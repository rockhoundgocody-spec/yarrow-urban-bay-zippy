// RockHound-GO Service Worker v33
// Bump this version string to force cache invalidation
const CACHE_VERSION = 'rh-v33';
const STATIC_CACHE = `${CACHE_VERSION}-static`;

const OFFLINE_MAP_DB = 'rockhound_offline_maps';
const OFFLINE_MAP_STORE = 'map_tiles';

// On install: skip waiting so the new SW activates immediately
self.addEventListener('install', () => {
  self.skipWaiting();
});

// On activate: delete ALL old caches so stale chunks are gone
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== STATIC_CACHE)
          .map((key) => caches.delete(key))
      )
    ).then(() => self.clients.claim())
  );
});

// Helper to get tile from IndexedDB
async function getCachedTile(url) {
  return new Promise((resolve) => {
    const request = indexedDB.open(OFFLINE_MAP_DB);
    request.onsuccess = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(OFFLINE_MAP_STORE)) {
        resolve(null);
        return;
      }
      const transaction = db.transaction([OFFLINE_MAP_STORE], 'readonly');
      const store = transaction.objectStore(OFFLINE_MAP_STORE);
      const getRequest = store.get(url);
      getRequest.onsuccess = () => {
        resolve(getRequest.result ? getRequest.result.data : null);
      };
      getRequest.onerror = () => resolve(null);
    };
    request.onerror = () => resolve(null);
  });
}

// Network-first for JS/CSS chunks — never serve stale bundles
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Handle map tiles (OpenStreetMap or OpenFreeMap)
  if (url.hostname.includes('tile.openstreetmap.org') || url.hostname.includes('tiles.openfreemap.org')) {
    event.respondWith(
      fetch(event.request).catch(async () => {
        const cachedBlob = await getCachedTile(event.request.url);
        if (cachedBlob) {
          return new Response(cachedBlob, {
            headers: { 'Content-Type': 'image/png' }
          });
        }
        return caches.match(event.request);
      })
    );
    return;
  }

  // Always network-first for Vite chunks and API calls
  if (
    url.pathname.includes('/.vite/') ||
    url.pathname.includes('/assets/') ||
    url.pathname.includes('/src/') ||
    url.pathname.includes('/node_modules/') ||
    url.hostname !== self.location.hostname
  ) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Network-first for everything else
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
