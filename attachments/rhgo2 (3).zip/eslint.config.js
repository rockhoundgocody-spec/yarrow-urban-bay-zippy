import globals from "globals";
import pluginJs from "@eslint/js";
import pluginReact from "eslint-plugin-react";
import pluginReactHooks from "eslint-plugin-react-hooks";
import pluginUnusedImports from "eslint-plugin-unused-imports";

export default [
  {
    // TypeScript test files are executed through tsx/node:test. This repo does
    // not install a TypeScript ESLint parser, so feeding TS syntax to Espree
    // produces parser errors rather than useful lint findings.
    ignores: ["**/*.test.ts", "**/*.test.tsx"],
  },
  {
    files: [
      "src/components/**/*.{js,mjs,cjs,jsx}",
      "src/pages/**/*.{js,mjs,cjs,jsx}",
      "src/Layout.jsx",
    ],
    ignores: ["src/lib/**/*", "src/components/ui/**/*"],
    ...pluginJs.configs.recommended,
    ...pluginReact.configs.flat.recommended,
    languageOptions: {
      globals: globals.browser,
      parserOptions: {
        ecmaVersion: 2022,
        sourceType: "module",
        ecmaFeatures: {
          jsx: true,
        },
      },
    },
    settings: {
      react: {
        version: "detect",
      },
    },
    plugins: {
      react: pluginReact,
      "react-hooks": pluginReactHooks,
      "unused-imports": pluginUnusedImports,
    },
    rules: {
      "no-unused-vars": "off",
      "react/jsx-uses-vars": "error",
      "react/jsx-uses-react": "error",
      "unused-imports/no-unused-imports": "error",
      "unused-imports/no-unused-vars": [
        "warn",
        {
          vars: "all",
          varsIgnorePattern: "^_",
          args: "after-used",
          argsIgnorePattern: "^_",
        },
      ],
      "react/prop-types": "off",
      "react/react-in-jsx-scope": "off",
      "react/no-unknown-property": [
        "error",
        { ignore: ["cmdk-input-wrapper", "toast-close"] },
      ],
      "react-hooks/rules-of-hooks": "error",
    },
  },
  {
    // Deno-targeted test harness files run under the Deno runtime, not the
    // browser — declare its global so `Deno.test` isn't flagged as undefined.
    files: ["**/*.test-target.js", "**/*.test-target.ts"],
    languageOptions: {
      globals: { ...globals.browser, ...globals.node, Deno: "readonly" },
      parserOptions: { ecmaVersion: 2022, sourceType: "module" },
    },
    rules: { "no-undef": "off" },
  },
  {
    // Unit tests run under the Node/Vitest runtime — Node globals such as
    // setImmediate are legitimately available there.
    files: ["**/*.test.js", "**/*.test.jsx"],
    languageOptions: {
      globals: { ...globals.browser, ...globals.node, Deno: "readonly" },
      parserOptions: { ecmaVersion: 2022, sourceType: "module" },
    },
    rules: { "no-undef": "off" },
  },
];