# Stripe Billing Integration Plan for RockHound-GO

Business: `rhgo.base44.app` — a rockhounding app with a paid membership ladder.

> Setup note: the Stripe Codex plugin and Stripe MCP planner were unavailable in this environment (`codex` command was not installed and `stripe_implementation_planner` was not exposed), so this plan is based on the existing repository implementation and Stripe Billing best practices.

## Billing model

RockHound-GO should use Stripe Billing subscriptions with hosted Checkout for new subscribers and the Stripe-hosted Billing Portal for plan management and cancellation. The app already has three recurring membership plans:

| Plan | Monthly | Annual | Primary value |
| --- | ---: | ---: | --- |
| Trail Scout | $14.99/mo | $120.52/yr | More AI scans and offline field packs |
| Crystal Pro | $24.99/mo | $200.92/yr | Deep AI, valuation, advanced maps, trip planning |
| Expedition Elite | $49.99/mo | $401.92/yr | Seller tools, provenance, land access, early AR |

Create one Stripe Product per plan and two recurring Prices per product (`month` and `year`). Store the resulting Price IDs in Base44 secrets:

- `STRIPE_PRICE_TRAIL_SCOUT_MONTHLY`
- `STRIPE_PRICE_TRAIL_SCOUT_ANNUAL`
- `STRIPE_PRICE_CRYSTAL_PRO_MONTHLY`
- `STRIPE_PRICE_CRYSTAL_PRO_ANNUAL`
- `STRIPE_PRICE_EXPEDITION_ELITE_MONTHLY`
- `STRIPE_PRICE_EXPEDITION_ELITE_ANNUAL`

## Required Stripe secrets

Set these only as server-side secrets; never commit them:

- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- The six `STRIPE_PRICE_*` values listed above

Use the publishable key only in client-side Stripe.js code if embedded payment UI is later added. Current hosted Checkout redirects do not require storing it in the frontend.

## Checkout flow

1. Authenticated user selects a plan and interval.
2. Client calls `createSubscriptionCheckout` with `plan_id`, `billing_interval`, `success_url`, and `cancel_url`.
3. Server validates the plan, interval, and redirect origins.
4. Server finds or creates a Stripe Customer tied to the app user.
5. Server creates a Stripe Checkout Session in `subscription` mode with metadata:
   - `user_email`
   - `user_id`
   - `plan_id`
   - `billing_interval`
6. Stripe redirects back to `BillingAccount` with `session_id`.
7. Entitlements remain server-authoritative and are only activated by signed Stripe webhooks.

## Webhook flow

Configure a Stripe webhook endpoint for `/api/functions/stripeWebhook` and subscribe to at least:

- `checkout.session.completed`
- `customer.subscription.updated`
- `customer.subscription.deleted`
- `invoice.payment_succeeded`
- `invoice.payment_failed`

Webhook handling should:

- Verify the `stripe-signature` header with `STRIPE_WEBHOOK_SECRET`.
- Resolve the app user from Checkout metadata first, then customer email as fallback.
- Resolve the tier from subscription metadata first, then Product ID compatibility mappings as fallback.
- Update only server-side user subscription fields.
- Leave paid entitlements unchanged for unknown products rather than accidentally granting access.

## Billing Portal

Existing subscribers should manage payment methods, cancellations, and plan changes through `billingPortal`. Configure the Billing Portal in Stripe Dashboard to allow the desired actions:

- Update payment method
- Cancel subscription
- Switch between the same product's monthly and annual prices, if desired
- Switch between membership products, if desired

## Security and operational checklist

- Rotate any Stripe secret key that has been shared in chat, logs, or commits.
- Keep Stripe secret keys server-side only.
- Do not trust client-side subscription state.
- Validate all redirect URLs against trusted app origins.
- Use signed webhooks as the only authority for entitlement changes.
- Test with Stripe test cards and Stripe CLI webhook forwarding before going live.
- Before live launch, replace test keys with live keys and live Price IDs, then perform a $0/test-mode-equivalent production smoke test using Stripe's recommended go-live checklist.
