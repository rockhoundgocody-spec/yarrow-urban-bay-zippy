import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const reactPath = path.resolve(__dirname, 'node_modules/react/index.js');
const reactDomPath = path.resolve(__dirname, 'node_modules/react-dom/index.js');
const reactJsxPath = path.resolve(__dirname, 'node_modules/react/jsx-runtime.js');
const reactJsxDevPath = path.resolve(__dirname, 'node_modules/react/jsx-dev-runtime.js');
const reactDomClientPath = path.resolve(__dirname, 'node_modules/react-dom/client.js');

export default defineConfig({
  cacheDir: '.vite_cache_v34',

  plugins: [react()],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      'react': reactPath,
      'react-dom': reactDomPath,
      'react/jsx-runtime': reactJsxPath,
      'react/jsx-dev-runtime': reactJsxDevPath,
      'react-dom/client': reactDomClientPath,
    },
    dedupe: ['react', 'react-dom', 'react/jsx-runtime'],
  },

  optimizeDeps: {
    // Exclude SDK from pre-bundling so it resolves React through
    // the runtime alias above rather than baking its own copy
    exclude: ['@base44/sdk'],
    include: [
      'react', 'react-dom', 'react/jsx-runtime',
      'react-router-dom', 'framer-motion',
      '@tanstack/react-query', 'lucide-react', 'date-fns', 'lodash',
      'zustand', 'clsx', 'tailwind-merge', 'class-variance-authority',
      'react-hook-form', 'recharts', 'moment', 'zod', 'axios', 'sonner',
      'vaul',
      '@radix-ui/react-dialog', '@radix-ui/react-toast', '@radix-ui/react-select',
      '@radix-ui/react-popover', '@radix-ui/react-tooltip',
      '@radix-ui/react-scroll-area', '@radix-ui/react-tabs',
      '@radix-ui/react-slot', '@radix-ui/react-label',
      '@radix-ui/react-checkbox', '@radix-ui/react-switch',
      '@radix-ui/react-progress', '@radix-ui/react-accordion',
      '@radix-ui/react-avatar', '@radix-ui/react-separator',
      '@radix-ui/react-slider', '@radix-ui/react-alert-dialog',
      '@radix-ui/react-hover-card', '@radix-ui/react-radio-group',
      '@radix-ui/react-dropdown-menu',
      'next-themes', 'react-hot-toast', 'react-markdown',
      'canvas-confetti', 'cmdk',
    ],
  },
});