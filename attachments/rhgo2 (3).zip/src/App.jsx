import { Toaster } from "@/components/ui/toaster"
import React, { Suspense, lazy, useEffect } from 'react';
// force HMR re-evaluation — clears stale Vite dep cache (v2)
import { motion } from 'framer-motion';
import { pageVariants } from '@/animation/pageVariants';
import { useNavDirection, prefersReducedMotion } from '@/animation/useNavDirection';
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker';
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import PublicErrorBoundary from '@/components/layout/PublicErrorBoundary';
import { AuthProvider, useAuth } from '@/lib/AuthContext';


import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AdminRoute from '@/components/auth/AdminRoute';
import BootSplash from '@/components/layout/BootSplash';
import { ModeProvider } from '@/lib/modeStore.jsx';
import PageSuspense from '@/components/layout/PageSuspense';
import SyncBootstrap from '@/components/offline/SyncBootstrap';

// ── Critical path — eager (used on / and camera flow) ────────────────────────
import Auth from './pages/Auth.jsx';
import Onboarding from './pages/Onboarding.jsx';
import SpecimenIdentifier from './pages/SpecimenIdentifier.jsx';

// ── All other explicit routes — lazy loaded ───────────────────────────────────
const Analytics            = lazy(() => import('./pages/Analytics.jsx'));
const MineralGuides        = lazy(() => import('./pages/MineralGuides.jsx'));
const SocialFeed           = lazy(() => import('./pages/SocialFeed.jsx'));
const AgentsHub            = lazy(() => import('./pages/AgentsHub.jsx'));
const FieldGuide           = lazy(() => import('./pages/FieldLessons.jsx'));
const FieldMap             = lazy(() => import('./pages/FieldMap.jsx'));
const ItineraryPlanner     = lazy(() => import('./pages/ItineraryPlanner.jsx'));
const FieldMissions        = lazy(() => import('./pages/FieldMissions.jsx'));
const BillingAccount       = lazy(() => import('./pages/BillingAccount.jsx'));
const MarketIntelligence   = lazy(() => import('./pages/MarketIntelligence.jsx'));
const PartnerDirectory     = lazy(() => import('./pages/PartnerDirectory.jsx'));
const LegalityIntelligence = lazy(() => import('./pages/LegalityIntelligence.jsx'));
const CollectorIdentity    = lazy(() => import('./pages/CollectorIdentity.jsx'));
const TradeBoard           = lazy(() => import('./pages/TradeBoard.jsx'));
const MineralNewsFeed      = lazy(() => import('./pages/MineralNewsFeed.jsx'));
const CollectionExport     = lazy(() => import('./pages/CollectionExport.jsx'));
const GeoTutorChat         = lazy(() => import('./pages/GeoTutorChat.jsx'));
const WeatherSafety        = lazy(() => import('./pages/WeatherSafety.jsx'));
const ClubFinder           = lazy(() => import('./pages/ClubFinder.jsx'));
const AboutUs              = lazy(() => import('./pages/AboutUs.jsx'));
const HelpSupport          = lazy(() => import('./pages/HelpSupport.jsx'));
const SpecimenAlerts       = lazy(() => import('./pages/SpecimenAlerts.jsx'));
const FieldPackBuilder     = lazy(() => import('./pages/FieldPackBuilder.jsx'));
const PrivacyPolicy        = lazy(() => import('./pages/PrivacyPolicy.jsx'));
const TermsOfService       = lazy(() => import('./pages/TermsOfService.jsx'));
const ParentalDashboard    = lazy(() => import('./pages/ParentalDashboard.jsx'));
const Challenges           = lazy(() => import('./pages/Challenges.jsx'));
const Mineralpedia         = lazy(() => import('./pages/Mineralpedia.jsx'));
const ShopProfile          = lazy(() => import('./pages/ShopProfile.jsx'));
const DisputeDashboard     = lazy(() => import('./pages/DisputeDashboard.jsx'));
const SpecimenViewer       = lazy(() => import('./pages/SpecimenViewer.jsx'));
const AppRelease           = lazy(() => import('./pages/AppRelease.jsx'));
const GeoDex               = lazy(() => import('./pages/GeoDex.jsx'));
const GamificationHub      = lazy(() => import('./pages/GamificationHub.jsx'));
const FieldTripManager     = lazy(() => import('./pages/FieldTripManager.jsx'));
const AdminSpecimenDashboard = lazy(() => import('./pages/AdminSpecimenDashboard.jsx'));
const Explore              = lazy(() => import('./pages/Explore.jsx'));
const ExploreIntelligence  = lazy(() => import('./pages/ExploreIntelligence.jsx'));
const IdentifyResult       = lazy(() => import('./pages/IdentifyResult.jsx'));
const SpecimenDetail       = lazy(() => import('./pages/SpecimenDetail.jsx'));
const MarketSell           = lazy(() => import('./pages/MarketSell.jsx'));
const QuickSell            = lazy(() => import('./pages/QuickSell.jsx'));
const OfflineFieldMode     = lazy(() => import('./pages/OfflineFieldMode.jsx'));
const AISubscription       = lazy(() => import('./pages/AISubscription.jsx'));
const MarketAnalytics      = lazy(() => import('./pages/MarketAnalytics.jsx'));
const ExpeditionPlanner    = lazy(() => import('./pages/ExpeditionPlanner.jsx'));
const ExpertVerification   = lazy(() => import('./pages/ExpertVerification.jsx'));
const OfflineSyncDashboard = lazy(() => import('./pages/OfflineSyncDashboard.jsx'));
const SocialDiscoveryFeed  = lazy(() => import('./pages/SocialDiscoveryFeed.jsx'));
const SpecimenMapView      = lazy(() => import('./pages/SpecimenMapView.jsx'));
const EducationHub         = lazy(() => import('./pages/EducationHub.jsx'));
const FieldAlerts          = lazy(() => import('./pages/FieldAlerts.jsx'));
const Notifications        = lazy(() => import('./pages/Notifications.jsx'));
const Marketplace          = lazy(() => import('./pages/Marketplace.jsx'));
const TrailsRoutes         = lazy(() => import('./pages/TrailsRoutes.jsx'));
const CommerceEngine       = lazy(() => import('./pages/CommerceEngine.jsx'));
const LocalityRead         = lazy(() => import('./pages/LocalityRead.jsx'));
const FieldVoiceLogger     = lazy(() => import('./pages/FieldVoiceLogger.jsx'));
const AppDownload          = lazy(() => import('./pages/AppDownload.jsx'));
const Pricing              = lazy(() => import('./pages/Pricing.jsx'));
const Checkout             = lazy(() => import('./pages/Checkout.jsx'));
const OrderConfirmation    = lazy(() => import('./pages/OrderConfirmation.jsx'));
const Orders               = lazy(() => import('./pages/Orders.jsx'));
const SubscriptionManagement = lazy(() => import('./pages/SubscriptionManagement.jsx'));
const BadgeShowcase = lazy(() => import('./pages/BadgeShowcase.jsx'));
const GoalTracker = lazy(() => import('./pages/GoalTracker.jsx'));
const SellerCommandCenter = lazy(() => import('./pages/SellerCommandCenter.jsx'));
const AuditCommandCenter = lazy(() => import('./pages/AdminAuditCenter.jsx'));
const Dashboard          = lazy(() => import('./pages/Dashboard.jsx'));
const CloverPage         = lazy(() => import('./pages/CloverPage.jsx'));
const GuidedIdentify     = lazy(() => import('./pages/GuidedIdentify.jsx'));
const SalesOverview      = lazy(() => import('./pages/SalesOverview.jsx'));
const TripCalendar           = lazy(() => import('./pages/TripCalendar.jsx'));
const DailyBriefing          = lazy(() => import('./pages/DailyBriefing.jsx'));
const SpecimenCompare        = lazy(() => import('./pages/SpecimenCompare.jsx'));
const ActivityFeed           = lazy(() => import('./pages/ActivityFeed.jsx'));
const ReferralHub            = lazy(() => import('./pages/ReferralHub.jsx'));
const NotificationSettings   = lazy(() => import('./pages/NotificationSettings.jsx'));
const FieldNotes             = lazy(() => import('./pages/FieldNotes.jsx'));
const SavedSites             = lazy(() => import('./pages/SavedSites.jsx'));
const TripPlannerNew         = lazy(() => import('./pages/TripPlanner.jsx'));
const StorageSubscription    = lazy(() => import('./pages/StorageSubscription.jsx'));
const VerifiedFindsMap       = lazy(() => import('./pages/VerifiedFindsMap.jsx'));
const FieldTools             = lazy(() => import('./pages/FieldTools.jsx'));
const CollectionAnalytics    = lazy(() => import('./pages/CollectionAnalytics.jsx'));
const LocationReviewsHub     = lazy(() => import('./pages/LocationReviewsHub.jsx'));
const LandingHome            = lazy(() => import('./pages/LandingHome.jsx'));
const LandingAIMineralID     = lazy(() => import('./pages/LandingAIMineralID.jsx'));
const LandingRockhoundingMap = lazy(() => import('./pages/LandingRockhoundingMap.jsx'));
const LandingCollection      = lazy(() => import('./pages/LandingCollection.jsx'));
const LandingFieldGuide      = lazy(() => import('./pages/LandingFieldGuide.jsx'));
const LandingLandAccess      = lazy(() => import('./pages/LandingLandAccess.jsx'));
const AgateTreatise          = lazy(() => import('./pages/AgateTreatise.jsx'));
const FieldExpeditionHub     = lazy(() => import('./pages/FieldExpeditionHub.jsx'));
const DailyQuestHub          = lazy(() => import('./pages/DailyQuestHub.jsx'));
const CollectionDashboard    = lazy(() => import('./pages/CollectionDashboard.jsx'));
const LogbookTemplates       = lazy(() => import('./pages/LogbookTemplates.jsx'));
const ResearchLeaderboard    = lazy(() => import('./pages/ResearchLeaderboard.jsx'));
const JulesAuditCenter       = lazy(() => import('./pages/JulesAuditCenter.jsx'));
const CrawlerDashboard       = lazy(() => import('./pages/CrawlerDashboard.jsx'));
const ProgressDashboard      = lazy(() => import('./pages/ProgressDashboard.jsx'));
const LandMarketplace        = lazy(() => import('./pages/LandMarketplace.jsx'));
const LandPropertyDetail     = lazy(() => import('./pages/LandPropertyDetail.jsx'));
const HostDashboard          = lazy(() => import('./pages/HostDashboard.jsx'));
const SafetyCenter           = lazy(() => import('./pages/SafetyCenter.jsx'));
const AppSettings            = lazy(() => import('./pages/AppSettings.jsx'));
const AdminOps               = lazy(() => import('./pages/AdminOps.jsx'));
const Contact                = lazy(() => import('./pages/Contact.jsx'));
const ScanHistory            = lazy(() => import('./pages/ScanHistory.jsx'));
const EngineConfigConsole    = lazy(() => import('./pages/EngineConfigConsole.jsx'));
const Chronolith             = lazy(() => import('./pages/Chronolith.jsx'));
const ChronolithCasePage     = lazy(() => import('./pages/ChronolithCase.jsx'));
const SquareDashboard        = lazy(() => import('./pages/SquareDashboard.jsx'));
const PublicFindsFeed        = lazy(() => import('./pages/PublicFindsFeed.jsx'));
const PrivacyControls        = lazy(() => import('./pages/PrivacyControls.jsx'));
const GeoSynthesis           = lazy(() => import('./pages/GeoSynthesis.jsx'));
const AsiCollective          = lazy(() => import('./pages/AsiCollective.jsx'));
const GuestScan               = lazy(() => import('./pages/GuestScan.jsx'));
const RqsLedger               = lazy(() => import('./pages/RqsLedger.jsx'));

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : () => null;

const LayoutWrapper = ({ children, currentPageName }) => Layout
  ? <Layout currentPageName={currentPageName}><PageSuspense><PageTransition>{children}</PageTransition></PageSuspense></Layout>
  : <PageSuspense><PageTransition>{children}</PageTransition></PageSuspense>;

function PageTransition({ children }) {
  const location = useLocation();
  const direction = useNavDirection();
  // Reduced motion keeps the crossfade but drops the horizontal travel.
  const offset = prefersReducedMotion() ? 0 : 24 * direction;
  return (
    <motion.div
      key={location.key}
      initial={{ opacity: 0, x: offset }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
      className="h-full w-full"
    >
      {children}
    </motion.div>
  );
}

// Marketing/SEO landing routes — rendered outside the auth gate and app shell so
// crawlers and the platform prerenderer always get full page HTML, never a login
// wall, boot splash, or layout chrome.
const PUBLIC_MARKETING_ROUTES = {
  '/': LandingHome,
  '/ai-mineral-identification': LandingAIMineralID,
  '/rockhounding-map': LandingRockhoundingMap,
  '/mineral-collection-tracker': LandingCollection,
  '/rockhounding-field-guide': LandingFieldGuide,
  '/land-access-rockhounding': LandingLandAccess,
  '/agates': AgateTreatise,
  '/agate-treatise': AgateTreatise,
  '/guest-scan': GuestScan,
  '/try': GuestScan,
  '/AboutUs': AboutUs,
  '/Contact': Contact,
  '/contact': Contact,
  '/HelpSupport': HelpSupport,
  '/PrivacyPolicy': PrivacyPolicy,
  '/privacy': PrivacyPolicy,
  '/TermsOfService': TermsOfService,
  '/terms': TermsOfService,
};

// Admin/internal pages from the pagesConfig loop that must be role-gated
const ADMIN_PAGE_SET = new Set(['AdminDashboard']);

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  const PublicPage = PUBLIC_MARKETING_ROUTES[location.pathname];
  if (PublicPage) {
    return (
      <PublicErrorBoundary>
        <Suspense fallback={null}><PublicPage /></Suspense>
      </PublicErrorBoundary>
    );
  }

  if (isLoadingPublicSettings || isLoadingAuth) {
    return <BootSplash />;
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      return <Auth />;
    }
  }

  return (
    <Routes>
      <Route path="/app" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([path, Page]) => {
        const page = (
          <LayoutWrapper currentPageName={path}>
            <Page />
          </LayoutWrapper>
        );
        return (
          <Route
            key={path}
            path={`/${path}`}
            element={ADMIN_PAGE_SET.has(path) ? <AdminRoute>{page}</AdminRoute> : page}
          />
        );
      })}
      <Route path="/Analytics" element={<LayoutWrapper currentPageName="Analytics"><Analytics /></LayoutWrapper>} />
      <Route path="/MineralGuides" element={<LayoutWrapper currentPageName="MineralGuides"><MineralGuides /></LayoutWrapper>} />

      <Route path="/SocialFeed" element={<LayoutWrapper currentPageName="SocialFeed"><SocialFeed /></LayoutWrapper>} />
      <Route path="/AgentsHub" element={<LayoutWrapper currentPageName="AgentsHub"><AgentsHub /></LayoutWrapper>} />

      <Route path="/FieldLessons" element={<LayoutWrapper currentPageName="FieldGuide"><FieldGuide /></LayoutWrapper>} />
      <Route path="/FieldGuide" element={<LayoutWrapper currentPageName="FieldGuide"><FieldGuide /></LayoutWrapper>} />
      <Route path="/FieldMap" element={<LayoutWrapper currentPageName="FieldMap"><FieldMap /></LayoutWrapper>} />

      <Route path="/ItineraryPlanner" element={<LayoutWrapper currentPageName="ItineraryPlanner"><ItineraryPlanner /></LayoutWrapper>} />
      <Route path="/FieldMissions" element={<LayoutWrapper currentPageName="FieldMissions"><FieldMissions /></LayoutWrapper>} />
      <Route path="/BillingAccount" element={<LayoutWrapper currentPageName="BillingAccount"><BillingAccount /></LayoutWrapper>} />
      <Route path="/Onboarding" element={<Onboarding />} />

      <Route path="/MarketIntelligence" element={<LayoutWrapper currentPageName="MarketIntelligence"><MarketIntelligence /></LayoutWrapper>} />

      <Route path="/PartnerDirectory" element={<LayoutWrapper currentPageName="PartnerDirectory"><PartnerDirectory /></LayoutWrapper>} />
      <Route path="/LegalityIntelligence" element={<LayoutWrapper currentPageName="LegalityIntelligence"><LegalityIntelligence /></LayoutWrapper>} />


      <Route path="/CollectorIdentity" element={<LayoutWrapper currentPageName="CollectorIdentity"><CollectorIdentity /></LayoutWrapper>} />
      <Route path="/TradeBoard" element={<LayoutWrapper currentPageName="TradeBoard"><TradeBoard /></LayoutWrapper>} />



      <Route path="/MineralNewsFeed" element={<LayoutWrapper currentPageName="MineralNewsFeed"><MineralNewsFeed /></LayoutWrapper>} />
      <Route path="/CollectionExport" element={<LayoutWrapper currentPageName="CollectionExport"><CollectionExport /></LayoutWrapper>} />
      <Route path="/GeoTutorChat" element={<LayoutWrapper currentPageName="GeoTutorChat"><GeoTutorChat /></LayoutWrapper>} />
      <Route path="/WeatherSafety" element={<LayoutWrapper currentPageName="WeatherSafety"><WeatherSafety /></LayoutWrapper>} />
      <Route path="/ClubFinder" element={<LayoutWrapper currentPageName="ClubFinder"><ClubFinder /></LayoutWrapper>} />

      <Route path="/SpecimenAlerts" element={<LayoutWrapper currentPageName="SpecimenAlerts"><SpecimenAlerts /></LayoutWrapper>} />
      <Route path="/FieldPackBuilder" element={<LayoutWrapper currentPageName="FieldPackBuilder"><FieldPackBuilder /></LayoutWrapper>} />




      <Route path="/DisputeDashboard" element={<AdminRoute><LayoutWrapper currentPageName="DisputeDashboard"><DisputeDashboard /></LayoutWrapper></AdminRoute>} />
      <Route path="/SpecimenViewer" element={<LayoutWrapper currentPageName="SpecimenViewer"><SpecimenViewer /></LayoutWrapper>} />
      <Route path="/SpecimenIdentifier" element={<LayoutWrapper currentPageName="SpecimenIdentifier"><SpecimenIdentifier /></LayoutWrapper>} />
      <Route path="/Identify" element={<Navigate to="/SpecimenIdentifier" replace />} />
      <Route path="/Scan" element={<Navigate to="/SpecimenIdentifier" replace />} />
      <Route path="/AppRelease" element={<LayoutWrapper currentPageName="AppRelease"><AppRelease /></LayoutWrapper>} />
      <Route path="/GeoDex" element={<LayoutWrapper currentPageName="GeoDex"><GeoDex /></LayoutWrapper>} />
      <Route path="/GamificationHub" element={<LayoutWrapper currentPageName="GamificationHub"><GamificationHub /></LayoutWrapper>} />
      <Route path="/FieldTripManager" element={<LayoutWrapper currentPageName="FieldTripManager"><FieldTripManager /></LayoutWrapper>} />
      <Route path="/AdminSpecimenDashboard" element={<AdminRoute><LayoutWrapper currentPageName="AdminSpecimenDashboard"><AdminSpecimenDashboard /></LayoutWrapper></AdminRoute>} />
      <Route path="/Explore" element={<LayoutWrapper currentPageName="Explore"><Explore /></LayoutWrapper>} />
      <Route path="/ExploreIntelligence" element={<LayoutWrapper currentPageName="ExploreIntelligence"><ExploreIntelligence /></LayoutWrapper>} />
      <Route path="/EducationHub" element={<LayoutWrapper currentPageName="EducationHub"><EducationHub /></LayoutWrapper>} />
      <Route path="/Market" element={<LayoutWrapper currentPageName="Market"><Marketplace /></LayoutWrapper>} />
      <Route path="/IdentifyResult" element={<LayoutWrapper currentPageName="IdentifyResult"><IdentifyResult /></LayoutWrapper>} />
      <Route path="/SpecimenDetail" element={<LayoutWrapper currentPageName="SpecimenDetail"><SpecimenDetail /></LayoutWrapper>} />
      <Route path="/MarketSell" element={<LayoutWrapper currentPageName="MarketSell"><MarketSell /></LayoutWrapper>} />
      <Route path="/QuickSell" element={<LayoutWrapper currentPageName="QuickSell"><QuickSell /></LayoutWrapper>} />
      <Route path="/OfflineFieldMode" element={<LayoutWrapper currentPageName="OfflineFieldMode"><OfflineFieldMode /></LayoutWrapper>} />
      <Route path="/AISubscription" element={<LayoutWrapper currentPageName="AISubscription"><AISubscription /></LayoutWrapper>} />
      <Route path="/MarketAnalytics" element={<LayoutWrapper currentPageName="MarketAnalytics"><MarketAnalytics /></LayoutWrapper>} />
      <Route path="/ExpeditionPlanner" element={<LayoutWrapper currentPageName="ExpeditionPlanner"><ExpeditionPlanner /></LayoutWrapper>} />
      <Route path="/ExpertVerification" element={<LayoutWrapper currentPageName="ExpertVerification"><ExpertVerification /></LayoutWrapper>} />
      <Route path="/OfflineSyncDashboard" element={<LayoutWrapper currentPageName="OfflineSyncDashboard"><OfflineSyncDashboard /></LayoutWrapper>} />
      <Route path="/SocialDiscoveryFeed" element={<LayoutWrapper currentPageName="SocialDiscoveryFeed"><SocialDiscoveryFeed /></LayoutWrapper>} />
      <Route path="/SpecimenMapView" element={<SpecimenMapView />} />
      <Route path="/FieldAlerts" element={<LayoutWrapper currentPageName="FieldAlerts"><FieldAlerts /></LayoutWrapper>} />
      <Route path="/Notifications" element={<LayoutWrapper currentPageName="Notifications"><Notifications /></LayoutWrapper>} />
      <Route path="/TrailsRoutes" element={<LayoutWrapper currentPageName="TrailsRoutes"><TrailsRoutes /></LayoutWrapper>} />
      <Route path="/CommerceEngine" element={<LayoutWrapper currentPageName="CommerceEngine"><CommerceEngine /></LayoutWrapper>} />
      <Route path="/LocalityRead" element={<LayoutWrapper currentPageName="LocalityRead"><LocalityRead /></LayoutWrapper>} />
      <Route path="/FieldVoiceLogger" element={<LayoutWrapper currentPageName="FieldVoiceLogger"><FieldVoiceLogger /></LayoutWrapper>} />
      <Route path="/AppDownload" element={<LayoutWrapper currentPageName="AppDownload"><AppDownload /></LayoutWrapper>} />
      <Route path="/Pricing" element={<LayoutWrapper currentPageName="Pricing"><Pricing /></LayoutWrapper>} />
      <Route path="/Checkout" element={<LayoutWrapper currentPageName="Checkout"><Checkout /></LayoutWrapper>} />
      <Route path="/OrderConfirmation" element={<LayoutWrapper currentPageName="OrderConfirmation"><OrderConfirmation /></LayoutWrapper>} />
      <Route path="/Orders" element={<LayoutWrapper currentPageName="Orders"><Orders /></LayoutWrapper>} />
      <Route path="/SubscriptionManagement" element={<LayoutWrapper currentPageName="SubscriptionManagement"><SubscriptionManagement /></LayoutWrapper>} />
      <Route path="/BadgeShowcase" element={<LayoutWrapper currentPageName="BadgeShowcase"><BadgeShowcase /></LayoutWrapper>} />
      <Route path="/GoalTracker" element={<LayoutWrapper currentPageName="GoalTracker"><GoalTracker /></LayoutWrapper>} />
      <Route path="/SellerCommandCenter" element={<LayoutWrapper currentPageName="SellerCommandCenter"><SellerCommandCenter /></LayoutWrapper>} />
      <Route path="/AuditCommandCenter" element={<AdminRoute><LayoutWrapper currentPageName="AuditCommandCenter"><AuditCommandCenter /></LayoutWrapper></AdminRoute>} />
      <Route path="/Dashboard" element={<LayoutWrapper currentPageName="Dashboard"><Dashboard /></LayoutWrapper>} />
      <Route path="/Clover"          element={<LayoutWrapper currentPageName="Clover"><CloverPage /></LayoutWrapper>} />
      <Route path="/GuidedIdentify" element={<LayoutWrapper currentPageName="GuidedIdentify"><GuidedIdentify /></LayoutWrapper>} />
      <Route path="/SalesOverview" element={<AdminRoute><LayoutWrapper currentPageName="SalesOverview"><SalesOverview /></LayoutWrapper></AdminRoute>} />
      <Route path="/TripCalendar" element={<LayoutWrapper currentPageName="TripCalendar"><TripCalendar /></LayoutWrapper>} />
      <Route path="/DailyBriefing" element={<LayoutWrapper currentPageName="DailyBriefing"><DailyBriefing /></LayoutWrapper>} />
      <Route path="/SpecimenCompare" element={<LayoutWrapper currentPageName="SpecimenCompare"><SpecimenCompare /></LayoutWrapper>} />
      <Route path="/ActivityFeed" element={<LayoutWrapper currentPageName="ActivityFeed"><ActivityFeed /></LayoutWrapper>} />
      <Route path="/ReferralHub" element={<LayoutWrapper currentPageName="ReferralHub"><ReferralHub /></LayoutWrapper>} />
      <Route path="/NotificationSettings" element={<LayoutWrapper currentPageName="NotificationSettings"><NotificationSettings /></LayoutWrapper>} />
      <Route path="/FieldNotes" element={<LayoutWrapper currentPageName="FieldNotes"><FieldNotes /></LayoutWrapper>} />
      <Route path="/SavedSites" element={<LayoutWrapper currentPageName="SavedSites"><SavedSites /></LayoutWrapper>} />

      <Route path="/StorageSubscription" element={<LayoutWrapper currentPageName="StorageSubscription"><StorageSubscription /></LayoutWrapper>} />
      <Route path="/VerifiedFindsMap" element={<LayoutWrapper currentPageName="VerifiedFindsMap"><VerifiedFindsMap /></LayoutWrapper>} />
      <Route path="/PublicFindsFeed" element={<LayoutWrapper currentPageName="PublicFindsFeed"><PublicFindsFeed /></LayoutWrapper>} />
      <Route path="/FieldTools" element={<LayoutWrapper currentPageName="FieldTools"><FieldTools /></LayoutWrapper>} />
      <Route path="/CollectionAnalytics" element={<LayoutWrapper currentPageName="CollectionAnalytics"><CollectionAnalytics /></LayoutWrapper>} />
      <Route path="/LocationReviewsHub" element={<LayoutWrapper currentPageName="LocationReviewsHub"><LocationReviewsHub /></LayoutWrapper>} />
      <Route path="/FieldExpeditionHub" element={<LayoutWrapper currentPageName="FieldExpeditionHub"><FieldExpeditionHub /></LayoutWrapper>} />
      <Route path="/DailyQuestHub" element={<LayoutWrapper currentPageName="DailyQuestHub"><DailyQuestHub /></LayoutWrapper>} />
      <Route path="/CollectionDashboard" element={<LayoutWrapper currentPageName="CollectionDashboard"><CollectionDashboard /></LayoutWrapper>} />
      <Route path="/LogbookTemplates" element={<LayoutWrapper currentPageName="LogbookTemplates"><LogbookTemplates /></LayoutWrapper>} />
      <Route path="/ResearchLeaderboard" element={<LayoutWrapper currentPageName="ResearchLeaderboard"><ResearchLeaderboard /></LayoutWrapper>} />
      <Route path="/JulesAuditCenter" element={<AdminRoute><LayoutWrapper currentPageName="JulesAuditCenter"><JulesAuditCenter /></LayoutWrapper></AdminRoute>} />
      <Route path="/CrawlerDashboard" element={<AdminRoute><LayoutWrapper currentPageName="CrawlerDashboard"><CrawlerDashboard /></LayoutWrapper></AdminRoute>} />
      <Route path="/ProgressDashboard" element={<LayoutWrapper currentPageName="ProgressDashboard"><ProgressDashboard /></LayoutWrapper>} />
      <Route path="/LandMarketplace" element={<LayoutWrapper currentPageName="LandMarketplace"><LandMarketplace /></LayoutWrapper>} />
      <Route path="/LandPropertyDetail" element={<LayoutWrapper currentPageName="LandPropertyDetail"><LandPropertyDetail /></LayoutWrapper>} />
      <Route path="/HostDashboard" element={<LayoutWrapper currentPageName="HostDashboard"><HostDashboard /></LayoutWrapper>} />
      <Route path="/SafetyCenter" element={<LayoutWrapper currentPageName="SafetyCenter"><SafetyCenter /></LayoutWrapper>} />
      <Route path="/AppSettings" element={<LayoutWrapper currentPageName="AppSettings"><AppSettings /></LayoutWrapper>} />
      <Route path="/AdminOps" element={<AdminRoute><LayoutWrapper currentPageName="AdminOps"><AdminOps /></LayoutWrapper></AdminRoute>} />
      <Route path="/ScanHistory" element={<LayoutWrapper currentPageName="ScanHistory"><ScanHistory /></LayoutWrapper>} />
      <Route path="/EngineConfigConsole" element={<AdminRoute><LayoutWrapper currentPageName="EngineConfigConsole"><EngineConfigConsole /></LayoutWrapper></AdminRoute>} />
      <Route path="/Chronolith" element={<LayoutWrapper currentPageName="Chronolith"><Chronolith /></LayoutWrapper>} />
      <Route path="/ChronolithCase" element={<LayoutWrapper currentPageName="ChronolithCase"><ChronolithCasePage /></LayoutWrapper>} />
      <Route path="/SquareDashboard" element={<AdminRoute><LayoutWrapper currentPageName="SquareDashboard"><SquareDashboard /></LayoutWrapper></AdminRoute>} />
      <Route path="/PrivacyControls" element={<LayoutWrapper currentPageName="PrivacyControls"><PrivacyControls /></LayoutWrapper>} />
      <Route path="/GeoSynthesis" element={<LayoutWrapper currentPageName="GeoSynthesis"><GeoSynthesis /></LayoutWrapper>} />
      <Route path="/AsiCollective" element={<LayoutWrapper currentPageName="AsiCollective"><AsiCollective /></LayoutWrapper>} />
      <Route path="/RqsLedger" element={<LayoutWrapper currentPageName="RqsLedger"><RqsLedger /></LayoutWrapper>} />

      {/* Convenience redirects for external/broken links */}
      <Route path="/RockIdentifier" element={<Navigate to="/SpecimenIdentifier" replace />} />
      <Route path="/MineralIdentifier" element={<Navigate to="/SpecimenIdentifier" replace />} />
      <Route path="/RockScanner" element={<Navigate to="/SpecimenIdentifier" replace />} />
      <Route path="/RockhoundingMap" element={<Navigate to={{ pathname: "/FieldMap", search: window.location.search }} replace />} />
      <Route path="/OfflineMap" element={<Navigate to="/OfflineFieldMode" replace />} />
      <Route path="/QuestHub" element={<Navigate to="/GamificationHub" replace />} />
      <Route path="/settings" element={<Navigate to="/Profile" replace />} />
      <Route path="/geo-dex" element={<Navigate to="/GeoDex" replace />} />
      <Route path="/explore/zones" element={<Navigate to="/Explore" replace />} />
      <Route path="/explore/sites" element={<Navigate to="/Explore" replace />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  useEffect(() => {
    // Apply saved accessibility / battery prefs (AppSettings)
    [['rh_pref_large_text','rh-a11y-large-text'],['rh_pref_high_contrast','rh-a11y-high-contrast'],['rh_pref_battery_saver','rh-battery-saver']]
      .forEach(([key, cls]) => document.body.classList.toggle(cls, localStorage.getItem(key) === '1'));
    // App is dark-only by design — force the .dark token class at the root so
    // public (pre-auth) legal/marketing pages that use Tailwind dark utilities
    // (text-white, bg-white/[0.02]) render correctly instead of white-on-white.
    document.documentElement.classList.add("dark");
    // Offline sync boot lives in <SyncBootstrap/> — it waits for a resolved,
    // authenticated user. Token presence alone is not access: an expired token
    // made anonymous visitors poll OfflineSyncQueue and collect 403s.
  }, []);

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ModeProvider>
            <NavigationTracker />
            <SyncBootstrap />
            <AuthenticatedApp />
          </ModeProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App