import React, { useState, useEffect, useRef, Component, useCallback } from "react";
import { motion } from "framer-motion";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  Mountain, Camera, BookOpen, Map, Gem, Menu, X, LogOut, Home,
  MessageSquare, Compass, UserCircle, ShieldCheck, ArrowLeft, ShoppingBag, Star, CloudSun, Users, Heart } from
"lucide-react";
import WeatherEmergencyAlert from "@/components/weather/WeatherEmergencyAlert";
import FooterNav from "./components/nav/FooterNav";
import NavMenuSheet from "./components/nav/NavMenuSheet";
import CompactToolRail from "./components/nav/CompactToolRail";
import { TabHistoryProvider, useTabHistory } from "./components/nav/TabHistoryContext";
import CloverAgentShell from "./components/clover/CloverAgentShell";
import AppShell from "./components/layout/AppShell.jsx";
import InstallPrompt from "./components/install/InstallPrompt";
import ImageLazyEnhancer from "./components/perf/ImageLazyEnhancer";
import FeedbackWidget from "./components/feedback/FeedbackWidget";
import { modeTheme } from "@/lib/modeTokens";
import { useModeStore } from "@/lib/modeStore";
import { useAuth } from "@/lib/AuthContext";
import GeoNotificationManager from "@/components/notifications/GeoNotificationManager";
import { bootCloverRuntime } from "@/lib/cloverRuntime";
import CloverCoreOrchestrator from "@/lib/agents/cloverCoreOrchestrator.js";
import XPToast from "@/components/gamification/XPToast";
import AsiWelcome from "@/components/asi/AsiWelcome";
import SyncStatusBar from "@/components/offline/SyncStatusBar";
import ProximityAlertBanner from "@/components/map/ProximityAlertBanner";
import ModeToggle from "@/components/mode/ModeToggle";
import NotificationBell from "@/components/notifications/NotificationBell";
// VideoSplashScreen lives in App.jsx (topmost overlay, above auth) so it plays
// on every site/app visit before any page renders. No session-gated splash here.

// ── Lightweight error logging (Sentry SDK can be wired in later if needed) ───
function initErrorLogging() {
  window.addEventListener("error", (e) =>
    console.error("[RHGO] uncaught error:", e.error || e.message)
  );
  window.addEventListener("unhandledrejection", (e) =>
    console.error("[RHGO] unhandled rejection:", e.reason)
  );
}

// ── Error boundary ───────────────────────────────────────────────────────────
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(err) {
    return { hasError: true, message: err?.message || "Unknown error" };
  }

  componentDidCatch(err) {
    console.error("[RHGO] render error boundary caught:", err);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-4 text-center px-6">
          <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center">
            <span className="text-2xl">⚠️</span>
          </div>
          <h2 className="text-xl font-bold text-white">Something went wrong</h2>
          <p className="text-white/40 text-sm max-w-sm">{this.state.message}</p>
          <button
            onClick={() => this.setState({ hasError: false, message: "" })}
            className="px-4 py-2 rounded-lg bg-amber-500/15 text-amber-400 text-sm hover:bg-amber-500/25 transition-colors">
            
            Try again
          </button>
        </div>);

    }
    return this.props.children;
  }
}

// ── Nav items — split by mode ───────────────────────────────────────────────
// Groups: core, discover, account
const HOME_NAV_ITEMS = [
  // Core
  { name: "Home",        icon: Home,         page: "Home",               group: "core" },
  { name: "Identify",    icon: Camera,        page: "SpecimenIdentifier", group: "core" },
  { name: "Collection",  icon: Gem,           page: "Collection",         group: "core" },
  { name: "Explore",     icon: Map,           page: "Explore",            group: "core" },
  // Discover
  { name: "Community",   icon: Users,         page: "Community",          group: "discover" },
  { name: "Market",      icon: ShoppingBag,   page: "Marketplace",        group: "discover" },
  { name: "Trip Planner",icon: Compass,       page: "TripPlanner",        group: "discover" },
  { name: "Saved Sites", icon: Heart,         page: "SavedSites",         group: "discover" },
  // Account
  { name: "Profile",     icon: UserCircle,    page: "Profile",            group: "account" },
  { name: "Pricing",     icon: Star,          page: "Pricing",            group: "account" },
];


const FIELD_NAV_ITEMS = [
{ name: "Home", icon: Home, page: "Home" },
{ name: "Field Map", icon: Map, page: "FieldMap" },
{ name: "Identify", icon: Camera, page: "SpecimenIdentifier" },
{ name: "Collection", icon: Gem, page: "Collection" },
{ name: "Field Guide", icon: BookOpen, page: "FieldGuide" },
{ name: "Weather", icon: CloudSun, page: "WeatherSafety" },
{ name: "Trip Planner", icon: Compass, page: "TripPlanner" },
{ name: "Legality", icon: ShieldCheck, page: "LegalityIntelligence" },
{ name: "Profile", icon: UserCircle, page: "Profile" }];









function PullToRefreshIndicator({ ptr, isField }) {
  if (!ptr.pulling && !ptr.refreshing) return null;
  return (
    <div style={{
      height: ptr.refreshing ? 48 : ptr.distance * 0.6,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      transition: ptr.refreshing ? 'height 0.2s ease' : 'none',
      overflow: 'hidden'
    }}>
      <div style={{
        width: 28, height: 28, borderRadius: '50%',
        border: `2px solid ${isField ? 'rgba(74,163,84,0.3)' : 'rgba(0,214,143,0.3)'}`,
        borderTopColor: isField ? '#4AA354' : '#00D68F',
        animation: ptr.refreshing ? 'spin 0.7s linear infinite' : 'none',
        transform: ptr.pulling ? `rotate(${ptr.distance / 60 * 180}deg)` : 'none',
        opacity: Math.min(1, ptr.distance / 40)
      }} />
    </div>
  );
}

function MobileNavMenu({ mobileOpen, setMobileOpen, isField, navGroups, visibleNavItems, currentPageName, user }) {
  if (!mobileOpen) return null;
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.22, ease: [0.23, 1, 0.32, 1] }}
      className="absolute inset-0 z-40"
      style={{
        background: isField
          ? 'linear-gradient(180deg, rgba(8,20,10,0.97) 0%, rgba(6,16,8,0.97) 100%)'
          : 'linear-gradient(180deg, rgba(8,6,18,0.97) 0%, rgba(5,4,14,0.97) 100%)',
        overflowY: 'auto', overflowX: 'hidden',
        paddingTop: 64, paddingBottom: 32,
      }}
    >
      <div className="relative z-10 px-4">
        {/* Top bar: notifications + mode toggle */}
        <div className="flex items-center justify-between mb-5 px-1">
          <span className="text-sm font-semibold" style={{ color: 'rgba(255,255,255,0.55)' }}>
            {isField ? '🌿 Field Mode' : '✦ Navigation'}
          </span>
          <div className="flex items-center gap-2">
            <NotificationBell />
            <ModeToggle />
          </div>
        </div>

        {/* Weather emergency alert — only visible during severe weather */}
        <div className="mb-4">
          <WeatherEmergencyAlert />
        </div>

        {/* Field mode banner */}
        {isField && (
          <div className="mb-4 px-3 py-2.5 rounded-2xl flex items-center gap-3" style={{ background: 'rgba(74,163,84,0.10)', border: '1px solid rgba(74,163,84,0.22)' }}>
            <Mountain className="w-4 h-4 flex-shrink-0" style={{ color: '#4AA354' }} />
            <div>
              <div className="text-xs font-bold" style={{ color: '#4AA354' }}>Field Mode Active</div>
              <div className="text-xs" style={{ color: 'rgba(74,163,84,0.55)' }}>Optimized for outdoor use</div>
            </div>
          </div>
        )}

        {/* Home mode — grouped, searchable navigation */}
        {navGroups ? (
          <NavMenuSheet currentPageName={currentPageName} onNavigate={() => setMobileOpen(false)} />
        ) : (
          /* Field mode — simple list */
          <nav className="flex flex-col gap-1.5">
            {visibleNavItems.map(item => {
              const active = currentPageName === item.page;
              return (
                <Link
                  key={item.page}
                  to={createPageUrl(item.page)}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-3 px-4 py-3.5 rounded-2xl font-medium transition-all duration-200"
                  style={{
                    background: active ? 'rgba(74,163,84,0.14)' : 'rgba(255,255,255,0.03)',
                    border: `1px solid ${active ? 'rgba(74,163,84,0.38)' : 'rgba(255,255,255,0.06)'}`,
                    color: active ? '#88FF99' : 'rgba(255,255,255,0.55)',
                    fontSize: 14,
                  }}
                >
                  <item.icon className="w-4 h-4" style={{ color: active ? '#88FF99' : 'rgba(255,255,255,0.35)' }} />
                  {item.name}
                </Link>
              );
            })}
          </nav>
        )}

        {/* Discord link */}
        <a
          href="https://discord.gg/3A7Fpgcx7"
          target="_blank"
          rel="noopener noreferrer"
          onClick={() => setMobileOpen(false)}
          className="mt-5 flex items-center gap-3 px-4 py-3 rounded-2xl font-medium transition-all"
          style={{
            background: 'rgba(88,101,242,0.08)',
            border: '1px solid rgba(88,101,242,0.20)',
            color: '#7289DA', fontSize: 13,
          }}
        >
          <MessageSquare className="w-4 h-4" />
          Join our Discord
        </a>

        {/* Sign out */}
        {user && (
          <button
            onClick={() => base44.auth.logout()}
            className="mt-4 mb-4 flex items-center gap-2 px-4 py-2.5 rounded-2xl w-full transition-all duration-200"
            style={{
              background: 'rgba(255,60,60,0.05)',
              border: '1px solid rgba(255,60,60,0.12)',
              color: 'rgba(255,120,120,0.65)', fontSize: 13,
            }}
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        )}
      </div>
    </motion.div>
  );
}

function LayoutHeader({ isField, showBack, handleBack, mobileOpen, setMobileOpen }) {
  return (
    <header className="absolute top-0 left-0 right-0 z-50" style={{ paddingTop: "env(safe-area-inset-top, 0px)", borderBottom: isField ? '1px solid rgba(74,163,84,0.35)' : '1px solid rgba(0,214,143,0.15)', boxShadow: isField ? '0 4px 24px rgba(0,0,0,0.6)' : '0 4px 24px rgba(0,0,0,0.5)', background: isField ? 'rgba(13,31,15,0.95)' : 'rgba(10,15,20,0.92)', backdropFilter: 'blur(10px)' }}>
      <div className="relative z-10 mx-auto px-3 py-1.5 max-w-7xl h-14 flex items-center justify-between">
        {/* Left: back button or logo */}
        <div className="flex items-center gap-2 w-12">
          {showBack ?
          <button
            onClick={handleBack}
            className="p-2 rounded-lg text-[var(--quantum-cyan)]/70 hover:text-[var(--quantum-cyan)] focus-visible:ring-2 focus-visible:outline-none focus-visible:ring-emerald-400 transition-all duration-300"
            style={{ minWidth: 44, minHeight: 44, display: "flex", alignItems: "center", justifyContent: "center" }}
            aria-label="Go back">
              <ArrowLeft className="w-5 h-5" />
            </button> :

          <Link to={createPageUrl("Home")} className="group">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all duration-300 overflow-hidden flex-shrink-0"
            style={{ border: "1.5px solid rgba(141,124,255,0.40)", boxShadow: "0 0 14px rgba(141,124,255,0.25), inset 0 1px 0 rgba(255,255,255,0.08)" }}>
                <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699b620aabda6503e72aa4f2/b4bbf8913_20260221_213444-IMG_STYLE.jpg"
                alt="RockHound-Go"
                className="w-full h-full object-cover" />
              </div>
            </Link>
          }
        </div>

        {/* Center: brand name */}
        <Link to={createPageUrl("Home")} className="flex-1 flex justify-center">
          {isField ?
          <div className="flex items-center gap-1.5">
              <span className="text-sm font-bold tracking-widest uppercase" style={{ color: '#4AA354', letterSpacing: '0.15em' }}>FIELD MODE</span>
              <span className="text-xs" style={{ color: 'rgba(74,163,84,0.6)' }}>● Active</span>
            </div> :

          <span className="font-black tracking-tight whitespace-nowrap text-2xl" style={{
            background: 'linear-gradient(120deg, #8D7CFF 0%, #7AE7FF 45%, #D4AF37 100%)',
            backgroundSize: '200%', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            textShadow: 'none', letterSpacing: '-0.03em'
          }}>
              ROCKHOUND-GO
            </span>
          }
        </Link>

        {/* Right: hamburger only */}
        <div className="w-12 flex justify-end">
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-expanded={mobileOpen}
            aria-label="Toggle navigation menu"
            className="p-2 rounded-lg focus-visible:ring-2 focus-visible:outline-none focus-visible:ring-emerald-400 transition-all duration-300"
            style={{ color: isField ? 'rgba(74,163,84,0.8)' : 'rgba(122,231,255,0.7)', boxShadow: mobileOpen ? isField ? '0 0 16px rgba(74,163,84,0.4)' : 'var(--glow-magenta)' : 'none' }}>
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </header>
  );
}

function LayoutBackground({ theme, isField }) {
  return (
    <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
      {/* Ambient glow layers — crossfade on mode change */}
      <div style={{ position: "absolute", inset: 0, background: theme.ambientGlow1, transition: "background 0.9s ease" }} />
      <div style={{ position: "absolute", inset: 0, background: theme.ambientGlow2, transition: "background 0.9s ease" }} />
      {/* Tactical grid */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `linear-gradient(0deg, rgba(${theme.accentRgb},${theme.gridOpacity}) 1px, transparent 1px), linear-gradient(90deg, rgba(${theme.accentRgb},${theme.gridOpacity}) 1px, transparent 1px)`,
        backgroundSize: `${theme.gridSize} ${theme.gridSize}`,
        transition: "opacity 0.6s ease"
      }} />
      {/* Field mode vignette */}
      {isField &&
      <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at 50% 50%, transparent 60%, rgba(0,0,0,0.5) 100%)" }} />
      }
    </div>
  );
}

// Inner layout — lives inside TabHistoryProvider so it can consume the nav stack context
function LayoutInner({ children, currentPageName }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [user, setUser] = useState(null);
  // VideoSplashScreen is rendered in App.jsx (above auth) so it plays on every
  // visit before Layout mounts. No splash state needed here.
  // Reuse the user already resolved by AuthContext instead of issuing a
  // separate base44.auth.me() call here (the platform rate-limits boot bursts).
  const { user: authedUser } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const { isField } = useModeStore();
  const { pushHistory, popHistory, canGoBack: stackCanGoBack } = useTabHistory();

  useEffect(() => {
    bootCloverRuntime();
  }, []);

  useEffect(() => {
    if (authedUser) {
      setUser(authedUser);
    }
  }, [authedUser]);

  useEffect(() => {
    initErrorLogging();
  }, []);

  // Push previous URL onto stack whenever we navigate (before location changes)
  const prevPathRef = useRef(null);
  useEffect(() => {
    if (prevPathRef.current && prevPathRef.current !== location.pathname + location.search) {
      pushHistory(prevPathRef.current);
    }
    prevPathRef.current = location.pathname + location.search;
    // Sync Clover orchestrator on every route change
    CloverCoreOrchestrator.onRouteChange(location.pathname);
  }, [location.pathname, location.search, pushHistory]);

  // Dark mode: app is dark-only by design. Ensure the .dark token class stays on
  // (App.jsx also forces it at the root; this guards against any earlier removal).
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  // Per-route canonical URL — prevents duplicate-content signals across SPA
  // routes. Without this, the canonical link stays hardcoded to "/" (from
  // index.html) for any authed route that doesn't call useSEO individually.
  useEffect(() => {
    let link = document.querySelector('link[rel="canonical"]');
    if (!link) {
      link = document.createElement('link');
      link.rel = 'canonical';
      document.head.appendChild(link);
    }
    link.href = 'https://rockhoundgo.com' + location.pathname;
  }, [location.pathname]);

  // Pull-to-refresh state
  const [ptr, setPtr] = useState({ pulling: false, distance: 0, refreshing: false });
  const ptrStartY = useRef(null);
  const mainRef = useRef(null);

  const handleTouchStart = useCallback((e) => {
    if (mainRef.current?.scrollTop === 0) {
      ptrStartY.current = e.touches[0].clientY;
    }
  }, []);

  const handleTouchMove = useCallback((e) => {
    if (ptrStartY.current === null) return;
    const dist = Math.max(0, e.touches[0].clientY - ptrStartY.current);
    if (dist > 4) setPtr((p) => ({ ...p, pulling: true, distance: Math.min(dist, 80) }));
  }, []);

  const handleTouchEnd = useCallback(() => {
    if (ptr.distance >= 60) {
      setPtr({ pulling: false, distance: 0, refreshing: true });
      window.dispatchEvent(new Event("rh:pull-refresh"));
      setTimeout(() => setPtr({ pulling: false, distance: 0, refreshing: false }), 1200);
    } else {
      setPtr({ pulling: false, distance: 0, refreshing: false });
    }
    ptrStartY.current = null;
  }, [ptr.distance]);

  const PRIMARY_PAGE_SET = new Set(["Home", "Collection", "RockhoundingMap", "FieldMap", "Profile"]);
  const showBack = !PRIMARY_PAGE_SET.has(currentPageName) && stackCanGoBack();

  const handleBack = () => {
    const prev = popHistory();
    if (prev) navigate(prev);
  };

  const allNavItems = isField ? FIELD_NAV_ITEMS : HOME_NAV_ITEMS;
  const visibleNavItems = allNavItems.filter((item) => {
    if (item.page === "AdminDashboard") return false;
    return true;
  });

  // Group items for the friendly menu layout (home mode only)
  const navGroups = isField ? null : [
    { label: "Main",     key: "core",     items: visibleNavItems.filter(i => i.group === "core") },
    { label: "Discover", key: "discover", items: visibleNavItems.filter(i => i.group === "discover") },
    { label: "Account",  key: "account",  items: visibleNavItems.filter(i => i.group === "account") },
  ];

  const theme = modeTheme(isField ? "field" : "home");

  return (
    <div style={{ position: 'relative', width: '100%', height: '100dvh', maxHeight: '100dvh', overflow: 'hidden', background: theme.pageBg || "#05070A" }}>
      {/* ── Persistent background — constrained to mobile shell ── */}
      <LayoutBackground theme={theme} isField={isField} />

      <AppShell currentPageName={currentPageName} style={{ position: 'relative', height: '100dvh', minHeight: '100dvh', overflow: 'hidden' }}>
        <style>{`
          * { scrollbar-width: thin; scrollbar-color: rgba(0,214,143,0.5) transparent; }
          ::-webkit-scrollbar { width: 8px; }
          ::-webkit-scrollbar-track { background: rgba(0,214,143,0.02); border-radius: 6px; }
          ::-webkit-scrollbar-thumb { background: linear-gradient(180deg, #00D68F, #7AE7FF); border-radius: 6px; border: 1px solid rgba(0,214,143,0.15); }
          @keyframes liquidHeroLayout { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
        `}</style>
        {/* Top Nav */}
        <LayoutHeader isField={isField} showBack={showBack} handleBack={handleBack} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} />

        {/* Dropdown Menu */}
        <MobileNavMenu mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} isField={isField} navGroups={navGroups} visibleNavItems={visibleNavItems} currentPageName={currentPageName} user={user} />

        {/* Compact auto-hiding tool rail */}
        <CompactToolRail />

        {/* Main Content */}
        <main
          ref={mainRef}
          className="relative z-10"
          style={{
            position: 'absolute',
            top: 'calc(3.5rem + env(safe-area-inset-top, 0px))',
            left: 0,
            right: 0,
            bottom: 'calc(5rem + env(safe-area-inset-bottom, 0px))',
            overflowY: 'auto',
            overflowX: 'hidden',
            overscrollBehaviorY: 'none',
            WebkitOverflowScrolling: 'touch'
          }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}>
          
          {/* Pull-to-refresh indicator */}
          <PullToRefreshIndicator ptr={ptr} isField={isField} />
          <ErrorBoundary>
            {children}
          </ErrorBoundary>
        </main>
      </AppShell>

      {/* Overlays — absolute within the mobile shell container */}
      <InstallPrompt />
      <ImageLazyEnhancer />
      <CloverAgentShell />
      <GeoNotificationManager />
      <XPToast />
      <AsiWelcome />
      <SyncStatusBar />
      <ProximityAlertBanner />
      <FeedbackWidget />
      <FooterNav currentPageName={currentPageName} />
    </div>);

}

export default function Layout({ children, currentPageName }) {
  return (
    <TabHistoryProvider>
      <LayoutInner currentPageName={currentPageName}>{children}</LayoutInner>
    </TabHistoryProvider>);

}