/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import { lazy } from 'react';
import __Layout from './Layout.jsx';

// ── Critical path — eager (Home, Collection, Marketplace are tab-1 routes) ──
import Home from './pages/Home';
import Collection from './pages/Collection';
import Marketplace from './pages/Marketplace';

// ── All other pages — code-split, loaded on demand ────────────────────────
const ARVeinMap            = lazy(() => import('./pages/ARVeinMap'));
const AboutUs              = lazy(() => import('./pages/AboutUs'));
const Achievements         = lazy(() => import('./pages/Achievements'));
const AdminDashboard       = lazy(() => import('./pages/AdminDashboard'));
const Challenges           = lazy(() => import('./pages/Challenges'));
const Community            = lazy(() => import('./pages/Community'));
const CommunityStats       = lazy(() => import('./pages/CommunityStats'));
const Discoveries          = lazy(() => import('./pages/Discoveries'));
const Events               = lazy(() => import('./pages/Events'));
const Guilds               = lazy(() => import('./pages/Guilds'));
const HelpSupport          = lazy(() => import('./pages/HelpSupport'));
const LearningCenter       = lazy(() => import('./pages/LearningCenter'));
const LocationLogbook      = lazy(() => import('./pages/LocationLogbook'));
const Mineralpedia         = lazy(() => import('./pages/Mineralpedia'));
const ParentalDashboard    = lazy(() => import('./pages/ParentalDashboard'));
const PrivacyPolicy        = lazy(() => import('./pages/PrivacyPolicy'));
const Profile              = lazy(() => import('./pages/Profile'));
const RockhoundingAssistant= lazy(() => import('./pages/RockhoundingAssistant'));
const RockhoundingJournal  = lazy(() => import('./pages/RockhoundingJournal'));
const ShopProfile          = lazy(() => import('./pages/ShopProfile'));
const Store                = lazy(() => import('./pages/Store'));
const TermsOfService       = lazy(() => import('./pages/TermsOfService'));
const TripPlanner          = lazy(() => import('./pages/TripPlanner'));

export const PAGES = {
    "ARVeinMap": ARVeinMap,
    "AboutUs": AboutUs,
    "Achievements": Achievements,
    "AdminDashboard": AdminDashboard,
    "Challenges": Challenges,
    "Collection": Collection,
    "Community": Community,
    "CommunityStats": CommunityStats,
    "Discoveries": Discoveries,
    "Events": Events,
    "Guilds": Guilds,
    "HelpSupport": HelpSupport,
    "Home": Home,
    "LearningCenter": LearningCenter,
    "LocationLogbook": LocationLogbook,
    "Marketplace": Marketplace,
    "Mineralpedia": Mineralpedia,
    "ParentalDashboard": ParentalDashboard,
    "PrivacyPolicy": PrivacyPolicy,
    "Profile": Profile,
    "RockhoundingAssistant": RockhoundingAssistant,
    "RockhoundingJournal": RockhoundingJournal,
    "ShopProfile": ShopProfile,
    "Store": Store,
    "TermsOfService": TermsOfService,
    "TripPlanner": TripPlanner,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};