import React, { Suspense, startTransition, lazy } from 'react'
import ReactDOM from 'react-dom/client'
import 'leaflet/dist/leaflet.css'
import '@/globals.css'
import '@/index.css'

const RootFallback = () => (
  <div style={{ position: 'fixed', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#05070A' }}>
    <div style={{ width: 28, height: 28, border: '3px solid rgba(255,255,255,0.08)', borderTopColor: '#00D68F', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} />
    <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

const rootEl = document.getElementById('root');
const appShell = document.createElement('div');
appShell.id = 'app-shell';
rootEl.appendChild(appShell);

const root = ReactDOM.createRoot(appShell);

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
  window.isIOS = true;
}

// Lazy-load App — defers all module evaluation until after ReactDOM.createRoot()
const App = lazy(() => import('@/App.jsx'));

startTransition(() => {
  root.render(
    <Suspense fallback={<RootFallback />}>
      <App />
    </Suspense>
  );
});