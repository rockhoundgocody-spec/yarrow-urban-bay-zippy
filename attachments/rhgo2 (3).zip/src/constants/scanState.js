export const SCAN_STATE = {
  IDLE: "idle",
  REQUESTING: "requestingPermission",
  READY: "cameraReady",
  CAPTURING: "capturing",
  ANALYZING: "analyzing",
  RESULT: "result",
  ERROR: "error",
};