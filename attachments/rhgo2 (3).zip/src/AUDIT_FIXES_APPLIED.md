# RockHound-GO Audit — Applied Fixes
**Date:** 2026-04-28 | **App ID:** 699b620aabda6503e72aa4f2

---

## Boot / Auth (Lead Orchestrator)
- `AuthenticatedApp` was calling `useAuth()` before `<Router>` context existed → crashes on mount
- Fixed: switched to `useContext(AuthContext)` with null guard spinner
- `AuthContext` exported from `lib/AuthContext.jsx`
- `ModeProvider` moved inside `<Router>` to resolve `useState` null context error
- Boot order now: `AuthProvider → QueryClientProvider → Router → ModeProvider → AuthenticatedApp`

## Explore / Map (Map Geo Auditor)
- GPS denial used to block entire Explore page with a dead-end screen
- GPS failure now falls back to `{ lat: 41.8041, lng: -87.8346, isSeed: true }` (Hickory Hills, IL)
- `useExploreData` merges DB sites with `chicagoSeedService` (50-mile radius) when DB has no records
- Exposes `isUsingRegionFallback` flag — shown in `ExploreHeader` as "IL Region" GPS badge (amber)
- `SitesTab` rebuilt: access badges (Public / Permit Required / Access Unverified / Fee Area)
- `SiteDetailSheet` bottom sheet: minerals, confidence bar, Directions (Google Maps), Save Offline, Plan a Trip
- Access reminder banner shown inline for permit-required and unverified sites
- Predictive disclaimer on every site sheet: "AI-inferred — always verify"

## Payments (Payment Auditor)
- `CheckoutFlow` restyled to dark crystalline RockHound-GO theme
- `PAYMENT_TYPE_LABELS` map added for all 6 checkout types
- `PaymentProviderStatus` component: shown when provider not configured, safe placeholder, no live API claims
- `PaymentFailureRecovery` component: retry, view orders, contact support — routed on checkout error
- Card details disclaimer and Stripe redirect flow with proper loading/error states

## Scan → Collection Handoff (Scan AI Auditor)
- `IdentifyResult` now shows explicit "Save to Collection" + "List for Sale" CTA strip above Clover panel
- Both actions prominent, not buried in GeoDexReveal

## Commerce (Commerce Auditor)
- `ExternalListingExporter` already showed safe disclaimer ("copy/download and post manually") — retained
- `CheckoutFlow` now correctly labels payment type in header

## What Was NOT Changed
- Navigation tabs: Explore | Scan | Collection | Community | Market — preserved as-is
- All domain pages: preserved (no removals)
- Clover, Rewards, Subscriptions, Land, Safety, Notifications, Provenance, Trust — all intact
- Visual style: dark crystalline premium — preserved and extended into CheckoutFlow