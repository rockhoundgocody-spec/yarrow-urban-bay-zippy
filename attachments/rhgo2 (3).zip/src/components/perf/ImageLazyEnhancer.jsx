import { useEffect } from "react";

/**
 * ImageLazyEnhancer
 *
 * Globally promotes <img> elements to native lazy loading so image-heavy pages
 * only fetch what's near the viewport. Runs once in the shared Layout and
 * covers every current and future page via a MutationObserver — no per-page
 * edits required.
 *
 * - Sets loading="lazy" + decoding="async" on <img> elements that have no
 *   explicit loading attribute (respects existing eager/lazy).
 * - Catches images added later (lazy-rendered lists, markdown, modals).
 * - Opt out for critical above-the-fold heroes: <img loading="eager"> or
 *   <img data-eager> stays eager (good for LCP).
 *
 * Renders nothing. Mount once.
 */
export default function ImageLazyEnhancer() {
  useEffect(() => {
    const enhance = (img) => {
      if (!img || img.tagName !== "IMG") return;
      // Respect any explicit loading hint (eager or lazy).
      if (img.hasAttribute("loading")) return;
      if (img.hasAttribute("data-eager")) return;
      img.setAttribute("loading", "lazy");
      if (!img.hasAttribute("decoding")) {
        img.setAttribute("decoding", "async");
      }
    };

    const enhanceWithin = (root) => {
      if (!root || !root.querySelectorAll) return;
      root.querySelectorAll("img").forEach(enhance);
    };

    // 1) Process images already in the document.
    enhanceWithin(document);

    // 2) Watch for images added later (lazy-mounted routes, infinite lists, etc.)
    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        m.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node.tagName === "IMG") enhance(node);
          else enhanceWithin(node);
        });
      }
    });

    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, []);

  return null;
}