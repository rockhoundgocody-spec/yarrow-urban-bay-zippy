import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Trophy } from "lucide-react";

const tierColors = {
  bronze: { bg: "#92400E", border: "#D97706", glow: "rgba(217,119,6,0.4)" },
  silver: { bg: "#374151", border: "#9CA3AF", glow: "rgba(156,163,175,0.4)" },
  gold: { bg: "#92400E", border: "#F59E0B", glow: "rgba(245,158,11,0.4)" },
  platinum: { bg: "#1E1B4B", border: "#A78BFA", glow: "rgba(167,139,250,0.4)" },
  legendary: { bg: "#7C2D12", border: "#F97316", glow: "rgba(249,115,22,0.4)" },
};

export default function MissionUnlockAnimation({ achievement, visible, onDismiss }) {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(onDismiss, 4000);
      return () => clearTimeout(timer);
    }
  }, [visible, onDismiss]);

  if (!achievement) return null;

  const color = tierColors[achievement.tier] || tierColors.bronze;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed top-0 left-0 right-0 z-50 flex items-center justify-center pointer-events-none p-4"
          initial={{ opacity: 0, y: -100 }}
          animate={{ opacity: 1, y: 20 }}
          exit={{ opacity: 0, y: -100 }}
          transition={{ type: "spring", stiffness: 300, damping: 30 }}
        >
          <div
            className="rounded-3xl px-8 py-6 max-w-sm w-full shadow-2xl pointer-events-auto"
            style={{
              background: color.bg,
              border: `2px solid ${color.border}`,
              boxShadow: `0 0 32px ${color.glow}, 0 8px 32px rgba(0,0,0,0.4)`,
            }}
          >
            <div className="flex items-center gap-4">
              {/* Icon/Badge */}
              <motion.div
                className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 text-4xl"
                style={{ background: "rgba(255,255,255,0.1)" }}
                animate={{ scale: [1, 1.1, 1], rotate: [0, 360, 0] }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                {achievement.icon}
              </motion.div>

              {/* Text */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <Trophy className="w-4 h-4" style={{ color: color.border }} />
                  <p className="text-xs font-bold uppercase tracking-widest" style={{ color: color.border }}>
                    Achievement Unlocked
                  </p>
                </div>
                <h3 className="text-lg font-bold text-white mb-1">{achievement.name}</h3>
                <p className="text-sm text-white/60">{achievement.message}</p>
                <div className="mt-2 flex items-center gap-2">
                  <Star className="w-4 h-4" style={{ color: "#F59E0B" }} />
                  <span className="text-sm font-bold" style={{ color: "#F59E0B" }}>
                    +{achievement.xp} XP
                  </span>
                </div>
              </div>
            </div>

            {/* Animated progress bar */}
            <motion.div
              className="mt-4 h-1 rounded-full"
              style={{ background: "rgba(255,255,255,0.2)" }}
            >
              <motion.div
                className="h-full rounded-full"
                style={{ background: color.border }}
                initial={{ width: 0 }}
                animate={{ width: "100%" }}
                transition={{ duration: 3.5, ease: "easeInOut" }}
              />
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}