import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Zap, X } from "lucide-react";
import ParticleCanvas, { useParticleEmitter } from "../gamification/ParticleCanvas";

export default function MissionBadgeUnlock({ result, missionTitle, onClose }) {
  const [show, setShow] = useState(true);
  const { canvasRef, emit } = useParticleEmitter();
  const firedRef = useRef(false);

  useEffect(() => {
    const t = setTimeout(() => { setShow(false); setTimeout(onClose, 400); }, 5000);
    return () => clearTimeout(t);
  }, []);

  // Fire confetti shortly after modal appears
  useEffect(() => {
    if (firedRef.current) return;
    firedRef.current = true;
    const t1 = setTimeout(() => emit("confetti", { x: window.innerWidth / 2, y: window.innerHeight * 0.35 }), 350);
    const t2 = setTimeout(() => emit("xp",       { x: window.innerWidth / 2, y: window.innerHeight * 0.6  }), 600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [emit]);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center px-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <ParticleCanvas canvasRef={canvasRef} style={{ zIndex: 10000 }} />
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => { setShow(false); setTimeout(onClose, 400); }} />

          <motion.div
            className="relative rounded-3xl border border-amber-500/30 p-8 text-center max-w-xs w-full"
            style={{ background: "linear-gradient(135deg, #1a0a2e, #0a0a15)", boxShadow: "0 0 80px rgba(212,175,55,0.4), inset 0 0 40px rgba(212,175,55,0.05)" }}
            initial={{ scale: 0.7, y: 40 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 20 }}
            transition={{ type: "spring", damping: 15 }}
          >
            <button onClick={() => { setShow(false); setTimeout(onClose, 400); }} className="absolute top-3 right-3 text-white/30 hover:text-white/70" aria-label="Close">
              <X className="w-4 h-4" />
            </button>

            {/* Rays */}
            <div className="absolute inset-0 overflow-hidden rounded-3xl pointer-events-none">
              {Array.from({ length: 8 }).map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute top-1/2 left-1/2 w-px bg-gradient-to-t from-amber-400/30 to-transparent"
                  style={{ height: "120%", transformOrigin: "bottom center", rotate: `${i * 45}deg`, translateX: "-50%" }}
                  animate={{ opacity: [0.2, 0.6, 0.2] }}
                  transition={{ duration: 2, delay: i * 0.1, repeat: Infinity }}
                />
              ))}
            </div>

            <p className="text-xs font-bold uppercase tracking-widest text-amber-400/60 mb-3">Mission Complete</p>

            {/* Badge icon */}
            <motion.div
              className="w-20 h-20 rounded-2xl mx-auto flex items-center justify-center text-5xl mb-4 border border-amber-500/40"
              style={{ background: "rgba(212,175,55,0.12)" }}
              animate={{ scale: [1, 1.08, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            >
              {result.badge_awarded ? "🏅" : "⚡"}
            </motion.div>

            <h2 className="text-xl font-bold text-white mb-1">{result.badge_awarded || missionTitle}</h2>
            <p className="text-sm text-white/50 mb-5 leading-relaxed">{result.verification_note}</p>

            {/* XP award */}
            <div className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
              <Zap className="w-4 h-4 text-amber-400" />
              <span className="text-lg font-bold text-amber-400">+{result.xp_awarded} XP</span>
            </div>

            {result.badge_awarded && (
              <p className="text-xs text-emerald-400 mt-3">🎖 Badge Unlocked: {result.badge_awarded}</p>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}