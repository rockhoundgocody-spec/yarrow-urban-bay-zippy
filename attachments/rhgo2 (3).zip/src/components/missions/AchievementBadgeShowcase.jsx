import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Lock, Zap } from "lucide-react";
import { FIELD_MISSIONS } from "@/services/missions/fieldMissionDefinitions";

const tierColors = {
  bronze: { text: "#D97706", bg: "rgba(217,119,6,0.1)", border: "rgba(217,119,6,0.3)" },
  silver: { text: "#9CA3AF", bg: "rgba(156,163,175,0.1)", border: "rgba(156,163,175,0.3)" },
  gold: { text: "#F59E0B", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.3)" },
  platinum: { text: "#A78BFA", bg: "rgba(167,139,250,0.1)", border: "rgba(167,139,250,0.3)" },
  legendary: { text: "#F97316", bg: "rgba(249,115,22,0.1)", border: "rgba(249,115,22,0.3)" },
};

export default function AchievementBadgeShowcase({ userEmail }) {
  const { data: userAchievements = [], isLoading } = useQuery({
    queryKey: ["user-achievements", userEmail],
    enabled: !!userEmail,
    queryFn: () =>
      base44.asServiceRole.entities.UserAchievement.filter({
        created_by: userEmail,
      }),
    staleTime: 5 * 60 * 1000,
  });

  const awardedIds = new Set(userAchievements.map((a) => a.achievement_id));
  const unlockedMissions = FIELD_MISSIONS.filter((m) => awardedIds.has(m.id));
  const lockedMissions = FIELD_MISSIONS.filter((m) => !awardedIds.has(m.id));

  if (isLoading) {
    return (
      <div className="space-y-2">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="h-12 bg-white/5 rounded-lg animate-pulse" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Unlocked Achievements */}
      {unlockedMissions.length > 0 && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.4)" }}>
            🏆 Unlocked ({unlockedMissions.length})
          </h3>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {unlockedMissions.map((mission) => {
              const color = tierColors[mission.tier];
              return (
                <motion.div
                  key={mission.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="rounded-xl p-3 text-center transition-all hover:scale-105"
                  style={{ background: color.bg, border: `1px solid ${color.border}` }}
                >
                  <div className="text-3xl mb-1">{mission.icon}</div>
                  <p className="text-xs font-bold mb-1" style={{ color: color.text }}>
                    {mission.name}
                  </p>
                  <div className="flex items-center justify-center gap-1">
                    <Zap className="w-3 h-3" style={{ color: "#F59E0B" }} />
                    <span className="text-[10px] font-bold" style={{ color: "#F59E0B" }}>
                      {mission.xp_reward}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      )}

      {/* Locked Achievements (preview) */}
      {lockedMissions.length > 0 && (
        <div>
          <h3 className="text-xs font-bold uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.25)" }}>
            🔒 Locked ({lockedMissions.length})
          </h3>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {lockedMissions.slice(0, 6).map((mission) => {
              const color = tierColors[mission.tier];
              return (
                <div
                  key={mission.id}
                  className="rounded-xl p-3 text-center opacity-50"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    border: "1px solid rgba(255,255,255,0.1)",
                  }}
                  title={`${mission.name} — ${mission.description}`}
                >
                  <div className="text-3xl mb-1 opacity-40">{mission.icon}</div>
                  <p className="text-xs font-bold mb-1 text-white/40">{mission.name}</p>
                  <div className="flex items-center justify-center gap-1">
                    <Lock className="w-3 h-3 text-white/20" />
                    <span className="text-[10px] text-white/30">{mission.xp_reward} XP</span>
                  </div>
                </div>
              );
            })}
            {lockedMissions.length > 6 && (
              <div className="rounded-xl p-3 text-center flex items-center justify-center" style={{ background: "rgba(255,255,255,0.02)" }}>
                <span className="text-xs text-white/30">+{lockedMissions.length - 6} more</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Empty state */}
      {unlockedMissions.length === 0 && lockedMissions.length === 0 && (
        <p className="text-center text-sm text-white/40 py-8">No achievements yet. Start rockhounding!</p>
      )}
    </div>
  );
}