import React, { useState, useRef, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { X, Upload, Gem, MapPin, Loader2, Camera, Zap, CheckCircle, AlertTriangle, BookOpen } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

const DIFF_COLOR = { easy: "text-emerald-400", moderate: "text-amber-400", hard: "text-orange-400", expert: "text-red-400" };
const RARITY_LABEL = { common: "Common", uncommon: "Uncommon", rare: "Rare", ultra_rare: "Ultra Rare", legendary: "Legendary" };

export default function MissionDetailModal({ mission, progress, user, onClose, onAccept, onSubmit, submitting }) {
  const [notes, setNotes] = useState(progress?.submission_notes || "");
  const [photoUrls, setPhotoUrls] = useState(progress?.evidence_photo_urls || []);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [selectedSpecimens, setSelectedSpecimens] = useState(progress?.evidence_specimen_ids || []);
  const fileRef = useRef();

  const { data: specimens = [] } = useQuery({
    queryKey: ["my-specimens-mission"],
    queryFn: () => base44.entities.Specimen.filter({ created_by: user?.email }),
    enabled: !!user?.email && (mission.mission_type === "collect_mineral" || mission.mission_type === "identify_rarity")
  });

  const relevantSpecimens = useMemo(() => {
    if (!mission.target_mineral) return specimens;
    // ⚡ Bolt: Hoisted lowercase conversion and memoized filter to prevent O(N*M) allocations
    const targetLower = mission.target_mineral.toLowerCase();
    return specimens.filter(s => s.name?.toLowerCase().includes(targetLower));
  }, [specimens, mission.target_mineral]);

  const handlePhotoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhotoUrls(prev => [...prev, file_url]);
    setUploadingPhoto(false);
  };

  const toggleSpecimen = (id) => {
    setSelectedSpecimens(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const canSubmit = photoUrls.length > 0 || selectedSpecimens.length > 0;
  const isCompleted = progress?.status === "completed";
  const isAccepted = progress && !isCompleted;

  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center justify-center bg-black/60 backdrop-blur-sm px-0 md:px-4">
      <div className="w-full max-w-lg bg-[#0f0f1e] border border-white/10 rounded-t-2xl md:rounded-2xl overflow-hidden" style={{ maxHeight: "90vh" }}>
        {/* Header */}
        <div className="px-5 pt-5 pb-4 border-b border-white/6" style={{ background: "linear-gradient(135deg, rgba(0,245,255,0.04), rgba(139,0,255,0.04))" }}>
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-[10px] font-bold uppercase tracking-widest ${DIFF_COLOR[mission.difficulty] || "text-white/40"}`}>
                  {mission.difficulty}
                </span>
                <span className="text-[10px] text-white/25">·</span>
                <span className="text-[10px] text-white/35">{RARITY_LABEL[mission.rarity_tier] || "Common"}</span>
                {isCompleted && <span className="text-[10px] text-emerald-400 font-bold">✓ Completed</span>}
              </div>
              <h2 className="text-base font-bold text-white leading-snug">{mission.title}</h2>
            </div>
            <button onClick={onClose} aria-label="Close" title="Close" className="text-white/30 hover:text-white shrink-0 mt-1"><X className="w-4 h-4" /></button>
          </div>
        </div>

        <div className="overflow-y-auto" style={{ maxHeight: "calc(90vh - 80px)" }}>
          <div className="p-5 space-y-4">
            {/* Description */}
            <p className="text-sm text-white/60 leading-relaxed">{mission.description}</p>

            {mission.flavor_text && (
              <div className="flex gap-2.5 bg-amber-500/6 border border-amber-500/15 rounded-xl px-3 py-2.5">
                <BookOpen className="w-4 h-4 text-amber-400/60 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-300/70 italic leading-relaxed">{mission.flavor_text}</p>
              </div>
            )}

            {/* Mission details */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="bg-white/[0.03] border border-white/6 rounded-xl px-3 py-2.5">
                <p className="text-[10px] text-white/30 mb-0.5">XP Reward</p>
                <p className="text-sm font-bold text-amber-400 flex items-center gap-1"><Zap className="w-3.5 h-3.5" />{mission.xp_reward}</p>
              </div>
              {mission.badge_reward_name && (
                <div className="bg-white/[0.03] border border-white/6 rounded-xl px-3 py-2.5">
                  <p className="text-[10px] text-white/30 mb-0.5">Badge</p>
                  <p className="text-sm font-bold text-white">{mission.badge_reward_icon} {mission.badge_reward_name}</p>
                </div>
              )}
              {mission.target_mineral && (
                <div className="bg-white/[0.03] border border-white/6 rounded-xl px-3 py-2.5">
                  <p className="text-[10px] text-white/30 mb-0.5">Target</p>
                  <p className="text-sm font-semibold text-cyan-400 flex items-center gap-1"><Gem className="w-3.5 h-3.5" />{mission.target_mineral}</p>
                </div>
              )}
              {mission.target_location_name && (
                <div className="bg-white/[0.03] border border-white/6 rounded-xl px-3 py-2.5">
                  <p className="text-[10px] text-white/30 mb-0.5">Location</p>
                  <p className="text-sm font-semibold text-white/70 flex items-center gap-1 truncate"><MapPin className="w-3.5 h-3.5 shrink-0" />{mission.target_location_name}</p>
                </div>
              )}
            </div>

            {mission.hint && (
              <div className="bg-purple-500/6 border border-purple-500/15 rounded-xl px-3 py-2.5">
                <p className="text-[10px] text-purple-400/60 font-bold uppercase mb-0.5">Field Hint</p>
                <p className="text-xs text-purple-300/70">{mission.hint}</p>
              </div>
            )}

            {/* Completed state */}
            {isCompleted && (
              <div className="bg-emerald-500/8 border border-emerald-500/25 rounded-xl px-4 py-3">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-semibold text-emerald-400">Mission Completed!</span>
                </div>
                {progress.verification_result && <p className="text-xs text-white/40">{progress.verification_result}</p>}
                {progress.badge_awarded && <p className="text-xs text-amber-400 mt-1">🏅 Badge earned: {progress.badge_awarded}</p>}
              </div>
            )}

            {/* Submission form (accepted missions) */}
            {isAccepted && !isCompleted && (
              <MissionSubmissionForm
                relevantSpecimens={relevantSpecimens}
                selectedSpecimens={selectedSpecimens}
                toggleSpecimen={toggleSpecimen}
                photoUrls={photoUrls}
                setPhotoUrls={setPhotoUrls}
                uploadingPhoto={uploadingPhoto}
                fileRef={fileRef}
                handlePhotoUpload={handlePhotoUpload}
                notes={notes}
                setNotes={setNotes}
                canSubmit={canSubmit}
                submitting={submitting}
                onSubmit={onSubmit}
              />
            )}

            {/* Accept button (not yet accepted) */}
            {!progress && (
              <button
                onClick={() => onAccept(mission)}
                className="w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2"
                style={{ background: "linear-gradient(135deg, #d4af37, #f59e0b)" }}
              >
                <Zap className="w-4 h-4" /> Accept Mission
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function MissionSubmissionForm({
  relevantSpecimens,
  selectedSpecimens,
  toggleSpecimen,
  photoUrls,
  setPhotoUrls,
  uploadingPhoto,
  fileRef,
  handlePhotoUpload,
  notes,
  setNotes,
  canSubmit,
  submitting,
  onSubmit
}) {
  return (
    <div className="space-y-3 pt-2 border-t border-white/5">
      <p className="text-xs font-bold text-white/50 uppercase tracking-wider">Submit Evidence</p>

      {/* Relevant specimens from collection */}
      {relevantSpecimens.length > 0 && (
        <div>
          <p className="text-[11px] text-white/35 mb-2">Link from your collection:</p>
          <div className="space-y-1.5 max-h-32 overflow-y-auto">
            {relevantSpecimens.slice(0, 10).map(spec => (
              <div
                key={spec.id}
                onClick={() => toggleSpecimen(spec.id)}
                className={`flex items-center gap-2.5 p-2 rounded-xl border cursor-pointer transition-all ${
                  selectedSpecimens.includes(spec.id)
                    ? "border-cyan-500/40 bg-cyan-500/8"
                    : "border-white/6 hover:border-white/15"
                }`}
              >
                {spec.photo_url && <img src={spec.photo_url} className="w-8 h-8 rounded-lg object-cover" />}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-white truncate">{spec.name}</p>
                  <p className="text-[10px] text-white/35 truncate">{spec.location_found || "No location"}</p>
                </div>
                {selectedSpecimens.includes(spec.id) && <CheckCircle className="w-4 h-4 text-cyan-400 shrink-0" />}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Photo upload */}
      <div>
        <p className="text-[11px] text-white/35 mb-2">Upload field photos:</p>
        <div className="flex flex-wrap gap-2">
          {photoUrls.map((url, i) => (
            <div key={i} className="relative">
              <img src={url} className="w-16 h-16 rounded-xl object-cover border border-white/10" />
              <button
                aria-label="Remove photo"
                title="Remove photo"
                onClick={() => setPhotoUrls(prev => prev.filter((_, j) => j !== i))}
                className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center"
              >×</button>
            </div>
          ))}
          <button
            aria-label="Upload photo"
            title="Upload photo"
            onClick={() => fileRef.current?.click()}
            disabled={uploadingPhoto}
            className="w-16 h-16 rounded-xl border border-dashed border-white/15 flex items-center justify-center text-white/30 hover:border-cyan-500/40 hover:text-cyan-400 transition-all"
          >
            {uploadingPhoto ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
          </button>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoUpload} />
        </div>
      </div>

      {/* Notes */}
      <textarea
        value={notes}
        onChange={e => setNotes(e.target.value)}
        placeholder="Describe your find, conditions, coordinates..."
        rows={3}
        className="w-full bg-white/5 border border-white/8 rounded-xl text-sm text-white placeholder:text-white/20 px-3 py-2.5 focus:outline-none focus:border-cyan-500/30 resize-none"
      />

      {!canSubmit && (
        <div className="flex items-center gap-1.5 text-xs text-orange-400/60">
          <AlertTriangle className="w-3.5 h-3.5" />
          Upload at least one photo or link a specimen to submit
        </div>
      )}

      <button
        onClick={() => onSubmit({ photoUrls, specimenIds: selectedSpecimens, notes })}
        disabled={!canSubmit || submitting}
        className="w-full py-3 rounded-xl font-semibold text-sm transition-all disabled:opacity-40 flex items-center justify-center gap-2"
        style={{ background: "linear-gradient(135deg, #7c3aed, #a855f7)" }}
      >
        {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
        Submit for Verification
      </button>
    </div>
  );
}
