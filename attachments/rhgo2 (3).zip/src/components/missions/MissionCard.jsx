import React from "react";
import { MapPin, Gem, Camera, Mountain, Zap, Star, Clock, Users, ChevronRight, Check } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const DIFFICULTY_CONFIG = {
  easy:     { label: "Easy",    color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
  moderate: { label: "Moderate",color: "text-amber-400",   bg: "bg-amber-500/10 border-amber-500/20" },
  hard:     { label: "Hard",    color: "text-orange-400",  bg: "bg-orange-500/10 border-orange-500/20" },
  expert:   { label: "Expert",  color: "text-red-400",     bg: "bg-red-500/10 border-red-500/20" },
};

const RARITY_CONFIG = {
  common:     { label: "Common",     glow: "rgba(148,163,184,0.3)" },
  uncommon:   { label: "Uncommon",   glow: "rgba(74,222,128,0.3)" },
  rare:       { label: "Rare",       glow: "rgba(96,165,250,0.3)" },
  ultra_rare: { label: "Ultra Rare", glow: "rgba(167,139,250,0.4)" },
  legendary:  { label: "Legendary",  glow: "rgba(251,191,36,0.5)" },
};

const TYPE_ICON = {
  collect_mineral:   Gem,
  visit_location:    MapPin,
  photo_find:        Camera,
  identify_rarity:   Star,
  terrain_challenge: Mountain,
  multi_find:        Zap,
};

export default function MissionCard({ mission, progress, onClick }) {
  const diff = DIFFICULTY_CONFIG[mission.difficulty] || DIFFICULTY_CONFIG.moderate;
  const rarity = RARITY_CONFIG[mission.rarity_tier] || RARITY_CONFIG.common;
  const Icon = TYPE_ICON[mission.mission_type] || Gem;
  const isCompleted = progress?.status === "completed";
  const isAccepted = progress && progress.status !== "completed";
  const isExpired = mission.expires_at && new Date(mission.expires_at) < new Date();

  return (
    <div
      onClick={() => !isExpired && onClick(mission, progress)}
      className={`relative rounded-2xl border p-4 cursor-pointer transition-all group ${
        isCompleted
          ? "border-emerald-500/30 bg-emerald-500/5 opacity-70"
          : isExpired
          ? "border-white/5 bg-white/[0.01] opacity-40 cursor-not-allowed"
          : "border-white/8 bg-[#13131f] hover:border-white/20"
      }`}
      style={{ boxShadow: isCompleted ? "none" : `0 0 24px ${rarity.glow}` }}
    >
      {/* Featured banner */}
      {mission.is_featured && !isCompleted && (
        <div className="absolute -top-px left-4 right-4 h-px bg-gradient-to-r from-transparent via-amber-400/60 to-transparent" />
      )}

      <div className="flex items-start gap-3">
        {/* Icon */}
        <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${diff.bg}`}>
          <Icon className={`w-5 h-5 ${diff.color}`} />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <h3 className={`text-sm font-bold leading-tight ${isCompleted ? "text-white/50" : "text-white"}`}>
              {mission.title}
            </h3>
            {isCompleted && <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />}
            {!isCompleted && !isExpired && (
              <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-all shrink-0 mt-0.5" />
            )}
          </div>

          <p className="text-xs text-white/40 mt-0.5 line-clamp-2">{mission.description}</p>

          {/* Tags row */}
          <div className="flex flex-wrap items-center gap-1.5 mt-2.5">
            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${diff.bg} ${diff.color}`}>
              {diff.label}
            </span>
            <span className="text-[10px] text-white/35 px-2 py-0.5 rounded-full bg-white/5 border border-white/8">
              {rarity.label}
            </span>
            {mission.target_mineral && (
              <span className="text-[10px] text-cyan-400/70 px-2 py-0.5 rounded-full bg-cyan-500/8 border border-cyan-500/15">
                {mission.target_mineral}
              </span>
            )}
            {mission.target_location_name && (
              <span className="text-[10px] text-white/30 flex items-center gap-0.5">
                <MapPin className="w-2.5 h-2.5" />{mission.target_location_name}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
        <div className="flex items-center gap-3">
          {/* XP */}
          <div className="flex items-center gap-1">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-xs font-bold text-amber-400">{mission.xp_reward} XP</span>
          </div>
          {/* Badge reward */}
          {mission.badge_reward_name && (
            <div className="flex items-center gap-1">
              <span className="text-xs">{mission.badge_reward_icon || "🏅"}</span>
              <span className="text-[11px] text-white/40">{mission.badge_reward_name}</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 text-[10px] text-white/25">
          {mission.completion_count > 0 && (
            <span className="flex items-center gap-0.5">
              <Users className="w-2.5 h-2.5" />{mission.completion_count}
            </span>
          )}
          {mission.expires_at && !isExpired && (
            <span className="flex items-center gap-0.5 text-orange-400/60">
              <Clock className="w-2.5 h-2.5" />
              {formatDistanceToNow(new Date(mission.expires_at), { addSuffix: true })}
            </span>
          )}
          {isAccepted && (
            <span className="text-cyan-400 font-semibold">In Progress</span>
          )}
        </div>
      </div>

      {/* Progress bar for accepted missions */}
      {isAccepted && mission.target_count > 1 && (
        <div className="mt-2 w-full h-1 rounded-full bg-white/5">
          <div
            className="h-1 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 transition-all"
            style={{ width: `${((progress.current_count || 0) / mission.target_count) * 100}%` }}
          />
        </div>
      )}
    </div>
  );
}