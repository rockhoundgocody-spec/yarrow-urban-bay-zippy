import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Printer, X } from "lucide-react";
import { escapeHtml } from "@/utils";

function CheckItem({ label, checked = false }) {
  return (
    <div className="flex items-center gap-2 py-0.5">
      <div className="w-4 h-4 border border-gray-400 rounded shrink-0 flex items-center justify-center">
        {checked && <span className="text-[10px]">✓</span>}
      </div>
      <span className="text-sm text-gray-800">{label}</span>
    </div>
  );
}

function Section({ title, emoji, children }) {
  return (
    <div className="mb-5 break-inside-avoid">
      <h3 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-2">{emoji} {title}</h3>
      <div className="grid grid-cols-2 gap-x-6">{children}</div>
    </div>
  );
}

export default function PrintableChecklist({ trip, locations = [], onClose }) {
  const printRef = useRef(null);

  const tripLocations = locations.filter(l => trip.locations?.includes(l.id));
  const allMinerals = new Set(tripLocations.flatMap(l => l.minerals_found || []));
  const allHazards = new Set(tripLocations.flatMap(l => l.hazards || []));
  const allManagers = new Set(tripLocations.map(l => l.land_manager).filter(Boolean));
  const needs4x4 = tripLocations.some(l => l.vehicle_requirement === "4x4 Required");
  const needsHC = tripLocations.some(l => l.vehicle_requirement === "High Clearance");
  const needsGoldPan = [...allMinerals].some(m => /gold|placer/i.test(m));
  const needsPryBar = [...allMinerals].some(m => /crystal|geode/i.test(m));

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const win = window.open("", "_blank");
    win.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>Field Pack — ${escapeHtml(trip.name)}</title>
        <style>
          * { box-sizing: border-box; margin: 0; padding: 0; }
          body { font-family: 'Georgia', serif; font-size: 12px; color: #1a1a1a; padding: 20px 32px; }
          h1 { font-size: 18px; font-weight: 800; color: #0f766e; margin-bottom: 4px; }
          h2 { font-size: 13px; font-weight: 700; color: #374151; margin: 14px 0 6px; border-bottom: 1px solid #d1d5db; padding-bottom: 4px; }
          h3 { font-size: 12px; font-weight: 700; color: #111827; border-bottom: 1px solid #e5e7eb; padding-bottom: 3px; margin-bottom: 6px; }
          .meta { color: #6b7280; font-size: 11px; margin-bottom: 12px; }
          .grid2 { display: grid; grid-template-columns: 1fr 1fr; column-gap: 24px; }
          .check-item { display: flex; align-items: center; gap: 6px; padding: 2px 0; font-size: 12px; }
          .check-box { width: 13px; height: 13px; border: 1.5px solid #6b7280; border-radius: 2px; display: inline-block; flex-shrink: 0; }
          .section { margin-bottom: 14px; break-inside: avoid; }
          .stop-card { border: 1px solid #e5e7eb; border-radius: 6px; padding: 8px 10px; margin-bottom: 6px; break-inside: avoid; }
          .stop-name { font-size: 12px; font-weight: 700; color: #111827; }
          .stop-meta { font-size: 10px; color: #6b7280; margin-top: 2px; }
          .badge { display: inline-block; font-size: 9px; padding: 1px 5px; border-radius: 10px; border: 1px solid; margin-right: 3px; margin-top: 3px; }
          .badge-green { color: #166534; border-color: #86efac; background: #f0fdf4; }
          .badge-amber { color: #92400e; border-color: #fcd34d; background: #fffbeb; }
          .badge-red { color: #991b1b; border-color: #fca5a5; background: #fef2f2; }
          .badge-blue { color: #1e40af; border-color: #93c5fd; background: #eff6ff; }
          .hazard { color: #dc2626; font-size: 11px; padding: 4px 8px; background: #fef2f2; border-radius: 4px; margin-bottom: 4px; }
          .legal { font-size: 11px; color: #374151; padding: 4px 8px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 4px; margin-bottom: 4px; }
          .footer { text-align: center; font-size: 10px; color: #9ca3af; margin-top: 24px; border-top: 1px solid #e5e7eb; padding-top: 8px; }
          @media print {
            body { padding: 12px 20px; }
            @page { margin: 0.5in; }
          }
        </style>
      </head>
      <body>${printContents}</body>
      </html>
    `);
    win.document.close();
    win.focus();
    win.print();
    win.close();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-start justify-center overflow-auto py-6 px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl">
        {/* Toolbar */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200 sticky top-0 bg-white rounded-t-2xl z-10">
          <h2 className="font-bold text-gray-900 text-sm">Field Pack Checklist Preview</h2>
          <div className="flex items-center gap-2">
            <Button onClick={handlePrint} className="bg-teal-600 hover:bg-teal-700 text-white gap-2 h-8 text-xs">
              <Printer className="w-3.5 h-3.5" /> Print / Save PDF
            </Button>
            <button onClick={onClose} className="p-1 text-gray-400 hover:text-gray-700" aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Preview */}
        <div ref={printRef} className="p-8 text-gray-900" style={{ fontFamily: "Georgia, serif" }}>
          <h1 className="text-xl font-extrabold text-teal-700 mb-1">🎒 Field Pack — {trip.name}</h1>
          <div className="text-xs text-gray-500 mb-4 space-y-0.5">
            <div>Starting from: <strong className="text-gray-700">{trip.start_location}</strong></div>
            <div>Duration: <strong className="text-gray-700">{trip.duration_days} days</strong>
              {trip.start_date && <> · Departs: <strong className="text-gray-700">{trip.start_date}</strong></>}
            </div>
            <div>~{Math.round(trip.estimated_distance || 0)} miles · ~{Math.round(trip.estimated_time || 0)} hours driving</div>
            <div className="text-gray-400 mt-1">Generated by RockHound-Go · {new Date().toLocaleDateString()}</div>
          </div>

          {/* Stops */}
          {tripLocations.length > 0 && (
            <div className="mb-5">
              <h2 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-3">📍 Site Stops ({tripLocations.length})</h2>
              {tripLocations.map((loc, i) => (
                <div key={loc.id} className="border border-gray-200 rounded-lg p-2.5 mb-2">
                  <div className="font-bold text-sm text-gray-900">{i + 1}. {loc.name}</div>
                  <div className="text-xs text-gray-500 mt-0.5">
                    {loc.state}{loc.county ? `, ${loc.county}` : ""} ·
                    GPS: {loc.latitude?.toFixed(5)}, {loc.longitude?.toFixed(5)}
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {loc.difficulty && <span className="text-[10px] px-1.5 py-0.5 rounded border border-gray-300 text-gray-600 bg-gray-50">{loc.difficulty}</span>}
                    {loc.land_manager && <span className="text-[10px] px-1.5 py-0.5 rounded border border-blue-200 text-blue-700 bg-blue-50">{loc.land_manager}</span>}
                    {loc.access_type && <span className="text-[10px] px-1.5 py-0.5 rounded border border-green-200 text-green-700 bg-green-50">{loc.access_type}</span>}
                    {loc.fee_required && <span className="text-[10px] px-1.5 py-0.5 rounded border border-amber-200 text-amber-700 bg-amber-50">Fee: {loc.fee_amount || "Yes"}</span>}
                    {loc.permit_required && <span className="text-[10px] px-1.5 py-0.5 rounded border border-red-200 text-red-700 bg-red-50">Permit Required</span>}
                  </div>
                  {loc.minerals_found?.length > 0 && (
                    <div className="text-[11px] text-gray-600 mt-1">💎 {loc.minerals_found.slice(0, 6).join(", ")}</div>
                  )}
                  {loc.hazards?.length > 0 && (
                    <div className="text-[11px] text-red-600 mt-0.5">⚠️ {loc.hazards.join(", ")}</div>
                  )}
                  {loc.access_info && (
                    <div className="text-[11px] text-gray-500 mt-0.5 italic">{loc.access_info}</div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Gear Checklist */}
          <div className="mb-5">
            <h2 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-3">🛠️ Gear Checklist</h2>
            <div className="grid grid-cols-2 gap-x-8">
              <div>
                <h3 className="text-xs font-bold text-gray-700 mb-2 uppercase tracking-wide">Rockhounding Tools</h3>
                {[
                  "Rock hammer (2–3 lb)", "Cold chisels (flat + point)", "Safety goggles",
                  "Collection bags + newspaper wrap", "Labels + permanent marker",
                  "Field guide / mineral ID chart", "Hand lens (10x loupe)", "Streak plate",
                  ...(needsGoldPan ? ["Gold pan + classifier screen"] : []),
                  ...(needsPryBar ? ["Pry bar for geodes"] : []),
                ].map(item => (
                  <div key={item} className="flex items-center gap-2 py-0.5">
                    <div style={{ width: 13, height: 13, border: "1.5px solid #9ca3af", borderRadius: 2, flexShrink: 0 }} />
                    <span className="text-xs text-gray-800">{item}</span>
                  </div>
                ))}
              </div>
              <div>
                <h3 className="text-xs font-bold text-gray-700 mb-2 uppercase tracking-wide">Safety & Navigation</h3>
                {[
                  "First aid kit (fully stocked)", "Sunscreen SPF 50+", "Hat + sunglasses",
                  `Water (1 gal/person/day × ${trip.duration_days} days)`, "High-calorie snacks / trail meals",
                  "Headlamp + spare batteries", "Whistle + emergency blanket",
                  "Phone charger / power bank", "Offline maps downloaded",
                  "GPS coordinates printed (backup)", "Notify someone of itinerary",
                ].map(item => (
                  <div key={item} className="flex items-center gap-2 py-0.5">
                    <div style={{ width: 13, height: 13, border: "1.5px solid #9ca3af", borderRadius: 2, flexShrink: 0 }} />
                    <span className="text-xs text-gray-800">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-x-8 mt-3">
              <div>
                <h3 className="text-xs font-bold text-gray-700 mb-2 uppercase tracking-wide">Vehicle</h3>
                {[
                  ...(needs4x4 ? ["⚠️ 4x4 REQUIRED for some stops"] : needsHC ? ["High clearance vehicle needed"] : []),
                  "Full tank of gas before departure", "Spare tire + jack + lug wrench",
                  "Tow strap", "Tire pressure gauge", "Jumper cables / jump starter",
                ].map(item => (
                  <div key={item} className="flex items-center gap-2 py-0.5">
                    <div style={{ width: 13, height: 13, border: "1.5px solid #9ca3af", borderRadius: 2, flexShrink: 0 }} />
                    <span className="text-xs text-gray-800">{item}</span>
                  </div>
                ))}
              </div>
              <div>
                <h3 className="text-xs font-bold text-gray-700 mb-2 uppercase tracking-wide">Personal Gear</h3>
                {[
                  "Sturdy boots (ankle support)", "Gloves (leather work)", "Kneepads",
                  "Weather-layered clothing", "Rain jacket / poncho",
                  "Camera or dedicated photo lens",
                  `Accommodation confirmed (${trip.duration_days - 1} nights)`,
                ].map(item => (
                  <div key={item} className="flex items-center gap-2 py-0.5">
                    <div style={{ width: 13, height: 13, border: "1.5px solid #9ca3af", borderRadius: 2, flexShrink: 0 }} />
                    <span className="text-xs text-gray-800">{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Safety hazards */}
          {allHazards.size > 0 && (
            <div className="mb-5">
              <h2 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-2">⚠️ Known Hazards at Your Stops</h2>
              <div className="grid grid-cols-2 gap-2">
                {[...allHazards].map(h => (
                  <div key={h} className="text-xs text-red-700 bg-red-50 border border-red-200 rounded px-2 py-1">⚠️ {h}</div>
                ))}
              </div>
              <div className="mt-2 text-xs text-gray-500">
                Always check local conditions. Flash flood risk, extreme heat, and unstable terrain are common in rockhounding areas.
              </div>
            </div>
          )}

          {/* Legality */}
          {allManagers.size > 0 && (
            <div className="mb-5">
              <h2 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-2">⚖️ Collection Rules by Land Manager</h2>
              <div className="space-y-1.5">
                {allManagers.has("BLM") && <div className="text-xs text-gray-700 bg-blue-50 border border-blue-200 rounded px-2 py-1.5"><strong>BLM:</strong> 25 lbs/day, 250 lbs/year casual collection. No commercial use.</div>}
                {allManagers.has("USFS") && <div className="text-xs text-gray-700 bg-green-50 border border-green-200 rounded px-2 py-1.5"><strong>USFS:</strong> Casual collection usually allowed. Check local ranger district for limits.</div>}
                {allManagers.has("NPS") && <div className="text-xs text-red-700 bg-red-50 border border-red-200 rounded px-2 py-1.5"><strong>⛔ NPS:</strong> NO collecting in National Parks. Violations result in fines.</div>}
                {allManagers.has("State Park") && <div className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1.5"><strong>State Parks:</strong> Rules vary by state. Verify before collecting.</div>}
                {allManagers.has("Private") && <div className="text-xs text-gray-700 bg-gray-50 border border-gray-200 rounded px-2 py-1.5"><strong>Private Land:</strong> Written permission required from landowner.</div>}
              </div>
            </div>
          )}

          {/* GPS Reference */}
          {tripLocations.length > 0 && (
            <div className="mb-4">
              <h2 className="text-sm font-bold text-gray-900 border-b border-gray-300 pb-1 mb-2">🧭 GPS Coordinates (Offline Reference)</h2>
              <div className="grid grid-cols-2 gap-x-6">
                {tripLocations.map((loc, i) => (
                  <div key={loc.id} className="text-[11px] text-gray-700 py-0.5">
                    <strong>{i + 1}.</strong> {loc.name} — <span className="font-mono text-gray-500">{loc.latitude?.toFixed(5)}, {loc.longitude?.toFixed(5)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="text-center text-xs text-gray-400 mt-6 pt-4 border-t border-gray-200">
            Generated by RockHound-Go · {new Date().toLocaleDateString()} · Always verify access and conditions before your trip.
          </div>
        </div>
      </div>
    </div>
  );
}