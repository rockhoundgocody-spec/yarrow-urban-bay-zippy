import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  MapPin, Clock, Car, ChevronDown, ChevronUp, Plus, Trash2, Navigation,
  Gem, DollarSign, Leaf, Mountain, ExternalLink, CheckCircle2, AlertTriangle
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

// Haversine distance in miles
function distanceMiles(a, b) {
  if (!a?.latitude || !b?.latitude) return null;
  const R = 3958.8;
  const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
  const dLng = ((b.longitude - a.longitude) * Math.PI) / 180;
  const aa = Math.sin(dLat / 2) ** 2 + Math.cos(a.latitude * Math.PI / 180) * Math.cos(b.latitude * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa)) * 1.3);
}

function driveTime(miles) {
  if (!miles) return null;
  const hrs = miles / 45;
  if (hrs < 1) return `${Math.round(hrs * 60)} min`;
  return `${Math.floor(hrs)}h ${Math.round((hrs % 1) * 60)}m`;
}

function difficultyColor(d) {
  if (d === "easy") return "bg-green-500/10 text-green-400 border-green-500/20";
  if (d === "moderate") return "bg-amber-500/10 text-amber-400 border-amber-500/20";
  if (d === "difficult") return "bg-orange-500/10 text-orange-400 border-orange-500/20";
  if (d === "expert") return "bg-red-500/10 text-red-400 border-red-500/20";
  return "bg-white/5 text-white/40 border-white/10";
}

function StopCard({ stop, index, _dayNum, onRemove, nextStop }) {
  const [expanded, setExpanded] = useState(false);
  const dist = nextStop ? distanceMiles(stop, nextStop) : null;
  const travel = dist ? driveTime(dist) : null;

  return (
    <div>
      <Card className="bg-[#1a1a2a] border-white/8">
        <div className="p-3.5">
          <div className="flex items-start gap-3">
            <div className="w-7 h-7 rounded-full bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-xs font-bold text-teal-400 shrink-0 mt-0.5">
              {index + 1}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white/90 truncate">{stop.name}</p>
                  <p className="text-xs text-white/40 mt-0.5">{stop.state}{stop.county ? `, ${stop.county}` : ""}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => setExpanded(e => !e)}
                    className="p-1 text-white/30 hover:text-white/60 transition-colors"
                  >
                    {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => onRemove(stop.id)}
                    className="p-1 text-white/20 hover:text-red-400 transition-colors"
                   aria-label="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-1.5 mt-2">
                {stop.difficulty && (
                  <Badge className={`text-[10px] ${difficultyColor(stop.difficulty)}`}>
                    {stop.difficulty}
                  </Badge>
                )}
                {stop.land_manager && (
                  <Badge className="text-[10px] bg-blue-500/10 text-blue-300 border-blue-500/20">
                    {stop.land_manager}
                  </Badge>
                )}
                {stop.fee_required && (
                  <Badge className="text-[10px] bg-amber-500/10 text-amber-400 border-amber-500/20">
                    <DollarSign className="w-2.5 h-2.5 mr-0.5" />Fee
                  </Badge>
                )}
                {stop.permit_required && (
                  <Badge className="text-[10px] bg-red-500/10 text-red-400 border-red-500/20">
                    Permit
                  </Badge>
                )}
              </div>

              {stop.minerals_found?.length > 0 && (
                <div className="flex items-center gap-1 mt-2">
                  <Gem className="w-3 h-3 text-purple-400 shrink-0" />
                  <p className="text-[11px] text-purple-300/70 truncate">
                    {stop.minerals_found.slice(0, 4).join(", ")}
                    {stop.minerals_found.length > 4 && ` +${stop.minerals_found.length - 4}`}
                  </p>
                </div>
              )}
            </div>
          </div>

          {expanded && (
            <div className="mt-3 pt-3 border-t border-white/5 space-y-2 ml-10">
              {stop.access_info && (
                <p className="text-xs text-white/50 leading-relaxed">{stop.access_info}</p>
              )}
              <div className="grid grid-cols-2 gap-2 text-xs">
                {stop.latitude && (
                  <div className="text-white/35">
                    <MapPin className="w-3 h-3 inline mr-1 text-teal-400" />
                    {stop.latitude?.toFixed(5)}, {stop.longitude?.toFixed(5)}
                  </div>
                )}
                {stop.vehicle_requirement && (
                  <div className="text-white/35">
                    <Car className="w-3 h-3 inline mr-1 text-cyan-400" />
                    {stop.vehicle_requirement}
                  </div>
                )}
                {stop.best_season && (
                  <div className="text-white/35">
                    <Leaf className="w-3 h-3 inline mr-1 text-green-400" />
                    Best: {stop.best_season}
                  </div>
                )}
              </div>
              {stop.hazards?.length > 0 && (
                <div className="flex items-start gap-1.5">
                  <AlertTriangle className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-[11px] text-amber-400/70">{stop.hazards.join(", ")}</p>
                </div>
              )}
              <a
                href={`https://maps.google.com/?q=${stop.latitude},${stop.longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-[11px] text-teal-400 hover:text-teal-300 transition-colors"
              >
                <Navigation className="w-3 h-3" /> Open in Google Maps
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          )}
        </div>
      </Card>

      {/* Travel connector */}
      {dist && (
        <div className="flex items-center gap-2 py-1.5 pl-9 text-xs text-white/30">
          <div className="w-px h-4 bg-white/10 ml-2.5 mr-1" />
          <Car className="w-3 h-3 text-white/20" />
          <span>{dist} mi · {travel}</span>
        </div>
      )}
    </div>
  );
}

function AddStopDialog({ open, onClose, allLocations, existingIds, onAdd }) {
  const [search, setSearch] = useState("");

  // ⚡ Bolt: Pre-calculate searchable string cache to avoid O(N*M) inline string allocations on every keystroke
  const optimizedLocations = useMemo(() => {
    return allLocations.map(l => ({
      item: l,
      searchStr: [
        l.name,
        l.state,
        ...(l.minerals_found || [])
      ].filter(Boolean).join("|").toLowerCase()
    }));
  }, [allLocations]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return optimizedLocations
      .filter(wrapper => !existingIds.has(wrapper.item.id))
      .filter(wrapper => !q || wrapper.searchStr.includes(q))
      .map(wrapper => wrapper.item)
      .slice(0, 50);
  }, [optimizedLocations, existingIds, search]);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-lg max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-teal-400" /> Add Site Stop
          </DialogTitle>
        </DialogHeader>
        <div className="relative mb-3">
          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input
            placeholder="Search by name, state, or mineral..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 text-white text-sm"
          />
        </div>
        <ScrollArea className="flex-1">
          <div className="space-y-1.5 pr-1">
            {filtered.map(loc => (
              <button
                key={loc.id}
                onClick={() => { onAdd(loc); onClose(); setSearch(""); }}
                className="w-full text-left p-3 rounded-xl bg-white/3 border border-white/5 hover:bg-teal-500/8 hover:border-teal-500/20 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-white/85 truncate">{loc.name}</p>
                    <p className="text-xs text-white/40 mt-0.5">{loc.state}</p>
                    {loc.minerals_found?.length > 0 && (
                      <p className="text-[11px] text-purple-300/60 mt-1 truncate">
                        💎 {loc.minerals_found.slice(0, 3).join(", ")}
                      </p>
                    )}
                  </div>
                  <Badge className={`text-[10px] shrink-0 ${difficultyColor(loc.difficulty)}`}>
                    {loc.difficulty || "?"}
                  </Badge>
                </div>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="text-center text-white/30 text-sm py-8">No sites found.</p>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

export default function TripStopsManager({ trip, allLocations, onTripUpdated }) {
  const [dayStops, setDayStops] = useState(() => {
    // Distribute stored location IDs across days
    const locs = (trip.locations || [])
      .map(id => allLocations.find(l => l.id === id))
      .filter(Boolean);
    const days = {};
    locs.forEach((loc, i) => {
      const day = Math.floor(i / Math.max(1, Math.ceil(locs.length / trip.duration_days))) + 1;
      const d = Math.min(day, trip.duration_days);
      if (!days[d]) days[d] = [];
      days[d].push(loc);
    });
    // Ensure all days exist
    for (let d = 1; d <= trip.duration_days; d++) {
      if (!days[d]) days[d] = [];
    }
    return days;
  });
  const [addingToDay, setAddingToDay] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const allStopIds = useMemo(() => {
    const ids = new Set();
    Object.values(dayStops).forEach(stops => stops.forEach(s => ids.add(s.id)));
    return ids;
  }, [dayStops]);

  const handleRemove = (day, stopId) => {
    setDayStops(prev => ({ ...prev, [day]: prev[day].filter(s => s.id !== stopId) }));
  };

  const handleAdd = (day, loc) => {
    setDayStops(prev => ({ ...prev, [day]: [...(prev[day] || []), loc] }));
  };

  const totalStats = useMemo(() => {
    const allStops = Object.values(dayStops).flat();
    let totalDist = 0;
    for (let i = 1; i < allStops.length; i++) {
      totalDist += distanceMiles(allStops[i - 1], allStops[i]) || 0;
    }
    return {
      stops: allStops.length,
      distance: totalDist,
      driveTime: driveTime(totalDist),
    };
  }, [dayStops]);

  const handleSave = async () => {
    setSaving(true);
    const orderedIds = Object.keys(dayStops)
      .sort((a, b) => Number(a) - Number(b))
      .flatMap(d => dayStops[d].map(s => s.id));
    await base44.entities.TripPlan.update(trip.id, {
      locations: orderedIds,
      estimated_distance: totalStats.distance,
      estimated_time: Math.round(totalStats.distance / 45 * 10) / 10,
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    onTripUpdated?.();
  };

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="flex items-center gap-4 p-3 rounded-xl bg-teal-500/5 border border-teal-500/15 text-xs text-white/50 flex-wrap">
        <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-teal-400" /> {totalStats.stops} stops</span>
        <span className="flex items-center gap-1"><Car className="w-3 h-3 text-cyan-400" /> ~{totalStats.distance} mi</span>
        <span className="flex items-center gap-1"><Clock className="w-3 h-3 text-white/30" /> ~{totalStats.driveTime || "—"} driving</span>
        <div className="ml-auto">
          <Button
            size="sm"
            onClick={handleSave}
            disabled={saving}
            className="bg-teal-500/20 text-teal-300 border border-teal-500/30 hover:bg-teal-500/30 text-xs h-7"
          >
            {saving ? "Saving..." : saved ? <><CheckCircle2 className="w-3 h-3 mr-1" />Saved</> : "Save Changes"}
          </Button>
        </div>
      </div>

      {/* Day cards */}
      {Array.from({ length: trip.duration_days }, (_, i) => i + 1).map(day => (
        <Card key={day} className="bg-[#14141e] border-white/5">
          <div className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-teal-500/30 to-cyan-600/30 border border-teal-500/20 flex items-center justify-center">
                  <Mountain className="w-4 h-4 text-teal-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white/90">Day {day}</p>
                  {trip.start_date && (
                    <p className="text-[11px] text-white/30">
                      {new Date(new Date(trip.start_date).getTime() + (day - 1) * 86400000).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" })}
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => setAddingToDay(day)}
                className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300 transition-colors px-2 py-1 rounded-lg border border-teal-500/20 hover:bg-teal-500/10"
              >
                <Plus className="w-3 h-3" /> Add Stop
              </button>
            </div>

            {dayStops[day]?.length === 0 ? (
              <div className="py-4 text-center border border-dashed border-white/8 rounded-xl">
                <p className="text-xs text-white/25">No stops yet. Click "Add Stop" to add a site.</p>
              </div>
            ) : (
              <div className="space-y-1">
                {dayStops[day].map((stop, idx) => (
                  <StopCard
                    key={stop.id}
                    stop={stop}
                    index={idx}
                    _dayNum={day}
                    onRemove={(id) => handleRemove(day, id)}
                    nextStop={dayStops[day][idx + 1] || null}
                  />
                ))}
              </div>
            )}
          </div>
        </Card>
      ))}

      <AddStopDialog
        open={addingToDay !== null}
        onClose={() => setAddingToDay(null)}
        allLocations={allLocations}
        existingIds={allStopIds}
        onAdd={(loc) => handleAdd(addingToDay, loc)}
      />
    </div>
  );
}