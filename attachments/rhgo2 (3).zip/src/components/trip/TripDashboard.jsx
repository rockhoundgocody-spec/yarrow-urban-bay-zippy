/**
 * TripDashboard — Summary analytics for past field trips
 * Shows: total trips, total finds, top minerals, best session, site heatmap summary.
 * Pulls from FieldSession + SpecimenEvent entities.
 */

import React, { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Mountain, Gem, MapPin, Trophy, TrendingUp, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

function StatCard({ icon: Icon, label, value, color = "#7DF9FF" }) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      className="rounded-2xl border p-4"
      style={{
        background: "linear-gradient(145deg, rgba(10,15,20,0.85) 0%, rgba(14,20,27,0.80) 100%)",
        border: "1px solid rgba(255,255,255,0.08)",
        boxShadow: "0 4px 20px rgba(0,0,0,0.5)",
      }}
    >
      <div className="flex items-center gap-2 mb-2">
        <Icon className="h-4 w-4" style={{ color }} />
        <span className="text-[10px] uppercase tracking-[0.18em] text-white/35">{label}</span>
      </div>
      <div className="text-2xl font-bold" style={{ color }}>{value}</div>
    </motion.div>
  );
}

export default function TripDashboard() {
  const [sessions, setSessions] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.FieldSession.filter({ status: "completed" }, "-end_time", 50),
      base44.entities.SpecimenEvent.filter({}, "-timestamp", 200),
    ]).then(([s, e]) => {
      setSessions(s);
      setEvents(e);
    }).finally(() => setLoading(false));
  }, []);

  // ⚡ Bolt: Use a single O(N) pass for derived stats instead of multiple .filter, .map, .reduce
  const { totalFinds, totalSites, bestSession, chartData } = useMemo(() => {
    let finds = 0;
    const mCount = {};
    for (let i = 0; i < events.length; i++) {
      const e = events[i];
      if (e.event_type === "collect") finds++;
      if (e.label) mCount[e.label] = (mCount[e.label] || 0) + 1;
    }

    const siteSet = new Set();
    let best = null;
    for (let i = 0; i < sessions.length; i++) {
      const s = sessions[i];
      if (s.locality_cluster) siteSet.add(s.locality_cluster);
      if (!best || (s.success_score || 0) > (best.success_score || 0)) {
        best = s;
      }
    }

    const data = Object.entries(mCount)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 8)
      .map(([name, count]) => ({ name: name.slice(0, 12), count }));

    return { totalFinds: finds, totalSites: siteSet.size, bestSession: best, chartData: data };
  }, [events, sessions]);

  // Session yield trend
  const yieldData = useMemo(() => sessions.slice(-12).map((s, i) => ({
    name: `S${i + 1}`,
    score: s.success_score || 0,
  })), [sessions]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-300/40" />
      </div>
    );
  }

  const CHART_COLORS = ["#7DF9FF", "#9B5CFF", "#00FFC6", "#FFC857", "#FF6A3D", "#7DF9FF", "#9B5CFF", "#00FFC6"];

  return (
    <div className="space-y-5 p-4">
      {/* Summary stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatCard icon={Mountain} label="Trips" value={sessions.length} color="#7DF9FF" />
        <StatCard icon={Gem} label="Finds" value={totalFinds} color="#00FFC6" />
        <StatCard icon={MapPin} label="Sites" value={totalSites} color="#9B5CFF" />
        <StatCard
          icon={Trophy}
          label="Best Score"
          value={bestSession ? `${Math.round(bestSession.success_score || 0)}` : "—"}
          color="#FFC857"
        />
      </div>

      {/* Top minerals chart */}
      {chartData.length > 0 && (
        <div
          className="rounded-2xl border p-4"
          style={{
            background: "linear-gradient(145deg, rgba(10,15,20,0.85) 0%, rgba(14,20,27,0.80) 100%)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div className="mb-3 flex items-center gap-2">
            <Gem className="h-4 w-4 text-cyan-300/60" />
            <span className="text-xs font-bold uppercase tracking-[0.18em] text-white/40">Top Minerals</span>
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <BarChart data={chartData} margin={{ top: 0, right: 0, left: -24, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.2)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "rgba(10,15,20,0.95)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, color: "#fff", fontSize: 12 }}
                cursor={{ fill: "rgba(255,255,255,0.03)" }}
              />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {chartData.map((_, i) => (
                  <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} opacity={0.85} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Session yield trend */}
      {yieldData.length > 1 && (
        <div
          className="rounded-2xl border p-4"
          style={{
            background: "linear-gradient(145deg, rgba(10,15,20,0.85) 0%, rgba(14,20,27,0.80) 100%)",
            border: "1px solid rgba(255,255,255,0.08)",
          }}
        >
          <div className="mb-3 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-purple-300/60" />
            <span className="text-xs font-bold uppercase tracking-[0.18em] text-white/40">Session Yield Trend</span>
          </div>
          <ResponsiveContainer width="100%" height={100}>
            <BarChart data={yieldData} margin={{ top: 0, right: 0, left: -24, bottom: 0 }}>
              <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.25)", fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis hide domain={[0, 100]} />
              <Tooltip
                contentStyle={{ background: "rgba(10,15,20,0.95)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 12, color: "#fff", fontSize: 12 }}
                cursor={{ fill: "rgba(255,255,255,0.03)" }}
              />
              <Bar dataKey="score" radius={[4, 4, 0, 0]} fill="#9B5CFF" opacity={0.8} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Past sessions list */}
      {sessions.length > 0 && (
        <div>
          <div className="mb-2 text-[10px] font-bold uppercase tracking-[0.22em] text-white/25">Recent Trips</div>
          <div className="space-y-2">
            {sessions.slice(0, 6).map((s) => (
              <div
                key={s.id}
                className="flex items-center justify-between rounded-xl border px-4 py-3"
                style={{
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <div>
                  <div className="text-sm font-medium text-white/80">
                    {s.locality_cluster || s.zone_type || "Field Trip"}
                  </div>
                  <div className="text-[11px] text-white/30">
                    {s.specimen_count || 0} finds · {s.session_type || "exploratory"}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-bold" style={{ color: "#7DF9FF" }}>
                    {Math.round(s.success_score || 0)}
                  </div>
                  <div className="text-[10px] text-white/25">score</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}