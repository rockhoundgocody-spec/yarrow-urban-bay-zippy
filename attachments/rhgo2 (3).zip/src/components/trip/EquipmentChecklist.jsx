import React, { useState } from "react";
import { CheckSquare, Square, ChevronDown, ChevronUp, Package } from "lucide-react";

const BASE_CHECKLIST = {
  "Rockhounding Tools": [
    { id: "hammer", label: "Rock hammer (24oz)", essential: true },
    { id: "chisels", label: "Cold chisels (set)", essential: true },
    { id: "pry_bar", label: "Pry bar / wrecking bar", essential: false },
    { id: "screens", label: "Classifier/gravel screens", essential: false },
    { id: "brush", label: "Soft brush & dental picks", essential: true },
    { id: "loupe", label: "Hand loupe (10x)", essential: true },
    { id: "bags", label: "Collecting bags (cloth + zip)", essential: true },
    { id: "labels", label: "Labels, marker, field notebook", essential: true },
    { id: "streak", label: "Streak plate", essential: false },
    { id: "acid", label: "Dilute HCl test vial (carbonates)", essential: false },
  ],
  "Safety & Navigation": [
    { id: "firstaid", label: "First aid kit", essential: true },
    { id: "water", label: "Water (2L+ per person per day)", essential: true },
    { id: "sunscreen", label: "Sunscreen SPF 50+", essential: true },
    { id: "hat", label: "Wide-brim hat", essential: true },
    { id: "gps", label: "GPS device or downloaded offline maps", essential: true },
    { id: "topo", label: "Topo maps (USGS) for each site", essential: true },
    { id: "headlamp", label: "Headlamp + extra batteries", essential: true },
    { id: "whistle", label: "Safety whistle", essential: true },
    { id: "blanket", label: "Emergency mylar blanket", essential: true },
    { id: "satellite", label: "Satellite communicator (remote areas)", essential: false },
  ],
  "Personal Gear": [
    { id: "boots", label: "Sturdy ankle-support boots", essential: true },
    { id: "gloves", label: "Leather work gloves", essential: true },
    { id: "eyepro", label: "Safety glasses / goggles", essential: true },
    { id: "layers", label: "Weather layers (base + mid + shell)", essential: true },
    { id: "charger", label: "Portable power bank", essential: true },
    { id: "snacks", label: "High-calorie trail snacks", essential: true },
  ],
  "Vehicle & Recovery": [
    { id: "spare", label: "Full-size spare tire", essential: true },
    { id: "jack", label: "Hi-lift jack", essential: false },
    { id: "tow", label: "Tow strap / kinetic rope", essential: false },
    { id: "fuel", label: "Extra fuel (remote areas)", essential: false },
    { id: "tools", label: "Basic tool kit", essential: true },
    { id: "jump", label: "Jump starter / battery pack", essential: false },
  ],
  "Camp Gear": [
    { id: "tent", label: "3-season tent", essential: true },
    { id: "sleep", label: "Sleeping bag (rated appropriately)", essential: true },
    { id: "pad", label: "Sleeping pad", essential: true },
    { id: "stove", label: "Camp stove + fuel", essential: true },
    { id: "filter", label: "Water filter / purification tabs", essential: true },
    { id: "bear", label: "Bear canister (required some areas)", essential: false },
  ],
};

const MINERAL_EXTRAS = {
  "gold": [
    { id: "gold_pan", label: "Gold pan (10-14 inch)", essential: true },
    { id: "sluice", label: "Portable sluice box", essential: false },
    { id: "snuffer", label: "Gold snuffer bottle", essential: true },
    { id: "classifier_fine", label: "Fine classifier (100-mesh)", essential: true },
  ],
  "turquoise": [
    { id: "matrix_pick", label: "Matrix pick for copper deposits", essential: true },
    { id: "padded_bag", label: "Padded specimen bags", essential: true },
  ],
  "quartz": [
    { id: "wedge", label: "Steel wedges for matrix splitting", essential: true },
    { id: "padding", label: "Bubble wrap for crystal tips", essential: true },
  ],
  "fossil": [
    { id: "fossil_pick", label: "Fossil pick / dental tools", essential: true },
    { id: "consolidant", label: "Paraloid B-72 consolidant", essential: false },
    { id: "photo_scale", label: "Measurement scale card for photos", essential: true },
    { id: "plaster", label: "Plaster bandages (field jacketing)", essential: false },
  ],
  "emerald": [
    { id: "gem_loupe", label: "Gem loupe (30x triplet)", essential: true },
    { id: "gem_bags", label: "Gem bags / paper folds", essential: true },
  ],
  "obsidian": [
    { id: "thick_gloves", label: "Heavy leather gloves (cut protection)", essential: true },
    { id: "wrapped_bags", label: "Thick-walled collecting box", essential: true },
  ],
};

export default function EquipmentChecklist({ minerals = [], camping = false, vehicle = "2wd" }) {
  const [checked, setChecked] = useState(new Set());
  const [expanded, setExpanded] = useState(new Set(["Rockhounding Tools", "Safety & Navigation"]));

  const toggleItem = (id) => {
    const next = new Set(checked);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setChecked(next);
  };

  const toggleSection = (section) => {
    const next = new Set(expanded);
    if (next.has(section)) next.delete(section);
    else next.add(section);
    setExpanded(next);
  };

  // Build checklist based on preferences
  const sections = { ...BASE_CHECKLIST };
  if (!camping) delete sections["Camp Gear"];
  if (vehicle === "2wd") {
    sections["Vehicle & Recovery"] = sections["Vehicle & Recovery"].filter(i => i.essential);
  }

  // Add mineral-specific gear
  const mineralExtras = [];
  minerals.forEach(m => {
    const key = Object.keys(MINERAL_EXTRAS).find(k => m.toLowerCase().includes(k) || k.includes(m.toLowerCase()));
    if (key) mineralExtras.push(...MINERAL_EXTRAS[key]);
  });
  if (mineralExtras.length > 0) {
    sections["Mineral-Specific Gear"] = [...new Map(mineralExtras.map(i => [i.id, i])).values()];
  }

  const totalItems = Object.values(sections).flat().length;
  const checkedCount = [...checked].filter(id => Object.values(sections).flat().some(i => i.id === id)).length;

  return (
    <div className="space-y-3">
      {/* Progress */}
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 text-xs text-white/50">
          <Package className="w-3.5 h-3.5" />
          <span>Field Pack — {checkedCount}/{totalItems} packed</span>
        </div>
        <div className="text-xs text-teal-400">{Math.round((checkedCount / totalItems) * 100)}%</div>
      </div>
      <div className="h-1 rounded-full bg-white/5 overflow-hidden mb-4">
        <div className="h-full rounded-full bg-teal-500 transition-all"
          style={{ width: `${(checkedCount / totalItems) * 100}%` }} />
      </div>

      {Object.entries(sections).map(([section, items]) => {
        const isExpanded = expanded.has(section);
        const sectionChecked = items.filter(i => checked.has(i.id)).length;
        const isSpecial = section === "Mineral-Specific Gear";
        return (
          <div key={section} className="rounded-xl border border-white/6 overflow-hidden">
            <button
              type="button"
              onClick={() => toggleSection(section)}
              className="w-full flex items-center justify-between px-3 py-2.5 bg-white/[0.02] hover:bg-white/[0.04] transition-colors text-left"
            >
              <span className={`text-xs font-semibold ${isSpecial ? "text-amber-400" : "text-white/70"}`}>
                {section}
                {isSpecial && " ⭐"}
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-white/30">{sectionChecked}/{items.length}</span>
                {isExpanded ? <ChevronUp className="w-3.5 h-3.5 text-white/30" /> : <ChevronDown className="w-3.5 h-3.5 text-white/30" />}
              </div>
            </button>
            {isExpanded && (
              <div className="divide-y divide-white/4">
                {items.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleItem(item.id)}
                    className="w-full flex items-center gap-2.5 px-3 py-2 hover:bg-white/[0.02] transition-colors text-left"
                  >
                    {checked.has(item.id)
                      ? <CheckSquare className="w-4 h-4 text-teal-400 flex-shrink-0" />
                      : <Square className="w-4 h-4 text-white/20 flex-shrink-0" />
                    }
                    <span className={`text-xs flex-1 ${checked.has(item.id) ? "line-through text-white/25" : "text-white/60"}`}>
                      {item.label}
                    </span>
                    {item.essential && !checked.has(item.id) && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 flex-shrink-0">required</span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}