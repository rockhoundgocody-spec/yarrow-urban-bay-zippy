import React, { useState, useMemo } from "react";
import { MapPin, Plus, Trash2, ChevronUp, ChevronDown, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function TripLocationPicker({ locations = [], selected = [], onChange }) {
  const [searchQ, setSearchQ] = useState("");

  const selectedSet = useMemo(() => new Set(selected), [selected]);

  // Pre-process and cache lowercase values for locations
  // This runs only when `locations` reference changes, avoiding repetitive operations on every keystroke
  const preprocessedLocations = useMemo(() => {
    return locations.map(l => ({
      ...l,
      _lowerName: l.name?.toLowerCase() || "",
      _lowerState: l.state?.toLowerCase() || "",
      _lowerMinerals: l.minerals_found?.map(m => m.toLowerCase()) || []
    }));
  }, [locations]);

  const suggestions = useMemo(() => {
    if (!searchQ) {
      return locations.filter(l => !selectedSet.has(l.id)).slice(0, 6);
    }
    const query = searchQ.toLowerCase();
    return preprocessedLocations
      .filter(l => !selectedSet.has(l.id) && (
        l._lowerName.includes(query) ||
        l._lowerState.includes(query) ||
        l._lowerMinerals.some(m => m.includes(query))
      ))
      .slice(0, 6);
  }, [preprocessedLocations, locations, selectedSet, searchQ]);

  // Memoize location lookup to prevent O(N * selected) search on every render/keystroke
  const selectedLocations = useMemo(() =>
    selected.map(id => locations.find(l => l.id === id)).filter(Boolean),
  [selected, locations]);

  const addLocation = (id) => onChange([...selected, id]);
  const removeLocation = (id) => onChange(selected.filter(i => i !== id));

  const moveUp = (idx) => {
    if (idx === 0) return;
    const next = [...selected];
    [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
    onChange(next);
  };

  const moveDown = (idx) => {
    if (idx === selected.length - 1) return;
    const next = [...selected];
    [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
    onChange(next);
  };

  // Memoize distance calculation to prevent redundant math on every keystroke
  const totalMiles = useMemo(() => {
    return selectedLocations.reduce((acc, loc, i) => {
      if (i === 0) return 0;
      const prev = selectedLocations[i - 1];
      const R = 3958.8;
      const dLat = ((loc.latitude - prev.latitude) * Math.PI) / 180;
      const dLng = ((loc.longitude - prev.longitude) * Math.PI) / 180;
      const a = Math.sin(dLat / 2) ** 2 + Math.cos((prev.latitude * Math.PI) / 180) * Math.cos((loc.latitude * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
      return acc + R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }, 0);
  }, [selectedLocations]);

  return (
    <div className="space-y-3">
      <label className="text-xs text-white/60 flex items-center gap-1.5">
        <MapPin className="w-3 h-3" /> Select Stops ({selected.length} selected)
        {selected.length >= 2 && (
          <span className="ml-auto text-[10px] text-emerald-400">
            ~{Math.round(totalMiles * 1.3)} mi est. driving
          </span>
        )}
      </label>

      {/* Selected stops */}
      {selectedLocations.length > 0 && (
        <div className="space-y-1.5">
          {selectedLocations.map((loc, idx) => (
            <div key={loc.id} className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2 border border-white/10 group">
              <div className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold flex items-center justify-center shrink-0">
                {idx + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white/80 truncate">{loc.name}</p>
                <p className="text-[10px] text-white/40 truncate">
                  {loc.state} · {loc.minerals_found?.slice(0, 2).join(", ")}
                </p>
              </div>
              <div className="flex items-center gap-0.5 opacity-60 group-hover:opacity-100 transition-opacity">
                <button onClick={() => moveUp(idx)} disabled={idx === 0} className="p-1 text-white/30 hover:text-white/60 disabled:opacity-20" aria-label="Collapse">
                  <ChevronUp className="w-3 h-3" />
                </button>
                <button onClick={() => moveDown(idx)} disabled={idx === selectedLocations.length - 1} className="p-1 text-white/30 hover:text-white/60 disabled:opacity-20" aria-label="Expand">
                  <ChevronDown className="w-3 h-3" />
                </button>
                <button onClick={() => removeLocation(loc.id)} className="p-1 text-white/30 hover:text-red-400" aria-label="Delete">
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Search and add */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
        <Input
          placeholder="Search locations to add..."
          value={searchQ}
          onChange={(e) => setSearchQ(e.target.value)}
          className="pl-9 bg-white/5 border-white/10 text-white text-xs placeholder:text-white/30"
        />
      </div>

      <div className="space-y-1 max-h-40 overflow-y-auto">
        {suggestions.map(loc => (
          <button
            key={loc.id}
            onClick={() => addLocation(loc.id)}
            className="w-full flex items-center gap-2 text-left px-3 py-2 rounded-lg hover:bg-white/5 border border-transparent hover:border-white/10 transition-all group"
          >
            <MapPin className="w-3.5 h-3.5 text-white/20 group-hover:text-emerald-400 transition-colors shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-white/70 truncate">{loc.name}</p>
              <p className="text-[10px] text-white/30">{loc.state} · {loc.difficulty}</p>
            </div>
            <Plus className="w-3 h-3 text-white/20 group-hover:text-emerald-400 transition-colors shrink-0" />
          </button>
        ))}
        {suggestions.length === 0 && searchQ && (
          <p className="text-[11px] text-white/30 text-center py-2">No matches</p>
        )}
      </div>
    </div>
  );
}