/**
 * RouteDriveSummary — OSRM-powered drive distance/time for an ordered trip itinerary.
 * Fetches road routing between stops (in order) via the osrmRoute backend function.
 */
import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Route, Loader2, AlertCircle } from "lucide-react";

const fmtDist = (m) => `${(m / 1609.34).toFixed(1)} mi`;
const fmtDur = (s) => {
  const h = Math.floor(s / 3600), min = Math.round((s % 3600) / 60);
  return h > 0 ? `${h}h ${min}m` : `${min}m`;
};

export default function RouteDriveSummary({ stops = [], locations = [] }) {
  const points = useMemo(() => {
    const locById = new Map(locations.map(l => [l.id, l]));
    return stops
      .map(s => {
        const loc = locById.get(s.location_id);
        return loc && isFinite(loc.latitude) && isFinite(loc.longitude)
          ? { name: s.location_name, lat: loc.latitude, lng: loc.longitude }
          : null;
      })
      .filter(Boolean);
  }, [stops, locations]);

  const routeKey = points.map(p => `${p.lat},${p.lng}`).join(";");

  const { data, isLoading, isError } = useQuery({
    queryKey: ["osrm-route", routeKey],
    enabled: points.length >= 2,
    staleTime: 10 * 60_000,
    retry: 1,
    queryFn: async () => {
      const res = await base44.functions.invoke("osrmRoute", {
        coordinates: points.map(p => ({ lat: p.lat, lng: p.lng })),
        profile: "driving",
      });
      return res.data;
    },
  });

  if (points.length < 2) return null;

  return (
    <div className="rounded-2xl p-4 mb-4"
      style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.14)" }}>
      <div className="flex items-center gap-2 mb-2.5">
        <Route className="w-3.5 h-3.5" style={{ color: "#7AE7FF" }} />
        <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: "#7AE7FF" }}>
          Drive Route
        </p>
      </div>

      {isLoading && (
        <div className="flex items-center gap-2 text-[11px]" style={{ color: "rgba(255,255,255,0.35)" }}>
          <Loader2 className="w-3.5 h-3.5 animate-spin" /> Calculating road route…
        </div>
      )}

      {isError && (
        <div className="flex items-center gap-2 text-[11px]" style={{ color: "rgba(245,182,66,0.7)" }}>
          <AlertCircle className="w-3.5 h-3.5" /> Routing unavailable right now — try again later.
        </div>
      )}

      {data && (
        <>
          <div className="flex items-center gap-4 mb-2.5">
            <div>
              <p className="text-lg font-black text-white leading-none">{fmtDist(data.distance_m)}</p>
              <p className="text-[9px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.3)" }}>total drive</p>
            </div>
            <div>
              <p className="text-lg font-black leading-none" style={{ color: "#00D68F" }}>{fmtDur(data.duration_s)}</p>
              <p className="text-[9px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.3)" }}>drive time</p>
            </div>
          </div>
          <div className="space-y-1">
            {(data.legs || []).map((leg, i) => (
              <div key={i} className="flex items-center justify-between text-[10px] px-2 py-1 rounded-lg"
                style={{ background: "rgba(255,255,255,0.02)" }}>
                <span style={{ color: "rgba(255,255,255,0.4)" }} className="truncate mr-2">
                  {points[i]?.name} → {points[i + 1]?.name}
                </span>
                <span className="flex-shrink-0 font-bold" style={{ color: "rgba(122,231,255,0.7)" }}>
                  {fmtDist(leg.distance_m)} · {fmtDur(leg.duration_s)}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}