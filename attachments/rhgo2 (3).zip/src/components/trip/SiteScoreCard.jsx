import React from "react";
import { MapPin, ShieldCheck, ShieldAlert, ShieldX, Star, Car, AlertTriangle, Leaf, Gem } from "lucide-react";

const SEASON_MAP = {
  0: "Winter", 1: "Winter", 2: "Spring",
  3: "Spring", 4: "Spring", 5: "Summer",
  6: "Summer", 7: "Summer", 8: "Fall",
  9: "Fall", 10: "Fall", 11: "Winter",
};

function getSeasonScore(loc, month) {
  const season = SEASON_MAP[month];
  const bestSeason = loc.best_season?.toLowerCase() || "";
  const restrictions = loc.seasonal_restrictions?.toLowerCase() || "";
  if (restrictions.includes(season.toLowerCase())) return { score: 0, label: "Restricted", color: "#ef4444" };
  if (bestSeason.includes(season.toLowerCase())) return { score: 1, label: "Peak Season", color: "#22c55e" };
  if (season === "Winter") return { score: 0.4, label: "Off-Season", color: "#f97316" };
  return { score: 0.7, label: "Good Season", color: "#06b6d4" };
}

function getMineralScore(loc, targetMinerals) {
  if (!targetMinerals?.length) return { score: 0.5, matches: [] };
  const found = loc.minerals_found || [];
  const predicted = loc.predicted_minerals || [];
  const checkMatch = (m, tLower) => {
    const mLower = m.toLowerCase();
    return mLower.includes(tLower) || tLower.includes(mLower);
  };
  const matches = targetMinerals.filter(t => {
    const tLower = t.toLowerCase();
    return found.some(m => checkMatch(m, tLower)) || predicted.some(m => checkMatch(m, tLower));
  });
  return { score: Math.min(1, matches.length / targetMinerals.length), matches };
}

function getLegalityIcon(status) {
  if (status === "Safe Public") return <ShieldCheck className="w-3.5 h-3.5 text-green-400" />;
  if (status === "Likely Legal") return <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />;
  if (status === "Use Caution") return <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />;
  return <ShieldX className="w-3.5 h-3.5 text-red-400" />;
}

export function scoreSite(loc, { targetMinerals = [], month = new Date().getMonth(), maxDistanceMi = 500, distanceMi = 0 }) {
  const mineralResult = getMineralScore(loc, targetMinerals);
  const seasonResult = getSeasonScore(loc, month);
  const distanceScore = Math.max(0, 1 - (distanceMi / maxDistanceMi));
  const ratingScore = (loc.rating_avg || 3) / 5;
  const legalBonus = loc.legality_status === "Safe Public" ? 1 : loc.legality_status === "Likely Legal" ? 0.8 : 0.4;

  const total = (
    mineralResult.score * 0.35 +
    seasonResult.score * 0.25 +
    distanceScore * 0.20 +
    ratingScore * 0.10 +
    legalBonus * 0.10
  );

  return {
    total: Math.round(total * 100),
    mineral: mineralResult,
    season: seasonResult,
    distance: distanceMi,
  };
}

export default function SiteScoreCard({ loc, score, targetMinerals, compact = false }) {
  if (!loc) return null;

  const barColor = score.total >= 75 ? "#22c55e" : score.total >= 50 ? "#06b6d4" : "#f97316";

  if (compact) {
    return (
      <div className="flex items-center gap-3 p-3 rounded-xl border border-white/5 bg-white/[0.02] hover:border-white/10 transition-all">
        <div className="flex-shrink-0 w-10 h-10 rounded-lg flex flex-col items-center justify-center text-center"
          style={{ background: `${barColor}15`, border: `1px solid ${barColor}30` }}>
          <span className="text-sm font-bold" style={{ color: barColor }}>{score.total}</span>
          <span className="text-[8px] text-white/30">score</span>
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold text-white/80 truncate">{loc.name}</div>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-[10px] text-white/30">{loc.state}</span>
            {getLegalityIcon(loc.legality_status)}
            {score.mineral.matches.length > 0 && (
              <span className="text-[10px] text-amber-400">{score.mineral.matches.slice(0,2).join(", ")}</span>
            )}
          </div>
        </div>
        <div className="text-[10px] px-2 py-0.5 rounded-full text-white/50"
          style={{ background: `${score.season.color}15`, color: score.season.color }}>
          {score.season.label}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 rounded-2xl border border-white/8 bg-[#0f0f1e] space-y-3">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="text-sm font-bold text-white/90">{loc.name}</div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <MapPin className="w-3 h-3 text-white/30" />
            <span className="text-[10px] text-white/40">{loc.state}{loc.county ? `, ${loc.county}` : ""}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1 flex-shrink-0">
          <div className="text-2xl font-black" style={{ color: barColor }}>{score.total}</div>
          <div className="text-[9px] text-white/25 uppercase tracking-wide">Match Score</div>
        </div>
      </div>

      {/* Score bar */}
      <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${score.total}%`, background: barColor }} />
      </div>

      {/* Badges */}
      <div className="flex flex-wrap gap-1.5">
        <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: `${score.season.color}15`, color: score.season.color }}>
          {score.season.label}
        </span>
        {loc.legality_status && (
          <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/50">
            {getLegalityIcon(loc.legality_status)} {loc.legality_status}
          </span>
        )}
        {loc.difficulty && (
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/40 capitalize">
            {loc.difficulty}
          </span>
        )}
        {loc.vehicle_requirement && (
          <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/40">
            <Car className="w-2.5 h-2.5" /> {loc.vehicle_requirement}
          </span>
        )}
        {loc.rating_avg > 0 && (
          <span className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400">
            <Star className="w-2.5 h-2.5" /> {loc.rating_avg.toFixed(1)}
          </span>
        )}
      </div>

      {/* Mineral matches */}
      {score.mineral.matches.length > 0 && (
        <div>
          <div className="text-[10px] text-white/30 mb-1 flex items-center gap-1">
            <Gem className="w-3 h-3" /> Target mineral matches
          </div>
          <div className="flex flex-wrap gap-1">
            {score.mineral.matches.map(m => (
              <span key={m} className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 capitalize">{m}</span>
            ))}
          </div>
        </div>
      )}

      {/* Hazards */}
      {loc.hazards?.length > 0 && (
        <div className="flex items-start gap-1.5 p-2 rounded-lg bg-red-500/5 border border-red-500/15">
          <AlertTriangle className="w-3 h-3 text-red-400 mt-0.5 flex-shrink-0" />
          <span className="text-[10px] text-red-300/70">{loc.hazards.join(" · ")}</span>
        </div>
      )}

      {/* Access */}
      {loc.access_info && (
        <div className="flex items-start gap-1.5 p-2 rounded-lg bg-green-500/5 border border-green-500/10">
          <Leaf className="w-3 h-3 text-green-400 mt-0.5 flex-shrink-0" />
          <span className="text-[10px] text-green-300/70 line-clamp-2">{loc.access_info}</span>
        </div>
      )}
    </div>
  );
}