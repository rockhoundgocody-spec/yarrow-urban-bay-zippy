import React, { useState } from "react";
import { Loader2, Package, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function FieldPackExport({ trip, locations = [] }) {
  const [generating, setGenerating] = useState(false);
  const [done, setDone] = useState(false);

  const tripLocations = locations.filter(l => trip.locations?.includes(l.id));

  const generateFieldPack = () => {
    setGenerating(true);

    const lines = [];
    lines.push(`# 🎒 Field Pack — ${trip.name}`);
    lines.push(`**Starting from:** ${trip.start_location}`);
    lines.push(`**Duration:** ${trip.duration_days} days`);
    lines.push(`**Distance:** ~${Math.round(trip.estimated_distance || 0)} miles`);
    lines.push(`**Drive Time:** ~${Math.round(trip.estimated_time || 0)} hours`);
    if (trip.start_date) lines.push(`**Departs:** ${trip.start_date}`);
    lines.push("");

    // Locations summary
    lines.push("## 📍 Stops");
    tripLocations.forEach((loc, i) => {
      lines.push(`### ${i+1}. ${loc.name}`);
      lines.push(`- **State:** ${loc.state || "Unknown"}`);
      lines.push(`- **GPS:** ${loc.latitude?.toFixed(5)}, ${loc.longitude?.toFixed(5)}`);
      lines.push(`- **Type:** ${loc.site_type || "Unknown"}`);
      lines.push(`- **Difficulty:** ${loc.difficulty || "Unknown"}`);
      lines.push(`- **Land Manager:** ${loc.land_manager || "Unknown"}`);
      lines.push(`- **Access:** ${loc.access_type || "Unknown"}`);
      if (loc.minerals_found?.length) lines.push(`- **Minerals:** ${loc.minerals_found.join(", ")}`);
      if (loc.hazards?.length) lines.push(`- **⚠️ Hazards:** ${loc.hazards.join(", ")}`);
      if (loc.seasonal_restrictions) lines.push(`- **Seasonal:** ${loc.seasonal_restrictions}`);
      if (loc.vehicle_requirement) lines.push(`- **Vehicle:** ${loc.vehicle_requirement}`);
      if (loc.fee_required) lines.push(`- **Fee:** ${loc.fee_amount || "Yes"}`);
      if (loc.access_info) lines.push(`- **Access Info:** ${loc.access_info}`);
      lines.push("");
    });

    // Safety section
    lines.push("## ⚠️ Safety Hazards");
    const allHazards = new Set();
    tripLocations.forEach(loc => loc.hazards?.forEach(h => allHazards.add(h)));
    if (allHazards.size > 0) {
      [...allHazards].forEach(h => lines.push(`- ${h}`));
    } else {
      lines.push("- Check local conditions before each stop");
    }
    lines.push("- Always carry water, first aid kit, and sun protection");
    lines.push("- Tell someone your itinerary before departing");
    lines.push("- Check weather forecast for flash flood risk");
    lines.push("");

    // Equipment checklist
    lines.push("## 🛠️ Equipment Checklist");
    const allMinerals = new Set();
    tripLocations.forEach(loc => loc.minerals_found?.forEach(m => allMinerals.add(m)));

    lines.push("### Rockhounding Tools");
    lines.push("- [ ] Rock hammer (2-3 lb)");
    lines.push("- [ ] Cold chisels (flat + point)");
    lines.push("- [ ] Safety goggles");
    lines.push("- [ ] Collection bags + newspaper wrap");
    lines.push("- [ ] Labels + permanent marker");
    lines.push("- [ ] Field guide / mineral ID chart");
    lines.push("- [ ] Hand lens (10x loupe)");
    lines.push("- [ ] Streak plate");
    if ([...allMinerals].some(m => /gold|placer/i.test(m))) {
      lines.push("- [ ] Gold pan + classifier");
    }
    if ([...allMinerals].some(m => /crystal|geode/i.test(m))) {
      lines.push("- [ ] Pry bar for geodes");
    }
    lines.push("");

    lines.push("### Safety & Navigation");
    lines.push("- [ ] First aid kit");
    lines.push("- [ ] Sunscreen SPF 50+");
    lines.push("- [ ] Hat + sunglasses");
    lines.push(`- [ ] Water (1 gal/person/day × ${trip.duration_days} days)`);
    lines.push("- [ ] Snacks / trail meals");
    lines.push("- [ ] Headlamp + spare batteries");
    lines.push("- [ ] Whistle + emergency blanket");
    lines.push("- [ ] Phone charger / power bank");
    lines.push("- [ ] Downloaded offline maps");
    lines.push("- [ ] GPS coordinates printed (backup)");
    lines.push("");

    lines.push("### Vehicle");
    const needs4x4 = tripLocations.some(l => l.vehicle_requirement === "4x4 Required");
    const needsHC = tripLocations.some(l => l.vehicle_requirement === "High Clearance");
    if (needs4x4) lines.push("- [ ] ⚠️ 4x4 REQUIRED for some stops");
    else if (needsHC) lines.push("- [ ] High clearance vehicle recommended");
    lines.push("- [ ] Full tank of gas");
    lines.push("- [ ] Spare tire + jack");
    lines.push("- [ ] Tow strap");
    lines.push("- [ ] Tire pressure gauge");
    lines.push("");

    // Legality
    lines.push("## ⚖️ Legality Notes");
    const managers = new Set(tripLocations.map(l => l.land_manager).filter(Boolean));
    if (managers.has("BLM")) lines.push("- **BLM:** 25 lbs/day, 250 lbs/year casual collection. No commercial.");
    if (managers.has("USFS")) lines.push("- **USFS:** Casual collection usually allowed. Check local ranger district.");
    if (managers.has("NPS")) lines.push("- **NPS:** ⛔ NO collecting in National Parks.");
    if (managers.has("State Park")) lines.push("- **State Parks:** Varies by state. Check before collecting.");
    if (managers.has("Private")) lines.push("- **Private:** Written permission required.");
    lines.push("");

    // GPS coordinates for offline
    lines.push("## 🧭 GPS Coordinates (Offline Reference)");
    tripLocations.forEach((loc, i) => {
      lines.push(`${i+1}. **${loc.name}** — ${loc.latitude?.toFixed(5)}, ${loc.longitude?.toFixed(5)}`);
    });
    lines.push("");
    lines.push(`---\n*Generated by RockHound-Go on ${new Date().toLocaleDateString()}*`);

    // Create downloadable file
    const content = lines.join("\n");
    const blob = new Blob([content], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `FieldPack_${trip.name.replace(/\s+/g, "_")}.md`;
    a.click();
    URL.revokeObjectURL(url);

    setGenerating(false);
    setDone(true);
    setTimeout(() => setDone(false), 3000);
  };

  if (tripLocations.length === 0) return null;

  return (
    <Button
      onClick={generateFieldPack}
      disabled={generating}
      variant="outline"
      className="gap-2 bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 hover:text-emerald-300"
    >
      {generating ? (
        <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</>
      ) : done ? (
        <><CheckCircle className="w-4 h-4" /> Downloaded!</>
      ) : (
        <><Package className="w-4 h-4" /> Download Field Pack</>
      )}
    </Button>
  );
}