import React, { useState } from "react";
import { MapPin, ChevronDown, ChevronUp, Check } from "lucide-react";

const REGIONS = {
  "Southwest": {
    states: ["Arizona", "New Mexico", "Nevada", "Utah"],
    color: "#f97316",
    minerals: ["turquoise", "azurite", "malachite", "obsidian", "jasper", "petrified wood"],
    description: "Desert gems, copper minerals, volcanic fields",
  },
  "Pacific West": {
    states: ["California", "Oregon", "Washington"],
    color: "#06b6d4",
    minerals: ["gold", "jade", "agate", "thunder eggs", "sunstone", "garnet"],
    description: "Gold country, agates, Pacific coast gems",
  },
  "Rocky Mountains": {
    states: ["Colorado", "Wyoming", "Montana", "Idaho"],
    color: "#8b5cf6",
    minerals: ["rhodochrosite", "aquamarine", "sapphire", "topaz", "garnet", "gold"],
    description: "High-altitude gems, mining districts",
  },
  "Great Plains": {
    states: ["South Dakota", "Nebraska", "Kansas", "North Dakota"],
    color: "#eab308",
    minerals: ["fairburn agate", "rose quartz", "flint", "calcite", "petrified wood"],
    description: "Agates, fossils, badlands terrain",
  },
  "Southeast": {
    states: ["North Carolina", "Georgia", "Arkansas", "Virginia"],
    color: "#22c55e",
    minerals: ["emerald", "ruby", "sapphire", "quartz", "diamonds", "amethyst"],
    description: "Appalachian gems, crystal mines",
  },
  "Great Lakes": {
    states: ["Michigan", "Minnesota", "Wisconsin"],
    color: "#3b82f6",
    minerals: ["copper", "chlorastrolite", "agate", "prehnite", "thomsonite"],
    description: "Lake Superior agates, native copper",
  },
  "Northeast": {
    states: ["Maine", "Vermont", "New Hampshire", "New York"],
    color: "#ec4899",
    minerals: ["tourmaline", "beryl", "garnet", "labradorite", "quartz"],
    description: "Pegmatite gems, granite terrains",
  },
  "Texas & Gulf": {
    states: ["Texas", "Louisiana", "Mississippi"],
    color: "#a16207",
    minerals: ["petrified wood", "calcite", "flint", "fossils", "agate"],
    description: "Fossils, flint, petrified wood",
  },
};

export default function RegionPicker({ selected, onChange }) {
  const [expanded, setExpanded] = useState(true);

  const toggle = (regionName) => {
    if (selected.includes(regionName)) {
      onChange(selected.filter(r => r !== regionName));
    } else {
      onChange([...selected, regionName]);
    }
  };

  const suggestedMinerals = [...new Set(
    selected.flatMap(r => REGIONS[r]?.minerals || [])
  )];

  return (
    <div className="space-y-3">
      <button
        type="button"
        className="w-full flex items-center justify-between text-xs text-white/60 hover:text-white/80 transition-colors"
        onClick={() => setExpanded(!expanded)}
      >
        <span className="flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5" />
          Geographic Regions
          {selected.length > 0 && (
            <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-teal-500/20 text-teal-400">
              {selected.length} selected
            </span>
          )}
        </span>
        {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
      </button>

      {expanded && (
        <div className="grid grid-cols-2 gap-2">
          {Object.entries(REGIONS).map(([name, region]) => {
            const isSelected = selected.includes(name);
            return (
              <button
                key={name}
                type="button"
                onClick={() => toggle(name)}
                className="relative text-left p-3 rounded-xl border transition-all text-xs"
                style={{
                  background: isSelected ? `${region.color}12` : "rgba(255,255,255,0.03)",
                  borderColor: isSelected ? `${region.color}50` : "rgba(255,255,255,0.08)",
                  boxShadow: isSelected ? `0 0 12px ${region.color}15` : "none",
                }}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2 w-4 h-4 rounded-full flex items-center justify-center"
                    style={{ background: region.color }}>
                    <Check className="w-2.5 h-2.5 text-white" />
                  </div>
                )}
                <div className="font-semibold mb-0.5" style={{ color: isSelected ? region.color : "rgba(255,255,255,0.7)" }}>
                  {name}
                </div>
                <div className="text-[10px] text-white/30 mb-1.5">{region.description}</div>
                <div className="flex flex-wrap gap-1">
                  {region.states.map(s => (
                    <span key={s} className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-white/25">{s}</span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {suggestedMinerals.length > 0 && (
        <div className="p-3 rounded-xl border border-amber-500/20 bg-amber-500/5">
          <div className="text-[10px] text-amber-400/70 mb-1.5">Minerals common in selected regions:</div>
          <div className="flex flex-wrap gap-1">
            {suggestedMinerals.map(m => (
              <span key={m} className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 capitalize">
                {m}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export { REGIONS };