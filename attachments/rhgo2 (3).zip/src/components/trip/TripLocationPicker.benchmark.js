// Benchmark test for TripLocationPicker filtering logic
import { performance } from "perf_hooks";

// Mock locations generator
function generateMockLocations(count) {
  const mineralsList = ["Quartz", "Amethyst", "Feldspar", "Mica", "Calcite", "Pyrite", "Fluorite", "Garnet", "Obsidian", "Hematite"];
  const states = ["CA", "OR", "WA", "NV", "AZ", "UT", "CO", "NM", "TX", "WY"];
  const locations = [];
  for (let i = 0; i < count; i++) {
    locations.push({
      id: `loc-${i}`,
      name: `Location Super Mineral Spot ${i} Special`,
      state: states[i % states.length],
      minerals_found: [
        mineralsList[i % mineralsList.length],
        mineralsList[(i + 1) % mineralsList.length],
        mineralsList[(i + 2) % mineralsList.length]
      ]
    });
  }
  return locations;
}

const locations = generateMockLocations(1000);
const selectedSet = new Set(["loc-1", "loc-50", "loc-999"]);
const query = "calcite";

// Existing/baseline implementation
function baselineFilter(locations, selectedSet, query) {
  return locations.filter(l => !selectedSet.has(l.id) && (
    l.name?.toLowerCase().includes(query) ||
    l.state?.toLowerCase().includes(query) ||
    l.minerals_found?.some(m => m.toLowerCase().includes(query))
  ));
}

// Optimized implementation
function optimizedFilter(locations, selectedSet, query) {
  // Let's first map locations to pre-lowercased versions
  const preprocessed = locations.map(l => ({
    id: l.id,
    lowerName: l.name?.toLowerCase() || "",
    lowerState: l.state?.toLowerCase() || "",
    lowerMinerals: l.minerals_found?.map(m => m.toLowerCase()) || []
  }));

  // Now run the filter using preprocessed
  return preprocessed.filter(l => !selectedSet.has(l.id) && (
    l.lowerName.includes(query) ||
    l.lowerState.includes(query) ||
    l.lowerMinerals.some(m => m.includes(query))
  ));
}

// In a real Component, the preprocessing would happen in useMemo over `locations` once,
// and the query filter would run over `preprocessedLocations` when `query` changes.
// Let's benchmark the search itself (assuming preprocessing is done once vs baseline doing lowercase every time).

// Let's measure:
// 1. Baseline search
// 2. Preprocessed search (including the preprocessing step)
// 3. Preprocessed search (excluding preprocessing step, i.e., search ONLY, which is what happens on every keystroke when typing)

const ITERATIONS = 1000;

console.log(`Running benchmark with ${locations.length} locations and ${ITERATIONS} iterations...`);

// 1. Baseline
const startBaseline = performance.now();
for (let i = 0; i < ITERATIONS; i++) {
  baselineFilter(locations, selectedSet, query);
}
const endBaseline = performance.now();
const baselineTime = endBaseline - startBaseline;

// 2. Optimized (Search only - simulating keystroke changes where preprocessed locations are memoized)
// Preprocess once (corresponds to memoization on locations prop change)
const preprocessed = locations.map(l => ({
  id: l.id,
  lowerName: l.name?.toLowerCase() || "",
  lowerState: l.state?.toLowerCase() || "",
  lowerMinerals: l.minerals_found?.map(m => m.toLowerCase()) || []
}));

const startOptimizedSearchOnly = performance.now();
for (let i = 0; i < ITERATIONS; i++) {
  preprocessed.filter(l => !selectedSet.has(l.id) && (
    l.lowerName.includes(query) ||
    l.lowerState.includes(query) ||
    l.lowerMinerals.some(m => m.includes(query))
  ));
}
const endOptimizedSearchOnly = performance.now();
const optimizedSearchOnlyTime = endOptimizedSearchOnly - startOptimizedSearchOnly;

// 3. Optimized (Including preprocessing - simulating full cold run)
const startOptimizedFull = performance.now();
for (let i = 0; i < ITERATIONS; i++) {
  optimizedFilter(locations, selectedSet, query);
}
const endOptimizedFull = performance.now();
const optimizedFullTime = endOptimizedFull - startOptimizedFull;

console.log(`\n--- BENCHMARK RESULTS ---`);
console.log(`Baseline execution:            ${baselineTime.toFixed(2)} ms`);
console.log(`Optimized (Search only):       ${optimizedSearchOnlyTime.toFixed(2)} ms (Speedup: ${(baselineTime / optimizedSearchOnlyTime).toFixed(2)}x)`);
console.log(`Optimized (With Preprocess):   ${optimizedFullTime.toFixed(2)} ms (Speedup: ${(baselineTime / optimizedFullTime).toFixed(2)}x)`);
