import React, { useMemo, useState } from "react";
import { Sparkles, MapPin, ChevronDown, ChevronUp, Filter } from "lucide-react";
import { scoreSite } from "./SiteScoreCard";
import SiteScoreCard from "./SiteScoreCard";

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const REGION_COORDS = {
  "Southwest": { lat: 34.0, lng: -111.0 },
  "Pacific West": { lat: 38.5, lng: -121.0 },
  "Rocky Mountains": { lat: 40.5, lng: -106.0 },
  "Great Plains": { lat: 44.0, lng: -100.0 },
  "Southeast": { lat: 35.5, lng: -82.0 },
  "Great Lakes": { lat: 46.0, lng: -86.0 },
  "Northeast": { lat: 44.5, lng: -71.0 },
  "Texas & Gulf": { lat: 31.0, lng: -99.0 },
};

export default function SiteSuggestions({ locations, regions, targetMinerals, startDate, limit = 12 }) {
  const [showAll, setShowAll] = useState(false);
  const [minScore, setMinScore] = useState(40);

  const month = useMemo(() => {
    if (startDate) return new Date(startDate).getMonth();
    return new Date().getMonth();
  }, [startDate]);

  const regionCenters = useMemo(() => {
    return regions.flatMap(r => REGION_COORDS[r] ? [REGION_COORDS[r]] : []);
  }, [regions]);

  const scored = useMemo(() => {
    if (!locations?.length) return [];

    return locations
      .filter(loc => {
        if (!loc.latitude || !loc.longitude) return false;
        if (loc.review_status && loc.review_status !== "approved") return false;
        // Filter to selected regions if any
        if (regions.length > 0) {
          const inRegion = regionCenters.some(center => {
            const km = haversineKm(loc.latitude, loc.longitude, center.lat, center.lng);
            return km < 1200; // ~750 miles radius per region center
          });
          if (!inRegion) return false;
        }
        return true;
      })
      .map(loc => {
        const closestCenter = regionCenters.length > 0
          ? Math.min(...regionCenters.map(c => haversineKm(loc.latitude, loc.longitude, c.lat, c.lng)))
          : 0;
        const distanceMi = closestCenter * 0.621;

        const score = scoreSite(loc, {
          targetMinerals,
          month,
          maxDistanceMi: 800,
          distanceMi,
        });

        return { loc, score };
      })
      .sort((a, b) => b.score.total - a.score.total)
      .filter(({ score }) => score.total >= minScore);
  }, [locations, regions, targetMinerals, month, regionCenters, minScore]);

  const displayed = showAll ? scored : scored.slice(0, limit);

  if (regions.length === 0 && !targetMinerals?.length) {
    return (
      <div className="text-center py-6 text-white/25 text-xs">
        Select a region or target minerals to see AI-scored site suggestions
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-white/60">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          <span>{scored.length} sites ranked by AI match score</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Filter className="w-3 h-3 text-white/30" />
          <span className="text-[10px] text-white/30">Min score:</span>
          <select
            value={minScore}
            onChange={e => setMinScore(Number(e.target.value))}
            className="text-[10px] bg-white/5 border border-white/10 rounded px-1.5 py-0.5 text-white/50"
          >
            <option value={0}>All</option>
            <option value={40}>40+</option>
            <option value={60}>60+</option>
            <option value={75}>75+</option>
          </select>
        </div>
      </div>

      {scored.length === 0 ? (
        <div className="text-center py-8 text-white/25 text-xs">
          <MapPin className="w-8 h-8 mx-auto mb-2 opacity-30" />
          No matching sites found for your criteria. Try lowering the minimum score or selecting a different region.
        </div>
      ) : (
        <>
          <div className="space-y-2">
            {displayed.map(({ loc, score }) => (
              <SiteScoreCard key={loc.id} loc={loc} score={score} targetMinerals={targetMinerals} compact />
            ))}
          </div>
          {scored.length > limit && (
            <button
              type="button"
              onClick={() => setShowAll(!showAll)}
              className="w-full text-xs text-white/30 hover:text-white/50 flex items-center justify-center gap-1 py-2 transition-colors"
            >
              {showAll ? (
                <><ChevronUp className="w-3.5 h-3.5" /> Show less</>
              ) : (
                <><ChevronDown className="w-3.5 h-3.5" /> Show {scored.length - limit} more sites</>
              )}
            </button>
          )}
        </>
      )}
    </div>
  );
}