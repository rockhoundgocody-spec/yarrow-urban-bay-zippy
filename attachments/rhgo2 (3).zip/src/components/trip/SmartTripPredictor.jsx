/**
 * SmartTripPredictor
 * Reads user's scan history + current location, asks the AI to predict
 * optimal rockhounding routes, then renders a proactive itinerary card.
 */
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";
import { Loader2, MapPin, Compass, ChevronDown, ChevronUp, Zap, Mountain, AlertTriangle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import ReactMarkdown from "react-markdown";

const DIFF_COLOR = { easy: "#22c55e", moderate: "#f59e0b", difficult: "#ef4444", expert: "#8D7CFF" };

function DiffBadge({ level }) {
  const c = DIFF_COLOR[level] || "#9ca3af";
  return (
    <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full"
      style={{ background: `${c}20`, color: c, border: `1px solid ${c}30` }}>
      {level}
    </span>
  );
}

function RouteCard({ route, idx }) {
  const [open, setOpen] = useState(idx === 0);
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: idx * 0.1 }}
      className="rounded-2xl overflow-hidden"
      style={{ border: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.03)" }}
    >
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-3 px-4 py-3"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: "rgba(0,214,143,0.15)" }}>
            <MapPin className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-left">
            <div className="text-sm font-bold text-white">{route.name}</div>
            <div className="flex items-center gap-2 mt-0.5">
              <DiffBadge level={route.difficulty} />
              {route.distance_km && (
                <span className="text-[11px] text-white/30">{route.distance_km} km</span>
              )}
              {route.expected_finds && (
                <span className="text-[11px] text-emerald-400/70">{route.expected_finds} likely finds</span>
              )}
            </div>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30 shrink-0" /> : <ChevronDown className="w-4 h-4 text-white/30 shrink-0" />}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
              <div className="prose prose-sm prose-invert max-w-none pt-3
                prose-p:text-white/55 prose-p:text-sm prose-p:leading-relaxed prose-p:my-1
                prose-headings:text-emerald-400 prose-headings:text-xs prose-headings:uppercase prose-headings:tracking-widest prose-headings:font-black prose-headings:mt-4 prose-headings:mb-1
                prose-ul:my-1 prose-li:text-white/55 prose-li:text-sm prose-strong:text-white/80">
                <ReactMarkdown>{route.detail}</ReactMarkdown>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function SmartTripPredictor({ compact = false }) {
  const [routes, setRoutes] = useState(null);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState(null);
  const [locError, setLocError] = useState(false);

  const { data: specimens = [] } = useQuery({
    queryKey: ["specimens-trip"],
    queryFn: () => base44.entities.Specimen.list("-created_date", 30),
    staleTime: 5 * 60 * 1000,
  });

  const { data: locations = [] } = useQuery({
    queryKey: ["locations-trip"],
    queryFn: () => base44.entities.RockhoundingLocation.list("-rating_avg", 20),
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      p => setLocation({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => setLocError(true),
      { timeout: 6000 }
    );
  }, []);

  const generate = async () => {
    setLoading(true);
    const mineralHistory = [...new Set(specimens.map(s => s.name).filter(Boolean))].slice(0, 15);
    const nearbyNames = locations.slice(0, 10).map(l => l.name);
    const locStr = location ? `${location.lat.toFixed(3)}, ${location.lng.toFixed(3)}` : "unknown";

    const prompt = `You are an expert field geologist and rockhounding trip planner. Based on the following user data, generate 3 optimal rockhounding trip routes as a JSON array.

User's scan history (minerals identified): ${mineralHistory.join(", ") || "beginner, no history yet"}
Known nearby locations in our database: ${nearbyNames.join(", ") || "none yet"}
User's current GPS: ${locStr}

For each route, generate a JSON object with:
- name: route name (creative, field-accurate)
- difficulty: one of easy/moderate/difficult/expert
- distance_km: estimated one-way distance as a number
- expected_finds: number of likely mineral finds
- detail: 3-4 sentences of markdown describing the geology, what to look for, why this matches the user's history, and the best approach strategy

Return ONLY a raw JSON array — no markdown fences, no explanation.`;

    const result = await base44.integrations.Core.InvokeLLM({ prompt, model: "claude_sonnet_4_6" });
    let parsed = [];
    try {
      const raw = typeof result === "string" ? result : JSON.stringify(result);
      parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {}
    setRoutes(Array.isArray(parsed) ? parsed : []);
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Compass className="w-4 h-4 text-pink-400" />
          <span className="text-xs font-black uppercase tracking-widest text-white/40">AI Trip Predictor</span>
        </div>
        {locError && (
          <div className="flex items-center gap-1 text-amber-400 text-[11px]">
            <AlertTriangle className="w-3 h-3" /> No GPS
          </div>
        )}
      </div>

      {!routes && !loading && (
        <div className="rounded-2xl p-5 text-center space-y-3"
          style={{ border: "1px solid rgba(236,72,153,0.2)", background: "rgba(236,72,153,0.05)" }}>
          <Mountain className="w-8 h-8 mx-auto text-pink-400/60" />
          <p className="text-sm text-white/50">
            Based on your <span className="text-white/70 font-semibold">{specimens.length} scanned specimens</span> and geological trends,
            I can predict your 3 best hounding routes right now.
          </p>
          <button
            onClick={generate}
            className="flex items-center gap-2 mx-auto px-5 py-2.5 rounded-xl font-bold text-sm"
            style={{ background: "rgba(236,72,153,0.15)", border: "1px solid rgba(236,72,153,0.3)", color: "#ec4899" }}
          >
            <Zap className="w-4 h-4" /> Generate My Routes
          </button>
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center gap-3 py-10 text-white/40 text-sm">
          <Loader2 className="w-5 h-5 animate-spin text-pink-400" />
          Analyzing your history + local geology...
        </div>
      )}

      {routes && routes.length > 0 && (
        <div className="space-y-3">
          {routes.map((r, i) => <RouteCard key={i} route={r} idx={i} />)}
          <button
            onClick={() => { setRoutes(null); generate(); }}
            className="text-xs text-white/25 hover:text-white/50 transition-colors mt-1"
          >
            Regenerate routes
          </button>
        </div>
      )}

      {routes && routes.length === 0 && (
        <p className="text-center text-sm text-white/30 py-6">Could not generate routes. Try again.</p>
      )}
    </div>
  );
}