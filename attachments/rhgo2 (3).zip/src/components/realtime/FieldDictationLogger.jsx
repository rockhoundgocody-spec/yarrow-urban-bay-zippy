import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { RealtimeVoiceSession } from '@/services/voice/realtimeVoiceSession';
import { Mic, Square, Copy, Check, Loader2 } from 'lucide-react';

/**
 * Field Dictation Logger — realtime transcription for field notes.
 * Speech-to-text using OpenAI Realtime API.
 */
export default function FieldDictationLogger({ onSave, onClose }) {
  const sessionRef = useRef(null);
  const [state, setState] = useState('idle'); // idle | connecting | live | error
  const [transcript, setTranscript] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [inputLevel, setInputLevel] = useState(0);
  const [copied, setCopied] = useState(false);
  const animationRef = useRef(null);

  useEffect(() => {
    const init = async () => {
      try {
        setState('connecting');

        const res = await base44.functions.invoke('createRealtimeClientSecret', {
          mode: 'transcription',
        });

        if (!res.data?.clientSecret) {
          throw new Error(res.data?.error || 'Failed to start transcription');
        }

        const session = new RealtimeVoiceSession({
          mode: 'transcription',
          onStatus: setState,
          onUserTranscript: (text) => setTranscript((prev) => (prev ? `${prev} ${text}` : text)),
          onError: () => setState('error'),
        });

        await session.connect(res.data.clientSecret);
        // Mic stays muted until the user presses Record.
        session.setMicEnabled(false);
        sessionRef.current = session;
      } catch (error) {
        console.error('Transcription session init failed:', error);
        setState('error');
      }
    };

    init();

    return () => {
      if (sessionRef.current) sessionRef.current.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!isRecording) return undefined;
    const tick = () => {
      setInputLevel(Math.round((sessionRef.current?.getInputLevel() || 0) * 100));
      animationRef.current = requestAnimationFrame(tick);
    };
    animationRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationRef.current);
  }, [isRecording]);

  const toggleRecording = () => {
    if (state !== 'live') return;
    const next = !isRecording;
    sessionRef.current?.setMicEnabled(next);
    setIsRecording(next);
    if (next) setTranscript('');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(transcript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSave = () => {
    onSave?.(transcript);
    setTranscript('');
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 flex items-end"
      style={{
        background: 'rgba(0,0,0,0.5)',
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
      onClick={onClose}
    >
      <motion.div
        className="w-full rounded-t-3xl overflow-hidden"
        style={{
          background: 'linear-gradient(145deg, rgba(10,15,20,0.98) 0%, rgba(14,20,27,0.98) 100%)',
          border: '1px solid rgba(122,231,255,0.2)',
          boxShadow: '0 -8px 48px rgba(0,0,0,0.8)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-cyan-900/20 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-white text-base">Field Notes</h3>
            <p className="text-xs text-white/40">Realtime transcription</p>
          </div>
          <button
            aria-label="Close Field Notes"
            title="Close Field Notes"
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-[rgba(122,231,255,0.15)] transition-colors"
            style={{
              background: 'rgba(122,231,255,0.1)',
              border: '1px solid rgba(122,231,255,0.2)',
              color: '#7AE7FF',
            }}
          >
            Done
          </button>
        </div>

        {/* Content */}
        <div className="px-5 py-5 space-y-4 max-h-96 overflow-y-auto">
          {/* Input level meter */}
          <AnimatePresence>
            {isRecording && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(122,231,255,0.1)' }}>
                  <motion.div
                    className="h-full"
                    style={{
                      background: 'linear-gradient(90deg, #7AE7FF, #00D68F)',
                      width: `${inputLevel}%`,
                    }}
                    animate={{ width: `${inputLevel}%` }}
                    transition={{ duration: 0.1 }}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Transcript display */}
          {transcript ? (
            <div
              className="p-4 rounded-xl text-sm leading-relaxed"
              style={{
                background: 'rgba(122,231,255,0.08)',
                border: '1px solid rgba(122,231,255,0.15)',
                color: '#F3F7FA',
              }}
            >
              {transcript}
            </div>
          ) : (
            <div className="text-center py-8 text-white/30 text-sm">
              {state === 'connecting' ? 'Initializing...' : 'Press Record to start dictating'}
            </div>
          )}

          {/* Status */}
          {state === 'live' && (
            <div className="text-xs text-center" style={{ color: 'rgba(122,231,255,0.5)' }}>
              {isRecording ? '● Recording...' : 'Ready'}
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="px-5 py-4 border-t border-cyan-900/20 space-y-3">
          {/* Record button */}
          <button
            onClick={toggleRecording}
            disabled={state !== 'live'}
            className="w-full py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
            style={{
              background: isRecording ? 'rgba(255,107,107,0.3)' : 'rgba(122,231,255,0.2)',
              border: isRecording ? '1px solid rgba(255,107,107,0.5)' : '1px solid rgba(122,231,255,0.3)',
              color: isRecording ? '#ff6b6b' : '#7AE7FF',
            }}
          >
            {isRecording ? <Square className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </button>

          {/* Action buttons */}
          {transcript && (
            <div className="flex gap-2">
              <button
                onClick={handleCopy}
                className="flex-1 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all"
                style={{
                  background: copied ? 'rgba(0,214,143,0.2)' : 'rgba(122,231,255,0.12)',
                  border: '1px solid rgba(122,231,255,0.25)',
                  color: copied ? '#00D68F' : '#7AE7FF',
                }}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
              <button
                onClick={handleSave}
                className="flex-1 py-3 rounded-xl font-bold text-sm"
                style={{
                  background: 'linear-gradient(135deg, #7AE7FF 0%, #00D68F 100%)',
                  color: '#0a0f14',
                }}
              >
                Save Note
              </button>
            </div>
          )}

          {state === 'connecting' && (
            <div className="flex justify-center py-2">
              <Loader2 className="w-5 h-5 animate-spin" style={{ color: '#7AE7FF' }} />
            </div>
          )}

          {state === 'error' && (
            <div className="text-center text-sm text-red-400">Connection error. Try again.</div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}