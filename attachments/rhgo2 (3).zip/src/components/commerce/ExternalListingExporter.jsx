import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Copy, Download, Share2, CheckCircle2, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ExternalListingExporter({ listing, onExported }) {
  const [loading, setLoading] = useState(false);
  const [packs, setPacks] = useState(null);
  const [activeTab, setActiveTab] = useState('ebay');
  const [copied, setCopied] = useState(null);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke('generateExternalListing', {
        listingId: listing.id,
      });
      setPacks(res.data?.packs);
    } catch (err) {
      console.error('Generation failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text, platform) => {
    navigator.clipboard.writeText(text);
    setCopied(platform);
    setTimeout(() => setCopied(null), 2000);
  };

  if (!packs) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl p-6 space-y-4"
        style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
        <div>
          <h3 className="text-sm font-bold mb-2" style={{ color: '#7AE7FF' }}>External Marketplace Export</h3>
          <p className="text-xs text-white/40 mb-4">Prepare this listing for eBay, Etsy, Facebook Marketplace, or direct share.</p>
        </div>
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full py-3 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
          style={{
            background: 'rgba(122,231,255,0.12)',
            border: '1px solid rgba(122,231,255,0.25)',
            color: '#7AE7FF',
          }}>
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
          {loading ? 'Generating...' : 'Generate Export Package'}
        </button>
      </motion.div>
    );
  }

  const pack = packs[activeTab];
  const platforms = ['ebay', 'etsy', 'facebook', 'direct'];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl p-6 space-y-4"
      style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold" style={{ color: '#7AE7FF' }}>Export Package Ready</h3>
        <CheckCircle2 className="w-4 h-4" style={{ color: '#00D68F' }} />
      </div>

      {/* Platform tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {platforms.map((p) => (
          <button
            key={p}
            onClick={() => setActiveTab(p)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all"
            style={{
              background: activeTab === p ? 'rgba(122,231,255,0.2)' : 'rgba(255,255,255,0.05)',
              color: activeTab === p ? '#7AE7FF' : 'rgba(255,255,255,0.4)',
              border: activeTab === p ? '1px solid rgba(122,231,255,0.4)' : '1px solid rgba(255,255,255,0.06)',
            }}>
            {p.charAt(0).toUpperCase() + p.slice(1).replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Content preview */}
      <div className="rounded-xl p-3 space-y-2" style={{ background: 'rgba(0,0,0,0.2)' }}>
        <p className="text-xs font-semibold text-white/60">Title</p>
        <p className="text-xs text-white/80">{pack.title}</p>

        <p className="text-xs font-semibold text-white/60 mt-3">Price</p>
        <p className="text-sm font-bold" style={{ color: '#F5B642' }}>${pack.price}</p>
      </div>

      {/* Export actions */}
      <div className="flex gap-2">
        <button
          onClick={() => handleCopy(pack.title + '\n\n' + (pack.description || ''), activeTab)}
          className="flex-1 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-2"
          style={{
            background: copied === activeTab ? 'rgba(0,214,143,0.15)' : 'rgba(122,231,255,0.12)',
            border: `1px solid ${copied === activeTab ? 'rgba(0,214,143,0.3)' : 'rgba(122,231,255,0.25)'}`,
            color: copied === activeTab ? '#00D68F' : '#7AE7FF',
          }}>
          {copied === activeTab ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copied === activeTab ? 'Copied!' : 'Copy Listing'}
        </button>
        <button
          className="px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-2"
          style={{
            background: 'rgba(245,182,66,0.12)',
            border: '1px solid rgba(245,182,66,0.25)',
            color: '#F5B642',
          }}>
          <Download className="w-3.5 h-3.5" /> Download
        </button>
      </div>

      <p className="text-[10px] text-white/30 italic">Listing ready for external marketplace posting. Not connected to live APIs — copy/download and post manually.</p>
    </motion.div>
  );
}