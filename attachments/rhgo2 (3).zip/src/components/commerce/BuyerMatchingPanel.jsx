import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Loader2, Users, TrendingUp } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const SEGMENT_COLORS = {
  collectors: '#7AE7FF',
  beginners: '#F5B642',
  decorators: '#8D7CFF',
  lapidary_users: '#00D68F',
  educators: '#FF6B9D',
  dealers: '#00D68F',
  premium_collectors: '#FFD700',
};

const SEGMENT_LABELS = {
  collectors: 'Serious Collectors',
  beginners: 'New Collectors',
  decorators: 'Home Decorators',
  lapidary_users: 'Lapidary Users',
  educators: 'Educators',
  dealers: 'Dealers & Resellers',
  premium_collectors: 'Premium Collectors',
};

export default function BuyerMatchingPanel({ listing }) {
  const [personas, setPersonas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPersonas = async () => {
      try {
        const res = await base44.functions.invoke('matchBuyerPersonas', {
          listingId: listing.id,
        });
        setPersonas(res.data?.buyer_personas || []);
      } catch (err) {
        console.error('Buyer matching failed:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPersonas();
  }, [listing.id]);

  if (loading) {
    return (
      <div className="rounded-2xl p-6 flex items-center justify-center gap-2" style={{ background: 'rgba(255,255,255,0.02)' }}>
        <Loader2 className="w-4 h-4 animate-spin" style={{ color: '#7AE7FF' }} />
        <span className="text-xs text-white/40">Analyzing buyer segments...</span>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl p-6 space-y-4"
      style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
      <div className="flex items-center gap-2">
        <Users className="w-4 h-4" style={{ color: '#7AE7FF' }} />
        <h3 className="text-sm font-bold" style={{ color: '#7AE7FF' }}>Buyer Personas</h3>
      </div>

      <p className="text-xs text-white/40">Who would buy this piece?</p>

      <div className="space-y-2">
        {personas.length > 0 ? (
          personas.slice(0, 3).map((p, i) => (
            <motion.div
              key={p.segment}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="rounded-xl p-3"
              style={{ background: `${SEGMENT_COLORS[p.segment]}15`, border: `1px solid ${SEGMENT_COLORS[p.segment]}30` }}>
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs font-bold mb-1" style={{ color: SEGMENT_COLORS[p.segment] }}>
                    {SEGMENT_LABELS[p.segment]}
                  </p>
                  <p className="text-[10px] text-white/50 leading-tight mb-2">{p.target_behavior}</p>
                  <div className="flex items-center gap-1">
                    <span className="text-[9px] text-white/40">Price range:</span>
                    <span className="text-[10px] font-semibold" style={{ color: SEGMENT_COLORS[p.segment] }}>
                      ${p.ideal_price_range?.min}-${p.ideal_price_range?.max}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-[10px] font-bold px-2 py-1 rounded-lg" style={{ background: SEGMENT_COLORS[p.segment] + '20', color: SEGMENT_COLORS[p.segment] }}>
                    {p.relevance_score}%
                  </span>
                  <span className="text-[9px] text-white/30">{p.best_platform}</span>
                </div>
              </div>
            </motion.div>
          ))
        ) : (
          <p className="text-xs text-white/40 italic">No strong buyer matches. Consider adjusting price or improving listing details.</p>
        )}
      </div>

      {personas.length > 0 && (
        <div className="flex items-center gap-1 text-[9px] text-white/30 pt-2 border-t border-white/10">
          <TrendingUp className="w-3 h-3" />
          Top segment: {SEGMENT_LABELS[personas[0]?.segment] || 'Unknown'}
        </div>
      )}
    </motion.div>
  );
}