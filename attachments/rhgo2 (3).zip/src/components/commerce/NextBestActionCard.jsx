/**
 * NextBestActionCard — Shows seller the most impactful next step
 * Based on trust score, listing status, and seller history
 */
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, ArrowRight, TrendingUp, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function NextBestActionCard({ action, urgency = 'normal' }) {
  const actions = {
    improve_trust: {
      title: 'Improve Trust Score',
      description: 'Add 2-3 more photos and detailed provenance notes',
      icon: TrendingUp,
      color: '#7AE7FF',
      bgColor: 'rgba(122,231,255,0.12)',
      cta: 'Edit Listing'
    },
    add_provenance: {
      title: 'Add Provenance Documentation',
      description: 'Include origin details and collection history to increase buyer confidence',
      icon: CheckCircle2,
      color: '#00D68F',
      bgColor: 'rgba(0,214,143,0.12)',
      cta: 'Add Provenance'
    },
    price_adjustment: {
      title: 'Optimize Pricing',
      description: 'Comparable sales suggest slight adjustment for faster sale',
      icon: TrendingUp,
      color: '#F5B642',
      bgColor: 'rgba(245,182,66,0.12)',
      cta: 'View Comps'
    },
    external_post: {
      title: 'Expand to External Marketplace',
      description: 'List on eBay or Etsy to reach more buyers',
      icon: Zap,
      color: '#00D68F',
      bgColor: 'rgba(0,214,143,0.12)',
      cta: 'Export Listing'
    },
    respond_inquiries: {
      title: 'Respond to Buyer Inquiries',
      description: 'You have 3 unanswered questions. Fast responses increase buyer confidence.',
      icon: AlertCircle,
      color: '#FF6B6B',
      bgColor: 'rgba(255,107,107,0.12)',
      cta: 'View Messages'
    }
  };

  const config = actions[action] || actions.improve_trust;
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-4 flex items-start justify-between"
      style={{ background: config.bgColor, border: `1px solid ${config.color}30` }}>
      <div className="flex items-start gap-3 flex-1">
        <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: `${config.color}20` }}>
          <Icon className="w-5 h-5" style={{ color: config.color }} />
        </div>
        <div>
          <h4 className="font-bold text-white text-sm">{config.title}</h4>
          <p className="text-xs text-white/60 mt-1">{config.description}</p>
        </div>
      </div>
      <button
        className="shrink-0 px-3 py-2 rounded-lg font-bold text-sm transition-all ml-3 flex items-center gap-1.5"
        style={{
          background: config.color + '25',
          border: `1px solid ${config.color}50`,
          color: config.color
        }}>
        {config.cta}
        <ArrowRight className="w-3.5 h-3.5" />
      </button>
    </motion.div>
  );
}