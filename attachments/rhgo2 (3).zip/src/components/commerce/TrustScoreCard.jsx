/**
 * TrustScoreCard — 4-factor breakdown for SellerCommandCenter.
 * Delegates heavy rendering to SellerTrustProfile.
 */
import React from 'react';
import SellerTrustProfile from '@/components/marketplace/SellerTrustProfile';

export default function TrustScoreCard({ listing }) {
  return <SellerTrustProfile listing={listing} />;
}