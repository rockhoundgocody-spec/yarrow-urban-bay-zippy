import React from "react";
import clsx from "clsx";
import { motion } from "framer-motion";
import { Camera } from "lucide-react";
import SpectralRing from "@/components/effects/SpectralRing";
import SpectralGlowField from "@/components/effects/SpectralGlowField";
import ShimmerSweep from "@/components/effects/ShimmerSweep";

export default function ScanOrbCore({
  state = "idle",
  onClick,
  disabled = false,
  ariaLabel = "Open Identify",
}) {
  const shellClass =
    state === "armed"
      ? "border-cyan-300/35 shadow-[0_0_36px_rgba(91,192,255,0.22)]"
      : state === "capture"
        ? "border-white/35 shadow-[0_0_42px_rgba(255,255,255,0.24)]"
        : state === "disabled"
          ? "border-white/10 shadow-none"
          : "border-violet-300/20 shadow-[0_0_26px_rgba(155,109,255,0.16)]";

  const coreClass =
    state === "disabled"
      ? "bg-white/[0.05] border-white/10 text-white/35"
      : "bg-[linear-gradient(135deg,rgba(255,255,255,0.08)_0%,rgba(255,255,255,0.03)_100%)] border-white/15 text-white";

  return (
    <motion.button
      type="button"
      aria-label={ariaLabel}
      onClick={onClick}
      disabled={disabled}
      whileTap={disabled ? undefined : { scale: 0.965 }}
      whileHover={disabled ? undefined : { scale: 1.02 }}
      className={clsx(
        "relative flex h-20 w-20 items-center justify-center overflow-hidden rounded-full border bg-black/20 backdrop-blur-2xl transition-all duration-200",
        disabled && "cursor-not-allowed",
        shellClass
      )}
    >
      <SpectralRing
        tone={state === "capture" ? "white" : state === "armed" ? "cyan" : "default"}
        intensity="md"
      />

      <motion.div
        className="absolute inset-[6px] rounded-full"
        animate={{
          opacity: state === "disabled" ? 0.18 : [0.24, 0.44, 0.24],
          scale: state === "capture" ? [0.96, 1.06, 0.96] : [1, 1.02, 1],
        }}
        transition={{ duration: state === "capture" ? 0.6 : 3.6, repeat: Infinity, ease: "easeInOut" }}
      >
        <div className="h-full w-full rounded-full bg-[radial-gradient(circle_at_30%_30%,rgba(91,192,255,0.28),transparent_28%),radial-gradient(circle_at_68%_34%,rgba(155,109,255,0.24),transparent_26%),radial-gradient(circle_at_50%_74%,rgba(255,201,74,0.18),transparent_28%)]" />
      </motion.div>

      <motion.div
        className={clsx(
          "relative z-10 flex h-14 w-14 items-center justify-center overflow-hidden rounded-full border backdrop-blur-xl",
          coreClass
        )}
        animate={
          state === "capture"
            ? { scale: [1, 0.92, 1.04, 1], rotate: [0, -4, 4, 0] }
            : { rotate: [0, 2, -2, 0] }
        }
        transition={{
          duration: state === "capture" ? 0.45 : 4.8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        <SpectralGlowField mode="orb" />
        <ShimmerSweep tone="cyan" active={state !== "disabled"} />
        <Camera className="relative z-10 h-6 w-6" />
      </motion.div>

      <motion.div
        className="absolute inset-[2px] rounded-full border border-white/8"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      />
    </motion.button>
  );
}