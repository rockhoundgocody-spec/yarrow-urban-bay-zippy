import React, { useState } from "react";
import { CheckCircle, XCircle, AlertCircle, ChevronDown } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";

function FeedbackSuccess() {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-emerald-400"
      style={{ background: "rgba(16,185,129,0.07)", border: "1px solid rgba(16,185,129,0.2)" }}>
      <CheckCircle className="w-3.5 h-3.5 shrink-0" />
      Thanks! Your feedback improves future identifications.
    </div>
  );
}

function FeedbackForm({ resultName, loading, correctedName, setCorrectedName, onSubmit }) {
  return (
    <div className="px-4 pb-4 space-y-3">
      <div className="flex gap-2">
        <button
          onClick={() => onSubmit("correct", resultName)}
          disabled={loading}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold text-emerald-400 transition-all active:scale-95"
          style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)" }}
        >
          <CheckCircle className="w-3.5 h-3.5" /> Yes, correct
        </button>
        <button
          onClick={() => onSubmit("partial", "")}
          disabled={loading}
          className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold text-amber-400 transition-all active:scale-95"
          style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.3)" }}
        >
          <AlertCircle className="w-3.5 h-3.5" /> Partially
        </button>
      </div>

      <div className="space-y-2">
        <input
          value={correctedName}
          onChange={e => setCorrectedName(e.target.value)}
          placeholder="Correct mineral name (if wrong)"
          className="w-full px-3 py-2 rounded-lg text-sm text-white placeholder-white/20 focus:outline-none"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)" }}
        />
        <button
          onClick={() => onSubmit("wrong", correctedName)}
          disabled={loading || !correctedName.trim()}
          className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold text-red-400 transition-all active:scale-95 disabled:opacity-40"
          style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.25)" }}
        >
          <XCircle className="w-3.5 h-3.5" /> Submit correction
        </button>
      </div>
    </div>
  );
}

export default function ConfirmIdentityPanel({ result, photoUrl, geoContext }) {
  const [submitted, setSubmitted] = useState(false);
  const [open, setOpen] = useState(false);
  const [correctedName, setCorrectedName] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (feedbackType, name) => {
    setLoading(true);
    await base44.entities.IdentificationFeedback.create({
      specimen_name: name || result.name,
      ai_predicted_name: result.name,
      confirmed_name: name || (feedbackType === "correct" ? result.name : ""),
      feedback_type: feedbackType,
      photo_url: photoUrl,
      geo_region: geoContext?.geo_region || "",
      formation_type: geoContext?.formation_type || "",
      confidence_score: result.confidence_score,
    });
    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return <FeedbackSuccess />;
  }

  return (
    <div className="rounded-xl overflow-hidden"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-4 py-3 text-xs text-white/40 hover:text-white/60 transition-colors"
      >
        <span>Was this identification correct?</span>
        <ChevronDown className={`w-3.5 h-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0 }} animate={{ height: "auto" }} exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <FeedbackForm
              resultName={result?.name}
              loading={loading}
              correctedName={correctedName}
              setCorrectedName={setCorrectedName}
              onSubmit={submit}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
