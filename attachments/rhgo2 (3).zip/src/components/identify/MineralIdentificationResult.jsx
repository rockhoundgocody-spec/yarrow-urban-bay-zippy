import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Gem, ChevronDown, ChevronUp, FlaskConical, TrendingUp,
  AlertCircle, BookOpen, History, Tag, Layers,
  Eye, Microscope, Globe, Star
} from 'lucide-react';
import PossibleMatchesPanel from '@/components/scan/PossibleMatchesPanel';

const RARITY_COLOR = { common: '#64748b', uncommon: '#22c55e', rare: '#3b82f6', ultra_rare: '#f59e0b' };
const VALUE_COLOR = { low: '#64748b', moderate: '#22c55e', high: '#3b82f6', museum_quality: '#f59e0b' };
const RISK_CONFIG = {
  safe: { color: '#22c55e', label: 'Safe' },
  caution: { color: '#f59e0b', label: 'Caution' },
  destructive: { color: '#ef4444', label: 'Destructive' },
};
const DIAG_COLOR = { high: '#22c55e', medium: '#f59e0b', low: '#64748b' };

function Section({ title, icon: Icon, color = '#7AE7FF', children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${color}18`, background: 'rgba(255,255,255,0.02)' }}>
      <button onClick={() => setOpen(o => !o)} className="w-full flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <Icon className="w-3.5 h-3.5" style={{ color }} />
          <span className="text-xs font-bold uppercase tracking-wider" style={{ color: `${color}cc` }}>{title}</span>
        </div>
        {open ? <ChevronUp className="w-3.5 h-3.5 text-white/20" /> : <ChevronDown className="w-3.5 h-3.5 text-white/20" />}
      </button>
      {open && <div className="px-4 pb-4">{children}</div>}
    </div>
  );
}

function TagList({ items, color }) {
  if (!items?.length) return null;
  return (
    <div className="flex flex-wrap gap-1.5 mt-1">
      {items.map((t, i) => (
        <span key={i} className="text-[11px] px-2 py-0.5 rounded-full font-medium"
          style={{ background: `${color}15`, color, border: `1px solid ${color}30` }}>{t}</span>
      ))}
    </div>
  );
}

function NameRow({ label, value }) {
  if (!value) return null;
  return (
    <div className="flex items-start gap-3 py-2 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <span className="text-[10px] uppercase tracking-wider text-white/25 w-28 flex-shrink-0 pt-0.5">{label}</span>
      <span className="text-xs text-white/75 flex-1">{Array.isArray(value) ? value.join(' · ') : value}</span>
    </div>
  );
}

function ConfidenceRing({ value }) {
  const color = value >= 80 ? '#22c55e' : value >= 55 ? '#f59e0b' : '#ef4444';
  return (
    <div className="flex flex-col items-center">
      <div className="relative w-16 h-16">
        <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
          <circle cx="18" cy="18" r="15.9" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="3" />
          <circle cx="18" cy="18" r="15.9" fill="none" stroke={color} strokeWidth="3"
            strokeDasharray={`${value} 100`} strokeLinecap="round" />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-sm font-black text-white">{value}%</span>
        </div>
      </div>
      <p className="text-[9px] text-white/35 mt-1 uppercase tracking-wider">Confidence</p>
    </div>
  );
}

export default function MineralIdentificationResult({ result, photoUrl, onSaveToCollection }) {
  if (!result) return null;

  const {
    primary_identification, all_names, classification, disambiguation,
    history, description, physical_properties, formation,
    field_identification_traits, field_tests, where_found,
    rarity, value, specimen_assessment, collector_tips
  } = result;

  const pid = primary_identification || {};
  const rarityColor = RARITY_COLOR[rarity?.overall] || '#64748b';
  const valueColor = VALUE_COLOR[value?.collector_grade] || '#64748b';

  // Build the display name hierarchy
  const displayName = pid.variety || pid.sub_variety || pid.mineral_species || 'Unknown Mineral';
  const speciesLine = pid.variety ? `${pid.mineral_species} · ${pid.variety}${pid.sub_variety ? ` · ${pid.sub_variety}` : ''}` : pid.mineral_species;

  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">

      {/* ── Hero Card ── */}
      <div className="rounded-2xl p-4" style={{
        background: 'linear-gradient(135deg, rgba(141,124,255,0.07) 0%, rgba(122,231,255,0.04) 100%)',
        border: '1px solid rgba(141,124,255,0.2)'
      }}>
        <div className="flex items-start gap-4">
          {photoUrl && (
            <img src={photoUrl} alt="Specimen" className="w-20 h-20 rounded-xl object-cover flex-shrink-0"
              style={{ border: '1px solid rgba(255,255,255,0.1)' }} />
          )}
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-black text-white leading-tight">{displayName}</h2>
            {pid.trade_name && (
              <p className="text-xs font-bold text-purple-300/70 mt-0.5">Trade: {pid.trade_name}</p>
            )}
            <p className="text-[11px] text-white/35 mt-0.5">{speciesLine}</p>
            <div className="flex flex-wrap gap-1.5 mt-2">
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                style={{ background: `${rarityColor}20`, color: rarityColor, border: `1px solid ${rarityColor}40` }}>
                {rarity?.overall?.replace('_', ' ').toUpperCase()}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                style={{ background: `${valueColor}20`, color: valueColor, border: `1px solid ${valueColor}40` }}>
                {value?.collector_grade?.replace('_', ' ').toUpperCase()} VALUE
              </span>
              {classification?.chemical_formula && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full"
                  style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.4)', border: '1px solid rgba(255,255,255,0.08)' }}>
                  {classification.chemical_formula}
                </span>
              )}
            </div>
          </div>
          <ConfidenceRing value={pid.confidence || 0} />
        </div>

        {description && (
          <p className="mt-3 text-sm text-white/60 leading-relaxed">{description}</p>
        )}

        {value?.estimated_value_usd && (
          <div className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl"
            style={{ background: 'rgba(245,182,66,0.08)', border: '1px solid rgba(245,182,66,0.2)' }}>
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-xs text-amber-300 font-semibold">Est. Value: {value.estimated_value_usd}</span>
          </div>
        )}

        {onSaveToCollection && (
          <button onClick={() => onSaveToCollection(result)}
            className="mt-3 w-full py-2.5 rounded-xl text-sm font-bold transition-all"
            style={{ background: 'linear-gradient(135deg, rgba(0,214,143,0.2), rgba(122,231,255,0.15))', border: '1px solid rgba(0,214,143,0.35)', color: '#4ade80' }}>
            + Save to Collection
          </button>
        )}
      </div>

      {/* ── Possible Matches — variety of minerals ── */}
      {result.possible_matches?.length > 0 && (
        <PossibleMatchesPanel matches={result.possible_matches} primaryName={pid.variety || pid.mineral_species} />
      )}

      {/* ── Names & Aliases ── */}
      {all_names && (
        <Section title="Names & Aliases" icon={Tag} color="#d4af37">
          <div className="space-y-0">
            <NameRow label="Scientific" value={all_names.scientific_name} />
            <NameRow label="Trade Names" value={all_names.trade_names} />
            <NameRow label="Historical" value={all_names.historical_names} />
            <NameRow label="All Varieties" value={all_names.variety_names} />
            <NameRow label="Regional" value={all_names.regional_names} />
            {all_names.common_confusions?.length > 0 && (
              <div className="pt-2">
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1.5">Commonly Confused With</p>
                <TagList items={all_names.common_confusions} color="#ef4444" />
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Disambiguation ── */}
      {disambiguation?.length > 0 && (
        <Section title="Disambiguation — What It's NOT" icon={AlertCircle} color="#ef4444">
          <p className="text-[11px] text-white/35 mb-3">These are commonly confused — here's how to tell them apart:</p>
          <div className="space-y-3">
            {disambiguation.map((d, i) => (
              <div key={i} className="rounded-xl p-3" style={{ background: 'rgba(239,68,68,0.04)', border: '1px solid rgba(239,68,68,0.15)' }}>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span className="text-sm font-bold text-white/90">{d.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full flex-shrink-0"
                    style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,255,255,0.35)', border: '1px solid rgba(255,255,255,0.08)' }}>
                    {d.relationship}
                  </span>
                </div>
                <p className="text-xs font-semibold text-red-300/80 mb-1">Key difference: {d.key_difference}</p>
                <p className="text-[11px] text-white/45 mb-1">{d.how_to_tell_apart}</p>
                {d.example && (
                  <p className="text-[11px] italic text-white/30">"{d.example}"</p>
                )}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ── History ── */}
      {history && (
        <Section title="History & Origins" icon={History} color="#a78bfa" defaultOpen={false}>
          <div className="space-y-3">
            {history.etymology && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Etymology</p>
                <p className="text-xs text-white/65">{history.etymology}</p>
              </div>
            )}
            {history.named_by && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Named By</p>
                <p className="text-xs text-white/65">{history.named_by}</p>
              </div>
            )}
            {history.historical_use && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Historical Use</p>
                <p className="text-xs text-white/65">{history.historical_use}</p>
              </div>
            )}
            {history.collector_history && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Collector History</p>
                <p className="text-xs text-white/65">{history.collector_history}</p>
              </div>
            )}
            {history.cultural_significance && (
              <div className="rounded-xl p-3" style={{ background: 'rgba(167,139,250,0.06)', border: '1px solid rgba(167,139,250,0.15)' }}>
                <p className="text-[9px] uppercase tracking-wider text-purple-400/60 mb-1">Cultural Significance</p>
                <p className="text-xs text-purple-100/60">{history.cultural_significance}</p>
              </div>
            )}
            {history.famous_occurrences?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1.5">Famous Occurrences</p>
                <ul className="space-y-1">
                  {history.famous_occurrences.map((o, i) => (
                    <li key={i} className="text-[11px] text-white/50 flex items-start gap-1.5">
                      <Star className="w-3 h-3 text-amber-400/40 flex-shrink-0 mt-0.5" />{o}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Classification ── */}
      {classification && (
        <Section title="Classification" icon={Layers} color="#7AE7FF" defaultOpen={false}>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2.5">
            {[
              ['Mineral Class', classification.mineral_class],
              ['Subclass', classification.subclass],
              ['Group', classification.mineral_group],
              ['Crystal System', classification.crystal_system],
              ['Chemical Formula', classification.chemical_formula],
              ['Series', classification.series],
              ['Space Group', classification.space_group],
            ].filter(([, v]) => v).map(([k, v]) => (
              <div key={k}>
                <p className="text-[9px] uppercase tracking-wider text-white/25">{k}</p>
                <p className="text-xs font-semibold text-white/80">{v}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* ── Physical Properties ── */}
      {physical_properties && (
        <Section title="Physical Properties" icon={Microscope} color="#22c55e" defaultOpen={false}>
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-x-4 gap-y-2.5">
              {[
                ['Color', physical_properties.color],
                ['Luster', physical_properties.luster],
                ['Hardness', physical_properties.hardness_mohs],
                ['Cleavage', physical_properties.cleavage],
                ['Fracture', physical_properties.fracture],
                ['Streak', physical_properties.streak],
                ['Transparency', physical_properties.transparency],
                ['Specific Gravity', physical_properties.specific_gravity],
                ['Refractive Index', physical_properties.refractive_index],
                ['Fluorescence', physical_properties.fluorescence],
              ].filter(([, v]) => v).map(([k, v]) => (
                <div key={k}>
                  <p className="text-[9px] uppercase tracking-wider text-white/25">{k}</p>
                  <p className="text-xs font-semibold text-white/80">{v}</p>
                </div>
              ))}
            </div>
            {physical_properties.color_causes && (
              <div className="pt-1">
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">What Causes the Color</p>
                <p className="text-xs text-white/60">{physical_properties.color_causes}</p>
              </div>
            )}
            {physical_properties.special_optical_effects && (
              <div className="rounded-xl p-3 mt-1" style={{ background: 'rgba(122,231,255,0.05)', border: '1px solid rgba(122,231,255,0.15)' }}>
                <p className="text-[9px] uppercase tracking-wider text-cyan-400/60 mb-1">Special Optical Effects</p>
                <p className="text-xs text-cyan-100/65">{physical_properties.special_optical_effects}</p>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Field Identification Traits ── */}
      {field_identification_traits?.length > 0 && (
        <Section title="Field Identification Traits" icon={Eye} color="#4ade80">
          <div className="space-y-3">
            {field_identification_traits.map((t, i) => {
              const trait = typeof t === 'string' ? { trait: `Trait ${i + 1}`, observation: t, significance: '' } : t;
              return (
                <div key={i} className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 text-[10px] font-bold"
                    style={{ background: 'rgba(74,222,128,0.15)', color: '#4ade80' }}>{i + 1}</span>
                  <div>
                    <p className="text-xs font-bold text-white/80">{trait.trait}</p>
                    <p className="text-[11px] text-white/55">{trait.observation}</p>
                    {trait.significance && <p className="text-[10px] text-emerald-400/50 mt-0.5">{trait.significance}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* ── Field Tests ── */}
      {field_tests?.length > 0 && (
        <Section title="Field Tests" icon={FlaskConical} color="#a78bfa" defaultOpen={false}>
          <div className="space-y-3">
            {field_tests.map((test, i) => {
              const rc = RISK_CONFIG[test.risk] || RISK_CONFIG.safe;
              const dc = DIAG_COLOR[test.diagnostic_value] || '#64748b';
              return (
                <div key={i} className="rounded-xl p-3"
                  style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-white/80">{test.test}</span>
                    <div className="flex gap-1">
                      {test.diagnostic_value && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                          style={{ background: `${dc}20`, color: dc }}>{test.diagnostic_value} diag.</span>
                      )}
                      <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: `${rc.color}20`, color: rc.color }}>{rc.label}</span>
                    </div>
                  </div>
                  <p className="text-[11px] text-white/45 mb-1">{test.method}</p>
                  <p className="text-[11px] font-semibold" style={{ color: rc.color }}>→ {test.expected_result}</p>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* ── Formation ── */}
      {formation && (
        <Section title="Formation" icon={Gem} color="#60a5fa" defaultOpen={false}>
          <div className="space-y-2">
            {formation.environment && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Environment</p>
                <p className="text-xs text-white/65">{formation.environment}</p>
              </div>
            )}
            {formation.process && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Process</p>
                <p className="text-xs text-white/65">{formation.process}</p>
              </div>
            )}
            {formation.host_rocks?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Host Rocks</p>
                <TagList items={formation.host_rocks} color="#60a5fa" />
              </div>
            )}
            {formation.associated_minerals?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Associated Minerals</p>
                <TagList items={formation.associated_minerals} color="#a78bfa" />
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Where Found ── */}
      {where_found && (
        <Section title="Where to Find It" icon={Globe} color="#d4af37" defaultOpen={false}>
          <div className="space-y-3">
            {where_found.us_localities?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1.5">US Localities</p>
                <TagList items={where_found.us_localities} color="#d4af37" />
              </div>
            )}
            {where_found.world_localities?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1.5">World Localities</p>
                <TagList items={where_found.world_localities} color="#94a3b8" />
              </div>
            )}
            {where_found.rockhounding_tips && (
              <div className="rounded-xl p-3" style={{ background: 'rgba(212,175,55,0.06)', border: '1px solid rgba(212,175,55,0.2)' }}>
                <p className="text-[9px] uppercase tracking-wider text-amber-400/60 mb-1">Rockhounding Tips</p>
                <p className="text-xs text-amber-100/70">{where_found.rockhounding_tips}</p>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Value & Rarity ── */}
      {(rarity || value) && (
        <Section title="Rarity & Value" icon={TrendingUp} color="#f59e0b" defaultOpen={false}>
          <div className="space-y-3">
            {rarity?.this_variety && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">This Variety's Rarity</p>
                <p className="text-xs text-white/65">{rarity.this_variety}</p>
              </div>
            )}
            {rarity?.notes && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">Rarity Notes</p>
                <p className="text-xs text-white/65">{rarity.notes}</p>
              </div>
            )}
            {value?.value_factors?.length > 0 && (
              <div>
                <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1.5">Value Factors</p>
                <ul className="space-y-1">
                  {value.value_factors.map((f, i) => (
                    <li key={i} className="text-[11px] text-white/50 flex items-start gap-1.5">
                      <span className="text-amber-400/60">·</span>{f}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {value?.gem_quality && (
              <div className="rounded-xl p-3" style={{ background: 'rgba(245,182,66,0.06)', border: '1px solid rgba(245,182,66,0.2)' }}>
                <p className="text-[9px] uppercase tracking-wider text-amber-400/60 mb-1">Gem-Quality Value</p>
                <p className="text-xs text-amber-100/70">{value.gem_quality}</p>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* ── Collector Tips ── */}
      {(collector_tips || specimen_assessment?.this_specimen_notes) && (
        <Section title="Collector Notes" icon={BookOpen} color="#22c55e" defaultOpen={false}>
          {specimen_assessment?.this_specimen_notes && (
            <div className="mb-3">
              <p className="text-[9px] uppercase tracking-wider text-white/25 mb-1">About This Specimen</p>
              <p className="text-xs text-white/65">{specimen_assessment.this_specimen_notes}</p>
            </div>
          )}
          {collector_tips && (
            <div className="rounded-xl p-3" style={{ background: 'rgba(34,197,94,0.06)', border: '1px solid rgba(34,197,94,0.2)' }}>
              <p className="text-xs text-green-100/70">{collector_tips}</p>
            </div>
          )}
        </Section>
      )}

      {/* ── Photo quality note ── */}
      {specimen_assessment?.photo_suggestions && (
        <div className="px-4 py-3 rounded-2xl flex items-start gap-2"
          style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)' }}>
          <AlertCircle className="w-3.5 h-3.5 text-white/25 flex-shrink-0 mt-0.5" />
          <p className="text-[11px] text-white/30">{specimen_assessment.photo_suggestions}</p>
        </div>
      )}
    </motion.div>
  );
}