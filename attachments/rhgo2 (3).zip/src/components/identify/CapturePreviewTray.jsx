import React from "react";

export default function CapturePreviewTray({ captures = [] }) {
  const accepted = captures.filter((c) => c.photoUri);

  if (!accepted.length) return null;

  return (
    <div className="absolute inset-x-4 bottom-48 z-30">
      <div className="flex gap-2 overflow-x-auto rounded-[22px] border border-white/10 bg-black/30 p-2 backdrop-blur-2xl">
        {accepted.map((capture) => (
          <div
            key={capture.key}
            className="w-20 shrink-0 overflow-hidden rounded-[16px] border border-white/10 bg-white/[0.05]"
          >
            {capture.photoUri ? (
              <img
                src={capture.photoUri}
                alt={capture.label}
                className="h-16 w-full object-cover"
              />
            ) : (
              <div className="h-16 w-full bg-white/[0.04]" />
            )}
            <div className="px-2 py-1 text-[10px] uppercase tracking-[0.14em] text-white/70">
              {capture.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}