import React, { memo, useMemo } from "react";
import { motion } from "framer-motion";

function getStroke(trackingState) {
  if (trackingState === "locked") return "rgba(91,192,255,1)";
  if (trackingState === "weak") return "rgba(255,201,74,0.95)";
  if (trackingState === "capturing") return "rgba(255,255,255,1)";
  return "rgba(255,255,255,0.42)";
}

function getFill(trackingState) {
  if (trackingState === "locked") return "rgba(91,192,255,0.08)";
  if (trackingState === "weak") return "rgba(255,201,74,0.05)";
  if (trackingState === "capturing") return "rgba(255,255,255,0.09)";
  return "rgba(255,255,255,0.02)";
}

function getBounds(polygon) {
  if (!polygon || !polygon.length) return null;
  const xs = polygon.map((p) => p.x);
  const ys = polygon.map((p) => p.y);
  return {
    x: Math.min(...xs),
    y: Math.min(...ys),
    width: Math.max(...xs) - Math.min(...xs),
    height: Math.max(...ys) - Math.min(...ys),
  };
}

function AnchorCorners({ bounds, stroke }) {
  if (!bounds) return null;
  const s = 22;
  const sw = 2.4;

  return (
    <g>      
      <path d={`M ${bounds.x} ${bounds.y + s} L ${bounds.x} ${bounds.y} L ${bounds.x + s} ${bounds.y}`} stroke={stroke} strokeWidth={sw} fill="none" />
      <path d={`M ${bounds.x + bounds.width - s} ${bounds.y} L ${bounds.x + bounds.width} ${bounds.y} L ${bounds.x + bounds.width} ${bounds.y + s}`} stroke={stroke} strokeWidth={sw} fill="none" />
      <path d={`M ${bounds.x} ${bounds.y + bounds.height - s} L ${bounds.x} ${bounds.y + bounds.height} L ${bounds.x + s} ${bounds.y + bounds.height}`} stroke={stroke} strokeWidth={sw} fill="none" />
      <path d={`M ${bounds.x + bounds.width - s} ${bounds.y + bounds.height} L ${bounds.x + bounds.width} ${bounds.y + bounds.height} L ${bounds.x + bounds.width} ${bounds.y + bounds.height - s}`} stroke={stroke} strokeWidth={sw} fill="none" />
    </g>
  );
}

function SpecimenContourOverlay({
  polygon,
  confidence = 0,
  trackingState = "searching",
  viewportWidth,
  viewportHeight,
}) {
  const points = useMemo(
    () => (polygon?.length ? polygon.map((p) => `${p.x},${p.y}`).join(" ") : ""),
    [polygon]
  );

  const bounds = useMemo(() => getBounds(polygon), [polygon]);
  const stroke = getStroke(trackingState);
  const fill = getFill(trackingState);

  if (!polygon?.length || !viewportWidth || !viewportHeight) return null;

  return (
    <div className="pointer-events-none absolute inset-0 z-20">
      <svg className="h-full w-full" viewBox={`0 0 ${viewportWidth} ${viewportHeight}`} preserveAspectRatio="none">
        <defs>
          <filter id="spectral-contour-glow">
            <feGaussianBlur stdDeviation="4.2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <linearGradient id="spectral-edge" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(255,255,255,0)" />
            <stop offset="25%" stopColor="rgba(91,192,255,0.95)" />
            <stop offset="60%" stopColor="rgba(155,109,255,0.85)" />
            <stop offset="85%" stopColor="rgba(255,201,74,0.75)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </linearGradient>

          <linearGradient id="contour-sweep" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="rgba(255,255,255,0)" />
            <stop offset="50%" stopColor="rgba(255,255,255,0.85)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0)" />
          </linearGradient>
        </defs>

        <motion.polygon
          points={points}
          fill={fill}
          stroke={stroke}
          strokeWidth="2.4"
          filter="url(#spectral-contour-glow)"
          animate={{
            opacity:
              trackingState === "locked"
                ? [0.75, 1, 0.75]
                : trackingState === "weak"
                  ? [0.3, 0.54, 0.3]
                  : trackingState === "capturing"
                    ? [1, 0.72, 1]
                    : [0.22, 0.38, 0.22],
          }}
          transition={{
            duration: trackingState === "capturing" ? 0.35 : 1.35,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />

        <motion.polygon
          points={points}
          fill="none"
          stroke="url(#spectral-edge)"
          strokeWidth="1.25"
          strokeDasharray="18 12"
          animate={{ strokeDashoffset: [0, -60] }}
          transition={{ duration: 2.8, repeat: Infinity, ease: "linear" }}
        />

        <AnchorCorners bounds={bounds} stroke={stroke} />

        {bounds && trackingState === "locked" && (
          <motion.rect
            x={bounds.x}
            y={bounds.y}
            width={bounds.width}
            height={bounds.height}
            fill="url(#contour-sweep)"
            opacity={0.22}
            animate={{ x: [bounds.x - 56, bounds.x + bounds.width + 56] }}
            transition={{ duration: 1.15, repeat: Infinity, ease: "linear" }}
          />
        )}

        {bounds && (
          <motion.ellipse
            cx={bounds.x + bounds.width / 2}
            cy={bounds.y + bounds.height / 2}
            rx={bounds.width * 0.56}
            ry={bounds.height * 0.56}
            fill="none"
            stroke="rgba(255,255,255,0.10)"
            strokeDasharray="8 12"
            animate={{
              rotate: [0, 360],
              opacity: trackingState === "locked" ? [0.12, 0.25, 0.12] : [0.07, 0.12, 0.07],
            }}
            transition={{ duration: 11, repeat: Infinity, ease: "linear" }}
            transform={`rotate(0 ${bounds.x + bounds.width / 2} ${bounds.y + bounds.height / 2})`}
          />
        )}
      </svg>

      {trackingState === "capturing" && (
        <motion.div
          className="absolute inset-0 bg-white/5"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 0.24, 0] }}
          transition={{ duration: 0.34 }}
        />
      )}
    </div>
  );
}

export default memo(SpecimenContourOverlay);