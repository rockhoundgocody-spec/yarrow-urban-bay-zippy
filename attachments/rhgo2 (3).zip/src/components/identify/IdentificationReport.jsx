import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Hexagon, Thermometer, Sparkles, DollarSign, Save, Star,
  Globe, ShieldCheck, Pickaxe, GitBranch, ChevronDown, ChevronUp, MapPin, Loader2,
  Droplets, Weight, Eye, Diamond, Mountain, Share2, FlaskConical
} from "lucide-react";
import IdentificationFeedback from "./IdentificationFeedback";
import ShareDiscoveryModal from "../social/ShareDiscoveryModal";
import ReferenceComparison from "./ReferenceComparison";
import SaveToCollectionPanel from "./SaveToCollectionPanel";
import ReactMarkdown from "react-markdown";
import { base44 } from "@/api/base44Client";

// ── Rarity config ─────────────────────────────────────────────────────────────
const RARITY = {
  "Common":        { color: "#94a3b8", bg: "rgba(148,163,184,0.1)",  glow: "rgba(148,163,184,0.2)", emoji: "🪨" },
  "Uncommon":      { color: "#22c55e", bg: "rgba(34,197,94,0.1)",    glow: "rgba(34,197,94,0.25)",  emoji: "💚" },
  "Rare":          { color: "#3b82f6", bg: "rgba(59,130,246,0.1)",   glow: "rgba(59,130,246,0.3)",  emoji: "💎" },
  "Very Rare":     { color: "#a855f7", bg: "rgba(168,85,247,0.12)",  glow: "rgba(168,85,247,0.4)",  emoji: "💜" },
  "Extremely Rare":{ color: "#ffd700", bg: "rgba(255,215,0,0.1)",    glow: "rgba(255,215,0,0.5)",   emoji: "👑" },
};

function getRarityConfig(label) {
  return RARITY[label] || RARITY["Common"];
}

// ── Confidence ring ───────────────────────────────────────────────────────────
function ConfidenceRing({ score }) {
  const r = 28, circ = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score || 0));
  const offset = circ - (pct / 100) * circ;
  const color = pct >= 80 ? "#10b981" : pct >= 60 ? "#f59e0b" : "#ef4444";

  return (
    <div className="flex flex-col items-center">
      <svg width="72" height="72" viewBox="0 0 72 72">
        <circle cx="36" cy="36" r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="4" />
        <circle
          cx="36" cy="36" r={r} fill="none"
          stroke={color} strokeWidth="4"
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round"
          transform="rotate(-90 36 36)"
          style={{ filter: `drop-shadow(0 0 6px ${color})`, transition: "stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1)" }}
        />
        <text x="36" y="40" textAnchor="middle" fill={color} fontSize="14" fontWeight="800" fontFamily="Sora, sans-serif">
          {pct}%
        </text>
      </svg>
      <span className="text-[10px] text-white/30 mt-0.5 uppercase tracking-wider">Match</span>
    </div>
  );
}

// ── Property pill ─────────────────────────────────────────────────────────────
function Pill({ icon: Icon, label, value, color = "#f59e0b" }) {
  if (!value && value !== 0) return null;
  return (
    <div className="flex flex-col items-center justify-center p-3 rounded-2xl text-center"
      style={{ background: `${color}09`, border: `1px solid ${color}20`, minWidth: 80 }}>
      <Icon className="w-4 h-4 mb-1.5" style={{ color }} />
      <div className="text-xs font-bold text-white/90">{String(value)}</div>
      <div className="text-[9px] text-white/30 mt-0.5 uppercase tracking-wider leading-none">{label}</div>
    </div>
  );
}

// ── Expandable section ────────────────────────────────────────────────────────
function Section({ icon: Icon, title, color = "#f59e0b", children, defaultOpen = false }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl overflow-hidden" style={{ border: `1px solid ${color}15`, background: `${color}04` }}>
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between gap-3 px-4 py-3.5 text-left"
      >
        <div className="flex items-center gap-2.5">
          <Icon className="w-4 h-4 shrink-0" style={{ color }} />
          <span className="text-sm font-semibold text-white/85">{title}</span>
        </div>
        {open
          ? <ChevronUp className="w-4 h-4 text-white/25 shrink-0" />
          : <ChevronDown className="w-4 h-4 text-white/25 shrink-0" />}
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────
export default function IdentificationReport({ result, photoUrl, onSave, saving, savedSpecimen, standalone, onBoostAccuracy }) {
  const [nearbyLocations, setNearbyLocations] = useState([]);
  const [loadingLocations, setLoadingLocations] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [user, setUser] = useState(null);
  const hasLoadedLocations = useRef(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  useEffect(() => {
    if (result?.name && !hasLoadedLocations.current) {
      hasLoadedLocations.current = true;
      fetchNearbyLocations();
    }
  }, [result]);

  const fetchNearbyLocations = async () => {
    setLoadingLocations(true);
    const mineralNames = [result.name, ...(result.similar_minerals?.map(m => m.name) || [])];
    const allLocations = await base44.entities.RockhoundingLocation.list("-rating_avg", 300);
    const matching = allLocations.filter(loc =>
      loc.minerals_found?.some(m => mineralNames.some(mn => m.toLowerCase().includes(mn.toLowerCase())))
    ).slice(0, 5);
    setNearbyLocations(matching);
    setLoadingLocations(false);
  };

  if (!result) return null;

  const rarity = getRarityConfig(result.rarity_label);

  return (
    <div className="space-y-4 pb-4">

      {/* ── HERO CARD ── */}
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, type: "spring", stiffness: 180 }}
        className="relative rounded-3xl overflow-hidden"
        style={{ border: `1px solid ${rarity.color}30`, boxShadow: `0 0 40px ${rarity.glow}, 0 0 80px ${rarity.glow}40` }}
      >
        {/* Photo */}
        {photoUrl && (
          <div className="relative">
            <img src={photoUrl} alt="Specimen" className="w-full max-h-64 object-contain bg-black/70" />
            <div className="absolute inset-0" style={{ background: `linear-gradient(0deg, #0d0820 0%, transparent 50%)` }} />
          </div>
        )}

        {/* Identity panel */}
        <div className="relative px-5 pb-5" style={{ marginTop: photoUrl ? -32 : 0, paddingTop: photoUrl ? 0 : 20 }}>
          {/* Rarity badge */}
          {result.rarity_label && (
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-3 text-xs font-bold"
              style={{ background: rarity.bg, border: `1px solid ${rarity.color}40`, color: rarity.color }}>
              <Diamond className="w-3 h-3" />
              {rarity.emoji} {result.rarity_label}
            </div>
          )}

          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h1 className="text-3xl font-black text-white leading-tight" style={{ fontFamily: "Sora, sans-serif" }}>
                {result.name}
              </h1>
              <p className="text-white/40 text-sm mt-1 capitalize">{result.category} · {result.color}</p>
            </div>
            <ConfidenceRing score={result.confidence_score} />
          </div>

          {/* Identification note */}
          {result.identification_notes && (
            <div className="mt-3 text-xs text-white/50 leading-relaxed px-3 py-2.5 rounded-xl" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
              {result.identification_notes}
            </div>
          )}

          {/* Action row */}
          <div className="flex gap-2 mt-4">
            {standalone && (
              <button
                onClick={onSave}
                disabled={saving}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl font-bold text-sm text-white transition-all active:scale-95"
                style={{ background: "linear-gradient(120deg, #10b981, #059669)", boxShadow: "0 0 20px rgba(16,185,129,0.35)" }}
              >
                <Save className="w-4 h-4" />
                {saving ? "Saving..." : "Save to Collection"}
              </button>
            )}
            <button
              onClick={() => setShareOpen(true)}
              className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm font-semibold text-cyan-400 transition-all active:scale-95"
              style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.2)" }}
             aria-label="Share">
              <Share2 className="w-4 h-4" />
            </button>
            {onBoostAccuracy && (
              <button
                onClick={onBoostAccuracy}
                className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm font-semibold text-purple-300 transition-all active:scale-95"
                style={{ background: "rgba(168,85,247,0.08)", border: "1px solid rgba(168,85,247,0.25)" }}
                title="Run field tests to boost accuracy"
              >
                <FlaskConical className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </motion.div>

      {/* ── PROPERTY PILLS ── */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="flex gap-2 overflow-x-auto pb-1 no-scrollbar"
      >
        <Pill icon={Thermometer} label="Hardness" value={result.hardness ? `${result.hardness} Mohs` : null} color="#f59e0b" />
        <Pill icon={Weight} label="Sp. Gravity" value={result.specific_gravity} color="#06b6d4" />
        <Pill icon={Droplets} label="Streak" value={result.streak_color} color="#8b5cf6" />
        <Pill icon={Sparkles} label="Luster" value={result.luster} color="#10b981" />
        <Pill icon={Hexagon} label="Crystal" value={result.crystal_system} color="#ec4899" />
        <Pill icon={Eye} label="Transparency" value={result.transparency} color="#f97316" />
        <Pill icon={DollarSign} label="Value" value={result.estimated_value} color="#ffd700" />
      </motion.div>

      {/* ── CONFIDENCE FACTORS ── */}
      {result.confidence_factors?.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="rounded-2xl px-4 py-3"
          style={{ background: "rgba(16,185,129,0.05)", border: "1px solid rgba(16,185,129,0.15)" }}
        >
          <p className="text-[10px] font-bold text-emerald-400/70 uppercase tracking-widest mb-2">Confidence Signals</p>
          <div className="space-y-1">
            {result.confidence_factors.map((f, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-white/50">
                <span className="w-1 h-1 rounded-full bg-emerald-400/60 shrink-0" />
                {f}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* ── FIELD TEST ANALYSIS ── */}
      {result.diagnostic_match && (
        <div className="rounded-2xl px-4 py-3" style={{ background: "rgba(168,85,247,0.05)", border: "1px solid rgba(168,85,247,0.15)" }}>
          <p className="text-[10px] font-bold text-purple-400/70 uppercase tracking-widest mb-2">Field Test Analysis</p>
          <p className="text-xs text-white/55 leading-relaxed">{result.diagnostic_match}</p>
        </div>
      )}

      {/* ── RECOMMENDED TESTS ── */}
      {result.recommended_tests?.length > 0 && (
        <div className="rounded-2xl px-4 py-3" style={{ background: "rgba(245,158,11,0.04)", border: "1px solid rgba(245,158,11,0.12)" }}>
          <div className="flex items-center justify-between mb-2">
            <p className="text-[10px] font-bold text-amber-400/70 uppercase tracking-widest">Recommended Tests</p>
            {onBoostAccuracy && (
              <button onClick={onBoostAccuracy} className="text-[10px] text-purple-400 font-semibold hover:text-purple-300 transition-colors flex items-center gap-1">
                <FlaskConical className="w-3 h-3" /> Run Tests
              </button>
            )}
          </div>
          <div className="space-y-1">
            {result.recommended_tests.map((t, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-white/45">
                <span className="text-amber-400/60">→</span>{t}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── RARITY METER ── */}
      {result.rarity_score != null && (
        <div className="rounded-2xl px-4 py-4" style={{ background: `${rarity.color}06`, border: `1px solid ${rarity.color}20` }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-white/60">Rarity Score</span>
            <span className="text-sm font-black" style={{ color: rarity.color }}>{result.rarity_score}/100</span>
          </div>
          <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${result.rarity_score}%` }}
              transition={{ delay: 0.4, duration: 1, ease: "easeOut" }}
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${rarity.color}88, ${rarity.color})`, boxShadow: `0 0 8px ${rarity.glow}` }}
            />
          </div>
          {result.rarity_notes && <p className="text-xs text-white/40 mt-2 leading-relaxed">{result.rarity_notes}</p>}
        </div>
      )}

      {/* ── COLLAPSIBLE SECTIONS ── */}
      <div className="space-y-2">
        {result.geological_context && (
          <Section icon={Globe} title="Geological Context" color="#06b6d4" defaultOpen>
            <p className="text-sm text-white/55 leading-relaxed">{result.geological_context}</p>
          </Section>
        )}

        {result.formation_history && (
          <Section icon={Mountain} title="Formation History" color="#f97316">
            <p className="text-sm text-white/55 leading-relaxed">{result.formation_history}</p>
          </Section>
        )}

        {result.similar_minerals?.length > 0 && (
          <Section icon={GitBranch} title={`Similar Minerals (${result.similar_minerals.length})`} color="#a855f7">
            <div className="space-y-2">
              {result.similar_minerals.map((m, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-xl" style={{ background: "rgba(168,85,247,0.06)", border: "1px solid rgba(168,85,247,0.12)" }}>
                  <span className="text-xs font-black text-purple-400/60 pt-0.5 w-4 shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-white/85">{m.name}</span>
                      {m.hardness && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/15">Mohs {m.hardness}</span>}
                    </div>
                    {m.key_difference && <p className="text-xs text-amber-400/70 mt-1">🔑 {m.key_difference}</p>}
                    {m.distinguishing_feature && <p className="text-xs text-white/35 mt-0.5">{m.distinguishing_feature}</p>}
                  </div>
                </div>
              ))}
            </div>
          </Section>
        )}

        {result.collecting_tips && (
          <Section icon={Pickaxe} title="Collecting Tips" color="#f59e0b">
            <div className="prose prose-sm prose-invert max-w-none prose-p:text-white/55 prose-li:text-white/55 prose-strong:text-amber-400 prose-p:my-1 prose-ul:my-1">
              <ReactMarkdown>{result.collecting_tips}</ReactMarkdown>
            </div>
          </Section>
        )}

        {result.preservation_methods && (
          <Section icon={ShieldCheck} title="Care & Preservation" color="#10b981">
            <div className="prose prose-sm prose-invert max-w-none prose-p:text-white/55 prose-li:text-white/55 prose-strong:text-emerald-400 prose-p:my-1 prose-ul:my-1">
              <ReactMarkdown>{result.preservation_methods}</ReactMarkdown>
            </div>
          </Section>
        )}

        {/* Nearby Locations */}
        <Section icon={MapPin} title="Where to Find More" color="#10b981">
          {loadingLocations ? (
            <div className="flex items-center gap-2 text-white/40 py-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span className="text-xs">Finding locations...</span>
            </div>
          ) : nearbyLocations.length > 0 ? (
            <div className="space-y-2">
              {nearbyLocations.map(loc => (
                <a key={loc.id} href={`https://maps.google.com/?q=${loc.latitude},${loc.longitude}`} target="_blank" rel="noopener noreferrer"
                  className="flex items-start justify-between gap-2 p-3 rounded-xl transition-all active:scale-[0.98]"
                  style={{ background: "rgba(16,185,129,0.05)", border: "1px solid rgba(16,185,129,0.15)" }}>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white/85">{loc.name}</div>
                    <div className="text-xs text-white/35 mt-0.5">{loc.state}{loc.county && ` · ${loc.county}`}</div>
                    {loc.minerals_found?.length > 0 && (
                      <div className="text-xs text-emerald-400/70 mt-1">{loc.minerals_found.slice(0, 3).join(", ")}</div>
                    )}
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full capitalize shrink-0 mt-0.5"
                    style={{ background: "rgba(16,185,129,0.1)", color: "#10b981", border: "1px solid rgba(16,185,129,0.2)" }}>
                    {loc.difficulty || "moderate"}
                  </span>
                </a>
              ))}
            </div>
          ) : (
            <p className="text-xs text-white/30 py-2">No known locations yet. Be the first to log a find!</p>
          )}
        </Section>

        {result.nearby_formations?.length > 0 && (
          <Section icon={Mountain} title="Likely Nearby Formations" color="#06b6d4">
            <div className="space-y-2">
              {result.nearby_formations.map((f, i) => (
                <div key={i} className="p-3 rounded-xl" style={{ background: "rgba(6,182,212,0.05)", border: "1px solid rgba(6,182,212,0.12)" }}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-semibold text-white/85">{f.formation_name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: "rgba(6,182,212,0.1)", color: "#06b6d4" }}>{f.formation_type}</span>
                  </div>
                  {f.description && <p className="text-xs text-white/40 leading-relaxed">{f.description}</p>}
                  {f.minerals_associated?.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {f.minerals_associated.map((m, j) => (
                        <span key={j} className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/5 text-white/35">{m}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Section>
        )}

        {result.full_report && (
          <Section icon={Star} title="Full Scientific Report" color="#ffd700">
            <div className="prose prose-sm prose-invert max-w-none prose-headings:text-white/90 prose-p:text-white/55 prose-li:text-white/55 prose-strong:text-amber-400 prose-p:my-1.5 prose-ul:my-1.5">
              <ReactMarkdown>{result.full_report}</ReactMarkdown>
            </div>
          </Section>
        )}
      </div>

      {/* ── REFERENCE + SAVE + FEEDBACK ── */}
      <ReferenceComparison result={result} />
      {standalone && <SaveToCollectionPanel result={result} photoUrl={photoUrl} />}
      <IdentificationFeedback specimenName={result.name} specimenId={savedSpecimen?.id} />

      {shareOpen && (
        <ShareDiscoveryModal
          open={shareOpen}
          onClose={() => setShareOpen(false)}
          specimen={{ ...result, photo_url: photoUrl, location_found: result.geological_context }}
          user={user}
        />
      )}
    </div>
  );
}