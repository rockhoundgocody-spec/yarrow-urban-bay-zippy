import React from "react";
import GlassSurface from "@/components/effects/GlassSurface";
import StatusChip from "@/components/ui/StatusChip";

export default function ScanGuidanceRail({
  qualityBucket,
  guidance,
  segmentationConfidence,
  backgroundScore,
}) {
  const tone =
    qualityBucket === "excellent"
      ? "success"
      : qualityBucket === "good"
        ? "info"
        : qualityBucket === "usable"
          ? "warning"
          : "danger";

  return (
    <div className="absolute left-1/2 bottom-32 z-30 w-[min(92vw,460px)] -translate-x-1/2">
      <GlassSurface tone="dark" rounded="lg" className="px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <StatusChip tone={tone}>{qualityBucket}</StatusChip>
          <StatusChip tone="info">
            lock {Math.round((segmentationConfidence || 0) * 100)}%
          </StatusChip>
          <StatusChip tone="default">
            bg {Math.round((backgroundScore || 0) * 100)}%
          </StatusChip>
        </div>

        <div className="mt-3 text-sm leading-6 text-white/85">
          {guidance}
        </div>
      </GlassSurface>
    </div>
  );
}