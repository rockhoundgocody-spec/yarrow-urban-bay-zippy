import React from "react";
import StatusChip from "@/components/ui/StatusChip";

export default function MultiAngleProgressRing({ captures = [], activeAngle }) {
  return (
    <div className="absolute left-4 top-24 z-30">
      <div className="rounded-[24px] border border-white/10 bg-black/35 px-3 py-3 backdrop-blur-2xl">
        <div className="text-[11px] uppercase tracking-[0.18em] text-cyan-300">
          Scan set
        </div>

        <div className="mt-3 flex flex-wrap gap-2 max-w-[220px]">
          {captures.map((capture) => (
            <StatusChip
              key={capture.key}
              tone={
                capture.status === "accepted"
                  ? "success"
                  : capture.key === activeAngle
                    ? "premium"
                    : capture.status === "captured"
                      ? "info"
                      : "default"
              }
            >
              {capture.label}
            </StatusChip>
          ))}
        </div>
      </div>
    </div>
  );
}