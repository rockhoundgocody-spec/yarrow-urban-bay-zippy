import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { CheckCircle2, XCircle, AlertCircle, MessageCircle, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

const OPTIONS = [
  { type: "correct", label: "Correct — looks right", icon: CheckCircle2, color: "text-emerald-400 border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20" },
  { type: "wrong", label: "Wrong rock — not correct", icon: XCircle, color: "text-red-400 border-red-500/30 bg-red-500/10 hover:bg-red-500/20" },
  { type: "missing_info", label: "Missing info — add more details", icon: AlertCircle, color: "text-amber-400 border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20" },
  { type: "other", label: "Other feedback", icon: MessageCircle, color: "text-cyan-400 border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20" },
];

export default function IdentificationFeedback({ specimenName, specimenId }) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState(null);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!selected) return;
    setSaving(true);
    await base44.entities.IdentificationFeedback.create({
      specimen_id: specimenId || "",
      specimen_name: specimenName,
      feedback_type: selected,
      comment: comment || undefined,
    });
    setSubmitted(true);
    setSaving(false);
  };

  if (submitted) {
    return (
      <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
        <CheckCircle2 className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
        <p className="text-sm text-emerald-400 font-medium">Thanks for your feedback!</p>
        <p className="text-xs text-white/40 mt-0.5">It helps improve our AI identification.</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl bg-white/[0.02] border border-white/8">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between p-4 text-left"
      >
        <div>
          <p className="text-sm font-semibold text-white/70">Was this identification correct?</p>
          <p className="text-xs text-white/35 mt-0.5">Help us improve our AI</p>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {open && (
        <div className="px-4 pb-4 space-y-2">
          {OPTIONS.map(({ type, label, icon: Icon, color }) => (
            <button
              key={type}
              onClick={() => setSelected(type)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl border text-sm font-medium transition-all ${color} ${selected === type ? "ring-1 ring-white/20" : ""}`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              {label}
            </button>
          ))}

          {selected && (
            <div className="pt-1 space-y-2">
              <Textarea
                placeholder="Optional: add more context..."
                value={comment}
                onChange={e => setComment(e.target.value)}
                className="bg-white/5 border-white/10 text-white text-sm resize-none h-20"
              />
              <Button
                onClick={handleSubmit}
                disabled={saving}
                className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white"
              >
                {saving ? "Submitting..." : "Submit Feedback"}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}