import React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Thermometer, Droplets, Sparkles, Hexagon, Eye, Palette, Layers, Zap } from "lucide-react";

const LUSTER_OPTIONS = ["metallic", "vitreous", "pearly", "silky", "resinous", "adamantine", "waxy", "dull", "earthy"];
const CRYSTAL_OPTIONS = ["cubic", "tetragonal", "orthorhombic", "hexagonal", "trigonal", "monoclinic", "triclinic", "amorphous", "unknown"];
const TRANSPARENCY_OPTIONS = ["transparent", "translucent", "opaque"];
const FRACTURE_OPTIONS = ["conchoidal", "uneven", "hackly", "splintery", "earthy"];

function Field({ icon: Icon, label, children }) {
  return (
    <div className="space-y-1.5">
      <Label className="flex items-center gap-1.5 text-xs text-white/50 uppercase tracking-wider">
        <Icon className="w-3 h-3" /> {label}
      </Label>
      {children}
    </div>
  );
}

export default function PropertyForm({ properties, onChange }) {
  const set = (key, val) => onChange({ ...properties, [key]: val });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Field icon={Palette} label="Color">
          <Input
            placeholder="e.g. golden, dark green"
            value={properties.color || ""}
            onChange={e => set("color", e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/25 h-9 text-sm"
          />
        </Field>
        <Field icon={Thermometer} label="Hardness (Mohs)">
          <Input
            type="number"
            min={1} max={10} step={0.5}
            placeholder="1–10"
            value={properties.hardness || ""}
            onChange={e => set("hardness", e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/25 h-9 text-sm"
          />
        </Field>
        <Field icon={Droplets} label="Streak Color">
          <Input
            placeholder="e.g. white, red-brown"
            value={properties.streak || ""}
            onChange={e => set("streak", e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/25 h-9 text-sm"
          />
        </Field>
        <Field icon={Sparkles} label="Luster">
          <Select value={properties.luster || ""} onValueChange={v => set("luster", v)}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white h-9 text-sm">
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {LUSTER_OPTIONS.map(o => <SelectItem key={o} value={o} className="capitalize">{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field icon={Hexagon} label="Crystal System">
          <Select value={properties.crystal_system || ""} onValueChange={v => set("crystal_system", v)}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white h-9 text-sm">
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {CRYSTAL_OPTIONS.map(o => <SelectItem key={o} value={o} className="capitalize">{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field icon={Eye} label="Transparency">
          <Select value={properties.transparency || ""} onValueChange={v => set("transparency", v)}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white h-9 text-sm">
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {TRANSPARENCY_OPTIONS.map(o => <SelectItem key={o} value={o} className="capitalize">{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field icon={Layers} label="Cleavage">
          <Input
            placeholder="e.g. perfect in 2 directions"
            value={properties.cleavage || ""}
            onChange={e => set("cleavage", e.target.value)}
            className="bg-white/5 border-white/10 text-white placeholder:text-white/25 h-9 text-sm"
          />
        </Field>
        <Field icon={Zap} label="Fracture">
          <Select value={properties.fracture || ""} onValueChange={v => set("fracture", v)}>
            <SelectTrigger className="bg-white/5 border-white/10 text-white h-9 text-sm">
              <SelectValue placeholder="Select..." />
            </SelectTrigger>
            <SelectContent>
              {FRACTURE_OPTIONS.map(o => <SelectItem key={o} value={o} className="capitalize">{o}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
      </div>
      <Field icon={Sparkles} label="Additional Notes">
        <Textarea
          placeholder="Describe shape, weight, texture, where you found it..."
          value={properties.notes || ""}
          onChange={e => set("notes", e.target.value)}
          className="bg-white/5 border-white/10 text-white placeholder:text-white/25 text-sm min-h-[70px]"
        />
      </Field>
    </div>
  );
}