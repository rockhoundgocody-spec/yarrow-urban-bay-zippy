import React, { useState } from "react";
import { ChevronDown, MapPin } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const GEO_REGIONS = [
  "Basin and Range (SW USA)",
  "Colorado Plateau",
  "Sierra Nevada",
  "Rocky Mountains",
  "Appalachian Mountains",
  "Pacific Coast Ranges",
  "Great Plains",
  "Canadian Shield",
  "Mojave Desert",
  "Sonoran Desert",
  "Black Hills (SD)",
  "Ozark Plateau",
  "Alaska Range",
  "Hawaii (Volcanic)",
  "Other / Unknown",
];

const FORMATION_TYPES = [
  "Igneous — Granite",
  "Igneous — Basalt",
  "Igneous — Rhyolite",
  "Igneous — Obsidian",
  "Sedimentary — Sandstone",
  "Sedimentary — Limestone",
  "Sedimentary — Shale",
  "Sedimentary — Conglomerate",
  "Metamorphic — Schist",
  "Metamorphic — Gneiss",
  "Metamorphic — Marble",
  "Metamorphic — Quartzite",
  "Hydrothermal Vein",
  "Alluvial / Stream",
  "Volcanic / Lava Flow",
  "Other / Unknown",
];

export default function GeoContextPanel({ value, onChange }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="mt-3">
      <button
        onClick={() => setOpen(v => !v)}
        className="flex items-center gap-2 text-xs text-white/40 hover:text-white/60 transition-colors"
      >
        <MapPin className="w-3.5 h-3.5" />
        <span>{value.geo_region || value.formation_type ? "Geo context added ✓" : "Add geological context (improves accuracy)"}</span>
        <ChevronDown className={`w-3 h-3 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="mt-2 p-3 rounded-xl space-y-3"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>

              <div>
                <label className="text-xs text-white/30 uppercase tracking-wider mb-1.5 block">Geological Region</label>
                <select
                  value={value.geo_region || ""}
                  onChange={e => onChange({ ...value, geo_region: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg text-sm text-white bg-transparent focus:outline-none"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                >
                  <option value="">— Select region —</option>
                  {GEO_REGIONS.map(r => <option key={r} value={r} className="bg-gray-900">{r}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs text-white/30 uppercase tracking-wider mb-1.5 block">Formation / Rock Type</label>
                <select
                  value={value.formation_type || ""}
                  onChange={e => onChange({ ...value, formation_type: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg text-sm text-white bg-transparent focus:outline-none"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                >
                  <option value="">— Select formation —</option>
                  {FORMATION_TYPES.map(f => <option key={f} value={f} className="bg-gray-900">{f}</option>)}
                </select>
              </div>

              <div>
                <label className="text-xs text-white/30 uppercase tracking-wider mb-1.5 block">Notes (optional)</label>
                <input
                  value={value.notes || ""}
                  onChange={e => onChange({ ...value, notes: e.target.value })}
                  placeholder="e.g. 'found in dry creek bed, elevation ~4200ft'"
                  className="w-full px-3 py-2 rounded-lg text-sm text-white placeholder-white/20 focus:outline-none"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}