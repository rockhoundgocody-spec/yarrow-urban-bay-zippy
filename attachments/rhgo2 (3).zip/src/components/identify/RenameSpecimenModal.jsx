import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { saveSecureData, loadSecureData } from "@/lib/secureStorage";
import { X, PenLine, CheckSquare, Square, AlertTriangle, CheckCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

const CHECKLIST = [
  "I physically held and examined the specimen",
  "I tested hardness (fingernail, coin, or knife blade)",
  "I observed the luster (metallic, glassy, dull, silky, etc.)",
  "I checked for cleavage planes or conchoidal fracture",
];

const DAILY_LIMIT = 5;
const STORAGE_KEY = "rh_renames";

function getRenameRecord() {
  try {
    const today = new Date().toDateString();
    const parsed = loadSecureData(STORAGE_KEY);
    if (!parsed || parsed.date !== today) return { date: today, count: 0 };
    return parsed;
  } catch {
    return { date: new Date().toDateString(), count: 0 };
  }
}

function incrementRenameCount() {
  const rec = getRenameRecord();
  saveSecureData(STORAGE_KEY, { ...rec, count: rec.count + 1 });
}

export default function RenameSpecimenModal({ specimen, onClose, onRenamed }) {
  const [checked, setChecked] = useState([false, false, false, false]);
  const [newName, setNewName] = useState(specimen?.name || "");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const rec = getRenameRecord();
  const remaining = DAILY_LIMIT - rec.count;
  const allChecked = checked.every(Boolean);
  const canSubmit = allChecked && newName.trim().length > 1 && newName.trim() !== specimen?.name && remaining > 0;

  const toggle = (i) => setChecked(prev => prev.map((v, idx) => idx === i ? !v : v));

  const handleSave = async () => {
    if (!canSubmit || saving) return;
    setSaving(true);
    const trimmed = newName.trim();
    await base44.entities.Specimen.update(specimen.id, {
      name: trimmed,
      is_user_renamed: true,
    });
    incrementRenameCount();
    setDone(true);
    setTimeout(() => {
      onRenamed(trimmed);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>

      <motion.div
        initial={{ y: 80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 80, opacity: 0 }}
        transition={{ type: "spring", damping: 28, stiffness: 320 }}
        className="w-full max-w-lg mx-auto rounded-t-3xl p-5 space-y-5"
        style={{ background: "linear-gradient(180deg, #0E0B1E 0%, #06040F 100%)", border: "1px solid rgba(141,124,255,0.2)", borderBottom: "none" }}>

        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PenLine className="w-4 h-4" style={{ color: "#8D7CFF" }} />
            <p className="text-sm font-bold text-white">Override Identification</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg" style={{ color: "rgba(255,255,255,0.3)" }} aria-label="Close">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Warning banner */}
        <div className="flex items-start gap-3 p-3 rounded-xl"
          style={{ background: "rgba(245,182,66,0.08)", border: "1px solid rgba(245,182,66,0.2)" }}>
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" style={{ color: "#F5B642" }} />
          <div className="space-y-0.5">
            <p className="text-xs font-bold" style={{ color: "#F5B642" }}>Zero XP for renamed specimens</p>
            <p className="text-[11px] leading-snug" style={{ color: "rgba(245,182,66,0.6)" }}>
              Manually overriding an AI result removes XP for this specimen. The original AI result is preserved in the record.
            </p>
          </div>
        </div>

        {/* Rate limit indicator */}
        <div className="flex items-center justify-between px-1">
          <p className="text-[11px]" style={{ color: "rgba(255,255,255,0.35)" }}>Daily renames remaining</p>
          <div className="flex gap-1">
            {Array.from({ length: DAILY_LIMIT }).map((_, i) => (
              <div key={i} className="w-4 h-1.5 rounded-full"
                style={{ background: i < remaining ? "rgba(141,124,255,0.6)" : "rgba(255,255,255,0.1)" }} />
            ))}
          </div>
          <p className="text-[11px] font-bold" style={{ color: remaining > 0 ? "#8D7CFF" : "#ff6b6b" }}>
            {remaining}/{DAILY_LIMIT}
          </p>
        </div>

        {remaining <= 0 && (
          <div className="p-3 rounded-xl text-center"
            style={{ background: "rgba(255,107,107,0.08)", border: "1px solid rgba(255,107,107,0.2)" }}>
            <p className="text-xs font-bold" style={{ color: "#ff6b6b" }}>Daily limit reached</p>
            <p className="text-[11px] mt-0.5" style={{ color: "rgba(255,107,107,0.5)" }}>You can rename up to {DAILY_LIMIT} specimens per day. Resets at midnight.</p>
          </div>
        )}

        {/* Field verification checklist */}
        {remaining > 0 && (
          <div className="space-y-2">
            <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>
              Field verification checklist
            </p>
            <p className="text-[11px]" style={{ color: "rgba(255,255,255,0.25)" }}>
              Complete all tests before overriding. This prevents misuse and keeps the data accurate.
            </p>
            <div className="space-y-2 mt-2">
              {CHECKLIST.map((item, i) => (
                <button key={i} onClick={() => toggle(i)}
                  className="w-full flex items-start gap-3 p-3 rounded-xl text-left transition-all"
                  style={{
                    background: checked[i] ? "rgba(141,124,255,0.1)" : "rgba(255,255,255,0.02)",
                    border: `1px solid ${checked[i] ? "rgba(141,124,255,0.35)" : "rgba(255,255,255,0.07)"}`,
                  }}>
                  {checked[i]
                    ? <CheckSquare className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "#8D7CFF" }} />
                    : <Square className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "rgba(255,255,255,0.2)" }} />}
                  <p className="text-xs leading-snug" style={{ color: checked[i] ? "rgba(255,255,255,0.8)" : "rgba(255,255,255,0.4)" }}>
                    {item}
                  </p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Name input — only shown after all checks */}
        <AnimatePresence>
          {allChecked && remaining > 0 && (
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-2">
              <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>
                Corrected name
              </p>
              <input
                value={newName}
                onChange={e => setNewName(e.target.value)}
                placeholder="e.g. Pyrite, Amethyst, Calcite..."
                className="w-full px-4 py-3 rounded-xl text-sm text-white placeholder:text-white/20 focus:outline-none"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(141,124,255,0.3)" }}
                maxLength={80}
                autoFocus
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Submit */}
        {remaining > 0 && (
          <button
            onClick={handleSave}
            disabled={!canSubmit || saving}
            className="w-full py-3.5 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2"
            style={{
              background: canSubmit ? "rgba(141,124,255,0.2)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${canSubmit ? "rgba(141,124,255,0.5)" : "rgba(255,255,255,0.08)"}`,
              color: canSubmit ? "#C4B5FD" : "rgba(255,255,255,0.2)",
              cursor: canSubmit ? "pointer" : "not-allowed",
            }}>
            {done
              ? <><CheckCircle className="w-4 h-4" /> Saved — 0 XP applied</>
              : saving ? "Saving..." : "Override Identification"}
          </button>
        )}
      </motion.div>
    </div>
  );
}