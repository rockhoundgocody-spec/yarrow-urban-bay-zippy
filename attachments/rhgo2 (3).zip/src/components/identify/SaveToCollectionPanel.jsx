import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Save, CheckCircle2, ExternalLink, Loader2, MapPin } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function SaveToCollectionPanel({ result, photoUrl }) {
  const [state, setState] = useState("idle"); // idle | saving | saved | error
  const [savedId, setSavedId] = useState(null);
  const [locationNote, setLocationNote] = useState("");

  const handleSave = async () => {
    setState("saving");
    try {
      const specimenData = {
        name: result.name,
        photo_url: photoUrl,
        category: result.category,
        hardness: result.hardness,
        crystal_system: result.crystal_system,
        mineral_composition: result.mineral_composition,
        color: result.color,
        luster: result.luster,
        formation_history: result.formation_history,
        geological_significance: result.geological_significance,
        estimated_value: result.estimated_value,
        confidence_score: result.confidence_score,
        notes: locationNote || undefined,
        full_report: result.full_report,
      };
      const saved = await base44.entities.Specimen.create(specimenData);
      setSavedId(saved.id);
      setState("saved");
      if (navigator.vibrate) navigator.vibrate([10, 50, 10]);
    } catch {
      setState("error");
    }
  };

  if (state === "saved") {
    return (
      <div className="rounded-2xl p-4 flex flex-col gap-3"
        style={{ background: "linear-gradient(135deg, rgba(16,185,129,0.1), rgba(5,150,105,0.08))", border: "1px solid rgba(16,185,129,0.3)" }}>
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          <span className="text-sm font-semibold text-emerald-300">Saved to your collection!</span>
        </div>
        <p className="text-xs text-white/40">
          <strong className="text-white/70">{result.name}</strong> has been added to your personal collection.
        </p>
        <Link
          to={createPageUrl("Collection")}
          className="flex items-center justify-center gap-2 w-full py-2.5 rounded-xl text-sm font-medium text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/10 transition-colors"
        >
          View Collection <ExternalLink className="w-3.5 h-3.5" />
        </Link>
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4 space-y-3"
      style={{ background: "rgba(245,158,11,0.05)", border: "1px solid rgba(245,158,11,0.2)" }}>
      <div className="flex items-center gap-2">
        <Save className="w-4 h-4 text-amber-400" />
        <span className="text-sm font-semibold text-white/80">Save to Collection</span>
      </div>

      <div className="flex items-center gap-2 p-2 rounded-xl bg-white/[0.03] border border-white/5">
        <MapPin className="w-3.5 h-3.5 text-white/30 shrink-0" />
        <input
          type="text"
          placeholder="Add location note (optional)"
          value={locationNote}
          onChange={(e) => setLocationNote(e.target.value)}
          className="flex-1 bg-transparent text-sm text-white/70 placeholder:text-white/25 outline-none min-w-0"
        />
      </div>

      {state === "error" && (
        <p className="text-xs text-red-400">Failed to save. Please try again.</p>
      )}

      <Button
        onClick={handleSave}
        disabled={state === "saving"}
        className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white hover:opacity-90"
      >
        {state === "saving" ? (
          <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Saving...</>
        ) : (
          <><Save className="w-4 h-4 mr-2" />Save to Collection</>
        )}
      </Button>
    </div>
  );
}