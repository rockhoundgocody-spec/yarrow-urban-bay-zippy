/**
 * IdentifyCameraOverlay — Scan screen HUD. Shock Pass v1.
 * Chamber-grade authority, not a scan widget.
 */

import React, { memo, useMemo } from "react";
import { ArrowLeft, Zap, ZapOff, Focus, AlertTriangle, ScanSearch, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

/* ─── State config ────────────────────────────────────────────────── */
function getStatus(trackingState, confidence, captureBusy, cameraReady, canCapture) {
  if (!cameraReady)    return { title: "Initializing Chamber",  sub: "Preparing crystal scan field",     tone: "text-white/70",  accent: "rgba(255,255,255,0.35)", icon: <ScanSearch className="h-4 w-4" /> };
  if (captureBusy)     return { title: "Capturing Specimen",    sub: "Locking crystal contour…",          tone: "text-cyan-300",  accent: "#7DF9FF",                icon: <Sparkles className="h-4 w-4" /> };
  if (trackingState === "locked") return { title: "Specimen Locked",  sub: `Signal strength ${Math.round(confidence * 100)}%`,   tone: "text-cyan-300",  accent: "#7DF9FF",                icon: <Focus className="h-4 w-4" /> };
  if (trackingState === "weak")   return { title: "Partial Signal",   sub: "Move closer — simplify field",  tone: "text-amber-300", accent: "#FFD700",                icon: <AlertTriangle className="h-4 w-4" /> };
  return { title: "Scanning Chamber", sub: canCapture ? "Orb armed — hold still" : "Place specimen in frame", tone: "text-white/75",  accent: "rgba(125,249,255,0.55)", icon: <ScanSearch className="h-4 w-4" /> };
}

/* ─── Hint rail ───────────────────────────────────────────────────── */
function HintRail({ trackingState, cameraReady, captureBusy }) {
  const hints = useMemo(() => {
    if (!cameraReady || captureBusy) return [];
    if (trackingState === "locked")  return ["Contour stable", "Orb will capture", "Single subject ideal"];
    if (trackingState === "weak")    return ["Simplify background", "Move closer", "Reduce reflections"];
    return ["Center specimen", "Plain background", "Steady hold"];
  }, [trackingState, cameraReady, captureBusy]);

  return (
    <AnimatePresence>
      {hints.length > 0 && (
        <motion.div
          key={trackingState}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 6 }}
          className="absolute bottom-36 left-1/2 z-30 w-[min(92vw,400px)] -translate-x-1/2"
        >
          <div
            className="flex flex-wrap items-center justify-center gap-2 rounded-2xl px-4 py-3"
            style={{ background: "rgba(5,7,10,0.80)", backdropFilter: "blur(16px)", border: "1px solid rgba(255,255,255,0.07)" }}
          >
            {hints.map((h, i) => (
              <span
                key={i}
                className="rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.16em] text-white/65"
                style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                {h}
              </span>
            ))}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─── Signal bar ──────────────────────────────────────────────────── */
function SignalBar({ confidence, trackingState }) {
  const color = trackingState === "locked" ? "#7DF9FF" : trackingState === "weak" ? "#FFD700" : "rgba(255,255,255,0.25)";
  return (
    <div className="absolute left-1/2 top-[72px] z-30 -translate-x-1/2">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        className="flex items-center gap-2 rounded-full px-4 py-1.5"
        style={{ background: "rgba(5,7,10,0.85)", backdropFilter: "blur(12px)", border: `1px solid ${color}35` }}
      >
        {/* Signal pips */}
        <div className="flex gap-0.5 items-end h-4">
          {[0.25, 0.5, 0.75, 1].map((threshold, i) => (
            <div
              key={i}
              className="w-1 rounded-sm transition-all duration-300"
              style={{
                height: 6 + i * 3,
                background: confidence >= threshold ? color : "rgba(255,255,255,0.12)",
                boxShadow: confidence >= threshold ? `0 0 4px ${color}` : "none",
              }}
            />
          ))}
        </div>
        <span className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color }}>
          {trackingState === "locked" ? "LOCKED" : trackingState === "weak" ? "PARTIAL" : "SCANNING"}
        </span>
        <span className="text-[10px] text-white/35">{Math.round(confidence * 100)}%</span>
      </motion.div>
    </div>
  );
}

/* ─── Main overlay ────────────────────────────────────────────────── */
function IdentifyCameraOverlay({
  trackingState = "searching",
  confidence = 0,
  captureBusy = false,
  cameraReady = false,
  canCapture = false,
  flashMode = "off",
  onToggleFlash,
  onBack,
}) {
  const status = getStatus(trackingState, confidence, captureBusy, cameraReady, canCapture);
  const isLocked = trackingState === "locked";

  return (
    <div className="pointer-events-none absolute inset-0 z-30">
      {/* Top vignette — deeper */}
      <div className="absolute inset-x-0 top-0 h-44" style={{ background: "linear-gradient(to bottom, rgba(4,8,14,0.88) 0%, rgba(4,8,14,0.35) 65%, transparent 100%)" }} />
      {/* Bottom vignette */}
      <div className="absolute inset-x-0 bottom-0 h-56" style={{ background: "linear-gradient(to top, rgba(4,8,14,0.92) 0%, rgba(4,8,14,0.40) 60%, transparent 100%)" }} />

      {/* Corner scan frames */}
      {isLocked && (
        <>
          {[["top-[22%] left-[10%]", "border-t border-l"], ["top-[22%] right-[10%]", "border-t border-r"], ["bottom-[30%] left-[10%]", "border-b border-l"], ["bottom-[30%] right-[10%]", "border-b border-r"]].map(([pos, border], i) => (
            <motion.div
              key={i}
              className={`absolute h-6 w-6 ${pos} ${border}`}
              style={{ borderColor: "#7DF9FF", borderWidth: 2 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 1.8, repeat: Infinity, delay: i * 0.12 }}
            />
          ))}
        </>
      )}

      {/* Top nav bar */}
      <div className="absolute inset-x-0 top-0 px-4 pt-[max(env(safe-area-inset-top),12px)]">
        <div className="pointer-events-auto flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onBack}
            className="flex h-11 w-11 items-center justify-center rounded-full text-white transition-all active:scale-90"
            style={{ background: "rgba(5,7,10,0.75)", backdropFilter: "blur(14px)", border: "1px solid rgba(255,255,255,0.10)" }}
           aria-label="Back">
            <ArrowLeft className="h-5 w-5" />
          </button>

          {/* Status pill */}
          <AnimatePresence mode="wait">
            <motion.div
              key={status.title}
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 4 }}
              className="min-w-0 flex-1 text-center"
            >
              <div
                className="inline-flex flex-col items-center rounded-2xl px-5 py-2.5"
                style={{
                  background: "rgba(5,7,10,0.82)",
                  backdropFilter: "blur(16px)",
                  border: `1px solid ${status.accent}30`,
                  boxShadow: isLocked ? `0 0 20px rgba(125,249,255,0.15)` : "none",
                }}
              >
                <div className={`flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.20em] ${status.tone}`}>
                  {status.icon}
                  {status.title}
                </div>
                <div className="mt-0.5 text-[10px] text-white/40">{status.sub}</div>
              </div>
            </motion.div>
          </AnimatePresence>

          <button
            type="button"
            onClick={onToggleFlash}
            className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full text-white transition-all active:scale-90"
            style={{ background: flashMode === "on" ? "rgba(125,249,255,0.15)" : "rgba(5,7,10,0.75)", backdropFilter: "blur(14px)", border: `1px solid ${flashMode === "on" ? "rgba(125,249,255,0.30)" : "rgba(255,255,255,0.10)"}` }}
          >
            {flashMode === "on"
              ? <Zap className="h-5 w-5 text-cyan-300" />
              : <ZapOff className="h-5 w-5 text-white/60" />
            }
          </button>
        </div>
      </div>

      {/* Signal bar */}
      <SignalBar confidence={confidence} trackingState={trackingState} />

      {/* Hint rail */}
      <HintRail trackingState={trackingState} cameraReady={cameraReady} captureBusy={captureBusy} />

      {/* Bottom orb status */}
      <div className="absolute bottom-[108px] left-1/2 -translate-x-1/2">
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: canCapture ? 1.2 : 2.5, repeat: Infinity }}
          className="text-[10px] font-bold uppercase tracking-[0.22em]"
          style={{ color: canCapture ? "#7DF9FF" : "rgba(255,255,255,0.30)" }}
        >
          {canCapture ? "● Orb Armed" : "○ Awaiting Lock"}
        </motion.div>
      </div>
    </div>
  );
}

export default memo(IdentifyCameraOverlay);