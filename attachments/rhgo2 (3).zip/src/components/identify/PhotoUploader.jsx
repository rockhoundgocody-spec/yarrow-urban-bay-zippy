import React, { useRef, useState } from "react";
import { Camera, Upload, Sparkles, Loader2, RotateCcw, Gem, Microscope, Zap, Plus, X, Image } from "lucide-react";
import { base44 } from "@/api/base44Client";

const TIPS = [
  "Upload multiple angles for the most accurate identification",
  "Place your specimen on a plain white or dark background",
  "Make sure the lighting is even with no harsh shadows",
  "Include something for scale — like a coin",
  "Clean the specimen for a clearer identification",
  "Capture the streak color on a tile for better mineral ID",
];

const EXAMPLES = [
  { label: "Quartz", color: "from-violet-500/20 to-purple-600/20", icon: "💎" },
  { label: "Pyrite", color: "from-yellow-500/20 to-amber-600/20", icon: "✨" },
  { label: "Obsidian", color: "from-slate-500/20 to-gray-700/20", icon: "🪨" },
  { label: "Amethyst", color: "from-purple-500/20 to-pink-600/20", icon: "💜" },
];

export default function PhotoUploader({ onPhotosUploaded, isProcessing, renderTrigger, compact }) {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [previews, setPreviews] = useState([]); // [{file, previewUrl, uploadedUrl}]
  const [dragOver, setDragOver] = useState(false);
  const [tipIndex] = useState(() => Math.floor(Math.random() * TIPS.length));

  const handleFiles = async (files) => {
    const imageFiles = Array.from(files).filter(f => f.type.startsWith("image/")).slice(0, 5);
    if (!imageFiles.length) return;

    setUploading(true);
    try {
      const uploadPromises = imageFiles.map(f => base44.integrations.Core.UploadFile({ file: f }));
      const results = await Promise.all(uploadPromises);
      const newPreviews = imageFiles.map((f, i) => ({ 
        file: f, 
        previewUrl: URL.createObjectURL(f), 
        uploadedUrl: results[i].file_url 
      }));
      if (navigator.vibrate) navigator.vibrate(10);
      setPreviews(prev => [...prev, ...newPreviews].slice(0, 5));
    } finally {
      setUploading(false);
    }
  };

  const removePhoto = (idx) => {
    setPreviews(prev => prev.filter((_, i) => i !== idx));
  };

  const handleAnalyze = () => {
    const urls = previews.map(p => p.uploadedUrl).filter(Boolean);
    if (urls.length > 0) onPhotosUploaded(urls);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  };

  const allUploaded = previews.length > 0 && previews.every(p => p.uploadedUrl);

  // Compact mode: expose a trigger renderer (used in radial scanner)
  // In compact mode we skip the preview grid entirely — upload then immediately fire onPhotosUploaded
  if (compact && typeof renderTrigger === "function") {
    const handleCompactFiles = async (files) => {
      const imageFiles = Array.from(files).filter(f => f.type.startsWith("image/")).slice(0, 5);
      if (!imageFiles.length) return;
      setUploading(true);
      try {
        const uploadPromises = imageFiles.map(f => base44.integrations.Core.UploadFile({ file: f }));
        const results = await Promise.all(uploadPromises);
        const urls = results.map(r => r.file_url);
        if (navigator.vibrate) navigator.vibrate(10);
        onPhotosUploaded(urls);
      } finally {
        setUploading(false);
      }
    };

    return (
      <>
        {renderTrigger(() => fileInputRef.current?.click(), uploading)}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          multiple
          className="hidden"
          onChange={(e) => handleCompactFiles(e.target.files)}
        />
      </>
    );
  }

  if (previews.length > 0) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-2">
          {previews.map((p, i) => (
            <div key={i} className="relative rounded-xl overflow-hidden border border-white/10 bg-[#14141e] aspect-square">
              <img src={p.previewUrl} alt={`Specimen ${i + 1}`} className="w-full h-full object-cover" />
              {!p.uploadedUrl && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
                </div>
              )}
              {p.uploadedUrl && !isProcessing && (
                <button
                  onClick={() => removePhoto(i)}
                  className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/70 flex items-center justify-center text-white/70 hover:text-white hover:bg-black transition"
                 aria-label="Close">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
          {previews.length < 5 && !isProcessing && (
            <button
              onClick={() => fileInputRef.current?.click()}
              className="aspect-square rounded-xl border-2 border-dashed border-white/10 hover:border-amber-500/40 flex flex-col items-center justify-center gap-1.5 text-white/30 hover:text-amber-400 transition-all"
            >
              <Plus className="w-5 h-5" />
              <span className="text-xs">Add</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 text-xs text-white/40">
          <Image className="w-3.5 h-3.5" />
          {previews.length} photo{previews.length !== 1 ? "s" : ""} · Multiple angles improve accuracy
        </div>

        {(uploading || isProcessing) && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-amber-500/5 border border-amber-500/20">
            <Loader2 className="w-5 h-5 text-amber-400 animate-spin shrink-0" />
            <p className="text-sm text-white/70">
              {uploading ? "Uploading photos..." : "Analyzing your specimen with AI..."}
            </p>
          </div>
        )}

        {!uploading && !isProcessing && allUploaded && (
          <button
            onClick={handleAnalyze}
            className="w-full py-3.5 rounded-xl font-semibold text-white text-sm flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
            style={{
              backgroundImage: 'linear-gradient(120deg, #f59e0b, #ea580c)',
              boxShadow: '0 0 20px rgba(245,158,11,0.35)'
            }}
          >
            <Sparkles className="w-4 h-4" />
            Identify Specimen ({previews.length} photo{previews.length !== 1 ? "s" : ""})
          </button>
        )}

        {!isProcessing && (
          <button
            onClick={() => setPreviews([])}
            className="w-full py-2.5 rounded-xl text-sm text-white/40 hover:text-white/70 border border-white/5 hover:bg-white/5 flex items-center justify-center gap-2 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Start over
          </button>
        )}

        <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => handleFiles(e.target.files)} />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative cursor-pointer rounded-2xl border-2 border-dashed transition-all duration-300 overflow-hidden group
          ${dragOver ? "border-amber-400/70 bg-amber-500/5 scale-[1.01]" : "border-white/10 hover:border-amber-500/40 hover:bg-amber-500/3"}`}
      >
        <div className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: "linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)",
            backgroundSize: "32px 32px"
          }}
        />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl group-hover:bg-amber-500/10 transition-all duration-500" />

        <div className="relative flex flex-col items-center gap-5 py-14 px-8 text-center">
          <div className="relative">
            <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-2xl shadow-amber-500/30 transition-transform duration-300 ${dragOver ? "scale-110" : "group-hover:scale-105"}`}>
              <Camera className="w-9 h-9 text-white" />
            </div>
            <div className="absolute -top-1.5 -right-1.5 w-7 h-7 rounded-full bg-[#14141e] border border-amber-500/30 flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            </div>
          </div>

          <div>
            <p className="text-xl font-bold text-white mb-1.5">
              {dragOver ? "Drop to identify!" : "Identify your specimen"}
            </p>
            <p className="text-sm text-white/40 max-w-xs leading-relaxed">
              Upload 1–5 photos from different angles for the most accurate AI identification
            </p>
          </div>

          <div className="flex items-center gap-2 px-5 py-2.5 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-300 text-sm font-medium hover:bg-amber-500/20 transition-colors">
            <Upload className="w-4 h-4" />
            Choose Photos (up to 5)
          </div>

          <p className="text-xs text-white/20">JPG · PNG · WEBP · HEIC supported</p>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-2">
        {[
          { icon: Zap, label: "Instant AI ID" },
          { icon: Gem, label: "5,000+ minerals" },
          { icon: Microscope, label: "Multi-photo analysis" },
        ].map(({ icon: Icon, label }) => (
          <div key={label} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/8 text-white/40 text-xs">
            <Icon className="w-3 h-3" />
            {label}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-2">
        {EXAMPLES.map(({ label, color, icon }) => (
          <div key={label} className={`rounded-xl bg-gradient-to-br ${color} border border-white/5 p-3 text-center`}>
            <div className="text-2xl mb-1">{icon}</div>
            <p className="text-xs text-white/50">{label}</p>
          </div>
        ))}
      </div>

      <div className="flex items-start gap-3 p-4 rounded-xl bg-white/3 border border-white/6">
        <div className="w-7 h-7 rounded-lg bg-amber-500/15 flex items-center justify-center shrink-0 mt-0.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
        </div>
        <div>
          <p className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-0.5">Pro Tip</p>
          <p className="text-sm text-white/40">{TIPS[tipIndex]}</p>
        </div>
      </div>

      <input ref={fileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => handleFiles(e.target.files)} />
    </div>
  );
}