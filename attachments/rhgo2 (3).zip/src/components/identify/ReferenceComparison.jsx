import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, ChevronDown, ChevronUp, Loader2, ExternalLink, Gem, Layers, Thermometer, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

function MatchScore({ score }) {
  const color = score >= 80 ? "text-emerald-400" : score >= 60 ? "text-amber-400" : "text-white/40";
  const bg = score >= 80 ? "bg-emerald-500/10" : score >= 60 ? "bg-amber-500/10" : "bg-white/5";
  const bar = score >= 80 ? "linear-gradient(90deg, #10b981, #34d399)" : score >= 60 ? "linear-gradient(90deg, #f59e0b, #fbbf24)" : "linear-gradient(90deg, #6b7280, #9ca3af)";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${score}%`, background: bar }} />
      </div>
      <span className={`text-xs font-bold ${color} ${bg} px-2 py-0.5 rounded-full border border-current/20`}>{score}%</span>
    </div>
  );
}

function ReferenceCard({ ref: refSpec, matchScore, result }) {
  const [expanded, setExpanded] = useState(false);

  const sharedProps = [];
  if (result.hardness && refSpec.hardness && Math.abs(result.hardness - refSpec.hardness) <= 0.5) {
    sharedProps.push(`Hardness ~${refSpec.hardness}`);
  }
  if (result.luster && refSpec.luster && result.luster.toLowerCase() === refSpec.luster.toLowerCase()) {
    sharedProps.push(`${refSpec.luster} luster`);
  }
  if (result.crystal_system && refSpec.crystal_system && result.crystal_system.toLowerCase() === refSpec.crystal_system.toLowerCase()) {
    sharedProps.push(`${refSpec.crystal_system} crystal system`);
  }
  if (result.category && refSpec.category && result.category.toLowerCase() === refSpec.category.toLowerCase()) {
    sharedProps.push(refSpec.category);
  }

  return (
    <Card className="bg-[#14141e] border-white/5 overflow-hidden">
      <div className="flex gap-3 p-3">
        {refSpec.photo_urls?.[0] ? (
          <img
            src={refSpec.photo_urls[0]}
            alt={refSpec.mineral_name}
            className="w-16 h-16 rounded-xl object-cover shrink-0 border border-white/10"
          />
        ) : (
          <div className="w-16 h-16 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
            <Gem className="w-6 h-6 text-white/20" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-sm font-semibold text-white/90 truncate">{refSpec.mineral_name}</span>
            {refSpec.category && (
              <Badge className="bg-purple-500/10 text-purple-300 border-purple-500/20 text-[10px] shrink-0 capitalize">
                {refSpec.category}
              </Badge>
            )}
          </div>
          <MatchScore score={matchScore} />
          {sharedProps.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {sharedProps.map((p) => (
                <span key={p} className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  ✓ {p}
                </span>
              ))}
            </div>
          )}
        </div>
        <button
          onClick={() => setExpanded((e) => !e)}
          className="self-start p-1 text-white/30 hover:text-white/60 transition-colors"
        >
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {expanded && (
        <div className="px-3 pb-3 space-y-2 border-t border-white/5 pt-2">
          {refSpec.description && (
            <p className="text-xs text-white/50 leading-relaxed">{refSpec.description}</p>
          )}
          <div className="grid grid-cols-2 gap-2 text-xs">
            {refSpec.hardness && (
              <div className="flex items-center gap-1.5 text-white/40">
                <Thermometer className="w-3 h-3 text-amber-400" />
                Hardness: <span className="text-white/70">{refSpec.hardness}</span>
              </div>
            )}
            {refSpec.luster && (
              <div className="flex items-center gap-1.5 text-white/40">
                <Sparkles className="w-3 h-3 text-cyan-400" />
                Luster: <span className="text-white/70">{refSpec.luster}</span>
              </div>
            )}
            {refSpec.crystal_system && (
              <div className="flex items-center gap-1.5 text-white/40">
                <Layers className="w-3 h-3 text-purple-400" />
                Crystal: <span className="text-white/70">{refSpec.crystal_system}</span>
              </div>
            )}
            {refSpec.streak_color && (
              <div className="flex items-center gap-1.5 text-white/40">
                <span className="w-3 h-3 flex items-center justify-center text-white/30">~</span>
                Streak: <span className="text-white/70">{refSpec.streak_color}</span>
              </div>
            )}
          </div>
          {refSpec.key_features?.length > 0 && (
            <div>
              <p className="text-[10px] text-white/30 uppercase tracking-wider mb-1">Key Features</p>
              <div className="flex flex-wrap gap-1">
                {refSpec.key_features.slice(0, 4).map((f) => (
                  <span key={f} className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-white/40">{f}</span>
                ))}
              </div>
            </div>
          )}
          {refSpec.similar_minerals?.length > 0 && (
            <p className="text-[10px] text-white/35">
              Often confused with: {refSpec.similar_minerals.slice(0, 3).join(", ")}
            </p>
          )}
        </div>
      )}
    </Card>
  );
}

function computeMatchScore(result, refSpec) {
  let score = 0;
  // Name match is the strongest signal
  const resultName = result.name?.toLowerCase() || "";
  const refName = refSpec.mineral_name?.toLowerCase() || "";
  if (resultName === refName) score += 50;
  else if (resultName.includes(refName) || refName.includes(resultName)) score += 30;
  // Check if it's in similar minerals
  const isSimilar = result.similar_minerals?.some(
    (s) => s.name?.toLowerCase() === refName || refName.includes(s.name?.toLowerCase())
  );
  if (isSimilar) score += 20;
  // Physical properties
  if (result.hardness && refSpec.hardness && Math.abs(result.hardness - refSpec.hardness) <= 0.5) score += 10;
  if (result.luster && refSpec.luster && result.luster.toLowerCase() === refSpec.luster.toLowerCase()) score += 8;
  if (result.crystal_system && refSpec.crystal_system && result.crystal_system.toLowerCase() === refSpec.crystal_system.toLowerCase()) score += 7;
  if (result.category && refSpec.category && result.category.toLowerCase() === refSpec.category.toLowerCase()) score += 5;
  return Math.min(score, 99);
}

export default function ReferenceComparison({ result }) {
  const [references, setReferences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (!result) return;
    loadReferences();
  }, [result]);

  const loadReferences = async () => {
    setLoading(true);
    try {
      const allRefs = await base44.entities.ReferenceSpecimen.list("-created_date", 200);
      // Score and rank
      const scored = allRefs
        .map((r) => ({ ref: r, score: computeMatchScore(result, r) }))
        .filter((r) => r.score >= 20)
        .sort((a, b) => b.score - a.score)
        .slice(0, 5);
      setReferences(scored);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="bg-[#14141e] border-white/5 p-4">
        <div className="flex items-center gap-2 text-white/40 text-sm">
          <Loader2 className="w-4 h-4 animate-spin" />
          Searching reference library...
        </div>
      </Card>
    );
  }

  if (references.length === 0) {
    return (
      <Card className="bg-[#14141e] border-white/5 p-4">
        <div className="flex items-center gap-2 text-sm">
          <BookOpen className="w-4 h-4 text-white/30" />
          <span className="text-white/40">No matching reference specimens found in library.</span>
          <Link to={createPageUrl("LearningCenter")} className="ml-auto text-cyan-400 text-xs flex items-center gap-1 hover:text-cyan-300">
            Browse library <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
      </Card>
    );
  }

  return (
    <Card className="bg-[#14141e] border-white/5">
      <button
        onClick={() => setCollapsed((c) => !c)}
        className="w-full flex items-center justify-between gap-3 p-5 text-left"
      >
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-indigo-400" />
          <span className="text-sm font-semibold text-white/90">Reference Library Matches</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            {references.length} found
          </span>
        </div>
        {collapsed ? <ChevronDown className="w-4 h-4 text-white/30" /> : <ChevronUp className="w-4 h-4 text-white/30" />}
      </button>
      {!collapsed && (
        <div className="px-5 pb-5 pt-0 space-y-3">
          <p className="text-xs text-white/30 -mt-2 mb-3">
            Ranked by property similarity. Tap any match to compare details.
          </p>
          {references.map(({ ref, score }) => (
            <ReferenceCard key={ref.id} ref={ref} matchScore={score} result={result} />
          ))}
          <Link
            to={createPageUrl("LearningCenter")}
            className="flex items-center justify-center gap-1.5 w-full mt-1 py-2.5 rounded-xl text-xs text-indigo-400 border border-indigo-500/20 hover:bg-indigo-500/5 transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5" />
            Browse full reference library
            <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
      )}
    </Card>
  );
}