/**
 * IdentifyResultSkeleton — shown while specimen data is loading from DB.
 * Matches the real layout so the transition feels smooth, not jarring.
 */
import React from "react";

function Bone({ className = "", style = {} }) {
  return (
    <div
      className={className}
      style={{
        background: "linear-gradient(90deg, rgba(255,255,255,0.04) 25%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.04) 75%)",
        backgroundSize: "200% 100%",
        animation: "skeletonShimmer 1.6s ease-in-out infinite",
        borderRadius: 10,
        ...style,
      }}
    />
  );
}

export default function IdentifyResultSkeleton() {
  return (
    <div className="min-h-screen px-4 pt-4 pb-28 space-y-4 max-w-2xl mx-auto" style={{ background: "#05070A" }}>
      <style>{`
        @keyframes skeletonShimmer {
          0%   { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>

      {/* Back button placeholder */}
      <Bone style={{ width: 80, height: 20, borderRadius: 6 }} />

      {/* Hero card */}
      <div className="rounded-3xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.06)" }}>
        {/* Image area */}
        <Bone style={{ height: 220, borderRadius: 0 }} />
        {/* Title area */}
        <div className="p-5 space-y-3" style={{ background: "rgba(255,255,255,0.02)" }}>
          <Bone style={{ width: "60%", height: 28 }} />
          <Bone style={{ width: "40%", height: 16 }} />
          {/* Confidence bar */}
          <div className="flex items-center gap-3 mt-2">
            <Bone style={{ flex: 1, height: 8, borderRadius: 4 }} />
            <Bone style={{ width: 36, height: 16 }} />
          </div>
        </div>
      </div>

      {/* Properties grid */}
      <div className="grid grid-cols-2 gap-3">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="rounded-2xl p-4 space-y-2" style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <Bone style={{ width: "50%", height: 10 }} />
            <Bone style={{ width: "70%", height: 18 }} />
          </div>
        ))}
      </div>

      {/* Action buttons */}
      <div className="flex gap-3">
        <Bone style={{ flex: 1, height: 52, borderRadius: 16 }} />
        <Bone style={{ flex: 1, height: 52, borderRadius: 16 }} />
      </div>

      {/* Intelligence panel */}
      <div className="rounded-2xl p-4 space-y-3" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
        <Bone style={{ width: "45%", height: 12 }} />
        <Bone style={{ width: "100%", height: 14 }} />
        <Bone style={{ width: "85%", height: 14 }} />
        <Bone style={{ width: "65%", height: 14 }} />
      </div>

      {/* Analyzing label */}
      <div className="flex items-center justify-center gap-2 py-2">
        <div style={{
          width: 8, height: 8, borderRadius: "50%",
          background: "#00D68F",
          animation: "skeletonShimmer 1.2s ease-in-out infinite",
        }} />
        <span className="text-xs font-semibold tracking-widest uppercase" style={{ color: "rgba(0,214,143,0.5)" }}>
          Loading Analysis…
        </span>
      </div>
    </div>
  );
}