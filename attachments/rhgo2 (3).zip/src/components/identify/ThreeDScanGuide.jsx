import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Camera, CheckCircle, Loader2, RotateCcw, Box } from "lucide-react";

const ANGLES = [
  { label: "Top view", hint: "Hold camera directly above specimen" },
  { label: "Front view", hint: "Face of the specimen" },
  { label: "Left side", hint: "45° from left" },
  { label: "Right side", hint: "45° from right" },
  { label: "Back view", hint: "Rear of specimen" },
];

export default function ThreeDScanGuide({ onComplete, onCancel }) {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const currentAngle = photos.length;
  const done = currentAngle >= ANGLES.length;

  const handleCapture = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhotos(p => [...p, file_url]);
    setUploading(false);
    e.target.value = "";
  };

  const handleFinish = () => {
    onComplete(photos);
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
          <Box className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-bold">3D Scan Guide</h2>
          <p className="text-white/40 text-xs">Capture {ANGLES.length} angles for best results</p>
        </div>
      </div>

      {/* Progress */}
      <div className="flex gap-1.5 mb-6">
        {ANGLES.map((a, i) => (
          <div
            key={i}
            className={`h-1.5 flex-1 rounded-full transition-all ${
              i < photos.length ? "bg-cyan-400" : i === photos.length ? "bg-cyan-400/40" : "bg-white/10"
            }`}
          />
        ))}
      </div>

      {/* Angles checklist */}
      <div className="space-y-2 mb-6">
        {ANGLES.map((angle, i) => {
          const captured = i < photos.length;
          const isCurrent = i === currentAngle && !done;
          return (
            <div
              key={i}
              className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                captured ? "border-cyan-500/30 bg-cyan-500/5"
                : isCurrent ? "border-amber-500/40 bg-amber-500/5"
                : "border-white/5 bg-white/[0.02]"
              }`}
            >
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                captured ? "bg-cyan-500 text-white" : isCurrent ? "bg-amber-500/20 text-amber-400 border border-amber-500/40" : "bg-white/5 text-white/20"
              }`}>
                {captured ? <CheckCircle className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <div className={`text-sm font-medium ${captured ? "text-cyan-300" : isCurrent ? "text-white" : "text-white/30"}`}>
                  {angle.label}
                </div>
                {isCurrent && <div className="text-xs text-white/40 mt-0.5">{angle.hint}</div>}
              </div>
              {captured && (
                <img src={photos[i]} alt="" className="w-10 h-10 rounded-lg object-cover border border-white/10" />
              )}
            </div>
          );
        })}
      </div>

      {!done ? (
        <>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleCapture}
            className="hidden"
          />
          <Button
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold h-12"
          >
            {uploading ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Camera className="w-4 h-4 mr-2" />
            )}
            {uploading ? "Uploading..." : `Capture ${ANGLES[currentAngle]?.label}`}
          </Button>
        </>
      ) : (
        <Button
          onClick={handleFinish}
          className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white font-semibold h-12"
        >
          <Box className="w-4 h-4 mr-2" />
          Build 3D Model + Identify
        </Button>
      )}

      <button
        onClick={onCancel}
        className="mt-3 w-full text-white/30 text-sm hover:text-white/60 transition-colors flex items-center justify-center gap-1"
      >
        <RotateCcw className="w-3 h-3" /> Start Over
      </button>
    </div>
  );
}