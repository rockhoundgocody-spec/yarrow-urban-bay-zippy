/**
 * ScanSuccessBurst — capture-confirmed success moment for the scan screen.
 * Shows a radial flash + particle ring when specimen is locked and captured.
 *
 * Props:
 *  active   boolean  — flip to true on capture confirmed
 *  onDone   fn
 */

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import SuccessBurst from "@/animation/SuccessBurst";

export default function ScanSuccessBurst({ active, onDone }) {
  return (
    <AnimatePresence>
      {active && (
        <motion.div
          className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
        >
          {/* Radial flash */}
          <motion.div
            className="absolute h-40 w-40 rounded-full"
            style={{
              background: "radial-gradient(circle, rgba(125,249,255,0.55) 0%, rgba(0,255,198,0.18) 50%, transparent 70%)",
              filter: "blur(8px)",
            }}
            initial={{ scale: 0.4, opacity: 0.9 }}
            animate={{ scale: 2.4, opacity: 0 }}
            transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          />

          {/* Ring flash */}
          <motion.div
            className="absolute h-28 w-28 rounded-full border-2"
            style={{ borderColor: "rgba(125,249,255,0.7)" }}
            initial={{ scale: 0.6, opacity: 1 }}
            animate={{ scale: 2, opacity: 0 }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          />

          {/* Particles */}
          <div className="relative h-0 w-0">
            <SuccessBurst active={active} color="#7DF9FF" count={16} radius={68} onDone={onDone} />
          </div>

          {/* Text confirmation */}
          <motion.div
            className="absolute bottom-[30%] flex flex-col items-center gap-1"
            initial={{ y: 12, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -8, opacity: 0 }}
            transition={{ delay: 0.15, duration: 0.38 }}
          >
            <span className="text-xs font-bold uppercase tracking-[0.26em]" style={{ color: "#7DF9FF" }}>
              Captured
            </span>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}