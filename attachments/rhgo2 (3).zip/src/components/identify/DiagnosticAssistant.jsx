import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  ChevronRight, ChevronLeft, Check, Thermometer, Droplets, 
  Layers, FlaskConical, Magnet, Weight, Sparkles, SkipForward, Info
} from "lucide-react";

const STEPS = [
  {
    id: "hardness_test",
    title: "Hardness Test",
    icon: Thermometer,
    color: "#f59e0b",
    instructions: "Try scratching your specimen with common objects to estimate Mohs hardness.",
    tests: [
      { label: "Fingernail scratches it", value: "softer_than_2.5", mohs: "< 2.5" },
      { label: "Copper coin scratches it", value: "softer_than_3.5", mohs: "< 3.5" },
      { label: "Glass nail file scratches it", value: "softer_than_5.5", mohs: "< 5.5" },
      { label: "Steel knife scratches it", value: "softer_than_6.5", mohs: "< 6.5" },
      { label: "It scratches glass", value: "harder_than_5.5", mohs: "> 5.5" },
      { label: "It scratches a steel knife", value: "harder_than_6.5", mohs: "> 6.5" },
      { label: "Nothing I have scratches it", value: "very_hard_7_plus", mohs: "> 7" },
    ],
    tip: "Always test on a fresh surface. Powder residue from a softer material can look like a scratch on a harder one.",
  },
  {
    id: "streak_test",
    title: "Streak Test",
    icon: Droplets,
    color: "#00f5ff",
    instructions: "Drag the specimen firmly across an unglazed porcelain tile (back of a bathroom tile works). Note the powder color left behind.",
    options: [
      { label: "White / colorless", value: "white" },
      { label: "Black / dark gray", value: "black" },
      { label: "Red / red-brown", value: "red_brown" },
      { label: "Yellow / yellow-brown", value: "yellow_brown" },
      { label: "Green", value: "green" },
      { label: "Blue", value: "blue" },
      { label: "Gray / silver", value: "gray" },
      { label: "No streak (too hard)", value: "no_streak_too_hard" },
    ],
    tip: "Streak color is often different from the specimen's surface color. A golden pyrite leaves a black streak. This is one of the most reliable field tests.",
  },
  {
    id: "cleavage_test",
    title: "Cleavage & Fracture",
    icon: Layers,
    color: "#a855f7",
    instructions: "Examine how the specimen breaks or has broken. Look at fractured surfaces closely.",
    options: [
      { label: "Flat, smooth planes (cleavage)", value: "cleavage_flat_planes" },
      { label: "Breaks in 2 directions at ~90°", value: "cleavage_two_90" },
      { label: "Breaks in 3+ directions", value: "cleavage_three_plus" },
      { label: "Curved, shell-like fracture (conchoidal)", value: "fracture_conchoidal" },
      { label: "Rough, uneven fracture", value: "fracture_uneven" },
      { label: "Splintery / fibrous fracture", value: "fracture_splintery" },
      { label: "Crumbly / earthy", value: "fracture_earthy" },
    ],
    tip: "Cleavage = breaks along flat planes (mineral structure). Fracture = irregular break. Quartz has conchoidal fracture; feldspar has cleavage.",
  },
  {
    id: "acid_test",
    title: "Acid Reaction",
    icon: FlaskConical,
    color: "#22c55e",
    instructions: "If you have vinegar or dilute HCl, place a drop on a fresh surface. Watch for fizzing/bubbling.",
    options: [
      { label: "Fizzes vigorously", value: "fizzes_strong" },
      { label: "Fizzes slightly / only when powdered", value: "fizzes_weak" },
      { label: "No reaction", value: "no_reaction" },
      { label: "Didn't test / no acid available", value: "not_tested" },
    ],
    tip: "Strong fizz = likely calcite or limestone. Weak fizz when powdered = possibly dolomite. Most silicates won't react.",
  },
  {
    id: "magnetism_test",
    title: "Magnetism",
    icon: Magnet,
    color: "#ef4444",
    instructions: "Hold a magnet (fridge magnet works) near the specimen.",
    options: [
      { label: "Strongly magnetic (pulls toward magnet)", value: "strongly_magnetic" },
      { label: "Weakly magnetic (slight attraction)", value: "weakly_magnetic" },
      { label: "Not magnetic", value: "not_magnetic" },
      { label: "Didn't test / no magnet available", value: "not_tested" },
    ],
    tip: "Magnetite is strongly magnetic. Some iron-bearing minerals show weak magnetism. This test alone can confirm magnetite vs. similar dark minerals.",
  },
  {
    id: "heft_test",
    title: "Heft / Density Feel",
    icon: Weight,
    color: "#f97316",
    instructions: "Pick up the specimen and compare its weight to what you'd expect for its size.",
    options: [
      { label: "Unusually heavy for its size", value: "very_heavy" },
      { label: "About what I'd expect", value: "normal_weight" },
      { label: "Surprisingly light", value: "light" },
    ],
    tip: "Galena and barite feel surprisingly heavy. Pumice feels unexpectedly light. Heavy heft often indicates metallic minerals or high specific gravity.",
  },
];

export default function DiagnosticAssistant({ onComplete, onSkip }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [results, setResults] = useState({});
  const [selectedOptions, setSelectedOptions] = useState({});

  const step = STEPS[currentStep];
  const isLast = currentStep === STEPS.length - 1;
  const hasSelection = !!selectedOptions[step.id];


  const handleMultiSelect = (value) => {
    const current = selectedOptions[step.id];
    if (current === value) {
      setSelectedOptions(prev => ({ ...prev, [step.id]: null }));
      setResults(prev => ({ ...prev, [step.id]: null }));
    } else {
      setSelectedOptions(prev => ({ ...prev, [step.id]: value }));
      setResults(prev => ({ ...prev, [step.id]: value }));
    }
  };

  const next = () => {
    if (isLast) {
      const cleanResults = {};
      Object.entries(results).forEach(([k, v]) => { if (v && v !== "not_tested") cleanResults[k] = v; });
      onComplete(cleanResults);
    } else {
      setCurrentStep(s => s + 1);
    }
  };

  const prev = () => setCurrentStep(s => Math.max(0, s - 1));

  const skipStep = () => {
    setResults(prev => ({ ...prev, [step.id]: null }));
    setSelectedOptions(prev => ({ ...prev, [step.id]: null }));
    if (isLast) {
      const cleanResults = {};
      Object.entries(results).forEach(([k, v]) => { if (v && v !== "not_tested") cleanResults[k] = v; });
      onComplete(cleanResults);
    } else {
      setCurrentStep(s => s + 1);
    }
  };

  const completedCount = Object.values(results).filter(v => v && v !== "not_tested").length;
  const options = step.tests || step.options;
  const Icon = step.icon;

  return (
    <div className="space-y-4">
      {/* Progress bar */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => {
          const done = results[s.id] && results[s.id] !== "not_tested";
          const active = i === currentStep;
          return (
            <button
              key={s.id}
              onClick={() => setCurrentStep(i)}
              className="flex-1 h-1.5 rounded-full transition-all duration-300"
              style={{
                background: done ? s.color : active ? `${s.color}60` : "rgba(255,255,255,0.06)",
                boxShadow: active ? `0 0 8px ${s.color}40` : "none",
              }}
             aria-label="Close"/>
          );
        })}
      </div>

      <div className="flex items-center justify-between">
        <span className="text-[11px] text-white/30 uppercase tracking-wider font-semibold">
          Step {currentStep + 1} of {STEPS.length}
        </span>
        <span className="text-[11px] text-white/30">
          {completedCount} test{completedCount !== 1 ? "s" : ""} completed
        </span>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
          className="space-y-4"
        >
          {/* Step header */}
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{ background: `${step.color}18`, border: `1px solid ${step.color}30` }}
            >
              <Icon className="w-5 h-5" style={{ color: step.color }} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white/90">{step.title}</h3>
              <p className="text-xs text-white/40 leading-relaxed">{step.instructions}</p>
            </div>
          </div>

          {/* Options */}
          <div className="space-y-2">
            {options.map((opt) => {
              const selected = selectedOptions[step.id] === opt.value;
              return (
                <button
                  key={opt.value}
                  onClick={() => handleMultiSelect(opt.value)}
                  className="w-full text-left flex items-center gap-3 px-4 py-3 rounded-xl transition-all active:scale-[0.98]"
                  style={{
                    background: selected ? `${step.color}12` : "rgba(255,255,255,0.02)",
                    border: `1px solid ${selected ? step.color + "50" : "rgba(255,255,255,0.06)"}`,
                  }}
                >
                  <div
                    className="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 transition-all"
                    style={{
                      borderColor: selected ? step.color : "rgba(255,255,255,0.15)",
                      background: selected ? step.color : "transparent",
                    }}
                  >
                    {selected && <Check className="w-3 h-3 text-black" />}
                  </div>
                  <span className={`text-sm ${selected ? "text-white/90 font-medium" : "text-white/60"}`}>
                    {opt.label}
                  </span>
                  {opt.mohs && (
                    <span className="ml-auto text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/30">
                      Mohs {opt.mohs}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Tip */}
          <div
            className="flex items-start gap-2.5 p-3 rounded-xl"
            style={{ background: `${step.color}06`, border: `1px solid ${step.color}15` }}
          >
            <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" style={{ color: step.color }} />
            <p className="text-xs leading-relaxed" style={{ color: `${step.color}99` }}>
              {step.tip}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation */}
      <div className="flex items-center gap-2 pt-2">
        {currentStep > 0 && (
          <button
            onClick={prev}
            className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-medium text-white/40 hover:text-white/70 transition-all"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Back
          </button>
        )}

        <button
          onClick={skipStep}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-medium text-white/30 hover:text-white/50 transition-all"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.04)" }}
        >
          <SkipForward className="w-3.5 h-3.5" /> Skip
        </button>

        <div className="flex-1" />

        <button
          onClick={next}
          disabled={!hasSelection}
          className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-semibold text-white transition-all disabled:opacity-30"
          style={{
            background: hasSelection ? `linear-gradient(120deg, ${step.color}, ${step.color}cc)` : "rgba(255,255,255,0.05)",
            boxShadow: hasSelection ? `0 0 16px ${step.color}30` : "none",
          }}
        >
          {isLast ? (
            <><Sparkles className="w-3.5 h-3.5" /> Finish & Identify</>
          ) : (
            <><ChevronRight className="w-3.5 h-3.5" /> Next Test</>
          )}
        </button>
      </div>

      {/* Skip all */}
      {onSkip && (
        <button
          onClick={onSkip}
          className="w-full text-center text-xs text-white/20 hover:text-white/40 py-2 transition-colors"
        >
          Skip all tests — identify from photos only
        </button>
      )}
    </div>
  );
}