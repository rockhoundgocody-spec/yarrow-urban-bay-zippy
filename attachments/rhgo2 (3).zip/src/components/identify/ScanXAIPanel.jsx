import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, ChevronDown, ChevronUp, CheckCircle, AlertTriangle, FlaskConical, MapPin, Gem, Eye } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ScanXAIPanel({ mineralName, confidence, photoUrl, fieldNotes, hardness, color, luster, crystalSystem }) {
  const [explanation, setExplanation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!mineralName) return;
    setExplanation(null);
    setError(null);
  }, [mineralName]);

  async function loadExplanation() {
    if (explanation || loading) return;
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('scanXAI', {
        mineral_name: mineralName,
        confidence,
        photo_url: photoUrl,
        field_notes: fieldNotes,
        hardness,
        color,
        luster,
        crystal_system: crystalSystem
      });
      setExplanation(res.data.explanation);
    } catch (e) {
      setError('Unable to load explanation');
    } finally {
      setLoading(false);
    }
  }

  function handleToggle() {
    setExpanded(e => !e);
    if (!expanded) loadExplanation();
  }

  const rarityColor = explanation?.rarity_insight?.startsWith('common') ? '#9ca3af'
    : explanation?.rarity_insight?.startsWith('uncommon') ? '#fbbf24'
    : '#a78bfa';

  return (
    <div className="rounded-xl overflow-hidden" style={{ background: 'rgba(141,124,255,0.06)', border: '1px solid rgba(141,124,255,0.2)' }}>
      <button
        onClick={handleToggle}
        className="w-full flex items-center gap-2.5 px-3 py-3"
        style={{ minHeight: 48 }}
      >
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: 'rgba(141,124,255,0.15)', border: '1px solid rgba(141,124,255,0.25)' }}>
          <Brain className="w-4 h-4" style={{ color: '#a78bfa' }} />
        </div>
        <div className="flex-1 text-left">
          <span className="text-sm font-bold" style={{ color: '#c4b5fd' }}>Why this identification?</span>
          <p className="text-xs" style={{ color: 'rgba(196,181,253,0.6)' }}>
            {loading ? 'Analyzing...' : explanation ? 'AI evidence breakdown' : 'Tap to see reasoning'}
          </p>
        </div>
        {loading
          ? <div className="w-4 h-4 rounded-full border-2 border-purple-400/30 border-t-purple-400 animate-spin flex-shrink-0" />
          : expanded ? <ChevronUp className="w-4 h-4 flex-shrink-0" style={{ color: 'rgba(196,181,253,0.5)' }} />
          : <ChevronDown className="w-4 h-4 flex-shrink-0" style={{ color: 'rgba(196,181,253,0.5)' }} />
        }
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-3" style={{ borderTop: '1px solid rgba(141,124,255,0.15)' }}>
              {error && (
                <p className="pt-3 text-xs" style={{ color: '#f87171' }}>{error}</p>
              )}

              {!explanation && !loading && !error && (
                <p className="pt-3 text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>Loading analysis...</p>
              )}

              {explanation && (
                <div className="pt-3 space-y-3">
                  {/* Primary Evidence */}
                  {explanation.primary_evidence?.length > 0 && (
                    <div>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <CheckCircle className="w-3.5 h-3.5" style={{ color: '#34d399' }} />
                        <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#34d399' }}>Key Evidence</span>
                      </div>
                      <div className="space-y-1">
                        {explanation.primary_evidence.map((e, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs" style={{ color: 'rgba(255,255,255,0.75)' }}>
                            <span className="mt-0.5 flex-shrink-0" style={{ color: '#34d399' }}>•</span>
                            <span>{e}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Supporting Evidence */}
                  {explanation.supporting_evidence?.length > 0 && (
                    <div>
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Eye className="w-3.5 h-3.5" style={{ color: '#60a5fa' }} />
                        <span className="text-xs font-bold uppercase tracking-wider" style={{ color: '#60a5fa' }}>Supporting Observations</span>
                      </div>
                      <div className="space-y-1">
                        {explanation.supporting_evidence.map((e, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs" style={{ color: 'rgba(255,255,255,0.6)' }}>
                            <span className="mt-0.5 flex-shrink-0" style={{ color: '#60a5fa' }}>◦</span>
                            <span>{e}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Confidence drivers */}
                  {explanation.confidence_drivers && (
                    <div className="rounded-lg p-2.5 space-y-1.5"
                      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                      <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>
                        <span className="font-semibold" style={{ color: '#34d399' }}>↑ High: </span>
                        {explanation.confidence_drivers.high}
                      </div>
                      {explanation.confidence_drivers.low && (
                        <div className="text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>
                          <span className="font-semibold" style={{ color: '#fbbf24' }}>⚠ Uncertain: </span>
                          {explanation.confidence_drivers.low}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Lookalike risk */}
                  {explanation.look_alike_risk?.mineral && (
                    <div className="rounded-lg p-2.5"
                      style={{ background: 'rgba(251,191,36,0.06)', border: '1px solid rgba(251,191,36,0.15)' }}>
                      <div className="flex items-center gap-1.5 mb-1">
                        <AlertTriangle className="w-3.5 h-3.5" style={{ color: '#fbbf24' }} />
                        <span className="text-xs font-bold" style={{ color: '#fbbf24' }}>
                          Watch out for: {explanation.look_alike_risk.mineral}
                        </span>
                      </div>
                      <p className="text-xs" style={{ color: 'rgba(253,230,138,0.7)' }}>
                        {explanation.look_alike_risk.distinguishing_test}
                      </p>
                    </div>
                  )}

                  {/* Field verification tip */}
                  {explanation.field_verification_tip && (
                    <div className="rounded-lg p-2.5"
                      style={{ background: 'rgba(96,165,250,0.06)', border: '1px solid rgba(96,165,250,0.15)' }}>
                      <div className="flex items-center gap-1.5 mb-1">
                        <FlaskConical className="w-3.5 h-3.5" style={{ color: '#60a5fa' }} />
                        <span className="text-xs font-bold" style={{ color: '#60a5fa' }}>Field Test</span>
                      </div>
                      <p className="text-xs" style={{ color: 'rgba(147,197,253,0.8)' }}>
                        {explanation.field_verification_tip}
                      </p>
                    </div>
                  )}

                  {/* Geo context + rarity row */}
                  <div className="flex gap-2">
                    {explanation.geological_context && (
                      <div className="flex-1 rounded-lg p-2"
                        style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                        <div className="flex items-center gap-1 mb-1">
                          <MapPin className="w-3 h-3" style={{ color: 'rgba(255,255,255,0.3)' }} />
                          <span className="text-xs font-semibold" style={{ color: 'rgba(255,255,255,0.4)' }}>Formation</span>
                        </div>
                        <p className="text-xs leading-snug" style={{ color: 'rgba(255,255,255,0.55)' }}>
                          {explanation.geological_context}
                        </p>
                      </div>
                    )}
                    {explanation.rarity_insight && (
                      <div className="w-20 rounded-lg p-2 flex flex-col items-center justify-center text-center flex-shrink-0"
                        style={{ background: `${rarityColor}10`, border: `1px solid ${rarityColor}25` }}>
                        <Gem className="w-3.5 h-3.5 mb-1" style={{ color: rarityColor }} />
                        <span className="text-xs font-bold capitalize" style={{ color: rarityColor }}>
                          {explanation.rarity_insight.split('—')[0].split(' ')[0]}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}