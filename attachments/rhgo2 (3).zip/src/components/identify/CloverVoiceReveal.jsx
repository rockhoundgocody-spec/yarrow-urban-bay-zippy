/**
 * CloverVoiceReveal
 * Auto-plays a dramatic Clover voice narration when a scan result loads.
 * Shows animated waveform while speaking, script text with typewriter effect.
 */
import React, { useEffect, useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Volume2, VolumeX, RefreshCw } from "lucide-react";
import { base44 } from "@/api/base44Client";

const NUM_BARS = 20;

export default function CloverVoiceReveal({ specimen }) {
  const [state, setState] = useState("idle"); // idle | loading | playing | done | error
  const [script, setScript] = useState("");
  const [displayedScript, setDisplayedScript] = useState("");
  const [muted, setMuted] = useState(false);
  const audioRef = useRef(new Audio());
  const typeTimerRef = useRef(null);
  const hasTriggered = useRef(false);
  // Stable ref for muted so async callback always sees current value
  const mutedRef = useRef(false);
  // Abort controller — cancels in-flight narration on unmount or re-trigger
  const abortRef = useRef(null);

  const triggerNarration = useCallback(async () => {
    if (!specimen?.name) return;

    // Cancel any previous in-flight narration
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    // Stop previous audio + typewriter
    audioRef.current.pause();
    audioRef.current.src = "";
    clearInterval(typeTimerRef.current);

    setState("loading");
    setDisplayedScript("");
    setScript("");

    try {
      const res = await base44.functions.invoke("cloverScanNarrate", {
        specimenName: specimen.name,
        category: specimen.category,
        confidence: specimen.confidence,
        rarity_label: specimen.rarity_label,
        rarity_score: specimen.rarity_score,
        estimated_value: specimen.valuation_estimated
          ? `$${specimen.valuation_estimated}`
          : specimen.valuation_low
          ? `$${specimen.valuation_low}–$${specimen.valuation_high}`
          : null,
        formation_history: specimen.formation_history,
        geological_significance: specimen.geological_significance,
        color: specimen.color,
        luster: specimen.luster,
        hardness: specimen.hardness,
        clover_commentary: specimen.clover_commentary,
      });

      if (controller.signal.aborted) return;

      const { script: text, audio } = res?.data || {};

      const finalText = text || `${specimen?.name || "Specimen"} identified. Check the field report for details.`;
      setScript(finalText);

      // Typewriter effect — 28ms per char
      let i = 0;
      typeTimerRef.current = setInterval(() => {
        if (controller.signal.aborted) { clearInterval(typeTimerRef.current); return; }
        i++;
        setDisplayedScript(finalText.slice(0, i));
        if (i >= finalText.length) clearInterval(typeTimerRef.current);
      }, 28);

      if (audio && !mutedRef.current) {
        const audioEl = audioRef.current;
        audioEl.src = audio;
        audioEl.volume = 1;
        audioEl.onplay  = () => { if (!controller.signal.aborted) setState("playing"); };
        audioEl.onended = () => { if (!controller.signal.aborted) setState("done"); };
        audioEl.onerror = () => { if (!controller.signal.aborted) setState("done"); };
        audioEl.play().catch(() => { if (!controller.signal.aborted) setState("done"); });
      } else {
        setState("done");
      }
    } catch (err) {
      if (controller.signal.aborted) return;
      console.error("[CloverVoiceReveal]", err);
      const fallback = `${specimen?.name || "Specimen"} — identified. Tap the report below for full field analysis.`;
      setScript(fallback);
      setDisplayedScript(fallback);
      setState("done");
    }
  }, [specimen]); // no `muted` dep — use mutedRef instead

  // Auto-trigger once when specimen is available.
  // 1400ms guard: page transition + animations settle before voice fires.
  useEffect(() => {
    if (!specimen?.name || hasTriggered.current) return;
    hasTriggered.current = true;
    const t = setTimeout(() => triggerNarration(), 1400);
    return () => clearTimeout(t);
  }, [specimen?.name]);  

  // Full cleanup on unmount — stop audio, cancel typewriter, abort in-flight
  useEffect(() => {
    return () => {
      abortRef.current?.abort();
      audioRef.current.pause();
      audioRef.current.src = "";
      clearInterval(typeTimerRef.current);
    };
  }, []);

  const toggleMute = () => {
    const next = !muted;
    mutedRef.current = next;
    setMuted(next);
    audioRef.current.muted = next;
  };

  const isRare = Number(specimen?.rarity_score || 0) >= 65;
  const accentColor = isRare ? "#F5B642" : "#00D68F";

  // Don't show until TTS is confirmed working
  if (state === "idle" && !hasTriggered.current) return null;

  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: `linear-gradient(135deg, rgba(14,20,27,0.95), rgba(8,12,18,0.98))`,
        border: `1px solid ${accentColor}22`,
        boxShadow: state === "playing" ? `0 0 32px ${accentColor}18` : "none",
        transition: "box-shadow 0.6s ease",
      }}
    >
      {/* Header bar */}
      <div
        className="flex items-center justify-between px-4 py-3"
        style={{ borderBottom: `1px solid ${accentColor}14` }}
      >
        <div className="flex items-center gap-2.5">
          {/* Clover orb */}
          <div
            className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
            style={{
              background: `radial-gradient(circle at 35% 35%, ${accentColor}60, ${accentColor}20)`,
              boxShadow: state === "playing" ? `0 0 12px ${accentColor}50` : "none",
              transition: "box-shadow 0.4s ease",
            }}
          >
            <div className="w-2 h-2 rounded-full" style={{ background: accentColor }} />
          </div>
          <span
            className="text-[10px] font-bold uppercase tracking-widest"
            style={{ color: `${accentColor}88` }}
          >
            Clover Field Intelligence
          </span>
        </div>

        <div className="flex items-center gap-2">
          {(state === "done" || state === "error") && (
            <button
              onClick={triggerNarration}
              className="p-1.5 rounded-lg transition-all"
              style={{ color: "rgba(255,255,255,0.3)" }}
              title="Replay"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-lg transition-all"
            style={{ color: muted ? "rgba(255,255,255,0.25)" : `${accentColor}80` }}
            title={muted ? "Unmute" : "Mute"}
          >
            {muted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Waveform + content */}
      <div className="px-4 py-4 space-y-3">
        {/* Animated waveform bars */}
        <AnimatePresence>
          {state === "playing" && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="flex items-center justify-center gap-[3px]"
              style={{ height: 32 }}
            >
              {Array.from({ length: NUM_BARS }).map((_, i) => (
                <motion.div
                  key={i}
                  className="rounded-full"
                  style={{
                    width: 3,
                    background: accentColor,
                    opacity: 0.7,
                  }}
                  animate={{
                    height: [
                      4 + Math.random() * 8,
                      8 + Math.random() * 20,
                      4 + Math.random() * 8,
                    ],
                  }}
                  transition={{
                    duration: 0.4 + Math.random() * 0.4,
                    repeat: Infinity,
                    repeatType: "mirror",
                    delay: i * 0.05,
                    ease: "easeInOut",
                  }}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Loading state */}
        {state === "loading" && (
          <div className="flex items-center gap-3 py-1">
            <div
              className="w-4 h-4 border-2 border-t-transparent rounded-full animate-spin flex-shrink-0"
              style={{ borderColor: `${accentColor}60`, borderTopColor: "transparent" }}
            />
            <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
              Clover is interpreting your find…
            </span>
          </div>
        )}

        {/* Script text — typewriter */}
        {(state === "playing" || state === "done") && displayedScript && (
          <p
            className="text-sm leading-relaxed"
            style={{ color: "rgba(255,255,255,0.72)", minHeight: 40 }}
          >
            {displayedScript}
            {state === "playing" && displayedScript.length < script.length && (
              <span
                className="inline-block w-0.5 h-3.5 ml-0.5 rounded-full align-middle"
                style={{
                  background: accentColor,
                  animation: "cloverCursor 0.7s step-end infinite",
                }}
              />
            )}
          </p>
        )}


      </div>

      <style>{`
        @keyframes cloverCursor {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}