import React from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Camera, Box } from "lucide-react";

function PhotoScanOption({ onChoose }) {
  return (
    <button
      onClick={() => onChoose("photo")}
      className="w-full flex items-center gap-4 p-4 rounded-xl bg-amber-500/10 border border-amber-500/25 hover:bg-amber-500/20 transition-all group text-left"
    >
      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shrink-0">
        <Camera className="w-5 h-5 text-white" />
      </div>
      <div>
        <div className="font-semibold text-white text-sm">Identify from Photo</div>
        <div className="text-xs text-white/40 mt-0.5">Fast AI identification from a single image</div>
      </div>
    </button>
  );
}

function ThreeDScanOption({ onChoose, scans3dRemaining }) {
  const isLimitReached = scans3dRemaining <= 0;

  const badgeColors = scans3dRemaining > 2
    ? "bg-emerald-500/20 text-emerald-400"
    : scans3dRemaining > 0
      ? "bg-yellow-500/20 text-yellow-400"
      : "bg-red-500/20 text-red-400";

  const badgeText = scans3dRemaining > 0
    ? `${scans3dRemaining} left`
    : "Limit reached";

  return (
    <button
      onClick={() => onChoose("3d")}
      disabled={isLimitReached}
      className="w-full flex items-center gap-4 p-4 rounded-xl bg-cyan-500/10 border border-cyan-500/25 hover:bg-cyan-500/20 transition-all group text-left disabled:opacity-40 disabled:cursor-not-allowed"
    >
      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shrink-0">
        <Box className="w-5 h-5 text-white" />
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <div className="font-semibold text-white text-sm">Create 3D Model + Identify</div>
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${badgeColors}`}>
            {badgeText}
          </span>
        </div>
        <div className="text-xs text-white/40 mt-0.5">
          Multi-angle scan → 3D model stored in your collection
        </div>
      </div>
    </button>
  );
}

function UpgradeBanner({ onChoose }) {
  return (
    <div className="mt-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20">
      <p className="text-xs text-red-300">
        You've used all 5 free 3D scans this month. Upgrade to Pro for unlimited scans.
      </p>
      <Button
        size="sm"
        className="mt-2 w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs font-semibold"
        onClick={() => onChoose("upgrade")}
      >
        Upgrade to Pro
      </Button>
    </div>
  );
}

export default function ScanModeModal({ open, onChoose, onCancel, scans3dRemaining }) {
  const isLimitReached = scans3dRemaining <= 0;

  return (
    <Dialog open={open} onOpenChange={onCancel}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
        <div className="text-center pt-2 pb-1">
          <h2 className="text-lg font-bold mb-1">Choose Scan Mode</h2>
          <p className="text-white/40 text-sm mb-6">How would you like to identify this specimen?</p>

          <div className="space-y-3">
            <PhotoScanOption onChoose={onChoose} />
            <ThreeDScanOption onChoose={onChoose} scans3dRemaining={scans3dRemaining} />
          </div>

          {isLimitReached && <UpgradeBanner onChoose={onChoose} />}

          <button
            onClick={onCancel}
            className="mt-4 text-white/30 text-sm hover:text-white/60 transition-colors"
          >
            Cancel
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
