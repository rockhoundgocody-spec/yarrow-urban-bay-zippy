import React from "react";

/**
 * Error boundary for public (pre-auth) marketing/legal routes that render
 * outside the app Layout. Catches lazy-import or render failures so a broken
 * page shows a recoverable message instead of a blank screen.
 */
export default class PublicErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, message: "" };
  }

  static getDerivedStateFromError(err) {
    return { hasError: true, message: err?.message || "Unknown error" };
  }

  componentDidCatch(err) {
    console.error("[RHGO] public route error:", err);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3 text-center px-6">
          <h2 className="text-xl font-bold text-white">This page failed to load</h2>
          <p className="text-white/50 text-sm max-w-sm">{this.state.message}</p>
          <a href="/" className="px-4 py-2 rounded-lg bg-white/10 text-white text-sm">
            Back to home
          </a>
        </div>
      );
    }
    return this.props.children;
  }
}