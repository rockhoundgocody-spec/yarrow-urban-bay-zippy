/**
 * ParentContainer — the page-level "parent container" wrapper.
 * Centers content, applies responsive padding, sits above animated backgrounds.
 * Use as the outermost wrapper for a page's content tree.
 */
import React from "react";

export default function ParentContainer({
  children,
  className = "",
  maxWidth = "max-w-5xl",
  as: Tag = "div",
}) {
  return (
    <Tag
      className={`relative z-10 ${maxWidth} mx-auto px-4 py-6 md:py-8 ${className}`}
    >
      {children}
    </Tag>
  );
}