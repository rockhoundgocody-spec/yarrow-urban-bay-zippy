import React from "react";

// Safe passthrough — no hooks, no router dependency.
// Previously called useLocation outside Router context causing dispatcher null crash.
export default function RouteTransition({ children }) {
  return <>{children}</>;
}