import React from "react";
import { Link } from "react-router-dom";
import { Shield, FileText, Mountain } from "lucide-react";

const LINKS = [
  { to: "/PrivacyPolicy", label: "Privacy Policy", icon: Shield },
  { to: "/TermsOfService", label: "Terms of Service", icon: FileText },
];

export default function LegalFooter({ current }) {
  return (
    <div className="mt-10 pt-6 border-t border-white/8 space-y-5 pb-8">
      {/* Cross-links */}
      <div className="flex flex-wrap gap-2 justify-center">
        {LINKS.filter(l => l.label !== current).map(({ to, label, icon: Icon }) => (
          <Link key={to} to={to}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.45)" }}>
            <Icon className="w-3 h-3" /> {label}
          </Link>
        ))}
        <Link to="/"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.45)" }}>
          <Mountain className="w-3 h-3" /> Back to App
        </Link>
      </div>

      <p className="text-center text-[9px]" style={{ color: "rgba(255,255,255,0.18)" }}>
        © 2025–2026 RockHound-GO, Inc. · All rights reserved · Last updated May 2026
      </p>
    </div>
  );
}