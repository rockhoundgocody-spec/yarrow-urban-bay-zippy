import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, X, Check } from "lucide-react";

const VIDEO_URL =
  "https://media.base44.com/videos/public/699b620aabda6503e72aa4f2/d960be17e_Messenger_creation_1005272240990945.mp4";

const DOWNLOAD_NOTIF_DELAY = 2000;

export default function VideoSplashScreen({ onEnter }) {
  const videoRef = useRef(null);
  const [showDownload, setShowDownload] = useState(false);
  const [installPrompt, setInstallPrompt] = useState(null);
  const [installState, setInstallState] = useState("idle"); // idle | installing | installed
  const [exiting, setExiting] = useState(false);
  const enteredRef = useRef(false);

  // ── Capture PWA install prompt (for background download) ──
  useEffect(() => {
    const handler = (e) => {
      e.preventDefault();
      setInstallPrompt(e);
    };
    const installedHandler = () => setInstallState("installed");
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", installedHandler);
    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installedHandler);
    };
  }, []);

  // ── Auto-play video (muted required for mobile autoplay) ──
  useEffect(() => {
    videoRef.current?.play().catch(() => {});
  }, []);

  // ── Pop download notification during playback ──
  useEffect(() => {
    const t = setTimeout(() => setShowDownload(true), DOWNLOAD_NOTIF_DELAY);
    return () => clearTimeout(t);
  }, []);

  // ── Warm cache in background while video plays ──
  useEffect(() => {
    try {
      const lastRegion = localStorage.getItem("rh_last_map_region");
      if (lastRegion) {
        const region = JSON.parse(lastRegion);
        if (region.center_lat && region.center_lng) {
          const z = 12;
          const n = Math.pow(2, z);
          const x = Math.floor(((region.center_lng + 180) / 360) * n);
          const y = Math.floor(
            ((1 - Math.asinh(Math.tan(region.center_lat * Math.PI / 180)) / Math.PI) / 2) * n
          );
          const img = new Image();
          img.src = `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
        }
      }
    } catch (_) {}
  }, []);

  const handleEnter = () => {
    if (enteredRef.current) return;
    enteredRef.current = true;
    setExiting(true);
    setTimeout(() => onEnter?.(), 450);
  };

  const handleInstall = async () => {
    if (!installPrompt || installState === "installing") return;
    setInstallState("installing");
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === "accepted") {
      setInstallState("installed");
    } else {
      setInstallState("idle");
    }
    setInstallPrompt(null);
  };

  const isIOS =
    typeof navigator !== "undefined" &&
    (/iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));

  return (
    <motion.div
      className="fixed inset-0 z-[99999] overflow-hidden"
      style={{ background: "#000" }}
      animate={exiting ? { opacity: 0 } : { opacity: 1 }}
      transition={{ duration: 0.45, ease: [0.4, 0, 0.2, 1] }}
    >
      {/* ── Full-screen video ── */}
      <video
        ref={videoRef}
        src={VIDEO_URL}
        className="absolute inset-0 w-full h-full object-cover"
        autoPlay
        playsInline
        muted
        preload="auto"
        onEnded={handleEnter}
        onError={handleEnter}
      />

      {/* ── Skip button — top-left, small, deliberately discouraging ── */}
      <button
        onClick={handleEnter}
        className="top-3 left-3 z-20 px-2 py-0.5 rounded transition-opacity hover:opacity-70"
        style={{
          position: "absolute",
          top: 12,
          left: 12,
          fontSize: 10,
          color: "rgba(255,255,255,0.28)",
          letterSpacing: "0.12em",
          textTransform: "uppercase",
          background: "rgba(0,0,0,0.12)",
        }}
      >
        skip
      </button>

      {/* ── Download notification — pops during playback ── */}
      <AnimatePresence>
        {showDownload && installState !== "installed" && (
          <motion.div
            key="download-notif"
            className="absolute bottom-0 left-0 right-0 z-20 px-4"
            style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 16px)" }}
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 60 }}
            transition={{ duration: 0.45, ease: [0.23, 1, 0.32, 1] }}
          >
            <div
              className="max-w-sm mx-auto flex items-center gap-3 p-3 rounded-2xl"
              style={{
                background: "rgba(8,6,18,0.90)",
                backdropFilter: "blur(16px)",
                WebkitBackdropFilter: "blur(16px)",
                border: "1px solid rgba(141,124,255,0.35)",
                boxShadow:
                  "0 0 24px rgba(141,124,255,0.20), 0 8px 32px rgba(0,0,0,0.5)",
              }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: "rgba(141,124,255,0.18)" }}
              >
                <Download className="w-4 h-4" style={{ color: "#8D7CFF" }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-bold text-white">
                  Get RockHound-GO
                </p>
                <p className="text-[11px] text-white/50 leading-tight mt-0.5">
                  {installState === "installing"
                    ? "Installing in background…"
                    : isIOS
                    ? "Share → Add to Home Screen"
                    : "Install — downloads in background"}
                </p>
              </div>
              {!isIOS && (
                <button
                  onClick={handleInstall}
                  disabled={installState === "installing" || !installPrompt}
                  className="px-3 py-1.5 text-[11px] font-bold rounded-lg shrink-0 transition-all active:scale-95 disabled:opacity-50"
                  style={{
                    background: "rgba(141,124,255,0.22)",
                    color: "#C4B5FD",
                    border: "1px solid rgba(141,124,255,0.45)",
                  }}
                >
                  {installState === "installing" ? "…" : "Get"}
                </button>
              )}
              <button
                onClick={() => setShowDownload(false)}
                className="p-1 rounded-lg shrink-0"
                style={{ color: "rgba(255,255,255,0.25)" }}
                aria-label="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Installed confirmation ── */}
      <AnimatePresence>
        {installState === "installed" && (
          <motion.div
            key="installed"
            className="absolute bottom-0 left-0 right-0 z-20 px-4"
            style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 16px)" }}
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 60 }}
            transition={{ duration: 0.4 }}
          >
            <div
              className="max-w-sm mx-auto flex items-center gap-3 p-3 rounded-2xl"
              style={{
                background: "rgba(0,214,143,0.12)",
                backdropFilter: "blur(16px)",
                border: "1px solid rgba(0,214,143,0.35)",
              }}
            >
              <Check className="w-4 h-4 shrink-0" style={{ color: "#00D68F" }} />
              <p className="text-[13px] font-semibold text-white">
                Installed — check your home screen
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}