import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion, AnimatePresence } from "framer-motion";

export const SESSION_KEY = "rh_splash_shown";
const AUTO_ENTER_MS = 3200;

// Geode crack fracture shard positions
const SHARDS = [
  { x: -38, y: -32, rotate: -22, scale: 0.72, delay: 0.55 },
  { x: 36, y: -28, rotate: 18, scale: 0.65, delay: 0.60 },
  { x: -22, y: 36, rotate: -14, scale: 0.60, delay: 0.58 },
  { x: 30, y: 34, rotate: 24, scale: 0.55, delay: 0.62 },
  { x: -52, y: 4, rotate: -30, scale: 0.50, delay: 0.64 },
  { x: 50, y: 6, rotate: 28, scale: 0.48, delay: 0.66 },
];

export default function SplashScreen({ onEnter }) {
  const [phase, setPhase] = useState("boot"); // boot → crack → shatter → reveal → hold → exit
  const [updateInfo, setUpdateInfo] = useState(null);
  const [installPrompt, setInstallPrompt] = useState(null);
  const [installable, setInstallable] = useState(false);

  useEffect(() => {
    const handler = (e) => { e.preventDefault(); setInstallPrompt(e); setInstallable(true); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  // ── Warm cache: preload last region tiles + restore camera permission state ──
  useEffect(() => {
    // Warm cache — prefetch user data and offline pack index in background
    import("@/services/offline/offlinePackService").then(({ getOfflineStorageEstimate }) => {
      getOfflineStorageEstimate(); // touch localStorage to warm it
    }).catch(() => {});

    // Preload last region map tiles if we have a saved region
    try {
      const lastRegion = localStorage.getItem("rh_last_map_region");
      if (lastRegion) {
        const region = JSON.parse(lastRegion);
        if (region.center_lat && region.center_lng) {
          // Preload a single tile at the last known location
          const z = 12;
          const n = Math.pow(2, z);
          const lat = region.center_lat;
          const lng = region.center_lng;
          const x = Math.floor(((lng + 180) / 360) * n);
          const y = Math.floor(((1 - Math.asinh(Math.tan(lat * Math.PI / 180)) / Math.PI) / 2) * n);
          const tileUrl = `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
          const img = new Image();
          img.src = tileUrl; // browser caches it
        }
      }
    } catch (_) {}

    // Restore camera permissions state (check if we previously had camera access)
    try {
      const camPerm = localStorage.getItem("rh_camera_permission");
      if (camPerm === "granted" && navigator.mediaDevices?.getUserMedia) {
        // Just check if we still have permission without actually keeping the stream
        navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
          .then(stream => {
            stream.getTracks().forEach(t => t.stop()); // release immediately
            localStorage.setItem("rh_camera_permission", "granted");
          })
          .catch(() => {
            localStorage.setItem("rh_camera_permission", "denied");
          });
      }
    } catch (_) {}
  }, []);

  useEffect(() => {
    const APP_VERSION = "1.0.0";
    const CACHE_KEY = "rh_version_check";
    const cached = sessionStorage.getItem(CACHE_KEY);
    if (cached) {
      try {
        const data = JSON.parse(cached);
        if (data.latest_version !== APP_VERSION || data.force_update) setUpdateInfo(data);
      } catch (_) {}
      return;
    }
    base44.functions.invoke("getAppVersion", {})
      .then(res => {
        const data = res?.data;
        if (!data) return;
        sessionStorage.setItem(CACHE_KEY, JSON.stringify(data));
        if (data.latest_version !== APP_VERSION || data.force_update) setUpdateInfo(data);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setPhase("crack"));
    const t2 = setTimeout(() => setPhase("shatter"), 900);
    const t3 = setTimeout(() => setPhase("reveal"), 1300);
    const t4 = setTimeout(() => setPhase("hold"), 1900);
    const t5 = setTimeout(() => {
      if (updateInfo?._show) return;
      setPhase("exit");
      setTimeout(() => {
        sessionStorage.setItem(SESSION_KEY, "1");
        onEnter();
      }, 650);
    }, AUTO_ENTER_MS);
    return () => {
      cancelAnimationFrame(raf);
      [t2, t3, t4, t5].forEach(clearTimeout);
    };
  }, [updateInfo, onEnter]);

  const dismissUpdate = () => {
    setUpdateInfo(prev => ({ ...prev, _dismissed: true, _show: false }));
    setPhase("exit");
    setTimeout(() => { sessionStorage.setItem(SESSION_KEY, "1"); onEnter(); }, 600);
  };

  const isCrack     = ["crack", "shatter", "reveal", "hold"].includes(phase);
  const isShatter   = ["shatter", "reveal", "hold"].includes(phase);
  const isReveal    = ["reveal", "hold"].includes(phase);
  const isExit      = phase === "exit";

  return (
    <motion.div
      className="absolute inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden"
      style={{ background: "#020008" }}
      animate={isExit ? { opacity: 0, scale: 1.06 } : { opacity: 1, scale: 1 }}
      transition={{ duration: 0.7, ease: [0.4, 0, 0.2, 1] }}
    >
      {/* ── Deep void base with obsidian-to-slate gradient ── */}
      <div className="absolute inset-0" style={{
        background: "radial-gradient(ellipse 90% 70% at 50% 45%, #120A28 0%, #080418 45%, #030010 80%, #010007 100%)",
      }} />

      {/* ── Tectonic lines background ── */}
      <TectonicLines />

      {/* ── Slow nebula color wash ── */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          style={{
            position: "absolute", inset: "-50%",
            background: `conic-gradient(from 0deg at 50% 50%,
              rgba(141,124,255,0.14) 0deg,
              rgba(122,231,255,0.09) 72deg,
              rgba(0,214,143,0.07) 144deg,
              rgba(212,175,55,0.10) 216deg,
              rgba(141,124,255,0.14) 288deg,
              rgba(141,124,255,0.14) 360deg)`,
            borderRadius: "50%",
            filter: "blur(90px)",
            mixBlendMode: "screen",
          }}
          animate={{ rotate: 360 }}
          transition={{ duration: 70, repeat: Infinity, ease: "linear" }}
        />
      </div>

      {/* ── Crystal cluster + crack animation ── */}
      <div className="absolute flex items-center justify-center" style={{ width: 200, height: 200 }}>

        {/* Crystal orb glow */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: 180, height: 180,
            background: "radial-gradient(ellipse at 38% 32%, rgba(180,160,255,0.30) 0%, rgba(80,50,200,0.15) 40%, transparent 70%)",
            border: "1px solid rgba(141,124,255,0.22)",
          }}
          initial={{ scale: 0, opacity: 0 }}
          animate={isCrack ? { scale: 1, opacity: isExit ? 0 : 0.8 } : {}}
          transition={{ duration: 0.7, ease: [0.34, 1.56, 0.64, 1] }}
        />

        {/* Outer ring */}
        <motion.div
          className="absolute rounded-full"
          style={{ width: 220, height: 220, border: "1px solid rgba(122,231,255,0.22)" }}
          initial={{ scale: 0.5, opacity: 0 }}
          animate={isCrack ? { scale: 1, opacity: 0.7 } : {}}
          transition={{ duration: 0.75, delay: 0.1, ease: [0.23, 1, 0.32, 1] }}
        />

        {/* Crystal gem SVG */}
        <motion.div
          className="absolute"
          initial={{ scale: 0, opacity: 0, rotate: -20 }}
          animate={isCrack ? { scale: 1, opacity: isShatter ? 0 : 1, rotate: 0 } : {}}
          transition={{ duration: 0.65, delay: 0.15, ease: [0.34, 1.56, 0.64, 1] }}
        >
          <CrystalGem size={88} />
        </motion.div>

        {/* Crack fracture line */}
        <motion.div
          className="absolute"
          style={{
            width: 2, height: 0,
            top: "10%", left: "calc(50% - 1px)",
            background: "linear-gradient(180deg, rgba(255,255,255,0.0) 0%, rgba(255,255,255,0.95) 50%, rgba(122,231,255,0.6) 100%)",
            borderRadius: 2,
            boxShadow: "0 0 12px rgba(255,255,255,0.8), 0 0 24px rgba(122,231,255,0.5)",
          }}
          initial={{ height: 0, opacity: 0 }}
          animate={isCrack ? { height: "80%", opacity: [0, 1, 0.7] } : {}}
          transition={{ duration: 0.35, delay: 0.2, ease: "easeOut" }}
        />

        {/* Shatter: shards fly outward */}
        {SHARDS.map((s, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{ width: 22, height: 22, top: "calc(50% - 11px)", left: "calc(50% - 11px)" }}
            initial={{ x: 0, y: 0, rotate: 0, opacity: 0, scale: 0 }}
            animate={isShatter ? {
              x: s.x * 2.2,
              y: s.y * 2.2,
              rotate: s.rotate * 2,
              opacity: isReveal ? 0 : [0, 0.9, 0.6],
              scale: isReveal ? 0 : s.scale,
            } : {}}
            transition={{ duration: isReveal ? 0.25 : 0.35, delay: s.delay, ease: isReveal ? "easeIn" : [0.34, 1.56, 0.64, 1] }}
          >
            <ShardSVG />
          </motion.div>
        ))}
      </div>

      {/* ── Main logo reveal — assembles from shards ── */}
      <motion.div
        className="relative z-10 flex flex-col items-center"
        style={{ marginTop: 200 }}
        initial={{ opacity: 0, y: 30, scale: 0.92 }}
        animate={isReveal ? { opacity: 1, y: 0, scale: 1 } : {}}
        transition={{ duration: 0.65, ease: [0.23, 1, 0.32, 1] }}
      >
        {/* Diamond refraction shimmer above text */}
        <motion.div
          className="relative overflow-hidden mb-2"
          style={{ borderRadius: 4 }}
        >
          <span
            style={{
              fontSize: 46,
              fontWeight: 900,
              letterSpacing: "-0.04em",
              fontFamily: "'Sora', 'Inter', sans-serif",
              background: "linear-gradient(160deg, #FFFFFF 0%, #E0D8FF 25%, #A89BFF 55%, #7AE7FF 80%, #5B4BD4 100%)",
              backgroundSize: "200% 200%",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              filter: "drop-shadow(0 0 28px rgba(141,124,255,0.55))",
              lineHeight: 1.0,
              display: "block",
            }}
          >
            ROCKHOUND-GO
          </span>
          {/* Diamond refraction sweep */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "linear-gradient(105deg, transparent 30%, rgba(255,255,255,0.35) 50%, rgba(122,231,255,0.2) 55%, transparent 70%)",
              borderRadius: 4,
            }}
            initial={{ x: "-120%" }}
            animate={isReveal ? { x: "220%" } : {}}
            transition={{ duration: 0.9, delay: 0.25, ease: "easeInOut" }}
          />
        </motion.div>

        {/* Tagline */}
        <motion.p
          style={{ fontSize: 10, color: "rgba(255,255,255,0.32)", letterSpacing: "0.22em", textTransform: "uppercase", fontWeight: 600 }}
          initial={{ opacity: 0 }}
          animate={isReveal ? { opacity: 1 } : {}}
          transition={{ duration: 0.5, delay: 0.45 }}
        >
          Mineral Discovery Platform
        </motion.p>

        {/* Loading bar */}
        <motion.div
          className="mt-7 relative overflow-hidden rounded-full"
          style={{ width: 160, height: 1.5, background: "rgba(255,255,255,0.06)" }}
          initial={{ opacity: 0 }}
          animate={isReveal ? { opacity: 1 } : {}}
          transition={{ delay: 0.3 }}
        >
          <motion.div
            style={{
              position: "absolute", inset: 0,
              background: "linear-gradient(90deg, transparent, #8D7CFF, #7AE7FF, #8D7CFF, transparent)",
            }}
            initial={{ x: "-100%" }}
            animate={isReveal ? { x: "100%" } : {}}
            transition={{ duration: 1.1, delay: 0.5, ease: "easeInOut", repeat: Infinity, repeatDelay: 0.5 }}
          />
        </motion.div>
      </motion.div>

      {/* ── Pulse rings on hold ── */}
      <AnimatePresence>
        {phase === "hold" && [0, 1].map(i => (
          <motion.div
            key={i}
            className="absolute rounded-full pointer-events-none"
            style={{ border: "1px solid rgba(141,124,255,0.35)" }}
            initial={{ width: 220, height: 220, opacity: 0.5, scale: 1 }}
            animate={{ scale: 2.0, opacity: 0 }}
            transition={{ duration: 1.4, delay: i * 0.5, ease: "easeOut" }}
          />
        ))}
      </AnimatePresence>

      {/* ── Install/Update chip ── */}
      <AnimatePresence>
        {updateInfo?._show && (
          <motion.div
            key="update-toast"
            className="fixed bottom-8 left-0 right-0 z-[99999] flex justify-center px-6"
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 60 }}
            transition={{ duration: 0.4, ease: [0.23, 1, 0.32, 1] }}
          >
            <button
              onClick={installable ? async () => { await installPrompt.prompt(); dismissUpdate(); } : dismissUpdate}
              className="flex items-center gap-3 px-5 py-3 rounded-2xl"
              style={{
                background: "rgba(12,8,28,0.96)",
                border: "1.5px solid rgba(141,124,255,0.55)",
                boxShadow: "0 0 30px rgba(141,124,255,0.35), 0 8px 32px rgba(0,0,0,0.6)",
                backdropFilter: "blur(20px)",
              }}
            >
              <span style={{ fontSize: 22 }}>📲</span>
              <span style={{ fontSize: 14, fontWeight: 700, color: "#C4B5FD", letterSpacing: "0.02em" }}>
                Download ROCKHOUND-GO
              </span>
              <span style={{ fontSize: 12, fontWeight: 800, color: "#8D7CFF", background: "rgba(141,124,255,0.15)", border: "1px solid rgba(141,124,255,0.4)", borderRadius: 8, padding: "2px 8px" }}>TAP</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

// ── Crystal gem SVG ───────────────────────────────────────────────────────────
function CrystalGem({ size = 80 }) {
  return (
    <svg viewBox="0 0 80 80" width={size} height={size} fill="none">
      <defs>
        <linearGradient id="gem-top" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="rgba(220,210,255,0.55)" />
          <stop offset="100%" stopColor="rgba(100,80,220,0.20)" />
        </linearGradient>
        <linearGradient id="gem-mid" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="rgba(122,231,255,0.30)" />
          <stop offset="100%" stopColor="rgba(80,40,200,0.10)" />
        </linearGradient>
        <filter id="gem-glow">
          <feGaussianBlur stdDeviation="3" result="blur" />
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
      {/* Main hexagon crystal */}
      <polygon points="40,4 70,22 70,58 40,76 10,58 10,22" fill="url(#gem-top)" stroke="rgba(141,124,255,0.65)" strokeWidth="1" filter="url(#gem-glow)" />
      {/* Inner facets */}
      <polygon points="40,4 70,22 40,34" fill="rgba(200,190,255,0.22)" />
      <polygon points="10,22 40,34 40,4" fill="rgba(122,231,255,0.14)" />
      <polygon points="40,34 70,22 70,58 40,76" fill="rgba(0,214,143,0.10)" />
      <polygon points="40,34 40,76 10,58 10,22" fill="rgba(141,124,255,0.12)" />
      {/* Center line — the crack */}
      <line x1="40" y1="4" x2="40" y2="76" stroke="rgba(255,255,255,0.15)" strokeWidth="0.5" />
      {/* Specular highlight */}
      <polygon points="40,4 55,18 40,26" fill="rgba(255,255,255,0.18)" />
    </svg>
  );
}

// ── Single shard SVG ──────────────────────────────────────────────────────────
function ShardSVG() {
  return (
    <svg viewBox="0 0 22 22" width="22" height="22" fill="none">
      <polygon points="11,1 21,10 14,21 2,18 3,6" fill="rgba(180,160,255,0.30)" stroke="rgba(141,124,255,0.55)" strokeWidth="0.8" />
      <polygon points="11,1 21,10 11,8" fill="rgba(255,255,255,0.15)" />
    </svg>
  );
}

// ── Tectonic lines background ─────────────────────────────────────────────────
function TectonicLines() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <svg width="100%" height="100%" viewBox="0 0 430 900" preserveAspectRatio="xMidYMid slice" fill="none">
        {/* Faint diagonal tectonic fault lines */}
        {[
          "M0,220 Q180,190 430,240",
          "M0,380 Q200,340 430,400",
          "M0,540 Q160,510 430,560",
          "M0,700 Q220,670 430,710",
          "M60,0 Q90,200 40,900",
          "M180,0 Q210,300 160,900",
          "M320,0 Q350,400 300,900",
        ].map((d, i) => (
          <motion.path
            key={i}
            d={d}
            stroke="rgba(141,124,255,0.06)"
            strokeWidth="1"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: [0, 0.06, 0.04] }}
            transition={{ duration: 3 + i * 0.4, delay: i * 0.15, ease: "easeInOut", repeat: Infinity, repeatType: "mirror", repeatDelay: 8 }}
          />
        ))}
      </svg>
    </div>
  );
}