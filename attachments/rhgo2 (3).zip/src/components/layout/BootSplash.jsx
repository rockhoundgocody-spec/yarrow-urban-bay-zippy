/**
 * BootSplash — Zero-flicker startup screen.
 * Renders instantly from frame 1 (no async, no auth dependency).
 * Covers the auth loading phase so the user never sees a blank screen.
 */
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

// Deterministic particles — no Math.random() during render
const PARTICLES = Array.from({ length: 20 }, (_, i) => {
  const angle = (i / 20) * Math.PI * 2;
  const r = 90 + (i % 4) * 22;
  return {
    x: Math.cos(angle) * r,
    y: Math.sin(angle) * r,
    size: 1.5 + (i % 3),
    color: i % 3 === 0 ? "#8D7CFF" : i % 3 === 1 ? "#7AE7FF" : "#D4AF37",
    delay: i * 0.05,
  };
});

const LETTER_VARIANTS = {
  hidden: { opacity: 0, y: 28, rotateX: -80, filter: "blur(8px)" },
  visible: { opacity: 1, y: 0, rotateX: 0, filter: "blur(0px)" },
};

export default function BootSplash() {
  const [phase, setPhase] = useState("init"); // init → active → done

  useEffect(() => {
    // Tiny rAF defer so the browser paints the black background first
    const raf = requestAnimationFrame(() => setPhase("active"));
    return () => cancelAnimationFrame(raf);
  }, []);

  const title = "ROCKHOUND";
  const subtitle = "GO";

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 99999,
        background: "#02010A",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        overflow: "hidden",
      }}
    >
      {/* ── Deep void radial ── */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(ellipse 70% 70% at 50% 50%, #0D0820 0%, #060212 55%, #02010A 100%)",
        }}
      />

      {/* ── Slow nebula conic rotation ── */}
      <motion.div
        style={{
          position: "absolute",
          inset: "-60%",
          background: `conic-gradient(from 0deg at 50% 50%,
            rgba(141,124,255,0.14) 0deg,
            rgba(122,231,255,0.08) 80deg,
            rgba(0,214,143,0.07) 160deg,
            rgba(212,175,55,0.09) 240deg,
            rgba(141,124,255,0.14) 360deg)`,
          borderRadius: "50%",
          filter: "blur(90px)",
          mixBlendMode: "screen",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 90, repeat: Infinity, ease: "linear" }}
      />

      {/* ── Ambient center glow ── */}
      <motion.div
        style={{
          position: "absolute",
          width: 480,
          height: 480,
          borderRadius: "50%",
          background:
            "radial-gradient(circle, rgba(141,124,255,0.20) 0%, rgba(122,231,255,0.08) 45%, transparent 72%)",
          filter: "blur(50px)",
        }}
        initial={{ opacity: 0, scale: 0.4 }}
        animate={phase === "active" ? { opacity: 1, scale: 1 } : {}}
        transition={{ duration: 1.4, ease: [0.23, 1, 0.32, 1] }}
      />

      {/* ── Shockwave ring ── */}
      <motion.div
        style={{
          position: "absolute",
          width: 8,
          height: 8,
          borderRadius: "50%",
          border: "2px solid rgba(141,124,255,0.9)",
        }}
        initial={{ scale: 1, opacity: 0.9 }}
        animate={phase === "active" ? { scale: 80, opacity: 0 } : {}}
        transition={{ duration: 1.5, ease: [0.23, 1, 0.32, 1] }}
      />

      {/* ── Orbital ring 1 ── */}
      <motion.div
        style={{
          position: "absolute",
          width: 240,
          height: 240,
          borderRadius: "50%",
          border: "1px solid rgba(141,124,255,0.22)",
        }}
        initial={{ opacity: 0, scale: 0.5 }}
        animate={phase === "active" ? { opacity: 1, scale: 1, rotate: 360 } : {}}
        transition={{
          opacity: { duration: 1.2, delay: 0.2 },
          scale: { duration: 1.2, delay: 0.2, ease: [0.34, 1.56, 0.64, 1] },
          rotate: { duration: 30, repeat: Infinity, ease: "linear" },
        }}
      />

      {/* ── Orbital ring 2 ── */}
      <motion.div
        style={{
          position: "absolute",
          width: 310,
          height: 310,
          borderRadius: "50%",
          border: "1px solid rgba(122,231,255,0.10)",
        }}
        initial={{ opacity: 0 }}
        animate={phase === "active" ? { opacity: 1, rotate: -360 } : {}}
        transition={{
          opacity: { duration: 1.5, delay: 0.4 },
          rotate: { duration: 48, repeat: Infinity, ease: "linear" },
        }}
      />

      {/* ── Diamond sparks on ring ── */}
      {phase === "active" &&
        [0, 90, 180, 270].map((deg, i) => (
          <motion.div
            key={deg}
            style={{
              position: "absolute",
              width: 5,
              height: 5,
              borderRadius: 1,
              background: i % 2 === 0 ? "#8D7CFF" : "#7AE7FF",
              boxShadow: `0 0 8px ${i % 2 === 0 ? "#8D7CFF" : "#7AE7FF"}`,
              transform: `rotate(${deg}deg) translateY(-120px) rotate(-${deg}deg)`,
            }}
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: [0, 1, 0.8], scale: 1 }}
            transition={{ duration: 0.8, delay: 0.5 + i * 0.12 }}
          />
        ))}

      {/* ── Particle burst ── */}
      {phase === "active" && (
        <div style={{ position: "absolute", pointerEvents: "none" }}>
          {PARTICLES.map((p, i) => (
            <motion.div
              key={i}
              style={{
                position: "absolute",
                width: p.size,
                height: p.size,
                borderRadius: "50%",
                background: p.color,
                boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
              }}
              initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
              animate={{ x: p.x, y: p.y, opacity: 0, scale: 0 }}
              transition={{
                duration: 1.6,
                delay: 0.1 + p.delay,
                ease: [0.23, 1, 0.32, 1],
              }}
            />
          ))}
        </div>
      )}

      {/* ── Gem icon ── */}
      <motion.div
        style={{
          position: "absolute",
          width: 56,
          height: 56,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
        initial={{ scale: 0, opacity: 0, rotate: -25 }}
        animate={phase === "active" ? { scale: 1, opacity: 1, rotate: 0 } : {}}
        transition={{ duration: 0.7, delay: 0.2, ease: [0.34, 1.56, 0.64, 1] }}
      >
        <svg viewBox="0 0 64 64" width="44" height="44" fill="none">
          <polygon
            points="32,4 56,20 56,44 32,60 8,44 8,20"
            fill="url(#bs-gem)"
            stroke="rgba(141,124,255,0.7)"
            strokeWidth="1.5"
          />
          <polygon points="32,4 56,20 32,28" fill="rgba(180,170,255,0.22)" />
          <polygon points="8,20 32,28 32,4" fill="rgba(122,231,255,0.14)" />
          <polygon points="32,28 56,20 56,44 32,60" fill="rgba(0,214,143,0.10)" />
          <polygon points="32,28 32,60 8,44 8,20" fill="rgba(141,124,255,0.13)" />
          <defs>
            <linearGradient id="bs-gem" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="rgba(200,190,255,0.10)" />
              <stop offset="100%" stopColor="rgba(80,40,200,0.07)" />
            </linearGradient>
          </defs>
        </svg>
      </motion.div>

      {/* ── Horizon line ── */}
      <motion.div
        style={{
          position: "absolute",
          top: "50%",
          left: "12%",
          right: "12%",
          height: 1,
          background:
            "linear-gradient(90deg, transparent, rgba(141,124,255,0.55) 20%, rgba(122,231,255,0.85) 50%, rgba(141,124,255,0.55) 80%, transparent)",
          filter: "blur(0.5px)",
        }}
        initial={{ scaleX: 0, opacity: 0 }}
        animate={phase === "active" ? { scaleX: 1, opacity: [0, 1, 0.5] } : {}}
        transition={{ duration: 0.65, delay: 0.15, ease: [0.23, 1, 0.32, 1] }}
      />

      {/* ── Wordmark block ── */}
      <motion.div
        style={{
          position: "relative",
          zIndex: 10,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          marginTop: 160,
        }}
        initial={{ opacity: 0, y: 20 }}
        animate={phase === "active" ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8, delay: 0.3, ease: [0.23, 1, 0.32, 1] }}
      >
        {/* Letter-forge title */}
        <motion.div
          style={{ display: "flex", alignItems: "center", justifyContent: "center" }}
          initial="hidden"
          animate={phase === "active" ? "visible" : "hidden"}
          variants={{
            visible: {
              transition: { staggerChildren: 0.055, delayChildren: 0.35 },
            },
          }}
        >
          {title.split("").map((letter, i) => (
            <motion.span
              key={i}
              variants={LETTER_VARIANTS}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
              style={{
                fontSize: 42,
                fontWeight: 900,
                letterSpacing: "-0.02em",
                fontFamily: "'Sora', 'Inter', sans-serif",
                background:
                  "linear-gradient(160deg, #FFFFFF 0%, #D8D0FF 28%, #9B8FFF 60%, #5B4BD4 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                filter: "drop-shadow(0 0 18px rgba(141,124,255,0.45))",
                display: "inline-block",
                transformOrigin: "bottom center",
              }}
            >
              {letter}
            </motion.span>
          ))}
        </motion.div>

        {/* GO — expands letter-spacing in */}
        <motion.span
          style={{
            fontSize: 13,
            fontWeight: 700,
            letterSpacing: "0.28em",
            textTransform: "uppercase",
            marginTop: -2,
          }}
          initial={{ opacity: 0, letterSpacing: "0.65em" }}
          animate={
            phase === "active"
              ? { opacity: 1, letterSpacing: "0.28em" }
              : {}
          }
          transition={{ duration: 0.8, delay: 0.9 }}
        >
          <span
            style={{
              background: "linear-gradient(90deg, #7AE7FF, #8D7CFF)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            {subtitle}
          </span>
        </motion.span>

        {/* Tagline */}
        <motion.p
          style={{
            fontSize: 10,
            color: "rgba(255,255,255,0.32)",
            letterSpacing: "0.20em",
            textTransform: "uppercase",
            fontWeight: 600,
            marginTop: 10,
          }}
          initial={{ opacity: 0 }}
          animate={phase === "active" ? { opacity: 1 } : {}}
          transition={{ duration: 0.7, delay: 1.1 }}
        >
          Mineral Discovery Platform
        </motion.p>

        {/* Loading scan bar */}
        <motion.div
          style={{
            marginTop: 28,
            width: 160,
            height: 2,
            background: "rgba(255,255,255,0.05)",
            borderRadius: 99,
            overflow: "hidden",
          }}
          initial={{ opacity: 0 }}
          animate={phase === "active" ? { opacity: 1 } : {}}
          transition={{ delay: 0.7 }}
        >
          <motion.div
            style={{
              height: "100%",
              background:
                "linear-gradient(90deg, transparent, #8D7CFF, #7AE7FF, #8D7CFF, transparent)",
              borderRadius: 99,
            }}
            initial={{ x: "-100%" }}
            animate={phase === "active" ? { x: "100%" } : {}}
            transition={{
              duration: 1.1,
              delay: 0.8,
              ease: "easeInOut",
              repeat: Infinity,
              repeatDelay: 0.3,
            }}
          />
        </motion.div>

        {/* "Loading" micro-label */}
        <motion.p
          style={{
            fontSize: 9,
            color: "rgba(122,231,255,0.35)",
            letterSpacing: "0.25em",
            textTransform: "uppercase",
            fontWeight: 600,
            marginTop: 10,
          }}
          initial={{ opacity: 0 }}
          animate={phase === "active" ? { opacity: [0, 1, 0.6, 1] } : {}}
          transition={{ duration: 2.0, delay: 1.0, repeat: Infinity }}
        >
          Initializing
        </motion.p>
      </motion.div>
    </div>
  );
}