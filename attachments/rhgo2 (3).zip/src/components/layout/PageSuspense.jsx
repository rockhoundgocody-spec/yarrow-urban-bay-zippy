/**
 * PageSuspense — lightweight Suspense boundary for lazy-loaded pages.
 * Uses an inline spinner to avoid any import overhead on the loading state.
 */
import React, { Suspense, memo } from 'react';

const PageFallback = () => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '50vh' }}>
    <div style={{
      width: 24,
      height: 24,
      border: '2.5px solid rgba(255,255,255,0.07)',
      borderTopColor: '#00D68F',
      borderRadius: '50%',
      animation: 'rhPageSpin 0.65s linear infinite',
    }} />
    <style>{`@keyframes rhPageSpin { to { transform: rotate(360deg); } }`}</style>
  </div>
);

function PageSuspense({ children }) {
  return <Suspense fallback={<PageFallback />}>{children}</Suspense>;
}

export default memo(PageSuspense);