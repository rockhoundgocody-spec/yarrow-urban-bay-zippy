/**
 * AppShell — Global layout wrapper.
 * Consumes Home/Field mode from useModeStore and applies:
 * - body class (rh-home / rh-field) for global CSS targeting
 * - CSS custom properties from modeCSSVars for all children
 * - Atmospheric background layers that shift per mode
 * - Visual tone (premium vs tactical) via inline style vars
 */
import React from "react";
import clsx from "clsx";
import { useModeStore } from "@/lib/modeStore.jsx";
import { modeCSSVars, modeTheme } from "@/lib/modeTokens.js";
// NOTE: LiquidCrystalBackground and ParticleField are intentionally NOT rendered here.
// They are rendered once at the Layout level (layout.jsx) to avoid remount flash on navigation.

export default function AppShell({
  children,
  className = "",
  mode: shellMode = "adventure",
  withParticles = true,
  withCaustics = true,
  withNavOffset = true,
  fullBleed = false,
  style = {},
}) {
  const { mode, isField } = useModeStore();
  const cssVars = modeCSSVars(mode);
  const theme = modeTheme(mode);

  // Body class is managed by LayoutInner (layout.jsx) to avoid flash on AppShell unmount/remount

  return (
    <div
      className="relative"
      style={{ ...cssVars, minHeight: '100dvh', ...style }}
    >
      <div
        className={clsx(
          "relative z-10 w-full text-white",
          !fullBleed && "px-4 max-w-7xl mx-auto",
          "pt-4",
          withNavOffset && "pb-28",
          className
        )}
        style={{ minHeight: '100dvh' }}
      >
        {children}
      </div>
    </div>
  );
}