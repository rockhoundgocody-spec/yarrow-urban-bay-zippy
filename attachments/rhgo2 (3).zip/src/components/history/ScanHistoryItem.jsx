/**
 * ScanHistoryItem — one identified specimen row: photo, name, expandable analysis report.
 */
import React, { useState, useId } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ChevronDown, ChevronUp, Gem } from "lucide-react";
import { format } from "date-fns";

function ReportRow({ label, value }) {
  if (!value && value !== 0) return null;
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-[10px] font-bold uppercase tracking-wider shrink-0" style={{ color: "rgba(255,255,255,0.30)" }}>{label}</span>
      <span className="text-xs text-right" style={{ color: "rgba(255,255,255,0.65)" }}>{value}</span>
    </div>
  );
}

export default function ScanHistoryItem({ specimen }) {
  const [open, setOpen] = useState(false);
  const contentId = useId();
  const photo = specimen.photo_url || specimen.photo_urls?.[0];
  const confidence = typeof specimen.confidence === "number" ? Math.round(specimen.confidence) : null;
  const confColor = confidence >= 80 ? "#00D68F" : confidence >= 55 ? "#F5B642" : "#8D7CFF";

  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}>
      <button type="button" onClick={() => setOpen(!open)} className="w-full flex items-center gap-3 p-3 text-left" aria-expanded={open} aria-controls={contentId}>
        {/* Photo */}
        <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 flex items-center justify-center" style={{ background: "rgba(122,231,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
          {photo
            ? <img src={photo} alt={specimen.name || specimen.mineral_type} className="w-full h-full object-cover" loading="lazy" />
            : <Gem className="w-6 h-6" style={{ color: "rgba(122,231,255,0.4)" }} />}
        </div>

        {/* Summary */}
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-white truncate">{specimen.name || specimen.mineral_type || "Unidentified"}</p>
          {specimen.variety && <p className="text-[11px] truncate" style={{ color: "rgba(122,231,255,0.55)" }}>{specimen.variety}</p>}
          <div className="flex items-center gap-2 mt-1">
            {confidence !== null && (
              <span className="text-[10px] font-black tabular-nums px-1.5 py-0.5 rounded-md" style={{ color: confColor, background: `${confColor}18` }}>
                {confidence}%
              </span>
            )}
            <span className="text-[10px]" style={{ color: "rgba(255,255,255,0.30)" }}>
              {specimen.created_date ? format(new Date(specimen.created_date), "MMM d, yyyy") : ""}
            </span>
          </div>
        </div>

        {open ? <ChevronUp className="w-4 h-4 shrink-0 text-white/30" aria-hidden="true" /> : <ChevronDown className="w-4 h-4 shrink-0 text-white/30" aria-hidden="true" />}
      </button>

      {/* Analysis report */}
      <motion.div id={contentId} initial={false} animate={{ height: open ? "auto" : 0 }} className="overflow-hidden">
        <div className="px-4 pb-4 pt-3 space-y-2 border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          {specimen.ai_explanation && (
            <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.55)" }}>{specimen.ai_explanation}</p>
          )}
          <ReportRow label="Color" value={specimen.color} />
          <ReportRow label="Luster" value={specimen.luster} />
          <ReportRow label="Hardness" value={specimen.hardness} />
          <ReportRow label="Crystal system" value={specimen.crystal_system} />
          <ReportRow label="Streak" value={specimen.streak_color} />
          <ReportRow label="Rarity" value={specimen.rarity} />
          <ReportRow
            label="Est. value"
            value={specimen.valuation_low && specimen.valuation_high ? `$${specimen.valuation_low}–$${specimen.valuation_high}` : null}
          />
          {specimen.ai_tests_suggested?.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wider mb-1" style={{ color: "rgba(255,255,255,0.30)" }}>Suggested tests</p>
              <ul className="space-y-1">
                {specimen.ai_tests_suggested.slice(0, 4).map((t, i) => (
                  <li key={i} className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>• {typeof t === "string" ? t : t.name || t.test || ""}</li>
                ))}
              </ul>
            </div>
          )}
          <Link
            to={`/IdentifyResult?id=${specimen.id}`}
            className="block pt-2 text-xs font-semibold"
            style={{ color: "rgba(122,231,255,0.7)" }}
          >
            View Full Report →
          </Link>
        </div>
      </motion.div>
    </div>
  );
}