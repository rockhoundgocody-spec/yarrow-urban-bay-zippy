/**
 * PermissionsWizard.jsx
 * Step 1.3 of the onboarding flow — guides users through granting
 * camera, location, and notification permissions.
 *
 * Each permission step explains why it's needed and provides a
 * request button. Camera is optional (guest mode works without it
 * but scan won't function). Location is recommended for map features.
 */
import React, { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, MapPin, Bell, CheckCircle, AlertCircle, ChevronRight, Shield } from "lucide-react";

const PERMISSION_STEPS = [
  {
    id: "location",
    icon: MapPin,
    title: "Location Access",
    description: "Enables the field map to show your position, nearby collecting sites, and region-based offline packs.",
    why: "Required for map navigation, proximity alerts, and trip planning.",
    accent: "#00D68F",
    accentRgb: "0,214,143",
    optional: false,
  },
  {
    id: "camera",
    icon: Camera,
    title: "Camera Access",
    description: "Lets you photograph and identify minerals with AI, and log field discoveries with photos.",
    why: "Required for the specimen scanner. Without it, you can still browse the map and collection.",
    accent: "#F5B642",
    accentRgb: "245,182,66",
    optional: true,
  },
  {
    id: "notifications",
    icon: Bell,
    title: "Notifications",
    description: "Receive alerts for nearby discoveries, weather hazards, quest completions, and community activity.",
    why: "Keeps you informed about field conditions and app activity.",
    accent: "#8D7CFF",
    accentRgb: "141,124,255",
    optional: true,
  },
];

export default function PermissionsWizard({ onComplete }) {
  const [stepIndex, setStepIndex] = useState(0);
  const [permissions, setPermissions] = useState({
    location: null, // null = not requested, true = granted, false = denied
    camera: null,
    notifications: null,
  });
  const [error, setError] = useState(null);

  const currentStep = PERMISSION_STEPS[stepIndex];
  const isLast = stepIndex === PERMISSION_STEPS.length - 1;

  const requestLocation = useCallback(async () => {
    setError(null);
    if (!navigator.geolocation) {
      setPermissions(p => ({ ...p, location: false }));
      setError("Geolocation is not supported on this device");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      () => setPermissions(p => ({ ...p, location: true })),
      (err) => {
        setPermissions(p => ({ ...p, location: false }));
        if (err.code === err.PERMISSION_DENIED) {
          setError("Location permission denied. You can enable it later in your device settings.");
        } else {
          setError("Could not get location. Please try again.");
        }
      },
      { timeout: 10000, enableHighAccuracy: false }
    );
  }, []);

  const requestCamera = useCallback(async () => {
    setError(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setPermissions(p => ({ ...p, camera: false }));
        setError("Camera access is not supported on this device");
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      stream.getTracks().forEach(t => t.stop());
      setPermissions(p => ({ ...p, camera: true }));
    } catch (err) {
      setPermissions(p => ({ ...p, camera: false }));
      if (err.name === "NotAllowedError") {
        setError("Camera permission denied. You can enable it later in your device settings.");
      } else {
        setError("Could not access camera. You can retry later.");
      }
    }
  }, []);

  const requestNotifications = useCallback(async () => {
    setError(null);
    if (!("Notification" in window)) {
      setPermissions(p => ({ ...p, notifications: false }));
      setError("Notifications are not supported on this device");
      return;
    }
    if (Notification.permission === "granted") {
      setPermissions(p => ({ ...p, notifications: true }));
      return;
    }
    const result = await Notification.requestPermission();
    setPermissions(p => ({ ...p, notifications: result === "granted" }));
    if (result !== "granted") {
      setError("Notifications denied. You can enable them later in your browser settings.");
    }
  }, []);

  const handleRequest = useCallback(() => {
    switch (currentStep.id) {
      case "location": return requestLocation();
      case "camera": return requestCamera();
      case "notifications": return requestNotifications();
    }
  }, [currentStep, requestLocation, requestCamera, requestNotifications]);

  const handleSkip = useCallback(() => {
    setPermissions(p => ({ ...p, [currentStep.id]: false }));
  }, [currentStep]);

  const handleNext = useCallback(() => {
    if (isLast) {
      onComplete?.(permissions);
    } else {
      setStepIndex(i => i + 1);
      setError(null);
    }
  }, [isLast, onComplete, permissions]);

  const permStatus = permissions[currentStep.id];

  return (
    <div className="fixed inset-0 z-50 flex flex-col" style={{ background: "#05070A" }}>
      {/* Ambient glow */}
      <motion.div
        className="pointer-events-none absolute inset-x-0 top-0 h-64"
        animate={{ background: `radial-gradient(ellipse at 50% 0%, rgba(${currentStep.accentRgb},0.08) 0%, transparent 70%)` }}
        transition={{ duration: 0.5 }}
      />

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between px-6 pt-12 pb-2 flex-shrink-0"
        style={{ paddingTop: "max(48px, env(safe-area-inset-top, 48px))" }}>
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4" style={{ color: currentStep.accent }} />
          <span className="text-xs font-bold tracking-widest uppercase" style={{ color: "rgba(255,255,255,0.4)" }}>
            Permissions · {stepIndex + 1}/{PERMISSION_STEPS.length}
          </span>
        </div>
        <button onClick={() => onComplete?.(permissions)}
          className="text-xs font-semibold px-3 py-1.5 rounded-xl transition-all active:scale-95"
          style={{ color: "rgba(255,255,255,0.4)", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", minHeight: 36 }}>
          Skip All
        </button>
      </div>

      {/* Progress dots */}
      <div className="relative z-10 flex items-center gap-1.5 px-6 pb-4">
        {PERMISSION_STEPS.map((step, i) => (
          <motion.div key={step.id} className="rounded-full"
            animate={{
              width: i === stepIndex ? 20 : 5,
              background: i < stepIndex
                ? `${step.accent}45`
                : i === stepIndex
                ? currentStep.accent
                : "rgba(255,255,255,0.14)",
            }}
            style={{ height: 4 }}
            transition={{ type: "spring", stiffness: 420, damping: 30 }} />
        ))}
      </div>

      {/* Content */}
      <div className="relative z-10 flex-1 overflow-hidden flex flex-col px-6 py-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={stepIndex}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
            className="flex flex-col flex-1">

            {/* Icon */}
            <div className="flex items-center justify-center mb-8 mt-4">
              <div className="relative w-24 h-24 rounded-3xl flex items-center justify-center"
                style={{
                  background: `${currentStep.accent}12`,
                  border: `1.5px solid ${currentStep.accent}40`,
                  boxShadow: `0 0 40px ${currentStep.accent}25`,
                }}>
                {permStatus === true ? (
                  <CheckCircle className="w-10 h-10" style={{ color: currentStep.accent }} />
                ) : (
                  <currentStep.icon className="w-10 h-10" style={{ color: currentStep.accent }} />
                )}
                {permStatus === true && (
                  <motion.div
                    className="absolute inset-0 rounded-3xl"
                    style={{ border: `2px solid ${currentStep.accent}` }}
                    initial={{ scale: 1, opacity: 0.6 }}
                    animate={{ scale: 1.3, opacity: 0 }}
                    transition={{ duration: 0.8, repeat: 2 }} />
                )}
              </div>
            </div>

            {/* Title & description */}
            <motion.h1 className="text-2xl font-bold text-center text-white mb-2"
              initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 }}>
              {currentStep.title}
            </motion.h1>

            {currentStep.optional && (
              <p className="text-center text-[10px] font-bold uppercase tracking-wider mb-3"
                style={{ color: "rgba(255,255,255,0.3)" }}>
                Optional
              </p>
            )}

            <motion.p className="text-sm text-center leading-relaxed mb-4"
              style={{ color: "rgba(255,255,255,0.5)" }}
              initial={{ opacity: 0, y: 3 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
              {currentStep.description}
            </motion.p>

            <motion.div className="mx-auto max-w-sm px-4 py-3 rounded-xl mb-6"
              style={{ background: `${currentStep.accent}08`, border: `1px solid ${currentStep.accent}18` }}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.14 }}>
              <p className="text-xs text-center" style={{ color: `${currentStep.accent}90` }}>
                {currentStep.why}
              </p>
            </motion.div>

            {/* Error message */}
            {error && (
              <motion.div
                className="mx-auto max-w-sm px-4 py-3 rounded-xl mb-4 flex items-center gap-2"
                style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)" }}
                initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <p className="text-xs text-red-300">{error}</p>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom CTA */}
      <div className="relative z-10 px-6 pb-12 pt-3 flex-shrink-0 space-y-3">
        {permStatus === null ? (
          <motion.button onClick={handleRequest}
            className="w-full py-4 rounded-2xl text-base font-bold flex items-center justify-center gap-2"
            style={{
              background: `linear-gradient(135deg, ${currentStep.accent}, rgba(${currentStep.accentRgb},0.7))`,
              color: "#000",
              boxShadow: `0 4px 24px rgba(${currentStep.accentRgb},0.30)`,
              minHeight: 56,
            }}
            whileTap={{ scale: 0.97 }}>
            Allow {currentStep.title} <ChevronRight className="w-5 h-5" />
          </motion.button>
        ) : (
          <motion.button onClick={handleNext}
            className="w-full py-4 rounded-2xl text-base font-bold flex items-center justify-center gap-2"
            style={{
              background: permStatus === true
                ? `linear-gradient(135deg, ${currentStep.accent}, rgba(${currentStep.accentRgb},0.7))`
                : "rgba(255,255,255,0.08)",
              color: permStatus === true ? "#000" : "#fff",
              border: permStatus === true ? "none" : "1px solid rgba(255,255,255,0.1)",
              minHeight: 56,
            }}
            whileTap={{ scale: 0.97 }}>
            {isLast ? "Enter RockHound-GO" : "Continue"} <ChevronRight className="w-5 h-5" />
          </motion.button>
        )}

        {permStatus === null && currentStep.optional && (
          <button onClick={() => { handleSkip(); handleNext(); }}
            className="w-full text-xs font-medium py-2 transition-colors"
            style={{ color: "rgba(255,255,255,0.25)", minHeight: 36 }}>
            Skip for now
          </button>
        )}
      </div>
    </div>
  );
}