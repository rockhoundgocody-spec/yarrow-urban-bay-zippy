/**
 * OnboardingTips — dismissible contextual tip strip for first-time users.
 * Shows rotating, actionable hints. Dismissed once per surface via localStorage.
 * Non-intrusive: sits inline, never blocks interaction.
 */
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lightbulb, X, ChevronRight } from "lucide-react";

const STORAGE_PREFIX = "rh_tip_dismissed_";

export default function OnboardingTips({ surface, tips = [], className = "" }) {
  const [visible, setVisible] = useState(false);
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (!tips.length) return;
    const dismissed = localStorage.getItem(`${STORAGE_PREFIX}${surface}`);
    if (!dismissed) {
      // Small delay so it appears after page settles
      const t = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(t);
    }
  }, [surface, tips.length]);

  const dismiss = () => {
    localStorage.setItem(`${STORAGE_PREFIX}${surface}`, "1");
    setVisible(false);
  };

  const next = () => {
    if (index < tips.length - 1) {
      setIndex(index + 1);
    } else {
      dismiss();
    }
  };

  if (!visible || !tips.length) return null;
  const tip = tips[index];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -6 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -6 }}
        transition={{ duration: 0.2 }}
        className={`relative flex items-center gap-2.5 px-3.5 py-2.5 rounded-2xl ${className}`}
        style={{
          background: "linear-gradient(135deg, rgba(245,182,66,0.08) 0%, rgba(141,124,255,0.06) 100%)",
          border: "1px solid rgba(245,182,66,0.18)",
        }}
      >
        <Lightbulb className="w-4 h-4 flex-shrink-0" style={{ color: "#F5B642" }} />

        <div className="flex-1 min-w-0">
          <p className="text-[12px] font-medium leading-tight" style={{ color: "rgba(255,255,255,0.75)" }}>
            {tip.text}
          </p>
        </div>

        {tip.to && (
          <a
            href={tip.to}
            onClick={(e) => { e.preventDefault(); window.location.href = tip.to; }}
            className="flex-shrink-0 flex items-center gap-0.5 px-2 py-1 rounded-lg text-[11px] font-bold"
            style={{ color: "#F5B642", background: "rgba(245,182,66,0.10)" }}
          >
            Go
            <ChevronRight className="w-3 h-3" />
          </a>
        )}

        {/* Pagination dots */}
        {tips.length > 1 && (
          <div className="flex items-center gap-1 flex-shrink-0">
            {tips.map((_, i) => (
              <span
                key={i}
                className="w-1 h-1 rounded-full transition-all"
                style={{
                  background: i === index ? "#F5B642" : "rgba(255,255,255,0.15)",
                  width: i === index ? 6 : 3,
                }}
              />
            ))}
          </div>
        )}

        <button
          onClick={next}
          aria-label={index < tips.length - 1 ? "Next tip" : "Dismiss tips"}
          className="flex-shrink-0 p-1 rounded-lg transition-colors hover:bg-white/5"
          style={{ color: "rgba(255,255,255,0.25)" }}
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </motion.div>
    </AnimatePresence>
  );
}