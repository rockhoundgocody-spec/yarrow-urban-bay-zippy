import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { motion } from 'framer-motion';
import { MapPin, Plus, Wifi, WifiOff, Download, Trash2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import MapRegionDownloader from './MapRegionDownloader';
import WaypointEditor from './WaypointEditor';

export default function OfflineMapViewer() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [downloadedRegions, setDownloadedRegions] = useState([]);
  const [waypoints, setWaypoints] = useState([]);
  const [user, setUser] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState(null);
  const [showWaypointEditor, setShowWaypointEditor] = useState(false);
  const [currentLocation, setCurrentLocation] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  // Track online/offline
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load user and data
  useEffect(() => {
    const loadData = async () => {
      try {
        const me = await base44.auth.me();
        setUser(me);

        // Fetch downloaded regions
        const regions = await base44.entities.DownloadedMapRegion.filter({
          created_by: me.email,
          is_active: true,
        });
        setDownloadedRegions(regions);

        // Fetch waypoints
        const pts = await base44.entities.WaypointNote.filter({
          created_by: me.email,
        });
        setWaypoints(pts);

        if (regions.length > 0) {
          setSelectedRegion(regions[0]);
        }
      } catch (err) {
        console.error('Failed to load offline data:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  const handleDeleteRegion = async (regionId) => {
    try {
      await base44.entities.DownloadedMapRegion.delete(regionId);
      setDownloadedRegions((prev) => prev.filter((r) => r.id !== regionId));
      if (selectedRegion?.id === regionId) {
        setSelectedRegion(downloadedRegions[0] || null);
      }
    } catch (err) {
      console.error('Failed to delete region:', err);
    }
  };

  const handleAddWaypoint = () => {
    if (!currentLocation) {
      alert('Click on the map to set a location');
      return;
    }
    setShowWaypointEditor(true);
  };

  const regionWaypoints = selectedRegion
    ? waypoints.filter(
        (w) =>
          w.latitude <= selectedRegion.north_lat &&
          w.latitude >= selectedRegion.south_lat &&
          w.longitude <= selectedRegion.east_lng &&
          w.longitude >= selectedRegion.west_lng
      )
    : [];

  const mapCenter = selectedRegion
    ? [
        (selectedRegion.north_lat + selectedRegion.south_lat) / 2,
        (selectedRegion.east_lng + selectedRegion.west_lng) / 2,
      ]
    : [39.8283, -98.5795]; // Default USA center

  return (
    <div className="min-h-screen px-4 pt-6 pb-28">
      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
      >
        {/* Header with online/offline indicator */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-white">Offline Map</h1>
          <div className="flex items-center gap-2 px-3 py-1 rounded-full" style={{ background: 'rgba(255,255,255,0.05)' }}>
            {isOnline ? (
              <>
                <Wifi className="w-4 h-4 text-green-400" />
                <span className="text-xs font-semibold text-green-400">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-semibold text-amber-400">Offline</span>
              </>
            )}
          </div>
        </div>

        {/* Region selector and downloader */}
        <div className="flex gap-3 mb-6">
          {downloadedRegions.length > 0 && (
            <select
              value={selectedRegion?.id || ''}
              onChange={(e) => {
                const region = downloadedRegions.find((r) => r.id === e.target.value);
                setSelectedRegion(region);
              }}
              className="flex-1 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
            >
              {downloadedRegions.map((region) => (
                <option key={region.id} value={region.id}>
                  {region.region_name} ({region.local_storage_size_mb?.toFixed(1) || '?'} MB)
                </option>
              ))}
            </select>
          )}

          <MapRegionDownloader onRegionSelected={() => window.location.reload()} />
        </div>

        {/* Map container */}
        {!isLoading && (
          <div className="rounded-2xl overflow-hidden mb-6" style={{ height: '500px', border: '1px solid rgba(255,255,255,0.1)' }}>
            <MapContainer center={mapCenter} zoom={selectedRegion?.zoom_level || 10} style={{ height: '100%', width: '100%' }}>
              <TileLayer
                url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='© OpenStreetMap contributors'
              />

              {/* Waypoint markers */}
              {regionWaypoints.map((waypoint) => (
                <Marker
                  key={waypoint.id}
                  position={[waypoint.latitude, waypoint.longitude]}
                  onClick={() => setCurrentLocation({ lat: waypoint.latitude, lng: waypoint.longitude })}
                >
                  <Popup>
                    <div className="max-w-xs">
                      <h4 className="font-bold text-sm mb-1">{waypoint.title}</h4>
                      <p className="text-xs text-gray-600 mb-2">{waypoint.description}</p>
                      <span className="inline-block px-2 py-0.5 rounded text-xs bg-emerald-100 text-emerald-800">
                        {waypoint.waypoint_type}
                      </span>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        )}

        {/* Region info and waypoints */}
        {selectedRegion && (
          <div className="space-y-4">
            {/* Region details */}
            <div className="rounded-2xl p-6" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)' }}>
              <h2 className="text-lg font-bold text-white mb-4">{selectedRegion.region_name}</h2>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/50">Downloaded</p>
                  <p className="text-white font-semibold">{new Date(selectedRegion.downloaded_date).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/50">Storage Size</p>
                  <p className="text-white font-semibold">{selectedRegion.local_storage_size_mb?.toFixed(1) || '?'} MB</p>
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/50">Status</p>
                  <span className="inline-block px-2 py-1 rounded-full text-xs font-bold" style={{ background: 'rgba(34,197,94,0.2)', color: '#22C55E' }}>
                    ✓ Available
                  </span>
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-widest text-white/50">Expires</p>
                  <p className="text-white font-semibold">{new Date(selectedRegion.expiration_date).toLocaleDateString()}</p>
                </div>
              </div>

              <button
                onClick={() => handleDeleteRegion(selectedRegion.id)}
                className="w-full py-2 rounded-lg text-red-400 border border-red-500/30 hover:bg-red-500/10 transition flex items-center justify-center gap-2 text-sm font-semibold"
              >
                <Trash2 className="w-4 h-4" />
                Remove Region
              </button>
            </div>

            {/* Waypoints */}
            <div className="rounded-2xl p-6" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)' }}>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white">Waypoints ({regionWaypoints.length})</h3>
                <button
                  onClick={handleAddWaypoint}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-white text-sm font-semibold"
                  style={{ background: 'rgba(0,214,143,0.2)', border: '1px solid rgba(0,214,143,0.4)' }}
                >
                  <Plus className="w-4 h-4" />
                  Add
                </button>
              </div>

              {regionWaypoints.length > 0 ? (
                <div className="space-y-3">
                  {regionWaypoints.map((wp) => (
                    <div
                      key={wp.id}
                      className="p-3 rounded-lg"
                      style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                    >
                      <div className="flex items-start gap-3">
                        <MapPin className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-bold text-white text-sm">{wp.title}</h4>
                          <p className="text-xs text-white/50 mt-1">{wp.description}</p>
                          <div className="flex gap-2 mt-2">
                            <span className="px-2 py-1 rounded-full text-xs bg-white/10 text-white/70">
                              {wp.waypoint_type}
                            </span>
                            {wp.yield_rating && (
                              <span className="px-2 py-1 rounded-full text-xs bg-amber-500/10 text-amber-400">
                                ⭐ {wp.yield_rating}/5
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-white/40">No waypoints yet. Click the map to add one.</p>
              )}
            </div>
          </div>
        )}

        {!selectedRegion && !isLoading && (
          <div className="rounded-2xl p-12 text-center" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <Download className="w-12 h-12 mx-auto mb-4 text-white/40" />
            <h3 className="text-lg font-bold text-white mb-2">No regions downloaded yet</h3>
            <p className="text-white/50 mb-6">Download a map region to get started with offline maps</p>
            <MapRegionDownloader onRegionSelected={() => window.location.reload()} />
          </div>
        )}
      </motion.div>

      {/* Waypoint Editor */}
      <WaypointEditor
        isOpen={showWaypointEditor}
        onClose={() => setShowWaypointEditor(false)}
        currentLocation={currentLocation}
        onSaved={() => {
          setWaypoints([]);
          setShowWaypointEditor(false);
          window.location.reload();
        }}
      />
    </div>
  );
}