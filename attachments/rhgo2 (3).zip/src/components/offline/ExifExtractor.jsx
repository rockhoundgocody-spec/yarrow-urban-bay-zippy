/**
 * EXIF data extraction from uploaded images.
 * Extracts GPS, datetime, and camera info from JPEG/HEIF images.
 * Pure JS — no external dependencies.
 */

export async function extractExifFromFile(file) {
  const result = {
    latitude: null,
    longitude: null,
    datetime: null,
    camera: null,
    hasGps: false,
  };

  try {
    const buffer = await file.arrayBuffer();
    const view = new DataView(buffer);

    // Check for JPEG SOI marker
    if (view.getUint16(0) !== 0xFFD8) return result;

    let offset = 2;
    while (offset < view.byteLength - 1) {
      const marker = view.getUint16(offset);
      if (marker === 0xFFE1) {
        // APP1 — EXIF
        const length = view.getUint16(offset + 2);
        const exifData = parseExifSegment(view, offset + 4, length - 2);
        if (exifData) {
          Object.assign(result, exifData);
          if (exifData.latitude !== null && exifData.longitude !== null) {
            result.hasGps = true;
          }
        }
        break;
      }
      // Skip non-EXIF markers
      if ((marker & 0xFF00) !== 0xFF00) break;
      offset += 2 + view.getUint16(offset + 2);
    }
  } catch (e) {
    console.warn("[EXIF] Parse error:", e);
  }

  return result;
}

function parseExifSegment(view, offset, length) {
  const result = { latitude: null, longitude: null, datetime: null, camera: null };

  // Check "Exif\0\0"
  const exifHeader = String.fromCharCode(
    view.getUint8(offset), view.getUint8(offset + 1),
    view.getUint8(offset + 2), view.getUint8(offset + 3)
  );
  if (exifHeader !== "Exif") return null;

  const tiffStart = offset + 6;
  const endian = view.getUint16(tiffStart);
  const littleEndian = endian === 0x4949;

  const get16 = (o) => view.getUint16(o, littleEndian);
  const get32 = (o) => view.getUint32(o, littleEndian);

  // Read IFD0
  const ifd0Offset = tiffStart + get32(tiffStart + 4);
  const ifd0Count = get16(ifd0Offset);

  let gpsIfdOffset = null;
  let exifIfdOffset = null;

  for (let i = 0; i < ifd0Count; i++) {
    const entryOffset = ifd0Offset + 2 + i * 12;
    const tag = get16(entryOffset);
    
    if (tag === 0x010F) {
      // Make
      result.camera = readAsciiTag(view, entryOffset, tiffStart, littleEndian);
    }
    if (tag === 0x0110) {
      // Model
      const model = readAsciiTag(view, entryOffset, tiffStart, littleEndian);
      if (model) result.camera = result.camera ? `${result.camera} ${model}` : model;
    }
    if (tag === 0x8769) {
      exifIfdOffset = tiffStart + get32(entryOffset + 8);
    }
    if (tag === 0x8825) {
      gpsIfdOffset = tiffStart + get32(entryOffset + 8);
    }
  }

  // Read Exif IFD for datetime
  if (exifIfdOffset) {
    const count = get16(exifIfdOffset);
    for (let i = 0; i < count; i++) {
      const entryOffset = exifIfdOffset + 2 + i * 12;
      const tag = get16(entryOffset);
      if (tag === 0x9003 || tag === 0x9004) {
        // DateTimeOriginal or DateTimeDigitized
        const dt = readAsciiTag(view, entryOffset, tiffStart, littleEndian);
        if (dt) {
          // Convert "2024:01:15 14:30:00" to ISO
          result.datetime = dt.replace(/^(\d{4}):(\d{2}):(\d{2})/, "$1-$2-$3");
        }
        break;
      }
    }
  }

  // Read GPS IFD
  if (gpsIfdOffset) {
    const count = get16(gpsIfdOffset);
    let latRef = "N", lonRef = "E";
    let latVals = null, lonVals = null;

    for (let i = 0; i < count; i++) {
      const entryOffset = gpsIfdOffset + 2 + i * 12;
      const tag = get16(entryOffset);

      if (tag === 1) latRef = String.fromCharCode(view.getUint8(entryOffset + 8));
      if (tag === 3) lonRef = String.fromCharCode(view.getUint8(entryOffset + 8));
      if (tag === 2) latVals = readRationalArray(view, entryOffset, tiffStart, littleEndian, 3);
      if (tag === 4) lonVals = readRationalArray(view, entryOffset, tiffStart, littleEndian, 3);
    }

    if (latVals && lonVals) {
      result.latitude = dmsToDecimal(latVals, latRef);
      result.longitude = dmsToDecimal(lonVals, lonRef);
    }
  }

  return result;
}

function readAsciiTag(view, entryOffset, tiffStart, littleEndian) {
  const get16 = (o) => view.getUint16(o, littleEndian);
  const get32 = (o) => view.getUint32(o, littleEndian);
  const count = get32(entryOffset + 4);
  if (count > 200) return null;
  
  let valueOffset;
  if (count <= 4) {
    valueOffset = entryOffset + 8;
  } else {
    valueOffset = tiffStart + get32(entryOffset + 8);
  }
  
  let str = "";
  for (let i = 0; i < count - 1; i++) {
    str += String.fromCharCode(view.getUint8(valueOffset + i));
  }
  return str.trim() || null;
}

function readRationalArray(view, entryOffset, tiffStart, littleEndian, count) {
  const get32 = (o) => view.getUint32(o, littleEndian);
  const valueOffset = tiffStart + get32(entryOffset + 8);
  const result = [];
  for (let i = 0; i < count; i++) {
    const num = get32(valueOffset + i * 8);
    const den = get32(valueOffset + i * 8 + 4);
    result.push(den ? num / den : 0);
  }
  return result;
}

function dmsToDecimal(dms, ref) {
  const [degrees, minutes, seconds] = dms;
  let decimal = degrees + minutes / 60 + seconds / 3600;
  if (ref === "S" || ref === "W") decimal = -decimal;
  return Math.round(decimal * 1000000) / 1000000;
}