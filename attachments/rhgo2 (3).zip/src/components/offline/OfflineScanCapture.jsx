/**
 * OfflineScanCapture
 * Lightweight offline scan capture widget for OfflineFieldMode.
 * Captures photo + GPS, stores to IndexedDB pending_scans queue.
 * No AI identification in offline mode — queued for server processing on reconnect.
 */
import React, { useRef, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, MapPin, CheckCircle2, AlertTriangle, Loader2 } from "lucide-react";
import { enqueueScan } from "@/lib/offlineScannerStore";

export default function OfflineScanCapture({ userLat, userLng, onCaptured }) {
  const fileRef = useRef(null);
  const [status, setStatus] = useState("idle"); // idle | capturing | queued | error
  const [lastCapture, setLastCapture] = useState(null);

  const handleFile = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus("capturing");

    try {
      const scan = await enqueueScan({
        photo_blob: file,
        lat: userLat,
        lng: userLng,
        user_id: null, // resolved server-side on sync
        metadata: {
          label: "Field capture",
          captured_offline: true,
          file_name: file.name,
          file_size: file.size,
          timestamp: new Date().toISOString(),
        },
      });

      setLastCapture({ name: file.name, local_id: scan.local_id });
      setStatus("queued");
      onCaptured?.(scan);

      // Reset after 3s
      setTimeout(() => setStatus("idle"), 3000);
    } catch (err) {
      console.error("[OfflineScan] Capture failed:", err);
      setStatus("error");
      setTimeout(() => setStatus("idle"), 3000);
    }

    // Reset file input
    e.target.value = "";
  }, [userLat, userLng, onCaptured]);

  return (
    <div>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFile}
      />

      <AnimatePresence mode="wait">
        {status === "idle" && (
          <motion.button
            key="idle"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => fileRef.current?.click()}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl transition-all active:scale-[0.97]"
            style={{ background: "rgba(245,182,66,0.10)", border: "1px solid rgba(245,182,66,0.28)" }}
          >
            <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(245,182,66,0.15)", border: "1px solid rgba(245,182,66,0.30)" }}>
              <Camera className="w-4 h-4" style={{ color: "#F5B642" }} />
            </div>
            <div className="text-left flex-1">
              <p className="text-sm font-bold" style={{ color: "#F5B642" }}>Capture Offline Scan</p>
              <p className="text-[10px] text-white/35">Photo queued · AI identifies on reconnect</p>
            </div>
            {userLat != null && (
              <div className="flex items-center gap-1 shrink-0">
                <MapPin className="w-3 h-3" style={{ color: "rgba(245,182,66,0.5)" }} />
                <span className="text-[9px] font-mono" style={{ color: "rgba(245,182,66,0.5)" }}>GPS ✓</span>
              </div>
            )}
          </motion.button>
        )}

        {status === "capturing" && (
          <motion.div key="capturing"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl"
            style={{ background: "rgba(122,231,255,0.07)", border: "1px solid rgba(122,231,255,0.20)" }}>
            <Loader2 className="w-5 h-5 animate-spin shrink-0" style={{ color: "#7AE7FF" }} />
            <span className="text-sm font-semibold" style={{ color: "#7AE7FF" }}>Saving to device…</span>
          </motion.div>
        )}

        {status === "queued" && (
          <motion.div key="queued"
            initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl"
            style={{ background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.28)" }}>
            <CheckCircle2 className="w-5 h-5 shrink-0" style={{ color: "#00D68F" }} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold" style={{ color: "#00D68F" }}>Queued for sync</p>
              <p className="text-[10px] text-white/30 truncate">{lastCapture?.name}</p>
            </div>
          </motion.div>
        )}

        {status === "error" && (
          <motion.div key="error"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-2xl"
            style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.25)" }}>
            <AlertTriangle className="w-5 h-5 shrink-0" style={{ color: "#ef4444" }} />
            <span className="text-sm font-semibold text-red-400">Capture failed — try again</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}