/**
 * Offline-First Sync Engine v3
 * IndexedDB-backed queue with background sync, exponential backoff, and
 * timestamp-based conflict resolution for specimens, field pins, sessions.
 */
import { base44 } from "@/api/base44Client";

const DB_NAME = "rockhound_sync_v3";
const DB_VERSION = 3;
const STORE_QUEUE = "sync_queue";
const STORE_CACHE = "data_cache";
const MAX_RETRIES = 4;
const RETRY_DELAYS = [2000, 8000, 30000, 120000];

// ── IndexedDB helpers ────────────────────────────────────────────────
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_QUEUE)) {
        const qs = db.createObjectStore(STORE_QUEUE, { keyPath: "id", autoIncrement: true });
        qs.createIndex("status", "status", { unique: false });
        qs.createIndex("entity", "entity", { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_CACHE)) {
        const cs = db.createObjectStore(STORE_CACHE, { keyPath: "cache_key" });
        cs.createIndex("entity", "entity", { unique: false });
        cs.createIndex("expires_at", "expires_at", { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbPut(storeName, data) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).put(data);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

/**
 * Bulk put operation in a single transaction.
 * Improves performance by reducing transaction overhead for multiple items.
 */
async function idbPutMany(storeName, items) {
  if (!items.length) return;
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    for (const item of items) {
      store.put(item);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

/**
 * Bulk delete operation in a single transaction.
 */
async function idbDeleteMany(storeName, keys) {
  if (!keys.length) return;
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    for (const key of keys) {
      store.delete(key);
    }
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

async function idbGet(storeName, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbGetAll(storeName, indexName, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readonly");
    const store = tx.objectStore(storeName);
    const req = indexName ? store.index(indexName).getAll(value) : store.getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function idbDelete(storeName, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    tx.objectStore(storeName).delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function idbUpdate(storeName, key, updates) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, "readwrite");
    const store = tx.objectStore(storeName);
    const getReq = store.get(key);
    getReq.onsuccess = () => {
      const record = { ...getReq.result, ...updates };
      store.put(record);
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

// ── Queue operations ─────────────────────────────────────────────────
export async function enqueueOperation(entity, operation, data) {
  await idbPut(STORE_QUEUE, {
    entity,
    operation,
    data,
    status: "pending",
    retries: 0,
    queued_at: Date.now(),
    last_attempt: null,
    error: null,
  });
  if (navigator.onLine) processQueue();
}

export async function getPendingCount() {
  const items = await idbGetAll(STORE_QUEUE, "status", "pending");
  return items.length;
}

export async function getQueueItems() {
  const all = await idbGetAll(STORE_QUEUE);
  return all.sort((a, b) => a.queued_at - b.queued_at);
}

export async function clearFailedItems() {
  const items = await idbGetAll(STORE_QUEUE, "status", "failed");
  if (items.length > 0) {
    await idbDeleteMany(STORE_QUEUE, items.map(item => item.id));
  }
}

// ── Cache operations ─────────────────────────────────────────────────
export async function cacheData(entity, key, data, ttlMs = 30 * 60 * 1000) {
  await idbPut(STORE_CACHE, {
    cache_key: `${entity}:${key}`,
    entity,
    data,
    cached_at: Date.now(),
    expires_at: Date.now() + ttlMs,
  });
}

export async function getCachedData(entity, key) {
  const cacheKey = `${entity}:${key}`;
  const item = await idbGet(STORE_CACHE, cacheKey);
  if (!item) return null;
  if (Date.now() > item.expires_at) {
    await idbDelete(STORE_CACHE, cacheKey);
    return null;
  }
  return item.data;
}

export async function cacheLocations(locations) {
  const now = Date.now();
  const items = locations.map(loc => ({
    cache_key: `RockhoundingLocation:${loc.id}`,
    entity: "RockhoundingLocation",
    data: loc,
    cached_at: now,
    expires_at: now + 24 * 60 * 60 * 1000,
  }));

  // Also cache the full list
  items.push({
    cache_key: "RockhoundingLocation:_list",
    entity: "RockhoundingLocation",
    data: locations,
    cached_at: now,
    expires_at: now + 30 * 60 * 1000,
  });

  await idbPutMany(STORE_CACHE, items);
}

export async function getCachedLocations() {
  return await getCachedData("RockhoundingLocation", "_list");
}

// ── Process queue (sync to server) ───────────────────────────────────
let isSyncing = false;
const syncListeners = new Set();

export function onSyncStatusChange(listener) {
  syncListeners.add(listener);
  return () => syncListeners.delete(listener);
}

function notifyListeners(status) {
  syncListeners.forEach(fn => fn(status));
}

async function fetchServerRecord(entityApi, id) {
  try {
    const all = await entityApi.list();
    return all.find(r => r.id === id) || null;
  } catch {
    return null;
  }
}

function serverIsNewer(serverRecord, queued_at) {
  if (!serverRecord?.updated_date) return false;
  return new Date(serverRecord.updated_date).getTime() > queued_at;
}

export async function processQueue() {
  if (isSyncing || !navigator.onLine) return;
  isSyncing = true;
  notifyListeners({ syncing: true });

  const items = await idbGetAll(STORE_QUEUE, "status", "pending");
  let synced = 0;
  let failed = 0;

  for (const item of items) {
    try {
      await idbUpdate(STORE_QUEUE, item.id, { last_attempt: Date.now() });

      const entityApi = base44.entities[item.entity];
      if (!entityApi) throw new Error(`Unknown entity: ${item.entity}`);

      switch (item.operation) {
        case "create": {
          try {
            await entityApi.create(item.data);
          } catch (err) {
            if (err?.response?.status === 409 || err?.message?.includes("duplicate")) {
              // already exists, treat as success
            } else {
              throw err;
            }
          }
          break;
        }
        case "update": {
          if (!item.data.id) throw new Error("Update requires id");
          const serverRecord = await fetchServerRecord(entityApi, item.data.id);
          if (serverIsNewer(serverRecord, item.queued_at)) {
            console.warn(`[SyncEngine] Conflict: ${item.entity}/${item.data.id} is newer on server. Discarding.`);
            notifyListeners({ conflict: true, entity: item.entity, id: item.data.id });
          } else {
            const { id, ...updateData } = item.data;
            await entityApi.update(id, updateData);
          }
          break;
        }
        case "delete": {
          if (!item.data.id) throw new Error("Delete requires id");
          try {
            await entityApi.delete(item.data.id);
          } catch (err) {
            if (err?.response?.status === 404) {
              // already deleted, treat as success
            } else {
              throw err;
            }
          }
          break;
        }
        default:
          throw new Error(`Unknown operation: ${item.operation}`);
      }

      await idbDelete(STORE_QUEUE, item.id);
      synced++;
    } catch (err) {
      const newRetries = (item.retries || 0) + 1;
      if (newRetries >= MAX_RETRIES) {
        await idbUpdate(STORE_QUEUE, item.id, { status: "failed", retries: newRetries, error: err.message });
        failed++;
      } else {
        await idbUpdate(STORE_QUEUE, item.id, { retries: newRetries, error: err.message });
        setTimeout(() => processQueue(), RETRY_DELAYS[newRetries - 1] || 30000);
      }
    }
  }

  isSyncing = false;
  notifyListeners({ syncing: false, synced, failed });
  return { synced, failed };
}

// ── Network monitor ───────────────────────────────────────────────────
let networkListenersAttached = false;
let bgIntervalId = null;

export function startNetworkMonitor() {
  if (networkListenersAttached) return;
  networkListenersAttached = true;

  window.addEventListener("online", () => {
    notifyListeners({ online: true });
    processQueue();
  });

  window.addEventListener("offline", () => {
    notifyListeners({ offline: true });
  });

  if (!bgIntervalId) {
    bgIntervalId = setInterval(() => {
      if (navigator.onLine) processQueue();
    }, 90_000);
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && navigator.onLine) processQueue();
  });

  if (navigator.onLine) setTimeout(() => processQueue(), 1500);
}

// ── Offline-aware CRUD helpers ────────────────────────────────────────
export async function offlineCreate(entity, data) {
  if (navigator.onLine) return base44.entities[entity].create(data);
  await enqueueOperation(entity, "create", data);
  return { ...data, id: `offline_${Date.now()}_${Math.random().toString(36).slice(2)}`, _offline: true };
}

export async function offlineUpdate(entity, id, data) {
  if (navigator.onLine) return base44.entities[entity].update(id, data);
  await enqueueOperation(entity, "update", { id, ...data });
  return { id, ...data, _offline: true };
}

export async function offlineDelete(entity, id) {
  if (navigator.onLine) return base44.entities[entity].delete(id);
  await enqueueOperation(entity, "delete", { id });
}

// Domain-specific shortcuts
export const offlineCreateSpecimen    = (d) => offlineCreate("Specimen", d);
export const offlineUpdateSpecimen    = (id, d) => offlineUpdate("Specimen", id, d);
export const offlineCreateLocationLog = (d) => offlineCreate("LocationLog", d);
export const offlineCreateSpotting    = (d) => offlineCreate("Spotting", d);
export const offlineCreateFieldPin    = (d) => offlineCreate("SavedMapConfig", { ...d, config_type: "waypoint" });
export const offlineUpdateFieldPin    = (id, d) => offlineUpdate("SavedMapConfig", id, d);
export const offlineDeleteFieldPin    = (id) => offlineDelete("SavedMapConfig", id);
export const offlineCreateFieldSession = (d) => offlineCreate("FieldSession", d);
export const offlineUpdateFieldSession = (id, d) => offlineUpdate("FieldSession", id, d);

export function isOnline() {
  return navigator.onLine;
}

// ── Storage estimate ──────────────────────────────────────────────────
export async function getStorageEstimate() {
  if (!navigator.storage?.estimate) return null;
  return navigator.storage.estimate();
}