/**
 * SpecimenSyncChip
 * Inline sync status indicator for a single specimen card or row.
 * Shows: queued | syncing | synced | failed
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, RefreshCw, Check, AlertTriangle } from "lucide-react";

const CONFIG = {
  queued: {
    icon: Clock,
    label: "Queued for sync",
    bg: "rgba(245,182,66,0.12)",
    border: "rgba(245,182,66,0.3)",
    color: "#F5B642",
  },
  syncing: {
    icon: RefreshCw,
    label: "Syncing…",
    bg: "rgba(122,231,255,0.10)",
    border: "rgba(122,231,255,0.25)",
    color: "#7AE7FF",
    spin: true,
  },
  synced: {
    icon: Check,
    label: "Synced",
    bg: "rgba(0,214,143,0.10)",
    border: "rgba(0,214,143,0.25)",
    color: "#00D68F",
  },
  failed: {
    icon: AlertTriangle,
    label: "Sync failed",
    bg: "rgba(239,68,68,0.10)",
    border: "rgba(239,68,68,0.28)",
    color: "#ef4444",
  },
};

export default function SpecimenSyncChip({ status, compact = false }) {
  const cfg = CONFIG[status] || CONFIG.queued;
  const Icon = cfg.icon;

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={status}
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.85 }}
        transition={{ duration: 0.18 }}
        className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1"
        style={{
          background: cfg.bg,
          border: `1px solid ${cfg.border}`,
          color: cfg.color,
        }}
      >
        <Icon
          className={cfg.spin ? "animate-spin" : ""}
          style={{ width: compact ? 10 : 12, height: compact ? 10 : 12 }}
        />
        {!compact && (
          <span style={{ fontSize: 10, fontWeight: 600, letterSpacing: "0.04em" }}>
            {cfg.label}
          </span>
        )}
      </motion.div>
    </AnimatePresence>
  );
}