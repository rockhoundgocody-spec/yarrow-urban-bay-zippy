import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, X, Star, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function WaypointEditor({ isOpen, onClose, onSaved, currentLocation }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    waypoint_type: 'site_note',
    tags: [],
    difficulty_level: 'moderate',
    yield_rating: 3,
    access_notes: '',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState(null);

  const handleFieldChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleAddTag = (tag) => {
    if (tag && !formData.tags.includes(tag)) {
      setFormData((prev) => ({ ...prev, tags: [...prev.tags, tag] }));
    }
  };

  const handleRemoveTag = (tag) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((t) => t !== tag),
    }));
  };

  const handleSave = async () => {
    setError(null);

    if (!formData.title) {
      setError('Waypoint title is required');
      return;
    }

    setIsSaving(true);

    try {
      const payload = {
        latitude: currentLocation.lat,
        longitude: currentLocation.lng,
        ...formData,
      };

      await base44.entities.WaypointNote.create(payload);
      onSaved?.();
      setFormData({
        title: '',
        description: '',
        waypoint_type: 'site_note',
        tags: [],
        difficulty_level: 'moderate',
        yield_rating: 3,
        access_notes: '',
      });
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to save waypoint');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 bg-black/70 flex items-end z-50"
      initial={{ opacity: 0 }}
      animate={{ opacity: isOpen ? 1 : 0 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      style={{ pointerEvents: isOpen ? 'auto' : 'none' }}
    >
      <motion.div
        className="w-full bg-slate-900 rounded-t-3xl p-6 max-h-[90vh] overflow-y-auto"
        initial={{ y: 400 }}
        animate={{ y: isOpen ? 0 : 400 }}
        exit={{ y: 400 }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Add Waypoint
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition" aria-label="Close">
            <X className="w-5 h-5 text-white/60" />
          </button>
        </div>

        {/* Location display */}
        <div className="rounded-lg p-3 mb-4" style={{ background: 'rgba(122,231,255,0.1)', border: '1px solid rgba(122,231,255,0.3)' }}>
          <p className="text-xs font-bold uppercase tracking-widest text-cyan-400 mb-1">Location</p>
          <p className="text-sm text-white">
            {currentLocation?.lat?.toFixed(4)}, {currentLocation?.lng?.toFixed(4)}
          </p>
        </div>

        {/* Title */}
        <div className="mb-4">
          <label htmlFor="waypoint-title" className="text-xs font-bold uppercase tracking-widest text-white/50">
            Waypoint Title *
          </label>
          <input id="waypoint-title"
            type="text"
            placeholder="e.g., Quartz outcrop, Parking spot"
            value={formData.title}
            onChange={(e) => handleFieldChange('title', e.target.value)}
            className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30"
          />
        </div>

        {/* Type */}
        <div className="mb-4">
          <label htmlFor="waypoint-type" className="text-xs font-bold uppercase tracking-widest text-white/50">
            Waypoint Type
          </label>
          <select id="waypoint-type"
            value={formData.waypoint_type}
            onChange={(e) => handleFieldChange('waypoint_type', e.target.value)}
            className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
          >
            <option value="site_note">Site Note</option>
            <option value="specimen_location">Specimen Location</option>
            <option value="hazard">Hazard</option>
            <option value="landmark">Landmark</option>
            <option value="parking">Parking</option>
            <option value="camp">Camp</option>
            <option value="custom">Custom</option>
          </select>
        </div>

        {/* Description */}
        <div className="mb-4">
          <label htmlFor="waypoint-description" className="text-xs font-bold uppercase tracking-widest text-white/50">
            Description
          </label>
          <textarea id="waypoint-description"
            placeholder="Details about this waypoint..."
            value={formData.description}
            onChange={(e) => handleFieldChange('description', e.target.value)}
            className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30 h-24"
          />
        </div>

        {/* Difficulty & Rating */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <label htmlFor="waypoint-difficulty" className="text-xs font-bold uppercase tracking-widest text-white/50">
              Difficulty
            </label>
            <select id="waypoint-difficulty"
              value={formData.difficulty_level}
              onChange={(e) => handleFieldChange('difficulty_level', e.target.value)}
              className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
            >
              <option value="easy">Easy</option>
              <option value="moderate">Moderate</option>
              <option value="difficult">Difficult</option>
              <option value="expert">Expert</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-bold uppercase tracking-widest text-white/50">
              Yield Rating
            </label>
            <div className="mt-2 flex gap-1">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  onClick={() => handleFieldChange('yield_rating', rating)}
                  className="transition-transform hover:scale-110"
                 aria-label="Rate">
                  <Star
                    className={`w-5 h-5 ${
                      rating <= formData.yield_rating
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-white/20'
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Tags */}
        <div className="mb-4">
          <label htmlFor="waypoint-tags" className="text-xs font-bold uppercase tracking-widest text-white/50 mb-2 block">
            Tags
          </label>
          <div className="flex flex-wrap gap-2 mb-3">
            {formData.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-2"
                style={{ background: 'rgba(0,214,143,0.2)', color: '#00D68F' }}
              >
                {tag}
                <button onClick={() => handleRemoveTag(tag)} className="hover:opacity-60" aria-label="Remove">
                  ×
                </button>
              </span>
            ))}
          </div>
          <input
            type="text"
            placeholder="Type a tag and press Enter"
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleAddTag(e.target.value);
                e.target.value = '';
              }
            }}
            id="waypoint-tags"
            className="w-full px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30 text-sm"
          />
        </div>

        {/* Access notes */}
        <div className="mb-4">
          <label htmlFor="waypoint-access-notes" className="text-xs font-bold uppercase tracking-widest text-white/50">
            Access Notes
          </label>
          <textarea id="waypoint-access-notes"
            placeholder="Parking, permissions, restrictions..."
            value={formData.access_notes}
            onChange={(e) => handleFieldChange('access_notes', e.target.value)}
            className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30 h-16"
          />
        </div>

        {/* Error */}
        {error && (
          <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 flex items-gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-xs text-red-300">{error}</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 pt-4">
          <button
            onClick={onClose}
            className="flex-1 py-3 rounded-lg font-semibold text-white/70 border border-white/20 hover:bg-white/5 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1 py-3 rounded-lg font-semibold text-white"
            style={{ background: 'rgba(0,214,143,0.3)', border: '1px solid rgba(0,214,143,0.5)' }}
          >
            {isSaving ? 'Saving...' : 'Save Waypoint'}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}