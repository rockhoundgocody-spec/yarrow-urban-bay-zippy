/**
 * OfflineSyncStatus — field scanner sync indicator.
 * Shows pending count, sync progress, last sync time.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { WifiOff, RefreshCw, CheckCircle2, Upload } from 'lucide-react';
import { getPendingCount, getMeta } from '@/lib/offlineScannerStore';
import { syncPendingScans, onSyncStatus } from '@/lib/offlineSyncEngine';

export default function OfflineSyncStatus({ compact = false }) {
  const [pending, setPending] = useState(0);
  const [online, setOnline] = useState(navigator.onLine);
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState(null);
  const [lastResult, setLastResult] = useState(null);

  useEffect(() => {
    const refresh = async () => {
      const count = await getPendingCount();
      const ls = await getMeta('last_sync');
      const lr = await getMeta('last_sync_result');
      setPending(count);
      setLastSync(ls);
      setLastResult(lr);
    };
    refresh();
    const interval = setInterval(refresh, 8000);

    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    const unsub = onSyncStatus(({ type, synced, failed }) => {
      if (type === 'start' || type === 'syncing') setSyncing(true);
      if (type === 'complete' || type === 'idle') {
        setSyncing(false);
        if (synced !== undefined) setLastResult({ synced, failed });
        refresh();
      }
    });

    return () => {
      clearInterval(interval);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
      unsub();
    };
  }, []);

  const handleManualSync = async () => {
    if (syncing || !online) return;
    await syncPendingScans();
  };

  const color = !online ? '#ef4444' : pending > 0 ? '#F5B642' : '#00D68F';
  const Icon = !online ? WifiOff : syncing ? RefreshCw : pending > 0 ? Upload : CheckCircle2;

  if (compact) {
    return (
      <motion.div
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg cursor-pointer"
        style={{
          background: `${color}15`,
          border: `1px solid ${color}35`,
        }}
        onClick={handleManualSync}
        whileTap={{ scale: 0.95 }}
        title={online ? (pending > 0 ? `${pending} scans pending sync` : 'All synced') : 'Offline mode'}
      >
        <motion.div animate={syncing ? { rotate: 360 } : {}} transition={{ duration: 1, repeat: syncing ? Infinity : 0, linear: true }}>
          <Icon className="w-3.5 h-3.5" style={{ color }} />
        </motion.div>
        {pending > 0 && (
          <span className="text-[11px] font-bold" style={{ color }}>{pending}</span>
        )}
      </motion.div>
    );
  }

  return (
    <div className="rounded-2xl overflow-hidden" style={{
      background: 'rgba(10,15,22,0.85)',
      border: '1px solid rgba(255,255,255,0.08)',
      boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
    }}>
      <div className="px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}18`, border: `1px solid ${color}35` }}>
            <motion.div animate={syncing ? { rotate: 360 } : {}} transition={{ duration: 1, repeat: syncing ? Infinity : 0, linear: true }}>
              <Icon className="w-5 h-5" style={{ color }} />
            </motion.div>
          </div>
          <div>
            <p className="text-sm font-bold text-white">
              {!online ? 'Offline Mode' : syncing ? 'Syncing…' : pending > 0 ? `${pending} Scans Pending` : 'All Synced'}
            </p>
            {lastSync && (
              <p className="text-xs text-white/40">
                Last sync: {new Date(lastSync).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </p>
            )}
          </div>
        </div>
        {online && pending > 0 && !syncing && (
          <motion.button
            onClick={handleManualSync}
            className="px-4 py-2 rounded-xl text-xs font-bold"
            style={{
              background: `${color}18`,
              border: `1px solid ${color}35`,
              color,
            }}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.96 }}
          >
            Sync Now
          </motion.button>
        )}
      </div>

      {/* Progress details */}
      {(lastResult || pending > 0) && (
        <div className="px-5 pb-4 pt-0 flex items-center gap-4 text-xs text-white/40">
          {lastResult && (
            <>
              <span style={{ color: '#00D68F' }}>{lastResult.synced} synced</span>
              {lastResult.failed > 0 && <span style={{ color: '#ef4444' }}>{lastResult.failed} failed</span>}
            </>
          )}
          {pending > 0 && !online && (
            <span style={{ color: '#F5B642' }}>Will sync when online</span>
          )}
        </div>
      )}
    </div>
  );
}