/**
 * Offline storage using IndexedDB for location data caching.
 */

const DB_NAME = "rockhound_offline";
const DB_VERSION = 1;
const STORE_LOCATIONS = "locations";
const STORE_REGIONS = "regions";

function openDB() {
  return new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error("IndexedDB not available"));
      return;
    }
    let req;
    try {
      req = indexedDB.open(DB_NAME, DB_VERSION);
    } catch (e) {
      reject(e);
      return;
    }
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_LOCATIONS)) {
        const store = db.createObjectStore(STORE_LOCATIONS, { keyPath: "id" });
        store.createIndex("region_id", "region_id", { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_REGIONS)) {
        db.createObjectStore(STORE_REGIONS, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error("IndexedDB blocked"));
  });
}

const CHUNK_SIZE = 50; // max records per IDB transaction to avoid quota errors

function putChunk(db, store, items) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(store, "readwrite");
    const s = tx.objectStore(store);
    for (const item of items) s.put(item);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function saveRegionOffline(region, locations) {
  // Guard: check quota before writing
  if (navigator.storage?.estimate) {
    try {
      const { usage, quota } = await navigator.storage.estimate();
      // Bail out if we're already over 80% of quota
      if (quota > 0 && usage / quota > 0.8) {
        console.warn("[offlineStorage] Storage quota >80% full, skipping region save.");
        return false;
      }
    } catch (_) {}
  }

  const db = await openDB();

  // Save region metadata first
  await putChunk(db, STORE_REGIONS, [{
    ...region,
    downloaded_at: new Date().toISOString(),
    locations_count: locations.length,
  }]);

  // Write locations in chunks to avoid single-transaction quota limits
  for (let i = 0; i < locations.length; i += CHUNK_SIZE) {
    const chunk = locations.slice(i, i + CHUNK_SIZE).map(loc => ({ ...loc, region_id: region.id }));
    try {
      await putChunk(db, STORE_LOCATIONS, chunk);
    } catch (err) {
      if (err?.name === "QuotaExceededError") {
        console.warn(`[offlineStorage] Quota hit at chunk ${i}. Saved ${i} of ${locations.length} locations.`);
        break; // partial save is fine — don't crash
      }
      throw err;
    }
  }

  return true;
}

export async function getOfflineRegions() {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const req = db.transaction(STORE_REGIONS, "readonly").objectStore(STORE_REGIONS).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch (_) { return []; }
}

export async function getAllOfflineLocations() {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const req = db.transaction(STORE_LOCATIONS, "readonly").objectStore(STORE_LOCATIONS).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch (_) { return []; }
}

export async function getLocationsForRegion(regionId) {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const store = db.transaction(STORE_LOCATIONS, "readonly").objectStore(STORE_LOCATIONS);
      const idx = store.index("region_id");
      const req = idx.getAll(regionId);
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });
  } catch (_) { return []; }
}

export async function deleteRegionOffline(regionId) {
  try {
    const db = await openDB();
    const tx = db.transaction([STORE_LOCATIONS, STORE_REGIONS], "readwrite");
    tx.objectStore(STORE_REGIONS).delete(regionId);
    const locStore = tx.objectStore(STORE_LOCATIONS);
    const idx = locStore.index("region_id");
    const keysReq = idx.getAllKeys(regionId);
    keysReq.onsuccess = () => keysReq.result.forEach((k) => locStore.delete(k));
    return new Promise((resolve) => {
      tx.oncomplete = () => resolve(true);
      tx.onerror = () => resolve(false);
    });
  } catch (_) { return false; }
}

export async function getStorageEstimate() {
  if (navigator.storage?.estimate) {
    const { usage, quota } = await navigator.storage.estimate();
    return {
      usageMB: Math.round((usage || 0) / 1024 / 1024),
      quotaMB: Math.round((quota || 0) / 1024 / 1024),
    };
  }
  return { usageMB: 0, quotaMB: 500 };
}