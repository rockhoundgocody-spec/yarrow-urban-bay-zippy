import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, AlertCircle, CheckCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { downloadRegionPack } from '@/services/offline/offlinePackService';

export default function MapRegionDownloader({ onRegionSelected }) {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState('bounds'); // bounds, confirm, downloading, complete
  const [bounds, setBounds] = useState({
    region_name: '',
    north_lat: null,
    south_lat: null,
    east_lng: null,
    west_lng: null,
    zoom_level: 14,
    include_topography: true,
    include_known_sites: true,
    include_user_collection: true,
    include_rules_ethics: true,
    include_field_guide: true,
    include_emergency_info: true,
  });
  const [estimatedData, setEstimatedData] = useState(null);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [error, setError] = useState(null);

  const handleBoundsChange = (field, value) => {
    setBounds((prev) => ({ ...prev, [field]: value }));
  };

  const handleConfirmBounds = async () => {
    setError(null);
    if (
      !bounds.region_name ||
      bounds.north_lat === null ||
      bounds.south_lat === null ||
      bounds.east_lng === null ||
      bounds.west_lng === null
    ) {
      setError('Please fill in all region fields');
      return;
    }

    try {
      setStep('confirm');
      const response = await base44.functions.invoke('downloadMapRegion', bounds);
      setEstimatedData(response.data);
    } catch (err) {
      setError(err.message || 'Failed to estimate download');
      setStep('bounds');
    }
  };

  const handleStartDownload = async () => {
    try {
      setStep('downloading');
      setDownloadProgress(0);

      // Build and save the complete offline pack (tiles + sites + rules + field guide + emergency)
      const pack = await downloadRegionPack(bounds);
      setDownloadProgress(100);

      setStep('complete');
      onRegionSelected?.(pack);
    } catch (err) {
      setError(err.message || 'Download failed');
      setStep('confirm');
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-4 py-2 rounded-lg text-white text-sm font-semibold"
        style={{ background: 'rgba(0,214,143,0.15)', border: '1px solid rgba(0,214,143,0.3)' }}
      >
        <Download className="w-4 h-4" />
        Download Region
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="fixed inset-0 bg-black/70 flex items-end z-50"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
          >
            <motion.div
              className="w-full bg-slate-900 rounded-t-3xl p-6 max-h-[90vh] overflow-y-auto"
              initial={{ y: 400 }}
              animate={{ y: 0 }}
              exit={{ y: 400 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Download Map Region</h2>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-lg transition"
                 aria-label="Close">
                  <X className="w-5 h-5 text-white/60" />
                </button>
              </div>

              {/* Step: Bounds ───────────────────────────────────────────────── */}
              {step === 'bounds' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                      Region Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g., Red Rock Canyon"
                      value={bounds.region_name}
                      onChange={(e) => handleBoundsChange('region_name', e.target.value)}
                      className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/30"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                        North Lat
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={bounds.north_lat || ''}
                        onChange={(e) =>
                          handleBoundsChange('north_lat', parseFloat(e.target.value) || null)
                        }
                        className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                        South Lat
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={bounds.south_lat || ''}
                        onChange={(e) =>
                          handleBoundsChange('south_lat', parseFloat(e.target.value) || null)
                        }
                        className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                        East Lng
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={bounds.east_lng || ''}
                        onChange={(e) =>
                          handleBoundsChange('east_lng', parseFloat(e.target.value) || null)
                        }
                        className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                        West Lng
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        value={bounds.west_lng || ''}
                        onChange={(e) =>
                          handleBoundsChange('west_lng', parseFloat(e.target.value) || null)
                        }
                        className="w-full mt-2 px-3 py-2 rounded-lg bg-white/10 border border-white/20 text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase tracking-widest text-white/50">
                      Zoom Level (7-18)
                    </label>
                    <input
                      type="range"
                      min="7"
                      max="18"
                      value={bounds.zoom_level}
                      onChange={(e) => handleBoundsChange('zoom_level', parseInt(e.target.value))}
                      className="w-full mt-2"
                    />
                    <p className="text-xs text-white/40 mt-1">Level: {bounds.zoom_level}</p>
                  </div>

                  {/* Include options */}
                  <div className="space-y-2 pt-4">
                    {[
                      { key: 'include_topography', label: 'Topographic Data' },
                      { key: 'include_known_sites', label: 'Known Sites' },
                      { key: 'include_user_collection', label: 'My Collection' },
                      { key: 'include_rules_ethics', label: 'Rules & Ethics Guide' },
                      { key: 'include_field_guide', label: 'Field Guide (Top 20 Minerals)' },
                      { key: 'include_emergency_info', label: 'Emergency Info & Safety' },
                    ].map(({ key, label }) => (
                      <label key={key} className="flex items-center gap-3">
                        <input
                          type="checkbox"
                          checked={bounds[key]}
                          onChange={(e) => handleBoundsChange(key, e.target.checked)}
                          className="w-4 h-4 rounded"
                        />
                        <span className="text-sm text-white/70">{label}</span>
                      </label>
                    ))}
                  </div>

                  {error && (
                    <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 flex items-gap-2">
                      <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                      <p className="text-xs text-red-300">{error}</p>
                    </div>
                  )}

                  <button
                    onClick={handleConfirmBounds}
                    className="w-full py-3 rounded-lg font-semibold text-white mt-6"
                    style={{ background: 'rgba(0,214,143,0.2)', border: '1px solid rgba(0,214,143,0.4)' }}
                  >
                    Estimate Download
                  </button>
                </div>
              )}

              {/* Step: Confirm ───────────────────────────────────────────────── */}
              {step === 'confirm' && estimatedData && (
                <div className="space-y-4">
                  <div className="rounded-lg p-4" style={{ background: 'rgba(255,255,255,0.05)' }}>
                    <p className="text-sm text-white/70 mb-3">Download Summary:</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-white/50">Estimated Size:</span>
                        <span className="text-white font-semibold">{estimatedData.estimated_mb.toFixed(1)} MB</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50">Tiles:</span>
                        <span className="text-white font-semibold">{estimatedData.estimated_tiles}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50">Specimens:</span>
                        <span className="text-white font-semibold">{estimatedData.specimen_count}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-white/50">Known Sites:</span>
                        <span className="text-white font-semibold">{estimatedData.site_count}</span>
                      </div>
                      {bounds.include_rules_ethics && (
                        <div className="flex justify-between">
                          <span className="text-white/50">Rules & Ethics:</span>
                          <span className="text-emerald-400 font-semibold">Included</span>
                        </div>
                      )}
                      {bounds.include_field_guide && (
                        <div className="flex justify-between">
                          <span className="text-white/50">Field Guide:</span>
                          <span className="text-emerald-400 font-semibold">20 minerals</span>
                        </div>
                      )}
                      {bounds.include_emergency_info && (
                        <div className="flex justify-between">
                          <span className="text-white/50">Emergency Info:</span>
                          <span className="text-emerald-400 font-semibold">Included</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={handleStartDownload}
                    className="w-full py-3 rounded-lg font-semibold text-white"
                    style={{ background: 'rgba(0,214,143,0.3)', border: '1px solid rgba(0,214,143,0.5)' }}
                  >
                    Start Download
                  </button>

                  <button
                    onClick={() => setStep('bounds')}
                    className="w-full py-3 rounded-lg font-semibold text-white/70 border border-white/20"
                  >
                    Back
                  </button>
                </div>
              )}

              {/* Step: Downloading ───────────────────────────────────────────── */}
              {step === 'downloading' && (
                <div className="space-y-4">
                  <p className="text-sm text-white/70">Downloading {estimatedData.region_name}...</p>
                  <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      className="h-full"
                      style={{ background: 'linear-gradient(90deg, #00D68F, #7AE7FF)' }}
                      initial={{ width: 0 }}
                      animate={{ width: `${downloadProgress}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                  <p className="text-xs text-white/50 text-center">{downloadProgress}%</p>
                </div>
              )}

              {/* Step: Complete ───────────────────────────────────────────────── */}
              {step === 'complete' && (
                <div className="space-y-4 text-center">
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white">Download Complete</h3>
                  <p className="text-sm text-white/50">
                    {estimatedData.region_name} is now available offline
                  </p>
                  <button
                    onClick={() => setIsOpen(false)}
                    className="w-full py-3 rounded-lg font-semibold text-white"
                    style={{ background: 'rgba(0,214,143,0.3)' }}
                  >
                    Close
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}