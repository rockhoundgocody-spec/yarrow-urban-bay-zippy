/**
 * FieldCompass
 * Device-orientation compass for offline field navigation.
 * Uses DeviceOrientationEvent (webkitCompassHeading on iOS, alpha on Android).
 * Falls back to a manual bearing display if orientation not available.
 */
import React, { useState, useEffect } from "react";
import { Navigation, Compass } from "lucide-react";

const CARDINAL = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
function headingToCardinal(h) {
  return CARDINAL[Math.round(h / 45) % 8];
}

export default function FieldCompass({ targetBearing = null, targetLabel = null, size = 200 }) {
  const [heading, setHeading] = useState(null);
  const [error, setError] = useState(null);
  const [permissionAsked, setPermissionAsked] = useState(false);

  const requestPermission = async () => {
    setPermissionAsked(true);
    // iOS 13+ requires explicit permission
    if (typeof DeviceOrientationEvent?.requestPermission === "function") {
      const res = await DeviceOrientationEvent.requestPermission().catch(() => "denied");
      if (res !== "granted") { setError("Compass permission denied."); return; }
    }
    startListening();
  };

  const startListening = () => {
    const handler = (e) => {
      // iOS uses webkitCompassHeading (0=N, clockwise)
      // Android uses alpha (0=N, counter-clockwise) → convert
      let h = null;
      if (e.webkitCompassHeading != null) {
        h = e.webkitCompassHeading;
      } else if (e.alpha != null) {
        h = (360 - e.alpha) % 360;
      }
      if (h !== null) setHeading(Math.round(h));
    };
    window.addEventListener("deviceorientation", handler, true);
    return () => window.removeEventListener("deviceorientation", handler, true);
  };

  useEffect(() => {
    // Non-iOS: start directly without permission prompt
    if (typeof DeviceOrientationEvent?.requestPermission !== "function") {
      const cleanup = startListening();
      setPermissionAsked(true);
      return cleanup;
    }
  }, []);

  const needsPermission = !permissionAsked && typeof DeviceOrientationEvent?.requestPermission === "function";
  const r = size / 2;
  const tickCount = 72; // every 5°

  // Relative bearing to target
  const relBearing = targetBearing != null && heading != null
    ? ((targetBearing - heading + 360) % 360)
    : null;

  return (
    <div className="flex flex-col items-center gap-3">
      {needsPermission ? (
        <button
          onClick={requestPermission}
          className="flex items-center gap-2 px-5 py-3 rounded-2xl text-sm font-bold transition-all active:scale-95"
          style={{ background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.3)", color: "#00D68F" }}>
          <Compass className="w-4 h-4" />
          Enable Compass
        </button>
      ) : (
        <>
          {/* SVG Compass Rose */}
          <div className="relative" style={{ width: size, height: size }}>
            {/* Outer glow ring */}
            <div className="absolute inset-0 rounded-full"
              style={{ background: "radial-gradient(circle, rgba(0,214,143,0.06) 0%, transparent 70%)", filter: "blur(8px)" }} />

            <svg width={size} height={size} className="relative z-10">
              {/* Background disc */}
              <circle cx={r} cy={r} r={r - 2} fill="rgba(6,9,14,0.95)" stroke="rgba(0,214,143,0.22)" strokeWidth="1.5" />

              {/* Tick marks — rotate with heading so dial spins */}
              <g transform={`rotate(${heading != null ? -heading : 0}, ${r}, ${r})`}>
                {Array.from({ length: tickCount }, (_, i) => {
                  const deg = i * (360 / tickCount);
                  const rad = (deg * Math.PI) / 180;
                  const isCardinal = i % 18 === 0;    // every 90°
                  const isMinor = i % 6 === 0;         // every 30°
                  const len = isCardinal ? 14 : isMinor ? 9 : 5;
                  const x1 = r + (r - 14) * Math.sin(rad);
                  const y1 = r - (r - 14) * Math.cos(rad);
                  const x2 = r + (r - 14 - len) * Math.sin(rad);
                  const y2 = r - (r - 14 - len) * Math.cos(rad);
                  return (
                    <line key={i} x1={x1} y1={y1} x2={x2} y2={y2}
                      stroke={isCardinal ? "#00D68F" : isMinor ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.1)"}
                      strokeWidth={isCardinal ? 2 : 1} />
                  );
                })}

                {/* Cardinal labels */}
                {[["N", 0, "#00D68F"], ["E", 90, "rgba(255,255,255,0.6)"], ["S", 180, "rgba(255,255,255,0.6)"], ["W", 270, "rgba(255,255,255,0.6)"]].map(([label, deg, color]) => {
                  const rad = (deg * Math.PI) / 180;
                  const tx = r + (r - 30) * Math.sin(rad);
                  const ty = r - (r - 30) * Math.cos(rad) + 5;
                  return (
                    <text key={label} x={tx} y={ty} textAnchor="middle" fontSize="12"
                      fontWeight="800" fontFamily="system-ui" fill={color}>{label}</text>
                  );
                })}
              </g>

              {/* Fixed north pointer (always points up) */}
              <polygon points={`${r},${r - r * 0.38} ${r - 7},${r + 8} ${r + 7},${r + 8}`}
                fill="#00D68F" opacity="0.9" />
              <polygon points={`${r},${r + r * 0.38} ${r - 7},${r - 8} ${r + 7},${r - 8}`}
                fill="rgba(255,255,255,0.2)" />

              {/* Target bearing needle */}
              {relBearing != null && (() => {
                const rad = (relBearing * Math.PI) / 180;
                const nx = r + (r * 0.38) * Math.sin(rad);
                const ny = r - (r * 0.38) * Math.cos(rad);
                return (
                  <g>
                    <line x1={r} y1={r} x2={nx} y2={ny} stroke="#F5B642" strokeWidth="2.5" strokeLinecap="round" />
                    <circle cx={nx} cy={ny} r="4" fill="#F5B642" />
                  </g>
                );
              })()}

              {/* Center jewel */}
              <circle cx={r} cy={r} r="6" fill="rgba(6,9,14,0.98)" stroke="rgba(0,214,143,0.5)" strokeWidth="1.5" />
              <circle cx={r} cy={r} r="3" fill="#00D68F" opacity="0.8" />
            </svg>

            {/* Degree readout */}
            <div className="absolute bottom-3 left-0 right-0 text-center">
              {heading != null ? (
                <span className="text-sm font-black tabular-nums" style={{ color: "#00D68F" }}>
                  {heading}° {headingToCardinal(heading)}
                </span>
              ) : error ? (
                <span className="text-xs text-red-400">{error}</span>
              ) : (
                <span className="text-xs text-white/30">Calibrating…</span>
              )}
            </div>
          </div>

          {/* Target bearing info */}
          {targetBearing != null && (
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold"
              style={{ background: "rgba(245,182,66,0.1)", border: "1px solid rgba(245,182,66,0.25)", color: "#F5B642" }}>
              <Navigation className="w-3.5 h-3.5" />
              {targetLabel || "Target"} · {Math.round(targetBearing)}° {headingToCardinal(targetBearing)}
              {relBearing != null && <span className="text-white/40 font-normal ml-1">({Math.round(relBearing)}° relative)</span>}
            </div>
          )}
        </>
      )}
    </div>
  );
}