// SyncStatusBar v2
import React, { useState, useEffect } from "react";
import { WifiOff, RefreshCw, Check, AlertTriangle } from "lucide-react";
import { getPendingCount, processQueue, onSyncStatusChange, startNetworkMonitor } from "./SyncEngine";

export default function SyncStatusBar() {
  const [online, setOnline] = useState(navigator.onLine);
  const [pending, setPending] = useState(0);
  const [syncing, setSyncing] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [showResult, setShowResult] = useState(false);

  useEffect(() => {
    startNetworkMonitor();

    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    const unsub = onSyncStatusChange((status) => {
      if (status.syncing !== undefined) setSyncing(status.syncing);
      if (status.synced !== undefined || status.failed !== undefined) {
        const synced = status.synced || 0;
        const failed = status.failed || 0;
        if (synced > 0 || failed > 0) {
          setLastResult({ synced, failed });
          setShowResult(true);
          setTimeout(() => setShowResult(false), 3000);
        }
      }
    });

    // Poll pending count
    const interval = setInterval(async () => {
      const count = await getPendingCount();
      setPending(count);
    }, 5000);

    getPendingCount().then(setPending);

    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
      unsub();
      clearInterval(interval);
    };
  }, []);

  // Only show when offline, actively syncing, or a sync just completed with results
  const shouldShow =
    !online ||
    (syncing && pending > 0) ||
    (showResult && lastResult && (lastResult.synced > 0 || lastResult.failed > 0));

  if (!shouldShow) return null;

  return (
    <div className="absolute top-16 left-0 right-0 z-40 flex justify-center pointer-events-none" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <div className="pointer-events-auto px-4 py-2 rounded-b-xl flex items-center gap-2 text-xs font-medium"
        style={{
          background: !online
            ? "rgba(239,68,68,0.9)"
            : syncing
              ? "rgba(59,130,246,0.9)"
              : showResult && lastResult?.failed > 0
                ? "rgba(245,158,11,0.9)"
                : "rgba(34,197,94,0.9)",
          backdropFilter: "blur(12px)",
          color: "#fff",
        }}>
        {!online ? (
          <>
            <WifiOff className="w-3.5 h-3.5" />
            Offline — {pending} change{pending !== 1 ? "s" : ""} queued
          </>
        ) : syncing ? (
          <>
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            Syncing {pending} item{pending !== 1 ? "s" : ""}...
          </>
        ) : showResult ? (
          lastResult?.failed > 0 ? (
            <>
              <AlertTriangle className="w-3.5 h-3.5" />
              {lastResult.synced} synced, {lastResult.failed} failed
            </>
          ) : (
            <>
              <Check className="w-3.5 h-3.5" />
              {lastResult.synced} item{lastResult.synced !== 1 ? "s" : ""} synced
            </>
          )
        ) : (
          <>
            <RefreshCw className="w-3.5 h-3.5" />
            {pending} pending change{pending !== 1 ? "s" : ""}
            <button onClick={() => processQueue()} className="ml-2 underline text-white/80 hover:text-white">
              Sync now
            </button>
          </>
        )}
      </div>
    </div>
  );
}