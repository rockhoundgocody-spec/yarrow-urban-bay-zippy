import { useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';

/**
 * Starts the OfflineSyncQueue drain loop only once a user is genuinely
 * authenticated. Booting it on mere token presence made anonymous visitors
 * (and visitors holding an expired token) poll an entity they cannot read,
 * which the server answers with 403.
 */
export default function SyncBootstrap() {
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated || !user) return;
    let stopped = false;
    let stop;
    const t = setTimeout(() => {
      import('@/lib/syncService').then((m) => {
        if (stopped) return;
        stop = m.stopSync;
        m.startSync();
      });
    }, 2000);
    return () => {
      stopped = true;
      clearTimeout(t);
      if (stop) stop();
    };
  }, [isAuthenticated, user]);

  return null;
}