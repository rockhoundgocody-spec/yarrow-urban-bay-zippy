import { base44 } from "../../api/base44Client";

export async function getMemory(keys = null) {
  const res = await base44.functions.invoke("memoryGet", {
    scope: "global",
    keys: keys || [],
  });
  return res.data?.memory || {};
}

export async function setMemory(key, value) {
  await base44.functions.invoke("memorySet", {
    scope: "global",
    key,
    value,
  });
}