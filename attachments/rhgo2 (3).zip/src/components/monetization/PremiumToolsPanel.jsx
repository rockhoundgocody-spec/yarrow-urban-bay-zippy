/**
 * PremiumToolsPanel — tasteful monetization surface.
 * Used in: hub, market, geodex, collection.
 * Shows: premium tier features, clear value prop, upgrade CTA.
 * Not spammy — appears once per surface, contextually.
 *
 * Props:
 *  context    "hub" | "market" | "collection" | "geodex" | "scan"
 *  onUpgrade  fn — opens billing/plan page
 *  compact    boolean — short one-liner chip version
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Crown, Zap, BarChart2, ShieldCheck, Map, ChevronRight, X } from "lucide-react";

const CTX_FEATURES = {
  hub: [
    { icon: Map,         label: "Offline Field Map",       sub: "Cache entire regions before trips" },
    { icon: BarChart2,   label: "Collection Analytics",    sub: "Valuation trends and rarity insights" },
    { icon: ShieldCheck, label: "Provenance Certificates", sub: "Export certified specimen records" },
  ],
  market: [
    { icon: BarChart2,   label: "Market Comp Intelligence", sub: "Deep price history and trends" },
    { icon: ShieldCheck, label: "Priority Trust Badge",     sub: "Verified seller profile signal" },
    { icon: Zap,         label: "Featured Listings",        sub: "Boost visibility for your items" },
  ],
  collection: [
    { icon: ShieldCheck, label: "Provenance Certificates", sub: "PDF export for serious collectors" },
    { icon: BarChart2,   label: "Vault Analytics",         sub: "Rarity map and value tracking" },
    { icon: Crown,       label: "Unlimited Specimens",     sub: "No storage cap on your vault" },
  ],
  geodex: [
    { icon: BarChart2,   label: "Deep Mineral Comps",      sub: "Full auction and market history" },
    { icon: Map,         label: "Occurrence Heat Maps",     sub: "Where minerals actually appear" },
    { icon: Crown,       label: "Expert ID Queue",          sub: "Submit scans for expert review" },
  ],
  scan: [
    { icon: Zap,         label: "Unlimited Scans",         sub: "No monthly scan cap" },
    { icon: BarChart2,   label: "Deep Analysis Mode",      sub: "Full spectral breakdown + comps" },
    { icon: Crown,       label: "Expert Review Queue",     sub: "Human-verified difficult IDs" },
  ],
};

export default function PremiumToolsPanel({ context = "hub", onUpgrade, compact = false }) {
  const [dismissed, setDismissed] = useState(false);
  const features = CTX_FEATURES[context] || CTX_FEATURES.hub;

  if (dismissed) return null;

  if (compact) {
    return (
      <motion.button
        type="button"
        onClick={onUpgrade}
        whileTap={{ scale: 0.97 }}
        className="flex w-full items-center gap-3 rounded-2xl px-4 py-3"
        style={{
          background: "linear-gradient(135deg, rgba(255,215,0,0.07) 0%, rgba(185,122,255,0.06) 100%)",
          border: "1px solid rgba(255,215,0,0.18)",
        }}
      >
        <Crown className="h-4 w-4 shrink-0 text-amber-300" />
        <div className="flex-1 text-left">
          <div className="text-xs font-bold text-white/80">Unlock Collector Pro</div>
          <div className="text-[10px] text-white/35">Premium tools for serious rockhounds</div>
        </div>
        <ChevronRight className="h-4 w-4 text-amber-300/40 shrink-0" />
      </motion.button>
    );
  }

  return (
    <AnimatePresence>
      {!dismissed && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.97 }}
          className="relative overflow-hidden rounded-[26px]"
          style={{
            background: "linear-gradient(145deg, rgba(8,5,20,0.97) 0%, rgba(4,8,14,0.97) 100%)",
            border: "1px solid rgba(255,215,0,0.18)",
            boxShadow: "0 0 40px rgba(255,215,0,0.06)",
          }}
        >
          {/* Dismiss */}
          <button
            type="button"
            onClick={() => setDismissed(true)}
            className="absolute right-3 top-3 text-white/20 hover:text-white/50"
           aria-label="Close">
            <X className="h-4 w-4" />
          </button>

          {/* Header */}
          <div className="px-5 pt-5 pb-3">
            <div className="flex items-center gap-2 mb-2">
              <Crown className="h-4 w-4 text-amber-300" />
              <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-amber-300">Collector Pro</span>
            </div>
            <h3 className="text-base font-black text-white leading-tight">Premium tools for serious collectors.</h3>
          </div>

          {/* Features */}
          <div className="px-4 pb-4 space-y-2">
            {features.map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-3 rounded-xl px-3 py-2.5"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg"
                  style={{ background: "rgba(255,215,0,0.10)", border: "1px solid rgba(255,215,0,0.20)" }}>
                  <Icon className="h-3.5 w-3.5 text-amber-300" />
                </div>
                <div>
                  <div className="text-xs font-bold text-white/80">{label}</div>
                  <div className="text-[10px] text-white/30">{sub}</div>
                </div>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="px-4 pb-5">
            <button
              type="button"
              onClick={() => { onUpgrade?.(); }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl py-3.5 text-sm font-black uppercase tracking-wide"
              style={{
                background: "linear-gradient(120deg, rgba(255,215,0,0.18) 0%, rgba(185,122,255,0.14) 100%)",
                border: "1px solid rgba(255,215,0,0.35)",
                color: "#FFD700",
                boxShadow: "0 0 20px rgba(255,215,0,0.12)",
              }}
            >
              <Crown className="h-4 w-4" />
              Unlock Collector Pro
            </button>
            <p className="mt-2 text-center text-[10px] text-white/20">
              Cancel anytime · No commitment required
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}