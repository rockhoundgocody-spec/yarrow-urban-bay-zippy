/**
 * MarketPriceBlur — wraps a price display in marketplace items.
 * For free users: blurs the sold/comp price, shows a tap-to-unlock hint.
 * For paid users: renders children as-is.
 *
 * Usage:
 *   <MarketPriceBlur user={user} price={item.price}>
 *     <span>${item.price}</span>
 *   </MarketPriceBlur>
 */
import React from "react";
import { Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { getActiveTier } from "@/components/subscription/entitlements";

export default function MarketPriceBlur({ user, children, price }) {
  const navigate = useNavigate();
  const tier = getActiveTier(user);
  const isLocked = tier === "free";

  if (!isLocked) return <>{children}</>;

  return (
    <button
      onClick={(e) => { e.stopPropagation(); navigate("/Pricing"); }}
      className="relative inline-flex items-center gap-1 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400/50 rounded"
      title="Unlock with Crystal Pro"
      aria-label="Price locked. Unlock with Crystal Pro"
      style={{ minHeight: 24 }}
    >
      <span
        aria-hidden="true"
        style={{
          filter: "blur(5px)",
          userSelect: "none",
          pointerEvents: "none",
          color: "rgba(255,255,255,0.6)",
          fontWeight: 700,
          fontSize: "inherit",
        }}
      >
        {price ? `$${price}` : "$—"}
      </span>
      <Lock size={9} style={{ color: "rgba(141,124,255,0.6)", flexShrink: 0 }} aria-hidden="true" />
    </button>
  );
}