/**
 * LandAccessUpgradeCard — monetization surface for private land access / host features.
 * Shown on Land/Property pages for hosts and visitors.
 */
import React from "react";
import { Link } from "react-router-dom";
import { MapPin, DollarSign, Shield, Star, CalendarCheck, BarChart2 } from "lucide-react";

const HOST_BENEFITS = [
  { icon: DollarSign,    text: "Earn from your private land — set your own access fees" },
  { icon: MapPin,        text: "Featured placement on the discovery map" },
  { icon: Shield,        text: "Verified land host badge — builds visitor trust" },
  { icon: CalendarCheck, text: "Integrated booking & availability management" },
  { icon: BarChart2,     text: "Visitor analytics: revenue, peak seasons, top minerals" },
];

const VISITOR_BENEFITS = [
  { icon: MapPin,   text: "Access exclusive private land not on public maps" },
  { icon: Shield,   text: "Verified host safety ratings & legality transparency" },
  { icon: Star,     text: "Permit pre-clearance included with booking" },
  { icon: CalendarCheck, text: "Instant booking confirmation" },
];

export default function LandAccessUpgradeCard({ mode = "visitor", compact = false, className = "" }) {
  const benefits = mode === "host" ? HOST_BENEFITS : VISITOR_BENEFITS;
  const title = mode === "host" ? "List Your Land" : "Book Private Land Access";
  const desc = mode === "host"
    ? "Turn your property into a premium rockhounding destination."
    : "Find and book verified private land with rare mineral potential.";
  const accent = mode === "host" ? "#00D68F" : "#7AE7FF";
  const border = mode === "host" ? "rgba(0,214,143,0.22)" : "rgba(122,231,255,0.22)";
  const bg = mode === "host" ? "rgba(0,214,143,0.05)" : "rgba(122,231,255,0.05)";

  if (compact) {
    return (
      <div className={`rounded-2xl p-4 flex items-center gap-3 ${className}`}
        style={{ background: bg, border: `1px solid ${border}` }}>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: `${accent}18`, border: `1px solid ${accent}30` }}>
          <MapPin className="w-4 h-4" style={{ color: accent }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-white">{title}</p>
          <p className="text-[11px] text-white/40">{desc}</p>
        </div>
        <Link to="/LandAccess"
          className="shrink-0 px-3.5 py-2 rounded-xl text-[11px] font-black transition-all active:scale-95"
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}cc)`, color: "#000", boxShadow: `0 0 14px ${accent}35` }}>
          {mode === "host" ? "List" : "Browse"}
        </Link>
      </div>
    );
  }

  return (
    <div className={`rounded-3xl overflow-hidden ${className}`}
      style={{ background: "linear-gradient(145deg, rgba(4,10,8,0.98) 0%, rgba(6,14,12,0.97) 100%)", border: `1px solid ${border}`, boxShadow: `0 0 60px ${accent}08` }}>
      <div className="px-5 pt-5 pb-4" style={{ borderBottom: `1px solid ${accent}12` }}>
        <div className="flex items-center gap-2 mb-3">
          <MapPin className="w-4 h-4" style={{ color: accent }} />
          <span className="text-[10px] font-black uppercase tracking-[0.22em]" style={{ color: accent }}>
            {mode === "host" ? "Land Host" : "Private Access"}
          </span>
        </div>
        <h3 className="text-lg font-black text-white leading-tight">{title}</h3>
        <p className="text-xs text-white/35 mt-1.5 leading-relaxed">{desc}</p>
      </div>

      <div className="px-5 py-4 space-y-2.5">
        {benefits.map(({ icon: Icon, text }) => (
          <div key={text} className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
              style={{ background: `${accent}15` }}>
              <Icon className="w-3 h-3" style={{ color: accent }} />
            </div>
            <span className="text-xs text-white/65">{text}</span>
          </div>
        ))}
      </div>

      <div className="px-5 pb-5">
        <Link to="/LandAccess"
          className="flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl text-sm font-black text-black transition-all active:scale-[0.98]"
          style={{ background: `linear-gradient(135deg, ${accent}, ${accent}cc)`, boxShadow: `0 0 24px ${accent}25` }}>
          <MapPin className="w-4 h-4" /> {mode === "host" ? "Start Hosting" : "Browse Properties"}
        </Link>
        <p className="text-center text-white/20 text-[10px] mt-2">
          {mode === "host" ? "Free to list · Platform fee on bookings" : "Booking fee includes permit coordination"}
        </p>
      </div>
    </div>
  );
}