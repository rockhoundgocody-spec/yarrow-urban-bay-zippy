/**
 * ProSellerUpgradeCard — shown in Marketplace / SellerDashboard for free sellers.
 * Communicates value clearly without aggressive pressure.
 */
import React from "react";
import { Link } from "react-router-dom";
import { ShieldCheck, TrendingUp, BarChart2, Zap, Star, Crown } from "lucide-react";

const BENEFITS = [
  { icon: TrendingUp, text: "Advanced pricing comps & real sale history" },
  { icon: BarChart2,  text: "Seller analytics: views, conversion, revenue" },
  { icon: ShieldCheck,text: "Pro Seller trust badge on every listing" },
  { icon: Star,       text: "Promoted listings — higher discovery" },
  { icon: Zap,        text: "Bulk listing tools & AI title optimiser" },
];

export default function ProSellerUpgradeCard({ compact = false, className = "" }) {
  if (compact) {
    return (
      <div
        className={`rounded-2xl p-4 flex items-center gap-3 ${className}`}
        style={{ background: "rgba(245,182,66,0.07)", border: "1px solid rgba(245,182,66,0.25)" }}
      >
        <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: "rgba(245,182,66,0.12)", border: "1px solid rgba(245,182,66,0.3)" }}>
          <Crown className="w-4 h-4" style={{ color: "#F5B642" }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-bold text-white">Go Pro Seller</p>
          <p className="text-[11px] text-white/40">Comps, analytics, promoted listings</p>
        </div>
        <Link to="/Pricing"
          className="shrink-0 px-3.5 py-2 rounded-xl text-[11px] font-black text-black transition-all active:scale-95"
          style={{ background: "linear-gradient(135deg, #F5B642, #e5a030)", boxShadow: "0 0 14px rgba(245,182,66,0.3)" }}>
          Upgrade
        </Link>
      </div>
    );
  }

  return (
    <div
      className={`rounded-3xl overflow-hidden ${className}`}
      style={{ background: "linear-gradient(145deg, rgba(8,6,2,0.98) 0%, rgba(14,10,4,0.97) 100%)", border: "1px solid rgba(245,182,66,0.22)", boxShadow: "0 0 60px rgba(245,182,66,0.06)" }}
    >
      {/* Header */}
      <div className="px-5 pt-5 pb-4" style={{ borderBottom: "1px solid rgba(245,182,66,0.10)" }}>
        <div className="flex items-center gap-2 mb-3">
          <Crown className="w-4 h-4" style={{ color: "#F5B642" }} />
          <span className="text-[10px] font-black uppercase tracking-[0.22em]" style={{ color: "#F5B642" }}>Pro Seller</span>
        </div>
        <h3 className="text-lg font-black text-white leading-tight">Sell faster. Price smarter.<br />Build trust that converts.</h3>
        <p className="text-xs text-white/35 mt-1.5 leading-relaxed">
          Pro Sellers close 2× faster with verified trust badges, real comp data, and promoted discovery placement.
        </p>
      </div>

      {/* Benefits */}
      <div className="px-5 py-4 space-y-2.5">
        {BENEFITS.map(({ icon: Icon, text }) => (
          <div key={text} className="flex items-center gap-2.5">
            <div className="w-6 h-6 rounded-lg flex items-center justify-center shrink-0"
              style={{ background: "rgba(245,182,66,0.12)" }}>
              <Icon className="w-3 h-3" style={{ color: "#F5B642" }} />
            </div>
            <span className="text-xs text-white/65">{text}</span>
          </div>
        ))}
      </div>

      {/* CTA */}
      <div className="px-5 pb-5">
        <Link
          to="/Store"
          className="flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl text-sm font-black text-black transition-all active:scale-[0.98]"
          style={{ background: "linear-gradient(135deg, #F5B642, #d4903a)", boxShadow: "0 0 24px rgba(245,182,66,0.25)" }}
        >
          <Crown className="w-4 h-4" /> Unlock Pro Seller
        </Link>
        <p className="text-center text-white/20 text-[10px] mt-2">Included with Expedition Elite</p>
      </div>
    </div>
  );
}