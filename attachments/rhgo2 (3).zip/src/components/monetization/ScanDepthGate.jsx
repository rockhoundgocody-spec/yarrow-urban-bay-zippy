/**
 * ScanDepthGate — shown at bottom of IdentifyResult for free/trail_scout users.
 * Reveals the shape of what's locked (formation history, provenance, market comp)
 * without fake data. Investment already made (they just scanned) → high conversion moment.
 */
import React from "react";
import { motion } from "framer-motion";
import { Lock, Zap, TrendingUp, Map } from "lucide-react";
import { Link } from "react-router-dom";
import { getActiveTier } from "@/components/subscription/entitlements";

const LOCKED_ROWS = [
  { icon: Map,        label: "Formation History",      preview: "Geological formation context and tectonic environment…" },
  { icon: TrendingUp, label: "Market Comparable Sales", preview: "Live auction comps from verified collector transactions…" },
  { icon: Zap,        label: "Locality Predictions",   preview: "Predicted source regions and US state occurrence data…" },
];

export default function ScanDepthGate({ user }) {
  const tier = getActiveTier(user);
  // Show gate for free users; crystal_pro+ gets full report
  if (tier === "crystal_pro" || tier === "expedition_elite") return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.6 }}
      className="relative overflow-hidden rounded-2xl"
      style={{
        background: "linear-gradient(160deg, rgba(10,8,22,0.97) 0%, rgba(6,4,14,0.98) 100%)",
        border: "1px solid rgba(141,124,255,0.22)",
        boxShadow: "0 0 32px rgba(141,124,255,0.06)",
      }}
    >
      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between">
        <div>
          <p className="text-[9px] font-black uppercase tracking-[0.2em]" style={{ color: "rgba(141,124,255,0.6)" }}>
            Deep Analysis
          </p>
          <p className="text-sm font-bold text-white/80 mt-0.5">Full Geological Report</p>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full"
          style={{ background: "rgba(141,124,255,0.10)", border: "1px solid rgba(141,124,255,0.25)" }}>
          <Lock size={10} style={{ color: "#8D7CFF" }} />
          <span className="text-[10px] font-bold" style={{ color: "#8D7CFF" }}>Crystal Pro</span>
        </div>
      </div>

      {/* Blurred rows */}
      <div className="px-4 pb-2 space-y-2">
        {LOCKED_ROWS.map(({ icon: RowIcon, label, preview }) => (
          <div key={label} className="rounded-xl px-3 py-3"
            style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <div className="flex items-center gap-2 mb-1.5">
              <RowIcon size={11} style={{ color: "rgba(141,124,255,0.5)" }} />
              <span className="text-[10px] font-bold uppercase tracking-wide" style={{ color: "rgba(141,124,255,0.5)" }}>
                {label}
              </span>
            </div>
            {/* Blurred preview text */}
            <p className="text-xs leading-relaxed select-none" style={{
              color: "rgba(255,255,255,0.25)",
              filter: "blur(4px)",
              userSelect: "none",
              pointerEvents: "none",
            }}>
              {preview}
            </p>
          </div>
        ))}
      </div>

      {/* Gradient fade over the blurred content */}
      <div className="pointer-events-none absolute bottom-16 inset-x-0 h-12"
        style={{ background: "linear-gradient(to bottom, transparent, rgba(8,6,18,0.96))" }} />

      {/* CTA */}
      <div className="px-4 pb-4 pt-1">
        <Link to="/Pricing"
          className="flex items-center justify-center gap-2 w-full py-3.5 rounded-2xl font-bold text-sm"
          style={{
            background: "linear-gradient(135deg, rgba(141,124,255,0.20), rgba(80,40,200,0.12))",
            border: "1.5px solid rgba(141,124,255,0.42)",
            color: "#C4B5FD",
            boxShadow: "0 0 24px rgba(141,124,255,0.15)",
          }}>
          <Zap size={14} />
          Unlock Full Analysis — Crystal Pro
        </Link>
        <p className="text-center text-[10px] mt-2" style={{ color: "rgba(255,255,255,0.18)" }}>
          Formation history · market comps · locality predictions
        </p>
      </div>
    </motion.div>
  );
}