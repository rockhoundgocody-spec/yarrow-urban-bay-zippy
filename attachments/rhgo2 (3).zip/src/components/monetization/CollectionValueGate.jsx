/**
 * CollectionValueGate — replaces the Est. Value stat in VaultHero for free users.
 * The hidden number is more compelling than showing $0.
 * Clicking it navigates to Pricing.
 */
import React from "react";
import { Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { getActiveTier } from "@/components/subscription/entitlements";

export default function CollectionValueGate({ user, totalValue }) {
  const navigate = useNavigate();
  const tier = getActiveTier(user);
  const isLocked = tier === "free";

  if (!isLocked) {
    // Return null — VaultHero renders the real value itself
    return null;
  }

  return (
    <button
      onClick={() => navigate("/Pricing")}
      className="flex flex-col items-center gap-1 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 rounded-xl"
      title="Unlock Estimated Value"
      aria-label="Unlock Estimated Value"
      style={{ minHeight: 44, minWidth: 44 }}
    >
      <div className="flex h-9 w-9 items-center justify-center rounded-xl"
        style={{ background: "rgba(212,175,55,0.10)", border: "1px solid rgba(212,175,55,0.22)" }}
        aria-hidden="true"
      >
        <Lock size={14} style={{ color: "#D4AF37", opacity: 0.7 }} />
      </div>
      <div className="text-xl font-black leading-none" style={{ color: "rgba(212,175,55,0.35)", letterSpacing: "-0.02em" }} aria-hidden="true">
        $—
      </div>
      <div className="text-[9px] uppercase tracking-[0.18em]" style={{ color: "rgba(212,175,55,0.35)" }} aria-hidden="true">
        Est. Value
      </div>
    </button>
  );
}