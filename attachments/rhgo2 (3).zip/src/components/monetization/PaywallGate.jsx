import React, { useState } from "react";
import { motion } from "framer-motion";
import { Gem, Zap, Crown, Check, X, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { PLANS as SUBSCRIPTION_PLANS } from "@/components/subscription/plans";
import { getActiveTier } from "@/components/subscription/entitlements";

const ICONS = { trail_scout: Gem, crystal_pro: Zap, expedition_elite: Crown };
const FREE_PLAN = {
  key: "free",
  planId: null,
  label: "Free",
  price: "$0",
  period: "/mo",
  accent: "rgba(122,231,255,0.7)",
  icon: Gem,
  perks: ["5 AI scans/month", "Basic collection", "Community browsing"],
  cta: "Continue Free",
  ctaStyle: {
    background: "rgba(255,255,255,0.05)",
    border: "1px solid rgba(255,255,255,0.15)",
    color: "rgba(255,255,255,0.55)",
  },
};

const PLANS = [
  FREE_PLAN,
  ...SUBSCRIPTION_PLANS.map((plan) => ({
    key: plan.id,
    planId: plan.id,
    label: plan.name,
    price: plan.pricing.monthly.label,
    period: plan.pricing.monthly.period,
    accent: plan.badge.color,
    icon: ICONS[plan.id] || Gem,
    highlight: Boolean(plan.popular),
    perks: plan.features.slice(0, 4),
    cta: plan.cta,
    ctaStyle: {
      background: `linear-gradient(135deg, ${plan.badge.color}35, ${plan.badge.color}18)`,
      border: `1.5px solid ${plan.badge.color}99`,
      color: plan.badge.color,
      boxShadow: `0 0 24px ${plan.badge.color}28`,
    },
  })),
];

export default function PaywallGate({ onContinue }) {
  const [exiting, setExiting] = useState(false);
  const [loadingPlan, setLoadingPlan] = useState(null);

  const handleFree = () => {
    setExiting(true);
    localStorage.setItem("rh_paywall_seen", "free");
    setTimeout(() => onContinue("free"), 500);
  };

  const handlePaid = async (plan) => {
    setLoadingPlan(plan.key);
    try {
      const user = await base44.auth.me().catch(() => null);
      if (!user) {
        base44.auth.redirectToLogin(window.location.pathname);
        return;
      }
      if (getActiveTier(user) !== "free" && user.stripe_subscription_id) {
        const portal = await base44.functions.invoke("billingPortal", {
          return_url: `${window.location.origin}${window.location.pathname}`,
        });
        if (portal?.data?.portal_url) {
          window.location.href = portal.data.portal_url;
          return;
        }
      }

      const res = await base44.functions.invoke("createSubscriptionCheckout", {
        plan_id: plan.planId,
        billing_interval: "monthly",
        success_url: `${window.location.origin}/BillingAccount?success=true&plan=${encodeURIComponent(plan.label)}`,
        cancel_url: `${window.location.origin}/Pricing?canceled=true`,
      });
      const url = res?.data?.checkout_url;
      if (url) {
        window.location.href = url;
      } else {
        // Fallback — go to pricing page
        setExiting(true);
        localStorage.setItem("rh_paywall_seen", "pricing");
        setTimeout(() => onContinue("pricing"), 400);
      }
    } catch {
      setExiting(true);
      localStorage.setItem("rh_paywall_seen", "pricing");
      setTimeout(() => onContinue("pricing"), 400);
    } finally {
      setLoadingPlan(null);
    }
  };

  const handleSelect = (plan) => {
    if (!plan.planId) return handleFree();
    handlePaid(plan);
  };

  return (
    <motion.div
      className="absolute inset-0 z-[9998] flex flex-col items-center overflow-y-auto"
      style={{ background: "radial-gradient(ellipse at 50% 30%, rgba(141,124,255,0.10) 0%, #04020E 60%)" }}
      animate={{ opacity: exiting ? 0 : 1, scale: exiting ? 0.97 : 1 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    >
      {/* Ambient orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: "absolute", width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, rgba(141,124,255,0.12) 0%, transparent 70%)", top: "10%", left: "50%", transform: "translateX(-50%)", filter: "blur(60px)" }} />
        <div style={{ position: "absolute", width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,214,143,0.07) 0%, transparent 70%)", bottom: "5%", left: "50%", transform: "translateX(-50%)", filter: "blur(50px)" }} />
      </div>

      {/* Immediate dismiss — subscription choice must never trap the user. */}
      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        onClick={handleFree}
        className="absolute top-5 right-5 z-10 w-9 h-9 rounded-full flex items-center justify-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
        style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", minHeight: "unset", minWidth: "unset" }}
        aria-label="Close paywall"
        title="Close paywall"
      >
        <span className="sr-only">Close paywall</span>
        <X size={15} style={{ color: "rgba(255,255,255,0.4)" }} aria-hidden="true" />
      </motion.button>

      {/* Header */}
      <motion.div
        className="relative z-10 text-center mb-7 px-6 pt-16 flex-shrink-0"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15, duration: 0.6 }}
      >
        <p className="text-[10px] font-bold uppercase tracking-[0.3em] mb-2" style={{ color: "rgba(122,231,255,0.5)" }}>
          Choose Your Path
        </p>
        <h2 className="text-2xl font-black tracking-tight" style={{
          background: "linear-gradient(120deg, #8D7CFF 0%, #7AE7FF 50%, #D4AF37 100%)",
          WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text",
        }}>
          Unlock the Full Field
        </h2>
        <p className="text-xs mt-1.5" style={{ color: "rgba(255,255,255,0.25)" }}>
          Upgrade anytime · Cancel anytime
        </p>
      </motion.div>

      {/* Plan cards */}
      <div className="relative z-10 flex flex-col gap-3 w-full px-5 max-w-sm pb-24">
        {PLANS.map((plan, i) => {
          const Icon = plan.icon;
          const isLoading = loadingPlan === plan.key;
          return (
            <motion.div
              key={plan.key}
              initial={{ opacity: 0, x: -24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.25 + i * 0.1, duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
            >
              <div style={{
                background: plan.highlight
                  ? "linear-gradient(135deg, rgba(141,124,255,0.12) 0%, rgba(10,8,28,0.95) 100%)"
                  : "rgba(10,8,22,0.85)",
                border: plan.highlight ? "1.5px solid rgba(141,124,255,0.35)" : "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18, padding: "14px 16px", position: "relative", overflow: "hidden",
              }}>
                {plan.highlight && (
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 1, background: "linear-gradient(90deg, transparent, rgba(141,124,255,0.7), transparent)" }} />
                )}
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2.5">
                    <div style={{ width: 32, height: 32, borderRadius: 10, background: `rgba(${plan.key === "free" ? "122,231,255" : plan.key === "pro" ? "141,124,255" : "212,175,55"},0.15)`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                      <Icon size={14} style={{ color: plan.accent }} />
                    </div>
                    <div>
                      <div className="text-xs font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>{plan.label}</div>
                      <div className="flex items-baseline gap-0.5">
                        <span className="text-base font-black" style={{ color: plan.accent }}>{plan.price}</span>
                        {plan.period && <span className="text-[10px]" style={{ color: "rgba(255,255,255,0.3)" }}>{plan.period}</span>}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => !isLoading && handleSelect(plan)}
                    disabled={!!loadingPlan}
                    className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50"
                    style={{ ...plan.ctaStyle, borderRadius: 10, padding: "7px 14px", fontSize: 11, fontWeight: 700, letterSpacing: "0.05em", cursor: loadingPlan ? "default" : "pointer", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 5, opacity: loadingPlan && !isLoading ? 0.5 : 1 }}
                  >
                    {isLoading ? <Loader2 size={11} className="animate-spin" /> : null}
                    {isLoading ? "..." : plan.cta}
                  </button>
                </div>
                <div className="flex flex-wrap gap-x-3 gap-y-1">
                  {plan.perks.map(p => (
                    <span key={p} className="flex items-center gap-1 text-[10px]" style={{ color: "rgba(255,255,255,0.38)" }}>
                      <Check size={8} style={{ color: plan.accent, flexShrink: 0 }} />{p}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Compare link */}
      <motion.div className="relative z-10 mt-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }}>
        <Link to="/Pricing" onClick={handleFree} className="text-[10px] uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.15)" }}>
          Compare all features →
        </Link>
      </motion.div>
    </motion.div>
  );
}