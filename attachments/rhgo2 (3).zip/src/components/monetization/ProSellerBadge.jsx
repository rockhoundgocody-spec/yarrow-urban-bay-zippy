/**
 * ProSellerBadge — compact trust signal for verified pro sellers.
 * Renders inline next to seller name in listing cards, detail sheets, and profiles.
 */
import React from "react";
import { ShieldCheck } from "lucide-react";

export default function ProSellerBadge({ compact = false, className = "" }) {
  if (compact) {
    return (
      <span
        className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wide ${className}`}
        style={{ background: "rgba(245,182,66,0.12)", border: "1px solid rgba(245,182,66,0.35)", color: "#F5B642" }}
        title="Pro Seller — verified trust badge"
      >
        <ShieldCheck className="w-2.5 h-2.5" /> PRO
      </span>
    );
  }
  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${className}`}
      style={{ background: "rgba(245,182,66,0.10)", border: "1px solid rgba(245,182,66,0.30)", color: "#F5B642", boxShadow: "0 0 10px rgba(245,182,66,0.12)" }}
    >
      <ShieldCheck className="w-3 h-3" /> Pro Seller
    </span>
  );
}