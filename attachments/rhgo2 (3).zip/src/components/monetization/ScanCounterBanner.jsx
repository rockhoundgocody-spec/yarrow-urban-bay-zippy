/**
 * ScanCounterBanner — quiet scan usage nudge.
 * Shows when user is at 60%+ of their monthly scan limit.
 * Framing: recognition of activity, not punishment.
 */
import React from "react";
import { motion } from "framer-motion";
import { Camera, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { getActiveTier, getScansRemaining, LIMITS } from "@/components/subscription/entitlements";

export default function ScanCounterBanner({ user }) {
  if (!user) return null;

  const tier = getActiveTier(user);
  const limit = (LIMITS[tier] || LIMITS.free).scans_per_month;

  // Don't show for unlimited tiers
  if (limit >= 9999) return null;

  const remaining = getScansRemaining(user);
  const used = limit - remaining;
  const usedPct = used / limit;

  // Only show at 60%+ usage
  if (usedPct < 0.6) return null;

  const isNearLimit = remaining <= 2;
  const isAtLimit = remaining <= 0;

  const accentColor = isAtLimit ? "#ff6b6b" : isNearLimit ? "#F5B642" : "#7AE7FF";

  const message = isAtLimit
    ? `You've identified ${used} specimens this month — serious collectors need more.`
    : isNearLimit
    ? `${remaining} scan${remaining === 1 ? "" : "s"} left this month. Keep the momentum going.`
    : `${remaining} scans remaining — you're building a real collection.`;

  const nextTier = tier === "free" ? "Trail Scout" : tier === "trail_scout" ? "Crystal Pro" : "Expedition Elite";
  const nextPath = "/Pricing";

  return (
    <motion.div
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl px-4 py-3 flex items-center gap-3"
      style={{
        background: `${accentColor}08`,
        border: `1px solid ${accentColor}22`,
      }}
    >
      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl"
        style={{ background: `${accentColor}14`, border: `1px solid ${accentColor}25` }}>
        <Camera size={14} style={{ color: accentColor }} />
      </div>

      <div className="flex-1 min-w-0">
        {/* Progress bar */}
        <div className="w-full h-1 rounded-full mb-1.5 overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
          <div className="h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, usedPct * 100)}%`, background: accentColor }} />
        </div>
        <p className="text-xs leading-snug" style={{ color: "rgba(255,255,255,0.55)" }}>{message}</p>
      </div>

      {!isAtLimit ? null : (
        <Link to={nextPath}
          className="shrink-0 flex items-center gap-1 px-3 py-2 rounded-xl text-[10px] font-bold"
          style={{ background: `${accentColor}14`, border: `1px solid ${accentColor}30`, color: accentColor }}>
          {nextTier} <ChevronRight size={10} />
        </Link>
      )}
    </motion.div>
  );
}