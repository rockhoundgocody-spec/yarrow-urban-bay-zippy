/**
 * ContextualUpgrade — tasteful, contextual upgrade prompt.
 * Shows only when a feature requires a higher tier.
 * Feels like a capability unlock, not a paywall.
 */
import React from "react";
import { Link } from "react-router-dom";
import { Sparkles, Lock } from "lucide-react";
import { hasAccess, getRequiredTier, TIER_NAMES, TIER_COLORS } from "@/components/subscription/entitlements";

const VARIANT_STYLES = {
  // Slim inline bar — for inside panels
  inline: { padding: "p-3", icon: "w-8 h-8", text: "text-xs", cta: "text-[10px] px-3 py-1.5" },
  // Card — for section gates
  card: { padding: "p-5", icon: "w-11 h-11", text: "text-sm", cta: "text-xs px-4 py-2.5" },
  // Minimal chip — for data cells
  chip: { padding: "p-2.5", icon: "w-7 h-7", text: "text-[11px]", cta: "text-[10px] px-2.5 py-1" },
};

export default function ContextualUpgrade({
  user,
  feature,
  title,
  description,
  variant = "inline",
  accentColor,
  className = "",
}) {
  if (!feature || hasAccess(user, feature)) return null;

  const tier = getRequiredTier(feature);
  const colors = TIER_COLORS[tier] || TIER_COLORS.trail_scout || TIER_COLORS.free;
  const tierName = TIER_NAMES[tier] || "Trail Scout";
  const accent = accentColor || colors.text;
  const v = VARIANT_STYLES[variant] || VARIANT_STYLES.inline;

  return (
    <div
      className={`rounded-2xl flex items-center gap-3 ${v.padding} ${className}`}
      style={{
        background: `linear-gradient(135deg, ${colors.bg} 0%, rgba(255,255,255,0.015) 100%)`,
        border: `1px solid ${colors.border}`,
      }}
    >
      <div
        className={`${v.icon} rounded-xl flex items-center justify-center shrink-0`}
        style={{ background: colors.bg, border: `1px solid ${colors.border}` }}
      >
        <Lock className="w-4 h-4" style={{ color: accent }} />
      </div>

      <div className="flex-1 min-w-0">
        <p className={`font-bold text-white leading-snug ${v.text}`}>
          {title || `${tierName} feature`}
        </p>
        {description && (
          <p className="text-white/40 text-[11px] mt-0.5 leading-snug">{description}</p>
        )}
      </div>

      <Link
        to="/Pricing"
        className={`shrink-0 rounded-xl font-black text-black transition-all hover:scale-105 active:scale-95 flex items-center gap-1 ${v.cta}`}
        style={{
          background: `linear-gradient(135deg, ${accent}, ${accent}cc)`,
          boxShadow: `0 0 12px ${accent}35`,
        }}
      >
        <Sparkles className="w-3 h-3" /> Unlock
      </Link>
    </div>
  );
}