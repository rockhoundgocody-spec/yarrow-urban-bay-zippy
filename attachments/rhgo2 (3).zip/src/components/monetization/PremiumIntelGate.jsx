/**
 * PremiumIntelGate — wraps a premium data section with a tasteful blur/gate.
 * Shows a preview blur + upgrade CTA when user lacks access.
 * For data panels: valuations, comps, deep analytics, provenance.
 */
import React from "react";
import { Link } from "react-router-dom";
import { Sparkles } from "lucide-react";
import { hasAccess, getRequiredTier, TIER_NAMES, TIER_COLORS } from "@/components/subscription/entitlements";

export default function PremiumIntelGate({
  user,
  feature,
  title = "Premium Intelligence",
  description,
  children,
  previewRows = 2,
  className = "",
}) {
  if (!feature || hasAccess(user, feature)) {
    return <div className={className}>{children}</div>;
  }

  const tier = getRequiredTier(feature);
  const colors = TIER_COLORS[tier] || TIER_COLORS.crystal;
  const tierName = TIER_NAMES[tier] || "Crystal";

  return (
    <div className={`relative rounded-2xl overflow-hidden ${className}`}>
      {/* Blurred preview of content */}
      <div style={{ filter: "blur(5px)", opacity: 0.35, pointerEvents: "none", userSelect: "none" }} aria-hidden="true">
        {children}
      </div>

      {/* Gate overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center p-5 text-center"
        style={{ background: "linear-gradient(180deg, rgba(5,7,10,0.4) 0%, rgba(5,7,10,0.88) 40%, rgba(5,7,10,0.96) 100%)" }}>
        <div className="w-10 h-10 rounded-2xl flex items-center justify-center mb-3"
          style={{ background: colors.bg, border: `1px solid ${colors.border}` }}>
          <Sparkles className="w-5 h-5" style={{ color: colors.text }} />
        </div>
        <p className="font-black text-white text-sm mb-1">{title}</p>
        {description && <p className="text-white/40 text-[11px] mb-4 leading-relaxed max-w-xs">{description}</p>}
        <Link
          to="/Pricing"
          className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-black text-black transition-all active:scale-95"
          style={{
            background: `linear-gradient(135deg, ${colors.text}, ${colors.text}cc)`,
            boxShadow: `0 0 16px ${colors.text}35`,
          }}
        >
          <Sparkles className="w-3 h-3" /> Unlock with {tierName}
        </Link>
        <p className="text-white/20 text-[10px] mt-2">Cancel anytime · Instant activation</p>
      </div>
    </div>
  );
}