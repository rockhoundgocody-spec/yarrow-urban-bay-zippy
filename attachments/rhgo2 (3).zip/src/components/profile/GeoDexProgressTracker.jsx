/**
 * GeoDexProgressTracker — profile widget showing Shiny variant catalog
 * completion based on the user's found specimens.
 */
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Sparkles, Gem, ChevronRight } from "lucide-react";
import { computeShinyProgress } from "@/components/collection/shinyCatalog";

export default function GeoDexProgressTracker({ userEmail }) {
  const { data: specimens = [], isLoading } = useQuery({
    queryKey: ["collection-specimens", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.Specimen.filter({ created_by: userEmail }, "-created_date", 200),
    staleTime: 30 * 1000,
  });

  const { entries, foundCount, total, offCatalog } = computeShinyProgress(specimens);
  const pct = total > 0 ? Math.round((foundCount / total) * 100) : 0;

  if (isLoading) {
    return (
      <div className="rounded-2xl h-24 animate-pulse"
        style={{ background: "rgba(245,182,66,0.04)", border: "1px solid rgba(245,182,66,0.10)" }} />
    );
  }

  return (
    <div className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(135deg, rgba(245,182,66,0.05), rgba(141,124,255,0.04))",
        border: "1px solid rgba(245,182,66,0.18)",
      }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4" style={{ color: "#F5B642" }} />
          <p className="text-xs font-black uppercase tracking-widest" style={{ color: "#F5B642" }}>
            Geo-DEX · Shiny Catalog
          </p>
        </div>
        <Link to="/Collection" className="flex items-center gap-0.5 text-[10px] font-bold"
          style={{ color: "rgba(122,231,255,0.7)" }}>
          Open DEX <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      {/* Progress bar */}
      <div className="flex items-center gap-3 mb-3">
        <div className="flex-1 h-2.5 rounded-full overflow-hidden"
          style={{ background: "rgba(255,255,255,0.05)" }}>
          <motion.div
            className="h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
            style={{
              background: "linear-gradient(90deg, #F5B642, #8D7CFF)",
              boxShadow: "0 0 10px rgba(245,182,66,0.4)",
            }}
          />
        </div>
        <p className="text-xs font-black flex-shrink-0" style={{ color: "#F5B642" }}>
          {foundCount}/{total} · {pct}%
        </p>
      </div>

      {/* Catalog chips */}
      <div className="flex flex-wrap gap-1.5">
        {entries.map(({ name, found }) => (
          <span key={name}
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold"
            style={{
              background: found ? "rgba(245,182,66,0.12)" : "rgba(255,255,255,0.02)",
              border: `1px solid ${found ? "rgba(245,182,66,0.4)" : "rgba(255,255,255,0.06)"}`,
              color: found ? "#F5B642" : "rgba(255,255,255,0.18)",
              boxShadow: found ? "0 0 8px rgba(245,182,66,0.15)" : "none",
            }}>
            {found ? <Sparkles className="w-2.5 h-2.5" /> : <Gem className="w-2.5 h-2.5" />}
            {found ? name : "???"}
          </span>
        ))}
      </div>

      {/* Off-catalog bonus shinies */}
      {offCatalog.length > 0 && (
        <p className="mt-2.5 text-[10px]" style={{ color: "rgba(141,124,255,0.65)" }}>
          ✦ +{offCatalog.length} bonus shiny {offCatalog.length === 1 ? "species" : "species"} discovered beyond the catalog
        </p>
      )}

      {foundCount === 0 && offCatalog.length === 0 && (
        <p className="mt-2.5 text-[10px]" style={{ color: "rgba(255,255,255,0.28)" }}>
          Scan Very Rare and Legendary specimens in the field to light up the catalog.
        </p>
      )}
    </div>
  );
}