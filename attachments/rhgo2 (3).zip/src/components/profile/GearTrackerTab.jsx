import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Plus, Wrench, Trash2, Camera, MapPin, CalendarDays, Edit, ChevronDown, ChevronUp } from "lucide-react";

const CATEGORY_LABELS = {
  hammer: "🔨 Hammer", chisel: "🪨 Chisel", uv_light: "🔦 UV Light",
  magnifier: "🔍 Magnifier", safety: "🦺 Safety", bag: "🎒 Bag",
  pick: "⛏️ Pick", screen: "🪣 Screen", other: "🧰 Other"
};

const CONDITION_COLORS = {
  excellent: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  good: "bg-cyan-500/15 text-cyan-400 border-cyan-500/25",
  fair: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  needs_maintenance: "bg-red-500/15 text-red-400 border-red-500/25",
  retired: "bg-gray-500/15 text-gray-400 border-gray-500/25",
};

const EMPTY_GEAR = { name: "", category: "other", brand: "", model: "", condition: "good", notes: "", purchase_date: "", last_maintenance_date: "", photo_url: "" };

export default function GearTrackerTab({ userEmail }) {
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [expandedId, setExpandedId] = useState(null);
  const [showMaintLog, setShowMaintLog] = useState(null);
  const [maintNote, setMaintNote] = useState("");
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState(EMPTY_GEAR);

  const { data: gear = [], isLoading } = useQuery({
    queryKey: ["user-gear", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.UserGear.filter({ created_by: userEmail }, "-created_date"),
  });

  const save = useMutation({
    mutationFn: (data) => editing ? base44.entities.UserGear.update(editing.id, data) : base44.entities.UserGear.create(data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["user-gear"] }); setShowForm(false); setEditing(null); setForm(EMPTY_GEAR); },
  });

  const del = useMutation({
    mutationFn: (id) => base44.entities.UserGear.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-gear"] }),
  });

  const addMaint = useMutation({
    mutationFn: ({ gear: g, note }) => {
      const log = [...(g.maintenance_log || []), { date: new Date().toISOString().slice(0, 10), note }];
      return base44.entities.UserGear.update(g.id, { maintenance_log: log, last_maintenance_date: new Date().toISOString().slice(0, 10) });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["user-gear"] }); setMaintNote(""); setShowMaintLog(null); },
  });

  const handlePhoto = async (e, gearId) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    await base44.entities.UserGear.update(gearId, { photo_url: file_url });
    qc.invalidateQueries({ queryKey: ["user-gear"] });
    setUploading(false);
  };

  const openEdit = (g) => {
    setEditing(g);
    setForm({ name: g.name, category: g.category || "other", brand: g.brand || "", model: g.model || "", condition: g.condition || "good", notes: g.notes || "", purchase_date: g.purchase_date || "", last_maintenance_date: g.last_maintenance_date || "", photo_url: g.photo_url || "" });
    setShowForm(true);
  };

  if (isLoading) return <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 text-amber-400 animate-spin" /></div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-white">Field Equipment</h3>
          <p className="text-xs text-white/40">{gear.length} items tracked</p>
        </div>
        <Button size="sm" onClick={() => { setEditing(null); setForm(EMPTY_GEAR); setShowForm(true); }}
          className="bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-400">
          <Plus className="w-3.5 h-3.5 mr-1.5" /> Add Gear
        </Button>
      </div>

      {gear.length === 0 && (
        <div className="text-center py-16 border border-dashed border-white/10 rounded-xl">
          <Wrench className="w-10 h-10 text-white/10 mx-auto mb-3" />
          <p className="text-white/30 text-sm">No gear tracked yet.</p>
          <p className="text-white/20 text-xs mt-1">Log your rock hammers, UV lights, chisels & more.</p>
        </div>
      )}

      <div className="grid gap-3">
        {gear.map((g) => (
          <Card key={g.id} className="bg-[#14141e] border-white/5 overflow-hidden">
            <div className="p-4">
              <div className="flex gap-3">
                {/* Thumbnail */}
                <div className="relative shrink-0">
                  {g.photo_url ? (
                    <img src={g.photo_url} alt={g.name} className="w-14 h-14 rounded-lg object-cover" />
                  ) : (
                    <div className="w-14 h-14 rounded-lg bg-white/5 flex items-center justify-center text-2xl">
                      {CATEGORY_LABELS[g.category]?.split(" ")[0] || "🧰"}
                    </div>
                  )}
                  <label className="absolute -bottom-1 -right-1 w-5 h-5 bg-white/10 rounded-full flex items-center justify-center cursor-pointer hover:bg-white/20 focus-within:ring-2 focus-within:ring-amber-500/50">
                    <Camera className="w-2.5 h-2.5 text-white/60" />
                    <input aria-label="Upload photo" type="file" accept="image/*" className="sr-only" onChange={(e) => handlePhoto(e, g.id)} />
                  </label>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-sm font-semibold text-white">{g.name}</p>
                      <p className="text-xs text-white/40">{CATEGORY_LABELS[g.category] || g.category}{g.brand ? ` · ${g.brand}` : ""}{g.model ? ` ${g.model}` : ""}</p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Badge className={`text-[10px] border ${CONDITION_COLORS[g.condition] || CONDITION_COLORS.good}`}>
                        {g.condition?.replace("_", " ")}
                      </Badge>
                      <button onClick={() => openEdit(g)} aria-label="Edit tool" title="Edit tool" className="p-1 text-white/30 hover:text-white/60"><Edit className="w-3.5 h-3.5" /></button>
                      <button onClick={() => del.mutate(g.id)} aria-label="Delete tool" title="Delete tool" className="p-1 text-white/30 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2 mt-2 text-[10px] text-white/35">
                    {g.last_maintenance_date && (
                      <span className="flex items-center gap-1"><Wrench className="w-3 h-3" /> Maint: {g.last_maintenance_date}</span>
                    )}
                    {g.purchase_date && (
                      <span className="flex items-center gap-1"><CalendarDays className="w-3 h-3" /> Bought: {g.purchase_date}</span>
                    )}
                    {g.linked_location_names?.length > 0 && (
                      <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {g.linked_location_names.length} locations</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Expand */}
              <button
                onClick={() => setExpandedId(expandedId === g.id ? null : g.id)}
                className="mt-3 flex items-center gap-1 text-[10px] text-white/25 hover:text-white/50"
              >
                {expandedId === g.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                {expandedId === g.id ? "Hide details" : "Details & maintenance log"}
              </button>
            </div>

            {expandedId === g.id && (
              <div className="border-t border-white/5 p-4 space-y-3 bg-white/2">
                {g.notes && <p className="text-xs text-white/50">{g.notes}</p>}

                <div>
                  <p className="text-[10px] font-bold text-white/30 uppercase tracking-wider mb-2">Maintenance Log</p>
                  {(g.maintenance_log || []).length === 0 ? (
                    <p className="text-[10px] text-white/20">No maintenance recorded.</p>
                  ) : (
                    <div className="space-y-1">
                      {[...(g.maintenance_log || [])].reverse().slice(0, 5).map((entry, i) => (
                        <div key={i} className="flex items-start gap-2 text-xs">
                          <span className="text-white/25 shrink-0 font-mono">{entry.date}</span>
                          <span className="text-white/60">{entry.note}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <button
                    onClick={() => setShowMaintLog(g)}
                    className="mt-2 text-[10px] text-amber-400/70 hover:text-amber-400 flex items-center gap-1"
                  >
                    <Plus className="w-3 h-3" /> Log maintenance
                  </button>
                </div>
              </div>
            )}
          </Card>
        ))}
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={showForm} onOpenChange={(v) => { setShowForm(v); if (!v) { setEditing(null); setForm(EMPTY_GEAR); } }}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-md">
          <DialogHeader><DialogTitle>{editing ? "Edit Gear" : "Add Gear"}</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            {[
              { label: "Tool Name *", key: "name", placeholder: "e.g. Estwing Rock Hammer" },
              { label: "Brand", key: "brand", placeholder: "e.g. Estwing" },
              { label: "Model", key: "model", placeholder: "e.g. E3-22P" },
            ].map(({ label, key, placeholder }) => (
              <div key={key}>
                <label className="text-xs text-white/50 block mb-1">{label}</label>
                <input
                  className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none focus:border-amber-500/40"
                  value={form[key]} onChange={(e) => setForm(f => ({ ...f, [key]: e.target.value }))}
                  placeholder={placeholder}
                />
              </div>
            ))}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-white/50 block mb-1">Category</label>
                <select className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none"
                  value={form.category} onChange={(e) => setForm(f => ({ ...f, category: e.target.value }))}>
                  {Object.entries(CATEGORY_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Condition</label>
                <select className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none"
                  value={form.condition} onChange={(e) => setForm(f => ({ ...f, condition: e.target.value }))}>
                  {Object.keys(CONDITION_COLORS).map(k => <option key={k} value={k}>{k.replace("_", " ")}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-white/50 block mb-1">Purchase Date</label>
                <input type="date" className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none"
                  value={form.purchase_date} onChange={(e) => setForm(f => ({ ...f, purchase_date: e.target.value }))} />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Last Maintenance</label>
                <input type="date" className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none"
                  value={form.last_maintenance_date} onChange={(e) => setForm(f => ({ ...f, last_maintenance_date: e.target.value }))} />
              </div>
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Notes</label>
              <textarea rows={2} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none resize-none"
                value={form.notes} onChange={(e) => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Any notes about this tool..." />
            </div>
            <div className="flex gap-3 pt-1">
              <Button variant="ghost" className="flex-1 text-white/50" onClick={() => { setShowForm(false); setEditing(null); }}>Cancel</Button>
              <Button className="flex-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-400"
                disabled={!form.name.trim() || save.isPending}
                onClick={() => save.mutate(form)}>
                {save.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
                {editing ? "Save Changes" : "Add Tool"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Maintenance Log Dialog */}
      <Dialog open={!!showMaintLog} onOpenChange={(v) => !v && setShowMaintLog(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader><DialogTitle>Log Maintenance — {showMaintLog?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3 pt-2">
            <textarea rows={3} className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 text-white text-sm outline-none resize-none"
              value={maintNote} onChange={(e) => setMaintNote(e.target.value)}
              placeholder="e.g. Sharpened chisel edge, cleaned UV lens, replaced handle grip..." />
            <Button className="w-full bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-400"
              disabled={!maintNote.trim() || addMaint.isPending}
              onClick={() => addMaint.mutate({ gear: showMaintLog, note: maintNote })}>
              {addMaint.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
              Save Log Entry
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}