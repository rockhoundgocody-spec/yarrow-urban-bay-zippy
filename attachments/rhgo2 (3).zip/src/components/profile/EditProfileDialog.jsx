import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

export default function EditProfileDialog({ user, open, onOpenChange, onSaved }) {
  const [form, setForm] = useState({
    bio: user?.bio || "",
    location: user?.location || "",
    years_experience: user?.years_experience || "",
    favorite_minerals: (user?.favorite_minerals || []).join(", "),
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await base44.auth.updateMe({
      bio: form.bio,
      location: form.location,
      years_experience: form.years_experience ? Number(form.years_experience) : undefined,
      favorite_minerals: form.favorite_minerals.split(",").map((m) => m.trim()).filter(Boolean),
    });
    setSaving(false);
    onSaved?.();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-2">
          <div>
            <label className="text-xs text-white/60 block mb-1">Bio</label>
            <Textarea
              value={form.bio}
              onChange={(e) => setForm({ ...form, bio: e.target.value })}
              placeholder="Tell the community about yourself..."
              className="bg-white/5 border-white/10 text-white text-sm"
              rows={3}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-white/60 block mb-1">Location</label>
              <Input
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
                placeholder="Colorado, USA"
                className="bg-white/5 border-white/10 text-white text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-white/60 block mb-1">Years Experience</label>
              <Input
                type="number"
                value={form.years_experience}
                onChange={(e) => setForm({ ...form, years_experience: e.target.value })}
                placeholder="0"
                className="bg-white/5 border-white/10 text-white text-sm"
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-white/60 block mb-1">Favorite Minerals (comma-separated)</label>
            <Input
              value={form.favorite_minerals}
              onChange={(e) => setForm({ ...form, favorite_minerals: e.target.value })}
              placeholder="Quartz, Amethyst, Tourmaline"
              className="bg-white/5 border-white/10 text-white text-sm"
            />
          </div>
          <Button
            onClick={handleSave}
            disabled={saving}
            className="w-full bg-gradient-to-r from-amber-500 to-orange-600 text-white"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}