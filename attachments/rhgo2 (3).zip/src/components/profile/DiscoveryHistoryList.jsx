/**
 * DiscoveryHistoryList — full RQS v2 ledger history for the dedicated
 * discovery-ledger dashboard. Renders every ScoreLedger row for the owner
 * with the RQS score, component breakdown (R/Q/V/D/E), integrity status,
 * and leaderboard-eligibility flag.
 *
 * Shares the React Query key with RqsDashboard so the two views dedupe to
 * a single network request.
 */
import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Loader2, Sparkles, ShieldCheck, ShieldAlert } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const COMPONENTS = [
  { key: "component_r", label: "R", color: "#8D7CFF", full: "Rarity" },
  { key: "component_q", label: "Q", color: "#7AE7FF", full: "Quality" },
  { key: "component_v", label: "V", color: "#00D68F", full: "Verification" },
  { key: "component_d", label: "D", color: "#F5B642", full: "Documentation" },
  { key: "component_e", label: "E", color: "#FF8844", full: "Ethics" },
];

export default function DiscoveryHistoryList({ userId }) {
  const { data: scores = [], isLoading } = useQuery({
    queryKey: ["rqs-scores", userId],
    enabled: !!userId,
    queryFn: () => base44.entities.ScoreLedger.filter({ user_id: userId }, "-created_date", 200),
  });

  const rows = useMemo(() => scores, [scores]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10 gap-2">
        <Loader2 className="w-5 h-5 animate-spin" style={{ color: "#8D7CFF" }} />
        <span className="text-xs uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>Loading ledger</span>
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="rounded-2xl p-6 text-center"
        style={{ background: "rgba(141,124,255,0.04)", border: "1px solid rgba(141,124,255,0.12)" }}>
        <Sparkles className="w-6 h-6 mx-auto mb-2" style={{ color: "rgba(141,124,255,0.3)" }} />
        <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.5)" }}>No discovery records yet</p>
        <p className="text-[11px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>
          Recorded findings will appear here as immutable ledger entries.
        </p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(10,12,22,0.6)", border: "1px solid rgba(141,124,255,0.18)" }}>
      <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <Sparkles className="w-4 h-4" style={{ color: "#8D7CFF" }} />
        <h3 className="text-xs font-bold uppercase tracking-widest" style={{ color: "#C4B5FD" }}>Discovery Ledger</h3>
        <span className="ml-auto text-[10px]" style={{ color: "rgba(255,255,255,0.3)" }}>{rows.length} records</span>
      </div>

      <div className="max-h-[420px] overflow-y-auto" style={{ scrollbarWidth: "thin" }}>
        {rows.map((s) => {
          const rqs = Math.round(Number(s.rqs_score) || 0);
          const eligible = !!s.is_eligible_leaderboard;
          const integrity = s.integrity_status || "pending";
          return (
            <div key={s.id} className="px-4 py-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-bold text-white truncate">{s.mineral_name || "Specimen"}</p>
                    {eligible ? (
                      <span className="flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: "rgba(0,214,143,0.12)", color: "#00D68F", border: "1px solid rgba(0,214,143,0.3)" }}>
                        <ShieldCheck className="w-2.5 h-2.5" /> Eligible
                      </span>
                    ) : (
                      <span className="flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                        style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.4)", border: "1px solid rgba(255,255,255,0.08)" }}>
                        <ShieldAlert className="w-2.5 h-2.5" /> {integrity}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] mt-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>
                    {formatDistanceToNow(new Date(s.created_date), { addSuffix: true })}
                    {s.xp_awarded ? ` · +${Math.round(Number(s.xp_awarded))} XP` : ""}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-lg font-black" style={{ color: "#C4B5FD", textShadow: "0 0 12px rgba(141,124,255,0.3)" }}>{rqs}</div>
                  <div className="text-[8px] uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>RQS</div>
                </div>
              </div>

              {/* Component mini-bars */}
              <div className="flex gap-2 mt-2">
                {COMPONENTS.map((c) => {
                  const val = Math.round((Number(s[c.key]) || 0) * 100);
                  return (
                    <div key={c.key} className="flex-1" title={c.full}>
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="text-[8px] font-bold" style={{ color: c.color }}>{c.label}</span>
                        <span className="text-[8px]" style={{ color: "rgba(255,255,255,0.3)" }}>{val}</span>
                      </div>
                      <div className="h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                        <div className="h-full rounded-full" style={{ width: `${val}%`, background: c.color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}