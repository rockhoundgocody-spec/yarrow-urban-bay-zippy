import React, { useState, useEffect, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { MILESTONES, TIER_ORDER, TIER_META, RARITY_META } from "@/lib/milestones";
import {
  Loader2, CheckCircle2, Lock, Sparkles, RefreshCw,
  Gem, Package, Archive, Trophy, Crown, Diamond, Bone, Heart,
  MapPin, Compass, Map, Globe, PlusCircle, Route, Star,
  MessageSquare, Camera, Image, ThumbsUp, Zap, Flame, Award,
  Shield, Brain, MessagesSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const ICON_MAP = {
  Gem, Package, Archive, Trophy, Crown, Diamond, Bone, Heart,
  MapPin, Compass, Map, Globe, PlusCircle, Route, Star,
  MessageSquare, Camera, Image, ThumbsUp, Zap, Flame, Award,
  Shield, Brain, Sparkles, MessagesSquare,
};

function DynIcon({ name, className, style }) {
  const Icon = ICON_MAP[name] || Gem;
  return <Icon className={className} style={style} />;
}

function MilestoneCard({ milestone, earned, earnedAt, progress }) {
  const rarity = RARITY_META[milestone.rarity];
  const pct = earned ? 100 : Math.round((progress.current / progress.target) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "relative rounded-2xl border p-4 flex gap-4 items-start transition-all duration-200",
        earned ? "border-white/15 bg-white/5" : "border-white/5 bg-white/[0.02] opacity-70"
      )}
      style={earned ? { boxShadow: `0 0 20px ${milestone.color}22` } : {}}
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 mt-0.5"
        style={{
          background: earned ? `${milestone.color}22` : "rgba(255,255,255,0.04)",
          border: `1px solid ${earned ? milestone.color + "55" : "rgba(255,255,255,0.08)"}`,
          boxShadow: earned ? `0 0 12px ${milestone.color}44` : "none",
        }}
      >
        {earned ? (
          <DynIcon name={milestone.icon} className="w-5 h-5" style={{ color: milestone.color }} />
        ) : (
          <Lock className="w-4 h-4 text-white/20" />
        )}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2 mb-0.5">
          <span className={cn("text-sm font-semibold", earned ? "text-white" : "text-white/40")}>
            {milestone.name}
          </span>
          <span
            className="text-[10px] shrink-0 px-1.5 py-0.5 rounded-full"
            style={{ color: rarity.color, background: rarity.color + "22", border: `1px solid ${rarity.color}44` }}
          >
            {rarity.label}
          </span>
        </div>
        <p className="text-xs text-white/40 mb-2 leading-relaxed">{milestone.description}</p>

        {!earned && (
          <div className="space-y-1">
            <div className="flex justify-between text-[10px] text-white/30">
              <span>Progress</span>
              <span>{progress.current} / {progress.target}</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${pct}%`, background: milestone.color }}
              />
            </div>
          </div>
        )}

        {earned && earnedAt && (
          <p className="text-[10px] text-white/30 flex items-center gap-1 mt-1">
            <CheckCircle2 className="w-3 h-3 text-green-400" />
            Earned {new Date(earnedAt).toLocaleDateString()}
          </p>
        )}
      </div>
    </motion.div>
  );
}

export default function RewardsTab({ userEmail }) {
  const queryClient = useQueryClient();
  const [newlyUnlocked, setNewlyUnlocked] = useState([]);
  const [activeTier, setActiveTier] = useState("all");

  const { data: badges = [], isLoading: loadingBadges } = useQuery({
    queryKey: ["user-badges", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.UserBadge.filter({ created_by: userEmail }, "-earned_at"),
  });

  const { data: specimens = [] } = useQuery({
    queryKey: ["specimens-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.Specimen.filter({ created_by: userEmail }),
  });

  const { data: locationLogs = [] } = useQuery({
    queryKey: ["location-logs-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.LocationLog.filter({ created_by: userEmail }),
  });

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.LocationReview.filter({ created_by: userEmail }),
  });

  const { data: photos = [] } = useQuery({
    queryKey: ["photos-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.LocationPhoto.filter({ created_by: userEmail }),
  });

  const { data: topics = [] } = useQuery({
    queryKey: ["topics-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.ForumTopic.filter({ created_by: userEmail }),
  });

  const { data: forumPosts = [] } = useQuery({
    queryKey: ["posts-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.ForumPost.filter({ created_by: userEmail }),
  });

  const { data: trips = [] } = useQuery({
    queryKey: ["trips-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.TripPlan.filter({ created_by: userEmail }),
  });

  const { data: userXP = null } = useQuery({
    queryKey: ["user-xp-rewards", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.UserXP.filter({ created_by: userEmail }).then(r => r[0]),
  });

  const { data: scans = [] } = useQuery({
    queryKey: ["scans-count", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.Scans.filter({ created_by: userEmail }),
  });

  const liveStats = useMemo(() => {
    // ⚡ Bolt Optimization: Replaced 4 consecutive O(N) array filter passes
    // with a single O(N) loop to eliminate redundant traversals and prevent
    // intermediate array allocations during render cycles.
    let gemstones = 0;
    let fossils = 0;
    let crystals = 0;
    let favorites = 0;

    for (let i = 0; i < specimens.length; i++) {
      const s = specimens[i];
      if (s.category === "gemstone") gemstones++;
      if (s.category === "fossil") fossils++;
      if (s.category === "crystal") crystals++;
      if (s.is_favorite) favorites++;
    }

    return {
      specimens: specimens.length,
      gemstones,
      fossils,
      crystals,
      favorites,
      sitesVisited: locationLogs.length,
      statesVisited: 0,
      sitesAdded: 0,
      tripsPlanned: trips.length,
      reviews: reviews.length,
      photos: photos.length,
      topics: topics.length,
      helpfulVotes:
        reviews.reduce((s, r) => s + (r.helpful_count || 0), 0) +
        forumPosts.reduce((s, p) => s + (p.helpful_count || 0), 0),
      totalXP: userXP?.total_xp || 0,
      level: userXP?.level || 1,
      streak: 0,
      aiScans: scans.length,
    };
  }, [
    specimens,
    locationLogs.length,
    trips.length,
    reviews,
    photos.length,
    topics.length,
    forumPosts,
    userXP,
    scans.length
  ]);

  const checkMutation = useMutation({
    mutationFn: () => base44.functions.invoke("checkMilestones", {}),
    onSuccess: (res) => {
      const newly = res?.data?.newlyEarned || [];
      if (newly.length > 0) {
        setNewlyUnlocked(newly);
        setTimeout(() => setNewlyUnlocked([]), 6000);
      }
      queryClient.invalidateQueries({ queryKey: ["user-badges", userEmail] });
    },
  });

  useEffect(() => {
    if (userEmail) checkMutation.mutate();
  }, [userEmail]);

  const earnedMap = new Map(badges.map(b => [b.badge_id, b]));
  const earnedCount = badges.length;
  const totalCount = MILESTONES.length;

  const filteredMilestones = activeTier === "all"
    ? MILESTONES
    : MILESTONES.filter(m => m.tier === activeTier);

  const sorted = [...filteredMilestones].sort((a, b) => {
    const aEarned = earnedMap.has(a.id) ? 1 : 0;
    const bEarned = earnedMap.has(b.id) ? 1 : 0;
    if (aEarned !== bEarned) return bEarned - aEarned;
    const aProg = a.progress(liveStats);
    const bProg = b.progress(liveStats);
    return (bProg.current / bProg.target) - (aProg.current / aProg.target);
  });

  if (loadingBadges) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Newly unlocked banner */}
      <AnimatePresence>
        {newlyUnlocked.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            className="rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 flex items-center gap-3"
          >
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
            <div>
              <p className="text-sm font-semibold text-amber-300">
                🎉 {newlyUnlocked.length} new milestone{newlyUnlocked.length > 1 ? "s" : ""} unlocked!
              </p>
              <p className="text-xs text-amber-400/70 mt-0.5">
                {newlyUnlocked.map(id => MILESTONES.find(m => m.id === id)?.name).filter(Boolean).join(", ")}
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Header card */}
      <div className="holographic-glass rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-white">Milestone Progress</h3>
            <p className="text-xs text-white/40 mt-0.5">{earnedCount} of {totalCount} badges earned</p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => checkMutation.mutate()}
            disabled={checkMutation.isPending}
            className="text-white/40 hover:text-white/70 text-xs gap-1.5"
          >
            <RefreshCw className={cn("w-3.5 h-3.5", checkMutation.isPending && "animate-spin")} />
            Sync
          </Button>
        </div>

        {/* Overall bar */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-white/40 mb-1.5">
            <span>Overall completion</span>
            <span>{Math.round((earnedCount / totalCount) * 100)}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-white/5 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: "linear-gradient(90deg, #f59e0b, #ef4444, #8b5cf6)" }}
              initial={{ width: 0 }}
              animate={{ width: `${(earnedCount / totalCount) * 100}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
        </div>

        {/* Quick counts */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Earned", value: earnedCount, color: "#f59e0b" },
            {
              label: "In Progress",
              value: MILESTONES.filter(m => !earnedMap.has(m.id) && m.progress(liveStats).current > 0).length,
              color: "#60a5fa"
            },
            {
              label: "Locked",
              value: MILESTONES.filter(m => !earnedMap.has(m.id) && m.progress(liveStats).current === 0).length,
              color: "#6b7280"
            },
          ].map(s => (
            <div key={s.label} className="text-center rounded-xl bg-white/5 py-2.5">
              <div className="text-lg font-bold" style={{ color: s.color }}>{s.value}</div>
              <div className="text-[10px] text-white/40">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Tier filter */}
      <div className="flex gap-2 flex-wrap">
        <button
          onClick={() => setActiveTier("all")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-medium border transition-all",
            activeTier === "all"
              ? "bg-white/10 text-white border-white/20"
              : "bg-white/5 text-white/40 border-white/10 hover:border-white/20"
          )}
        >
          All ({MILESTONES.length})
        </button>
        {TIER_ORDER.map(tier => {
          const meta = TIER_META[tier];
          const count = MILESTONES.filter(m => m.tier === tier).length;
          const earnedInTier = MILESTONES.filter(m => m.tier === tier && earnedMap.has(m.id)).length;
          return (
            <button
              key={tier}
              onClick={() => setActiveTier(tier)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-xs font-medium border transition-all",
                activeTier === tier
                  ? "text-white"
                  : "bg-white/5 text-white/40 border-white/10 hover:border-white/20"
              )}
              style={activeTier === tier ? { background: meta.bg, borderColor: meta.border, color: meta.color } : {}}
            >
              {meta.label} ({earnedInTier}/{count})
            </button>
          );
        })}
      </div>

      {/* Milestone list */}
      <div className="space-y-3">
        {sorted.map(milestone => (
          <MilestoneCard
            key={milestone.id}
            milestone={milestone}
            earned={earnedMap.has(milestone.id)}
            earnedAt={earnedMap.get(milestone.id)?.earned_at}
            progress={milestone.progress(liveStats)}
          />
        ))}
      </div>
    </div>
  );
}