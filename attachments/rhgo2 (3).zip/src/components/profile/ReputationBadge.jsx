import React from "react";
import { cn } from "@/lib/utils";
import { Star, Shield, Award, Zap } from "lucide-react";

const TIERS = [
  { min: 0,   label: "Novice",    color: "text-white/40",       bg: "bg-white/5",         icon: Zap },
  { min: 50,  label: "Explorer",  color: "text-emerald-400",    bg: "bg-emerald-500/10",  icon: Star },
  { min: 150, label: "Collector", color: "text-cyan-400",       bg: "bg-cyan-500/10",     icon: Shield },
  { min: 300, label: "Expert",    color: "text-amber-400",      bg: "bg-amber-500/10",    icon: Award },
  { min: 600, label: "Master",    color: "text-purple-400",     bg: "bg-purple-500/10",   icon: Award },
];

export function getTier(score) {
  return [...TIERS].reverse().find((t) => score >= t.min) || TIERS[0];
}

export default function ReputationBadge({ score, size = "md" }) {
  const tier = getTier(score);
  const Icon = tier.icon;
  const isLg = size === "lg";

  return (
    <div className={cn("inline-flex items-center gap-2 rounded-full border px-3 py-1.5", tier.bg, `border-current/20`)}>
      <Icon className={cn(isLg ? "w-5 h-5" : "w-3.5 h-3.5", tier.color)} />
      <span className={cn("font-semibold", tier.color, isLg ? "text-base" : "text-xs")}>
        {tier.label}
      </span>
      <span className={cn("opacity-60", tier.color, isLg ? "text-sm" : "text-[10px]")}>
        {score} pts
      </span>
    </div>
  );
}