import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Loader2, Save, Map, Bell, Eye, Trash2 } from "lucide-react";

function Toggle({ checked, onChange, label, description }) {
  return (
    <label className="flex items-start gap-3 cursor-pointer group">
      <div
        onClick={() => onChange(!checked)}
        className={`relative mt-0.5 w-9 h-5 rounded-full transition-colors shrink-0 ${checked ? "bg-amber-500" : "bg-white/15"}`}
      >
        <div className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-4" : ""}`} />
      </div>
      <div>
        <div className="text-sm text-white/80 font-medium">{label}</div>
        {description && <div className="text-xs text-white/40 mt-0.5">{description}</div>}
      </div>
    </label>
  );
}

export default function ProfileSettings({ user, onSaved }) {
  const [form, setForm] = useState({
    preferred_map_view: user.preferred_map_view || "standard",
    notify_nearby_spots: user.notify_nearby_spots ?? true,
    notify_replies: user.notify_replies ?? true,
    notify_moderation: user.notify_moderation ?? false,
    profile_public: user.profile_public ?? true,
    contributions_public: user.contributions_public ?? true,
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleDeleteAccount = async () => {
    setDeleting(true);
    await base44.functions.invoke("deleteAccount", {});
    base44.auth.logout("/");
  };

  const handleSave = async () => {
    setSaving(true);
    await base44.auth.updateMe(form);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    onSaved && onSaved();
  };

  return (
    <div className="space-y-4">
      {/* Map Preference */}
      <Card className="bg-[#14141e] border-white/5 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Map className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">Map Preferences</h3>
        </div>
        <div>
          <label className="text-xs text-white/50 block mb-2">Default Map View</label>
          <Select value={form.preferred_map_view} onValueChange={v => set("preferred_map_view", v)}>
            <SelectTrigger className="w-48 bg-white/5 border-white/10 text-white text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="standard">Standard (Dark)</SelectItem>
              <SelectItem value="satellite">Satellite</SelectItem>
              <SelectItem value="terrain">Terrain</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      {/* Notifications */}
      <Card className="bg-[#14141e] border-white/5 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Bell className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">Notifications</h3>
        </div>
        <div className="space-y-4">
          <Toggle
            checked={form.notify_nearby_spots}
            onChange={v => set("notify_nearby_spots", v)}
            label="New Nearby Spots"
            description="Get notified when new rockhounding sites are added near you"
          />
          <Toggle
            checked={form.notify_replies}
            onChange={v => set("notify_replies", v)}
            label="Replies & Comments"
            description="Notify when someone replies to your posts or reviews"
          />
          {(user.role === "moderator" || user.role === "admin") && (
            <Toggle
              checked={form.notify_moderation}
              onChange={v => set("notify_moderation", v)}
              label="Moderation Outcomes"
              description="Updates on flags and moderation decisions"
            />
          )}
        </div>
      </Card>

      {/* Privacy */}
      <Card className="bg-[#14141e] border-white/5 p-5">
        <div className="flex items-center gap-2 mb-4">
          <Eye className="w-4 h-4 text-amber-400" />
          <h3 className="text-sm font-semibold text-white">Privacy</h3>
        </div>
        <div className="space-y-4">
          <Toggle
            checked={form.profile_public}
            onChange={v => set("profile_public", v)}
            label="Public Profile"
            description="Others can view your profile, bio, and reputation"
          />
          <Toggle
            checked={form.contributions_public}
            onChange={v => set("contributions_public", v)}
            label="Public Contributions"
            description="Show your added locations and reviews to other users"
          />
        </div>
      </Card>

      <Button
        onClick={handleSave}
        disabled={saving}
        className={`w-full font-semibold transition-all ${saved ? "bg-emerald-600 hover:bg-emerald-600" : "bg-gradient-to-r from-amber-500 to-orange-600"} text-white`}
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
        {saved ? "Saved!" : "Save Settings"}
      </Button>

      {/* Delete Account */}
      <Card className="bg-red-950/20 border-red-500/15 p-5 mt-2">
        <div className="flex items-center gap-2 mb-3">
          <Trash2 className="w-4 h-4 text-red-400" />
          <h3 className="text-sm font-semibold text-red-300">Danger Zone</h3>
        </div>
        {!deleteConfirm ? (
          <button
            onClick={() => setDeleteConfirm(true)}
            className="w-full py-2.5 rounded-xl text-sm font-semibold text-red-400 border border-red-500/25 bg-red-500/5 hover:bg-red-500/10 transition-all"
            style={{ minHeight: 44 }}
          >
            Delete My Account
          </button>
        ) : (
          <div className="space-y-3">
            <p className="text-xs text-red-300/70 leading-relaxed">
              This permanently deletes your account, specimens, reviews, and all data. This cannot be undone.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setDeleteConfirm(false)}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-white/50 border border-white/10 hover:bg-white/5 transition-all"
                style={{ minHeight: 44 }}
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleting}
                className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white bg-red-600 hover:bg-red-700 transition-all flex items-center justify-center gap-2"
                style={{ minHeight: 44 }}
              >
                {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                Confirm Delete
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}