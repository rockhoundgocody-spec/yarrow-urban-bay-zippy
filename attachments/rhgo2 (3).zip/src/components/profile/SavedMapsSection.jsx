import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Trash2, Star } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function SavedMapsSection({ userEmail }) {
  const [expandedId, setExpandedId] = useState(null);
  const queryClient = useQueryClient();

  const { data: savedConfigs = [], isLoading } = useQuery({
    queryKey: ["saved-map-configs", userEmail],
    enabled: !!userEmail,
    queryFn: () => base44.entities.SavedMapConfig.filter({ created_by: userEmail }, "-last_used"),
  });

  const deleteMutation = useMutation({
    mutationFn: (configId) => base44.entities.SavedMapConfig.delete(configId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["saved-map-configs"] });
    },
  });

  const setDefaultMutation = useMutation({
    mutationFn: async (configId) => {
      // Unset other defaults and set the new default in parallel
      const others = savedConfigs.filter(c => c.id !== configId && c.is_default);
      await Promise.all([
        base44.entities.SavedMapConfig.update(configId, { is_default: true }),
        ...others.map(other => base44.entities.SavedMapConfig.update(other.id, { is_default: false }))
      ]);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["saved-map-configs"] });
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
      </div>
    );
  }

  if (savedConfigs.length === 0) {
    return (
      <div className="text-center py-12 text-white/30">
        <p className="text-sm">No saved map configurations yet.</p>
        <p className="text-xs mt-1">Create one on the Map page to manage them here.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {savedConfigs.map(config => (
        <Card key={config.id} className="bg-[#14141e] border-white/5 overflow-hidden">
          <div className="p-4">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-white truncate">{config.config_name}</h4>
                  {config.is_default && (
                    <Badge className="text-[10px] bg-yellow-500/20 text-yellow-300 border-yellow-500/30 shrink-0">
                      Default
                    </Badge>
                  )}
                </div>
                {config.description && (
                  <p className="text-xs text-white/50 line-clamp-1">{config.description}</p>
                )}
                <p className="text-[10px] text-white/30 mt-1">
                  Created {formatDistanceToNow(new Date(config.created_at), { addSuffix: true })}
                  {config.last_used && config.last_used !== config.created_at && (
                    <span> • Used {formatDistanceToNow(new Date(config.last_used), { addSuffix: true })}</span>
                  )}
                </p>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setDefaultMutation.mutate(config.id)}
                  disabled={setDefaultMutation.isPending || config.is_default}
                  className="h-8 w-8 text-yellow-400/40 hover:text-yellow-400"
                  title="Set as default"
                  aria-label="Set as default"
                >
                  <Star className="w-4 h-4" />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteMutation.mutate(config.id)}
                  disabled={deleteMutation.isPending}
                  className="h-8 w-8 text-red-400/40 hover:text-red-400"
                  title="Delete"
                  aria-label="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Config details toggle */}
            <button
              onClick={() => setExpandedId(expandedId === config.id ? null : config.id)}
              className="text-xs text-white/40 hover:text-white/60 transition-colors"
            >
              {expandedId === config.id ? "Hide" : "Show"} configuration
            </button>

            {expandedId === config.id && (
              <div className="mt-3 pt-3 border-t border-white/5 space-y-2 text-xs text-white/50">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="font-medium text-white/60 mb-1">Layers</p>
                    <ul className="text-[10px] space-y-0.5 ml-2">
                      {Object.entries(config.map_layers || {}).map(([key, enabled]) => (
                        enabled && (
                          <li key={key} className="text-white/40">
                            ✓ {key.replace("show_", "").replace(/_/g, " ")}
                          </li>
                        )
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="font-medium text-white/60 mb-1">Filters</p>
                    <p className="text-[10px] text-white/40">
                      {Object.keys(config.filters || {}).filter(k => (config.filters[k] || []).length > 0).length} filters active
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  );
}
