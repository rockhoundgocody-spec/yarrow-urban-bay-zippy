/**
 * ProfileBadgeShowcase — Renders pinned featured Liquid Mineral Badges on the user's profile page.
 * Allows users to showcase and pin up to 3 badges to highlight.
 */

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Pin, Trophy, Plus, Check } from 'lucide-react';
import MineralEmblemBadge from '@/components/badges/MineralEmblemBadge';
import MaterialBreakdownModal from '@/components/badges/MaterialBreakdownModal';
import { getAllBadges, getBadgeById } from '@/services/rewards/badgeDefinitions';

export default function ProfileBadgeShowcase({ userBadges = [] }) {
  const [pinnedBadgeIds, setPinnedBadgeIds] = useState(['crystal_whisperer', 'trailblazer', 'sharp_eye']);
  const [selectedBadgeForBreakdown, setSelectedBadgeForBreakdown] = useState(null);
  const [isPickerOpen, setIsPickerOpen] = useState(false);

  const allBadges = getAllBadges();
  const pinnedBadges = pinnedBadgeIds.map((id) => getBadgeById(id)).filter(Boolean);

  const togglePinBadge = (badgeId) => {
    if (pinnedBadgeIds.includes(badgeId)) {
      setPinnedBadgeIds(pinnedBadgeIds.filter((id) => id !== badgeId));
    } else {
      if (pinnedBadgeIds.length < 3) {
        setPinnedBadgeIds([...pinnedBadgeIds, badgeId]);
      }
    }
  };

  return (
    <div className="w-full space-y-4 text-white">
      {/* Material Breakdown Modal */}
      {selectedBadgeForBreakdown && (
        <MaterialBreakdownModal
          badgeId={selectedBadgeForBreakdown}
          isOpen={!!selectedBadgeForBreakdown}
          onClose={() => setSelectedBadgeForBreakdown(null)}
        />
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Trophy className="w-4 h-4 text-amber-400" />
          <h3 className="font-extrabold text-sm tracking-tight text-white">Featured Profile Badges</h3>
        </div>

        <button
          onClick={() => setIsPickerOpen(!isPickerOpen)}
          className="flex items-center gap-1 text-[11px] font-bold text-amber-400 hover:text-amber-300 transition-colors"
        >
          <Pin className="w-3 h-3" />
          <span>{isPickerOpen ? 'Done Pinning' : 'Customize Pinned'}</span>
        </button>
      </div>

      {/* Pinned Badges Grid */}
      <div className="grid grid-cols-3 gap-3 p-4 rounded-3xl border bg-slate-950/60 border-amber-500/20 shadow-xl">
        {pinnedBadges.map((badge) => (
          <motion.div
            key={badge.id}
            whileHover={{ scale: 1.05 }}
            className="flex flex-col items-center justify-center p-2 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-500/40 transition-all cursor-pointer"
            onClick={() => setSelectedBadgeForBreakdown(badge.id)}
          >
            <MineralEmblemBadge
              badge={badge}
              size={85}
              isUnlocked={true}
              showLabel={true}
            />
          </motion.div>
        ))}

        {Array.from({ length: Math.max(0, 3 - pinnedBadges.length) }).map((_, i) => (
          <div
            key={i}
            onClick={() => setIsPickerOpen(true)}
            className="flex flex-col items-center justify-center p-4 rounded-2xl border border-dashed border-white/15 bg-white/5 hover:bg-white/10 transition-colors cursor-pointer text-slate-400 hover:text-slate-200"
          >
            <Plus className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-bold uppercase">Pin Badge</span>
          </div>
        ))}
      </div>

      {/* Pin Picker Tray */}
      {isPickerOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          className="p-4 rounded-3xl border border-amber-500/30 bg-slate-900/90 space-y-3"
        >
          <p className="text-xs font-bold text-amber-300">Select up to 3 badges to feature on your profile:</p>
          <div className="grid grid-cols-4 gap-2 max-h-48 overflow-y-auto pr-1">
            {allBadges.map((badge) => {
              const isPinned = pinnedBadgeIds.includes(badge.id);

              return (
                <button
                  key={badge.id}
                  onClick={() => togglePinBadge(badge.id)}
                  className={`p-2 rounded-2xl border flex flex-col items-center text-center transition-all ${
                    isPinned
                      ? 'bg-amber-500/20 border-amber-400 text-white'
                      : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-lg">{badge.icon}</span>
                  <span className="text-[9px] font-bold line-clamp-1 mt-1">{badge.name}</span>
                  {isPinned && <Check className="w-3 h-3 text-amber-400 mt-1" />}
                </button>
              );
            })}
          </div>
        </motion.div>
      )}
    </div>
  );
}
