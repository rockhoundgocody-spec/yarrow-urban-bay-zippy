/**
 * RqsDashboard — Profile section RQS v2 metrics view.
 *
 * Visualizes collection growth and total rarity score from the server-
 * authoritative ScoreLedger, plus a rarity-tier breakdown of the collection.
 * Reads only from the RQS v2 ledger (ScoreLedger) for scores — never client-
 * computed — so the numbers shown here are the same cheat-proof values that
 * drive leaderboards.
 */
import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Sparkles, TrendingUp, Gem, Loader2, ShieldCheck, Award } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { formatDistanceToNow } from "date-fns";

const RARITY_TIERS = [
  { key: "common", label: "Common", color: "#9CA3AF" },
  { key: "uncommon", label: "Uncommon", color: "#4ADE80" },
  { key: "rare", label: "Rare", color: "#7AE7FF" },
  { key: "very rare", label: "Very Rare", color: "#8D7CFF" },
  { key: "legendary", label: "Legendary", color: "#F5B642" },
];

function normalizeRarity(r) {
  const s = String(r || "").toLowerCase();
  if (s === "epic") return "very rare";
  return RARITY_TIERS.some((t) => t.key === s) ? s : "common";
}

function Panel({ title, icon: Icon, accent, children }) {
  return (
    <div className="rounded-2xl p-4"
      style={{ background: "rgba(10,12,22,0.6)", border: `1px solid ${accent}22` }}>
      <div className="flex items-center gap-2 mb-3">
        <Icon className="w-4 h-4" style={{ color: accent }} />
        <h3 className="text-xs font-bold uppercase tracking-widest" style={{ color: `${accent}cc` }}>{title}</h3>
      </div>
      {children}
    </div>
  );
}

export default function RqsDashboard({ userId, userEmail }) {
  // Authoritative RQS scores from the server-side ledger (RLS: owner + admin).
  const { data: scores = [], isLoading: scoresLoading } = useQuery({
    queryKey: ["rqs-scores", userId],
    enabled: !!userId,
    queryFn: () => base44.entities.ScoreLedger.filter({ user_id: userId }, "-created_date", 200),
  });
  // Collection specimens for the rarity-tier breakdown (RLS limits to owner).
  const { data: specimens = [], isLoading: specLoading } = useQuery({
    queryKey: ["rqs-specimens", userId],
    enabled: !!userId,
    queryFn: () => base44.entities.Specimen.list("-created_date", 200),
  });

  const eligibleScores = useMemo(() => scores.filter((s) => s.is_eligible_leaderboard), [scores]);
  const totalRqs = useMemo(() => eligibleScores.reduce((sum, s) => sum + (Number(s.rqs_score) || 0), 0), [eligibleScores]);
  const totalXp = useMemo(() => eligibleScores.reduce((sum, s) => sum + (Number(s.xp_awarded) || 0), 0), [eligibleScores]);
  const bestRqs = useMemo(() => eligibleScores.reduce((m, s) => Math.max(m, Number(s.rqs_score) || 0), 0), [eligibleScores]);

  // Cumulative RQS growth over time (oldest → newest).
  const growthData = useMemo(() => {
    const sorted = [...scores].sort((a, b) => new Date(a.created_date || 0) - new Date(b.created_date || 0));
    let cum = 0;
    return sorted.map((s) => {
      cum += Number(s.rqs_score) || 0;
      return {
        date: new Date(s.created_date || Date.now()).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
        rqs: Math.round(cum),
      };
    });
  }, [scores]);

  // Rarity tier breakdown across the collection.
  const tierCounts = useMemo(() => {
    const counts = Object.fromEntries(RARITY_TIERS.map((t) => [t.key, 0]));
    for (const s of specimens) counts[normalizeRarity(s.rarity)] += 1;
    return counts;
  }, [specimens]);
  const maxTier = Math.max(1, ...Object.values(tierCounts));

  if (scoresLoading || specLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <Loader2 className="w-7 h-7 animate-spin" style={{ color: "#8D7CFF" }} />
        <span className="text-xs uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>Loading RQS metrics</span>
      </div>
    );
  }

  if (scores.length === 0 && specimens.length === 0) {
    return (
      <div className="text-center py-16">
        <Sparkles className="w-10 h-10 mx-auto mb-3" style={{ color: "rgba(141,124,255,0.15)" }} />
        <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.5)" }}>No RQS data yet</p>
        <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>
          Scan and record findings to build your server-authoritative rarity score.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* ── Headline metrics ── */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl p-4 text-center"
          style={{ background: "linear-gradient(145deg, rgba(141,124,255,0.10), rgba(141,124,255,0.03))", border: "1px solid rgba(141,124,255,0.25)" }}>
          <Sparkles className="w-4 h-4 mx-auto mb-1" style={{ color: "#8D7CFF" }} />
          <div className="text-2xl font-black" style={{ color: "#C4B5FD", textShadow: "0 0 16px rgba(141,124,255,0.4)" }}>
            {totalRqs.toLocaleString()}
          </div>
          <div className="text-[9px] uppercase tracking-widest mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>Total RQS</div>
        </div>
        <div className="rounded-2xl p-4 text-center"
          style={{ background: "linear-gradient(145deg, rgba(0,214,143,0.10), rgba(0,214,143,0.03))", border: "1px solid rgba(0,214,143,0.25)" }}>
          <Award className="w-4 h-4 mx-auto mb-1" style={{ color: "#00D68F" }} />
          <div className="text-2xl font-black" style={{ color: "#4AE5A8", textShadow: "0 0 16px rgba(0,214,143,0.4)" }}>
            {totalXp.toLocaleString()}
          </div>
          <div className="text-[9px] uppercase tracking-widest mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>RQS XP</div>
        </div>
        <div className="rounded-2xl p-4 text-center"
          style={{ background: "linear-gradient(145deg, rgba(245,182,66,0.10), rgba(245,182,66,0.03))", border: "1px solid rgba(245,182,66,0.25)" }}>
          <Gem className="w-4 h-4 mx-auto mb-1" style={{ color: "#F5B642" }} />
          <div className="text-2xl font-black" style={{ color: "#F5B642", textShadow: "0 0 16px rgba(245,182,66,0.4)" }}>
            {bestRqs.toLocaleString()}
          </div>
          <div className="text-[9px] uppercase tracking-widest mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>Best Find</div>
        </div>
      </div>

      {/* ── Collection growth chart ── */}
      <Panel title="Collection Growth" icon={TrendingUp} accent="#8D7CFF">
        {growthData.length < 2 ? (
          <p className="text-xs py-6 text-center" style={{ color: "rgba(255,255,255,0.3)" }}>
            Record more findings to see your growth curve.
          </p>
        ) : (
          <div style={{ width: "100%", height: 160 }}>
            <ResponsiveContainer>
              <AreaChart data={growthData} margin={{ top: 5, right: 8, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="rqsGrowth" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#8D7CFF" stopOpacity={0.5} />
                    <stop offset="100%" stopColor="#8D7CFF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="date" tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 10 }} tickLine={false} axisLine={false} minTickGap={24} />
                <YAxis tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 10 }} tickLine={false} axisLine={false} width={40} />
                <Tooltip
                  contentStyle={{ background: "#0A0D16", border: "1px solid rgba(141,124,255,0.3)", borderRadius: 12, fontSize: 12, color: "#fff" }}
                  labelStyle={{ color: "rgba(255,255,255,0.5)" }}
                />
                <Area type="monotone" dataKey="rqs" stroke="#8D7CFF" strokeWidth={2} fill="url(#rqsGrowth)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </Panel>

      {/* ── Rarity tier breakdown ── */}
      <Panel title="Discoveries by Rarity" icon={Gem} accent="#F5B642">
        <div className="space-y-2.5">
          {RARITY_TIERS.map((tier) => {
            const count = tierCounts[tier.key] || 0;
            const pct = (count / maxTier) * 100;
            return (
              <div key={tier.key} className="flex items-center gap-3">
                <span className="text-[11px] font-semibold w-20 flex-shrink-0" style={{ color: tier.color }}>{tier.label}</span>
                <div className="flex-1 h-2.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.04)" }}>
                  <div className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pct}%`, background: tier.color, boxShadow: `0 0 10px ${tier.color}80` }} />
                </div>
                <span className="text-xs font-bold w-6 text-right" style={{ color: "rgba(255,255,255,0.6)" }}>{count}</span>
              </div>
            );
          })}
        </div>
        <div className="mt-3 pt-3 flex items-center gap-2" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <ShieldCheck className="w-3.5 h-3.5" style={{ color: "rgba(0,214,143,0.6)" }} />
          <span className="text-[10px]" style={{ color: "rgba(255,255,255,0.35)" }}>
            {eligibleScores.length} of {scores.length} scores Themis-cleared for leaderboard
          </span>
        </div>
      </Panel>

      {/* ── Recent scored findings ── */}
      <Panel title="Recent Scored Finds" icon={Sparkles} accent="#7AE7FF">
        {scores.length === 0 ? (
          <p className="text-xs py-4 text-center" style={{ color: "rgba(255,255,255,0.3)" }}>No scored findings yet.</p>
        ) : (
          <div className="space-y-2">
            {scores.slice(0, 5).map((s) => (
              <div key={s.id} className="flex items-center justify-between gap-2 py-1.5">
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold text-white truncate">
                    {s.mineral_name || "Specimen"} · RQS {Math.round(Number(s.rqs_score) || 0)}
                  </div>
                  <div className="text-[10px]" style={{ color: "rgba(255,255,255,0.3)" }}>
                    {formatDistanceToNow(new Date(s.created_date), { addSuffix: true })}
                    {s.integrity_status === "cleared" ? " · cleared" : s.integrity_status === "flagged" ? " · flagged" : ""}
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                  style={{
                    background: s.is_eligible_leaderboard ? "rgba(0,214,143,0.12)" : "rgba(255,255,255,0.05)",
                    color: s.is_eligible_leaderboard ? "#00D68F" : "rgba(255,255,255,0.4)",
                    border: `1px solid ${s.is_eligible_leaderboard ? "rgba(0,214,143,0.3)" : "rgba(255,255,255,0.08)"}`,
                  }}>
                  {s.is_eligible_leaderboard ? "Eligible" : "Pending"}
                </span>
              </div>
            ))}
          </div>
        )}
      </Panel>
    </div>
  );
}