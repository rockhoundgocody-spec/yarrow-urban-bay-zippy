/**
 * ConfidenceBadge
 * 
 * Displays a confidence score with color-coded tier indicator.
 * Adapts sizing for Field vs Desk mode.
 */

import React from "react";
import { useModeStore } from "@/lib/modeStore.jsx";
import { confidenceTierFromScore, confidenceTierColor } from "@/lib/apiTypes";

export default function ConfidenceBadge({ score, label, className = "" }) {
  const { isField } = useModeStore();
  // Normalize: accept both 0–1 floats and 0–100 integers.
  const normalized = score > 1 ? score / 100 : score;
  const tier = confidenceTierFromScore(normalized);
  const colors = confidenceTierColor(tier);
  const pct = Math.round(normalized * 100);

  return (
    <div
      className={`inline-flex items-center gap-2 font-semibold ${className}`}
      style={{
        background: colors.bg,
        border: `1px solid ${colors.border}`,
        color: colors.text,
        borderRadius: isField ? 14 : 10,
        padding: isField ? "8px 14px" : "4px 10px",
        fontSize: isField ? 14 : 12,
        minHeight: isField ? 40 : 28,
      }}
    >
      {/* Dot indicator */}
      <span
        className="rounded-full shrink-0"
        style={{
          width: isField ? 10 : 8,
          height: isField ? 10 : 8,
          background: colors.text,
          boxShadow: `0 0 8px ${colors.text}`,
        }}
      />
      <span>{pct}%</span>
      {label && <span className="opacity-70">{label}</span>}
    </div>
  );
}