/**
 * SiteIntelPanel
 * 
 * Displays full site intelligence: expected minerals, hazards, access, evidence.
 * Mode-aware: sparse/large in field mode, dense/expandable in desk mode.
 */

import React from "react";
import { useQuery } from "@tanstack/react-query";
import { useModeStore } from "@/lib/modeStore.jsx";
import { fetchSiteIntel, fetchSiteProspectivity } from "@/services/geoIntel";
import ConfidenceBadge from "./ConfidenceBadge";
import EvidenceFactorCard from "./EvidenceFactorCard";
import { Loader2, AlertTriangle, ShieldAlert, Gem, Mountain, Download } from "lucide-react";
import { hazardSeverityColor } from "@/lib/apiTypes";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function SiteIntelPanel({ siteId, onClose }) {
  const { mode, isField, isDesk } = useModeStore();

  const { data: intel, isLoading: loadingIntel, error: intelError } = useQuery({
    queryKey: ["site-intel", siteId],
    queryFn: () => fetchSiteIntel(siteId),
    enabled: !!siteId,
    staleTime: 5 * 60 * 1000,
    retry: 1,
  });

  const { data: prospectivity } = useQuery({
    queryKey: ["site-prospectivity", siteId],
    queryFn: () => fetchSiteProspectivity(siteId),
    enabled: !!siteId,
    staleTime: 5 * 60 * 1000,
  });

  const pad = isField ? "p-5" : "p-4";
  const gap = isField ? "space-y-5" : "space-y-3";
  const headingSize = isField ? "text-lg font-bold" : "text-sm font-semibold";
  const textSize = isField ? "text-base" : "text-sm";
  const radius = isField ? "rounded-2xl" : "rounded-xl";

  // Loading state
  if (loadingIntel) {
    return (
      <div className={`${radius} border border-white/10 bg-white/[0.02] ${pad} flex items-center justify-center`} style={{ minHeight: isField ? 200 : 120 }}>
        <Loader2 className="w-6 h-6 text-[#00f5ff] animate-spin" />
        <span className="ml-3 text-white/50 text-sm">Loading site intelligence...</span>
      </div>
    );
  }

  // Error state
  if (intelError || !intel) {
    return (
      <div className={`${radius} border border-red-500/20 bg-red-500/[0.05] ${pad} text-center`}>
        <AlertTriangle className="w-6 h-6 text-red-400 mx-auto mb-2" />
        <p className="text-red-400 text-sm font-medium">Unable to load site intelligence</p>
        <p className="text-white/30 text-xs mt-1">{intelError?.message || "Site data unavailable"}</p>
      </div>
    );
  }

  return (
    <div className={gap}>

      {/* ── Prospectivity Score ── */}
      {prospectivity && (
        <div className={`${radius} border border-white/10 bg-white/[0.02] ${pad}`}>
          <div className="flex items-center justify-between mb-3">
            <h3 className={`${headingSize} text-white flex items-center gap-2`}>
              <Mountain className="w-4 h-4 text-[#00f5ff]" />
              Prospectivity
            </h3>
            <ConfidenceBadge score={prospectivity.prospectivityScore} />
          </div>
          {isDesk && prospectivity.evidenceFactors?.length > 0 && (
            <div className="space-y-2 mt-3">
              {prospectivity.evidenceFactors.map((f, i) => (
                <EvidenceFactorCard key={i} factor={f} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Expected Minerals ── */}
      {intel.expectedMinerals?.length > 0 && (
        <div className={`${radius} border border-white/10 bg-white/[0.02] ${pad}`}>
          <h3 className={`${headingSize} text-white flex items-center gap-2 mb-3`}>
            <Gem className="w-4 h-4 text-[#a855f7]" />
            Expected Minerals
          </h3>
          <div className={isField ? "space-y-3" : "grid grid-cols-2 gap-2"}>
            {intel.expectedMinerals.slice(0, isField ? 5 : 10).map((m, i) => (
              <div
                key={i}
                className="flex items-center justify-between border border-white/8 bg-white/[0.02]"
                style={{
                  borderRadius: isField ? 12 : 8,
                  padding: isField ? "12px 14px" : "8px 10px",
                  minHeight: isField ? 52 : 36,
                }}
              >
                <div>
                  <span className={`font-semibold text-white ${isField ? "text-base" : "text-sm"}`}>{m.name}</span>
                  {isDesk && m.reason && (
                    <p className="text-white/30 text-[10px] mt-0.5 line-clamp-1">{m.reason}</p>
                  )}
                </div>
                <ConfidenceBadge score={m.confidence} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Access / Legality ── */}
      <div className={`${radius} border border-white/10 bg-white/[0.02] ${pad}`}>
        <h3 className={`${headingSize} text-white flex items-center gap-2 mb-3`}>
          <ShieldAlert className="w-4 h-4 text-[#ffaa00]" />
          Access & Legality
        </h3>
        <div className="flex items-center gap-3 mb-3">
          <ConfidenceBadge score={intel.access.collectingAllowedConfidence} label="allowed" />
          {intel.access.requiresManualReview && (
            <span className="text-xs text-[#ffaa00] font-medium px-2 py-1 rounded-lg bg-[#ffaa00]/10 border border-[#ffaa00]/30">
              Verify locally
            </span>
          )}
        </div>
        <p className={`text-white/50 ${textSize} leading-relaxed`}>{intel.access.summary}</p>
        <p className="text-white/25 text-[10px] mt-2">Sources: {intel.access.sourceCount} · Risk: {intel.access.risk}</p>
      </div>

      {/* ── Hazards ── */}
      {intel.hazards?.length > 0 && (
        <div className={`${radius} border border-red-500/15 bg-red-500/[0.03] ${pad}`}>
          <h3 className={`${headingSize} text-white flex items-center gap-2 mb-3`}>
            <AlertTriangle className="w-4 h-4 text-red-400" />
            Hazards
          </h3>
          <div className={isField ? "space-y-3" : "space-y-2"}>
            {intel.hazards.map((h, i) => {
              const colors = hazardSeverityColor(h.severity);
              return (
                <div
                  key={i}
                  className="flex items-start gap-3"
                  style={{
                    padding: isField ? "10px 12px" : "6px 8px",
                    borderRadius: isField ? 12 : 8,
                    background: colors.bg,
                    minHeight: isField ? 48 : 32,
                  }}
                >
                  <span className="shrink-0 mt-0.5 w-2 h-2 rounded-full" style={{ background: colors.text }} />
                  <div>
                    <span className="font-semibold" style={{ color: colors.text, fontSize: isField ? 14 : 12 }}>{h.label}</span>
                    {(isDesk || h.severity === "high") && (
                      <p className="text-white/40 text-[11px] mt-0.5">{h.summary}</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Evidence Summary ── */}
      {isDesk && intel.evidenceSummary?.length > 0 && (
        <div className={`${radius} border border-white/10 bg-white/[0.02] ${pad}`}>
          <h3 className={`${headingSize} text-white/70 mb-2`}>Evidence Summary</h3>
          <ul className="space-y-1.5">
            {intel.evidenceSummary.map((e, i) => (
              <li key={i} className="flex items-start gap-2 text-white/50 text-[12px]">
                <span className="text-[#00f5ff] mt-1 shrink-0">•</span>
                <span className="leading-relaxed">{e}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* ── Offline Pack CTA ── */}
      <Link
        to={createPageUrl("OfflineMap")}
        className={`flex items-center gap-3 ${radius} border border-[#00f5ff]/20 bg-[#00f5ff]/[0.04] transition-all hover:border-[#00f5ff]/40`}
        style={{
          padding: isField ? "16px 18px" : "10px 14px",
          minHeight: isField ? 56 : 44,
        }}
      >
        <Download className="w-5 h-5 text-[#00f5ff] shrink-0" />
        <div>
          <span className={`font-semibold text-[#00f5ff] ${isField ? "text-base" : "text-sm"}`}>Download for offline use</span>
          {isDesk && <p className="text-white/30 text-[10px] mt-0.5">Save this region before heading into the field</p>}
        </div>
      </Link>
    </div>
  );
}