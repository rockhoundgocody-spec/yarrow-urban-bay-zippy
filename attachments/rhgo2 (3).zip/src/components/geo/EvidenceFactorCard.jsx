/**
 * EvidenceFactorCard
 * 
 * Shows a single evidence factor with weight bar and optional explanation.
 * Compact in field mode, expandable in desk mode.
 */

import React from "react";
import { useModeStore } from "@/lib/modeStore.jsx";

export default function EvidenceFactorCard({ factor }) {
  const { isField, isDesk } = useModeStore();

  if (!factor) return null;

  const widthPct = Math.round(factor.weight * 100);

  return (
    <div
      className="border border-white/10 bg-white/[0.02]"
      style={{
        borderRadius: isField ? 14 : 10,
        padding: isField ? "14px 16px" : "10px 12px",
      }}
    >
      <div className="flex items-center justify-between mb-2">
        <span
          className="font-semibold text-white/80"
          style={{ fontSize: isField ? 14 : 12 }}
        >
          {factor.label}
        </span>
        <span
          className="font-bold text-[#00f5ff]"
          style={{ fontSize: isField ? 14 : 11 }}
        >
          {widthPct}%
        </span>
      </div>

      {/* Weight bar */}
      <div
        className="w-full rounded-full overflow-hidden"
        style={{
          height: isField ? 8 : 5,
          background: "rgba(255,255,255,0.06)",
        }}
      >
        <div
          className="h-full rounded-full transition-all duration-300"
          style={{
            width: `${widthPct}%`,
            background: "linear-gradient(90deg, #00f5ff, #8b00ff)",
            boxShadow: "0 0 8px rgba(0,245,255,0.4)",
          }}
        />
      </div>

      {/* Explanation — desk mode only */}
      {isDesk && factor.explanation && (
        <p className="text-white/40 text-[11px] mt-2 leading-relaxed">
          {factor.explanation}
        </p>
      )}
    </div>
  );
}