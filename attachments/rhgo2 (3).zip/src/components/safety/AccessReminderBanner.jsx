/**
 * AccessReminderBanner — Calm, actionable access & legality reminder
 * Shown when collecting, saving locations, or viewing predictive zones
 */
import React from 'react';
import { AlertCircle, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';

export default function AccessReminderBanner({ type = 'collecting', location = null, onDismiss }) {
  const configs = {
    collecting: {
      title: 'Verify Access Before Collecting',
      message: 'Confirm you have permission to collect at this location. Private land requires owner consent.',
      icon: MapPin,
      bgColor: 'rgba(122,231,255,0.08)',
      borderColor: 'rgba(122,231,255,0.2)',
      textColor: '#7AE7FF'
    },
    predictive: {
      title: 'Educational Prediction',
      message: 'This is an AI-inferred zone based on geological data. Always verify mineral presence and access status in the field.',
      icon: AlertCircle,
      bgColor: 'rgba(245,182,66,0.08)',
      borderColor: 'rgba(245,182,66,0.2)',
      textColor: '#F5B642'
    },
    offline: {
      title: 'Check Legal Status',
      message: 'When offline, you cannot verify current access restrictions. Assume private land requires permission.',
      icon: AlertCircle,
      bgColor: 'rgba(255,107,107,0.08)',
      borderColor: 'rgba(255,107,107,0.2)',
      textColor: '#FF6B6B'
    }
  };

  const config = configs[type] || configs.collecting;
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      className="rounded-xl p-3 flex items-start gap-3"
      style={{ background: config.bgColor, border: `1px solid ${config.borderColor}` }}>
      <Icon className="w-4 h-4 shrink-0 mt-0.5" style={{ color: config.textColor }} />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold" style={{ color: config.textColor }}>{config.title}</p>
        <p className="text-xs text-white/60 mt-0.5 leading-relaxed">{config.message}</p>
        {location && (
          <p className="text-[11px] text-white/40 mt-1 font-mono">{location}</p>
        )}
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="shrink-0 text-white/40 hover:text-white/70 transition-colors" aria-label="Dismiss">
          ✕
        </button>
      )}
    </motion.div>
  );
}