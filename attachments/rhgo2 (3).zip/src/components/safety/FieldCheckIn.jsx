/**
 * FieldCheckIn (4.3) — timed check-in: if you don't confirm you're back
 * by the deadline, you can (or the app prompts you to) notify your contact.
 */
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Timer, CheckCircle2, Send, Loader2 } from "lucide-react";

const KEY = "rh_field_checkin";

function load() {
  try { return JSON.parse(localStorage.getItem(KEY) || "null"); } catch { return null; }
}

export default function FieldCheckIn({ user }) {
  const [active, setActive] = useState(load);
  const [contact, setContact] = useState("");
  const [duration, setDuration] = useState(4);
  const [note, setNote] = useState("");
  const [now, setNow] = useState(Date.now());
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(t);
  }, []);

  const start = () => {
    if (!contact.trim()) return;
    const data = {
      contact: contact.trim(),
      note: note.trim(),
      due: Date.now() + duration * 3600 * 1000,
      started: Date.now(),
    };
    localStorage.setItem(KEY, JSON.stringify(data));
    setActive(data);
  };

  const cancel = () => {
    localStorage.removeItem(KEY);
    setActive(null);
    setSent(false);
  };

  const notifyContact = async () => {
    setSending(true);
    let locationLine = "Location unavailable.";
    try {
      const pos = await new Promise((res, rej) =>
        navigator.geolocation.getCurrentPosition(res, rej, { timeout: 6000 }));
      locationLine = `Last known location: https://maps.google.com/?q=${pos.coords.latitude},${pos.coords.longitude}`;
    } catch { /* keep fallback */ }
    await base44.integrations.Core.SendEmail({
      to: active.contact,
      subject: `Field check-in alert — ${user?.full_name || "a RockHound-GO user"}`,
      body: `${user?.full_name || "A RockHound-GO user"} started a field check-in and has not confirmed they are back safe.\n\nCheck-in started: ${new Date(active.started).toLocaleString()}\nExpected back by: ${new Date(active.due).toLocaleString()}\n${active.note ? `Trip note: ${active.note}\n` : ""}${locationLine}\n\nPlease try to reach them.`,
      from_name: "RockHound-GO Safety",
    });
    setSending(false);
    setSent(true);
  };

  const overdue = active && now > active.due;
  const remaining = active ? Math.max(0, active.due - now) : 0;
  const remainH = Math.floor(remaining / 3600000);
  const remainM = Math.floor((remaining % 3600000) / 60000);

  const inputStyle = { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" };

  if (active) {
    return (
      <div className="rounded-2xl p-4 space-y-3"
        style={{
          background: overdue ? "rgba(255,80,80,0.08)" : "rgba(0,214,143,0.06)",
          border: `1px solid ${overdue ? "rgba(255,80,80,0.35)" : "rgba(0,214,143,0.25)"}`,
        }}>
        <div className="flex items-center gap-2">
          <Timer className="w-4 h-4" style={{ color: overdue ? "#FF8080" : "#00D68F" }} />
          <p className="text-sm font-bold text-white">
            {overdue ? "Check-in overdue" : `Check-in active — ${remainH}h ${remainM}m left`}
          </p>
        </div>
        <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>
          Contact: {active.contact} · Expected back by {new Date(active.due).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
        </p>
        {sent && (
          <p className="text-xs font-semibold" style={{ color: "#00D68F" }}>✓ Your contact has been notified.</p>
        )}
        <div className="flex gap-2">
          <button onClick={cancel}
            className="flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2"
            style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.4)", color: "#00D68F" }}>
            <CheckCircle2 className="w-4 h-4" /> I'm back safe
          </button>
          {overdue && !sent && (
            <button onClick={notifyContact} disabled={sending}
              className="flex-1 py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-50"
              style={{ background: "rgba(255,80,80,0.15)", border: "1px solid rgba(255,80,80,0.4)", color: "#FF8080" }}>
              {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />} Notify contact
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4 space-y-3" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}>
      <div className="flex items-center gap-2">
        <Timer className="w-4 h-4" style={{ color: "#7AE7FF" }} />
        <p className="text-sm font-bold text-white">Field check-in</p>
      </div>
      <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
        Set a timer before heading out. If you don't check back in, you can alert your emergency contact with your last location.
      </p>
      <input value={contact} onChange={e => setContact(e.target.value)} type="email"
        placeholder="Emergency contact email"
        className="w-full rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/25 focus:outline-none" style={inputStyle} />
      <input value={note} onChange={e => setNote(e.target.value)}
        placeholder="Trip note (where you're going, optional)"
        className="w-full rounded-xl px-3 py-2.5 text-sm text-white placeholder-white/25 focus:outline-none" style={inputStyle} />
      <label className="text-xs block" style={{ color: "rgba(255,255,255,0.5)" }}>
        Expected back in: {duration}h
        <input type="range" min={1} max={12} value={duration} onChange={e => setDuration(Number(e.target.value))} className="w-full mt-1" />
      </label>
      <button onClick={start} disabled={!contact.trim()}
        className="w-full py-3 rounded-xl text-sm font-bold disabled:opacity-40"
        style={{ background: "rgba(122,231,255,0.12)", border: "1px solid rgba(122,231,255,0.35)", color: "#7AE7FF" }}>
        Start check-in timer
      </button>
    </div>
  );
}