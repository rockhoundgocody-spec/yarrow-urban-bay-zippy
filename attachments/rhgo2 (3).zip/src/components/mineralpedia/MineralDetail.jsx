import React, { useState } from 'react';
import { ArrowLeft, RotateCw } from 'lucide-react';

export default function MineralDetail({ mineral, onBack }) {
  const [rotation, setRotation] = useState(0);

  const handleRotate = () => {
    setRotation(r => (r + 45) % 360);
  };

  const colorMap = {
    purple: '#a855f7',
    clear: '#00f0ff',
    blue: '#00b4d8',
    black: '#00ff88',
    green: '#00ff88',
    red: '#ff006e',
  };

  return (
    <div>
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-[var(--neon-cyan)] mb-8 hover:text-[var(--neon-green)] transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to Minerals
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* 3D Model Section */}
        <div className="liquid-glass rounded-2xl p-8 border border-[var(--neon-cyan)]/40 flex flex-col items-center justify-center min-h-[500px]" style={{ boxShadow: 'var(--neon-cyan-glow)' }}>
          <div
            className="text-8xl mb-8 transition-transform duration-300"
            style={{ transform: `rotateY(${rotation}deg) rotateX(20deg)` }}
          >
            💎
          </div>
          <button
            onClick={handleRotate}
            className="flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-[var(--neon-cyan)] to-[var(--neon-green)] text-black font-bold hover:scale-110 transition-transform"
            style={{ boxShadow: 'var(--neon-cyan-glow)' }}
          >
            <RotateCw className="w-4 h-4" />
            Rotate Model
          </button>
        </div>

        {/* Info Section */}
        <div className="space-y-6">
          <div>
            <h1 className="text-5xl font-bold mb-2" style={{ background: 'linear-gradient(90deg, var(--neon-cyan), var(--neon-green))', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
              {mineral.name}
            </h1>
            <p className="text-[var(--neon-cyan)]/70">Crystalline Mineral Database Entry</p>
          </div>

          <div className="liquid-glass rounded-xl p-4 border border-[var(--neon-green)]/40 space-y-3">
            <div className="flex justify-between">
              <span className="text-[var(--neon-cyan)]/70">Hardness (Mohs)</span>
              <span className="font-bold text-[var(--neon-green)]">{mineral.hardness}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[var(--neon-cyan)]/70">Crystal System</span>
              <span className="font-bold text-[var(--neon-cyan)]">{mineral.system}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[var(--neon-cyan)]/70">Rarity Level</span>
              <span className="font-bold" style={{ color: mineral.rarity === 'Rare' ? 'var(--neon-green)' : 'var(--neon-cyan)' }}>
                {mineral.rarity}
              </span>
            </div>
          </div>

          <div className="liquid-glass rounded-xl p-4 border border-[var(--neon-cyan)]/40">
            <h3 className="font-bold text-[var(--neon-cyan)] mb-3">Geological Context</h3>
            <p className="text-[var(--neon-cyan)]/70 text-sm leading-relaxed">
              This mineral forms under specific geological conditions. It is commonly found in pegmatites, hydrothermal veins, and metamorphic rocks. The exact formation process influences its color, transparency, and crystalline structure.
            </p>
          </div>

          <button className="w-full py-3 rounded-lg bg-gradient-to-r from-[var(--neon-cyan)] to-[var(--neon-green)] text-black font-bold hover:scale-105 transition-transform" style={{ boxShadow: 'var(--neon-green-glow)' }}>
            View Your Finds
          </button>
        </div>
      </div>
    </div>
  );
}