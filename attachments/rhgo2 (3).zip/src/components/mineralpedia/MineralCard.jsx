import React from 'react';

export default function MineralCard({ mineral, onClick }) {
  const colorMap = {
    purple: '#a855f7',
    clear: '#00f0ff',
    blue: '#00b4d8',
    black: '#00ff88',
    green: '#00ff88',
    red: '#ff006e',
  };

  return (
    <div
      onClick={onClick}
      className="liquid-glass rounded-2xl p-6 border border-[var(--neon-cyan)]/40 cursor-pointer group hover:scale-105 transition-transform duration-300"
      style={{
        boxShadow: 'var(--neon-cyan-glow)',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = 'var(--neon-green-glow)';
        e.currentTarget.style.borderColor = 'rgba(0, 255, 136, 0.6)';
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = 'var(--neon-cyan-glow)';
        e.currentTarget.style.borderColor = 'rgba(0, 240, 255, 0.4)';
      }}
    >
      {/* 3D Model Placeholder */}
      <div className="w-full h-48 rounded-xl mb-4 flex items-center justify-center relative overflow-hidden" style={{ background: `linear-gradient(135deg, rgba(${parseInt(colorMap[mineral.color].slice(1,3), 16)}, ${parseInt(colorMap[mineral.color].slice(3,5), 16)}, ${parseInt(colorMap[mineral.color].slice(5,7), 16)}, 0.1) 0%, rgba(0, 255, 136, 0.05) 100%)` }}>
        <div className="text-6xl group-hover:animate-spin transition-transform" style={{ animationDuration: '3s' }}>
          💎
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--deep)] via-transparent to-transparent opacity-50"></div>
      </div>

      <h3 className="text-xl font-bold text-[var(--neon-cyan)] mb-2">{mineral.name}</h3>
      
      <div className="space-y-2 text-sm text-[var(--neon-cyan)]/70 mb-4">
        <p>⚒️ Hardness: {mineral.hardness}</p>
        <p>🔷 System: {mineral.system}</p>
        <p>✨ Rarity: <span style={{ color: mineral.rarity === 'Rare' ? 'var(--neon-green)' : mineral.rarity === 'Very Common' ? 'var(--neon-cyan)' : 'var(--neon-cyan)' }}>{mineral.rarity}</span></p>
      </div>

      <button className="w-full py-2 rounded-lg bg-gradient-to-r from-[var(--neon-cyan)]/20 to-[var(--neon-green)]/20 text-[var(--neon-cyan)] font-bold hover:from-[var(--neon-cyan)]/40 hover:to-[var(--neon-green)]/40 transition-all">
        View Details
      </button>
    </div>
  );
}