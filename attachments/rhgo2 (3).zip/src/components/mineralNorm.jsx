/**
 * Mineral normalization utility — frontend singleton.
 * Canonical source of truth for synonym → canonical name mapping.
 *
 * Usage:
 *   import { normalizeMineral, normalizeMineralList, resolveSearchTerm } from '@/components/mineralNorm';
 */

export const MINERAL_SYNONYMS = {
  'au':'Gold','gold':'Gold','native gold':'Gold',
  'ag':'Silver','silver':'Silver','native silver':'Silver',
  'cu':'Copper','copper':'Copper','native copper':'Copper',
  'pt':'Platinum','platinum':'Platinum',
  'diamond':'Diamond','graphite':'Graphite','coal':'Coal',
  'sulfur':'Sulfur','sulphur':'Sulfur',
  'pyrite':'Pyrite',"fool's gold":'Pyrite','fools gold':'Pyrite','iron pyrites':'Pyrite',
  'marcasite':'Marcasite',
  'chalcopyrite':'Chalcopyrite','copper pyrite':'Chalcopyrite',
  'bornite':'Bornite','peacock ore':'Bornite','peacock copper':'Bornite',
  'galena':'Galena','pb':'Lead','lead':'Lead',
  'sphalerite':'Sphalerite','zinc blende':'Sphalerite','zn':'Zinc','zinc':'Zinc',
  'molybdenite':'Molybdenite','mo':'Molybdenum','molybdenum':'Molybdenum','moly':'Molybdenum',
  'cinnabar':'Cinnabar','hg':'Mercury','mercury':'Mercury',
  'stibnite':'Stibnite','sb':'Antimony','antimony':'Antimony',
  'arsenopyrite':'Arsenopyrite','as':'Arsenic','arsenic':'Arsenic',
  'realgar':'Realgar','orpiment':'Orpiment',
  'cobaltite':'Cobaltite','co':'Cobalt','cobalt':'Cobalt',
  'ni':'Nickel','nickel':'Nickel','bi':'Bismuth','bismuth':'Bismuth',
  'proustite':'Proustite','ruby silver':'Proustite',
  'pyrargyrite':'Pyrargyrite','dark ruby silver':'Pyrargyrite',
  'tetrahedrite':'Tetrahedrite',
  // Oxides
  'hematite':'Hematite','kidney ore':'Hematite','specularite':'Hematite',
  'magnetite':'Magnetite','lodestone':'Magnetite',
  'limonite':'Limonite','goethite':'Goethite',
  'ilmenite':'Ilmenite','ti':'Titanium','titanium':'Titanium',
  'rutile':'Rutile','anatase':'Anatase',
  'chromite':'Chromite','cr':'Chromium','chromium':'Chromium',
  'pyrolusite':'Pyrolusite','mn':'Manganese','manganese':'Manganese',
  'corundum':'Corundum','al':'Aluminum','aluminum':'Aluminum','aluminium':'Aluminum',
  'ruby':'Ruby','sapphire':'Sapphire','blue sapphire':'Blue Sapphire',
  'star ruby':'Star Ruby','star sapphire':'Star Sapphire',
  'padparadscha':'Padparadscha','padparadschah':'Padparadscha',
  'yellow sapphire':'Yellow Sapphire','pukhraj':'Yellow Sapphire',
  'pink sapphire':'Pink Sapphire','white sapphire':'White Sapphire',
  'green sapphire':'Green Sapphire','orange sapphire':'Orange Sapphire',
  'spinel':'Spinel','alexandrite':'Alexandrite',
  "cat's eye":"Cat's Eye Chrysoberyl",'cats eye':"Cat's Eye Chrysoberyl",'cymophane':"Cat's Eye Chrysoberyl",
  'chrysoberyl':'Chrysoberyl',
  'cassiterite':'Cassiterite','sn':'Tin','tin':'Tin',
  'uraninite':'Uraninite','pitchblende':'Uraninite','u':'Uranium','uranium':'Uranium',
  // Quartz — macrocrystalline
  'quartz':'Quartz','sio2':'Quartz','silica':'Quartz','rock crystal':'Quartz',
  'milky quartz':'Milky Quartz',
  'amethyst':'Amethyst','violet quartz':'Amethyst','purple quartz':'Amethyst',
  'citrine':'Citrine','yellow quartz':'Citrine','false topaz':'Citrine',
  'smoky quartz':'Smoky Quartz','morion':'Smoky Quartz','cairngorm':'Smoky Quartz',
  'rose quartz':'Rose Quartz','pink quartz':'Rose Quartz',
  'rutilated quartz':'Rutilated Quartz','sagenite':'Rutilated Quartz',
  'ametrine':'Ametrine','trystine':'Ametrine','bolivianite':'Ametrine',
  'prasiolite':'Prasiolite','green amethyst':'Prasiolite','vermarine':'Prasiolite',
  'aventurine':'Aventurine',
  // Chalcedony — explicitly requested varieties
  'chalcedony':'Chalcedony',
  'carnelian':'Carnelian','cornelian':'Carnelian','corneline':'Carnelian',
  'sard':'Sard','sardius':'Sard','sarda':'Sard',
  'sardonyx':'Sardonyx',
  'onyx':'Onyx','black onyx':'Black Onyx',
  'chrysoprase':'Chrysoprase','chrysophrase':'Chrysoprase','apple green chalcedony':'Chrysoprase',
  'prase':'Prase',
  'bloodstone':'Bloodstone','heliotrope':'Bloodstone','blood jasper':'Bloodstone',
  'blue chalcedony':'Blue Chalcedony','purple chalcedony':'Purple Chalcedony',
  // Agate varieties
  'agate':'Agate','moss agate':'Moss Agate','mocha stone':'Moss Agate',
  'fire agate':'Fire Agate',
  'blue lace agate':'Blue Lace Agate','blue agate':'Blue Lace Agate','blue lace':'Blue Lace Agate',
  'plume agate':'Plume Agate','thunder egg':'Thunder Egg','thunderegg':'Thunder Egg',
  'turritella agate':'Turritella Agate','crazy lace agate':'Crazy Lace Agate',
  'lake superior agate':'Lake Superior Agate','fairburn agate':'Fairburn Agate',
  'dryhead agate':'Dryhead Agate','eye agate':'Eye Agate','bullseye agate':'Eye Agate',
  'snakeskin agate':'Snakeskin Agate','sagenitic agate':'Sagenitic Agate',
  // Jasper varieties
  'jasper':'Jasper','red jasper':'Red Jasper','yellow jasper':'Yellow Jasper',
  'picture jasper':'Picture Jasper',
  'orbicular jasper':'Orbicular Jasper','ocean jasper':'Ocean Jasper',
  'poppy jasper':'Poppy Jasper',
  'leopardskin jasper':'Leopardskin Jasper','leopard skin jasper':'Leopardskin Jasper',
  'mookaite':'Mookaite Jasper','mookite':'Mookaite Jasper','mookalite':'Mookaite Jasper',
  'kambaba jasper':'Kambaba Jasper','crocodile jasper':'Kambaba Jasper',
  'dalmatian jasper':'Dalmatian Jasper','dalmatian stone':'Dalmatian Jasper',
  // Chert/flint
  'chert':'Chert','flint':'Flint','hornstone':'Chert',
  // Opal varieties
  'opal':'Opal','fire opal':'Fire Opal','mexican fire opal':'Fire Opal',
  'precious opal':'Precious Opal','black opal':'Black Opal','dark opal':'Black Opal',
  'white opal':'White Opal','milky opal':'White Opal',
  'crystal opal':'Crystal Opal','boulder opal':'Boulder Opal',
  'ethiopian opal':'Ethiopian Opal','welo opal':'Ethiopian Opal',
  'peruvian opal':'Peruvian Opal','andean opal':'Peruvian Opal',
  'hyalite':'Hyalite','water opal':'Hyalite',
  // Obsidian varieties
  'obsidian':'Obsidian','rainbow obsidian':'Rainbow Obsidian','sheen obsidian':'Rainbow Obsidian',
  'snowflake obsidian':'Snowflake Obsidian','mahogany obsidian':'Mahogany Obsidian',
  'apache tears':'Apache Tears',
  'petrified wood':'Petrified Wood','silicified wood':'Petrified Wood',
  // Carbonates
  'calcite':'Calcite','caco3':'Calcite','limestone':'Limestone','marble':'Marble',
  'iceland spar':'Iceland Spar','optical calcite':'Iceland Spar',
  'dogtooth calcite':'Dogtooth Calcite',
  'mangano calcite':'Manganocalcite','manganocalcite':'Manganocalcite','pink calcite':'Manganocalcite',
  'cobaltocalcite':'Cobaltocalcite','cobaltian calcite':'Cobaltocalcite',
  'dolomite':'Dolomite','aragonite':'Aragonite','siderite':'Siderite',
  'rhodochrosite':'Rhodochrosite','rosinca':'Rhodochrosite',
  'smithsonite':'Smithsonite','azurite':'Azurite',
  'malachite':'Malachite','cerussite':'Cerussite','magnesite':'Magnesite',
  // Sulfates
  'gypsum':'Gypsum','selenite':'Selenite','satin spar':'Satin Spar','alabaster':'Alabaster',
  'desert rose':'Desert Rose',
  'barite':'Barite','baryte':'Barite','ba':'Barium','barium':'Barium',
  'celestite':'Celestite','celestine':'Celestite','sr':'Strontium','strontium':'Strontium',
  'anglesite':'Anglesite','chalcanthite':'Chalcanthite',
  // Phosphates
  'apatite':'Apatite','turquoise':'Turquoise','callais':'Turquoise',
  'variscite':'Variscite','chrysocolla':'Chrysocolla',
  'vanadinite':'Vanadinite','v':'Vanadium','vanadium':'Vanadium',
  'wulfenite':'Wulfenite','pyromorphite':'Pyromorphite',
  'crocoite':'Crocoite','red lead ore':'Crocoite',
  // Tungstates
  'scheelite':'Scheelite','wolframite':'Wolframite','w':'Tungsten','tungsten':'Tungsten',
  // Halides
  'halite':'Halite','rock salt':'Halite','salt':'Halite',
  'fluorite':'Fluorite','fluorspar':'Fluorite','blue john':'Blue John Fluorite',
  // Beryl varieties
  'beryl':'Beryl','be':'Beryllium','beryllium':'Beryllium',
  'emerald':'Emerald','green beryl':'Emerald',
  'aquamarine':'Aquamarine','blue beryl':'Aquamarine',
  'morganite':'Morganite','pink beryl':'Morganite','rose beryl':'Morganite',
  'heliodor':'Heliodor','golden beryl':'Heliodor','yellow beryl':'Heliodor',
  'goshenite':'Goshenite','white beryl':'Goshenite',
  'red beryl':'Red Beryl','bixbite':'Red Beryl','scarlet emerald':'Red Beryl',
  // Tourmaline varieties
  'tourmaline':'Tourmaline',
  'schorl':'Schorl','black tourmaline':'Schorl',
  'rubellite':'Rubellite','red tourmaline':'Rubellite','pink tourmaline':'Rubellite',
  'indicolite':'Indicolite','blue tourmaline':'Indicolite','indigolite':'Indicolite',
  'verdelite':'Verdelite','green tourmaline':'Verdelite',
  'paraiba tourmaline':'Paraíba Tourmaline','paraiba':'Paraíba Tourmaline',
  'watermelon tourmaline':'Watermelon Tourmaline','dravite':'Dravite',
  // Garnet varieties
  'garnet':'Garnet',
  'almandine':'Almandine Garnet','almandite':'Almandine Garnet','carbuncle':'Almandine Garnet',
  'pyrope':'Pyrope Garnet','arizona ruby':'Pyrope Garnet',
  'rhodolite':'Rhodolite Garnet',
  'spessartine':'Spessartine Garnet','spessartite':'Spessartine Garnet','mandarin garnet':'Spessartine Garnet',
  'grossular':'Grossular Garnet','grossularite':'Grossular Garnet',
  'hessonite':'Hessonite Garnet','cinnamon stone':'Hessonite Garnet',
  'tsavorite':'Tsavorite Garnet','tsavolite':'Tsavorite Garnet',
  'uvarovite':'Uvarovite Garnet','andradite':'Andradite Garnet',
  'demantoid':'Demantoid Garnet',
  'malaya garnet':'Malaya Garnet','mali garnet':'Mali Garnet',
  'color change garnet':'Color Change Garnet',
  // Feldspar varieties
  'feldspar':'Feldspar','orthoclase':'Orthoclase',
  'moonstone':'Moonstone','rainbow moonstone':'Rainbow Moonstone',
  'sunstone':'Sunstone','heliolite':'Sunstone',
  'labradorite':'Labradorite','spectrolite':'Labradorite',
  'amazonite':'Amazonite','amazon stone':'Amazonite',
  'plagioclase':'Plagioclase','albite':'Albite',
  'oligoclase':'Oligoclase','andesine':'Andesine',
  // Pyroxene / Jade
  'jadeite':'Jadeite','nephrite':'Nephrite','jade':'Jade',
  'spodumene':'Spodumene','li':'Lithium','lithium':'Lithium',
  'kunzite':'Kunzite','pink spodumene':'Kunzite',
  'hiddenite':'Hiddenite','green spodumene':'Hiddenite',
  'diopside':'Diopside','chrome diopside':'Chrome Diopside',
  // Amphibole
  'actinolite':'Actinolite','tremolite':'Tremolite','hornblende':'Hornblende',
  "tiger's eye":"Tiger's Eye",'tigers eye':"Tiger's Eye",
  "hawk's eye":"Hawk's Eye",'hawks eye':"Hawk's Eye",'blue tigers eye':"Hawk's Eye",
  'pietersite':'Pietersite','tempest stone':'Pietersite',
  // Mica
  'mica':'Mica','muscovite':'Muscovite','biotite':'Biotite',
  'phlogopite':'Phlogopite','lepidolite':'Lepidolite',
  'fuchsite':'Fuchsite','green mica':'Fuchsite',
  'chlorite':'Chlorite','talc':'Talc','soapstone':'Soapstone','steatite':'Steatite',
  'serpentine':'Serpentine','bowenite':'Bowenite','new jade':'Bowenite',
  // Nesosilicates
  'olivine':'Olivine','peridot':'Peridot','chrysolite':'Peridot',
  'topaz':'Topaz','imperial topaz':'Imperial Topaz',
  'blue topaz':'Blue Topaz','white topaz':'White Topaz',
  'zircon':'Zircon','kyanite':'Kyanite','disthene':'Kyanite',
  'sillimanite':'Sillimanite','fibrolite':'Sillimanite',
  'andalusite':'Andalusite','staurolite':'Staurolite','fairy cross':'Staurolite',
  'titanite':'Titanite','sphene':'Titanite',
  'rhodonite':'Rhodonite','danburite':'Danburite','axinite':'Axinite',
  'scapolite':'Scapolite','wernerite':'Scapolite',
  // Cyclosilicates
  'iolite':'Iolite','cordierite':'Cordierite','water sapphire':'Iolite','dichroite':'Iolite',
  'vesuvianite':'Vesuvianite','idocrase':'Vesuvianite',
  'dioptase':'Dioptase',
  // Sorosilicates
  'epidote':'Epidote','zoisite':'Zoisite',
  'tanzanite':'Tanzanite','blue zoisite':'Tanzanite',
  'thulite':'Thulite','pink zoisite':'Thulite',
  'prehnite':'Prehnite','apophyllite':'Apophyllite',
  'stilbite':'Stilbite','heulandite':'Heulandite','zeolite':'Zeolite',
  // Feldspathoids
  'sodalite':'Sodalite',
  'lazurite':'Lapis Lazuli','lapis lazuli':'Lapis Lazuli','lapis':'Lapis Lazuli',
  // Rare
  'benitoite':'Benitoite','shattuckite':'Shattuckite','cavansite':'Cavansite',
  // Fossils
  'fossils':'Fossils','fossil':'Fossils',
  'ammonite':'Ammonite','ammonites':'Ammonite',
  'trilobite':'Trilobite','trilobites':'Trilobite',
  'shark teeth':'Shark Teeth','shark tooth':'Shark Teeth',
  'megalodon':'Megalodon Tooth',
  'crinoid':'Crinoid','sea lily':'Crinoid',
  'dinosaur bone':'Dinosaur Bone',
  // Rocks
  'granite':'Granite','basalt':'Basalt','pumice':'Pumice',
  'rhyolite':'Rhyolite','sandstone':'Sandstone','slate':'Slate',
  'schist':'Schist','gneiss':'Gneiss','quartzite':'Quartzite',
  'pegmatite':'Pegmatite',
};

/**
 * Normalize a raw mineral string to its canonical display name.
 */
export function normalizeMineral(raw) {
  if (!raw || typeof raw !== 'string') return '';
  const key = raw.toLowerCase().trim();
  if (MINERAL_SYNONYMS[key]) return MINERAL_SYNONYMS[key];
  const firstWord = key.split(/[\s,_()\-/]/)[0];
  if (firstWord && MINERAL_SYNONYMS[firstWord]) return MINERAL_SYNONYMS[firstWord];
  const varMatch = key.match(/var\.?\s+(.+)$/);
  if (varMatch && MINERAL_SYNONYMS[varMatch[1].trim()]) return MINERAL_SYNONYMS[varMatch[1].trim()];
  return raw.trim().replace(/\w\S*/g, w => w[0].toUpperCase() + w.slice(1).toLowerCase());
}

/**
 * Returns a stable lowercase underscore ID for a canonical mineral name.
 * e.g. "Almandine Garnet" → "almandine_garnet"
 */
export function getMineralId(canonical) {
  return canonical
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_|_$/g, '');
}

/**
 * Normalize and deduplicate an array of mineral names.
 */
export function normalizeMineralList(minerals) {
  if (!Array.isArray(minerals)) return [];
  return [...new Set(minerals.map(normalizeMineral).filter(Boolean))];
}

/**
 * Resolve a search query to canonical name + ID + all known synonyms.
 * Use this for mineral-based search/filter to ensure consistent results.
 */
export function resolveSearchTerm(query) {
  if (!query) return { canonical: '', id: '', synonyms: [] };
  const canonical = normalizeMineral(query);
  const id = getMineralId(canonical);
  const synonyms = Object.entries(MINERAL_SYNONYMS)
    .filter(([, v]) => v === canonical)
    .map(([k]) => k);
  return { canonical, id, synonyms };
}