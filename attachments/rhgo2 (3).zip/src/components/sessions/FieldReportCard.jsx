/**
 * FieldReportCard — generates and displays an AI field report for a session.
 * Drop-in for any session detail view or session replay page.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  FileText, Sparkles, Loader2, Share2, Star, Copy, CheckCircle2,
  ChevronDown, ChevronUp
} from "lucide-react";

function StarRating({ rating }) {
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(i => (
        <Star key={i} className="w-3.5 h-3.5"
          fill={i <= rating ? "#d4af37" : "transparent"}
          style={{ color: i <= rating ? "#d4af37" : "rgba(255,255,255,0.2)" }} />
      ))}
    </div>
  );
}

export default function FieldReportCard({ session }) {
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const [copied, setCopied] = useState(false);

  const generate = async () => {
    setLoading(true);
    try {
      const res = await base44.functions.invoke("generateFieldReport", { session_id: session.id });
      setReport(res.data);
    } catch {
      setReport({
        headline: `Field session at ${session.location_name || "the site"}`,
        summary: `A productive field session with ${session.specimen_names?.length || 0} specimens collected over ${session.duration_minutes ? Math.round(session.duration_minutes / 60) + " hours" : "the day"}.`,
        highlights: session.specimen_names?.slice(0, 3).map(s => `Found ${s}`) || ["Completed field session"],
        collectability_rating: 3,
        shareable_caption: `Great day in the field! Found some amazing specimens. #rockhounding #minerals #geology`,
      });
    }
    setLoading(false);
  };

  const copyCaption = () => {
    if (report?.shareable_caption) {
      navigator.clipboard.writeText(report.shareable_caption);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const share = () => {
    if (!report) return;
    navigator.share?.({
      title: report.headline,
      text: report.shareable_caption,
    });
  };

  if (!report && !loading) {
    return (
      <button onClick={generate}
        className="w-full flex items-center gap-2 py-3 px-4 rounded-xl text-xs font-medium transition-all"
        style={{ background: "rgba(141,124,255,0.08)", color: "#8D7CFF", border: "1px solid rgba(141,124,255,0.2)" }}>
        <Sparkles className="w-4 h-4" />
        Generate AI Field Report
      </button>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center gap-2 py-6 text-xs text-white/40">
        <Loader2 className="w-4 h-4 animate-spin text-[#8D7CFF]" />
        Writing your field report...
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="rounded-2xl border border-[#8D7CFF]/25 overflow-hidden"
      style={{ background: "linear-gradient(135deg, rgba(141,124,255,0.06), rgba(10,15,20,0.9))" }}
    >
      {/* Header */}
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#8D7CFF]" />
            <span className="text-xs font-semibold text-[#8D7CFF] uppercase tracking-wide">AI Field Report</span>
          </div>
          <div className="flex items-center gap-1.5">
            <button onClick={share} className="p-1.5 rounded-lg text-white/25 hover:text-white/50 transition-colors" aria-label="Share" title="Share">
              <Share2 className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setExpanded(!expanded)} className="p-1.5 rounded-lg text-white/25">
              {expanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
          </div>
        </div>

        <h3 className="text-base font-bold text-white">{report.headline}</h3>

        {report.collectability_rating && (
          <div className="flex items-center gap-2 mt-1.5">
            <StarRating rating={report.collectability_rating} />
            <span className="text-xs text-white/30">collectability</span>
          </div>
        )}
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-4 border-t border-white/5 pt-4">
              {/* Summary */}
              <p className="text-xs text-white/55 leading-relaxed">{report.summary}</p>

              {/* Highlights */}
              {report.highlights?.length > 0 && (
                <div className="space-y-1.5">
                  {report.highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-white/50">
                      <span className="text-[#00D68F] mt-0.5 shrink-0">•</span>{h}
                    </div>
                  ))}
                </div>
              )}

              {/* Difficulty */}
              {report.difficulty_verdict && (
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                  <p className="text-[10px] font-semibold text-white/30 mb-0.5">TERRAIN</p>
                  <p className="text-xs text-white/50">{report.difficulty_verdict}</p>
                </div>
              )}

              {/* Field tips */}
              {report.field_tips && (
                <div className="p-3 rounded-xl border border-[#F5B642]/15"
                  style={{ background: "rgba(245,182,66,0.04)" }}>
                  <p className="text-[10px] font-semibold text-[#F5B642]/60 mb-0.5">PRO TIP</p>
                  <p className="text-xs text-white/50">{report.field_tips}</p>
                </div>
              )}

              {/* Shareable caption */}
              {report.shareable_caption && (
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/5">
                  <div className="flex items-center justify-between mb-1.5">
                    <p className="text-[10px] font-semibold text-white/30">SHAREABLE CAPTION</p>
                    <button onClick={copyCaption}
                      className="flex items-center gap-1 text-[10px] transition-colors"
                      style={{ color: copied ? "#00D68F" : "rgba(255,255,255,0.25)" }}>
                      {copied ? <CheckCircle2 className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {copied ? "Copied!" : "Copy"}
                    </button>
                  </div>
                  <p className="text-xs text-white/50 italic">{report.shareable_caption}</p>
                </div>
              )}

              <button onClick={generate}
                className="text-[10px] text-white/20 hover:text-white/40 transition-colors">
                ↻ Regenerate
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}