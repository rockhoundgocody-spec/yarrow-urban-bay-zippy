import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { MapPin, ArrowRight, Gem } from "lucide-react";

export default function NearbyActivity({ locations = [] }) {
  const nearby = locations.slice(0, 5);

  if (nearby.length === 0) {
    return (
      <div className="rounded-2xl border border-white/8 bg-white/3 p-6 text-center">
        <MapPin className="w-8 h-8 text-white/15 mx-auto mb-2" />
        <p className="text-white/30 text-sm">No nearby sites loaded yet.</p>
        <Link to={createPageUrl("RockhoundingMap")} className="text-[var(--quantum-cyan)] text-xs mt-2 inline-block">
          Open Map →
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {nearby.map((loc) => (
        <Link
          key={loc.id}
          to={`${createPageUrl("RockhoundingMap")}?site=${loc.id}`}
          className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/3 px-4 py-3 hover:border-white/15 transition-all"
        >
          <div className="w-8 h-8 rounded-lg bg-[var(--quantum-cyan)]/10 flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4 text-[var(--quantum-cyan)]" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white/90 font-medium truncate">{loc.name}</p>
            <p className="text-[10px] text-white/40">{loc.state}{loc.county ? `, ${loc.county}` : ""}</p>
          </div>
          {loc.minerals_found?.length > 0 && (
            <div className="flex items-center gap-1 text-[10px] text-amber-400/70 shrink-0">
              <Gem className="w-3 h-3" />
              {loc.minerals_found.length}
            </div>
          )}
          <ArrowRight className="w-3.5 h-3.5 text-white/20 shrink-0" />
        </Link>
      ))}
    </div>
  );
}