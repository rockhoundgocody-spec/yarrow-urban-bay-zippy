/**
 * FeaturedLocationsCarousel — horizontal scroll of curated rockhounding locations.
 * Links each card to /Explore (map view).
 */
import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { MapPin, ChevronRight, Star } from "lucide-react";
import { motion } from "framer-motion";

const FALLBACK_LOCATIONS = [
  { id: "1", name: "Crystal Cave, AZ", locality_type: "quarry", yield_score: 88, specimen_types: ["Quartz", "Amethyst"] },
  { id: "2", name: "Devil's Backbone, CO", locality_type: "road_cut", yield_score: 75, specimen_types: ["Pyrite", "Galena"] },
  { id: "3", name: "Sunstone Butte, OR", locality_type: "hillside", yield_score: 92, specimen_types: ["Sunstone", "Feldspar"] },
];

const BG_COLORS = [
  "linear-gradient(135deg, rgba(0,214,143,0.15), rgba(0,214,143,0.05))",
  "linear-gradient(135deg, rgba(141,124,255,0.15), rgba(141,124,255,0.05))",
  "linear-gradient(135deg, rgba(245,182,66,0.15), rgba(245,182,66,0.05))",
  "linear-gradient(135deg, rgba(122,231,255,0.15), rgba(122,231,255,0.05))",
];
const ACCENT_COLORS = ["#00D68F", "#8D7CFF", "#F5B642", "#7AE7FF"];

export default function FeaturedLocationsCarousel() {
  const { data: locations = FALLBACK_LOCATIONS, isLoading } = useQuery({
    queryKey: ["featured-locations"],
    queryFn: () => base44.entities.RockhoundingLocation.list("-yield_score", 8),
    staleTime: 5 * 60 * 1000,
  });

  const items = locations.length > 0 ? locations : FALLBACK_LOCATIONS;

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "rgba(255,255,255,0.35)" }}>
          Featured Locations
        </p>
        <Link to="/Explore" className="flex items-center gap-0.5 text-[10px] font-semibold" style={{ color: "#00D68F" }}>
          View all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1" style={{ scrollbarWidth: "none" }}>
        {isLoading
          ? Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="flex-shrink-0 w-44 h-28 rounded-2xl animate-pulse"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }} />
            ))
          : items.map((loc, i) => {
              const accent = ACCENT_COLORS[i % ACCENT_COLORS.length];
              const bg = BG_COLORS[i % BG_COLORS.length];
              const minerals = Array.isArray(loc.specimen_types) ? loc.specimen_types.slice(0, 2) : [];
              return (
                <Link key={loc.id || i} to={`/Explore`}>
                  <motion.div
                    className="flex-shrink-0 w-44 rounded-2xl p-3.5 cursor-pointer"
                    style={{ background: bg, border: `1px solid ${accent}25`, minHeight: 112 }}
                    whileHover={{ y: -2, borderColor: `${accent}45` }}
                    whileTap={{ scale: 0.97 }}
                    initial={{ opacity: 0, x: 12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <MapPin className="w-3.5 h-3.5" style={{ color: accent }} />
                      {loc.yield_score > 0 && (
                        <div className="flex items-center gap-0.5">
                          <Star className="w-2.5 h-2.5" style={{ color: accent }} />
                          <span className="text-[9px] font-bold" style={{ color: accent }}>{loc.yield_score}</span>
                        </div>
                      )}
                    </div>
                    <p className="text-xs font-bold leading-snug text-white/90 mb-1.5">{loc.name || loc.label}</p>
                    <div className="flex flex-wrap gap-1">
                      {minerals.map((m) => (
                        <span key={m} className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold"
                          style={{ background: `${accent}15`, color: `${accent}cc`, border: `1px solid ${accent}20` }}>
                          {m}
                        </span>
                      ))}
                      {loc.locality_type && (
                        <span className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold capitalize"
                          style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.35)" }}>
                          {loc.locality_type.replace(/_/g, " ")}
                        </span>
                      )}
                    </div>
                  </motion.div>
                </Link>
              );
            })}
      </div>
    </div>
  );
}