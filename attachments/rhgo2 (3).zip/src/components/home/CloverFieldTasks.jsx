/**
 * CloverFieldTasks — stub component to satisfy dynamic imports.
 * This file prevents "error loading dynamically imported module" errors.
 */

export default function CloverFieldTasks({ userEmail }) {
  return null;
}