/**
 * GreatnessMissionBlock — Mission identity and platform pillar overview.
 * Frames RockHound-GO as the operating system for modern rockhounding.
 */
import React from 'react';
import { motion } from 'framer-motion';

export default function GreatnessMissionBlock() {
  return (
    <motion.div
      className="rounded-2xl p-5 mb-6"
      style={{
        background: 'linear-gradient(135deg, rgba(141,124,255,0.12) 0%, rgba(122,231,255,0.06) 100%)',
        border: '1px solid rgba(141,124,255,0.25)',
        boxShadow: '0 0 32px rgba(141,124,255,0.08)',
      }}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* Mission headline */}
      <div className="mb-4">
        <p className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: 'rgba(141,124,255,0.6)' }}>
          The Operating System for Modern Rockhounding
        </p>
        <h2 className="text-lg font-bold leading-tight text-white">
          Disciplined Discovery. <br /> Real Mastery.
        </h2>
      </div>

      {/* Mission description */}
      <p className="text-sm leading-relaxed mb-4" style={{ color: 'rgba(255,255,255,0.65)' }}>
        RockHound-GO integrates every tool modern collectors and explorers need. Scan and identify specimens with AI. Document GPS context and provenance. Access peer-reviewed mineral science. Build your reputation through community. Trade and establish lasting value.
      </p>

      {/* Pillars */}
      <div className="grid grid-cols-2 gap-2 text-[11px]">
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#00D68F' }}>Field Discovery</span> – Map, locate, explore
        </div>
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#7AE7FF' }}>AI Identification</span> – Scan & learn instantly
        </div>
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#F5B642' }}>Collection Intelligence</span> – Organize & value
        </div>
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#8D7CFF' }}>Education</span> – Master the science
        </div>
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#88C99A' }}>Community</span> – Connect & grow
        </div>
        <div style={{ color: 'rgba(255,255,255,0.5)' }}>
          <span className="font-semibold" style={{ color: '#FF8844' }}>Commerce</span> – Trade & build legacy
        </div>
      </div>
    </motion.div>
  );
}