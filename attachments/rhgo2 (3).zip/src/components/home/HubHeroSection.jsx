/**
 * HubHeroSection — Glassmorphism premium hero for ROCKHOUND-GO
 */
import React from 'react';
import { motion } from 'framer-motion';
import { Gem } from 'lucide-react';

export default function HubHeroSection() {
  return (
    <motion.div
      className="relative z-10 mb-6 overflow-hidden rounded-3xl"
      style={{
        background: "linear-gradient(145deg, rgba(14,10,30,0.78) 0%, rgba(10,8,22,0.70) 100%)",
        backdropFilter: "blur(28px)",
        WebkitBackdropFilter: "blur(28px)",
        border: "1px solid rgba(141,124,255,0.22)",
        boxShadow: "0 8px 40px rgba(0,0,0,0.6), 0 0 30px rgba(141,124,255,0.07), inset 0 1px 0 rgba(255,255,255,0.07)",
        padding: "22px 20px 20px",
      }}
      initial={{ opacity: 0, y: -6 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Specular top-edge highlight */}
      <div className="absolute top-0 left-0 right-0 h-px" style={{
        background: "linear-gradient(90deg, transparent, rgba(141,124,255,0.55) 35%, rgba(122,231,255,0.40) 65%, transparent)",
      }} />

      {/* Ambient crystal shimmer sweep */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "linear-gradient(105deg, transparent 25%, rgba(255,255,255,0.025) 50%, transparent 75%)",
        }}
        animate={{ x: ["-120%", "220%"] }}
        transition={{ duration: 6, repeat: Infinity, repeatDelay: 10, ease: "easeInOut" }}
      />

      <div className="relative z-10">
        {/* Icon + Badge row */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-2xl flex items-center justify-center flex-shrink-0" style={{
            background: "linear-gradient(135deg, rgba(141,124,255,0.22), rgba(80,50,200,0.12))",
            border: "1px solid rgba(141,124,255,0.38)",
            boxShadow: "0 0 16px rgba(141,124,255,0.22)",
          }}>
            <Gem className="w-4 h-4" style={{ color: "#C4B5FD" }} />
          </div>
          <motion.div
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full"
            style={{
              background: "rgba(141,124,255,0.10)",
              border: "1px solid rgba(141,124,255,0.28)",
            }}
          >
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: "#8D7CFF", boxShadow: "0 0 6px rgba(141,124,255,0.9)" }} />
            <span style={{ fontSize: 9.5, fontWeight: 700, color: "#A89BFF", letterSpacing: "0.1em", textTransform: "uppercase" }}>
              Geological Intelligence Platform
            </span>
          </motion.div>
        </div>

        {/* Title */}
        <h1
          className="text-2xl font-black tracking-tight leading-tight mb-2"
          style={{
            background: 'linear-gradient(120deg, #FFFFFF 0%, #C4B5FD 40%, #7AE7FF 80%)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          The operating system
          <br />
          for modern rockhounding
        </h1>

        <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,255,255,0.50)' }}>
          AI identification · field mapping · collection management · market intelligence — unified.
        </p>
      </div>
    </motion.div>
  );
}