/**
 * StatusProgressionModule — rank, progress bar, and key stats.
 * Clean data density. No decorative noise.
 */
import React, { memo, useMemo, useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { Trophy, Star, Gem } from "lucide-react";

const RANK_TIERS = [
  { min: 0,   label: "Prospector",   color: "#9ca3af" },
  { min: 5,   label: "Scout",        color: "#4ade80" },
  { min: 15,  label: "Field Agent",  color: "#60a5fa" },
  { min: 30,  label: "Surveyor",     color: "#c084fc" },
  { min: 60,  label: "Geologist",    color: "#f59e0b" },
  { min: 100, label: "Expeditioner", color: "#f43f5e" },
];

function getRank(count) {
  let rank = RANK_TIERS[0];
  for (const t of RANK_TIERS) { if (count >= t.min) rank = t; }
  return rank;
}

function StatusProgressionModule({ userEmail }) {
  const [data, setData] = useState({ specimens: [], badges: [] });

  useEffect(() => {
    if (!userEmail) return;
    Promise.all([
      base44.entities.Specimen.filter({ created_by: userEmail }, "-created_date", 200),
      base44.entities.UserBadge.filter({ created_by: userEmail }, "-earned_at"),
    ])
      .then(([specimens, badges]) => setData({ specimens, badges }))
      .catch(() => {});
  }, [userEmail]);

  const { specimens, badges } = data;

  const count    = specimens.length;
  const rank     = useMemo(() => getRank(count), [count]);
  const rareCount  = useMemo(() => specimens.filter((s) => (s.confidence || 0) >= 80).length, [specimens]);
  const totalValue = useMemo(() => specimens.reduce((s, x) => s + (x.valuation_estimated || 0), 0), [specimens]);

  const nextTierIdx = useMemo(() => RANK_TIERS.findIndex((t) => t.label === rank.label) + 1, [rank]);
  const nextTier    = RANK_TIERS[nextTierIdx] || null;
  const progressPct = useMemo(() => nextTier
    ? Math.min(100, Math.round(((count - rank.min) / (nextTier.min - rank.min)) * 100))
    : 100, [nextTier, count, rank]);

  return (
    <div className="rounded-2xl p-4"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>

      {/* Rank row */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: `${rank.color}15`, border: `1px solid ${rank.color}25` }}>
            <Trophy style={{ color: rank.color, width: 15, height: 15 }} />
          </div>
          <div>
            <p style={{ fontSize: 13, fontWeight: 700, color: rank.color, lineHeight: 1.2 }}>{rank.label}</p>
            {nextTier && (
              <p style={{ fontSize: 10, color: "rgba(255,255,255,0.28)", marginTop: 1 }}>
                {nextTier.min - count} to {nextTier.label}
              </p>
            )}
          </div>
        </div>
        <Link to="/GamificationHub">
          <span style={{ fontSize: 11, color: "rgba(122,231,255,0.45)", fontWeight: 600 }}>Progress →</span>
        </Link>
      </div>

      {/* Progress bar */}
      <div className="h-1 rounded-full mb-4" style={{ background: "rgba(255,255,255,0.06)" }}>
        <div className="h-full rounded-full" style={{ width: `${progressPct}%`, background: `linear-gradient(90deg, ${rank.color}, ${rank.color}80)`, transition: "width 0.6s ease" }} />
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { icon: Gem,    label: "Finds",  value: count,                                      color: "#00D68F" },
          { icon: Star,   label: "Rare+",  value: rareCount,                                  color: "#7AE7FF" },
          { icon: Trophy, label: "Value",  value: totalValue > 0 ? `$${Math.round(totalValue)}` : "—", color: "#F5B642" },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="rounded-xl py-2.5 text-center"
            style={{ background: `${color}08`, border: `1px solid ${color}14` }}>
            <p style={{ fontSize: 15, fontWeight: 800, color, lineHeight: 1 }}>{value}</p>
            <p style={{ fontSize: 9, color: "rgba(255,255,255,0.28)", fontWeight: 600, letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 3 }}>{label}</p>
          </div>
        ))}
      </div>

      {/* Badge strip */}
      {badges.length > 0 && (
        <div className="flex gap-1.5 mt-3.5 overflow-x-auto" style={{ scrollbarWidth: "none" }}>
          {badges.slice(0, 8).map((b, i) => (
            <div key={i} className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-sm"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              🏅
            </div>
          ))}
          {badges.length > 8 && (
            <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <span style={{ fontSize: 8, color: "rgba(255,255,255,0.3)", fontWeight: 700 }}>+{badges.length - 8}</span>
            </div>
          )}
        </div>
      )}
    </div>
    );
    }

    export default memo(StatusProgressionModule);