/**
 * DisciplineStreak — Shows user's current engagement streak and daily focus
 * 
 * Lightweight gamification hook tied to the Greatness mindset.
 * Encourages daily field practice and documentation.
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Flame, Target } from 'lucide-react';

export default function DisciplineStreak({ userEmail }) {
  const [streak, setStreak] = useState(0);
  const [daysLogged, setDaysLogged] = useState(0);

  useEffect(() => {
    if (!userEmail) return;

    // Mock streak calculation from user activity
    // In production, connect to UserXP or FieldSession entities
    try {
      const cachedStreak = sessionStorage.getItem(`rh_streak_${userEmail}`);
      if (cachedStreak) {
        setStreak(parseInt(cachedStreak, 10));
      } else {
        // Simulate streak: 1-21 for visual variety
        setStreak(Math.floor(Math.random() * 21) + 1);
      }
      setDaysLogged(Math.floor(Math.random() * 47) + 3);
    } catch {}
  }, [userEmail]);

  if (streak === 0) return null;

  return (
    <motion.div
      className="rounded-2xl p-4 mb-6 flex items-center gap-4"
      style={{
        background: 'linear-gradient(135deg, rgba(245,182,66,0.08) 0%, rgba(245,182,66,0.02) 100%)',
        border: '1px solid rgba(245,182,66,0.2)',
        boxShadow: '0 0 16px rgba(245,182,66,0.1)',
      }}
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 }}
    >
      <div className="flex gap-3 flex-1">
        {/* Streak flame */}
        <div className="flex flex-col items-center gap-1">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.2, repeat: Infinity }}
          >
            <Flame style={{ color: '#F5B642', width: 24, height: 24 }} />
          </motion.div>
          <p className="text-[10px] font-semibold uppercase" style={{ color: 'rgba(245,182,66,0.6)' }}>Streak</p>
        </div>

        {/* Streak info */}
        <div className="flex-1 min-w-0">
          <p className="text-2xl font-black text-white">{streak}</p>
          <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.5)' }}>
            days of field work · {daysLogged} total logged
          </p>
        </div>

        {/* Target badge */}
        <div className="flex flex-col items-center justify-center">
          <Target style={{ color: '#F5B642', width: 20, height: 20 }} />
          <p className="text-[10px] font-semibold uppercase mt-1" style={{ color: 'rgba(245,182,66,0.5)' }}>
            {streak >= 30 ? 'Mastery' : streak >= 14 ? 'Disciplined' : 'Building'}
          </p>
        </div>
      </div>
    </motion.div>
  );
}