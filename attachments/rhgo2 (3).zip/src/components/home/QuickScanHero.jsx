import React, { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

export default function QuickScanHero({ onScanComplete }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const streamRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [error, setError] = useState('');
  const [permission, setPermission] = useState(null);

  const startCamera = async () => {
    try {
      setError('');
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err) {
      setError(err.name === 'NotAllowedError' ? 'Camera permission denied.' : 'Camera unavailable.');
      setPermission('denied');
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const captureAndIdentify = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    setScanning(true);
    try {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      context.drawImage(videoRef.current, 0, 0);
      
      canvas.toBlob(async blob => {
        const formData = new FormData();
        formData.append('file', blob, 'scan.jpg');
        const uploadRes = await fetch('/api/upload', { method: 'POST', body: formData }).catch(() => null);
        const uploadedUrl = uploadRes?.ok ? await uploadRes.json() : null;
        
        stopCamera();
        onScanComplete({ photoUrl: uploadedUrl || canvas.toDataURL('image/jpeg'), confidence: 0.85 });
      }, 'image/jpeg', 0.9);
    } catch (err) {
      setError('Capture failed.');
      setScanning(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="relative">
      <style>{`
        @keyframes scanRing { 0%,100%{opacity:.6;transform:scale(1)} 50%{opacity:1;transform:scale(1.05)} }
        @keyframes corePulse { 0%,100%{box-shadow:0 0 40px rgba(16,185,129,.6)} 50%{box-shadow:0 0 80px rgba(16,185,129,.9)} }
      `}</style>

      {!cameraActive ? (
        <div className="flex flex-col items-center justify-center py-12 gap-6">
          {/* Orb */}
          <div className="relative" style={{ width: 160, height: 160 }}>
            <div className="absolute rounded-full" style={{ inset: 0, border: '1.5px solid rgba(16,185,129,.4)', animation: 'scanRing 3s ease-in-out infinite' }} />
            <div className="absolute rounded-full flex items-center justify-center" style={{
              inset: 0,
              background: 'radial-gradient(circle at 35% 35%, rgba(16,185,129,.2) 0%, rgba(10,10,21,.98) 60%)',
              border: '2px solid rgba(16,185,129,.6)',
              animation: 'corePulse 3s ease-in-out infinite'
            }}>
              <Camera className="w-12 h-12" style={{ color: '#6ee7b7', filter: 'drop-shadow(0 0 8px rgba(16,185,129,.8))' }} />
            </div>
          </div>

          <div className="text-center">
            <h1 className="text-2xl font-black text-white mb-1" style={{ fontFamily: 'Sora' }}>SCAN A SPECIMEN</h1>
            <p className="text-sm text-white/40">Point camera at rock or mineral to identify instantly</p>
          </div>

          {error && permission === 'denied' ? (
            <div className="flex items-center gap-2 text-sm text-orange-400/80 bg-orange-500/5 px-4 py-2 rounded-lg border border-orange-500/20">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          ) : error ? (
            <div className="flex items-center gap-2 text-sm text-red-400 bg-red-500/5 px-4 py-2 rounded-lg border border-red-500/20">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              {error}
            </div>
          ) : null}

          <button
            onClick={startCamera}
            className="px-8 py-4 rounded-2xl font-black text-base tracking-wide flex items-center gap-3 transition-all"
            style={{
              background: 'linear-gradient(135deg, rgba(16,185,129,.2) 0%, rgba(5,150,105,.12) 100%)',
              border: '1.5px solid rgba(16,185,129,.6)',
              color: '#6ee7b7',
              boxShadow: '0 0 24px rgba(16,185,129,.3)'
            }}
          >
            <Camera className="w-5 h-5" />
            OPEN CAMERA
          </button>
        </div>
      ) : (
        <div className="relative bg-black rounded-3xl overflow-hidden" style={{ height: 360 }}>
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full h-full object-cover"
          />
          <canvas ref={canvasRef} className="hidden" />
          
          {/* Crosshair overlay */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <svg width="120" height="120" viewBox="0 0 120 120" className="opacity-50">
              <circle cx="60" cy="60" r="50" fill="none" stroke="#10b981" strokeWidth="1.5" strokeDasharray="4 6" />
              <circle cx="60" cy="60" r="35" fill="none" stroke="#d4af37" strokeWidth="1" strokeDasharray="3 5" />
              <line x1="60" y1="20" x2="60" y2="40" stroke="#10b981" strokeWidth="1.5" />
              <line x1="60" y1="80" x2="60" y2="100" stroke="#10b981" strokeWidth="1.5" />
              <line x1="20" y1="60" x2="40" y2="60" stroke="#10b981" strokeWidth="1.5" />
              <line x1="80" y1="60" x2="100" y2="60" stroke="#10b981" strokeWidth="1.5" />
            </svg>
          </div>

          {/* Bottom controls */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-6 flex gap-3 justify-center">
            <button
              onClick={stopCamera}
              className="px-6 py-3 rounded-full font-bold text-sm bg-red-500/20 text-red-400 border border-red-500/50 hover:bg-red-500/30 transition-all"
            >
              CANCEL
            </button>
            <button
              onClick={captureAndIdentify}
              disabled={scanning}
              className="px-8 py-3 rounded-full font-black text-sm flex items-center gap-2 transition-all disabled:opacity-50"
              style={{
                background: scanning ? 'rgba(16,185,129,.3)' : 'linear-gradient(135deg, rgba(16,185,129,.4) 0%, rgba(5,150,105,.2) 100%)',
                border: '1.5px solid rgba(16,185,129,.8)',
                color: '#6ee7b7',
                boxShadow: '0 0 20px rgba(16,185,129,.4)'
              }}
            >
              {scanning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> SCANNING...
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" /> CAPTURE
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </motion.div>
  );
}