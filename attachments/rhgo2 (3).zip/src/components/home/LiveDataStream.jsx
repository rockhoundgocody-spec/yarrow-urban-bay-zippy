/**
 * LiveDataStream — recent activity feed.
 * Clean list, clear hierarchy, no competing glow noise.
 */
import React, { useMemo, memo, useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Camera, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";

function StreamRow({ icon: Icon, label, sub, color, to }) {
  const inner = (
    <div
      className="flex items-center gap-3 rounded-xl px-3 py-2.5 active:scale-[0.98] transition-transform"
      style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.05)" }}
    >
      <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}12`, border: `1px solid ${color}20` }}>
        <Icon style={{ color, width: 14, height: 14 }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium truncate" style={{ color: "rgba(255,255,255,0.75)" }}>{label}</p>
        {sub && <p className="text-[10px] truncate mt-0.5" style={{ color: "rgba(255,255,255,0.28)" }}>{sub}</p>}
      </div>
      <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: color, opacity: 0.7 }} />
    </div>
  );
  return to ? <Link to={to}>{inner}</Link> : inner;
}

function LiveDataStream() {
  const [data, setData] = useState({ specimens: [], listings: [] });

  useEffect(() => {
    Promise.all([
      base44.entities.Specimen.list("-created_date", 3),
      base44.entities.MarketplaceItem.filter({ status: "active" }, "-created_date", 2),
    ])
      .then(([specimens, listings]) => setData({ specimens, listings }))
      .catch(() => {});
  }, []);

  const { specimens = [], listings = [] } = data;

  const rows = useMemo(() => [
    ...specimens.map((s) => ({
      icon: Camera,
      label: s.name || "Unknown specimen",
      sub: s.locality_name ? `Found at ${s.locality_name}` : "Recent scan",
      color: "#00D68F",
      to: `/IdentifyResult?id=${s.id}`,
    })),
    ...listings.map((l) => ({
      icon: ShoppingBag,
      label: l.title || "New listing",
      sub: l.price ? `$${l.price}` : "Market active",
      color: "#F5B642",
      to: "/Marketplace",
    })),
  ].slice(0, 4), [specimens, listings]);

  if (rows.length === 0) {
    return (
      <div className="rounded-2xl px-4 py-4 text-center"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)" }}>
        <p className="text-xs" style={{ color: "rgba(255,255,255,0.18)" }}>Scan a specimen to see live activity here.</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl overflow-hidden"
      style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="flex items-center justify-between px-4 pt-3.5 pb-2">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full" style={{ background: "#00D68F" }} />
          <span style={{ fontSize: 10, color: "rgba(255,255,255,0.4)", fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase" }}>Live Activity</span>
        </div>
        <Link to="/Collection">
          <span style={{ fontSize: 11, color: "rgba(122,231,255,0.4)", fontWeight: 600 }}>View all →</span>
        </Link>
      </div>
      <div className="px-3 pb-3 space-y-1.5">
        {rows.map((r, i) => <StreamRow key={i} {...r} />)}
      </div>
    </div>
  );
}

export default memo(LiveDataStream);