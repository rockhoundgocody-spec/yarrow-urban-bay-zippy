import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { Trophy, Gem, Flame, ChevronRight, Crown, Star } from "lucide-react";
import { base44 } from "@/api/base44Client";

const RANK_CONFIG = [
  { icon: Crown, color: "#FFD700", bg: "rgba(255,215,0,0.15)", border: "rgba(255,215,0,0.35)", label: "1st" },
  { icon: Trophy, color: "#C0C0C0", bg: "rgba(192,192,192,0.12)", border: "rgba(192,192,192,0.28)", label: "2nd" },
  { icon: Trophy, color: "#CD7F32", bg: "rgba(205,127,50,0.12)", border: "rgba(205,127,50,0.28)", label: "3rd" },
];

function getRankStyle(index) {
  if (index < 3) return RANK_CONFIG[index];
  return { icon: Star, color: "rgba(255,255,255,0.25)", bg: "rgba(255,255,255,0.03)", border: "rgba(255,255,255,0.08)", label: `${index + 1}th` };
}

function getTodayStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

export default function DailyLeaderboard() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [userRank, setUserRank] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const todayStart = getTodayStart();

    Promise.all([
      base44.auth.me().catch(() => null),
      // Fetch today's public spottings + discoveries in parallel
      base44.entities.Spotting.filter({}, "-created_date", 100),
      base44.entities.DiscoveryPost.filter({}, "-created_date", 100),
    ]).then(([user, spottings, discoveries]) => {
      if (cancelled) return;
      setCurrentUser(user);

      // Merge and filter to today
      const allFinds = [
        ...(spottings || []).map(s => ({ name: s.user_display_name || "Anonymous", mineral: s.specimen_name, ts: s.created_date })),
        ...(discoveries || []).map(d => ({ name: d.user_display_name || "Anonymous", mineral: d.specimen_name, ts: d.created_date })),
      ].filter(f => f.ts >= todayStart);

      // Aggregate by display name
      const counts = {};
      const lastFind = {};
      allFinds.forEach(f => {
        counts[f.name] = (counts[f.name] || 0) + 1;
        lastFind[f.name] = lastFind[f.name] || f.mineral;
      });

      const ranked = Object.entries(counts)
        .map(([name, count]) => ({ name, count, lastFind: lastFind[name] }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      setEntries(ranked);

      // Find current user's rank
      if (user?.full_name) {
        const idx = ranked.findIndex(e => e.name === user.full_name);
        setUserRank(idx >= 0 ? idx + 1 : null);
      }

      setLoading(false);
    }).catch(() => setLoading(false));

    return () => { cancelled = true; };
  }, []);

  const isEmpty = !loading && entries.length === 0;

  return (
    <div className="rounded-2xl overflow-hidden"
      style={{
        background: "linear-gradient(160deg, rgba(141,124,255,0.08) 0%, rgba(10,8,22,0.95) 100%)",
        border: "1px solid rgba(141,124,255,0.22)",
        boxShadow: "0 0 32px rgba(141,124,255,0.08)",
      }}>

      {/* Header */}
      <div className="px-4 pt-4 pb-3 flex items-center justify-between"
        style={{ borderBottom: "1px solid rgba(141,124,255,0.12)" }}>
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,215,0,0.15)", border: "1px solid rgba(255,215,0,0.30)" }}>
            <Trophy className="w-4 h-4" style={{ color: "#FFD700" }} />
          </div>
          <div>
            <p className="text-sm font-bold text-white leading-tight">Daily Leaderboard</p>
            <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.35)" }}>
              Today's top finders · resets at midnight
            </p>
          </div>
        </div>
        {userRank && (
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg"
            style={{ background: "rgba(141,124,255,0.18)", border: "1px solid rgba(141,124,255,0.35)" }}>
            <Flame className="w-3 h-3" style={{ color: "#8D7CFF" }} />
            <span className="text-xs font-bold" style={{ color: "#C4B5FD" }}>#{userRank}</span>
          </div>
        )}
      </div>

      {/* Body */}
      <div className="px-3 py-3 space-y-2">
        {loading && (
          <div className="space-y-2">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-12 rounded-xl animate-pulse"
                style={{ background: "rgba(255,255,255,0.04)" }} />
            ))}
          </div>
        )}

        {isEmpty && (
          <div className="py-8 text-center">
            <Gem className="w-8 h-8 mx-auto mb-3 opacity-20 text-white" />
            <p className="text-sm font-semibold text-white/30">No finds logged today yet</p>
            <p className="text-xs text-white/20 mt-1">Be first on the board — scan a specimen!</p>
            <Link to="/SpecimenIdentifier">
              <motion.div
                whileTap={{ scale: 0.97 }}
                className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-xl text-xs font-bold"
                style={{
                  background: "rgba(141,124,255,0.18)",
                  border: "1px solid rgba(141,124,255,0.35)",
                  color: "#C4B5FD",
                }}>
                <Gem className="w-3.5 h-3.5" />
                Scan Now
              </motion.div>
            </Link>
          </div>
        )}

        <AnimatePresence>
          {entries.map((entry, i) => {
            const rank = getRankStyle(i);
            const RankIcon = rank.icon;
            const isMe = currentUser?.full_name === entry.name;

            return (
              <motion.div
                key={entry.name}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05, duration: 0.2 }}
                className="flex items-center gap-3 rounded-xl px-3 py-2.5"
                style={{
                  background: isMe
                    ? "linear-gradient(135deg, rgba(141,124,255,0.18), rgba(141,124,255,0.06))"
                    : rank.bg,
                  border: `1px solid ${isMe ? "rgba(141,124,255,0.45)" : rank.border}`,
                  boxShadow: i === 0 ? "0 0 16px rgba(255,215,0,0.10)" : "none",
                }}
              >
                {/* Rank icon */}
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                  style={{ background: `${rank.color}15` }}>
                  <RankIcon className="w-3.5 h-3.5" style={{ color: rank.color }} />
                </div>

                {/* Name + last find */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold leading-tight truncate"
                    style={{ color: isMe ? "#C4B5FD" : i < 3 ? "#fff" : "rgba(255,255,255,0.65)" }}>
                    {entry.name}
                    {isMe && <span className="ml-1.5 text-[10px] font-bold" style={{ color: "#8D7CFF" }}>YOU</span>}
                  </p>
                  {entry.lastFind && (
                    <p className="text-[10px] truncate mt-0.5" style={{ color: "rgba(255,255,255,0.30)" }}>
                      last: {entry.lastFind}
                    </p>
                  )}
                </div>

                {/* Count badge */}
                <div className="flex items-center gap-1 px-2 py-1 rounded-lg flex-shrink-0"
                  style={{
                    background: i === 0 ? "rgba(255,215,0,0.15)" : "rgba(255,255,255,0.06)",
                    border: `1px solid ${i === 0 ? "rgba(255,215,0,0.25)" : "rgba(255,255,255,0.10)"}`,
                  }}>
                  <Gem className="w-3 h-3" style={{ color: i === 0 ? "#FFD700" : "rgba(255,255,255,0.35)" }} />
                  <span className="text-xs font-bold"
                    style={{ color: i === 0 ? "#FFD700" : "rgba(255,255,255,0.6)" }}>
                    {entry.count}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Footer CTA */}
      {!loading && entries.length > 0 && (
        <Link to="/SocialDiscoveryFeed">
          <div className="px-4 py-3 flex items-center justify-center gap-1.5"
            style={{ borderTop: "1px solid rgba(141,124,255,0.10)" }}>
            <span className="text-xs font-semibold" style={{ color: "rgba(141,124,255,0.65)" }}>
              View all community finds
            </span>
            <ChevronRight className="w-3.5 h-3.5" style={{ color: "rgba(141,124,255,0.5)" }} />
          </div>
        </Link>
      )}
    </div>
  );
}