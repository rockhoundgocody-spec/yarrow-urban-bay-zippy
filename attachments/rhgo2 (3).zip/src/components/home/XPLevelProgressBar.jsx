/**
 * XPLevelProgressBar — shows current level, total XP, and progress to next level.
 */
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

// Level thresholds (XP required to reach each level)
const LEVELS = [
  { level: 1, xp: 0,      label: "Pebble Scout" },
  { level: 2, xp: 250,    label: "Rock Finder" },
  { level: 3, xp: 750,    label: "Stone Seeker" },
  { level: 4, xp: 1750,   label: "Mineral Hunter" },
  { level: 5, xp: 3500,   label: "Crystal Tracker" },
  { level: 6, xp: 6000,   label: "Gem Prospector" },
  { level: 7, xp: 10000,  label: "Field Geologist" },
  { level: 8, xp: 16000,  label: "Rock Whisperer" },
  { level: 9, xp: 25000,  label: "Quartz Master" },
  { level: 10, xp: 40000, label: "Crystal Legend" },
];

function getLevelInfo(totalXP) {
  let current = LEVELS[0];
  let next = LEVELS[1];
  for (let i = 0; i < LEVELS.length; i++) {
    if (totalXP >= LEVELS[i].xp) {
      current = LEVELS[i];
      next = LEVELS[i + 1] || null;
    }
  }
  const progressXP = totalXP - current.xp;
  const neededXP = next ? next.xp - current.xp : 0;
  const pct = next ? Math.min(100, (progressXP / neededXP) * 100) : 100;
  return { current, next, progressXP, neededXP, pct, totalXP };
}

export default function XPLevelProgressBar({ userEmail }) {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) return;
    base44.entities.UserXP.filter({ created_by: userEmail }, "-created_date", 500)
      .then((records) => {
        const total = (records || []).reduce((sum, r) => sum + (r.amount || 0), 0);
        setInfo(getLevelInfo(total));
      })
      .catch(() => setInfo(getLevelInfo(0)))
      .finally(() => setLoading(false));
  }, [userEmail]);

  if (loading) {
    return (
      <div className="rounded-2xl px-4 py-4 mb-4 animate-pulse"
        style={{ background: "rgba(141,124,255,0.05)", border: "1px solid rgba(141,124,255,0.12)", height: 80 }} />
    );
  }

  if (!info) return null;

  const { current, next, progressXP, neededXP, pct, totalXP } = info;

  return (
    <div className="rounded-2xl px-4 py-4 mb-4"
      style={{
        background: "linear-gradient(145deg, rgba(12,8,28,0.96) 0%, rgba(8,6,18,0.94) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.5), 0 0 20px rgba(141,124,255,0.06)",
      }}>

      {/* Top row: level badge + label + total XP */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2.5">
          {/* Level badge */}
          <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: "radial-gradient(circle at 40% 35%, rgba(141,124,255,0.30), rgba(141,124,255,0.08))",
              border: "1.5px solid rgba(141,124,255,0.45)",
              boxShadow: "0 0 16px rgba(141,124,255,0.25)",
            }}>
            <span className="text-sm font-black" style={{ color: "#C4B5FD" }}>
              {current.level}
            </span>
          </div>
          <div>
            <p className="text-sm font-bold leading-tight" style={{ color: "#C4B5FD" }}>
              {current.label}
            </p>
            <p className="text-[10px] mt-0.5" style={{ color: "rgba(196,181,253,0.45)" }}>
              Level {current.level}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-right">
          <Sparkles className="w-3.5 h-3.5" style={{ color: "#D4AF37" }} />
          <span className="text-xs font-bold" style={{ color: "#D4AF37" }}>
            {totalXP.toLocaleString()} XP
          </span>
        </div>
      </div>

      {/* Progress bar */}
      <div className="relative h-2 rounded-full mb-2"
        style={{ background: "rgba(141,124,255,0.12)" }}>
        <motion.div
          className="absolute inset-y-0 left-0 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.15 }}
          style={{
            background: "linear-gradient(90deg, #8D7CFF 0%, #C4B5FD 60%, #7AE7FF 100%)",
            boxShadow: "0 0 12px rgba(141,124,255,0.55)",
          }}
        />
      </div>

      {/* Bottom row: progress fraction + next level */}
      <div className="flex items-center justify-between">
        {next ? (
          <>
            <p className="text-[10px]" style={{ color: "rgba(255,255,255,0.30)" }}>
              {progressXP.toLocaleString()} / {neededXP.toLocaleString()} XP to Level {next.level}
            </p>
            <Link to="/GamificationHub" className="flex items-center gap-1 tap-compact">
              <span className="text-[10px] font-semibold" style={{ color: "rgba(141,124,255,0.55)" }}>
                {next.label}
              </span>
              <ChevronRight className="w-3 h-3" style={{ color: "rgba(141,124,255,0.40)" }} />
            </Link>
          </>
        ) : (
          <p className="text-[10px] font-bold" style={{ color: "#D4AF37" }}>
            ✦ Max Level Reached — Legend Status
          </p>
        )}
      </div>
    </div>
  );
}