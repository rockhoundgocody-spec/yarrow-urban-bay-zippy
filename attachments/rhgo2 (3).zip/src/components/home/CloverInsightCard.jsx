import React from "react";
import { Bot, Sparkles, ArrowRight } from "lucide-react";
import CrystalCard from "@/components/ui/CrystalCard";
import LiquidButton from "@/components/ui/LiquidButton";
import StatusChip from "@/components/ui/StatusChip";

export default function CloverInsightCard({
  commentary,
  onOpen,
}) {
  return (
    <CrystalCard tone="dark" glow="purple">
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-violet-500/15 text-violet-500">
          <Bot className="h-6 w-6" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <StatusChip tone="premium" icon={<Sparkles className="h-3.5 w-3.5" />}>
              Clover Active
            </StatusChip>
          </div>

          <div className="mt-3 text-lg font-semibold text-white">
            Personalized field guidance
          </div>

          <div className="mt-2 text-sm leading-6 text-white/60">
            {commentary || "Clover is ready to surface trip patterns, scan insights, and collection gaps when you need them."}
          </div>

          <div className="mt-4">
            <LiquidButton
              variant="premium"
              size="sm"
              rightIcon={<ArrowRight className="h-4 w-4" />}
              onClick={onOpen}
            >
              Open Clover
            </LiquidButton>
          </div>
        </div>
      </div>
    </CrystalCard>
  );
}