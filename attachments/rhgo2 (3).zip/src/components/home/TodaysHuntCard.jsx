/**
 * TodaysHuntCard — Prominent first-screen CTA on the Home command center.
 * Greets the user, shows date, and provides immediate scan + map quick actions.
 */
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Camera, Map, Gem, Compass, Sun, Sunset, Moon } from "lucide-react";
import CrystalGlassPanel from "@/components/effects/CrystalGlassPanel";

function getGreeting() {
  const h = new Date().getHours();
  if (h < 5)  return { text: "Good night,",    icon: Moon,   color: "#8D7CFF" };
  if (h < 12) return { text: "Good morning,",  icon: Sun,    color: "#F5B642" };
  if (h < 17) return { text: "Good afternoon,",icon: Sun,    color: "#F5B642" };
  if (h < 20) return { text: "Good evening,",  icon: Sunset, color: "#FF8C42" };
  return       { text: "Good night,",           icon: Moon,   color: "#8D7CFF" };
}

function getDateLabel() {
  return new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });
}

const QUICK_ACTIONS = [
  { label: "Nearby Spots", icon: Map,    color: "#00D68F", path: "/Explore" },
  { label: "My Vault",     icon: Gem,    color: "#7AE7FF", path: "/Collection" },
  { label: "Field Trips",  icon: Compass, color: "#8D7CFF", path: "/TripPlanner" },
];

export default function TodaysHuntCard({ user }) {
  const name = user?.full_name?.split(" ")[0] || "";
  const greeting = getGreeting();
  const GreetIcon = greeting.icon;

  return (
    <motion.div
      className="mb-5"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
    >
      <CrystalGlassPanel accent="#F5B642" glowStrength="strong" className="px-5 pt-4 pb-5">
        {/* Greeting row */}
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="flex items-center gap-1.5 mb-0.5">
              <GreetIcon style={{ width: 14, height: 14, color: greeting.color }} />
              <span style={{ fontSize: 12, color: "rgba(255,255,255,0.45)", fontWeight: 500 }}>
                {greeting.text}{name ? ` ${name}` : ""}
              </span>
            </div>
            <h2 className="text-xl font-bold tracking-tight" style={{ color: "#fff", lineHeight: 1.2 }}>
              Today's Hunt
            </h2>
            <p style={{ fontSize: 11, color: "rgba(255,255,255,0.3)", marginTop: 2 }}>{getDateLabel()}</p>
          </div>

          {/* Status dot */}
          <div className="flex items-center gap-1.5 mt-1">
            <motion.div
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: "#00D68F", boxShadow: "0 0 8px rgba(0,214,143,0.9)" }}
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
            <span style={{ fontSize: 9, fontWeight: 700, color: "#00D68F", letterSpacing: "0.12em", textTransform: "uppercase" }}>
              Ready
            </span>
          </div>
        </div>

        {/* Primary Start Hunt CTA */}
        <Link to="/SpecimenIdentifier">
          <motion.div
            whileTap={{ scale: 0.97 }}
            className="flex items-center justify-center gap-2 rounded-2xl mb-3"
            style={{
              background: "linear-gradient(135deg, rgba(245,182,66,0.18) 0%, rgba(212,175,55,0.10) 100%)",
              border: "1px solid rgba(245,182,66,0.45)",
              boxShadow: "0 0 20px rgba(245,182,66,0.12), inset 0 1px 0 rgba(255,255,255,0.06)",
              padding: "14px 20px",
              minHeight: 52,
            }}
          >
            <Camera style={{ width: 20, height: 20, color: "#F5B642" }} />
            <span style={{ fontSize: 15, fontWeight: 700, color: "#F5B642", letterSpacing: "-0.01em" }}>
              Start Scanning
            </span>
          </motion.div>
        </Link>

        {/* Quick action row */}
        <div className="grid grid-cols-3 gap-2">
          {QUICK_ACTIONS.map(({ label, icon: Icon, color, path }) => (
            <Link key={label} to={path}>
              <motion.div
                whileTap={{ scale: 0.94 }}
                className="flex flex-col items-center gap-1.5 rounded-2xl py-3"
                style={{
                  background: `${color}0A`,
                  border: `1px solid ${color}28`,
                  minHeight: 64,
                  justifyContent: "center",
                }}
              >
                <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                  style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
                  <Icon style={{ width: 16, height: 16, color }} />
                </div>
                <span style={{ fontSize: 9, fontWeight: 700, color: "rgba(255,255,255,0.55)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                  {label}
                </span>
              </motion.div>
            </Link>
          ))}
        </div>
      </CrystalGlassPanel>
    </motion.div>
  );
}