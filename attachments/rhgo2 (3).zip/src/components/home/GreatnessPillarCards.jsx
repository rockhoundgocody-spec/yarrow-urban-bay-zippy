/**
 * GreatnessPillarCards — 6-pillar card grid showcasing core platform areas.
 * Field Discovery, AI Identification, Collection Intelligence,
 * Mineral Education, Community Expeditions, Marketplace/Commerce.
 */
import React, { memo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Map, Sparkles, Gem, BookOpen, Users, TrendingUp, ChevronRight
} from 'lucide-react';

const PILLARS = [
  {
    icon: Map,
    title: 'Field Discovery',
    desc: 'Map, locate, and explore rockhounding zones. Real-time terrain intel.',
    cta: 'Start Exploring',
    color: '#00D68F',
    path: '/Explore',
    priority: true,
  },
  {
    icon: Sparkles,
    title: 'AI Identification',
    desc: 'Scan specimens. Get instant mineral identification and science.',
    cta: 'Scan Now',
    color: '#7AE7FF',
    path: '/SpecimenIdentifier',
    priority: true,
  },
  {
    icon: Gem,
    title: 'Collection Intelligence',
    desc: 'Organize findings, track value, build your vault strategically.',
    cta: 'Enter Vault',
    color: '#F5B642',
    path: '/Collection',
  },
  {
    icon: BookOpen,
    title: 'Mineral Education',
    desc: 'Learn geology, mineralogy, and field techniques from experts.',
    cta: 'Start Learning',
    color: '#8D7CFF',
    path: '/EducationHub',
  },
  {
    icon: Users,
    title: 'Community Expeditions',
    desc: 'Connect with collectors, share discoveries, join group trips.',
    cta: 'Join Community',
    color: '#88C99A',
    path: '/Community',
  },
  {
    icon: TrendingUp,
    title: 'Marketplace & Commerce',
    desc: 'Trade specimens, analyze value, build your collector brand.',
    cta: 'Explore Market',
    color: '#FF8844',
    path: '/MarketIntelligence',
  },
];

const PillarCard = memo(function PillarCard({ pillar }) {
  const Icon = pillar.icon;
  return (
    <Link to={pillar.path}>
      <motion.div
        whileTap={{ scale: 0.97 }}
        className="rounded-2xl p-4 group cursor-pointer"
        style={{
          background: pillar.priority
            ? `linear-gradient(135deg, ${pillar.color}12, ${pillar.color}06)`
            : `linear-gradient(135deg, ${pillar.color}08, ${pillar.color}03)`,
          border: `1.5px solid ${pillar.color}25`,
          boxShadow: pillar.priority ? `0 0 20px ${pillar.color}12` : `0 0 12px ${pillar.color}08`,
        }}
      >
        {/* Icon */}
        <div className="mb-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              background: `${pillar.color}18`,
              border: `1px solid ${pillar.color}30`,
              boxShadow: `0 0 12px ${pillar.color}12`,
            }}>
            <Icon style={{ color: pillar.color, width: 20, height: 20 }} />
          </div>
        </div>

        {/* Title + desc */}
        <h3 className="text-sm font-bold mb-1 text-white group-hover:opacity-90 transition-opacity">
          {pillar.title}
        </h3>
        <p className="text-xs mb-3 leading-relaxed" style={{ color: 'rgba(255,255,255,0.55)' }}>
          {pillar.desc}
        </p>

        {/* CTA button */}
        <motion.div
          className="flex items-center gap-2 text-xs font-semibold"
          style={{ color: pillar.color }}
        >
          {pillar.cta}
          <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
        </motion.div>
      </motion.div>
    </Link>
  );
});

export default function GreatnessPillarCards() {
  return (
    <motion.div
      className="mb-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4, staggerChildren: 0.05 }}
    >
      <p className="text-[10px] font-bold uppercase tracking-widest mb-3 px-0.5" style={{ color: 'rgba(255,255,255,0.18)' }}>
        Core Pillars
      </p>
      <div className="grid grid-cols-1 gap-2.5">
        {PILLARS.map((pillar) => (
          <motion.div
            key={pillar.title}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <PillarCard pillar={pillar} />
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}