/**
 * CommandCenterHub — RockHound-GO central command center.
 *
 * Home mode: greeting, weather boost, streak/level, quick actions, progress.
 * Field mode: mission tiles + quick access grid.
 */
import React, { useState, useEffect, memo } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

// Stagger child mounts to avoid simultaneous API burst (429 rate limit)
function LazyMount({ delay, children }) {
  const [ready, setReady] = useState(delay === 0);
  useEffect(() => {
    if (delay === 0) { setReady(true); return; }
    const t = setTimeout(() => setReady(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  return ready ? children : null;
}
import {
  Camera, Map, Gem, Shield, Footprints,
  ChevronRight, Target, AlertTriangle, Navigation,
} from "lucide-react";
import { useModeStore } from "@/lib/modeStore.jsx";
import { triggerHapticSound } from "@/lib/useHapticSound";
import { useAuth } from "@/lib/AuthContext";

import StatusProgressionModule from "@/components/home/StatusProgressionModule";
import CloverRouteIntel   from "@/components/clover/CloverRouteIntel";
import QuickActionsLauncher  from "./QuickActionsLauncher";
import YourProgressWidget    from "./YourProgressWidget";
import RecentDiscoveriesFeed from "./RecentDiscoveriesFeed";
import TodaysHuntCard from "@/components/home/TodaysHuntCard";
import XPLevelProgressBar from "@/components/home/XPLevelProgressBar";
import WeatherBoostWidget from "@/components/weather/WeatherBoostWidget";
import CrystalGlassPanel from "@/components/effects/CrystalGlassPanel";
import OnboardingTips from "@/components/onboarding/OnboardingTips";

const HOME_TIPS = [
  { text: "Tap the gold Scan button to identify any rock or mineral with AI." },
  { text: "Check the map for rockhounding spots near your location." },
  { text: "Your Vault grows automatically with every specimen you scan." },
  { text: "Daily Quests reset every day — earn XP for field activities." },
];

// ── Field mode mission tiles ──────────────────────────────────────────────────
const FIELD_MISSIONS = [
  { icon: Camera,        title: "Scan",       sub: "Identify specimen",    color: "#F5B642", path: "/SpecimenIdentifier", priority: true },
  { icon: Map,           title: "Field Map",  sub: "Live terrain intel",   color: "#4AA354", path: "/FieldMap",           priority: true },
  { icon: Shield,        title: "Legality",   sub: "Access rules · risk",  color: "#7AE7FF", path: "/LegalityIntelligence" },
  { icon: Navigation,    title: "Explore",    sub: "Prospecting zones",    color: "#4AA354", path: "/Explore" },
  { icon: Footprints,    title: "Trails",     sub: "Saved routes · nearby",color: "#88C99A", path: "/TrailsRoutes" },
  { icon: Gem,           title: "Collection", sub: "Field log · finds",    color: "#7AE7FF", path: "/Collection" },
  { icon: Target,        title: "Missions",   sub: "Active objectives",    color: "#F5B642", path: "/FieldMissions" },
  { icon: AlertTriangle, title: "Weather",    sub: "Safety · hazards",     color: "#FF8844", path: "/WeatherSafety" },
];

// ── FieldMissionTile ──────────────────────────────────────────────────────────
const FieldMissionTile = memo(function FieldMissionTile({ tile }) {
  const Icon = tile.icon;
  return (
    <Link to={tile.path}>
      <motion.div whileTap={{ scale: 0.96 }} className="relative">
        <CrystalGlassPanel
          accent={tile.color}
          glowStrength={tile.priority ? "strong" : "soft"}
          className="flex items-center gap-3"
          style={{ padding: "14px 16px", minHeight: 64, borderRadius: 18 }}
        >
          <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
            style={{
              background: `radial-gradient(circle at 40% 40%, ${tile.color}20, ${tile.color}08)`,
              border: `1px solid ${tile.color}30`,
              boxShadow: `0 0 12px ${tile.color}15`,
            }}>
            <Icon style={{ color: tile.color, width: 20, height: 20 }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold leading-tight" style={{ color: tile.priority ? "#fff" : "rgba(255,255,255,0.75)" }}>
              {tile.title}
            </p>
            <p className="text-[11px] mt-0.5 truncate" style={{ color: "rgba(255,255,255,0.35)" }}>
              {tile.sub}
            </p>
          </div>
          <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: "rgba(255,255,255,0.18)" }} />
        </CrystalGlassPanel>
      </motion.div>
    </Link>
  );
});

// ── FieldModeHub ──────────────────────────────────────────────────────────────
function FieldModeHub() {
  return (
    <motion.div
      className="relative z-10 max-w-xl mx-auto px-4 pt-6 pb-28"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <motion.div
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: "#4AA354", boxShadow: "0 0 8px rgba(74,163,84,0.9)" }}
              animate={{ opacity: [0.6, 1, 0.6] }}
              transition={{ duration: 1.8, repeat: Infinity }}
            />
            <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "#4AA354" }}>
              Field Mode · Active
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Field Operations</h1>
        </div>
        <Link to="/SpecimenIdentifier" onClick={() => triggerHapticSound("hub_tap")}>
          <motion.div
            whileTap={{ scale: 0.93 }}
            className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{
              background: "radial-gradient(circle at 40% 40%, rgba(245,182,66,0.2), rgba(245,182,66,0.06))",
              border: "1px solid rgba(245,182,66,0.4)",
              boxShadow: "0 0 16px rgba(245,182,66,0.2)",
            }}
          >
            <Camera style={{ color: "#F5B642", width: 22, height: 22 }} />
          </motion.div>
        </Link>
      </div>

      <CloverRouteIntel context="field_mission_control" color="#4AA354" mode="field" className="mb-5" />

      <div className="space-y-2 mb-5">
        {FIELD_MISSIONS.map((tile) => <FieldMissionTile key={tile.title} tile={tile} />)}
      </div>

      <div className="rounded-2xl p-4"
        style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(74,163,84,0.15)" }}>
        <p className="text-[10px] font-bold uppercase tracking-widest mb-3" style={{ color: "rgba(74,163,84,0.5)" }}>
          Quick Access
        </p>
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Trip Planner",    path: "/ItineraryPlanner",    color: "#88C99A" },
            { label: "Market Prices",  path: "/MarketIntelligence",  color: "#F5B642" },
            { label: "Field Notes",    path: "/FieldNotes",           color: "#4AA354" },
            { label: "Daily Briefing", path: "/DailyBriefing",        color: "#7AE7FF" },
            { label: "Offline Map",    path: "/OfflineMap",           color: "#7AE7FF" },
          ].map(({ label, path, color }) => (
            <Link key={label} to={path}>
              <motion.div
                whileTap={{ scale: 0.95 }}
                className="rounded-xl py-3 text-center text-[11px] font-semibold flex items-center justify-center"
                style={{
                  background: "rgba(255,255,255,0.03)",
                  border: `1px solid ${color}15`,
                  color: `${color}80`,
                  minHeight: 44,
                }}
              >
                {label}
              </motion.div>
            </Link>
          ))}
        </div>
      </div>

      {/* Discord */}
      <a href="https://discord.gg/3A7Fpgcx7" target="_blank" rel="noopener noreferrer" className="block mt-3">
        <motion.div
          whileTap={{ scale: 0.97 }}
          className="rounded-2xl p-3 flex items-center gap-3"
          style={{
            background: "rgba(88,101,242,0.14)",
            border: "1px solid rgba(88,101,242,0.4)",
          }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" className="flex-shrink-0">
            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" fill="#5865F2"/>
          </svg>
          <span className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.7)" }}>Join our Discord</span>
          <ChevronRight className="w-4 h-4 ml-auto flex-shrink-0" style={{ color: "rgba(88,101,242,0.6)" }} />
        </motion.div>
      </a>
    </motion.div>
  );
}

// ── Main export ───────────────────────────────────────────────────────────────
export default function CommandCenterHub() {
  const { isField } = useModeStore();
  const { user: authUser } = useAuth();
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (authUser) setUser(authUser);
  }, [authUser]);

  if (isField) {
    return <div className="min-h-screen relative"><FieldModeHub /></div>;
  }

  return (
    <div className="min-h-screen relative">
      <motion.div
        className="relative z-10 max-w-lg mx-auto px-4 pt-6 pb-28"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
      >
        {/* Today's Hunt — greeting + primary scan CTA */}
        <TodaysHuntCard user={user} />

        {/* First-time onboarding tips */}
        <div className="mb-4">
          <OnboardingTips surface="home" tips={HOME_TIPS} />
        </div>

        {/* Weather Boost — live conditions + spawn multiplier */}
        <div className="mb-4">
          <WeatherBoostWidget />
        </div>

        {/* Streak + Level Progress */}
        {user && <LazyMount delay={100}><div className="mb-4"><StatusProgressionModule userEmail={user.email} /></div></LazyMount>}
        {user && <XPLevelProgressBar userEmail={user.email} />}

        {/* Quick Actions */}
        <div className="mb-4"><QuickActionsLauncher /></div>

        {/* Progress */}
        <LazyMount delay={200}><div className="mb-4"><YourProgressWidget /></div></LazyMount>

        {/* Live field discoveries from the community */}
        <LazyMount delay={300}><div className="mb-4"><RecentDiscoveriesFeed /></div></LazyMount>
      </motion.div>
    </div>
  );
}