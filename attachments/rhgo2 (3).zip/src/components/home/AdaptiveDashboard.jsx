/**
 * AdaptiveDashboard — reorders dashboard sections by user behavior.
 * Drop this into the Home page in place of the static layout.
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAdaptiveUI } from "@/lib/useAdaptiveUI";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Camera, Map, Gem, BookOpen, Trophy, Compass, Sparkles, Zap } from "lucide-react";

const SECTIONS = {
  scan: {
    label: "Quick Scan",
    desc: "Identify a specimen instantly",
    icon: Camera,
    color: "#F5B642",
    to: "Identify",
  },
  map: {
    label: "Field Map",
    desc: "Hotspots near you",
    icon: Map,
    color: "#00D68F",
    to: "RockhoundingMap",
  },
  collection: {
    label: "My Collection",
    desc: "Manage your specimens",
    icon: Gem,
    color: "#8D7CFF",
    to: "Collection",
  },
  guides: {
    label: "Mineral Guides",
    desc: "Educational references",
    icon: BookOpen,
    color: "#7AE7FF",
    to: "MineralGuides",
  },
  achievements: {
    label: "Achievements",
    desc: "Pending milestones",
    icon: Trophy,
    color: "#F5B642",
    to: "Achievements",
  },
  trip: {
    label: "Smart Trip Planner",
    desc: "AI-predicted best routes",
    icon: Compass,
    color: "#ec4899",
    to: "ItineraryPlanner",
  },
  missions: {
    label: "Field Missions",
    desc: "Active challenges",
    icon: Zap,
    color: "#00D68F",
    to: "FieldMissions",
  },
  assistant: {
    label: "Clover AI",
    desc: "Your field assistant",
    icon: Sparkles,
    color: "#8D7CFF",
    to: "RockhoundingAssistant",
  },
};

const SECTION_KEYS = Object.keys(SECTIONS);

export default function AdaptiveDashboard() {
  const { ordered, topFeatures, track } = useAdaptiveUI(SECTION_KEYS);

  // top 3 = hero cards, rest = compact grid
  const heroes = ordered.slice(0, 3);
  const grid = ordered.slice(3);

  return (
    <div className="space-y-5 px-4 py-6">
      {/* Personalized shortcut bar */}
      {topFeatures.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {topFeatures.map(({ key }) => {
            const s = SECTIONS[key];
            if (!s) return null;
            return (
              <Link
                key={key}
                to={createPageUrl(s.to)}
                onClick={() => track(key)}
                className="shrink-0 flex items-center gap-2 px-3 py-2 rounded-full text-xs font-semibold"
                style={{ background: `${s.color}15`, border: `1px solid ${s.color}30`, color: s.color }}
              >
                <s.icon className="w-3.5 h-3.5" /> {s.label}
              </Link>
            );
          })}
          <span className="shrink-0 flex items-center text-[10px] text-white/20 px-1">↑ Your shortcuts</span>
        </div>
      )}

      {/* Hero cards — top 3 most-used */}
      <AnimatePresence mode="popLayout">
        <div className="grid grid-cols-1 gap-3">
          {heroes.map((key, i) => {
            const s = SECTIONS[key];
            if (!s) return null;
            return (
              <motion.div
                key={key}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  to={createPageUrl(s.to)}
                  onClick={() => track(key)}
                  className="flex items-center gap-4 p-4 rounded-2xl"
                  style={{ background: `${s.color}0D`, border: `1px solid ${s.color}25` }}
                >
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                    style={{ background: `${s.color}20` }}>
                    <s.icon className="w-6 h-6" style={{ color: s.color }} />
                  </div>
                  <div>
                    <div className="font-bold text-white text-sm">{s.label}</div>
                    <div className="text-xs text-white/40 mt-0.5">{s.desc}</div>
                  </div>
                  {i === 0 && (
                    <span className="ml-auto text-[9px] font-black tracking-widest uppercase px-2 py-0.5 rounded-full"
                      style={{ background: `${s.color}20`, color: s.color }}>Top Pick</span>
                  )}
                </Link>
              </motion.div>
            );
          })}
        </div>
      </AnimatePresence>

      {/* Compact grid — remaining sections */}
      <div className="grid grid-cols-2 gap-3">
        {grid.map((key, i) => {
          const s = SECTIONS[key];
          if (!s) return null;
          return (
            <motion.div key={key} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.04 }}>
              <Link
                to={createPageUrl(s.to)}
                onClick={() => track(key)}
                className="flex flex-col items-start gap-2 p-4 rounded-xl"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <s.icon className="w-5 h-5" style={{ color: s.color }} />
                <div className="text-sm font-semibold text-white/80">{s.label}</div>
                <div className="text-[11px] text-white/30">{s.desc}</div>
              </Link>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}