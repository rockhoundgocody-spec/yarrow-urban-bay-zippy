/**
 * NextBestActionCard — Smart retention hook showing the user's best next action
 * 
 * Contextual recommendation based on user's recent activity.
 * Lightweight, non-intrusive, actionable.
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { ChevronRight } from 'lucide-react';
import CrystalGlassPanel from '@/components/effects/CrystalGlassPanel';

export default function NextBestActionCard({ userEmail }) {
  const [action, setAction] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) { setLoading(false); return; }

    Promise.all([
      base44.entities.Specimen?.filter({ created_by: userEmail }, '-created_date', 1).catch(() => []),
      base44.entities.Scans?.filter({ created_by: userEmail }, '-created_date', 1).catch(() => []),
      base44.entities.UserProfile?.filter({ created_by: userEmail }).catch(() => []),
    ]).then(([specimens, scans, profiles]) => {
      const specimenCount = specimens?.length || 0;
      const scanCount = scans?.length || 0;
      const profile = profiles?.[0];

      // Smart recommendation logic
      let rec = null;
      if (specimenCount === 0) {
        rec = { label: 'Scan your first specimen', path: '/SpecimenIdentifier', context: 'Start your journey', color: '#F5B642' };
      } else if (scanCount < 3) {
        rec = { label: 'Explore nearby locations', path: '/Explore', context: 'Find your next spot', color: '#4AA354' };
      } else if (!profile?.completed_learning_module) {
        rec = { label: 'Master mineral science', path: '/EducationHub', context: 'Level up your knowledge', color: '#8D7CFF' };
      } else {
        rec = { label: 'Join community expeditions', path: '/Community', context: 'Connect with collectors', color: '#7AE7FF' };
      }

      setAction(rec);
      setLoading(false);
    }).catch(() => {
      setAction({ label: 'Start exploring', path: '/Explore', context: 'Begin your adventure', color: '#7AE7FF' });
      setLoading(false);
    });
  }, [userEmail]);

  if (loading || !action) return null;

  return (
    <Link to={action.path}>
      <motion.div
        className="mb-6"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
      >
        <CrystalGlassPanel accent={action.color} glowStrength="soft" className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: action.color, boxShadow: `0 0 8px ${action.color}` }} />
            <div className="min-w-0">
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: action.color }}>{action.context}</p>
              <p className="text-sm font-bold leading-tight mt-0.5 text-white">{action.label}</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 flex-shrink-0" style={{ color: `${action.color}60` }} />
        </CrystalGlassPanel>
      </motion.div>
    </Link>
  );
}