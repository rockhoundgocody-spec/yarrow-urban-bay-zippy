/**
 * YourProgressWidget: Progress summary with circular rings (P3)
 * Shows total finds, rare finds, missions
 */
import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { motion } from 'framer-motion';
import { Loader2, Gem, Star, Target } from 'lucide-react';

export default function YourProgressWidget() {
  const { user } = useAuth();
  const [totalFinds, setTotalFinds] = useState(0);
  const [rareFinds, setRareFinds] = useState(0);
  const [missionsCount, setMissionsCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.email) return;

    Promise.all([
      base44.entities.Specimen.filter({ created_by: user.email }),
      base44.entities.UserMissionProgress.filter({ created_by: user.email }),
    ])
      .then(([specimens, missions]) => {
        const specList = specimens || [];
        setTotalFinds(specList.length);
        setRareFinds(specList.filter((s) => ['rare', 'epic', 'legendary'].includes(s.rarity)).length);
        setMissionsCount(missions?.filter((m) => m.status === 'completed').length || 0);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to fetch progress:', err);
        setLoading(false);
      });
  }, [user]);

  const CircleProgress = ({ icon: Icon, label, value, color }) => {
    const circumference = 2 * Math.PI * 45;
    const strokeDashoffset = circumference - (value / 100) * circumference;

    return (
      <div className="flex flex-col items-center gap-2">
        <div className="relative w-24 h-24">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="45" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="4" />
            <motion.circle
              cx="50"
              cy="50"
              r="45"
              fill="none"
              stroke={color}
              strokeWidth="4"
              strokeDasharray={circumference}
              initial={{ strokeDashoffset: circumference }}
              animate={{ strokeDashoffset }}
              transition={{ duration: 1, ease: 'easeOut' }}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <Icon className="w-6 h-6" style={{ color }} />
          </div>
        </div>
        <div className="text-center">
          <p className="text-lg font-bold">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </div>
    );
  };

  if (!user?.email) {
    return null; // Not logged in — don't show blank section
  }

  if (loading) {
    return (
      <div className="rounded-2xl p-4 flex items-center justify-center gap-2"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", minHeight: 80 }}>
        <Loader2 className="w-4 h-4 animate-spin" style={{ color: "#00D68F" }} />
        <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>Loading progress…</span>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <p className="text-[10px] font-bold uppercase tracking-widest px-0.5" style={{ color: "rgba(255,255,255,0.2)" }}>Your Progress</p>
      <div className="grid grid-cols-3 gap-4">
        <CircleProgress
          icon={Gem}
          label="Total Finds"
          value={Math.min(totalFinds, 100)}
          color="#00D68F"
        />
        <CircleProgress
          icon={Star}
          label="Rare Finds"
          value={Math.min(rareFinds, 100)}
          color="#F5B642"
        />
        <CircleProgress
          icon={Target}
          label="Missions"
          value={Math.min(missionsCount, 100)}
          color="#7AE7FF"
        />
      </div>
    </motion.div>
  );
}