/**
 * PrimaryActionRing — 6-node orbital action ring around the scan core.
 * Style: obsidian crystalline panels, gemstone glow borders, dark base.
 */
import React from "react";
import { Link } from "react-router-dom";
import { Map, Gem, ShoppingBag, Users, Compass, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

const ACTIONS = [
  { icon: Map,        label: "Explore",    color: "#00D68F", glow: "rgba(0,214,143,0.22)",    border: "rgba(0,214,143,0.35)",    path: "/Explore" },
  { icon: Gem,        label: "Collection", color: "#7AE7FF", glow: "rgba(122,231,255,0.18)",  border: "rgba(122,231,255,0.30)",  path: "/Collection" },
  { icon: ShoppingBag,label: "Market",     color: "#D4AF37", glow: "rgba(212,175,55,0.18)",   border: "rgba(212,175,55,0.30)",   path: "/Marketplace" },
  { icon: Users,      label: "Community",  color: "#8D7CFF", glow: "rgba(141,124,255,0.18)",  border: "rgba(141,124,255,0.30)",  path: "/Community" },
  { icon: Compass,    label: "Trips",      color: "#88C99A", glow: "rgba(136,201,154,0.16)",  border: "rgba(136,201,154,0.28)",  path: "/ItineraryPlanner" },
  { icon: Sparkles,   label: "Clover",     color: "#00D68F", glow: "rgba(0,214,143,0.22)",    border: "rgba(0,214,143,0.35)",    path: "/Clover" },
];

export default function PrimaryActionRing() {
  return (
    <div className="grid grid-cols-3 gap-3">
      {ACTIONS.map((action, i) => {
        const Icon = action.icon;
        return (
          <Link key={action.label} to={action.path}>
            <motion.div
              className="flex flex-col items-center gap-2.5 cursor-pointer"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.08 + i * 0.07, duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              whileTap={{ scale: 0.88 }}
              whileHover={{ scale: 1.05 }}
            >
              <div
                className="w-full rounded-2xl flex flex-col items-center justify-center gap-2.5 py-5 relative overflow-hidden"
                style={{
                  background: `linear-gradient(145deg, rgba(10,8,22,0.98) 0%, rgba(8,6,18,0.95) 100%)`,
                  border: `1.5px solid ${action.border}`,
                  boxShadow: `0 0 28px ${action.glow}, 0 4px 16px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.08)`,
                  minHeight: 90,
                }}
              >
                {/* Crystal sheen */}
                <div className="absolute inset-0 pointer-events-none"
                  style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.07) 0%, transparent 55%)", borderRadius: "inherit" }} />
                {/* Top accent line */}
                <div className="absolute top-0 left-3 right-3 h-[1.5px] pointer-events-none"
                  style={{ background: `linear-gradient(90deg, transparent, ${action.color}70, transparent)` }} />

                <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
                  style={{
                    background: `radial-gradient(circle at 40% 35%, ${action.color}22, ${action.color}08)`,
                    border: `1px solid ${action.color}30`,
                  }}>
                  <Icon style={{ color: action.color, width: 26, height: 26, filter: `drop-shadow(0 0 10px ${action.color})` }} />
                </div>
                <p style={{
                  fontSize: 11, fontWeight: 800, color: "rgba(255,255,255,0.70)",
                  textAlign: "center", letterSpacing: "0.05em",
                  textShadow: `0 0 12px ${action.color}60`,
                }}>
                  {action.label}
                </p>
              </div>
            </motion.div>
          </Link>
        );
      })}
    </div>
  );
}