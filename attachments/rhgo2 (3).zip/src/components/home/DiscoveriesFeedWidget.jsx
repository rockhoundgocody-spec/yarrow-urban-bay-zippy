/**
 * DiscoveriesFeedWidget: Real-time community discoveries widget (P3)
 * Shows 3 most recent Discovery records
 */
import React, { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { Compass, Loader2 } from 'lucide-react';
import { timeAgo } from '@/utils';

const RARITY_COLORS = {
  common: '#6B7280',
  uncommon: '#10B981',
  rare: '#3B82F6',
  epic: '#8B5CF6',
  legendary: '#F59E0B',
};

export default function DiscoveriesFeedWidget() {
  const [discoveries, setDiscoveries] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Discovery.list('-created_date', 3)
      .then((results) => {
        setDiscoveries(results || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to fetch discoveries:', err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="rounded-2xl p-4 flex items-center justify-center gap-2"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)", minHeight: 80 }}>
        <Loader2 className="w-4 h-4 animate-spin" style={{ color: "#00D68F" }} />
        <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>Loading discoveries…</span>
      </div>
    );
  }

  if (discoveries.length === 0) {
    return null; // No blank section — just omit when empty
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-3"
    >
      <div className="flex items-center gap-2">
        <Compass className="w-5 h-5" style={{ color: "#00D68F" }} />
        <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.2)" }}>Live Discoveries</p>
      </div>

      <div className="space-y-2">
        {discoveries.map((discovery, idx) => (
          <motion.div
            key={discovery.id}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="rounded-lg border border-border bg-card/50 p-3 space-y-1"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{discovery.mineral_name || 'Unknown'}</p>
                <p className="text-xs text-muted-foreground truncate">
                  by {discovery.created_by?.split('@')[0] || 'Collector'}
                </p>
              </div>
              <span
                className="text-xs font-bold px-2 py-1 rounded whitespace-nowrap"
                style={{
                  color: RARITY_COLORS[discovery.rarity] || RARITY_COLORS.common,
                  background: `${RARITY_COLORS[discovery.rarity]}20`,
                }}
              >
                {discovery.rarity?.toUpperCase() || 'COMMON'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {discovery.location_name || 'Unknown location'} · {timeAgo(discovery.created_date)}
            </p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}