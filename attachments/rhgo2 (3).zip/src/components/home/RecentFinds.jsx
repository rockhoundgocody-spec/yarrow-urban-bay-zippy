import React from "react";
import { Gem } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { formatDistanceToNow } from "date-fns";

export default function RecentFinds({ specimens = [] }) {
  const recent = specimens.slice(0, 4);

  if (recent.length === 0) {
    return (
      <div className="rounded-2xl border border-white/8 bg-white/3 p-6 text-center">
        <Gem className="w-8 h-8 text-white/15 mx-auto mb-2" />
        <p className="text-white/30 text-sm">No specimens yet. Try scanning one!</p>
        <Link to={createPageUrl("Identify")} className="text-[var(--quantum-magenta)] text-xs mt-2 inline-block">
          Identify a Rock →
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-2.5">
      {recent.map((s) => (
        <Link
          key={s.id}
          to={createPageUrl("Collection")}
          className="rounded-xl border border-white/8 bg-white/3 overflow-hidden hover:border-white/15 transition-all"
        >
          {s.photo_url && (
            <img src={s.photo_url} alt={s.name} className="w-full h-24 object-cover" />
          )}
          <div className="p-2.5">
            <p className="text-xs font-medium text-white/90 truncate">{s.name}</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {s.hardness && (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/20">
                  ⚡ {s.hardness} Mohs
                </span>
              )}
              {s.category && (
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/8 text-white/40 border border-white/10 capitalize">
                  {s.category}
                </span>
              )}
            </div>
            <p className="text-[10px] text-white/35 mt-1">
              {formatDistanceToNow(new Date(s.created_date), { addSuffix: true })}
            </p>
          </div>
        </Link>
      ))}
    </div>
  );
}