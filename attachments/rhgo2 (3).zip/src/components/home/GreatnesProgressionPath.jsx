/**
 * GreatnessProgressionPath — "Greatness Path" journey stages.
 * Discover → Identify → Document → Master → Share → Build Legacy
 */
import React, { memo } from 'react';
import { motion } from 'framer-motion';
import { Compass, Zap, ClipboardList, Trophy, Share2, Crown } from 'lucide-react';

const STAGES = [
  {
    icon: Compass,
    stage: 'Discover',
    desc: 'Explore zones, find specimens, learn the land.',
    color: '#00D68F',
  },
  {
    icon: Zap,
    stage: 'Identify',
    desc: 'Scan with AI, unlock mineral science instantly.',
    color: '#7AE7FF',
  },
  {
    icon: ClipboardList,
    stage: 'Document',
    desc: 'Log findings, catalog your collection with precision.',
    color: '#F5B642',
  },
  {
    icon: Trophy,
    stage: 'Master',
    desc: 'Study geology, develop expertise, earn credentials.',
    color: '#8D7CFF',
  },
  {
    icon: Share2,
    stage: 'Share',
    desc: 'Connect with community, contribute knowledge.',
    color: '#88C99A',
  },
  {
    icon: Crown,
    stage: 'Build Legacy',
    desc: 'Trade, monetize, establish yourself as a collector.',
    color: '#FF8844',
  },
];

const StageNode = memo(function StageNode({ stage, index, total }) {
  const Icon = stage.icon;
  const isLast = index === total - 1;
  
  return (
    <div className="flex items-start gap-3">
      {/* Circle + line */}
      <div className="flex flex-col items-center pt-1">
        <motion.div
          className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
          style={{
            background: `${stage.color}22`,
            border: `1.5px solid ${stage.color}45`,
            boxShadow: `0 0 12px ${stage.color}20`,
          }}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.3, delay: index * 0.08 }}
        >
          <Icon style={{ color: stage.color, width: 16, height: 16 }} />
        </motion.div>
        {!isLast && (
          <div
            className="w-0.5 h-10 mt-1"
            style={{ background: `linear-gradient(180deg, ${stage.color}40, ${stage.color}05)` }}
          />
        )}
      </div>

      {/* Content */}
      <motion.div
        className="flex-1 pt-0.5"
        initial={{ opacity: 0, x: -8 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3, delay: index * 0.1 }}
      >
        <p className="text-sm font-bold text-white">{stage.stage}</p>
        <p className="text-xs mt-0.5" style={{ color: 'rgba(255,255,255,0.5)' }}>
          {stage.desc}
        </p>
      </motion.div>
    </div>
  );
});

export default function GreatnessProgressionPath() {
  return (
    <motion.div
      className="rounded-2xl p-5 mb-6"
      style={{
        background: 'linear-gradient(135deg, rgba(0,214,143,0.10) 0%, rgba(136,199,154,0.05) 100%)',
        border: '1px solid rgba(0,214,143,0.20)',
        boxShadow: '0 0 28px rgba(0,214,143,0.08)',
      }}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Header */}
      <div className="mb-4">
        <p className="text-[10px] font-bold uppercase tracking-widest mb-1" style={{ color: 'rgba(0,214,143,0.6)' }}>
          Your Journey
        </p>
        <h3 className="text-lg font-bold text-white">The Greatness Path</h3>
      </div>

      {/* Stages */}
      <div className="space-y-4">
        {STAGES.map((stage, i) => (
          <StageNode key={stage.stage} stage={stage} index={i} total={STAGES.length} />
        ))}
      </div>

      {/* Footer text */}
      <p className="text-xs mt-5 pt-4 border-t border-white/10" style={{ color: 'rgba(255,255,255,0.45)' }}>
        Growth through disciplined discovery. Each stage unlocks new tools, knowledge, and community standing.
      </p>
    </motion.div>
  );
}