/**
 * CommunityHighlights — recent community posts and trending activity.
 */
import React from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Users, Heart, MessageCircle, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

export default function CommunityHighlights() {
  const { data: posts = [], isLoading } = useQuery({
    queryKey: ["home-community"],
    queryFn: () => base44.entities.Post.list("-created_date", 3),
    staleTime: 3 * 60 * 1000,
  });

  if (!isLoading && posts.length === 0) return null;

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "rgba(255,255,255,0.35)" }}>
          Community Highlights
        </p>
        <Link to="/Community" className="flex items-center gap-0.5 text-[10px] font-semibold" style={{ color: "#7AE7FF" }}>
          See more <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="space-y-2">
        {isLoading
          ? Array.from({ length: 2 }).map((_, i) => (
              <div key={i} className="h-16 rounded-2xl animate-pulse"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }} />
            ))
          : posts.map((post, i) => (
              <Link key={post.id} to="/Community">
                <motion.div
                  className="rounded-2xl px-4 py-3 flex items-start gap-3 cursor-pointer"
                  style={{ background: "rgba(122,231,255,0.05)", border: "1px solid rgba(122,231,255,0.12)" }}
                  whileHover={{ borderColor: "rgba(122,231,255,0.25)", y: -1 }}
                  whileTap={{ scale: 0.98 }}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.07 }}
                >
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                    style={{ background: "rgba(122,231,255,0.12)", border: "1px solid rgba(122,231,255,0.2)" }}>
                    <Users className="w-4 h-4" style={{ color: "#7AE7FF" }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-semibold text-white/80 leading-snug line-clamp-2">{post.content}</p>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="text-[9px] text-white/30">{post.user_display_name || post.created_by?.split("@")[0]}</span>
                      <span className="text-[9px] text-white/20">·</span>
                      <span className="text-[9px] text-white/25">
                        {formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}
                      </span>
                      {post.like_count > 0 && (
                        <>
                          <span className="text-[9px] text-white/20">·</span>
                          <span className="flex items-center gap-0.5 text-[9px] text-white/30">
                            <Heart className="w-2.5 h-2.5" /> {post.like_count}
                          </span>
                        </>
                      )}
                      {post.comment_count > 0 && (
                        <span className="flex items-center gap-0.5 text-[9px] text-white/30">
                          <MessageCircle className="w-2.5 h-2.5" /> {post.comment_count}
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
      </div>
    </div>
  );
}