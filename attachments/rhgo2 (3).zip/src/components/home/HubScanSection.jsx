/**
 * HubScanSection — ScanOrb hero card with status metadata strip.
 * Wraps the ScanOrb in the Hub's premium dark crystal panel.
 */
import React from "react";
import ScanOrb from "@/components/scan/ScanOrb";
import DustMoteField from "@/components/effects/DustMoteField";

const META = [
  { label: "AI Confidence", value: "94%",        color: "#00D68F" },
  { label: "Model",         value: "Gemini Pro",  color: "#7AE7FF" },
  { label: "Mode",          value: "Field Ready", color: "#8D7CFF" },
];

export default function HubScanSection({ scanCount = 0, findCount = 0 }) {
  return (
    <div
      className="relative rounded-3xl mb-7 flex flex-col items-center pt-7 pb-5 overflow-hidden"
      style={{
        background: "linear-gradient(160deg, rgba(8,6,20,0.97) 0%, rgba(12,8,28,0.94) 100%)",
        border: "1px solid rgba(141,124,255,0.18)",
        boxShadow: [
          "0 8px 48px rgba(0,0,0,0.6)",
          "0 0 80px rgba(141,124,255,0.06)",
          "inset 0 1px 0 rgba(255,255,255,0.05)",
        ].join(", "),
      }}
    >
      {/* Dust mote particle field — visual white noise */}
      <DustMoteField count={14} color="#8D7CFF" className="absolute inset-0 pointer-events-none z-0" />

      {/* Top crystal edge accent */}
      <div
        className="absolute top-0 left-0 right-0 h-px pointer-events-none"
        style={{ background: "linear-gradient(90deg, transparent, rgba(141,124,255,0.50), rgba(122,231,255,0.28), transparent)" }}
      />
      {/* Bottom accent */}
      <div
        className="absolute bottom-0 left-0 right-0 h-px pointer-events-none"
        style={{ background: "linear-gradient(90deg, transparent, rgba(0,214,143,0.22), transparent)" }}
      />

      {/* ScanOrb flagship component */}
      <div className="relative z-10">
        <ScanOrb scanCount={scanCount} findCount={findCount} size="lg" />
      </div>

      {/* Status metadata strip */}
      <div className="relative z-10 flex items-center gap-5 mt-5 pt-4 border-t w-full px-6"
        style={{ borderColor: "rgba(255,255,255,0.05)" }}
      >
        {META.map(({ label, value, color }) => (
          <div key={label} className="flex-1 text-center">
            <p className="text-[10px] font-bold" style={{ color }}>{value}</p>
            <p className="text-[9px] mt-0.5 uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.22)" }}>
              {label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}