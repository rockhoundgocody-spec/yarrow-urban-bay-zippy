/**
 * QuickActionsLauncher: 5-button shortcut grid (P3)
 */
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import { MapPin, Compass, BookOpen, CloudSun, RefreshCw } from 'lucide-react';

const ACTIONS = [
  { label: 'Nearby',    icon: MapPin,    navigate: '/Explore',              color: '#00D68F' },
  { label: 'Trips',     icon: Compass,   navigate: '/TripPlanner',          color: '#8D7CFF' },
  { label: 'Notes',     icon: BookOpen,  navigate: '/FieldNotes',           color: '#7AE7FF' },
  { label: 'Safety',    icon: CloudSun,  navigate: '/WeatherSafety',         color: '#FF8844' },
  { label: 'Sync',      icon: RefreshCw, navigate: '/OfflineSyncDashboard', badge: 'pending_count', color: '#F5B642' },
];

export default function QuickActionsLauncher() {
  const navigate = useNavigate();
  const [pendingCount, setPendingCount] = useState(0);

  // Get sync pending count
  useEffect(() => {
    base44.entities.OfflineSyncQueue.filter({ status: 'pending' })
      .then((results) => {
        setPendingCount(results?.length || 0);
      })
      .catch(() => {});
  }, []);

  return (
    <div>
      <p className="text-[10px] font-bold uppercase tracking-widest mb-2 px-0.5" style={{ color: "rgba(255,255,255,0.2)" }}>Quick Actions</p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-5 gap-2"
      >
        {ACTIONS.map((action, idx) => {
          const Icon = action.icon;
          const showBadge = action.badge === 'pending_count' && pendingCount > 0;

          return (
            <motion.button
              key={action.label}
              onClick={() => navigate(action.navigate)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="relative flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all"
              style={{
                background: "rgba(255,255,255,0.03)",
                border: "1px solid rgba(255,255,255,0.07)",
                minHeight: 64,
              }}
            >
              <Icon className="w-5 h-5" style={{ color: action.color }} />
              <span className="text-[9px] font-semibold text-center leading-tight" style={{ color: "rgba(255,255,255,0.45)" }}>{action.label}</span>
              {showBadge && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {pendingCount}
                </span>
              )}
            </motion.button>
          );
        })}
      </motion.div>
    </div>
  );
}