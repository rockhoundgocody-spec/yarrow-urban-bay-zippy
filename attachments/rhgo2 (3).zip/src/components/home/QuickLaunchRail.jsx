import React from "react";
import { motion } from "framer-motion";
import { Camera, Map, BookOpen, Route, Store, Bot } from "lucide-react";
import CrystalCard from "@/components/ui/CrystalCard";

const items = [
  { key: "scan", label: "Scan", icon: Camera, tone: "teal" },
  { key: "explore", label: "Explore", icon: Map, tone: "sky" },
  { key: "collection", label: "Collection", icon: BookOpen, tone: "violet" },
  { key: "trips", label: "Trips", icon: Route, tone: "gold" },
  { key: "market", label: "Market", icon: Store, tone: "coral" },
  { key: "clover", label: "Clover", icon: Bot, tone: "teal" },
];

function toneClasses(tone) {
  switch (tone) {
    case "sky":
      return "bg-sky-400/15 text-sky-500";
    case "violet":
      return "bg-violet-400/15 text-violet-500";
    case "gold":
      return "bg-amber-300/20 text-amber-500";
    case "coral":
      return "bg-orange-400/15 text-orange-500";
    default:
      return "bg-cyan-400/15 text-cyan-500";
  }
}

export default function QuickLaunchRail({ onSelect }) {
  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
      {items.map((item, index) => {
        const Icon = item.icon;

        return (
          <motion.div
            key={item.key}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.04 }}
          >
            <button
              type="button"
              onClick={() => onSelect?.(item.key)}
              className="w-full"
            >
              <CrystalCard tone="dark" className="h-full">
                <div className="flex items-center gap-3">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-full ${toneClasses(item.tone)}`}>
                    <Icon className="h-5 w-5" />
                  </div>

                  <div>
                    <div className="text-sm font-semibold text-white">
                      {item.label}
                    </div>
                    <div className="text-xs text-white/60">
                      Launch
                    </div>
                  </div>
                </div>
              </CrystalCard>
            </button>
          </motion.div>
        );
      })}
    </div>
  );
}