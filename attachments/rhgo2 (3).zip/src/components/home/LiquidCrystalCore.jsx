/**
 * LiquidCrystalCore v2 — premium refractive mineral-tech core.
 * Advanced light physics, realistic glass behavior, spectral refraction.
 */
import React from 'react';
import { motion } from 'framer-motion';

export default function LiquidCrystalCore({ isActive, isComplete }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      {/* Outer atmospheric glow aureole */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 340,
          height: 340,
          background: 'radial-gradient(circle, rgba(122,231,255,0.18) 0%, rgba(141,124,255,0.08) 35%, rgba(0,214,143,0.04) 65%, transparent 100%)',
          filter: 'blur(60px)',
          opacity: 0,
        }}
        initial={{ opacity: 0, scale: 0.4 }}
        animate={isActive ? { opacity: 1, scale: 1 } : { opacity: 0 }}
        transition={{ duration: 2.6, ease: 'easeOut' }}
      />

      {/* Mid atmospheric layer */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 280,
          height: 280,
          background: 'radial-gradient(circle, rgba(0,214,143,0.12) 0%, rgba(122,231,255,0.06) 50%, transparent 100%)',
          filter: 'blur(40px)',
          opacity: 0,
        }}
        initial={{ opacity: 0, scale: 0.5 }}
        animate={isActive ? { opacity: 1, scale: 1 } : { opacity: 0 }}
        transition={{ duration: 2.8, ease: 'easeOut', delay: 0.3 }}
      />

      {/* Core structure — faceted refractive geometry */}
      <motion.div
        className="relative"
        style={{ width: 160, height: 160, perspective: '1200px' }}
        initial={{ opacity: 0, scale: 0 }}
        animate={isActive ? { opacity: 1, scale: 1 } : { opacity: 0 }}
        transition={{ duration: 2.2, ease: 'easeOut', delay: 0.5 }}
      >
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 160 160"
          style={{
            filter: 'drop-shadow(0 0 32px rgba(122,231,255,0.5)) drop-shadow(0 0 64px rgba(141,124,255,0.25))',
          }}
        >
          <defs>
            {/* Advanced material gradients */}
            <linearGradient id="coreLiquid1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#7AE7FF" stopOpacity="1" />
              <stop offset="50%" stopColor="#8D7CFF" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#00D68F" stopOpacity="0.4" />
            </linearGradient>
            <linearGradient id="coreLiquid2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#8D7CFF" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#7AE7FF" stopOpacity="0.3" />
            </linearGradient>
            <linearGradient id="coreEdge" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgba(255,255,255,0)" />
              <stop offset="50%" stopColor="rgba(255,255,255,0.4)" />
              <stop offset="100%" stopColor="rgba(255,255,255,0)" />
            </linearGradient>
            <filter id="coreBlur" x="-100%" y="-100%" width="300%" height="300%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="0.4" />
            </filter>
          </defs>

          {/* Upper pyramid facet — dominant light capture */}
          <motion.polygon
            points="80,15 130,75 80,95 30,75"
            fill="url(#coreLiquid1)"
            opacity="1"
            animate={{
              opacity: [1, 0.95, 1],
              filter: ['drop-shadow(0 0 16px rgba(122,231,255,0.6))', 'drop-shadow(0 0 24px rgba(122,231,255,0.8))', 'drop-shadow(0 0 16px rgba(122,231,255,0.6))'],
            }}
            transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut' }}
          />

          {/* Right facet — refraction plane */}
          <motion.polygon
            points="80,95 130,75 150,120 100,135"
            fill="url(#coreLiquid2)"
            opacity="0.85"
            animate={{
              opacity: [0.85, 0.92, 0.85],
            }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 0.3 }}
          />

          {/* Left facet — secondary reflection */}
          <motion.polygon
            points="80,95 30,75 10,120 60,135"
            fill="url(#coreLiquid1)"
            opacity="0.8"
            animate={{
              opacity: [0.8, 0.88, 0.8],
            }}
            transition={{ duration: 5.2, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
          />

          {/* Lower apex — deep spectrum */}
          <motion.polygon
            points="80,145 130,95 100,135"
            fill="url(#coreLiquid2)"
            opacity="0.75"
            animate={{
              opacity: [0.75, 0.85, 0.75],
            }}
            transition={{ duration: 4.8, repeat: Infinity, ease: 'easeInOut', delay: 0.2 }}
          />
          <motion.polygon
            points="80,145 30,95 60,135"
            fill="url(#coreLiquid1)"
            opacity="0.75"
            animate={{
              opacity: [0.75, 0.85, 0.75],
            }}
            transition={{ duration: 4.8, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
          />

          {/* Bright edge highlight — fresnel effect */}
          <motion.line
            x1="80"
            y1="15"
            x2="80"
            y2="60"
            stroke="url(#coreEdge)"
            strokeWidth="3"
            opacity="0"
            animate={{ opacity: [0.3, 0.6, 0.3] }}
            transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
          />
        </svg>

        {/* Inner core luminescence */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(122,231,255,0.5) 0%, rgba(141,124,255,0.2) 40%, transparent 70%)',
            filter: 'blur(12px)',
          }}
          animate={{
            opacity: [0.4, 0.7, 0.4],
          }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Spectral shimmer sweep */}
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: 'linear-gradient(45deg, transparent 0%, rgba(255,255,255,0.25) 50%, transparent 100%)',
            backgroundSize: '200% 200%',
            filter: 'blur(2px)',
          }}
          animate={{ backgroundPosition: ['0% 0%', '200% 200%', '400% 400%'] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
        />
      </motion.div>

      {/* Orbital harmonic rings — holographic geometry */}
      {isComplete && (
        <>
          <motion.svg
            className="absolute inset-0 w-full h-full pointer-events-none"
            viewBox="0 0 100 100"
            preserveAspectRatio="xMidYMid slice"
          >
            <defs>
              <linearGradient id="ringGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7AE7FF" stopOpacity="0.3" />
                <stop offset="50%" stopColor="#8D7CFF" stopOpacity="0.15" />
                <stop offset="100%" stopColor="#00D68F" stopOpacity="0" />
              </linearGradient>
            </defs>
            <motion.circle
              cx="50"
              cy="50"
              r="22"
              fill="none"
              stroke="url(#ringGradient1)"
              strokeWidth="0.6"
              opacity="0.4"
              animate={{ rotate: 360 }}
              transition={{ duration: 10, repeat: Infinity, linear: true }}
            />
            <motion.circle
              cx="50"
              cy="50"
              r="30"
              fill="none"
              stroke="url(#ringGradient1)"
              strokeWidth="0.4"
              opacity="0.25"
              animate={{ rotate: -360 }}
              transition={{ duration: 16, repeat: Infinity, linear: true }}
            />
            <motion.circle
              cx="50"
              cy="50"
              r="38"
              fill="none"
              stroke="url(#ringGradient1)"
              strokeWidth="0.5"
              opacity="0.2"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, linear: true }}
            />
          </motion.svg>
        </>
      )}
    </div>
  );
}