/**
 * QuickActionDock — 3 prominent quick-action buttons per sitemap spec:
 * AI Identification · Trip Planner · AR Field Guide
 */
import React from "react";
import { Link } from "react-router-dom";
import { Camera, Compass, Layers } from "lucide-react";
import { motion } from "framer-motion";

const ACTIONS = [
  {
    icon: Camera,
    label: "AI Identification",
    sub: "Scan specimen",
    path: "/SpecimenIdentifier",
    color: "#F5B642",
    bg: "linear-gradient(135deg, rgba(245,182,66,0.18), rgba(245,182,66,0.06))",
  },
  {
    icon: Compass,
    label: "Trip Planner",
    sub: "Plan your route",
    path: "/ItineraryPlanner",
    color: "#00D68F",
    bg: "linear-gradient(135deg, rgba(0,214,143,0.18), rgba(0,214,143,0.06))",
  },
  {
    icon: Layers,
    label: "AR Field Guide",
    sub: "Vein map overlay",
    path: "/ARVeinMap",
    color: "#8D7CFF",
    bg: "linear-gradient(135deg, rgba(141,124,255,0.18), rgba(141,124,255,0.06))",
  },
];

export default function QuickActionDock() {
  return (
    <div className="mb-6">
      <p className="text-[10px] font-bold uppercase tracking-[0.18em] mb-3" style={{ color: "rgba(255,255,255,0.35)" }}>
        Quick Actions
      </p>
      <div className="grid grid-cols-3 gap-3">
        {ACTIONS.map((action, i) => {
          const Icon = action.icon;
          return (
            <Link key={action.label} to={action.path}>
              <motion.div
                className="rounded-2xl p-3.5 flex flex-col items-center text-center cursor-pointer"
                style={{
                  background: action.bg,
                  border: `1px solid ${action.color}28`,
                  minHeight: 88,
                }}
                whileHover={{ borderColor: `${action.color}55`, y: -2, boxShadow: `0 8px 24px ${action.color}18` }}
                whileTap={{ scale: 0.96 }}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.06 }}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-2"
                  style={{ background: `${action.color}18`, border: `1px solid ${action.color}32` }}>
                  <Icon className="w-5 h-5" style={{ color: action.color }} />
                </div>
                <p className="text-[10px] font-bold leading-tight text-white/80">{action.label}</p>
                <p className="text-[9px] mt-0.5" style={{ color: "rgba(255,255,255,0.35)" }}>{action.sub}</p>
              </motion.div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}