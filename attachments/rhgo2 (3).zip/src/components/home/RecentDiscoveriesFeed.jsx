/**
 * RecentDiscoveriesFeed — Home dashboard live feed of recent field discoveries
 * from other users. Highlights rarity tier and locality for each entry to
 * encourage community interaction.
 *
 * Reads public Discovery records (is_shared=true) — the same shared feed that
 * drives the community discovery surfaces. Each card surfaces the rarity tier
 * and locality prominently and deep-links into the specimen detail.
 */
import React, { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Radio, MapPin, Heart, Loader2, Sparkles } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const RARITY_STYLE = {
  common: { color: "#9CA3AF", bg: "rgba(156,163,175,0.12)", border: "rgba(156,163,175,0.3)" },
  uncommon: { color: "#4ADE80", bg: "rgba(74,222,128,0.12)", border: "rgba(74,222,128,0.3)" },
  rare: { color: "#7AE7FF", bg: "rgba(122,231,255,0.12)", border: "rgba(122,231,255,0.35)" },
  epic: { color: "#8D7CFF", bg: "rgba(141,124,255,0.14)", border: "rgba(141,124,255,0.4)" },
  legendary: { color: "#F5B642", bg: "rgba(245,182,66,0.16)", border: "rgba(245,182,66,0.45)" },
};

const RARITY_SCORE = { common: 20, uncommon: 40, rare: 65, epic: 85, legendary: 100 };

function rarityTier(t) {
  const s = String(t || "").toLowerCase();
  return RARITY_STYLE[s] ? s : "common";
}

export default function RecentDiscoveriesFeed() {
  const { data: discoveries = [], isLoading } = useQuery({
    queryKey: ["home-recent-discoveries"],
    queryFn: () => base44.entities.Discovery.filter({ is_shared: true }, "-shared_date", 12),
    staleTime: 60_000,
  });

  const items = useMemo(() => discoveries.slice(0, 8), [discoveries]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-6 gap-2">
        <Loader2 className="w-4 h-4 animate-spin" style={{ color: "#8D7CFF" }} />
        <span className="text-[11px] uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>Loading live feed</span>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="rounded-2xl p-4 text-center"
        style={{ background: "rgba(141,124,255,0.04)", border: "1px solid rgba(141,124,255,0.12)" }}>
        <Radio className="w-5 h-5 mx-auto mb-2" style={{ color: "rgba(141,124,255,0.3)" }} />
        <p className="text-xs font-semibold" style={{ color: "rgba(255,255,255,0.5)" }}>No shared discoveries yet</p>
        <p className="text-[10px] mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>Be the first to share a find with the community.</p>
      </div>
    );
  }

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ background: "#8D7CFF" }} />
            <span className="relative inline-flex rounded-full h-2 w-2" style={{ background: "#8D7CFF" }} />
          </span>
          <h3 className="text-xs font-bold uppercase tracking-widest" style={{ color: "#C4B5FD" }}>Live Field Discoveries</h3>
        </div>
        <Link to="/SocialDiscoveryFeed" className="text-[10px] font-semibold" style={{ color: "rgba(122,231,255,0.7)" }}>
          View all →
        </Link>
      </div>

      {/* Horizontal scroll feed */}
      <div className="flex gap-3 overflow-x-auto pb-2" style={{ scrollbarWidth: "none" }}>
        {items.map((d) => {
          const tier = rarityTier(d.rarity_tier);
          const rs = RARITY_STYLE[tier];
          return (
            <Link
              key={d.id}
              to={d.specimen_id ? `/SpecimenDetail?id=${d.specimen_id}` : "/SocialDiscoveryFeed"}
              className="flex-shrink-0 w-44 rounded-2xl overflow-hidden transition-all"
              style={{
                background: "rgba(10,12,22,0.7)",
                border: `1px solid ${rs.border}`,
                boxShadow: `0 4px 20px rgba(0,0,0,0.4), 0 0 12px ${rs.color}15`,
              }}
            >
              {/* Photo */}
              <div className="relative h-28 w-full overflow-hidden" style={{ background: "rgba(255,255,255,0.03)" }}>
                {d.photo_url ? (
                  <img src={d.photo_url} alt={d.mineral_name} className="w-full h-full object-cover" loading="lazy" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Sparkles className="w-6 h-6" style={{ color: "rgba(255,255,255,0.1)" }} />
                  </div>
                )}
                {/* Rarity badge — top highlight */}
                <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider"
                  style={{ background: rs.bg, border: `1px solid ${rs.border}`, color: rs.color, backdropFilter: "blur(4px)" }}>
                  {tier}
                </span>
              </div>

              {/* Body */}
              <div className="p-3">
                <p className="text-sm font-bold text-white leading-tight truncate">{d.mineral_name}</p>
                {d.variety && <p className="text-[10px] truncate" style={{ color: "rgba(255,255,255,0.4)" }}>{d.variety}</p>}

                {/* Rarity score highlight */}
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-[8px] font-bold uppercase tracking-wide" style={{ color: rs.color }}>Rarity</span>
                  <span className="text-[11px] font-black" style={{ color: rs.color, textShadow: `0 0 8px ${rs.color}66` }}>{RARITY_SCORE[tier]}</span>
                  <span className="text-[8px]" style={{ color: "rgba(255,255,255,0.25)" }}>/ 100</span>
                </div>

                {/* Locality highlight */}
                <div className="flex items-center gap-1 mt-2">
                  <MapPin className="w-3 h-3 flex-shrink-0" style={{ color: "rgba(122,231,255,0.6)" }} />
                  <span className="text-[10px] truncate" style={{ color: "rgba(122,231,255,0.8)" }}>
                    {d.location_name || "Locality unknown"}
                  </span>
                </div>

                {/* Footer: discoverer + likes + time */}
                <div className="flex items-center justify-between mt-2 pt-2" style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}>
                  <span className="text-[9px] truncate" style={{ color: "rgba(255,255,255,0.35)" }}>
                    {d.discoverer_name || "Anonymous"}
                  </span>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {Number(d.like_count) > 0 && (
                      <span className="flex items-center gap-0.5 text-[9px]" style={{ color: "rgba(255,120,120,0.7)" }}>
                        <Heart className="w-2.5 h-2.5" /> {d.like_count}
                      </span>
                    )}
                    <span className="text-[9px]" style={{ color: "rgba(255,255,255,0.25)" }}>
                      {formatDistanceToNow(new Date(d.shared_date || d.created_date), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}