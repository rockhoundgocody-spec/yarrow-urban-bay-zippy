/**
 * HubIdentityHeader — greeting strip + Greatness mission positioning.
 */
import React from "react";

export default function HubIdentityHeader({ user }) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const firstName = user?.full_name?.split(" ")[0] || "Explorer";

  return (
    <div className="mb-6 text-center">
      {/* Greeting + short tagline */}
      <p className="text-sm font-semibold uppercase tracking-widest mb-1.5" style={{ color: "rgba(255,255,255,0.4)" }}>
        {greeting}, {firstName}
      </p>
      <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>
        Enter the command hub
      </p>
    </div>
  );
}