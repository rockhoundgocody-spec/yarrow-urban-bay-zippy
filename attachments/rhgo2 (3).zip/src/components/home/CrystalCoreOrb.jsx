/**
 * CrystalCoreOrb — Primary scan entry point for the Hub command center.
 * Obsidian base · amethyst/violet energy rings · gold frame · cyan pulse · hex crystal shards.
 */
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Camera } from "lucide-react";

const ICON_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699b620aabda6503e72aa4f2/b4bbf8913_20260221_213444-IMG_STYLE.jpg";

// Hex shard dots positioned around the orb
const SHARDS = [
  { angle: 0,   r: 72, size: 5, color: "#8D7CFF" },
  { angle: 60,  r: 68, size: 3, color: "#7AE7FF" },
  { angle: 120, r: 72, size: 5, color: "#D4AF37" },
  { angle: 180, r: 68, size: 3, color: "#8D7CFF" },
  { angle: 240, r: 72, size: 4, color: "#7AE7FF" },
  { angle: 300, r: 68, size: 3, color: "#D4AF37" },
];

function shard(s, i) {
  const rad = (s.angle * Math.PI) / 180;
  const x = 90 + Math.cos(rad) * s.r;
  const y = 90 + Math.sin(rad) * s.r;
  return (
    <motion.circle
      key={i}
      cx={x} cy={y} r={s.size}
      fill={s.color}
      filter={`drop-shadow(0 0 4px ${s.color})`}
      animate={{ opacity: [0.4, 1, 0.4], r: [s.size * 0.7, s.size, s.size * 0.7] }}
      transition={{ duration: 2 + i * 0.3, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

export default function CrystalCoreOrb({ scanCount = 0, findCount = 0 }) {
  return (
    <div className="relative flex flex-col items-center select-none">
      {/* Stats flanking the orb */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 flex flex-col items-center gap-0.5 -translate-x-2">
        <span className="text-lg font-black" style={{ color: "#7AE7FF", textShadow: "0 0 12px rgba(122,231,255,0.7)" }}>{scanCount}</span>
        <span className="text-[9px] font-bold uppercase tracking-widest" style={{ color: "rgba(122,231,255,0.4)" }}>Scans</span>
      </div>
      <div className="absolute right-0 top-1/2 -translate-y-1/2 flex flex-col items-center gap-0.5 translate-x-2">
        <span className="text-lg font-black" style={{ color: "#D4AF37", textShadow: "0 0 12px rgba(212,175,55,0.7)" }}>{findCount}</span>
        <span className="text-[9px] font-bold uppercase tracking-widest" style={{ color: "rgba(212,175,55,0.4)" }}>Relics</span>
      </div>

      <Link to="/SpecimenIdentifier">
        <motion.div
          className="relative"
          whileTap={{ scale: 0.93 }}
          whileHover={{ scale: 1.04 }}
          transition={{ type: "spring", stiffness: 300, damping: 22 }}
        >
          {/* SVG layer: rings + shards */}
          <svg width="180" height="180" viewBox="0 0 180 180" className="absolute inset-0 pointer-events-none">
            {/* Outer ambient ring */}
            <motion.circle cx="90" cy="90" r="84" fill="none"
              stroke="rgba(141,124,255,0.18)" strokeWidth="1"
              animate={{ opacity: [0.5, 0.9, 0.5] }}
              transition={{ duration: 3.5, repeat: Infinity }}
            />
            {/* Gold hex frame */}
            <motion.circle cx="90" cy="90" r="76" fill="none"
              stroke="rgba(212,175,55,0.30)" strokeWidth="1.5" strokeDasharray="8 6"
              animate={{ rotate: 360 }}
              style={{ transformOrigin: "90px 90px" }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
            />
            {/* Violet inner energy ring */}
            <motion.circle cx="90" cy="90" r="64" fill="none"
              stroke="rgba(141,124,255,0.50)" strokeWidth="1.5"
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 2.2, repeat: Infinity }}
            />
            {/* Cyan counter-rotating ring */}
            <motion.circle cx="90" cy="90" r="54" fill="none"
              stroke="rgba(122,231,255,0.35)" strokeWidth="1" strokeDasharray="4 8"
              animate={{ rotate: -360 }}
              style={{ transformOrigin: "90px 90px" }}
              transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
            />
            {/* Crystal shards */}
            {SHARDS.map(shard)}
          </svg>

          {/* Core orb button */}
          <div className="relative w-[180px] h-[180px] flex items-center justify-center">
            {/* Ambient glow behind orb */}
            <div className="absolute inset-0 rounded-full pointer-events-none"
              style={{ background: "radial-gradient(circle at 50%, rgba(141,124,255,0.22) 0%, rgba(0,214,143,0.08) 55%, transparent 70%)", filter: "blur(12px)" }} />

            {/* The orb itself */}
            <motion.div
              className="relative flex items-center justify-center rounded-full overflow-hidden"
              style={{
                width: 100, height: 100,
                background: "radial-gradient(circle at 38% 35%, rgba(141,124,255,0.35) 0%, rgba(10,6,24,0.98) 65%)",
                border: "2px solid rgba(141,124,255,0.55)",
                boxShadow: [
                  "0 0 0 6px rgba(141,124,255,0.08)",
                  "0 0 0 12px rgba(141,124,255,0.04)",
                  "0 0 32px rgba(141,124,255,0.35)",
                  "0 0 60px rgba(0,214,143,0.10)",
                  "inset 0 1px 0 rgba(255,255,255,0.12)",
                ].join(", "),
              }}
              animate={{
                boxShadow: [
                  "0 0 0 6px rgba(141,124,255,0.08), 0 0 0 12px rgba(141,124,255,0.04), 0 0 32px rgba(141,124,255,0.35), 0 0 60px rgba(0,214,143,0.10), inset 0 1px 0 rgba(255,255,255,0.12)",
                  "0 0 0 8px rgba(141,124,255,0.14), 0 0 0 18px rgba(141,124,255,0.06), 0 0 48px rgba(141,124,255,0.50), 0 0 80px rgba(122,231,255,0.15), inset 0 1px 0 rgba(255,255,255,0.14)",
                  "0 0 0 6px rgba(141,124,255,0.08), 0 0 0 12px rgba(141,124,255,0.04), 0 0 32px rgba(141,124,255,0.35), 0 0 60px rgba(0,214,143,0.10), inset 0 1px 0 rgba(255,255,255,0.12)",
                ]
              }}
              transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}
            >
              {/* App icon inside orb */}
              <img src={ICON_URL} alt="Scan" className="absolute inset-0 w-full h-full object-cover opacity-25" />
              {/* Glass sheen */}
              <div className="absolute inset-0 pointer-events-none"
                style={{ background: "linear-gradient(135deg, rgba(255,255,255,0.10) 0%, transparent 50%)" }} />
              {/* Camera icon */}
              <Camera className="relative z-10 w-9 h-9" style={{ color: "#fff", filter: "drop-shadow(0 0 8px rgba(141,124,255,0.9))" }} />
            </motion.div>
          </div>

          {/* Tap label */}
          <p className="text-center text-[9px] font-bold uppercase tracking-[0.28em] mt-1"
            style={{ color: "rgba(141,124,255,0.55)" }}>
            TAP TO SCAN
          </p>
        </motion.div>
      </Link>
    </div>
  );
}