/**
 * NewInMarketplace — horizontal scroll of recently listed marketplace items.
 */
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { ShoppingBag, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

const CAT_COLOR = {
  mineral: "#00D68F",
  crystal: "#8D7CFF",
  fossil: "#00ffaa",
  gemstone: "#F5B642",
  equipment: "#ff6600",
};

export default function NewInMarketplace() {
  const [items, setItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    base44.entities.MarketplaceItem.filter({ status: "active" }, "-created_date", 6)
      .then(data => setItems(data || []))
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  if (!isLoading && items.length === 0) return null;

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "rgba(255,255,255,0.35)" }}>
          New in Marketplace
        </p>
        <Link to="/Market" className="flex items-center gap-0.5 text-[10px] font-semibold" style={{ color: "#F5B642" }}>
          Browse all <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1" style={{ scrollbarWidth: "none" }}>
        {isLoading
          ? Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex-shrink-0 w-36 h-24 rounded-2xl animate-pulse"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }} />
            ))
          : items.map((item, i) => {
              const accent = CAT_COLOR[item.category] || "#F5B642";
              return (
                <Link key={item.id} to="/Market">
                  <motion.div
                    className="flex-shrink-0 w-36 rounded-2xl overflow-hidden cursor-pointer"
                    style={{ border: `1px solid ${accent}22`, background: `linear-gradient(145deg, ${accent}0D, rgba(10,15,20,0.9))`, minHeight: 96 }}
                    whileHover={{ y: -2, borderColor: `${accent}44` }}
                    whileTap={{ scale: 0.97 }}
                    initial={{ opacity: 0, x: 12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.06 }}
                  >
                    {item.photo_url
                      ? <img src={item.photo_url} alt={item.title} className="w-full h-16 object-cover" />
                      : (
                        <div className="w-full h-16 flex items-center justify-center" style={{ background: `${accent}10` }}>
                          <ShoppingBag className="w-6 h-6" style={{ color: `${accent}60` }} />
                        </div>
                      )}
                    <div className="px-2.5 py-2">
                      <p className="text-[10px] font-bold text-white/80 leading-snug truncate">{item.title}</p>
                      <p className="text-xs font-black mt-0.5" style={{ color: accent }}>${Number(item.price || 0).toFixed(0)}</p>
                    </div>
                  </motion.div>
                </Link>
              );
            })}
      </div>
    </div>
  );
}