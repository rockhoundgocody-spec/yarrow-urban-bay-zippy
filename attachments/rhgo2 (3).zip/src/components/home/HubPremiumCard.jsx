/**
 * HubPremiumCard — graceful fallback card for premium / coming-soon Hub features.
 *
 * type: "premium" | "coming_soon"
 */
import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Lock, Clock } from "lucide-react";

export default function HubPremiumCard({ icon: Icon, title, sub, type = "premium", path }) {
  const isPremium = type === "premium";
  const color = isPremium ? "#D4AF37" : "#7AE7FF";

  const inner = (
    <motion.div
      whileTap={{ scale: 0.97 }}
      className="flex items-center gap-3 rounded-2xl px-4 py-3.5 relative overflow-hidden"
      style={{
        background: "rgba(255,255,255,0.015)",
        border: `1px dashed ${color}22`,
        minHeight: 60,
      }}
    >
      <div
        className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}10`, border: `1px solid ${color}20` }}
      >
        <Icon style={{ color: `${color}70`, width: 17, height: 17 }} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.45)" }}>{title}</p>
        <p className="text-[10px] mt-0.5 leading-relaxed" style={{ color: "rgba(255,255,255,0.22)" }}>{sub}</p>
      </div>
      {isPremium
        ? <Lock className="w-3.5 h-3.5 flex-shrink-0" style={{ color: `${color}50` }} />
        : <Clock className="w-3.5 h-3.5 flex-shrink-0" style={{ color: `${color}50` }} />
      }
    </motion.div>
  );

  return path ? <Link to={path}>{inner}</Link> : inner;
}