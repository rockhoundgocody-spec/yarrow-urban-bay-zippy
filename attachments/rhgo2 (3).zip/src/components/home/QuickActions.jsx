import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Camera, Map, Gem, Compass, BookOpen, ShoppingBag } from "lucide-react";

const ACTIONS = [
{ label: "Scan", icon: Camera, page: "Identify", color: "#ff00ff", bg: "rgba(255,0,255,0.12)" },
{ label: "Map", icon: Map, page: "RockhoundingMap", color: "#00f5ff", bg: "rgba(0,245,255,0.12)" },
{ label: "Collection", icon: Gem, page: "Collection", color: "#a855f7", bg: "rgba(168,85,247,0.12)" },
{ label: "Trip Plan", icon: Compass, page: "TripPlanner", color: "#00ffaa", bg: "rgba(0,255,170,0.12)" },
{ label: "Learn", icon: BookOpen, page: "LearningCenter", color: "#ffd700", bg: "rgba(255,215,0,0.12)" },
{ label: "Market", icon: ShoppingBag, page: "Marketplace", color: "#ff6600", bg: "rgba(255,102,0,0.12)" }];


export default function QuickActions() {
  return (
    <div className="grid grid-cols-3 gap-2.5">
      {ACTIONS.map(({ label, icon: Icon, page, color, bg }) =>
      <Link
        key={page}
        to={createPageUrl(page)}
        className="flex flex-col items-center gap-1.5 rounded-2xl border border-white/8 p-4 hover:border-white/15 transition-all active:scale-95"
        style={{ background: bg }}>
        
          <Icon className="lucide lucide-book-open w-95 h-295" style={{ color }} />
          <span className="text-[11px] font-medium text-white/70">{label}</span>
        </Link>
      )}
    </div>);

}