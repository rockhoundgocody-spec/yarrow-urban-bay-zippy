import React, { useState } from 'react';
import { Settings, X } from 'lucide-react';

export default function WidgetSettingsButton() {
  const [showSettings, setShowSettings] = useState(false);
  const STORAGE_KEY = 'rh_widget_config';

  const WIDGETS = [
    { id: 'field-stats', name: 'Field Stats' },
    { id: 'scan-history', name: 'Recent Scans' },
    { id: 'weather-gps', name: 'Weather & GPS' },
    { id: 'nearby-discoveries', name: 'Nearby Finds' },
    { id: 'rarity-breakdown', name: 'Rarity Chart' },
  ];

  const getEnabledWidgets = () => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : ['field-stats', 'scan-history', 'weather-gps'];
    } catch {
      return ['field-stats', 'scan-history', 'weather-gps'];
    }
  };

  const handleToggle = (id) => {
    const enabled = getEnabledWidgets();
    const updated = enabled.includes(id) ? enabled.filter((w) => w !== id) : [...enabled, id];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    // Force re-render by closing and reopening
    setShowSettings(false);
    setTimeout(() => setShowSettings(true), 0);
  };

  const enabledWidgets = getEnabledWidgets();

  return (
    <>
      <button
        onClick={() => setShowSettings(!showSettings)}
        className="fixed bottom-20 left-6 z-40 p-2.4 rounded-full transition-all active:scale-95"
        style={{
          background: 'rgba(122,231,255,0.12)',
          border: '1px solid rgba(122,231,255,0.3)',
          color: '#7AE7FF',
          width: 40,
          height: 40,
          minHeight: 'unset',
          minWidth: 'unset',
        }}
       aria-label="Settings">
        <Settings className="w-5 h-5" />
      </button>

      {showSettings && (
        <div
          className="fixed inset-0 z-50 backdrop-blur-sm flex items-end"
          style={{ background: 'rgba(0,0,0,0.5)' }}
          onClick={() => setShowSettings(false)}
        >
          <div
            className="w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto"
            style={{ background: 'rgba(14,20,27,0.95)', borderTop: '1px solid rgba(122,231,255,0.2)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <Settings style={{ color: '#7AE7FF', width: 18, height: 18 }} />
                <h2 className="text-sm font-bold text-white">Customize Widgets</h2>
              </div>
              <button
                onClick={() => setShowSettings(false)}
                className="p-1 rounded-lg transition-all hover:bg-white/10"
                style={{ minHeight: 'unset', minWidth: 'unset' }}
               aria-label="Close">
                <X className="w-5 h-5 text-white/60 hover:text-white" />
              </button>
            </div>
            <div className="space-y-2">
              {WIDGETS.map(({ id, name }) => (
                <label
                  key={id}
                  className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <input
                    type="checkbox"
                    checked={enabledWidgets.includes(id)}
                    onChange={() => handleToggle(id)}
                    className="w-4 h-4 cursor-pointer accent-cyan-400"
                  />
                  <span className="text-xs font-semibold text-white">{name}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}