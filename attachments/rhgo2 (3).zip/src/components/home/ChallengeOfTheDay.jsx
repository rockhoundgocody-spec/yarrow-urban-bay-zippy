/**
 * ChallengeOfTheDay — surfaces a featured field mission / challenge for the user.
 */
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Target, Zap, ChevronRight } from "lucide-react";
import { motion } from "framer-motion";

const DIFFICULTY_COLOR = { easy: "#00D68F", moderate: "#F5B642", hard: "#FF6644", expert: "#FF2255" };

export default function ChallengeOfTheDay() {
  const [mission, setMission] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    base44.entities.FieldMission.filter({ is_active: true, is_featured: true }, "-created_date", 1)
      .then(featured => {
        if (featured?.[0]) { setMission(featured[0]); setIsLoading(false); return; }
        return base44.entities.FieldMission.filter({ is_active: true }, "-created_date", 1)
          .then(fallback => { setMission(fallback?.[0] || null); });
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, []);

  if (!isLoading && !mission) return null;

  const accent = mission ? (DIFFICULTY_COLOR[mission.difficulty] || "#00D68F") : "#00D68F";

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "rgba(255,255,255,0.35)" }}>
          Challenge of the Day
        </p>
        <Link to="/Challenges" className="flex items-center gap-0.5 text-[10px] font-semibold" style={{ color: accent }}>
          All challenges <ChevronRight className="w-3 h-3" />
        </Link>
      </div>

      {isLoading ? (
        <div className="h-20 rounded-2xl animate-pulse"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }} />
      ) : mission ? (
        <Link to="/Challenges">
          <motion.div
            className="rounded-2xl p-4 cursor-pointer flex items-center gap-4"
            style={{
              background: `linear-gradient(135deg, ${accent}12, ${accent}05)`,
              border: `1px solid ${accent}30`,
              boxShadow: `0 0 24px ${accent}10`,
            }}
            whileHover={{ borderColor: `${accent}55`, y: -2 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0"
              style={{ background: `${accent}18`, border: `1px solid ${accent}35` }}>
              <Target className="w-6 h-6" style={{ color: accent }} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[9px] font-bold uppercase tracking-widest capitalize px-2 py-0.5 rounded-full"
                  style={{ background: `${accent}18`, color: accent, border: `1px solid ${accent}30` }}>
                  {mission.difficulty || "moderate"}
                </span>
                <span className="flex items-center gap-1 text-[9px] font-bold" style={{ color: "rgba(245,182,66,0.8)" }}>
                  <Zap className="w-2.5 h-2.5" /> {mission.xp_reward} XP
                </span>
              </div>
              <p className="text-sm font-bold text-white/90 leading-snug truncate">{mission.title}</p>
              {mission.description && (
                <p className="text-[10px] mt-0.5 line-clamp-1" style={{ color: "rgba(255,255,255,0.4)" }}>{mission.description}</p>
              )}
            </div>
            <ChevronRight className="w-4 h-4 flex-shrink-0" style={{ color: `${accent}55` }} />
          </motion.div>
        </Link>
      ) : null}
    </div>
  );
}