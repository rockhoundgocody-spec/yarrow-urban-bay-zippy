import React, { useState, useEffect } from 'react';
import { Compass, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function NearbyDiscoveriesWidget() {
  const [userLoc, setUserLoc] = useState(null);
  const [discoveries, setDiscoveries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition((pos) => {
      setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    }, () => {});
  }, []);

  useEffect(() => {
    if (!userLoc) return;
    base44.entities.Discovery.list('-created_date', 5)
      .then(all => {
        const filtered = all.filter(d => {
          if (!d.latitude || !d.longitude) return false;
          const dist = Math.sqrt(
            Math.pow(d.latitude - userLoc.lat, 2) + Math.pow(d.longitude - userLoc.lng, 2)
          ) * 69;
          return dist < 25;
        }).slice(0, 3);
        setDiscoveries(filtered);
      })
      .catch(() => setDiscoveries([]))
      .finally(() => setIsLoading(false));
  }, [userLoc]);

  if (isLoading || !userLoc) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="h-20 bg-white/5 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(139,124,255,0.08)', border: '1px solid rgba(139,124,255,0.2)' }}>
      <div className="flex items-center gap-2 mb-3">
        <Compass style={{ color: '#8D7CFF', width: 16, height: 16 }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(139,124,255,0.8)' }}>Nearby</p>
      </div>
      <div className="space-y-2">
        {discoveries.length === 0 ? (
          <p className="text-xs text-white/35 text-center py-3">No discoveries nearby</p>
        ) : (
          discoveries.map((d) => (
            <div key={d.id} className="rounded-xl p-2.5 flex items-center gap-2" style={{ background: 'rgba(255,255,255,0.04)' }}>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(139,124,255,0.15)' }}>
                <MapPin style={{ color: '#8D7CFF', width: 14, height: 14 }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-white truncate">{d.title || 'Discovery'}</p>
                <p className="text-[10px] text-white/35">{d.mineral_type || 'Unknown'}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}