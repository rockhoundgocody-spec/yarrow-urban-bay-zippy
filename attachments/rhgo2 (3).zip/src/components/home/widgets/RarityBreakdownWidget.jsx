import React, { useState, useEffect } from 'react';
import { BarChart3 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const RARITY_COLORS = {
  common: '#6B7280',
  uncommon: '#00D68F',
  rare: '#7AE7FF',
  epic: '#8D7CFF',
  legendary: '#F5B642',
};

export default function RarityBreakdownWidget({ userEmail }) {
  const [breakdown, setBreakdown] = useState({ common: 0, uncommon: 0, rare: 0, epic: 0, legendary: 0 });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) {
      setIsLoading(false);
      return;
    }
    base44.entities.Specimen.filter({ created_by: userEmail })
      .then(specimens => {
        const counts = {
          common: 0, uncommon: 0, rare: 0, epic: 0, legendary: 0,
        };
        specimens.forEach((s) => {
          const rarity = s.rarity || 'common';
          counts[rarity] = (counts[rarity] || 0) + 1;
        });
        setBreakdown(counts);
      })
      .catch(() => {})
      .finally(() => setIsLoading(false));
  }, [userEmail]);

  const total = Object.values(breakdown).reduce((a, b) => a + b, 0);

  if (isLoading) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="h-20 bg-white/5 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center gap-2 mb-3">
        <BarChart3 style={{ color: '#7AE7FF', width: 16, height: 16 }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(255,255,255,0.6)' }}>Rarity</p>
      </div>
      <div className="space-y-2">
        {Object.entries(breakdown).map(([rarity, count]) => (
          <div key={rarity} className="flex items-center gap-2">
            <div className="w-16 text-xs font-semibold capitalize text-white/70">{rarity}</div>
            <div className="flex-1 h-2 rounded-full" style={{ background: 'rgba(255,255,255,0.05)' }}>
              <div
                className="h-full rounded-full transition-all"
                style={{
                  background: RARITY_COLORS[rarity],
                  width: total > 0 ? `${(count / total) * 100}%` : '0%',
                  boxShadow: `0 0 8px ${RARITY_COLORS[rarity]}`,
                }}
              />
            </div>
            <div className="w-6 text-right text-xs font-bold" style={{ color: RARITY_COLORS[rarity] }}>{count}</div>
          </div>
        ))}
      </div>
      <p className="text-[10px] text-white/30 mt-3 text-center">Total: {total} specimens</p>
    </div>
  );
}