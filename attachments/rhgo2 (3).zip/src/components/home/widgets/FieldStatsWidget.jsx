import React, { useState, useEffect } from 'react';
import { TrendingUp, Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function FieldStatsWidget({ userEmail }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) return;
    (async () => {
      try {
        const userStats = await base44.entities.UserStats.filter({ created_by: userEmail });
        if (userStats[0]) {
          setStats(userStats[0]);
        }
      } catch {
        setStats(null);
      } finally {
        setLoading(false);
      }
    })();
  }, [userEmail]);

  if (loading) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="h-20 bg-white/5 rounded-lg animate-pulse" />
      </div>
    );
  }

  const total_finds = stats?.total_finds || 0;
  const verified = stats?.verified_discoveries || 0;
  const streak = stats?.current_session_streak || 0;

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(0,214,143,0.08)', border: '1px solid rgba(0,214,143,0.2)' }}>
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp style={{ color: '#00D68F', width: 16, height: 16 }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(0,214,143,0.8)' }}>Field Stats</p>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-xl p-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
          <p className="text-2xl font-bold text-white">{total_finds}</p>
          <p className="text-[10px] text-white/40 mt-1">Total Finds</p>
        </div>
        <div className="rounded-xl p-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
          <p className="text-2xl font-bold" style={{ color: '#F5B642' }}>{verified}</p>
          <p className="text-[10px] text-white/40 mt-1">Verified</p>
        </div>
        <div className="rounded-xl p-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
          <div className="flex items-center gap-1">
            <p className="text-2xl font-bold" style={{ color: '#7AE7FF' }}>{streak}</p>
            <Zap style={{ color: '#7AE7FF', width: 14, height: 14 }} />
          </div>
          <p className="text-[10px] text-white/40 mt-1">Days</p>
        </div>
      </div>
    </div>
  );
}