import React, { useState, useEffect } from 'react';
import { Camera, Clock } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ScanHistoryWidget({ userEmail }) {
  const [scans, setScans] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!userEmail) {
      setIsLoading(false);
      return;
    }
    base44.entities.Scans.filter({ created_by: userEmail }, '-created_date', 3)
      .then(data => setScans(data || []))
      .catch(() => setScans([]))
      .finally(() => setIsLoading(false));
  }, [userEmail]);

  if (isLoading) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="h-20 bg-white/5 rounded-lg animate-pulse" />
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(245,182,66,0.08)', border: '1px solid rgba(245,182,66,0.2)' }}>
      <div className="flex items-center gap-2 mb-3">
        <Camera style={{ color: '#F5B642', width: 16, height: 16 }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(245,182,66,0.8)' }}>Recent Scans</p>
      </div>
      <div className="space-y-2">
        {scans.length === 0 ? (
          <p className="text-xs text-white/35 text-center py-3">No scans yet</p>
        ) : (
          scans.map((scan) => (
            <div key={scan.id} className="rounded-xl p-2.5 flex items-center gap-2" style={{ background: 'rgba(255,255,255,0.04)' }}>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'rgba(245,182,66,0.15)' }}>
                <Camera style={{ color: '#F5B642', width: 14, height: 14 }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-white truncate">{scan.mineral_name || scan.name || 'Specimen'}</p>
                <p className="text-[10px] text-white/35 flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {new Date(scan.created_date).toLocaleDateString()}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}