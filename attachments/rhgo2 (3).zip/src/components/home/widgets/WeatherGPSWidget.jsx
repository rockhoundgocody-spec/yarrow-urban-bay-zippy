import React, { useState, useEffect } from 'react';
import { CloudSun, MapPin, Droplets, Wind } from 'lucide-react';

export default function WeatherGPSWidget() {
  const [location, setLocation] = useState(null);
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setLocation({ latitude, longitude });
        // In production, use a weather API (OpenWeatherMap, Weather.gov, etc.)
        setWeather({
          temp: 72,
          humidity: 65,
          windSpeed: 8,
          condition: 'Partly Cloudy',
        });
        setLoading(false);
      },
      () => {
        setLoading(false);
        setLocation(null);
      }
    );
  }, []);

  if (loading) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <div className="h-20 bg-white/5 rounded-lg animate-pulse" />
      </div>
    );
  }

  if (!location) {
    return (
      <div className="rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}>
        <p className="text-xs text-white/35">Enable location access</p>
      </div>
    );
  }

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(122,231,255,0.08)', border: '1px solid rgba(122,231,255,0.2)' }}>
      <div className="flex items-center gap-2 mb-3">
        <CloudSun style={{ color: '#7AE7FF', width: 16, height: 16 }} />
        <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(122,231,255,0.8)' }}>Weather & GPS</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-xl p-3" style={{ background: 'rgba(255,255,255,0.04)' }}>
          <p className="text-2xl font-bold text-white">{weather?.temp}°F</p>
          <p className="text-[10px] text-white/40 mt-1">{weather?.condition}</p>
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 rounded-lg p-2" style={{ background: 'rgba(255,255,255,0.04)' }}>
            <Droplets style={{ color: '#7AE7FF', width: 13, height: 13 }} />
            <span className="text-xs font-semibold text-white">{weather?.humidity}%</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-lg p-2" style={{ background: 'rgba(255,255,255,0.04)' }}>
            <Wind style={{ color: '#7AE7FF', width: 13, height: 13 }} />
            <span className="text-xs font-semibold text-white">{weather?.windSpeed} mph</span>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-1.5 mt-2 text-[10px] text-white/40">
        <MapPin className="w-3 h-3" />
        {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
      </div>
    </div>
  );
}