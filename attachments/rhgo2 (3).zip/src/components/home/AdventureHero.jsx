/**
 * AdventureHero — Home screen cinematic portal. Shock Pass v1.
 * Full-immersion front gate, not a dashboard header.
 */

import React from "react";
import { motion } from "framer-motion";
import { Camera, Map, Sparkles, ChevronRight } from "lucide-react";

// Animated crystal particle for background
function CrystalParticle({ x, y, size, delay, color }) {
  return (
    <motion.div
      className="absolute rounded-full"
      style={{ left: `${x}%`, top: `${y}%`, width: size, height: size, background: color, filter: "blur(1px)" }}
      animate={{ y: [0, -18, 0], opacity: [0.25, 0.7, 0.25], scale: [1, 1.3, 1] }}
      transition={{ duration: 4 + delay, repeat: Infinity, delay, ease: "easeInOut" }}
    />
  );
}

const PARTICLES = [
  { x: 8,  y: 20, size: 4, delay: 0,   color: "rgba(125,249,255,0.7)" },
  { x: 88, y: 15, size: 3, delay: 0.8, color: "rgba(255,215,0,0.6)" },
  { x: 15, y: 72, size: 5, delay: 1.2, color: "rgba(185,122,255,0.5)" },
  { x: 78, y: 60, size: 4, delay: 0.4, color: "rgba(0,255,198,0.6)" },
  { x: 50, y: 10, size: 3, delay: 1.8, color: "rgba(125,249,255,0.4)" },
  { x: 92, y: 40, size: 6, delay: 0.6, color: "rgba(255,215,0,0.4)" },
  { x: 30, y: 85, size: 3, delay: 2.1, color: "rgba(185,122,255,0.45)" },
];

export default function AdventureHero({ onScan, onExplore, currentInsight }) {
  return (
    <div
      className="relative overflow-hidden rounded-[30px]"
      style={{
        background: "linear-gradient(145deg, rgba(4,8,14,0.97) 0%, rgba(8,14,24,0.96) 50%, rgba(5,4,14,0.97) 100%)",
        border: "1px solid rgba(255,255,255,0.07)",
        boxShadow: "0 0 80px rgba(0,0,0,0.8), inset 0 1px 0 rgba(255,255,255,0.06)",
        minHeight: 320,
      }}
    >
      {/* Crystal chamber background radiance */}
      <div className="pointer-events-none absolute inset-0">
        <div style={{ position: "absolute", top: "-30%", left: "-20%", width: "70%", height: "70%", borderRadius: "50%", background: "radial-gradient(circle, rgba(91,192,255,0.12) 0%, transparent 60%)", filter: "blur(40px)" }} />
        <div style={{ position: "absolute", bottom: "-20%", right: "-15%", width: "60%", height: "60%", borderRadius: "50%", background: "radial-gradient(circle, rgba(185,122,255,0.10) 0%, transparent 60%)", filter: "blur(36px)" }} />
        <div style={{ position: "absolute", top: "30%", left: "40%", width: "50%", height: "50%", borderRadius: "50%", background: "radial-gradient(circle, rgba(255,215,0,0.07) 0%, transparent 60%)", filter: "blur(48px)" }} />
      </div>

      {/* Floating particles */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {PARTICLES.map((p, i) => <CrystalParticle key={i} {...p} />)}
      </div>

      {/* Grid overlay — geode texture */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.025]"
        style={{ backgroundImage: "linear-gradient(rgba(125,249,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(125,249,255,1) 1px, transparent 1px)", backgroundSize: "48px 48px" }}
      />

      {/* Content */}
      <div className="relative z-10 px-6 pt-8 pb-7">
        {/* Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: -6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex items-center gap-2 mb-5"
        >
          <motion.div
            animate={{ opacity: [0.7, 1, 0.7] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="h-1.5 w-1.5 rounded-full"
            style={{ background: "#00FFC6", boxShadow: "0 0 8px rgba(0,255,198,0.8)" }}
          />
          <span className="text-[10px] font-bold uppercase tracking-[0.28em]" style={{ color: "#00FFC6" }}>
            Discovery Active
          </span>
          <span className="text-[10px] text-white/20">·</span>
          <span className="text-[10px] text-white/30 tracking-wide">Field Intelligence Online</span>
        </motion.div>

        {/* Hero headline */}
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.08 }}
          className="text-[2.4rem] leading-[1.08] font-black tracking-tight text-white"
          style={{ letterSpacing: "-0.03em", textShadow: "0 0 60px rgba(125,249,255,0.15)" }}
        >
          Every rock<br />
          <span style={{ background: "linear-gradient(120deg, #7DF9FF 0%, #FFD700 55%, #B97AFF 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>
            hides a wonder.
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.18 }}
          className="mt-3 text-sm leading-6 max-w-xs"
          style={{ color: "rgba(255,255,255,0.45)" }}
        >
          AI crystal identification · live rarity radar · treasure-map explore
        </motion.p>

        {/* CTA stack */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.28 }}
          className="mt-6 flex flex-col gap-3"
        >
          {/* Primary — Reveal Specimen */}
          <button
            type="button"
            onClick={onScan}
            className="flex items-center justify-between rounded-2xl px-5 py-4 text-left transition-all active:scale-[0.98]"
            style={{
              background: "linear-gradient(120deg, rgba(125,249,255,0.18) 0%, rgba(0,255,198,0.12) 100%)",
              border: "1px solid rgba(125,249,255,0.32)",
              boxShadow: "0 0 24px rgba(125,249,255,0.15), inset 0 1px 0 rgba(125,249,255,0.12)",
            }}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "rgba(125,249,255,0.15)", border: "1px solid rgba(125,249,255,0.25)" }}>
                <Camera className="h-5 w-5" style={{ color: "#7DF9FF" }} />
              </div>
              <div>
                <div className="text-sm font-bold text-white">Reveal Specimen</div>
                <div className="text-[11px]" style={{ color: "rgba(125,249,255,0.6)" }}>AI crystal identification</div>
              </div>
            </div>
            <ChevronRight className="h-4 w-4" style={{ color: "rgba(125,249,255,0.4)" }} />
          </button>

          {/* Secondary — Wonders Near You */}
          <button
            type="button"
            onClick={onExplore}
            className="flex items-center justify-between rounded-2xl px-5 py-4 text-left transition-all active:scale-[0.98]"
            style={{
              background: "linear-gradient(120deg, rgba(255,215,0,0.10) 0%, rgba(255,150,0,0.08) 100%)",
              border: "1px solid rgba(255,215,0,0.22)",
              boxShadow: "0 0 20px rgba(255,215,0,0.08)",
            }}
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "rgba(255,215,0,0.12)", border: "1px solid rgba(255,215,0,0.20)" }}>
                <Map className="h-5 w-5" style={{ color: "#FFD700" }} />
              </div>
              <div>
                <div className="text-sm font-bold text-white">Wonders Near You</div>
                <div className="text-[11px]" style={{ color: "rgba(255,215,0,0.55)" }}>Live rarity radar · hotspot map</div>
              </div>
            </div>
            <ChevronRight className="h-4 w-4" style={{ color: "rgba(255,215,0,0.35)" }} />
          </button>
        </motion.div>

        {/* Clover insight strip */}
        {currentInsight && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-4 flex items-start gap-2.5 rounded-2xl px-4 py-3"
            style={{ background: "rgba(185,122,255,0.07)", border: "1px solid rgba(185,122,255,0.14)" }}
          >
            <Sparkles className="h-3.5 w-3.5 mt-0.5 shrink-0" style={{ color: "#B97AFF" }} />
            <span className="text-[11px] leading-5" style={{ color: "rgba(255,255,255,0.45)" }}>
              {currentInsight}
            </span>
          </motion.div>
        )}
      </div>
    </div>
  );
}