/**
 * CinematicOpener — multi-act Hollywood-grade intro.
 * Six acts: Genesis → Formation → Reveal → Awakening → Manifesto → Call.
 * Video plays ONCE (no loop). Extended timeline (~24s auto-exit).
 * Portal onto app-shell to escape z-index stacking.
 */
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'framer-motion';

const VIDEO_URL = "https://media.base44.com/videos/public/699b620aabda6503e72aa4f2/294cce45e_generated_video.mp4";
const TITLE = "ROCKHOUND-GO";

// ── Extended timeline (ms) — six acts ──
const T = {
  // Act 1 — Genesis
  VOID_HUM:      0,
  SPARK:       400,
  SHOCKWAVE:   900,
  RINGS:      1200,
  // Act 2 — Formation
  PARTICLES:  1700,
  CRYSTAL_ASSEMBLE: 2400,
  PARTICLES_2: 3100,
  // Act 3 — Reveal
  VIDEO_IN:   3800,
  SCAN_SWEEP: 4400,
  GRID:       5000,
  // Act 4 — Awakening
  TITLE:      5800,
  SUBTITLE:   7000,
  // Act 5 — Manifesto
  LORE:       7900,
  LORE_2:     8700,
  PILLS:      9600,
  DIVIDER:   10400,
  TAGLINE:   11100,
  // Act 6 — Call
  CTA:       11900,
  AUTO_EXIT: 24000,
};

const ACT_CAPTIONS = [
  { at: 0,    text: 'I · GENESIS',     sub: 'From the void' },
  { at: 1700, text: 'II · FORMATION',  sub: 'Crystals assemble' },
  { at: 3800, text: 'III · REVEAL',    sub: 'The earth opens' },
  { at: 5800, text: 'IV · AWAKENING',  sub: 'Intelligence emerges' },
  { at: 7900, text: 'V · MANIFESTO',   sub: 'The mission' },
  { at: 11900,text: 'VI · CALL',       sub: 'Begin' },
];

const PILLS = ['⚡ Scan AI', '🗺 Field Maps', '💎 Collect', '🔬 Identify', '🌍 Explore'];

// Deterministic particle positions — two waves
const PARTICLES = Array.from({ length: 36 }, (_, i) => {
  const angle = (i / 36) * Math.PI * 2;
  const r = 140 + (i % 6) * 28;
  return {
    x: Math.cos(angle) * r,
    y: Math.sin(angle) * r,
    size: 2 + (i % 4),
    delay: i * 0.035,
    color: i % 3 === 0 ? '#8D7CFF' : i % 3 === 1 ? '#7AE7FF' : '#D4AF37',
  };
});

const PARTICLES_2 = Array.from({ length: 20 }, (_, i) => {
  const angle = (i / 20) * Math.PI * 2 + 0.3;
  const r = 90 + (i % 4) * 22;
  return {
    x: Math.cos(angle) * r,
    y: Math.sin(angle) * r,
    size: 1.5 + (i % 3),
    delay: i * 0.06,
    color: i % 2 === 0 ? '#7AE7FF' : '#D4AF37',
  };
});

// Constellation stars — slow drift
const STARS = Array.from({ length: 48 }, (_, i) => ({
  x: (i * 53) % 100,
  y: (i * 37) % 100,
  size: 0.8 + (i % 3) * 0.4,
  delay: (i % 12) * 0.3,
  duration: 3 + (i % 5),
}));

export default function CinematicOpener({ onComplete }) {
  const [videoReady, setVideoReady] = useState(false);
  const [phase, setPhase] = useState('loading');
  const [reached, setReached] = useState(new Set());
  const [skipVisible, setSkipVisible] = useState(false);
  const [actIndex, setActIndex] = useState(0);
  const doneRef = useRef(false);
  const videoRef = useRef(null);
  const timersRef = useRef([]);

  const reach = useCallback((key) => setReached(prev => new Set([...prev, key])), []);
  const has = useCallback((key) => reached.has(key), [reached]);

  // Preload video silently
  useEffect(() => {
    const vid = document.createElement('video');
    vid.src = VIDEO_URL;
    vid.muted = true;
    vid.playsInline = true;
    vid.preload = 'auto';
    const onReady = () => setVideoReady(true);
    vid.addEventListener('canplaythrough', onReady, { once: true });
    const fallback = setTimeout(() => setVideoReady(true), 3000);
    vid.load();
    return () => {
      vid.removeEventListener('canplaythrough', onReady);
      clearTimeout(fallback);
    };
  }, []);

  // Fire the timeline once video preloaded
  useEffect(() => {
    if (!videoReady) return;
    setPhase('intro');

    const t = (fn, ms) => {
      const id = setTimeout(fn, ms);
      timersRef.current.push(id);
    };

    // Act markers
    ACT_CAPTIONS.forEach((cap, i) => t(() => setActIndex(i), cap.at));

    // Timeline reaches
    t(() => reach('VOID_HUM'),     T.VOID_HUM);
    t(() => reach('SPARK'),        T.SPARK);
    t(() => reach('SHOCKWAVE'),    T.SHOCKWAVE);
    t(() => reach('RINGS'),        T.RINGS);
    t(() => reach('PARTICLES'),    T.PARTICLES);
    t(() => reach('CRYSTAL_ASSEMBLE'), T.CRYSTAL_ASSEMBLE);
    t(() => reach('PARTICLES_2'),  T.PARTICLES_2);
    t(() => reach('VIDEO_IN'),     T.VIDEO_IN);
    t(() => reach('SCAN_SWEEP'),   T.SCAN_SWEEP);
    t(() => reach('GRID'),         T.GRID);
    t(() => reach('TITLE'),        T.TITLE);
    t(() => reach('SUBTITLE'),     T.SUBTITLE);
    t(() => reach('LORE'),         T.LORE);
    t(() => reach('LORE_2'),       T.LORE_2);
    t(() => reach('PILLS'),        T.PILLS);
    t(() => reach('DIVIDER'),      T.DIVIDER);
    t(() => reach('TAGLINE'),      T.TAGLINE);
    t(() => reach('CTA'),          T.CTA);
    t(() => setSkipVisible(true), 1500);
    t(() => triggerComplete(),     T.AUTO_EXIT);

    return () => timersRef.current.forEach(clearTimeout);
  }, [videoReady]);  

  const triggerComplete = useCallback(() => {
    if (doneRef.current) return;
    doneRef.current = true;
    setPhase('exiting');
    setTimeout(() => onComplete?.(), 1100);
  }, [onComplete]);

  const content = (
    <AnimatePresence>
      {phase !== 'exiting' && (
        <motion.div
          key="cinematic"
          style={{
            position: 'absolute', inset: 0, zIndex: 999999,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            overflow: 'hidden',
            background: '#000',
          }}
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1.1, ease: 'easeInOut' }}
        >
          {/* Loading state — cinematic gem pulse before video ready */}
          {!videoReady && (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 20 }}>
              <motion.div
                style={{
                  width: 72, height: 72, borderRadius: '50%',
                  background: 'radial-gradient(circle, rgba(141,124,255,0.25) 0%, transparent 70%)',
                  border: '1.5px solid rgba(141,124,255,0.45)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
                animate={{ scale: [1, 1.12, 1], opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
              >
                <svg viewBox="0 0 64 64" width="36" height="36" fill="none">
                  <polygon points="32,4 56,20 56,44 32,60 8,44 8,20" fill="rgba(141,124,255,0.15)" stroke="rgba(141,124,255,0.7)" strokeWidth="1.5" />
                  <polygon points="32,4 56,20 32,28" fill="rgba(180,170,255,0.2)" />
                  <polygon points="8,20 32,28 32,4" fill="rgba(122,231,255,0.12)" />
                </svg>
              </motion.div>
              <motion.p
                style={{ fontSize: 9, color: 'rgba(141,124,255,0.5)', letterSpacing: '0.3em', textTransform: 'uppercase', fontWeight: 700 }}
                animate={{ opacity: [0.4, 1, 0.4] }}
                transition={{ duration: 1.6, repeat: Infinity }}
              >
                Initializing
              </motion.p>
            </div>
          )}

          {/* ── VIDEO — mounted after preload, plays ONCE (no loop) ── */}
          {has('VIDEO_IN') && (
            <motion.video
              ref={videoRef}
              autoPlay muted playsInline
              style={{
                position: 'absolute', inset: 0,
                width: '100%', height: '100%', objectFit: 'cover',
              }}
              initial={{ opacity: 0, scale: 1.08 }}
              animate={{ opacity: 0.88, scale: 1 }}
              transition={{ duration: 3.0, ease: [0.23, 1, 0.32, 1] }}
            >
              <source src={VIDEO_URL} type="video/mp4" />
            </motion.video>
          )}

          {/* ── Cinematic color grade + vignette ── */}
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0.0) 15%, rgba(0,0,0,0.72) 100%)',
          }} />
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none',
            background: 'linear-gradient(180deg, rgba(10,4,30,0.55) 0%, rgba(4,2,14,0.20) 40%, rgba(4,2,14,0.20) 60%, rgba(2,1,10,0.75) 100%)',
            mixBlendMode: 'multiply',
          }} />
          {/* Letterbox bars */}
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 72, background: 'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, transparent 100%)', pointerEvents: 'none' }} />
          <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 100, background: 'linear-gradient(0deg, rgba(0,0,0,0.90) 0%, transparent 100%)', pointerEvents: 'none' }} />

          {/* ── Constellation starfield (Act 1+) ── */}
          {has('VOID_HUM') && (
            <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
              {STARS.map((s, i) => (
                <motion.div
                  key={i}
                  style={{
                    position: 'absolute',
                    left: `${s.x}%`, top: `${s.y}%`,
                    width: s.size, height: s.size,
                    borderRadius: '50%',
                    background: 'rgba(200,220,255,0.8)',
                    boxShadow: `0 0 ${s.size * 4}px rgba(180,200,255,0.5)`,
                  }}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: [0, 0.8, 0.2, 0.6, 0] }}
                  transition={{ duration: s.duration, delay: s.delay, repeat: Infinity, ease: 'easeInOut' }}
                />
              ))}
            </div>
          )}

          {/* ── Deep earth rumble pulse (Act 1) ── */}
          {has('VOID_HUM') && !has('VIDEO_IN') && (
            <motion.div
              style={{
                position: 'absolute', inset: 0, pointerEvents: 'none',
                background: 'radial-gradient(ellipse at 50% 60%, rgba(141,124,255,0.06) 0%, transparent 60%)',
              }}
              animate={{ opacity: [0, 0.8, 0], scale: [0.9, 1.1, 0.9] }}
              transition={{ duration: 2.2, repeat: 3, ease: 'easeInOut' }}
            />
          )}

          {/* ── Initial spark (Act 1) ── */}
          {has('SPARK') && (
            <motion.div
              style={{
                position: 'absolute', width: 4, height: 4, borderRadius: '50%',
                background: '#FFFFFF', pointerEvents: 'none',
                boxShadow: '0 0 60px rgba(255,255,255,0.9), 0 0 120px rgba(141,124,255,0.6)',
              }}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: [0, 3, 0], opacity: [0, 1, 0] }}
              transition={{ duration: 0.9, ease: 'easeOut' }}
            />
          )}

          {/* ── Geological grid ── */}
          {has('GRID') && (
            <motion.div
              style={{
                position: 'absolute', inset: 0, pointerEvents: 'none',
                backgroundImage: `linear-gradient(0deg, rgba(122,231,255,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(122,231,255,0.035) 1px, transparent 1px)`,
                backgroundSize: '80px 80px',
              }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 3.0, ease: 'easeIn' }}
            />
          )}

          {/* ── Scan sweep line (Act 3) ── */}
          {has('SCAN_SWEEP') && (
            <motion.div
              style={{
                position: 'absolute', left: 0, right: 0, height: 2, pointerEvents: 'none',
                background: 'linear-gradient(90deg, transparent, rgba(122,231,255,0.9), rgba(141,124,255,0.6), transparent)',
                boxShadow: '0 0 24px rgba(122,231,255,0.6)',
              }}
              initial={{ top: '8%', opacity: 0 }}
              animate={{ top: ['8%', '92%', '8%'], opacity: [0, 1, 1, 0] }}
              transition={{ duration: 4.5, ease: 'easeInOut', times: [0, 0.4, 0.7, 1] }}
            />
          )}

          {/* ── Shockwave ring ── */}
          {has('SHOCKWAVE') && (
            <motion.div
              style={{ position: 'absolute', borderRadius: '50%', pointerEvents: 'none', width: 10, height: 10, border: '2px solid rgba(141,124,255,0.9)' }}
              initial={{ scale: 1, opacity: 0.9 }}
              animate={{ scale: 80, opacity: 0 }}
              transition={{ duration: 1.6, ease: [0.23, 1, 0.32, 1] }}
            />
          )}
          {has('RINGS') && (
            <motion.div
              style={{ position: 'absolute', borderRadius: '50%', pointerEvents: 'none', width: 10, height: 10, border: '1.5px solid rgba(122,231,255,0.6)' }}
              initial={{ scale: 1, opacity: 0.7 }}
              animate={{ scale: 60, opacity: 0 }}
              transition={{ duration: 2.0, ease: [0.23, 1, 0.32, 1] }}
            />
          )}

          {/* ── Ambient core glow ── */}
          {has('SHOCKWAVE') && (
            <motion.div
              style={{ position: 'absolute', borderRadius: '50%', pointerEvents: 'none', width: 700, height: 700, background: 'radial-gradient(circle, rgba(141,124,255,0.18) 0%, rgba(122,231,255,0.06) 40%, transparent 70%)', filter: 'blur(60px)' }}
              initial={{ opacity: 0, scale: 0.3 }}
              animate={{ opacity: [0, 1, 0.7], scale: 1 }}
              transition={{ duration: 2.5, ease: [0.23, 1, 0.32, 1] }}
            />
          )}

          {/* ── Particle burst wave 1 ── */}
          {has('PARTICLES') && (
            <div style={{ position: 'absolute', pointerEvents: 'none' }}>
              {PARTICLES.map((p, i) => (
                <motion.div
                  key={i}
                  style={{ position: 'absolute', width: p.size, height: p.size, borderRadius: '50%', background: p.color, boxShadow: `0 0 ${p.size * 3}px ${p.color}` }}
                  initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
                  animate={{ x: p.x, y: p.y, opacity: 0, scale: 0 }}
                  transition={{ duration: 1.8, delay: p.delay, ease: [0.23, 1, 0.32, 1] }}
                />
              ))}
            </div>
          )}

          {/* ── Crystal shard assembly (Act 2) — hexagon forms from shards ── */}
          {has('CRYSTAL_ASSEMBLE') && (
            <motion.div
              style={{ position: 'absolute', pointerEvents: 'none', width: 120, height: 120, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
              initial={{ opacity: 0, scale: 0.4, rotate: -30 }}
              animate={{ opacity: [0, 1, 1, 0], scale: [0.4, 1.1, 1, 1.4], rotate: [-30, 0, 0, 15] }}
              transition={{ duration: 3.2, ease: [0.23, 1, 0.32, 1] }}
            >
              <svg viewBox="0 0 120 120" width="120" height="120" fill="none">
                {[0, 60, 120, 180, 240, 300].map((rot) => (
                  <polygon
                    key={rot}
                    points="60,8 84,28 84,58 60,68 36,58 36,28"
                    transform={`rotate(${rot} 60 60)`}
                    fill="rgba(141,124,255,0.10)"
                    stroke="rgba(141,124,255,0.7)"
                    strokeWidth="1"
                  />
                ))}
                <circle cx="60" cy="60" r="6" fill="rgba(122,231,255,0.5)" />
              </svg>
            </motion.div>
          )}

          {/* ── Particle burst wave 2 (Act 2) ── */}
          {has('PARTICLES_2') && (
            <div style={{ position: 'absolute', pointerEvents: 'none' }}>
              {PARTICLES_2.map((p, i) => (
                <motion.div
                  key={i}
                  style={{ position: 'absolute', width: p.size, height: p.size, borderRadius: '50%', background: p.color, boxShadow: `0 0 ${p.size * 3}px ${p.color}` }}
                  initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
                  animate={{ x: p.x, y: p.y, opacity: 0, scale: 0 }}
                  transition={{ duration: 1.4, delay: p.delay, ease: [0.23, 1, 0.32, 1] }}
                />
              ))}
            </div>
          )}

          {/* ── Orbiting rings + diamond sparks ── */}
          {has('RINGS') && (
            <>
              <motion.div
                style={{ position: 'absolute', borderRadius: '50%', pointerEvents: 'none', width: 280, height: 280, border: '1px solid rgba(141,124,255,0.18)' }}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1, rotate: 360 }}
                transition={{ opacity: { duration: 1.5 }, scale: { duration: 1.5, ease: [0.34, 1.56, 0.64, 1] }, rotate: { duration: 28, repeat: Infinity, ease: 'linear' } }}
              />
              <motion.div
                style={{ position: 'absolute', borderRadius: '50%', pointerEvents: 'none', width: 360, height: 360, border: '1px solid rgba(122,231,255,0.09)' }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1, rotate: -360 }}
                transition={{ opacity: { duration: 2.0, delay: 0.3 }, rotate: { duration: 42, repeat: Infinity, ease: 'linear' } }}
              />
              {[0, 90, 180, 270].map((deg, i) => (
                <motion.div
                  key={deg}
                  style={{ position: 'absolute', width: 5, height: 5, background: i % 2 === 0 ? '#8D7CFF' : '#7AE7FF', borderRadius: 1, transform: `rotate(${deg}deg) translateY(-140px) rotate(-${deg}deg)`, boxShadow: `0 0 8px ${i % 2 === 0 ? '#8D7CFF' : '#7AE7FF'}` }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: [0, 1, 0.8, 1], scale: 1 }}
                  transition={{ duration: 1.0, delay: 0.6 + i * 0.15 }}
                />
              ))}
            </>
          )}

          {/* ── Act caption (top-left, cinematic chapter marker) ── */}
          {videoReady && (
            <AnimatePresence mode="wait">
              <motion.div
                key={actIndex}
                style={{ position: 'absolute', top: 'calc(env(safe-area-inset-top, 0px) + 90px)', left: 24, zIndex: 20, pointerEvents: 'none' }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.7, ease: 'easeOut' }}
              >
                <p style={{ fontSize: 8, fontWeight: 800, letterSpacing: '0.3em', color: 'rgba(212,175,55,0.7)', textTransform: 'uppercase' }}>
                  {ACT_CAPTIONS[actIndex]?.text}
                </p>
                <p style={{ fontSize: 8, color: 'rgba(255,255,255,0.3)', letterSpacing: '0.15em', marginTop: 2 }}>
                  {ACT_CAPTIONS[actIndex]?.sub}
                </p>
              </motion.div>
            </AnimatePresence>
          )}

          {/* ── Main text content ── */}
          <div style={{
            position: 'relative', zIndex: 10,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', textAlign: 'center',
            padding: '0 28px', marginTop: 32,
          }}>
            {/* Title — letter forge */}
            {has('TITLE') && (
              <motion.div
                style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 4 }}
                initial="hidden"
                animate="visible"
                variants={{ visible: { transition: { staggerChildren: 0.06 } } }}
              >
                {TITLE.split('').map((letter, i) => (
                  <motion.span
                    key={i}
                    variants={{
                      hidden: { opacity: 0, y: 50, rotateX: -90, scale: 0.8, filter: 'blur(16px)' },
                      visible: { opacity: 1, y: 0, rotateX: 0, scale: 1, filter: 'blur(0px)' },
                    }}
                    transition={{ duration: 0.7, ease: [0.23, 1, 0.32, 1] }}
                    style={{
                      fontSize: letter === '-' ? 24 : 32,
                      fontWeight: 900,
                      letterSpacing: '-0.01em',
                      fontFamily: "'Sora', sans-serif",
                      background: 'linear-gradient(160deg, #FFFFFF 0%, #E0D8FF 20%, #C4B5FD 40%, #7AE7FF 70%, #D4AF37 100%)',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      backgroundClip: 'text',
                      display: 'inline-block',
                      filter: 'drop-shadow(0 2px 6px rgba(141,124,255,0.35))',
                      width: letter === ' ' ? 8 : 'auto',
                      transformOrigin: 'bottom center',
                    }}
                  >
                    {letter}
                  </motion.span>
                ))}
              </motion.div>
            )}

            {/* Subtitle */}
            {has('SUBTITLE') && (
              <motion.p
                initial={{ opacity: 0, letterSpacing: '0.7em', y: 6 }}
                animate={{ opacity: 1, letterSpacing: '0.30em', y: 0 }}
                transition={{ duration: 1.8, ease: 'easeOut' }}
                style={{ color: 'rgba(122,231,255,0.95)', fontSize: 10, fontWeight: 700, textTransform: 'uppercase', marginBottom: 22, marginTop: 2 }}
              >
                Geological Intelligence Platform
              </motion.p>
            )}

            {/* Lore line 1 */}
            {has('LORE') && (
              <motion.p
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.4, ease: 'easeOut' }}
                style={{ color: 'rgba(255,255,255,0.82)', fontSize: 13, maxWidth: 260, lineHeight: 1.75, marginBottom: 4, fontStyle: 'italic' }}
              >
                The earth holds secrets older than memory.
              </motion.p>
            )}
            {/* Lore line 2 */}
            {has('LORE_2') && (
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.4, ease: 'easeOut' }}
                style={{ color: 'rgba(255,255,255,0.65)', fontSize: 12, maxWidth: 260, lineHeight: 1.75, marginBottom: 22, fontStyle: 'italic' }}
              >
                Some are waiting to be found.
              </motion.p>
            )}

            {/* Feature pills */}
            {has('PILLS') && (
              <motion.div
                style={{ display: 'flex', gap: 8, marginBottom: 22, flexWrap: 'wrap', justifyContent: 'center', maxWidth: 280 }}
                initial="hidden"
                animate="visible"
                variants={{ visible: { transition: { staggerChildren: 0.14 } } }}
              >
                {PILLS.map((label) => (
                  <motion.span
                    key={label}
                    variants={{ hidden: { opacity: 0, y: 14, scale: 0.85 }, visible: { opacity: 1, y: 0, scale: 1 } }}
                    transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
                    style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.1em', padding: '6px 12px', borderRadius: 24, background: 'rgba(141,124,255,0.14)', border: '1px solid rgba(141,124,255,0.35)', color: 'rgba(220,215,255,0.95)', backdropFilter: 'blur(8px)' }}
                  >
                    {label}
                  </motion.span>
                ))}
              </motion.div>
            )}

            {/* Horizon divider */}
            {has('DIVIDER') && (
              <motion.div
                style={{ height: 1, background: 'linear-gradient(90deg, transparent, rgba(141,124,255,0.7), rgba(122,231,255,0.5), rgba(212,175,55,0.4), transparent)', marginBottom: 20, width: 240 }}
                initial={{ scaleX: 0, opacity: 0 }}
                animate={{ scaleX: 1, opacity: 1 }}
                transition={{ duration: 1.2, ease: [0.23, 1, 0.32, 1] }}
              />
            )}

            {/* Tagline */}
            {has('TAGLINE') && (
              <motion.p
                initial={{ opacity: 0, letterSpacing: '0.5em' }}
                animate={{ opacity: 1, letterSpacing: '0.22em' }}
                transition={{ duration: 1.6, ease: 'easeOut' }}
                style={{ color: '#D4AF37', fontSize: 11, fontWeight: 800, letterSpacing: '0.22em', textTransform: 'uppercase', marginBottom: 32, textShadow: '0 0 20px rgba(212,175,55,0.6)' }}
              >
                Discover · Identify · Collect
              </motion.p>
            )}

            {/* CTA */}
            {has('CTA') && (
              <motion.button
                initial={{ opacity: 0, scale: 0.75, y: 24 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.9, ease: [0.34, 1.56, 0.64, 1] }}
                onClick={triggerComplete}
                style={{
                  background: 'linear-gradient(135deg, rgba(141,124,255,0.28) 0%, rgba(80,50,220,0.20) 50%, rgba(0,214,143,0.12) 100%)',
                  border: '1.5px solid rgba(141,124,255,0.85)',
                  boxShadow: '0 0 50px rgba(141,124,255,0.65), 0 0 100px rgba(141,124,255,0.22), inset 0 1px 0 rgba(255,255,255,0.14)',
                  borderRadius: 20, padding: '18px 64px', color: '#E0D8FF', fontSize: 15, fontWeight: 800,
                  letterSpacing: '0.26em', textTransform: 'uppercase', cursor: 'pointer', position: 'relative', overflow: 'hidden',
                  minHeight: 'unset', minWidth: 'unset',
                }}
              >
                <motion.div
                  style={{ position: 'absolute', top: 0, bottom: 0, width: '50%', background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)', skewX: '-15deg' }}
                  animate={{ x: ['-120%', '260%'] }}
                  transition={{ duration: 1.8, repeat: Infinity, repeatDelay: 1.2, ease: 'easeInOut' }}
                />
                Enter Field
              </motion.button>
            )}
          </div>

          {/* Skip */}
          <AnimatePresence>
            {skipVisible && !has('CTA') && (
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.8 }}
                onClick={triggerComplete}
                style={{ position: 'absolute', bottom: 44, right: 24, color: 'rgba(255,255,255,0.22)', fontSize: 10, fontWeight: 600, letterSpacing: '0.15em', textTransform: 'uppercase', cursor: 'pointer', background: 'none', border: 'none', minHeight: 'unset', minWidth: 'unset' }}
              >
                Skip →
              </motion.button>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );

  const shell = document.getElementById('app-shell') || document.body;
  return createPortal(content, shell);
}