import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { createPageUrl } from "@/utils";
import { motion } from "framer-motion";
import {
  Sparkles, MapPin, BookOpen, ArrowRight, Star,
  Camera, Zap, TrendingUp, Compass, RefreshCw } from
"lucide-react";

const INTEREST_STORAGE_KEY = "rh_search_history";

function getStoredInterests() {
  try {
    return JSON.parse(localStorage.getItem(INTEREST_STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function FeedCard({ icon: Icon, label, title, subtitle, href, color = "cyan", badge }) {
  const colorMap = {
    cyan: "text-[var(--quantum-cyan)] border-[var(--quantum-cyan)]/20",
    magenta: "text-[var(--quantum-magenta)] border-[var(--quantum-magenta)]/20",
    green: "text-[var(--quantum-green)] border-[var(--quantum-green)]/20",
    violet: "text-[var(--quantum-violet)] border-[var(--quantum-violet)]/20",
    orange: "text-[var(--quantum-orange)] border-[var(--quantum-orange)]/20"
  };
  const cls = colorMap[color] || colorMap.cyan;

  return (
    <Link to={href} className={`group block holographic-glass rounded-xl p-4 border ${cls} hover:scale-[1.02] transition-all duration-300`}>
      <div className="flex items-start gap-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${cls} bg-white/5`}>
          <Icon className="lucide lucide-camera w-6 h-6" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-0.5">
            <span className="text-[10px] font-semibold uppercase tracking-widest text-white/30">{label}</span>
            {badge &&
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/5 ${cls}`}>{badge}</span>
            }
          </div>
          <p className="text-sm font-semibold text-white truncate">{title}</p>
          {subtitle && <p className="text-xs text-white/40 mt-0.5 truncate">{subtitle}</p>}
        </div>
        <ArrowRight className="w-3.5 h-3.5 text-white/20 group-hover:text-white/50 shrink-0 mt-1 transition-colors" />
      </div>
    </Link>);

}

export default function PersonalizedFeed() {
  const [user, setUser] = useState(null);
  const [interests, setInterests] = useState([]);
  const [feedItems, setFeedItems] = useState([]);
  const [isBuilding, setIsBuilding] = useState(true);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    setInterests(getStoredInterests());
  }, []);

  // User's specimens (collection)
  const { data: specimens = [] } = useQuery({
    queryKey: ["mySpecimens"],
    queryFn: () => base44.entities.Specimen.list("-created_date", 10),
    enabled: !!user
  });

  // Saved locations
  const { data: savedLocations = [] } = useQuery({
    queryKey: ["savedLocations"],
    queryFn: () => base44.entities.RockhoundingLocation.filter({ is_saved: true }, "-updated_date", 10),
    enabled: !!user
  });

  // Top-rated locations for discovery
  const { data: topLocations = [] } = useQuery({
    queryKey: ["topLocations"],
    queryFn: () => base44.entities.RockhoundingLocation.list("-rating_avg", 20)
  });

  // Build the personalized feed
  const specimenIds = specimens.map((s) => s.id).join(",");
  const savedIds_str = savedLocations.map((l) => l.id).join(",");
  const topIds_str = topLocations.map((l) => l.id).join(",");

  useEffect(() => {
    if (!topLocations.length) return;
    setIsBuilding(true);

    const items = [];

    const collectedMinerals = specimens.map((s) => s.name?.toLowerCase()).filter(Boolean);
    const savedMinerals = savedLocations.flatMap((l) => l.minerals_found || []).map((m) => m.toLowerCase());
    const allInterests = [...new Set([...collectedMinerals, ...savedMinerals, ...interests.map((i) => i.toLowerCase())])];

    if (allInterests.length > 0) {
      const interestsSet = new Set(allInterests);
      const matched = topLocations.filter((loc) => {
        const minerals = loc.minerals_found || [];
        return minerals.some((m) => {
          const mLower = m.toLowerCase();
          if (interestsSet.has(mLower)) return true;
          return allInterests.some((interest) => mLower.includes(interest) || interest.includes(mLower));
        });
      });

      matched.slice(0, 3).forEach((loc) => {
        const matchedMineral = (loc.minerals_found || []).find((m) => {
          const mLower = m.toLowerCase();
          if (interestsSet.has(mLower)) return true;
          return allInterests.some((i) => mLower.includes(i) || i.includes(mLower));
        });
        items.push({
          id: `loc-${loc.id}`,
          icon: MapPin,
          label: "Based on your interests",
          title: loc.name,
          subtitle: `${matchedMineral || loc.minerals_found?.[0] || "minerals"} • ${loc.state || ""}`,
          href: createPageUrl("RockhoundingMap"),
          color: "cyan",
          badge: loc.legality_status || "Public",
          priority: 10
        });
      });
    }

    const savedIds = new Set(savedLocations.map((l) => l.id));
    const unsavedTop = topLocations.
    filter((l) => !savedIds.has(l.id) && l.rating_avg > 3.5).
    slice(0, 2);
    unsavedTop.forEach((loc) => {
      items.push({
        id: `disc-${loc.id}`,
        icon: Compass,
        label: "New discovery",
        title: loc.name,
        subtitle: `⭐ ${loc.rating_avg?.toFixed(1) || "?"} • ${loc.minerals_found?.slice(0, 2).join(", ") || ""}`,
        href: createPageUrl("RockhoundingMap"),
        color: "green",
        badge: loc.state,
        priority: 7
      });
    });

    if (specimens.length < 5) {
      items.push({
        id: "id-cta",
        icon: Camera,
        label: "Grow your collection",
        title: "Identify a new specimen",
        subtitle: `You have ${specimens.length} specimen${specimens.length !== 1 ? "s" : ""} — keep collecting!`,
        href: createPageUrl("Identify"),
        color: "magenta",
        badge: "+50 XP",
        priority: 6
      });
    }

    if (specimens.length > 0) {
      const recent = specimens[0];
      items.push({
        id: `learn-${recent.id}`,
        icon: BookOpen,
        label: "Learn more",
        title: `Dive deeper into ${recent.name}`,
        subtitle: `${recent.category || "mineral"} • Mohs ${recent.hardness || "?"}`,
        href: createPageUrl("LearningCenter"),
        color: "violet",
        priority: 5
      });
    }

    if (savedLocations.length > 0) {
      const next = savedLocations[0];
      items.push({
        id: `saved-${next.id}`,
        icon: Star,
        label: "Saved spot",
        title: next.name,
        subtitle: `${next.minerals_found?.slice(0, 2).join(", ") || ""}${next.state ? ` • ${next.state}` : ""}`,
        href: createPageUrl("RockhoundingMap"),
        color: "orange",
        badge: "Plan trip",
        priority: 8
      });
    }

    const trendingMinerals = ["Amethyst", "Quartz", "Obsidian", "Jasper", "Pyrite"];
    items.push({
      id: "trending",
      icon: TrendingUp,
      label: "Trending",
      title: `${trendingMinerals[0]} collecting tips`,
      subtitle: "Explore the learning center",
      href: createPageUrl("LearningCenter"),
      color: "cyan",
      priority: 3
    });

    items.sort((a, b) => b.priority - a.priority);
    setFeedItems(items.slice(0, 6));
    setIsBuilding(false);
     
  }, [specimenIds, savedIds_str, topIds_str]);

  if (!user) return null;

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="max-w-6xl mx-auto px-6 py-12">
      
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="lucide lucide-sparkles w-14 h-6 text-[var(--quantum-cyan)]" />
            <span className="text-xs font-semibold uppercase tracking-widest text-[var(--quantum-cyan)]/60">
              Personalized for you
            </span>
          </div>
          <h2 className="text-2xl md:text-3xl font-bold text-white">
            Your Discovery Feed
          </h2>
        </div>
        {isBuilding &&
        <RefreshCw className="w-4 h-4 text-white/30 animate-spin" />
        }
      </div>

      {feedItems.length === 0 && !isBuilding ?
      <div className="holographic-glass rounded-2xl p-8 text-center border border-white/10">
          <Zap className="w-8 h-8 text-[var(--quantum-cyan)]/40 mx-auto mb-3" />
          <p className="text-white/40 text-sm">Start identifying rocks and saving locations to personalize your feed!</p>
          <Link
          to={createPageUrl("Identify")}
          className="inline-flex items-center gap-2 mt-4 px-4 py-2 rounded-lg text-sm font-medium text-[var(--quantum-cyan)] border border-[var(--quantum-cyan)]/30 hover:bg-[var(--quantum-cyan)]/10 transition-all">
          
            <Camera className="w-4 h-4" /> Identify your first rock
          </Link>
        </div> :

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {feedItems.map((item, i) => {
          const { id, ...cardProps } = item;
          return (
            <motion.div
              key={id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07, duration: 0.4 }}>
              
                <FeedCard {...cardProps} />
              </motion.div>);

        })}
        </div>
      }
    </motion.section>);

}