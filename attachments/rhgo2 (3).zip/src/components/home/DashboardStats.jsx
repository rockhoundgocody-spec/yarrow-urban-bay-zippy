import React from "react";
import { Gem, MapPin, Camera, Trophy, Star, Flame } from "lucide-react";

const STAT_CONFIGS = [
{ key: "specimens", label: "Specimens", icon: Gem, color: "#a855f7" },
{ key: "locations", label: "Sites Visited", icon: MapPin, color: "#00f5ff" },
{ key: "scans", label: "Scans", icon: Camera, color: "#ff00ff" },
{ key: "xp", label: "XP", icon: Star, color: "#ffd700" },
{ key: "badges", label: "Badges", icon: Trophy, color: "#00ffaa" },
{ key: "streak", label: "Day Streak", icon: Flame, color: "#ff6600" }];


export default function DashboardStats({ stats = {} }) {
  return (
    <div className="grid grid-cols-3 gap-2.5">
      {STAT_CONFIGS.map(({ key, label, icon: Icon, color }) =>
      <div
        key={key}
        className="rounded-2xl border border-white/8 p-3.5 text-center"
        style={{ background: `${color}08` }}>
        
          <Icon className="lucide lucide-camera w-5 h-5 mx-auto mb-1.5" style={{ color }} />
          <div className="text-xl font-bold text-white">{stats[key] ?? 0}</div>
          <div className="text-[10px] text-white/40 mt-0.5">{label}</div>
        </div>
      )}
    </div>);

}