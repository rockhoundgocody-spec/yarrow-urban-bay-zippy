import React, { useState, useEffect } from 'react';
import { Grid3x3, X } from 'lucide-react';
import FieldStatsWidget from './widgets/FieldStatsWidget';
import ScanHistoryWidget from './widgets/ScanHistoryWidget';
import WeatherGPSWidget from './widgets/WeatherGPSWidget';
import NearbyDiscoveriesWidget from './widgets/NearbyDiscoveriesWidget';
import RarityBreakdownWidget from './widgets/RarityBreakdownWidget';

const AVAILABLE_WIDGETS = [
  { id: 'field-stats', name: 'Field Stats', component: FieldStatsWidget },
  { id: 'scan-history', name: 'Recent Scans', component: ScanHistoryWidget },
  { id: 'weather-gps', name: 'Weather & GPS', component: WeatherGPSWidget },
  { id: 'nearby-discoveries', name: 'Nearby Finds', component: NearbyDiscoveriesWidget },
  { id: 'rarity-breakdown', name: 'Rarity Chart', component: RarityBreakdownWidget },
];

const STORAGE_KEY = 'rh_widget_config';

export default function WidgetPicker({ userEmail }) {
  const [enabledWidgets, setEnabledWidgets] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : ['field-stats', 'scan-history', 'weather-gps'];
    } catch {
      return ['field-stats', 'scan-history', 'weather-gps'];
    }
  });

  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(enabledWidgets));
  }, [enabledWidgets]);

  const toggleWidget = (id) => {
    setEnabledWidgets((prev) =>
      prev.includes(id) ? prev.filter((w) => w !== id) : [...prev, id]
    );
  };

  const activeWidgets = AVAILABLE_WIDGETS.filter((w) => enabledWidgets.includes(w.id));

  return (
    <>
      {/* Widgets Display */}
      <div className="space-y-3 mb-6">
        {activeWidgets.map(({ id, component: Component }) => (
          <Component key={id} userEmail={userEmail} />
        ))}
      </div>

      {/* Settings Button — moved to CommandCenterHub */}

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-50 backdrop-blur-sm flex items-end" style={{ background: 'rgba(0,0,0,0.5)' }} onClick={() => setShowSettings(false)}>
          <div
            className="w-full rounded-t-3xl p-6 max-h-96 overflow-y-auto"
            style={{ background: 'rgba(14,20,27,0.95)', borderTop: '1px solid rgba(122,231,255,0.2)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-2 mb-4">
              <div className="flex items-center gap-2">
                <Grid3x3 style={{ color: '#7AE7FF', width: 18, height: 18 }} />
                <h2 className="text-sm font-bold text-white">Customize Widgets</h2>
              </div>
              <button
                onClick={() => setShowSettings(false)}
                className="p-1 rounded-lg transition-all hover:bg-white/10"
                style={{ minHeight: 'unset', minWidth: 'unset' }}
               aria-label="Close">
                <X className="w-5 h-5 text-white/60 hover:text-white" />
              </button>
            </div>
            <div className="space-y-2">
              {AVAILABLE_WIDGETS.map(({ id, name }) => (
                <label
                  key={id}
                  className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <input
                    type="checkbox"
                    checked={enabledWidgets.includes(id)}
                    onChange={() => toggleWidget(id)}
                    className="w-4 h-4 cursor-pointer accent-cyan-400"
                  />
                  <span className="text-xs font-semibold text-white">{name}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}