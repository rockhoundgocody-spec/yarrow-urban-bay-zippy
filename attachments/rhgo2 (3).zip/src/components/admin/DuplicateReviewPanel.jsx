import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Loader2, RefreshCw, GitMerge, X, ArrowRight, MapPin, Zap, CheckCircle, ScanSearch } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const CONFIDENCE_CFG = {
  high:   { color: "text-red-400",    bg: "rgba(239,68,68,0.1)",   border: "rgba(239,68,68,0.3)",   label: "High Risk" },
  medium: { color: "text-yellow-400", bg: "rgba(245,158,11,0.1)",  border: "rgba(245,158,11,0.3)",  label: "Medium Risk" },
  low:    { color: "text-blue-400",   bg: "rgba(59,130,246,0.1)",  border: "rgba(59,130,246,0.3)",  label: "Low Risk" },
};

function SimilarityBar({ value }) {
  const pct = Math.round((value || 0) * 100);
  const color = pct >= 75 ? "#ef4444" : pct >= 50 ? "#f59e0b" : "#3b82f6";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full bg-white/10">
        <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: color }} />
      </div>
      <span className="text-[10px] font-bold" style={{ color }}>{pct}%</span>
    </div>
  );
}

export default function DuplicateReviewPanel() {
  const [resolving, setResolving] = useState({});
  const [scanning, setScanning] = useState(false);
  const [scanResult, setScanResult] = useState(null);
  const queryClient = useQueryClient();

  const { data: candidates = [], isLoading } = useQuery({
    queryKey: ["duplicate-candidates"],
    queryFn: () => base44.entities.DuplicateCandidate.filter({ status: "pending" }, "-created_date", 100),
    staleTime: 15000,
  });

  const stats = {
    total: candidates.length,
    high: candidates.filter(c => c.confidence === "high").length,
    medium: candidates.filter(c => c.confidence === "medium").length,
  };

  async function runScan() {
    setScanning(true);
    setScanResult(null);
    try {
      const res = await base44.functions.invoke("geoNormalizer", { mode: "scan_duplicates" });
      setScanResult(res.data);
      queryClient.invalidateQueries({ queryKey: ["duplicate-candidates"] });
    } finally {
      setScanning(false);
    }
  }

  async function runMineralNorm() {
    setScanning(true);
    setScanResult(null);
    try {
      const res = await base44.functions.invoke("geoNormalizer", { mode: "normalize_minerals" });
      setScanResult({ ...res.data, _type: "mineral_norm" });
    } finally {
      setScanning(false);
    }
  }

  async function resolve(candidate, action) {
    setResolving(r => ({ ...r, [candidate.id]: action }));
    try {
      if (action === "merge") {
        // Add incoming minerals to matched location (union)
        const existing = await base44.entities.RockhoundingLocation.filter({ id: candidate.matched_location_id }).catch(() => []);
        if (existing.length > 0) {
          const loc = existing[0];
          const currentMinerals = loc.minerals_found || [];
          const newMinerals = candidate.incoming_minerals || [];
          const merged = [...new Set([...currentMinerals, ...newMinerals])];
          await base44.functions.invoke("processRockhoundingLocation", { id: loc.id }).catch(() => {});
          // Update minerals directly
          await base44.entities.RockhoundingLocation.update(loc.id, { minerals_found: merged });
        }
      } else if (action === "force_import") {
        let raw = {};
        try { raw = JSON.parse(candidate.incoming_raw || "{}"); } catch { raw = {}; }
        await base44.entities.RockhoundingLocation.create({
          name: candidate.incoming_name,
          latitude: candidate.incoming_lat,
          longitude: candidate.incoming_lon,
          minerals_found: candidate.incoming_minerals || [],
          site_type: raw.site_type || "other",
          state: raw.state || "",
          data_sources: [candidate.incoming_source || "manual"],
          confidence_score: 60,
          review_status: "pending",
          country: "USA",
        });
      }
      // Update candidate status
      await base44.entities.DuplicateCandidate.update(candidate.id, {
        status: action === "merge" ? "merged" : action === "force_import" ? "force_imported" : "dismissed",
      });
      queryClient.invalidateQueries({ queryKey: ["duplicate-candidates"] });
    } catch (err) {
      console.error("resolve error:", err);
    } finally {
      setResolving(r => { const n = {...r}; delete n[candidate.id]; return n; });
    }
  }

  return (
    <div className="space-y-4">
      {/* Header actions */}
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={runScan} disabled={scanning} size="sm"
          className="text-black font-semibold text-xs gap-1.5"
          style={{ background: "linear-gradient(135deg,#00f5ff,#8b00ff)", color: "#000" }}>
          {scanning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ScanSearch className="w-3.5 h-3.5" />}
          Scan for Duplicates
        </Button>
        <Button onClick={runMineralNorm} disabled={scanning} size="sm" variant="outline"
          className="border-white/15 text-white/60 hover:text-white text-xs gap-1.5">
          {scanning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
          Normalize Minerals
        </Button>
        <button onClick={() => queryClient.invalidateQueries({ queryKey: ["duplicate-candidates"] })}
          className="p-1.5 rounded-lg text-white/30 hover:text-white/60 border border-white/10 bg-white/5 transition-colors" aria-label="Refresh">
          <RefreshCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {scanResult && (
        <div className="p-3 rounded-xl border text-xs font-medium"
          style={{ background: "rgba(0,255,170,0.06)", borderColor: "rgba(0,255,170,0.2)", color: "#00ffaa" }}>
          {scanResult._type === "mineral_norm"
            ? `✓ Mineral normalization complete — ${scanResult.updated} locations updated of ${scanResult.total} total`
            : `✓ Scan complete — ${scanResult.pairs_found} new duplicate pairs found across ${scanResult.locations_scanned} locations`
          }
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "Pending Review", value: stats.total, color: "#00f5ff" },
          { label: "High Confidence", value: stats.high, color: "#ef4444" },
          { label: "Medium Confidence", value: stats.medium, color: "#f59e0b" },
        ].map(s => (
          <div key={s.label} className="rounded-xl p-3 border border-white/5 bg-white/[0.02] text-center">
            <div className="text-lg font-black" style={{ color: s.color }}>{s.value}</div>
            <div className="text-[10px] text-white/30 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Candidates list */}
      {isLoading ? (
        <div className="flex justify-center py-10"><Loader2 className="w-5 h-5 text-white/30 animate-spin" /></div>
      ) : candidates.length === 0 ? (
        <div className="text-center py-12 text-white/25">
          <CheckCircle className="w-10 h-10 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No pending duplicates — run a scan to detect new ones.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {candidates.map(c => {
            const cfg = CONFIDENCE_CFG[c.confidence] || CONFIDENCE_CFG.low;
            const isResolving = !!resolving[c.id];
            return (
              <div key={c.id} className="rounded-xl p-3.5 border" style={{ background: cfg.bg, borderColor: cfg.border }}>
                {/* Confidence badge + distance */}
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color }}>
                    {cfg.label} Duplicate
                  </span>
                  <div className="flex items-center gap-2 text-[10px] text-white/40">
                    <MapPin className="w-3 h-3" />
                    {c.distance_km != null ? `${c.distance_km} km apart` : "—"}
                    {c.created_date && <span>· {formatDistanceToNow(new Date(c.created_date), { addSuffix: true })}</span>}
                  </div>
                </div>

                {/* Side-by-side comparison */}
                <div className="grid grid-cols-[1fr,auto,1fr] gap-2 items-center mb-2.5">
                  <div className="rounded-lg p-2 bg-white/[0.03] border border-white/10">
                    <div className="text-[10px] text-white/30 mb-1">EXISTING RECORD</div>
                    <div className="text-xs font-semibold text-white truncate">{c.matched_location_name}</div>
                    <div className="text-[10px] text-white/30 mt-0.5 truncate">{c.matched_location_id?.slice(0,8)}…</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-white/20 flex-shrink-0" />
                  <div className="rounded-lg p-2 bg-white/[0.03] border border-white/10">
                    <div className="text-[10px] text-white/30 mb-1">INCOMING ({c.incoming_source || "?"})</div>
                    <div className="text-xs font-semibold text-white truncate">{c.incoming_name}</div>
                    {c.incoming_minerals?.length > 0 && (
                      <div className="text-[10px] text-white/40 mt-0.5 truncate">{c.incoming_minerals.slice(0,3).join(", ")}</div>
                    )}
                  </div>
                </div>

                {/* Name similarity bar */}
                <div className="mb-3">
                  <div className="text-[9px] text-white/30 mb-1 flex items-center justify-between">
                    <span>NAME SIMILARITY</span>
                  </div>
                  <SimilarityBar value={c.name_similarity} />
                </div>

                {/* Action buttons */}
                <div className="flex gap-1.5">
                  <button onClick={() => resolve(c, "merge")} disabled={isResolving}
                    className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-semibold transition-all disabled:opacity-40 active:scale-95"
                    style={{ background: "rgba(0,255,170,0.12)", border: "1px solid rgba(0,255,170,0.25)", color: "#00ffaa" }}>
                    {isResolving && resolving[c.id]==="merge" ? <Loader2 className="w-3 h-3 animate-spin" /> : <GitMerge className="w-3 h-3" />}
                    Merge Minerals
                  </button>
                  <button onClick={() => resolve(c, "force_import")} disabled={isResolving}
                    className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[11px] font-semibold transition-all disabled:opacity-40 active:scale-95"
                    style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.2)", color: "#00f5ff" }}>
                    {isResolving && resolving[c.id]==="force_import" ? <Loader2 className="w-3 h-3 animate-spin" /> : <ArrowRight className="w-3 h-3" />}
                    Import Anyway
                  </button>
                  <button onClick={() => resolve(c, "dismiss")} disabled={isResolving}
                    className="w-8 flex items-center justify-center rounded-lg text-[11px] transition-all disabled:opacity-40 active:scale-95"
                    style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", color: "#ef4444" }}>
                    {isResolving && resolving[c.id]==="dismiss" ? <Loader2 className="w-3 h-3 animate-spin" /> : <X className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}