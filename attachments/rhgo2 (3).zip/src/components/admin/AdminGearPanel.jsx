import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Search, Loader2, Pencil, Trash2, Plus, Package } from "lucide-react";

const TRIP_TYPES = ["all_purpose", "desert", "mountain", "river", "mine", "beach", "winter", "beginner"];
const GEAR_CATS = ["tools", "safety", "navigation", "clothing", "sample_storage", "reference", "camp", "emergency"];
const SORT_OPTIONS = [
  { value: "-created_date", label: "Newest" },
  { value: "created_date",  label: "Oldest" },
  { value: "name",          label: "Name A–Z" },
];

const BLANK = { name: "", description: "", trip_type: "all_purpose", items: [] };

export default function AdminGearPanel() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [sort, setSort] = useState("-created_date");
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(BLANK);
  const [isNew, setIsNew] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [newItem, setNewItem] = useState({ item: "", category: "tools", notes: "" });

  const { data: lists = [], isLoading } = useQuery({
    queryKey: ["admin-gear-lists", sort],
    queryFn: () => base44.entities.TripPlan.list(sort, 100),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => isNew
      ? base44.entities.TripPlan.create(data)
      : base44.entities.TripPlan.update(editing.id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-gear-lists"] }); setEditing(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.TripPlan.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-gear-lists"] }); setConfirmDelete(null); },
  });

  const openNew = () => { setIsNew(true); setForm(BLANK); setEditing({}); };
  const openEdit = (l) => { setIsNew(false); setForm({ name: l.name || "", description: l.description || "", trip_type: l.trip_type || "all_purpose", items: l.items || [] }); setEditing(l); };

  const addItem = () => {
    if (!newItem.item.trim()) return;
    setForm(f => ({ ...f, items: [...(f.items || []), { ...newItem, checked: false }] }));
    setNewItem({ item: "", category: "tools", notes: "" });
  };

  const removeItem = (idx) => setForm(f => ({ ...f, items: f.items.filter((_, i) => i !== idx) }));

  const filtered = lists.filter((l) => {
    const q = search.toLowerCase();
    const matchSearch = !search || l.name?.toLowerCase().includes(q);
    const matchType = filterType === "all" || l.trip_type === filterType;
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search gear lists..."
            className="pl-10 bg-[#14141e] border-white/10 text-white text-sm" />
        </div>
        <Select value={filterType} onValueChange={setFilterType}>
          <SelectTrigger className="w-full md:w-44 bg-[#14141e] border-white/10 text-white text-sm"><SelectValue placeholder="Trip Type" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Types</SelectItem>{TRIP_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace("_", " ")}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="w-full md:w-36 bg-[#14141e] border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>{SORT_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
        </Select>
        <button onClick={openNew}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
          <Plus className="w-4 h-4" /> New List
        </button>
      </div>

      <p className="text-xs text-white/30">{filtered.length} gear list{filtered.length !== 1 ? "s" : ""}</p>

      {isLoading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-emerald-400" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filtered.map(l => (
            <div key={l.id} className="rounded-xl border border-white/6 bg-[#14141e] p-4">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-emerald-400 shrink-0" />
                  <p className="font-semibold text-white/90 text-sm">{l.name}</p>
                </div>
                <div className="flex gap-1 shrink-0">
                  <button onClick={() => openEdit(l)} aria-label="Edit gear list" title="Edit gear list" className="w-7 h-7 rounded-lg border border-white/8 flex items-center justify-center text-white/30 hover:text-white/70">
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => setConfirmDelete(l)} aria-label="Delete gear list" title="Delete gear list" className="w-7 h-7 rounded-lg border border-red-500/15 flex items-center justify-center text-red-400/40 hover:text-red-400">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              {l.trip_type && <Badge className="text-[10px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20 mb-2">{l.trip_type.replace("_", " ")}</Badge>}
              {l.description && <p className="text-xs text-white/40 mb-2 line-clamp-2">{l.description}</p>}
              <div className="flex flex-wrap gap-1">
                {(l.items || []).slice(0, 6).map((item, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/40 border border-white/8">{item.item}</span>
                ))}
                {(l.items || []).length > 6 && <span className="text-[10px] text-white/25">+{l.items.length - 6} more</span>}
              </div>
            </div>
          ))}
          {filtered.length === 0 && <p className="col-span-full text-center text-white/25 py-10 text-sm">No gear lists found.</p>}
        </div>
      )}

      {/* Edit / Create Dialog */}
      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-sm">{isNew ? "Create Gear List" : `Edit — ${editing?.name}`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2 text-sm">
            <div>
              <label className="text-xs text-white/50 block mb-1">List Name *</label>
              <Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Trip Type</label>
              <Select value={form.trip_type} onValueChange={v => setForm({...form, trip_type: v})}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{TRIP_TYPES.map(t => <SelectItem key={t} value={t}>{t.replace("_", " ")}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Description</label>
              <Textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} rows={2} className="bg-white/5 border-white/10 text-white text-xs" />
            </div>

            {/* Items */}
            <div>
              <p className="text-xs font-semibold text-white/50 uppercase tracking-wider mb-2">Items ({(form.items || []).length})</p>
              <div className="space-y-1.5 mb-3 max-h-40 overflow-y-auto pr-1">
                {(form.items || []).map((item, i) => (
                  <div key={i} className="flex items-center gap-2 bg-white/3 rounded-lg px-3 py-2">
                    <span className="flex-1 text-xs text-white/70">{item.item}</span>
                    <Badge className="text-[9px] bg-white/5 text-white/30 border-white/8">{item.category}</Badge>
                    <button onClick={() => removeItem(i)} aria-label="Remove item" title="Remove item" className="text-red-400/40 hover:text-red-400 transition-colors">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2">
                <Input value={newItem.item} onChange={e => setNewItem({...newItem, item: e.target.value})}
                  placeholder="Item name" className="flex-1 bg-white/5 border-white/10 text-white text-xs" onKeyDown={e => e.key === "Enter" && addItem()} />
                <Select value={newItem.category} onValueChange={v => setNewItem({...newItem, category: v})}>
                  <SelectTrigger className="w-28 bg-white/5 border-white/10 text-white text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{GEAR_CATS.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
                <button onClick={addItem} className="px-3 py-2 rounded-lg bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 text-xs font-semibold hover:bg-emerald-500/25">Add</button>
              </div>
            </div>

            <div className="flex gap-2 pt-1">
              <button onClick={() => saveMutation.mutate(form)} disabled={!form.name || saveMutation.isPending}
                className="flex-1 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-500 to-teal-600 text-white disabled:opacity-40 flex items-center justify-center gap-2">
                {saveMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {isNew ? "Create" : "Save"}
              </button>
              <button onClick={() => setEditing(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader><DialogTitle className="text-sm">Delete gear list?</DialogTitle></DialogHeader>
          <p className="text-xs text-white/50 mt-1">"{confirmDelete?.name}" will be permanently removed.</p>
          <div className="flex gap-2 mt-4">
            <button onClick={() => deleteMutation.mutate(confirmDelete.id)} disabled={deleteMutation.isPending}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-red-500/15 text-red-400 border border-red-500/25 disabled:opacity-40 flex items-center justify-center gap-2">
              {deleteMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />} Delete
            </button>
            <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}