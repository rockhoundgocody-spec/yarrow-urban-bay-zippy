import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Play, CheckCircle, XCircle, Clock, RefreshCw, Database, AlertTriangle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const US_STATES = ["Arizona", "California", "Colorado", "Idaho", "Montana", "Nevada", "New Mexico", "Oregon", "Utah", "Wyoming"];

const SOURCE_META = {
  usgs_mrds:   { label: "USGS MRDS",    desc: "Real data from US Geological Survey Mine Records (WFS GeoJSON)", color: "#00f5ff" },
  ai_generate: { label: "AI Generate",  desc: "Gemini-powered synthesis of geologically-accurate locations", color: "#a855f7" },
};

const STATUS_CFG = {
  completed: { color: "text-emerald-400", bg: "rgba(0,255,170,0.08)", border: "rgba(0,255,170,0.25)", Icon: CheckCircle },
  failed:    { color: "text-red-400",     bg: "rgba(239,68,68,0.08)",  border: "rgba(239,68,68,0.25)",  Icon: XCircle },
  running:   { color: "text-blue-400",    bg: "rgba(59,130,246,0.08)", border: "rgba(59,130,246,0.25)", Icon: Loader2, spin: true },
  pending:   { color: "text-yellow-400",  bg: "rgba(245,158,11,0.08)", border: "rgba(245,158,11,0.25)", Icon: Clock },
};

export default function ImportDashboard() {
  const [source, setSource] = useState("usgs_mrds");
  const [region, setRegion] = useState("Arizona");
  const [running, setRunning] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [lastError, setLastError] = useState(null);
  const queryClient = useQueryClient();

  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ["import-jobs"],
    queryFn: () => base44.entities.ImportJob.list("-created_date", 25),
    refetchInterval: running ? 3000 : false,
    staleTime: 10000,
  });

  const triggerImport = async () => {
    setRunning(true);
    setLastResult(null);
    setLastError(null);
    const res = await base44.functions.invoke("triggerImport", { source, region });
    setRunning(false);
    if (res.data?.error) {
      setLastError(res.data.error);
    } else {
      setLastResult(res.data);
    }
    queryClient.invalidateQueries({ queryKey: ["import-jobs"] });
  };

  const totalImported = jobs.reduce((s, j) => s + (j.records_imported || 0), 0);
  const completedJobs = jobs.filter(j => j.status === "completed").length;
  const failedJobs = jobs.filter(j => j.status === "failed").length;

  return (
    <div className="space-y-5">
      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "Total Imported", value: totalImported, color: "#00ffaa" },
          { label: "Jobs Completed", value: completedJobs, color: "#00f5ff" },
          { label: "Jobs Failed", value: failedJobs, color: "#ef4444" },
        ].map(s => (
          <div key={s.label} className="rounded-xl p-3 border border-white/5 bg-white/[0.02] text-center">
            <div className="text-xl font-black" style={{ color: s.color }}>{s.value}</div>
            <div className="text-[10px] text-white/30 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Trigger panel */}
      <div className="rounded-xl p-4 border border-white/10 bg-white/[0.03]">
        <p className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
          <Database className="w-3.5 h-3.5" /> Run Import Pipeline
        </p>

        <div className="flex flex-col gap-3">
          <div className="flex gap-3">
            <Select value={source} onValueChange={setSource}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm flex-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="usgs_mrds">USGS MRDS (Real Data)</SelectItem>
                <SelectItem value="ai_generate">AI Generate (Gemini)</SelectItem>
              </SelectContent>
            </Select>

            <Select value={region} onValueChange={setRegion}>
              <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {US_STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {SOURCE_META[source] && (
            <p className="text-[11px] text-white/30">{SOURCE_META[source].desc}</p>
          )}

          <div className="flex gap-2">
            <Button onClick={triggerImport} disabled={running}
              className="font-semibold text-black flex-1"
              style={{ background: running ? "rgba(255,255,255,0.1)" : "linear-gradient(135deg,#00f5ff,#8b00ff)", color: running ? "rgba(255,255,255,0.4)" : "#000" }}>
              {running
                ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Running...</>
                : <><Play className="w-4 h-4 mr-2" />Run Import</>
              }
            </Button>
            <button onClick={() => queryClient.invalidateQueries({ queryKey: ["import-jobs"] })}
              className="p-2.5 rounded-lg text-white/30 hover:text-white/60 border border-white/10 bg-white/5 transition-colors" aria-label="Refresh">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Result feedback */}
        {lastResult && (
          <div className="mt-3 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <p className="text-xs text-emerald-400 font-medium">
              ✅ {lastResult.records_imported} records imported · {lastResult.records_skipped || 0} skipped · {lastResult.records_fetched} fetched
            </p>
          </div>
        )}
        {lastError && (
          <div className="mt-3 p-3 rounded-lg bg-red-500/10 border border-red-500/20 flex items-start gap-2">
            <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
            <p className="text-xs text-red-400">{lastError}</p>
          </div>
        )}
      </div>

      {/* Job history */}
      <div>
        <p className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3">Import History</p>
        {isLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-white/30 animate-spin" /></div>
        ) : jobs.length === 0 ? (
          <p className="text-center text-white/20 text-sm py-8">No import jobs yet. Run your first import above.</p>
        ) : (
          <div className="space-y-2">
            {jobs.map(job => {
              const cfg = STATUS_CFG[job.status] || STATUS_CFG.pending;
              const Icon = cfg.Icon;
              return (
                <div key={job.id} className="rounded-xl p-3 border flex items-center gap-3" style={{ borderColor: cfg.border, background: cfg.bg }}>
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0" style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>
                    <Icon className={`w-4 h-4 ${cfg.color} ${cfg.spin ? "animate-spin" : ""}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-semibold text-white/80">{SOURCE_META[job.source]?.label || job.source}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${cfg.color}`} style={{ background: cfg.bg }}>
                        {job.status}
                      </span>
                      {job.region && <span className="text-[10px] text-white/30">{job.region}</span>}
                    </div>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className="text-[10px] text-white/25">{formatDistanceToNow(new Date(job.created_date), { addSuffix: true })}</span>
                      {(job.records_imported > 0) && <span className="text-[10px] text-emerald-400">{job.records_imported} imported</span>}
                      {job.error_message && <span className="text-[10px] text-red-400 truncate max-w-[180px]">{job.error_message}</span>}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-sm font-bold text-white/70">{job.records_imported || 0}</div>
                    <div className="text-[9px] text-white/25">added</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}