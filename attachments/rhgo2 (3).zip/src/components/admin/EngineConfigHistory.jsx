import React from "react";

export default function EngineConfigHistory({ configs = [] }) {
  if (configs.length === 0) return <p className="text-xs text-white/30">No versions yet.</p>;
  return (
    <div className="space-y-2">
      {configs.map((c) => (
        <div key={c.id} className="flex items-center justify-between px-3 py-2 rounded-xl bg-white/[0.03] border border-white/[0.06]">
          <div>
            <span className="text-sm font-semibold text-white/80">v{c.version}</span>
            <span className="text-xs text-white/35 ml-2">{c.change_note}</span>
          </div>
          <div className="text-right">
            {c.is_active && (
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md" style={{ color: "#00D68F", background: "rgba(0,214,143,0.10)" }}>
                Active
              </span>
            )}
            <div className="text-[10px] text-white/25 mt-0.5">{c.changed_by}</div>
          </div>
        </div>
      ))}
    </div>
  );
}