import React from "react";

export default function WeightGroupEditor({ label, values = {}, onChange }) {
  const keys = Object.keys(values);
  return (
    <div className="rh-artifact-panel p-4">
      <h2 className="text-sm font-bold text-white/80 mb-3">{label}</h2>
      {keys.length === 0 ? (
        <p className="text-xs text-white/30">No values set for this group.</p>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {keys.map((k) => (
            <label key={k} className="flex flex-col gap-1">
              <span className="text-[10px] uppercase tracking-wider text-white/40">{k}</span>
              <input
                type="number"
                step="0.01"
                value={values[k]}
                onChange={(e) => onChange({ ...values, [k]: parseFloat(e.target.value) || 0 })}
                className="bg-white/5 border border-white/10 rounded-lg px-2.5 py-2 text-sm text-white tap-compact"
              />
            </label>
          ))}
        </div>
      )}
    </div>
  );
}