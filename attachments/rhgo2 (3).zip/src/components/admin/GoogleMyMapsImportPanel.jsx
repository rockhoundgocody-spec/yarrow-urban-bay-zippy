import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Loader2, AlertCircle, CheckCircle2, Database } from "lucide-react";

const DEFAULT_URL = "https://www.google.com/maps/d/edit?mid=1-C5zwe8Goh3-gi18khHovzUGhK27OD6w";

/**
 * GoogleMyMapsImportPanel — admin UI to trigger KML import from a Google My
 * Maps URL into the RockhoundingLocation entity.
 *
 * Supports dry-run preview, paginated import (offset/limit), and shows
 * real-time progress + errors.
 */
export default function GoogleMyMapsImportPanel() {
  const [url, setUrl] = useState(DEFAULT_URL);
  const [offset, setOffset] = useState(0);
  const [limit, setLimit] = useState(500);
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  async function handleDryRun() {
    setLoading(true);
    setMode("dryRun");
    setError(null);
    setResult(null);
    try {
      const res = await base44.functions.invoke("importGoogleMyMaps", { url, dryRun: true });
      setResult(res);
    } catch (e) {
      setError(e.message || "Dry run failed");
    } finally {
      setLoading(false);
    }
  }

  async function handleImport() {
    setLoading(true);
    setMode("import");
    setError(null);
    setResult(null);
    try {
      const res = await base44.functions.invoke("importGoogleMyMaps", {
        url, offset: Number(offset), limit: Number(limit),
      });
      setResult(res);
    } catch (e) {
      setError(e.message || "Import failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900/60 p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Database className="w-5 h-5 text-cyan-400" />
        <h3 className="text-sm font-bold text-white">Google My Maps Import</h3>
      </div>

      <div className="space-y-2">
        <label className="text-xs font-medium text-white/60">Google My Maps URL</label>
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://www.google.com/maps/d/edit?mid=..."
          className="bg-slate-800/60 border-white/10 text-white text-xs"
        />
      </div>

      <div className="flex gap-3 items-end">
        <div className="flex-1 space-y-1">
          <label className="text-[10px] font-medium text-white/40 uppercase">Offset</label>
          <Input
            type="number"
            value={offset}
            onChange={(e) => setOffset(e.target.value)}
            className="bg-slate-800/60 border-white/10 text-white text-xs"
          />
        </div>
        <div className="flex-1 space-y-1">
          <label className="text-[10px] font-medium text-white/40 uppercase">Limit</label>
          <Input
            type="number"
            value={limit}
            onChange={(e) => setLimit(e.target.value)}
            className="bg-slate-800/60 border-white/10 text-white text-xs"
          />
        </div>
      </div>

      <div className="flex gap-2">
        <Button
          onClick={handleDryRun}
          disabled={loading || !url}
          variant="outline"
          className="text-xs h-9"
        >
          {loading && mode === "dryRun" ? (
            <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
          ) : null}
          Dry Run
        </Button>
        <Button
          onClick={handleImport}
          disabled={loading || !url}
          className="text-xs h-9 bg-cyan-600 hover:bg-cyan-500"
        >
          {loading && mode === "import" ? (
            <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
          ) : (
            <Download className="w-3.5 h-3.5 mr-1.5" />
          )}
          Import Batch
        </Button>
      </div>

      {error && (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-red-900/20 border border-red-500/30">
          <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-red-300">{error}</p>
        </div>
      )}

      {result && (
        <div className="space-y-2 p-3 rounded-lg bg-slate-800/40 border border-white/5">
          {result.dryRun ? (
            <>
              <div className="flex items-center gap-2 text-xs text-cyan-300 font-medium">
                <CheckCircle2 className="w-4 h-4" />
                Dry Run — {result.totalPlacemarks} placemarks found
              </div>
              {result.sample?.map((s, i) => (
                <div key={i} className="text-[11px] text-white/50 pl-6">
                  • {s.name} — {s.state || "Unknown state"}, {s.siteType}, ({s.lat.toFixed(3)}, {s.lon.toFixed(3)})
                </div>
              ))}
            </>
          ) : (
            <>
              <div className="flex items-center gap-2 text-xs text-emerald-300 font-medium">
                <CheckCircle2 className="w-4 h-4" />
                Imported {result.imported} of {result.processed} (Total in map: {result.totalPlacemarks})
              </div>
              {result.hasMore && (
                <p className="text-[11px] text-amber-300 pl-6">
                  More remaining — next offset: {result.nextOffset}
                </p>
              )}
              {result.errors?.length > 0 && (
                <p className="text-[11px] text-red-300 pl-6">
                  {result.errors.length} error(s) — first: {result.errors[0]?.error || result.errors[0]?.name}
                </p>
              )}
            </>
          )}
        </div>
      )}

      <p className="text-[10px] text-white/30">
        Imported locations are marked <code className="text-white/50">review_status: pending</code> and tagged with
        <code className="text-white/50"> data_sources: ['google_my_maps']</code>. Use the offset/limit to paginate
        large maps (e.g. 0/500, then 500/500).
      </p>
    </div>
  );
}