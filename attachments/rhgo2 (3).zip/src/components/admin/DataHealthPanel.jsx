import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { AlertTriangle, CheckCircle2, Database, Loader2, RefreshCw, Wrench } from "lucide-react";

function Metric({ label, value, tone = "neutral" }) {
  const tones = {
    neutral: ["rgba(255,255,255,0.04)", "rgba(255,255,255,0.10)", "rgba(255,255,255,0.75)"],
    good: ["rgba(16,185,129,0.08)", "rgba(16,185,129,0.24)", "#34d399"],
    warn: ["rgba(245,182,66,0.08)", "rgba(245,182,66,0.26)", "#F5B642"],
  };
  const [bg, border, color] = tones[tone] || tones.neutral;
  return (
    <div className="rounded-2xl p-4" style={{ background: bg, border: `1px solid ${border}` }}>
      <div className="text-2xl font-black" style={{ color }}>{value ?? "—"}</div>
      <div className="text-xs text-white/40 mt-1">{label}</div>
    </div>
  );
}

export default function DataHealthPanel() {
  const qc = useQueryClient();
  const [action, setAction] = useState(null);
  const [message, setMessage] = useState("");

  const health = useQuery({
    queryKey: ["admin-data-health"],
    queryFn: () => base44.functions.invoke("dataHealthReport", {}).then((r) => r.data),
    staleTime: 15_000,
  });

  const run = async (name, payload, successLabel) => {
    setAction(name);
    setMessage("");
    try {
      const res = await base44.functions.invoke(name, payload);
      const data = res.data || {};
      setMessage(`${successLabel}: ${data.backfilled ?? data.normalized_count ?? data.resolved_count ?? 0}`);
      await qc.invalidateQueries({ queryKey: ["admin-data-health"] });
    } catch (error) {
      setMessage(error?.response?.data?.error || error?.message || `${name} failed`);
    } finally {
      setAction(null);
    }
  };

  if (health.isLoading) {
    return <div className="py-20 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-amber-400" /></div>;
  }

  const h = health.data || {};
  const stuck = h.stuck_findings?.count || 0;
  const stale = h.stale_crawls?.count || 0;
  const conflicts = h.subscription_conflicts?.count || 0;
  const posts = h.crawled_post_counts || {};
  const healthy = stuck === 0 && stale === 0 && conflicts === 0;

  return (
    <div className="space-y-5">
      <div className="rounded-2xl p-5 flex items-start justify-between gap-4" style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="flex gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: healthy ? "rgba(16,185,129,0.12)" : "rgba(245,182,66,0.12)" }}>
            {healthy ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-amber-400" />}
          </div>
          <div>
            <h2 className="font-black text-white">Production Data Health</h2>
            <p className="text-xs text-white/40 mt-1">Server-side integrity checks. No secret values or private GPS are exposed.</p>
          </div>
        </div>
        <button onClick={() => health.refetch()} className="p-2 rounded-xl text-white/50 hover:text-white" style={{ background: "rgba(255,255,255,0.05)" }} aria-label="Refresh data health">
          <RefreshCw className={`w-4 h-4 ${health.isFetching ? "animate-spin" : ""}`} />
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Metric label="Stuck findings" value={stuck} tone={stuck ? "warn" : "good"} />
        <Metric label="Stale crawl runs" value={stale} tone={stale ? "warn" : "good"} />
        <Metric label="Billing drift" value={conflicts} tone={conflicts ? "warn" : "good"} />
        <Metric label="Crawler pending" value={posts.pending || 0} tone={(posts.pending || 0) > 20 ? "warn" : "neutral"} />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="rounded-2xl p-5 space-y-3" style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="flex items-center gap-2"><Wrench className="w-4 h-4 text-cyan-300" /><h3 className="font-bold text-white">Finding repair</h3></div>
          <p className="text-xs text-white/45 leading-relaxed">Matches only placeholder findings to the same user's nearest scan/specimen within five minutes. It never rewrites historic RQS or XP.</p>
          <div className="flex gap-2">
            <button disabled={!!action} onClick={() => run("backfillFindings", { apply: false }, "Would repair")} className="flex-1 py-2.5 rounded-xl text-xs font-bold text-cyan-200" style={{ background: "rgba(34,211,238,0.08)", border: "1px solid rgba(34,211,238,0.22)" }}>Preview</button>
            <button disabled={!!action || stuck === 0} onClick={() => window.confirm("Repair matched placeholder findings now?") && run("backfillFindings", { apply: true }, "Repaired")} className="flex-1 py-2.5 rounded-xl text-xs font-bold text-emerald-300 disabled:opacity-40" style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.24)" }}>{action === "backfillFindings" ? "Working…" : "Repair"}</button>
          </div>
        </div>

        <div className="rounded-2xl p-5 space-y-3" style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="flex items-center gap-2"><Database className="w-4 h-4 text-violet-300" /><h3 className="font-bold text-white">Subscription normalization</h3></div>
          <p className="text-xs text-white/45 leading-relaxed">Live Stripe-backed User entitlement fields win. This only normalizes legacy tier aliases and fills missing non-destructive metadata.</p>
          <div className="flex gap-2">
            <button disabled={!!action} onClick={() => run("reconcileSubscriptions", { apply: false }, "Conflicts")} className="flex-1 py-2.5 rounded-xl text-xs font-bold text-violet-200" style={{ background: "rgba(141,124,255,0.08)", border: "1px solid rgba(141,124,255,0.22)" }}>Preview</button>
            <button disabled={!!action || conflicts === 0} onClick={() => window.confirm("Apply safe subscription normalization?") && run("reconcileSubscriptions", { apply: true }, "Normalized")} className="flex-1 py-2.5 rounded-xl text-xs font-bold text-emerald-300 disabled:opacity-40" style={{ background: "rgba(16,185,129,0.08)", border: "1px solid rgba(16,185,129,0.24)" }}>{action === "reconcileSubscriptions" ? "Working…" : "Normalize"}</button>
          </div>
        </div>
      </div>

      <div className="rounded-2xl p-4 text-xs text-white/40" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
        Crawler: {posts.published || 0} published · {posts.pending_review || 0} review queue · {posts.rejected || 0} rejected · {posts.pending || 0} pending.
        {message && <div className="mt-2 text-white/70">{message}</div>}
      </div>
    </div>
  );
}
