import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Pencil, Trash2, Search, Crown, CheckCircle, XCircle } from "lucide-react";

const BLANK = {
  name: "",
  stripe_price_id: "",
  price_usd: 0,
  billing_period: "monthly",
  description: "",
  features: [],
  limits: { monthly_scans: 0, collection_size: 0, offline_map_regions: 0, ai_identifications: 0 },
  is_active: true,
  display_order: 0,
};

const PERIODS = ["monthly", "annual"];

export default function TiersManager() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(BLANK);
  const [isNew, setIsNew] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [featureInput, setFeatureInput] = useState("");

  const { data: tiers = [], isLoading } = useQuery({
    queryKey: ["admin-tiers"],
    queryFn: () => base44.entities.SubscriptionTier.list("display_order", 50),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => isNew
      ? base44.entities.SubscriptionTier.create(data)
      : base44.entities.SubscriptionTier.update(editing.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-tiers"] });
      setEditing(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SubscriptionTier.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-tiers"] }),
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, is_active }) => base44.entities.SubscriptionTier.update(id, { is_active }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-tiers"] }),
  });

  const openNew = () => { setIsNew(true); setForm(BLANK); setEditing({}); };
  const openEdit = (t) => {
    setIsNew(false);
    setForm({
      ...BLANK,
      ...t,
      features: t.features || [],
      limits: t.limits || BLANK.limits,
    });
    setEditing(t);
  };

  const addFeature = () => {
    if (featureInput.trim() && !form.features.includes(featureInput.trim())) {
      setForm({ ...form, features: [...form.features, featureInput.trim()] });
    }
    setFeatureInput("");
  };

  const removeFeature = (f) => {
    setForm({ ...form, features: form.features.filter(x => x !== f) });
  };

  const filtered = tiers.filter(t => {
    const q = search.toLowerCase();
    return !search || t.name?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input
            placeholder="Search tiers..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-[#14141e] border-white/10 text-white text-sm"
          />
        </div>
        <button
          onClick={openNew}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-orange-600 text-white"
        >
          <Plus className="w-4 h-4" /> Add Tier
        </button>
      </div>

      <p className="text-xs text-white/30">{filtered.length} tier{filtered.length !== 1 ? "s" : ""}</p>

      {/* Grid */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(t => (
            <div key={t.id} className="rounded-xl border border-white/6 bg-[#14141e] p-4 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <Crown className="w-4 h-4 text-amber-400 shrink-0" />
                  <p className="font-semibold text-white/90 text-sm truncate">{t.name}</p>
                </div>
                <Badge className={`text-[10px] ${t.is_active ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/25" : "bg-white/5 text-white/30 border-white/10"}`}>
                  {t.is_active ? "Active" : "Inactive"}
                </Badge>
              </div>
              <div className="flex items-baseline gap-1">
                <span className="text-lg font-bold text-white">${t.price_usd ?? 0}</span>
                <span className="text-xs text-white/30">/{t.billing_period || "mo"}</span>
              </div>
              {t.description && <p className="text-xs text-white/40 line-clamp-2">{t.description}</p>}
              {t.features?.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-1">
                  {t.features.slice(0, 3).map((f, i) => (
                    <Badge key={i} className="text-[9px] bg-white/5 text-white/50 border-white/10">{f}</Badge>
                  ))}
                  {t.features.length > 3 && <span className="text-[10px] text-white/30">+{t.features.length - 3} more</span>}
                </div>
              )}
              <div className="flex items-center gap-2 mt-1 pt-2 border-t border-white/5">
                <button
                  onClick={() => toggleActiveMutation.mutate({ id: t.id, is_active: !t.is_active })}
                  className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium border border-white/8 text-white/50 hover:text-white/80"
                >
                  {t.is_active ? <XCircle className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
                  {t.is_active ? "Deactivate" : "Activate"}
                </button>
                <button onClick={() => openEdit(t)} className="w-7 h-7 rounded-lg border border-white/8 flex items-center justify-center text-white/30 hover:text-white/70">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => setConfirmDelete(t)} className="w-7 h-7 rounded-lg border border-red-500/15 flex items-center justify-center text-red-400/40 hover:text-red-400">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full text-center text-white/25 py-10 text-sm">No tiers found. Create one to get started.</p>
          )}
        </div>
      )}

      {/* Edit / Create Dialog */}
      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-sm">{isNew ? "Add Subscription Tier" : `Edit — ${editing?.name}`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Tier Name *</label>
                <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Free, Pro, Diamond" className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Price (USD)</label>
                <Input type="number" min="0" step="0.01" value={form.price_usd} onChange={e => setForm({ ...form, price_usd: parseFloat(e.target.value) || 0 })} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Billing Period</label>
                <Select value={form.billing_period} onValueChange={v => setForm({ ...form, billing_period: v })}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{PERIODS.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Stripe Price ID</label>
                <Input value={form.stripe_price_id} onChange={e => setForm({ ...form, stripe_price_id: e.target.value })} placeholder="price_..." className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Display Order</label>
                <Input type="number" min="0" value={form.display_order} onChange={e => setForm({ ...form, display_order: parseInt(e.target.value) || 0 })} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Description</label>
                <Textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={2} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
            </div>

            {/* Features */}
            <div>
              <label className="text-xs text-white/50 block mb-1">Features</label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={featureInput}
                  onChange={e => setFeatureInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); addFeature(); } }}
                  placeholder="Add a feature..."
                  className="bg-white/5 border-white/10 text-white text-xs flex-1"
                />
                <button onClick={addFeature} className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/25">Add</button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {form.features.map((f, i) => (
                  <Badge key={i} className="text-[10px] bg-white/5 text-white/60 border-white/10 cursor-pointer" onClick={() => removeFeature(f)}>
                    {f} ×
                  </Badge>
                ))}
                {form.features.length === 0 && <span className="text-xs text-white/20">No features added.</span>}
              </div>
            </div>

            {/* Limits */}
            <div>
              <label className="text-xs font-semibold text-white/50 uppercase tracking-wider block mb-2">Limits</label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-white/50 block mb-1">Monthly Scans</label>
                  <Input type="number" min="0" value={form.limits.monthly_scans} onChange={e => setForm({ ...form, limits: { ...form.limits, monthly_scans: parseInt(e.target.value) || 0 } })} className="bg-white/5 border-white/10 text-white text-xs" />
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">Collection Size</label>
                  <Input type="number" min="0" value={form.limits.collection_size} onChange={e => setForm({ ...form, limits: { ...form.limits, collection_size: parseInt(e.target.value) || 0 } })} className="bg-white/5 border-white/10 text-white text-xs" />
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">Offline Map Regions</label>
                  <Input type="number" min="0" value={form.limits.offline_map_regions} onChange={e => setForm({ ...form, limits: { ...form.limits, offline_map_regions: parseInt(e.target.value) || 0 } })} className="bg-white/5 border-white/10 text-white text-xs" />
                </div>
                <div>
                  <label className="text-xs text-white/50 block mb-1">AI Identifications</label>
                  <Input type="number" min="0" value={form.limits.ai_identifications} onChange={e => setForm({ ...form, limits: { ...form.limits, ai_identifications: parseInt(e.target.value) || 0 } })} className="bg-white/5 border-white/10 text-white text-xs" />
                </div>
              </div>
            </div>

            {/* Active toggle */}
            <label className="flex items-center gap-2 cursor-pointer pt-1">
              <input type="checkbox" checked={form.is_active} onChange={e => setForm({ ...form, is_active: e.target.checked })} className="accent-emerald-500" />
              <span className="text-xs text-white/60">Active (visible to users)</span>
            </label>

            <div className="flex gap-2 pt-1">
              <button
                onClick={() => saveMutation.mutate(form)}
                disabled={!form.name || saveMutation.isPending}
                className="flex-1 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-amber-500 to-orange-600 text-white disabled:opacity-40 flex items-center justify-center gap-2"
              >
                {saveMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {isNew ? "Create Tier" : "Save Changes"}
              </button>
              <button onClick={() => setEditing(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader><DialogTitle className="text-sm">Delete tier?</DialogTitle></DialogHeader>
          <p className="text-xs text-white/50 mt-1">"{confirmDelete?.name}" will be permanently removed. Existing subscribers on this tier will need to be migrated.</p>
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => deleteMutation.mutate(confirmDelete.id)}
              disabled={deleteMutation.isPending}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-red-500/15 text-red-400 border border-red-500/25 disabled:opacity-40 flex items-center justify-center gap-2"
            >
              {deleteMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />} Delete
            </button>
            <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}