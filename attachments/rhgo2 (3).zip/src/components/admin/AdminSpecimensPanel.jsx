import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Search, Loader2, Pencil, Trash2, Plus, Gem, Star } from "lucide-react";

const CATEGORIES = ["igneous", "sedimentary", "metamorphic", "mineral", "crystal", "fossil", "gemstone", "unknown"];
const LUSTERS = ["metallic", "vitreous", "pearly", "silky", "resinous", "adamantine", "waxy", "dull", "earthy"];
const SORT_OPTIONS = [
  { value: "-created_date", label: "Newest" },
  { value: "created_date",  label: "Oldest" },
  { value: "name",          label: "Name A–Z" },
  { value: "-confidence_score", label: "Confidence ↓" },
];

const BLANK = {
  name: "", category: "", hardness: "", color: "", luster: "",
  mineral_composition: "", formation_history: "", geological_significance: "",
  estimated_value: "", location_found: "", notes: "", confidence_score: 80,
};

export default function AdminSpecimensPanel() {
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("all");
  const [sort, setSort] = useState("-created_date");
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(BLANK);
  const [isNew, setIsNew] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const { data: specimens = [], isLoading } = useQuery({
    queryKey: ["admin-specimens"],
    queryFn: () => base44.entities.Specimen.list(sort, 300),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => isNew
      ? base44.entities.Specimen.create(data)
      : base44.entities.Specimen.update(editing.id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-specimens"] }); setEditing(null); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Specimen.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["admin-specimens"] }); setConfirmDelete(null); },
  });

  const openNew = () => { setIsNew(true); setForm(BLANK); setEditing({}); };
  const openEdit = (s) => { setIsNew(false); setForm({ ...BLANK, ...s }); setEditing(s); };

  const filtered = specimens.filter((s) => {
    const q = search.toLowerCase();
    const matchSearch = !search || s.name?.toLowerCase().includes(q) || s.location_found?.toLowerCase().includes(q);
    const matchCat = filterCat === "all" || s.category === filterCat;
    return matchSearch && matchCat;
  });

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col md:flex-row gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search specimens..."
            className="pl-10 bg-[#14141e] border-white/10 text-white text-sm" />
        </div>
        <Select value={filterCat} onValueChange={setFilterCat}>
          <SelectTrigger className="w-full md:w-40 bg-[#14141e] border-white/10 text-white text-sm"><SelectValue placeholder="Category" /></SelectTrigger>
          <SelectContent><SelectItem value="all">All Categories</SelectItem>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="w-full md:w-40 bg-[#14141e] border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>{SORT_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
        </Select>
        <button onClick={openNew}
          className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold bg-gradient-to-r from-amber-500 to-orange-600 text-white">
          <Plus className="w-4 h-4" /> Add Specimen
        </button>
      </div>

      <p className="text-xs text-white/30">{filtered.length} specimen{filtered.length !== 1 ? "s" : ""}</p>

      {/* Grid */}
      {isLoading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-amber-400" /></div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map(s => (
            <div key={s.id} className="rounded-xl border border-white/6 bg-[#14141e] p-3 flex gap-3">
              {s.photo_url
                ? <img src={s.photo_url} alt={s.name} className="w-14 h-14 rounded-lg object-cover shrink-0" />
                : <div className="w-14 h-14 rounded-lg bg-white/5 flex items-center justify-center shrink-0"><Gem className="w-6 h-6 text-white/20" /></div>}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white/90 text-sm truncate">{s.name}</p>
                <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                  {s.category && <Badge className="text-[10px] bg-purple-500/10 text-purple-400 border-purple-500/20">{s.category}</Badge>}
                  {s.hardness && <span className="text-[10px] text-white/30">H{s.hardness}</span>}
                  {s.is_favorite && <Star className="w-3 h-3 text-amber-400 fill-amber-400" />}
                </div>
                {s.location_found && <p className="text-[11px] text-white/30 mt-0.5 truncate">{s.location_found}</p>}
              </div>
              <div className="flex flex-col gap-1 shrink-0">
                <button onClick={() => openEdit(s)} aria-label="Edit specimen" title="Edit specimen" className="w-7 h-7 rounded-lg border border-white/8 flex items-center justify-center text-white/30 hover:text-white/70 transition-colors">
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => setConfirmDelete(s)} aria-label="Delete specimen" title="Delete specimen" className="w-7 h-7 rounded-lg border border-red-500/15 flex items-center justify-center text-red-400/40 hover:text-red-400 transition-colors">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
          {filtered.length === 0 && <p className="col-span-full text-center text-white/25 py-10 text-sm">No specimens found.</p>}
        </div>
      )}

      {/* Edit / Create Dialog */}
      <Dialog open={!!editing} onOpenChange={() => setEditing(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-sm">{isNew ? "Add Specimen" : `Edit — ${editing?.name}`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2 text-sm">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Name *</label>
                <Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Category</label>
                <Select value={form.category} onValueChange={v => setForm({...form, category: v})}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Luster</label>
                <Select value={form.luster} onValueChange={v => setForm({...form, luster: v})}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{LUSTERS.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Hardness (Mohs)</label>
                <Input type="number" min="1" max="10" step="0.5" value={form.hardness} onChange={e => setForm({...form, hardness: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Color</label>
                <Input value={form.color} onChange={e => setForm({...form, color: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Mineral Composition</label>
                <Input value={form.mineral_composition} onChange={e => setForm({...form, mineral_composition: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Estimated Value</label>
                <Input value={form.estimated_value} onChange={e => setForm({...form, estimated_value: e.target.value})} placeholder="e.g. $20–$50" className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Location Found</label>
                <Input value={form.location_found} onChange={e => setForm({...form, location_found: e.target.value})} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Formation History</label>
                <Textarea value={form.formation_history} onChange={e => setForm({...form, formation_history: e.target.value})} rows={2} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">Notes</label>
                <Textarea value={form.notes} onChange={e => setForm({...form, notes: e.target.value})} rows={2} className="bg-white/5 border-white/10 text-white text-xs" />
              </div>
              <div className="col-span-2">
                <label className="text-xs text-white/50 block mb-1">AI Confidence Score ({form.confidence_score})</label>
                <input type="range" min="0" max="100" value={form.confidence_score} onChange={e => setForm({...form, confidence_score: parseInt(e.target.value)})} className="w-full accent-amber-500" />
              </div>
            </div>
            <div className="flex gap-2 pt-1">
              <button onClick={() => saveMutation.mutate(form)} disabled={!form.name || saveMutation.isPending}
                className="flex-1 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-amber-500 to-orange-600 text-white disabled:opacity-40 flex items-center justify-center gap-2">
                {saveMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                {isNew ? "Create" : "Save"}
              </button>
              <button onClick={() => setEditing(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!confirmDelete} onOpenChange={() => setConfirmDelete(null)}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader><DialogTitle className="text-sm">Delete specimen?</DialogTitle></DialogHeader>
          <p className="text-xs text-white/50 mt-1">"{confirmDelete?.name}" will be permanently removed.</p>
          <div className="flex gap-2 mt-4">
            <button onClick={() => deleteMutation.mutate(confirmDelete.id)} disabled={deleteMutation.isPending}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-red-500/15 text-red-400 border border-red-500/25 disabled:opacity-40 flex items-center justify-center gap-2">
              {deleteMutation.isPending && <Loader2 className="w-3.5 h-3.5 animate-spin" />} Delete
            </button>
            <button onClick={() => setConfirmDelete(null)} className="px-4 py-2 rounded-xl text-sm text-white/40 border border-white/8">Cancel</button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}