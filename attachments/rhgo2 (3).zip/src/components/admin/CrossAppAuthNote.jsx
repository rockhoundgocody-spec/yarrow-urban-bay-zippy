/**
 * CrossAppAuthNote — Developer/operator configuration note.
 *
 * IMPORTANT: rhgo.base44.app and rhgo2.base44.app are two separate Base44 apps.
 * Base44 apps have isolated auth and database namespaces by default.
 *
 * To share user accounts, subscription state, XP, and data between both surfaces:
 *   1. Both apps must point to the SAME Base44 app ID (same backend/auth provider).
 *   2. In the Base44 dashboard, configure one app as primary and use the same
 *      app credentials/API keys in both deployment targets.
 *   3. Alternatively, use Base44's cross-app data sharing / API if available.
 *   4. Stripe webhooks must point to the shared backend app's webhook endpoint.
 *   5. STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET must be set in the primary app's
 *      environment secrets only — never in the client.
 *
 * Until this is connected, each app surface has its own isolated user database.
 * This is a PLATFORM-LEVEL configuration step that cannot be auto-completed here.
 */
import React from 'react';
import { AlertCircle } from 'lucide-react';

export default function CrossAppAuthNote() {
  return (
    <div className="rounded-2xl p-4"
      style={{
        background: 'rgba(245,182,66,0.06)',
        border: '1px solid rgba(245,182,66,0.25)',
      }}>
      <div className="flex items-start gap-3">
        <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" style={{ color: '#F5B642' }} />
        <div>
          <p className="text-sm font-black mb-1" style={{ color: '#F5B642' }}>
            ⚙️ Developer: Cross-App Shared Auth Required
          </p>
          <p className="text-xs leading-relaxed mb-3" style={{ color: 'rgba(255,255,255,0.50)' }}>
            <strong className="text-white/70">rhgo.base44.app</strong> and{' '}
            <strong className="text-white/70">rhgo2.base44.app</strong> are currently separate Base44 app instances
            with isolated databases and auth. To share user accounts, XP, subscriptions, pins, and data
            across both surfaces, both apps must be configured to use the same Base44 app backend.
          </p>
          <div className="space-y-1.5 text-xs" style={{ color: 'rgba(255,255,255,0.40)' }}>
            <p>✅ Step 1: In Base44 dashboard, confirm both surfaces point to the same App ID</p>
            <p>✅ Step 2: Set <code className="text-amber-400">STRIPE_SECRET_KEY</code> and <code className="text-amber-400">STRIPE_WEBHOOK_SECRET</code> in the shared backend</p>
            <p>✅ Step 3: Point Stripe webhook to: <code className="text-amber-400">/api/functions/stripeWebhook</code></p>
            <p>✅ Step 4: Set <code className="text-amber-400">STRIPE_FIELD_PRO_MONTHLY_PRICE_ID</code> and <code className="text-amber-400">STRIPE_FAMILY_MONTHLY_PRICE_ID</code> in environment secrets</p>
            <p>⚠️ Until connected: each app has isolated user data and subscription state</p>
          </div>
        </div>
      </div>
    </div>
  );
}