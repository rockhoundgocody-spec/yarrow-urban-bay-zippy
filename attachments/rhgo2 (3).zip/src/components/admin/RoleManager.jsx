import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Loader2, Search, User, Shield, History, Download } from "lucide-react";
import { ROLE_COLORS, ROLE_LABELS, ROLES, getPermissions } from "../auth/permissions";
import { formatDistanceToNow } from "date-fns";

const ROLE_OPTIONS = Object.keys(ROLES);

// Subscription tier metadata — values match User.subscription_tier enum
const TIER_LABELS = {
  free: "Free",
  trail_scout: "Trail Scout",
  crystal_pro: "Crystal Pro",
  expedition_elite: "Expedition Elite",
  stone: "Stone",
  crystal: "Crystal",
  diamond: "Diamond",
};
const TIER_OPTIONS = Object.keys(TIER_LABELS);
const TIER_COLORS = {
  free: "bg-white/10 text-white/50 border-white/15",
  trail_scout: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  crystal_pro: "bg-violet-500/15 text-violet-400 border-violet-500/25",
  expedition_elite: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  stone: "bg-stone-500/15 text-stone-300 border-stone-500/25",
  crystal: "bg-cyan-500/15 text-cyan-400 border-cyan-500/25",
  diamond: "bg-sky-400/15 text-sky-300 border-sky-400/25",
};

// Subscription status metadata — values match User.subscription_status enum
const STATUS_LABELS = {
  active: "Active",
  past_due: "Past Due",
  canceled: "Canceled",
  none: "None",
};
const STATUS_OPTIONS = Object.keys(STATUS_LABELS);
const STATUS_COLORS = {
  active: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  past_due: "bg-amber-500/15 text-amber-400 border-amber-500/25",
  canceled: "bg-red-500/15 text-red-400 border-red-500/25",
  none: "bg-white/10 text-white/40 border-white/15",
};

function PermissionsTable() {
  return (
    <div className="overflow-x-auto rounded-xl border border-white/5">
      <table className="w-full text-xs">
        <thead>
          <tr className="border-b border-white/5 text-white/30 uppercase">
            <th className="text-left p-3">Permission</th>
            {ROLE_OPTIONS.map(r => (
              <th key={r} className="text-center p-3">{ROLE_LABELS[r]}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {[
            "sites:view", "sites:create", "sites:edit", "sites:delete", "sites:verify",
            "moderation:view_queue", "moderation:resolve_flags",
            "users:view", "users:edit", "users:assign_roles",
            "analytics:view", "analytics:export", "admin:settings"
          ].map(perm => (
            <tr key={perm} className="border-b border-white/[0.03]">
              <td className="p-3 font-mono text-white/50">{perm}</td>
              {ROLE_OPTIONS.map(role => {
                const has = getPermissions(role).includes(perm);
                return (
                  <td key={role} className="p-3 text-center">
                    {has
                      ? <span className="text-emerald-400 font-bold">✓</span>
                      : <span className="text-white/15">—</span>}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function RoleManager({ currentUser }) {
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("all");
  const [activeTab, setActiveTab] = useState("users"); // users | permissions | audit
  const queryClient = useQueryClient();

  const { data: users = [], isLoading } = useQuery({
    queryKey: ["admin-users"],
    queryFn: () => base44.entities.User.list("-created_date", 200),
  });

  const { data: auditLogs = [] } = useQuery({
    queryKey: ["audit-logs"],
    queryFn: () => base44.entities.AuditLog.list("-created_date", 100),
    enabled: activeTab === "audit",
  });

  const updateRoleMutation = useMutation({
    mutationFn: async ({ userId, oldRole, newRole, targetEmail }) => {
      await base44.entities.User.update(userId, { role: newRole });
      await base44.entities.AuditLog.create({
        action: "role_change",
        target_user_id: userId,
        target_user_email: targetEmail,
        actor_email: currentUser.email,
        old_value: oldRole || "user",
        new_value: newRole,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
    },
  });

  // Manual tier override — admin edits a user's subscription_tier directly
  const updateTierMutation = useMutation({
    mutationFn: async ({ userId, oldTier, newTier, targetEmail }) => {
      await base44.entities.User.update(userId, { subscription_tier: newTier });
      await base44.entities.AuditLog.create({
        action: "tier_override",
        target_user_id: userId,
        target_user_email: targetEmail,
        actor_email: currentUser.email,
        old_value: oldTier || "free",
        new_value: newTier,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
    },
  });

  // Manual subscription status override — admin edits subscription_status directly
  const updateStatusMutation = useMutation({
    mutationFn: async ({ userId, oldStatus, newStatus, targetEmail }) => {
      await base44.entities.User.update(userId, { subscription_status: newStatus });
      await base44.entities.AuditLog.create({
        action: "status_override",
        target_user_id: userId,
        target_user_email: targetEmail,
        actor_email: currentUser.email,
        old_value: oldStatus || "none",
        new_value: newStatus,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-users"] });
      queryClient.invalidateQueries({ queryKey: ["audit-logs"] });
    },
  });

  const exportCSV = () => {
    const rows = [
      ["Full Name", "Email", "Role", "Joined"],
      ...users.map(u => [
        u.full_name || "",
        u.email || "",
        u.role || "user",
        u.created_date ? new Date(u.created_date).toLocaleDateString() : "",
      ]),
    ];
    const csv = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `rockhound_users_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filtered = users.filter(u => {
    const matchSearch = !search || u.full_name?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase());
    const matchRole = filterRole === "all" || (u.role || "user") === filterRole;
    return matchSearch && matchRole;
  });

  return (
    <div>
      {/* Tab switcher */}
      <div className="flex gap-1 mb-4 bg-white/5 rounded-lg p-1 w-fit">
        {[
          { id: "users", label: "Users", icon: User },
          { id: "permissions", label: "Permissions Matrix", icon: Shield },
          { id: "audit", label: "Audit Log", icon: History },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              activeTab === tab.id ? "bg-[var(--amber)]/15 text-[var(--amber)]" : "text-white/40 hover:text-white/70"
            }`}
          >
            <tab.icon className="w-3 h-3" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Users tab */}
      {activeTab === "users" && (
        <>
          <div className="flex gap-3 mb-4 flex-wrap">
            <div className="relative flex-1 min-w-48">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
              <Input
                placeholder="Search users..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 bg-[#14141e] border-white/10 text-white text-sm"
              />
            </div>
            <Select value={filterRole} onValueChange={setFilterRole}>
              <SelectTrigger className="w-36 bg-[#14141e] border-white/10 text-white text-sm">
                <SelectValue placeholder="Filter role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                {ROLE_OPTIONS.map(r => (
                  <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <button
              onClick={exportCSV}
              disabled={users.length === 0}
              className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold border border-emerald-500/25 text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 disabled:opacity-40 transition-all"
            >
              <Download className="w-3.5 h-3.5" /> Export CSV ({users.length})
            </button>
          </div>

          <Card className="bg-[#14141e] border-white/5 overflow-hidden">
            <ScrollArea className="h-[calc(100vh-420px)] min-h-64">
              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-white/5 text-white/30 text-xs uppercase">
                      <th className="text-left p-3">User</th>
                      <th className="text-left p-3">Current Role</th>
                      <th className="text-left p-3">Change Role</th>
                      <th className="text-left p-3">Tier</th>
                      <th className="text-left p-3">Sub Status</th>
                      <th className="text-left p-3 hidden md:table-cell">Joined</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map(u => (
                      <tr key={u.id} className="border-b border-white/[0.03] hover:bg-white/[0.02]">
                        <td className="p-3">
                          <div className="font-medium text-white/90 text-sm">{u.full_name || "—"}</div>
                          <div className="text-xs text-white/30">{u.email}</div>
                        </td>
                        <td className="p-3">
                          <Badge className={`text-[10px] border ${ROLE_COLORS[u.role || "user"]}`}>
                            {ROLE_LABELS[u.role || "user"]}
                          </Badge>
                        </td>
                        <td className="p-3">
                          {u.id !== currentUser.id ? (
                            <Select
                              value={u.role || "user"}
                              onValueChange={newRole => {
                                if (newRole !== (u.role || "user")) {
                                  updateRoleMutation.mutate({
                                    userId: u.id,
                                    oldRole: u.role || "user",
                                    newRole,
                                    targetEmail: u.email,
                                  });
                                }
                              }}
                            >
                              <SelectTrigger className="w-36 bg-white/5 border-white/10 text-white text-xs h-7">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {ROLE_OPTIONS.map(r => (
                                  <SelectItem key={r} value={r}>{ROLE_LABELS[r]}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : (
                            <span className="text-xs text-white/20 italic">You</span>
                          )}
                        </td>
                        <td className="p-3">
                          <Select
                            value={u.subscription_tier || "free"}
                            onValueChange={(newTier) => {
                              if (newTier !== (u.subscription_tier || "free")) {
                                updateTierMutation.mutate({
                                  userId: u.id,
                                  oldTier: u.subscription_tier || "free",
                                  newTier,
                                  targetEmail: u.email,
                                });
                              }
                            }}
                          >
                            <SelectTrigger className="w-36 bg-white/5 border-white/10 text-white text-xs h-7">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {TIER_OPTIONS.map((t) => (
                                <SelectItem key={t} value={t}>{TIER_LABELS[t]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-3">
                          <Select
                            value={u.subscription_status || "none"}
                            onValueChange={(newStatus) => {
                              if (newStatus !== (u.subscription_status || "none")) {
                                updateStatusMutation.mutate({
                                  userId: u.id,
                                  oldStatus: u.subscription_status || "none",
                                  newStatus,
                                  targetEmail: u.email,
                                });
                              }
                            }}
                          >
                            <SelectTrigger className="w-28 bg-white/5 border-white/10 text-white text-xs h-7">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {STATUS_OPTIONS.map((s) => (
                                <SelectItem key={s} value={s}>{STATUS_LABELS[s]}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="p-3 hidden md:table-cell text-xs text-white/30">
                          {u.created_date ? formatDistanceToNow(new Date(u.created_date), { addSuffix: true }) : "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </ScrollArea>
          </Card>
        </>
      )}

      {/* Permissions tab */}
      {activeTab === "permissions" && (
        <div>
          <p className="text-white/40 text-xs mb-4">Role permissions matrix — read only.</p>
          <PermissionsTable />
        </div>
      )}

      {/* Audit tab */}
      {activeTab === "audit" && (
        <Card className="bg-[#14141e] border-white/5 overflow-hidden">
          <ScrollArea className="h-[calc(100vh-380px)] min-h-64">
            {auditLogs.length === 0 ? (
              <div className="text-center py-12 text-white/30 text-sm">No audit log entries yet.</div>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/5 text-white/30 text-xs uppercase">
                    <th className="text-left p-3">When</th>
                    <th className="text-left p-3">Action</th>
                    <th className="text-left p-3">Target</th>
                    <th className="text-left p-3">Change</th>
                    <th className="text-left p-3 hidden md:table-cell">By</th>
                  </tr>
                </thead>
                <tbody>
                  {auditLogs.map(log => (
                    <tr key={log.id} className="border-b border-white/[0.03]">
                      <td className="p-3 text-xs text-white/30 whitespace-nowrap">
                        {formatDistanceToNow(new Date(log.created_date), { addSuffix: true })}
                      </td>
                      <td className="p-3">
                        <Badge className="text-[10px] bg-blue-500/10 text-blue-400 border-blue-500/20">{log.action}</Badge>
                      </td>
                      <td className="p-3 text-xs text-white/60">{log.target_user_email || "—"}</td>
                      <td className="p-3 text-xs">
                        {log.old_value && log.new_value ? (
                          <span>
                            <span className="text-red-400">{log.old_value}</span>
                            <span className="text-white/30 mx-1">→</span>
                            <span className="text-emerald-400">{log.new_value}</span>
                          </span>
                        ) : "—"}
                      </td>
                      <td className="p-3 text-xs text-white/30 hidden md:table-cell">{log.actor_email}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </ScrollArea>
        </Card>
      )}
    </div>
  );
}