/**
 * SpecimenPrivacyControls — location privacy controls for a saved specimen.
 *
 * Rockhounding locations are sensitive — collectors often guard their spots.
 * This component lets the user:
 *   1. Remove precise GPS coordinates from a specimen (irreversible)
 *   2. Link to full account-level privacy/consent settings
 */
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MapPinOff, ShieldCheck, Lock, Loader2, ChevronRight } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SpecimenPrivacyControls({ specimen, onUpdated }) {
  const navigate = useNavigate();
  const [removing, setRemoving] = useState(false);
  const [removed, setRemoved] = useState(false);
  const [error, setError] = useState(null);

  const hasCoords = specimen?.latitude != null || specimen?.longitude != null;
  const coordsRemoved = removed || (!hasCoords && !specimen?.locality_name);

  const handleRemoveCoords = async () => {
    if (!specimen?.id) return;
    setRemoving(true);
    setError(null);
    try {
      await base44.entities.Specimen.update(specimen.id, {
        latitude: null,
        longitude: null,
      });
      setRemoved(true);
      if (onUpdated) onUpdated({ ...specimen, latitude: null, longitude: null });
    } catch (e) {
      setError(e?.message || "Could not remove coordinates. Try again.");
    } finally {
      setRemoving(false);
    }
  };

  return (
    <div className="rounded-2xl p-4 space-y-3"
      style={{ background: "rgba(141,124,255,0.04)", border: "1px solid rgba(141,124,255,0.15)" }}>
      <div className="flex items-center gap-2">
        <Lock className="w-3.5 h-3.5" style={{ color: "#8D7CFF" }} />
        <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "rgba(141,124,255,0.5)" }}>
          Location Privacy
        </p>
      </div>

      {/* Status */}
      <div className="flex items-center gap-2.5">
        {coordsRemoved ? (
          <>
            <ShieldCheck className="w-4 h-4 flex-shrink-0" style={{ color: "#00D68F" }} />
            <p className="text-xs" style={{ color: "rgba(0,214,143,0.7)" }}>
              Precise coordinates removed — only locality name remains
            </p>
          </>
        ) : hasCoords ? (
          <>
            <MapPinOff className="w-4 h-4 flex-shrink-0" style={{ color: "#F5B642" }} />
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>
              Precise GPS coordinates are stored on this specimen
            </p>
          </>
        ) : (
          <>
            <ShieldCheck className="w-4 h-4 flex-shrink-0" style={{ color: "#00D68F" }} />
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>
              No precise coordinates stored
            </p>
          </>
        )}
      </div>

      {/* Action: remove coordinates */}
      {hasCoords && !coordsRemoved && (
        <button
          onClick={handleRemoveCoords}
          disabled={removing}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-opacity hover:opacity-80 disabled:opacity-50"
          style={{ background: "rgba(255,60,60,0.08)", border: "1px solid rgba(255,60,60,0.20)", color: "#FF6B6B" }}
        >
          {removing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MapPinOff className="w-3.5 h-3.5" />}
          {removing ? "Removing…" : "Remove precise coordinates"}
        </button>
      )}

      {error && (
        <p className="text-xs text-red-400 px-1">{error}</p>
      )}

      {/* Link to full privacy settings */}
      <button
        onClick={() => navigate("/PrivacyControls")}
        className="w-full flex items-center justify-between gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold transition-opacity hover:opacity-80"
        style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)" }}
      >
        <span className="flex items-center gap-2">
          <ShieldCheck className="w-3.5 h-3.5" />
          Account privacy & consent settings
        </span>
        <ChevronRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}