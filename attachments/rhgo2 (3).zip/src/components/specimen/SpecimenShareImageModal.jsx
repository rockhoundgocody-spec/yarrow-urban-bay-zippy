import React, { useState, useRef, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Image as ImageIcon, Download, Share2, Loader2, Check, RotateCcw } from "lucide-react";
import html2canvas from "html2canvas";
import SpecimenShareCard from "./SpecimenShareCard";

const THEMES = [
  { key: "obsidian", label: "Obsidian", swatch: "linear-gradient(135deg,#05070A,#0E141B)" },
  { key: "quartz", label: "Quartz", swatch: "linear-gradient(135deg,#FFFFFF,#E8EEF3)" },
  { key: "field", label: "Field", swatch: "linear-gradient(135deg,#010806,#04140B)" },
];

/** Wait for all <img> inside a node to finish loading (html2canvas needs decoded pixels). */
function awaitImages(node) {
  const imgs = Array.from(node.querySelectorAll("img"));
  return Promise.all(
    imgs.map((img) => {
      if (img.complete && img.naturalWidth > 0) return Promise.resolve();
      return new Promise((resolve) => {
        img.addEventListener("load", resolve, { once: true });
        img.addEventListener("error", resolve, { once: true });
        // Safety timeout — never block capture forever
        setTimeout(resolve, 4000);
      });
    })
  );
}

export default function SpecimenShareImageModal({ specimen, open, onClose }) {
  const [theme, setTheme] = useState("obsidian");
  const [showValue, setShowValue] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [imageBlob, setImageBlob] = useState(null);
  const [image_url, setImageUrl] = useState(null);
  const [error, setError] = useState("");
  const [shared, setShared] = useState(false);
  const cardRef = useRef(null);

  const generate = useCallback(async () => {
    if (!cardRef.current) return;
    setGenerating(true);
    setError("");
    try {
      await awaitImages(cardRef.current);
      // Small delay for layout/paint settle
      await new Promise((r) => setTimeout(r, 120));
      const canvas = await html2canvas(cardRef.current, {
        width: 1080,
        height: 1080,
        scale: 2,
        useCORS: true,
        allowTaint: false,
        backgroundColor: "#05070A",
        logging: false,
      });
      const blob = await new Promise((resolve) =>
        canvas.toBlob((b) => resolve(b), "image/png", 0.95)
      );
      if (!blob) throw new Error("Failed to render image");
      if (image_url) URL.revokeObjectURL(image_url);
      const url = URL.createObjectURL(blob);
      setImageBlob(blob);
      setImageUrl(url);
    } catch (err) {
      setError(err?.message || "Could not generate image. Try another theme.");
    } finally {
      setGenerating(false);
    }
  }, [image_url]);

  // Auto-generate on open + whenever theme/value/specimen changes (after preview mounts)
  useEffect(() => {
    if (!open || !specimen) return;
    // Reset any prior result so the hidden full-res card remounts for capture
    if (image_url) {
      URL.revokeObjectURL(image_url);
      setImageBlob(null);
      setImageUrl(null);
    }
    // Wait two frames so cardRef is attached, then capture
    const id = setTimeout(() => {
      generate();
    }, 60);
    return () => clearTimeout(id);
     
  }, [open, specimen, theme, showValue]);

  const handleDownload = () => {
    if (!imageBlob) return;
    const url = URL.createObjectURL(imageBlob);
    const a = document.createElement("a");
    a.href = url;
    const safeName = (specimen?.name || "specimen").replace(/[^a-z0-9]+/gi, "-").toLowerCase();
    a.download = `rockhound-go-${safeName}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handleShare = async () => {
    if (!imageBlob) return;
    const file = new File([imageBlob], "rockhound-go-find.png", { type: "image/png" });
    const shareData = {
      title: `${specimen?.name || "My mineral find"} — RockHound-GO`,
      text: `Check out my ${specimen?.name || "mineral find"}${specimen?.locality_name ? ` from ${specimen.locality_name}` : ""}! #RockHoundGO`,
      files: [file],
    };
    try {
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share(shareData);
        setShared(true);
        setTimeout(() => setShared(false), 1800);
      } else {
        handleDownload();
        if (navigator.clipboard) {
          navigator.clipboard.writeText(shareData.text).catch(() => {});
        }
        setShared(true);
        setTimeout(() => setShared(false), 1800);
      }
    } catch (err) {
      if (err?.name !== "AbortError") handleDownload();
    }
  };

  const reset = () => {
    if (image_url) URL.revokeObjectURL(image_url);
    setImageBlob(null);
    setImageUrl(null);
    setError("");
    setShared(false);
  };

  const close = () => {
    reset();
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[60] flex items-center justify-center p-4"
          style={{ background: "rgba(2,4,10,0.82)", backdropFilter: "blur(6px)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={close}
        >
          <motion.div
            className="w-full max-w-lg rounded-2xl overflow-hidden shadow-2xl"
            style={{
              background: "linear-gradient(160deg, rgba(12,8,28,0.98) 0%, rgba(6,10,18,0.99) 100%)",
              border: "1px solid rgba(0,214,143,0.22)",
            }}
            initial={{ opacity: 0, scale: 0.94 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.94 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-5 border-b border-white/5">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5" style={{ color: "#7AE7FF" }} />
                <h2 className="text-lg font-bold text-white">Share Card</h2>
              </div>
              <button
                onClick={close}
                className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10"
                style={{ minHeight: "unset", minWidth: "unset" }}
               aria-label="Close">
                <X className="w-5 h-5 text-white/60" />
              </button>
            </div>

            <div className="p-5 space-y-4">
              {/* Preview area */}
              <div className="flex justify-center">
                <div
                  style={{
                    width: 280,
                    height: 280,
                    borderRadius: 16,
                    overflow: "hidden",
                    border: "1px solid rgba(255,255,255,0.10)",
                    boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
                    background: "#05070A",
                    position: "relative",
                  }}
                >
                  {image_url ? (
                    <img src={image_url} alt="Generated share card" className="w-full h-full object-cover" />
                  ) : (
                    <div style={{ transform: "scale(0.259)", transformOrigin: "top left", width: 1080, height: 1080 }}>
                      <div ref={cardRef}>
                        <SpecimenShareCard specimen={specimen} theme={theme} showValue={showValue} />
                      </div>
                    </div>
                  )}
                  {/* Generating overlay */}
                  {generating && (
                    <div
                      className="absolute inset-0 flex flex-col items-center justify-center gap-2"
                      style={{ background: "rgba(5,7,10,0.78)" }}
                    >
                      <Loader2 className="w-7 h-7 animate-spin" style={{ color: "#00D68F" }} />
                      <span className="text-[11px] font-semibold text-white/60">Rendering crystal card…</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Hidden full-res card for capture (always rendered while no image yet) */}
              {!image_url && (
                <div
                  style={{
                    position: "absolute",
                    left: -10000,
                    top: 0,
                    width: 1080,
                    height: 1080,
                    pointerEvents: "none",
                  }}
                  aria-hidden="true"
                >
                  <div ref={cardRef}>
                    <SpecimenShareCard specimen={specimen} theme={theme} showValue={showValue} />
                  </div>
                </div>
              )}

              {/* Theme picker */}
              <div>
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-2">Style</p>
                <div className="grid grid-cols-3 gap-2">
                  {THEMES.map((t) => {
                    const active = theme === t.key;
                    return (
                      <button
                        key={t.key}
                        onClick={() => setTheme(t.key)}
                        className="flex flex-col items-center gap-1.5 py-2.5 rounded-xl border transition-all"
                        style={{
                          background: active ? "rgba(0,214,143,0.10)" : "rgba(255,255,255,0.03)",
                          borderColor: active ? "rgba(0,214,143,0.40)" : "rgba(255,255,255,0.08)",
                          minHeight: "unset",
                        }}
                      >
                        <span className="w-8 h-8 rounded-lg" style={{ background: t.swatch, border: "1px solid rgba(255,255,255,0.15)" }} />
                        <span className="text-xs font-semibold" style={{ color: active ? "#00D68F" : "rgba(255,255,255,0.55)" }}>
                          {t.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Value toggle */}
              <button
                onClick={() => setShowValue((v) => !v)}
                className="w-full flex items-center justify-between px-4 py-3 rounded-xl border"
                style={{
                  background: showValue ? "rgba(245,182,66,0.06)" : "rgba(255,255,255,0.03)",
                  borderColor: showValue ? "rgba(245,182,66,0.25)" : "rgba(255,255,255,0.08)",
                  minHeight: "unset",
                }}
              >
                <span className="text-sm font-semibold text-white/80">Show estimated value</span>
                <span
                  className="w-10 h-6 rounded-full relative transition-all"
                  style={{ background: showValue ? "#F5B642" : "rgba(255,255,255,0.15)" }}
                >
                  <span
                    className="absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all"
                    style={{ left: showValue ? 18 : 2 }}
                  />
                </span>
              </button>

              {/* Error */}
              {error && (
                <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                  <p className="text-xs text-red-300">{error}</p>
                </div>
              )}

              {/* Actions — auto-generated, so always show Download/Share */}
              <div className="flex gap-3">
                <button
                  onClick={reset}
                  disabled={generating}
                  className="px-4 py-3.5 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 disabled:opacity-40"
                  style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.7)", minHeight: "unset" }}
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Redo
                </button>
                <button
                  onClick={handleDownload}
                  disabled={!imageBlob || generating}
                  className="flex-1 py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40"
                  style={{ background: "rgba(122,231,255,0.12)", border: "1px solid rgba(122,231,255,0.30)", color: "#7AE7FF", minHeight: "unset" }}
                >
                  <Download className="w-4 h-4" /> Download
                </button>
                <button
                  onClick={handleShare}
                  disabled={!imageBlob || generating}
                  className="flex-1 py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40"
                  style={{ background: "linear-gradient(135deg, #00D68F, #7AE7FF)", color: "#000", minHeight: "unset" }}
                >
                  {shared ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                  {shared ? "Shared!" : "Share"}
                </button>
              </div>

              <p className="text-[11px] text-white/30 text-center leading-relaxed">
                1080×1080 PNG · Auto-generated · Perfect for Instagram, X, Facebook & Reddit
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}