/**
 * Procedural specimen habits, built with plain three.js.
 * Kept out of the React layer so the renderer stays presentational.
 */
import * as THREE from "three";

function physicalMaterial(preset) {
  return new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(preset.color),
    emissive: new THREE.Color(preset.emissive),
    metalness: preset.metalness,
    roughness: preset.roughness,
    transmission: preset.transmission,
    ior: preset.ior,
    thickness: preset.thickness,
    envMapIntensity: preset.envMapIntensity,
    transparent: preset.transmission > 0,
    opacity: preset.transmission > 0 ? 0.95 : 1,
    side: THREE.DoubleSide,
  });
}

function matrixBase(radius = 0.65) {
  const geo = new THREE.SphereGeometry(radius, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2);
  const mat = new THREE.MeshStandardMaterial({ color: 0x3d3530, roughness: 0.9, metalness: 0.1 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.y = -0.35;
  mesh.receiveShadow = true;
  return mesh;
}

function crystalCluster(material) {
  const group = new THREE.Group();
  const count = 9;
  for (let i = 0; i < count; i++) {
    const angle = (i / count) * Math.PI * 2;
    const radius = i === 0 ? 0 : 0.3 + Math.random() * 0.25;
    const height = 0.6 + Math.random() * 0.9;
    const scale = 0.08 + Math.random() * 0.12;
    const mesh = new THREE.Mesh(
      new THREE.CylinderGeometry(scale * 0.4, scale, height, 6),
      material
    );
    mesh.position.set(Math.cos(angle) * radius, height / 2 - 0.2, Math.sin(angle) * radius);
    mesh.rotation.set((Math.random() - 0.5) * 0.4, 0, (Math.random() - 0.5) * 0.3);
    mesh.castShadow = true;
    group.add(mesh);
  }
  group.add(matrixBase());
  return group;
}

function cubicSpecimen(material) {
  const group = new THREE.Group();
  const positions = [
    [0, 0, 0], [0.45, 0.1, 0.1], [-0.3, 0.15, 0.2],
    [0.1, 0.42, -0.1], [-0.1, -0.05, -0.35], [0.35, -0.1, -0.2],
  ];
  positions.forEach(([x, y, z]) => {
    const size = 0.22 + Math.random() * 0.1;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(size, size, size), material);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    group.add(mesh);
  });
  return group;
}

function roundedSpecimen(material) {
  const group = new THREE.Group();
  const main = new THREE.Mesh(new THREE.SphereGeometry(0.7, 48, 48), material);
  main.castShadow = true;
  const lobe = new THREE.Mesh(new THREE.SphereGeometry(0.35, 32, 32), material);
  lobe.position.set(0.3, -0.5, 0.2);
  lobe.castShadow = true;
  const plinth = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.6, 0.12, 32),
    new THREE.MeshStandardMaterial({ color: 0x3d3530, roughness: 0.95 })
  );
  plinth.position.y = -0.75;
  plinth.receiveShadow = true;
  group.add(main, lobe, plinth);
  return group;
}

function shardSpecimen(material) {
  const group = new THREE.Group();
  const shards = [
    { pos: [0, 0.3, 0], scale: [0.18, 1.1, 0.12], rot: [0.1, 0, 0.05] },
    { pos: [0.25, 0, 0.1], scale: [0.12, 0.8, 0.1], rot: [0.2, 0.3, 0.15] },
    { pos: [-0.22, 0.1, -0.1], scale: [0.1, 0.7, 0.08], rot: [-0.1, -0.2, -0.1] },
    { pos: [0.08, -0.1, 0.3], scale: [0.14, 0.6, 0.09], rot: [0.3, 0.1, 0.2] },
  ];
  shards.forEach((s) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(...s.scale), material);
    mesh.position.set(...s.pos);
    mesh.rotation.set(...s.rot);
    mesh.castShadow = true;
    group.add(mesh);
  });
  return group;
}

/** Build the specimen group for a preset. Caller disposes via disposeGroup(). */
export function buildSpecimen(preset) {
  const material = physicalMaterial(preset);
  switch (preset.geometry) {
    case "crystal_cluster": return crystalCluster(material);
    case "cubic": return cubicSpecimen(material);
    case "shard": return shardSpecimen(material);
    default: return roundedSpecimen(material);
  }
}

export function disposeGroup(group) {
  group?.traverse?.((child) => {
    child.geometry?.dispose?.();
    if (Array.isArray(child.material)) child.material.forEach((m) => m.dispose?.());
    else child.material?.dispose?.();
  });
}