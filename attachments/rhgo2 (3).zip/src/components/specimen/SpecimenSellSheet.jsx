import React from "react";
import { ArrowRight, Store, ShieldCheck, Gem } from "lucide-react";
import GlassSurface from "@/components/effects/GlassSurface";
import LiquidButton from "@/components/ui/LiquidButton";
import StatusChip from "@/components/ui/StatusChip";
import SectionHeader from "@/components/ui/SectionHeader";
import { createListingFromSpecimen } from "@/services/marketplace/listingFactory";
import { useListingStore } from "@/stores/listingStore";
import { normalizeConfidence } from "@/utils";

export default function SpecimenSellSheet({
  specimen,
  currentUser,
  onClose,
  onCreated,
}) {
  const upsertListing = useListingStore((s) => s.upsertListing);
  const setActiveListingId = useListingStore((s) => s.setActiveListingId);

  const handleCreateDraft = () => {
    const listing = createListingFromSpecimen(specimen, currentUser.id);
    upsertListing(listing);
    setActiveListingId(listing.id);
    onCreated?.(listing);
  };

  return (
    <div className="fixed inset-0 z-[90] bg-black/60 backdrop-blur-md">
      <div className="absolute inset-x-4 bottom-4 mx-auto max-w-2xl">
        <GlassSurface tone="dark" rounded="hero" className="overflow-hidden">
          <SectionHeader
            eyebrow="Specimen → Market Bridge"
            title="Create listing from specimen"
            subtitle="AI explanation, provenance, locality, and valuation carry into the listing draft automatically."
          />

          <div className="mt-5 rounded-[24px] border border-white/10 bg-white/[0.04] p-4">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-cyan-500/15 text-cyan-300">
                <Gem className="h-6 w-6" />
              </div>

              <div className="min-w-0">
                <div className="text-base font-semibold text-white">
                  {specimen.label}
                </div>
                <div className="mt-1 text-sm text-white/60">
                  {specimen.classification.mineral}
                  {specimen.classification.variety ? ` · ${specimen.classification.variety}` : ""}
                  {specimen.geo?.localityName ? ` · ${specimen.geo.localityName}` : ""}
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <StatusChip tone="discovery">
                    {normalizeConfidence(specimen.confidence)}% confidence
                  </StatusChip>
                  <StatusChip tone="info">{specimen.status}</StatusChip>
                  <StatusChip tone="success">
                    {specimen.provenance?.chain?.length || 0} provenance events
                  </StatusChip>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 rounded-[24px] border border-emerald-300/15 bg-emerald-500/10 p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-emerald-200">
              <ShieldCheck className="h-4 w-4" />
              Trust layer carries over
            </div>
            <div className="mt-1 text-xs leading-6 text-emerald-100/75">
              The listing inherits locality, AI explanation, provenance chain, legality context, and valuation range from the canonical specimen.
            </div>
          </div>

          <div className="mt-5 grid gap-3">
            <LiquidButton
              variant="gold"
              leftIcon={<Store className="h-4 w-4" />}
              rightIcon={<ArrowRight className="h-4 w-4" />}
              onClick={handleCreateDraft}
            >
              Create draft listing
            </LiquidButton>

            <LiquidButton
              variant="ghost"
              onClick={onClose}
            >
              Cancel
            </LiquidButton>
          </div>
        </GlassSurface>
      </div>
    </div>
  );
}