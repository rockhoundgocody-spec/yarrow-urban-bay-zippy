/**
 * SpecimenScene — plain three.js renderer for the specimen viewer.
 * Deliberately not react-three-fiber: the R3F/three version pairing has
 * already broken rendering here once.
 */
import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { buildSpecimen, disposeGroup } from "./specimenGeometry";

const LIGHT_MODES = {
  studio: { ambient: 0.4, key: 2.5, keyColor: 0xffffff, extra: null },
  warm: { ambient: 0.3, key: 2.2, keyColor: 0xffe8c0, extra: null },
  uv: { ambient: 0.15, key: 1.2, keyColor: 0xffffff, extra: { color: 0x8800ff, intensity: 2.4, position: [0, 2, 2] } },
  field: { ambient: 0.25, key: 3.0, keyColor: 0xffd700, extra: null },
};

export default function SpecimenScene({ preset, lightMode = "studio", autoRotate = true, resetTrigger = 0 }) {
  const mountRef = useRef(null);
  const stateRef = useRef({});

  // One-time renderer / scene setup
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return undefined;

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return undefined; // No WebGL — the still-image fallback in the parent shows instead.
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight || 1, 0.1, 100);
    camera.position.set(0, 1, 3);

    const ambient = new THREE.AmbientLight(0xffffff, 0.4);
    const key = new THREE.DirectionalLight(0xffffff, 2.5);
    key.position.set(5, 8, 3);
    const fill = new THREE.DirectionalLight(0x88aaff, 0.6);
    fill.position.set(-4, 2, -3);
    const top = new THREE.PointLight(0xffffff, 0.8);
    top.position.set(0, 4, 0);
    const accent = new THREE.PointLight(0x8800ff, 0);
    scene.add(ambient, key, fill, top, accent);

    const pivot = new THREE.Group();
    scene.add(pivot);

    const state = { renderer, scene, camera, pivot, ambient, key, accent, radius: 3, yaw: 0, pitch: 0.3, dragging: false, last: null, autoRotate: true, specimen: null };
    stateRef.current = state;

    const applyCamera = () => {
      const r = state.radius;
      camera.position.set(
        r * Math.cos(state.pitch) * Math.sin(state.yaw),
        r * Math.sin(state.pitch) + 0.4,
        r * Math.cos(state.pitch) * Math.cos(state.yaw)
      );
      camera.lookAt(0, 0, 0);
    };
    state.applyCamera = applyCamera;
    applyCamera();

    const onPointerDown = (e) => { state.dragging = true; state.last = { x: e.clientX, y: e.clientY }; };
    const onPointerMove = (e) => {
      if (!state.dragging || !state.last) return;
      state.yaw -= (e.clientX - state.last.x) * 0.008;
      state.pitch = Math.max(-0.4, Math.min(1.2, state.pitch + (e.clientY - state.last.y) * 0.006));
      state.last = { x: e.clientX, y: e.clientY };
      applyCamera();
    };
    const onPointerUp = () => { state.dragging = false; state.last = null; };
    const onWheel = (e) => {
      e.preventDefault();
      state.radius = Math.max(1.2, Math.min(6, state.radius + e.deltaY * 0.002));
      applyCamera();
    };

    const el = renderer.domElement;
    el.style.touchAction = "none";
    el.addEventListener("pointerdown", onPointerDown);
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
    el.addEventListener("wheel", onWheel, { passive: false });

    const resize = () => {
      if (!mount.clientWidth || !mount.clientHeight) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    const observer = new ResizeObserver(resize);
    observer.observe(mount);

    let frame;
    let prev = performance.now();
    const loop = (now) => {
      const delta = (now - prev) / 1000;
      prev = now;
      if (state.autoRotate && !state.dragging) pivot.rotation.y += delta * 0.3;
      renderer.render(scene, camera);
      frame = requestAnimationFrame(loop);
    };
    frame = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(frame);
      observer.disconnect();
      el.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      el.removeEventListener("wheel", onWheel);
      if (state.specimen) disposeGroup(state.specimen);
      renderer.dispose();
      el.remove();
    };
  }, []);

  // Swap specimen when the preset changes
  useEffect(() => {
    const state = stateRef.current;
    if (!state.pivot) return;
    if (state.specimen) {
      state.pivot.remove(state.specimen);
      disposeGroup(state.specimen);
    }
    state.specimen = buildSpecimen(preset);
    state.pivot.add(state.specimen);
  }, [preset]);

  useEffect(() => {
    const state = stateRef.current;
    if (!state.ambient) return;
    const cfg = LIGHT_MODES[lightMode] || LIGHT_MODES.studio;
    state.ambient.intensity = cfg.ambient;
    state.key.intensity = cfg.key;
    state.key.color.setHex(cfg.keyColor);
    state.accent.intensity = cfg.extra ? cfg.extra.intensity : 0;
    if (cfg.extra) state.accent.position.set(...cfg.extra.position);
  }, [lightMode]);

  useEffect(() => { stateRef.current.autoRotate = autoRotate; }, [autoRotate]);

  useEffect(() => {
    const state = stateRef.current;
    if (!state.applyCamera || !resetTrigger) return;
    state.yaw = 0;
    state.pitch = 0.3;
    state.radius = 3;
    state.pivot.rotation.y = 0;
    state.applyCamera();
  }, [resetTrigger]);

  return <div ref={mountRef} className="absolute inset-0" />;
}