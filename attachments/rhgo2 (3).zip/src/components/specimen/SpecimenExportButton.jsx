/**
 * SpecimenExportButton — downloads the full specimen record as a JSON file.
 * Works fully client-side (offline-friendly).
 */
import React from "react";
import { Download } from "lucide-react";

export default function SpecimenExportButton({ specimen }) {
  const handleExport = () => {
    const record = {
      exported_at: new Date().toISOString(),
      app: "RockHound-GO",
      specimen,
    };
    const blob = new Blob([JSON.stringify(record, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${(specimen.name || "specimen").replace(/[^a-z0-9]/gi, "_").toLowerCase()}_record.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <button onClick={handleExport}
      className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl text-xs font-semibold"
      style={{ background: "rgba(122,231,255,0.06)", border: "1px solid rgba(122,231,255,0.16)", color: "rgba(122,231,255,0.75)" }}>
      <Download className="w-3.5 h-3.5" /> Export Record
    </button>
  );
}