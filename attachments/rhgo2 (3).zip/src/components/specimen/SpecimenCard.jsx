import React from "react";
import { motion } from "framer-motion";
import {
  MapPin,
  ShieldAlert,
  BadgeCheck,
  WifiOff,
  Gem,
  Sparkles,
} from "lucide-react";
import StatusChip from "@/components/ui/StatusChip";
import ShimmerSweep from "@/components/effects/ShimmerSweep";
import { crystallineUnfoldVariants, crystallineUnfoldViewport, crystallineUnfoldTransition } from "@/components/effects/CrystallineUnfold";
import { specimenConfidencePercent, specimenValueLabel } from "@/services/specimen/specimenValuation";

function statusMeta(specimen) {
  if (specimen.status === "verified") {
    return {
      label: "Verified",
      tone: "success",
      icon: <BadgeCheck className="h-3.5 w-3.5" />,
    };
  }

  if (
    specimen.syncStatus === "queued" ||
    specimen.syncStatus === "failed" ||
    specimen.syncStatus === "local_only"
  ) {
    return {
      label: "Unsynced",
      tone: "warning",
      icon: <WifiOff className="h-3.5 w-3.5" />,
    };
  }

  return {
    label: "Identified",
    tone: "discovery",
    icon: <Sparkles className="h-3.5 w-3.5" />,
  };
}

function rarityGlow(specimen) {
  const value = specimen.valuation?.estimatedValue || specimen.valuation?.high || 0;

  if (value >= 250) return "shadow-[0_0_28px_rgba(255,201,74,0.24)]";
  if (value >= 100) return "shadow-[0_0_24px_rgba(155,109,255,0.22)]";
  if (value >= 40) return "shadow-[0_0_22px_rgba(91,192,255,0.20)]";
  return "shadow-[0_14px_32px_rgba(20,33,43,0.16)]";
}

export default function SpecimenCard({ specimen, onPress }) {
  const badge = statusMeta(specimen);
  const legalityWarning =
    specimen.geo?.legalityStatus &&
    specimen.geo.legalityStatus !== "allowed" &&
    specimen.geo.legalityStatus !== "unknown";

  return (
    <motion.button
      type="button"
      onClick={() => onPress?.(specimen)}
      whileTap={{ scale: 0.985 }}
      whileHover={{ scale: 1.01 }}
      className={`group relative w-full overflow-hidden rounded-[30px] border border-white/10 bg-white/70 text-left shadow-2xl backdrop-blur-xl ${rarityGlow(specimen)}`}
      variants={crystallineUnfoldVariants}
      initial="hidden"
      whileInView="shown"
      viewport={crystallineUnfoldViewport}
      transition={crystallineUnfoldTransition}
      style={{ transformPerspective: 1000, transformStyle: "preserve-3d" }}
    >
      <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(255,255,255,0.10)_0%,rgba(255,255,255,0.02)_100%)]" />
      <div className="absolute -top-10 right-0 h-28 w-28 rounded-full bg-cyan-300/10 blur-2xl" />
      <div className="absolute bottom-0 left-0 h-24 w-24 rounded-full bg-violet-300/10 blur-2xl" />

      <div className="relative">
        <div className="relative aspect-[4/4.6] overflow-hidden rounded-t-[30px]">
          {specimen.photos?.[0] ? (
            <img
              src={specimen.photos[0]}
              alt={specimen.label}
              className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.03]"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-sky-50 to-amber-50">
              <Gem className="h-10 w-10 text-cyan-300" />
            </div>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-[#14212B]/90 via-[#14212B]/10 to-transparent" />
          <ShimmerSweep tone="cyan" />

          <div className="absolute left-3 top-3 flex flex-wrap items-center gap-2">
            {legalityWarning && (
              <StatusChip
                tone="danger"
                icon={<ShieldAlert className="h-3.5 w-3.5" />}
              >
                {specimen.geo.legalityStatus}
              </StatusChip>
            )}

            <StatusChip tone="info">
              {specimenConfidencePercent(specimen)}%
            </StatusChip>
          </div>

          <div className="absolute right-3 top-3">
            <StatusChip tone={badge.tone} icon={badge.icon}>
              {badge.label}
            </StatusChip>
          </div>

          <div className="absolute inset-x-0 bottom-0 p-4">
            <div className="mb-2 flex flex-wrap items-center gap-2">
              <StatusChip tone="default">{specimen.classification.mineral}</StatusChip>
              {specimen.classification.group && (
                <StatusChip tone="info">{specimen.classification.group}</StatusChip>
              )}
              {specimen.classification.variety && (
                <StatusChip tone="premium">{specimen.classification.variety}</StatusChip>
              )}
            </div>

            <h3 className="text-xl font-semibold leading-tight text-white">
              {specimen.label}
            </h3>

            <div className="mt-3 flex items-center justify-between gap-3">
              <div className="text-sm font-semibold text-emerald-300">
                {specimenValueLabel(specimen)}
              </div>

              <div className="flex items-center gap-1 text-xs text-white/65">
                <MapPin className="h-3.5 w-3.5 text-cyan-300" />
                {specimen.geo?.localityName || "Unknown locality"}
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.button>
  );
}