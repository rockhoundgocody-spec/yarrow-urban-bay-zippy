/**
 * SpecimenAddedBurst — celebration overlay when a specimen is saved to collection.
 * Typically mounted inside the SaveToCollectionPanel or IdentifyResult page.
 *
 * Props:
 *  active       boolean
 *  specimenName string
 *  rarity       string  — "common" | "uncommon" | "rare" | "epic" | "legendary"
 *  onDone       fn
 */

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Gem, Star } from "lucide-react";
import SuccessBurst from "@/animation/SuccessBurst";

const RARITY_COLOR = {
  common:    "#7DF9FF",
  uncommon:  "#00FFC6",
  rare:      "#9B5CFF",
  epic:      "#FF6EC7",
  legendary: "#FFC857",
};

export default function SpecimenAddedBurst({ active, specimenName, rarity = "common", onDone }) {
  const color = RARITY_COLOR[rarity] || RARITY_COLOR.common;

  return (
    <AnimatePresence>
      {active && (
        <motion.div
          className="pointer-events-none fixed inset-0 z-[300] flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          {/* Dark veil */}
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />

          <div className="relative flex flex-col items-center gap-4">
            {/* Icon ring */}
            <div className="relative flex items-center justify-center">
              <motion.div
                className="h-28 w-28 rounded-full"
                style={{ background: `radial-gradient(circle, ${color}28 0%, transparent 70%)` }}
                animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <motion.div
                className="absolute flex h-20 w-20 items-center justify-center rounded-full border-2"
                style={{ borderColor: `${color}60`, background: "rgba(5,7,10,0.85)" }}
                initial={{ scale: 0.4, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 320, damping: 24 }}
              >
                <Gem className="h-9 w-9" style={{ color }} />
              </motion.div>
              <SuccessBurst active={active} color={color} count={18} radius={72} />
            </div>

            {/* Text */}
            <motion.div
              className="flex flex-col items-center gap-1.5"
              initial={{ y: 16, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.22, duration: 0.4 }}
            >
              <span className="text-[10px] font-bold uppercase tracking-[0.28em]" style={{ color }}>
                Added to Collection
              </span>
              {specimenName && (
                <span className="text-xl font-bold text-white">{specimenName}</span>
              )}
              <div
                className="mt-1 flex items-center gap-1.5 rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-widest"
                style={{ background: `${color}15`, border: `1px solid ${color}35`, color }}
              >
                <Star className="h-3 w-3" />
                {rarity}
              </div>
            </motion.div>

            {/* Dismiss hint */}
            <motion.div
              className="text-[10px] text-white/25"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
              onClick={onDone}
            >
              tap to continue
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}