import React from "react";

/**
 * SpecimenShareCard — fixed 1080×1080 crystal-style poster for social sharing.
 * Pure presentational; captured by html2canvas in SpecimenShareImageModal.
 * CSS kept html2canvas-safe: no backdrop-blur, no clip-path, no conic-gradient.
 * Only solid fills, linear/radial gradients, borders, box-shadows, transforms.
 *
 * Props: specimen, theme ('obsidian'|'quartz'|'field'), showValue (bool)
 */
const THEMES = {
  obsidian: {
    bg: "#05070A",
    bgGradient: "linear-gradient(160deg, #0A0F14 0%, #05070A 100%)",
    panel: "rgba(255,255,255,0.04)",
    panelBorder: "rgba(255,255,255,0.08)",
    text: "#FFFFFF",
    textDim: "rgba(255,255,255,0.45)",
    textFaint: "rgba(255,255,255,0.28)",
    accent: "#00D68F",
    accent2: "#7AE7FF",
    accent3: "#8D7CFF",
    accentSoft: "rgba(0,214,143,0.12)",
    accentBorder: "rgba(0,214,143,0.28)",
    facetTint: "rgba(122,231,255,0.10)",
  },
  quartz: {
    bg: "#F3F7FA",
    bgGradient: "linear-gradient(160deg, #FFFFFF 0%, #E8EEF3 100%)",
    panel: "rgba(15,23,32,0.04)",
    panelBorder: "rgba(15,23,32,0.08)",
    text: "#0E141B",
    textDim: "rgba(14,20,27,0.55)",
    textFaint: "rgba(14,20,27,0.32)",
    accent: "#00A06B",
    accent2: "#1B9FCB",
    accent3: "#7C5BC8",
    accentSoft: "rgba(0,160,107,0.10)",
    accentBorder: "rgba(0,160,107,0.24)",
    facetTint: "rgba(27,159,203,0.10)",
  },
  field: {
    bg: "#010806",
    bgGradient: "linear-gradient(160deg, #04140B 0%, #010806 100%)",
    panel: "rgba(74,163,84,0.06)",
    panelBorder: "rgba(74,163,84,0.18)",
    text: "#F0FFF4",
    textDim: "rgba(240,255,244,0.55)",
    textFaint: "rgba(240,255,244,0.30)",
    accent: "#4AA354",
    accent2: "#88FF99",
    accent3: "#7AE7FF",
    accentSoft: "rgba(74,163,84,0.12)",
    accentBorder: "rgba(74,163,84,0.32)",
    facetTint: "rgba(136,255,153,0.10)",
  },
};

function StatCell({ label, value, theme }) {
  if (value === null || value === undefined || value === "") return null;
  return (
    <div
      style={{
        background: theme.panel,
        border: `1px solid ${theme.panelBorder}`,
        borderRadius: 14,
        padding: "16px 18px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Crystalline left accent bar */}
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 0,
          bottom: 0,
          width: 3,
          background: `linear-gradient(180deg, ${theme.accent}, ${theme.accent2})`,
        }}
      />
      <p style={{ fontSize: 12, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: theme.textFaint, margin: 0 }}>
        {label}
      </p>
      <p style={{ fontSize: 20, fontWeight: 700, color: theme.text, margin: "4px 0 0", lineHeight: 1.2, textTransform: "capitalize" }}>
        {value}
      </p>
    </div>
  );
}

function rarityBadge(rarity, theme) {
  if (!rarity) return null;
  const map = {
    common: { bg: "rgba(120,130,140,0.18)", color: "#C7D0D9" },
    uncommon: { bg: "rgba(122,231,255,0.18)", color: "#7AE7FF" },
    rare: { bg: "rgba(141,124,255,0.20)", color: "#C4B5FD" },
    "very rare": { bg: "rgba(245,182,66,0.22)", color: "#F5B642" },
  };
  const style = map[(rarity || "").toLowerCase()] || { bg: theme.accentSoft, color: theme.accent };
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "6px 14px",
        borderRadius: 999,
        background: style.bg,
        color: style.color,
        fontSize: 13,
        fontWeight: 800,
        letterSpacing: "0.08em",
        textTransform: "uppercase",
      }}
    >
      ◆ {rarity}
    </span>
  );
}

/** Crystal shard corner accent — pure CSS, html2canvas-safe. */
function CrystalShard({ corner, theme }) {
  const base = {
    position: "absolute",
    width: 90,
    height: 90,
    pointerEvents: "none",
    background: `linear-gradient(135deg, ${theme.accent2} 0%, ${theme.accent} 50%, ${theme.accent3} 100%)`,
    opacity: 0.16,
  };
  const transforms = {
    tl: { top: -22, left: -22, transform: "rotate(45deg)" },
    tr: { top: -22, right: -22, transform: "rotate(135deg)" },
  };
  return <div style={{ ...base, ...transforms[corner] }} />;
}

export default function SpecimenShareCard({ specimen, theme: themeKey = "obsidian", showValue = true }) {
  const theme = THEMES[themeKey] || THEMES.obsidian;
  const photo = specimen?.photo_url || specimen?.photo_urls?.[0];
  const name = specimen?.name || "Unknown Specimen";
  const variety = specimen?.variety;
  const confidence = specimen?.confidence != null ? Math.round(specimen.confidence) : null;
  const crystalSystem = specimen?.crystal_system;

  const stats = [
    { label: "Hardness", value: specimen?.hardness ? `${specimen.hardness} Mohs` : null },
    { label: "Crystal System", value: crystalSystem },
    { label: "Luster", value: specimen?.luster },
    { label: "Color", value: specimen?.color },
    { label: "Streak", value: specimen?.streak_color },
    { label: "Transparency", value: specimen?.transparency },
    { label: "Specific Gravity", value: specimen?.specific_gravity },
    { label: "Category", value: specimen?.category },
  ].filter((s) => s.value);

  const locality = specimen?.locality_name;
  const dateFound = specimen?.created_date
    ? new Date(specimen.created_date).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })
    : null;

  const valueLow = specimen?.valuation_low;
  const valueHigh = specimen?.valuation_high;
  const valueEst = specimen?.valuation_estimated;
  const valueLabel = showValue && (valueLow || valueHigh || valueEst)
    ? (valueLow && valueHigh ? `$${valueLow}–$${valueHigh}` : valueEst ? `$${valueEst}` : null)
    : null;

  return (
    <div
      style={{
        width: 1080,
        height: 1080,
        background: theme.bgGradient,
        color: theme.text,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        position: "relative",
        fontFamily: "Inter, -apple-system, sans-serif",
        boxSizing: "border-box",
        // Crystalline frame: double border, accent edge
        border: `1px solid ${theme.accentBorder}`,
        boxShadow: `inset 0 0 0 6px ${theme.bg}, inset 0 0 0 7px ${theme.panelBorder}`,
      }}
    >
      {/* Top accent edge — crystalline gradient */}
      <div
        style={{
          height: 5,
          background: `linear-gradient(90deg, ${theme.accent3}, ${theme.accent2}, ${theme.accent}, ${theme.accent2}, ${theme.accent3})`,
          flexShrink: 0,
        }}
      />

      {/* Hero photo with crystal facet overlay */}
      <div style={{ position: "relative", height: 520, flexShrink: 0, overflow: "hidden" }}>
        {photo ? (
          <img
            src={photo}
            alt={name}
            crossOrigin="anonymous"
            style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
          />
        ) : (
          <div
            style={{
              width: "100%",
              height: "100%",
              background: `linear-gradient(135deg, ${theme.accentSoft}, transparent)`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 120,
              color: theme.accent2,
            }}
          >
            ◆
          </div>
        )}

        {/* Crystal facet overlay — geometric light refraction (linear gradients, safe) */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "45%",
            height: "70%",
            background: `linear-gradient(160deg, ${theme.facetTint} 0%, transparent 70%)`,
            transform: "skewX(-18deg)",
            transformOrigin: "top left",
          }}
        />
        <div
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            width: "55%",
            height: "60%",
            background: `linear-gradient(300deg, ${theme.facetTint} 0%, transparent 75%)`,
            transform: "skewX(-12deg)",
            transformOrigin: "bottom right",
          }}
        />

        {/* Bottom gradient fade into bg */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: `linear-gradient(180deg, transparent 50%, ${theme.bg} 100%)`,
          }}
        />

        {/* Crystal shard corner accents */}
        <CrystalShard corner="tl" theme={theme} />
        <CrystalShard corner="tr" theme={theme} />

        {/* Confidence chip — crystalline pill */}
        {confidence != null && (
          <div
            style={{
              position: "absolute",
              top: 20,
              right: 20,
              padding: "8px 16px",
              borderRadius: 999,
              background: "rgba(0,0,0,0.55)",
              border: `1px solid ${theme.accentBorder}`,
              color: theme.accent2,
              fontSize: 15,
              fontWeight: 800,
              letterSpacing: "0.04em",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <span style={{ color: theme.accent }}>◆</span>
            {confidence}% AI Confidence
          </div>
        )}

        {/* Name block */}
        <div style={{ position: "absolute", left: 40, right: 40, bottom: 28 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12, flexWrap: "wrap" }}>
            {rarityBadge(specimen?.rarity, theme)}
            {crystalSystem && (
              <span
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  padding: "6px 14px",
                  borderRadius: 999,
                  background: theme.panel,
                  border: `1px solid ${theme.accentBorder}`,
                  color: theme.accent2,
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.06em",
                  textTransform: "uppercase",
                }}
              >
                ✦ {crystalSystem}
              </span>
            )}
          </div>
          <h1 style={{ fontSize: 52, fontWeight: 800, lineHeight: 1.05, margin: 0, color: theme.text, letterSpacing: "-0.02em" }}>
            {name}
          </h1>
          {variety && (
            <p style={{ fontSize: 24, fontWeight: 500, margin: "6px 0 0", color: theme.textDim }}>
              {variety}
            </p>
          )}
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ padding: "8px 40px 24px", flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr",
            gap: 12,
            marginTop: 4,
          }}
        >
          {stats.map((s) => (
            <StatCell key={s.label} label={s.label} value={s.value} theme={theme} />
          ))}
        </div>

        {/* Locality + value strip */}
        <div style={{ display: "flex", alignItems: "center", gap: 20, marginTop: 20, flexWrap: "wrap" }}>
          {locality && (
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 18 }}>{theme.accent === "#00A06B" ? "📍" : "📍"}</span>
              <span style={{ fontSize: 18, fontWeight: 600, color: theme.textDim }}>{locality}</span>
            </div>
          )}
          {valueLabel && (
            <div
              style={{
                marginLeft: "auto",
                padding: "8px 16px",
                borderRadius: 12,
                background: "rgba(245,182,66,0.14)",
                border: "1px solid rgba(245,182,66,0.30)",
                color: "#F5B642",
                fontSize: 18,
                fontWeight: 800,
              }}
            >
              Est. {valueLabel}
            </div>
          )}
        </div>
      </div>

      {/* Branding footer — crystalline edge top */}
      <div
        style={{
          position: "relative",
          padding: "18px 40px",
          borderTop: `1px solid ${theme.panelBorder}`,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexShrink: 0,
        }}
      >
        {/* Crystalline top edge glow line */}
        <div
          style={{
            position: "absolute",
            top: -1,
            left: 0,
            right: 0,
            height: 1,
            background: `linear-gradient(90deg, transparent, ${theme.accent2}, ${theme.accent}, ${theme.accent2}, transparent)`,
            opacity: 0.7,
          }}
        />
        <div style={{ display: "flex", flexDirection: "column" }}>
          <span
            style={{
              fontSize: 22,
              fontWeight: 900,
              letterSpacing: "0.02em",
              background: `linear-gradient(120deg, ${theme.accent}, ${theme.accent2})`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            ROCKHOUND-GO
          </span>
          {dateFound && (
            <span style={{ fontSize: 13, color: theme.textFaint, marginTop: 2 }}>
              Found {dateFound}
            </span>
          )}
        </div>
        <span style={{ fontSize: 13, color: theme.textFaint, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" }}>
          #RockHoundGO
        </span>
      </div>
    </div>
  );
}