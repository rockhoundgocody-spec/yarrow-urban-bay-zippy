/**
 * SpecimenTestsPanel — physical properties + suggested field tests.
 */
import React from "react";
import { FlaskConical } from "lucide-react";

export default function SpecimenTestsPanel({ specimen }) {
  const props = [
    { label: "Color", value: specimen.color },
    { label: "Luster", value: specimen.luster },
    { label: "Streak", value: specimen.streak_color },
    { label: "Crystal System", value: specimen.crystal_system },
    { label: "Crystal Habit", value: specimen.crystal_habit },
    { label: "Cleavage", value: specimen.cleavage },
    { label: "Fracture", value: specimen.fracture },
    { label: "Specific Gravity", value: specimen.specific_gravity },
  ].filter(p => p.value || p.value === 0);

  const tests = (specimen.ai_tests_suggested || []).map(t =>
    typeof t === "string" ? t : (t.test || t.name || "")
  ).filter(Boolean);

  if (!props.length && !tests.length) return null;

  return (
    <div className="rounded-2xl p-4"
      style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <div className="flex items-center gap-2 mb-3">
        <FlaskConical className="w-3.5 h-3.5" style={{ color: "#F5B642" }} />
        <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>
          Properties & Tests
        </p>
      </div>

      {props.length > 0 && (
        <div className="grid grid-cols-2 gap-2 mb-3">
          {props.map(({ label, value }) => (
            <div key={label} className="rounded-xl px-3 py-2 min-w-0"
              style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.05)" }}>
              <p className="text-[10px] text-white/30 mb-0.5">{label}</p>
              <p className="text-xs font-semibold text-white/80 capitalize break-words">{value}</p>
            </div>
          ))}
        </div>
      )}

      {tests.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[10px] font-bold uppercase tracking-widest mb-1" style={{ color: "rgba(245,182,66,0.5)" }}>
            Suggested Field Tests
          </p>
          {tests.slice(0, 5).map((t, i) => (
            <div key={i} className="flex items-start gap-2 px-3 py-2 rounded-xl"
              style={{ background: "rgba(245,182,66,0.05)", border: "1px solid rgba(245,182,66,0.14)" }}>
              <span className="text-[10px] font-bold mt-0.5 flex-shrink-0" style={{ color: "#F5B642" }}>{i + 1}.</span>
              <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.6)" }}>{t}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}