import React from 'react';
import { Gem, Clock, Tag } from 'lucide-react';

const STATUS_CONFIG = {
  in_collection: {
    label: 'In Collection',
    icon: Gem,
    color: '#00D68F',
    bgColor: 'rgba(0, 214, 143, 0.12)',
    borderColor: 'rgba(0, 214, 143, 0.30)',
  },
  to_be_identified: {
    label: 'To Be Identified',
    icon: Clock,
    color: '#F5B642',
    bgColor: 'rgba(245, 182, 66, 0.12)',
    borderColor: 'rgba(245, 182, 66, 0.30)',
  },
  for_trade: {
    label: 'For Trade',
    icon: Tag,
    color: '#7AE7FF',
    bgColor: 'rgba(122, 231, 255, 0.12)',
    borderColor: 'rgba(122, 231, 255, 0.30)',
  },
};

export default function CollectionStatusBadge({ status = 'in_collection', size = 'sm' }) {
  const config = STATUS_CONFIG[status];
  if (!config) return null;

  const Icon = config.icon;
  const sizeClasses = size === 'lg' ? 'px-3 py-2 gap-2' : 'px-2.5 py-1.5 gap-1.5';
  const iconSize = size === 'lg' ? 18 : 14;
  const textSize = size === 'lg' ? 'text-xs font-medium' : 'text-[11px] font-semibold';

  return (
    <div
      className={`inline-flex items-center rounded-lg ${sizeClasses}`}
      style={{
        background: config.bgColor,
        border: `1px solid ${config.borderColor}`,
      }}
    >
      <Icon size={iconSize} style={{ color: config.color, flexShrink: 0 }} />
      <span className={textSize} style={{ color: config.color }}>
        {config.label}
      </span>
    </div>
  );
}