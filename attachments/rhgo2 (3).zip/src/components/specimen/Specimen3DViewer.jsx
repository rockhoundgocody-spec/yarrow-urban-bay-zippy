import React, { useRef, useState } from 'react';
import { RotateCcw, Maximize2, Sparkles } from 'lucide-react';
import SpecimenScene from './SpecimenScene';

// ── Mineral material presets ─────────────────────────────────────────────────
const MINERAL_PRESETS = {
  quartz: {
    color: '#e8f4f8',
    emissive: '#002244',
    metalness: 0.0,
    roughness: 0.05,
    transmission: 0.85,
    ior: 1.54,
    thickness: 2.0,
    envMapIntensity: 2.5,
    label: 'Quartz / Crystal',
    geometry: 'crystal_cluster',
  },
  amethyst: {
    color: '#9b59b6',
    emissive: '#1a0030',
    metalness: 0.0,
    roughness: 0.08,
    transmission: 0.7,
    ior: 1.54,
    thickness: 1.8,
    envMapIntensity: 2.8,
    label: 'Amethyst',
    geometry: 'crystal_cluster',
  },
  pyrite: {
    color: '#c8a820',
    emissive: '#1a1000',
    metalness: 0.95,
    roughness: 0.25,
    transmission: 0,
    ior: 1.0,
    thickness: 0,
    envMapIntensity: 3.0,
    label: 'Pyrite / Metallic',
    geometry: 'cubic',
  },
  malachite: {
    color: '#2ecc71',
    emissive: '#0a1f0a',
    metalness: 0.1,
    roughness: 0.55,
    transmission: 0,
    ior: 1.0,
    thickness: 0,
    envMapIntensity: 1.5,
    label: 'Malachite / Opaque',
    geometry: 'rounded',
  },
  obsidian: {
    color: '#1a1a2e',
    emissive: '#000000',
    metalness: 0.0,
    roughness: 0.02,
    transmission: 0.3,
    ior: 1.48,
    thickness: 3.0,
    envMapIntensity: 3.5,
    label: 'Obsidian / Glassy',
    geometry: 'shard',
  },
  fluorite: {
    color: '#7bed9f',
    emissive: '#001a08',
    metalness: 0.0,
    roughness: 0.04,
    transmission: 0.9,
    ior: 1.43,
    thickness: 1.5,
    envMapIntensity: 2.2,
    label: 'Fluorite',
    geometry: 'cubic',
  },
  azurite: {
    color: '#1e3799',
    emissive: '#000510',
    metalness: 0.05,
    roughness: 0.35,
    transmission: 0.1,
    ior: 1.73,
    thickness: 0.5,
    envMapIntensity: 1.8,
    label: 'Azurite',
    geometry: 'crystal_cluster',
  },
  custom: {
    color: '#d4af37',
    emissive: '#1a0f00',
    metalness: 0.5,
    roughness: 0.3,
    transmission: 0.2,
    ior: 1.6,
    thickness: 1.0,
    envMapIntensity: 2.0,
    label: 'Custom',
    geometry: 'rounded',
  },
};

// ── Main exported component ──────────────────────────────────────────────────
export default function Specimen3DViewer({
  mineralType = 'quartz',
  specimenName = null,
  height = 420,
  showControls = true,
  showPresetPicker = true,
  className = '',
}) {
  const [preset, setPreset] = useState(MINERAL_PRESETS[mineralType] || MINERAL_PRESETS.quartz);
  const [lightMode, setLightMode] = useState('studio');
  const [autoRotate, setAutoRotate] = useState(true);
  const [resetTrigger, setResetTrigger] = useState(0);
  const [showInfo, setShowInfo] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  const containerRef = useRef();

  const viewerHeight = fullscreen ? '100vh' : `${height}px`;

  const lightModes = ['studio', 'warm', 'uv', 'field'];

  return (
    <div
      ref={containerRef}
      className={`relative rounded-2xl overflow-hidden ${fullscreen ? 'fixed inset-0 z-50' : ''} ${className}`}
      style={{
        height: viewerHeight,
        background: 'linear-gradient(160deg, #05070A 0%, #0A0F14 60%, #111820 100%)',
        border: '1px solid rgba(0,214,143,0.15)',
        boxShadow: '0 8px 40px rgba(0,0,0,0.7), inset 0 1px 0 rgba(255,255,255,0.05)',
      }}
    >
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-4 py-3"
        style={{ background: 'linear-gradient(180deg, rgba(5,7,10,0.9) 0%, transparent 100%)' }}>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#00D68F' }} />
          <span className="text-xs font-bold tracking-widest uppercase" style={{ color: '#00D68F' }}>
            3D Specimen Viewer
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-white/40 font-medium">
            {specimenName || preset.label}
          </span>
          {showControls && (
            <button
              onClick={() => setFullscreen(f => !f)}
              className="p-1.5 rounded-lg transition-all"
              style={{ background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.1)' }}
             aria-label="Expand">
              <Maximize2 className="w-3.5 h-3.5 text-white/60" />
            </button>
          )}
        </div>
      </div>

      {/* WebGL scene */}
      <SpecimenScene
        preset={preset}
        lightMode={lightMode}
        autoRotate={autoRotate}
        resetTrigger={resetTrigger}
      />

      {/* Bottom Controls */}
      {showControls && (
        <div className="absolute bottom-0 left-0 right-0 z-20 px-4 pb-4 pt-8"
          style={{ background: 'linear-gradient(0deg, rgba(5,7,10,0.95) 0%, transparent 100%)' }}>

          {/* Preset picker */}
          {showPresetPicker && (
            <div className="flex gap-2 mb-3 overflow-x-auto pb-1 scrollbar-hide">
              {Object.entries(MINERAL_PRESETS).map(([key, p]) => (
                <button
                  key={key}
                  onClick={() => setPreset(p)}
                  className="flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all"
                  style={{
                    background: preset === p ? 'rgba(0,214,143,0.2)' : 'rgba(255,255,255,0.06)',
                    border: `1px solid ${preset === p ? 'rgba(0,214,143,0.5)' : 'rgba(255,255,255,0.1)'}`,
                    color: preset === p ? '#00D68F' : 'rgba(255,255,255,0.5)',
                  }}
                >
                  {p.label}
                </button>
              ))}
            </div>
          )}

          {/* Action bar */}
          <div className="flex items-center justify-between gap-3">
            {/* Light mode */}
            <div className="flex gap-1.5">
              {lightModes.map(m => (
                <button
                  key={m}
                  onClick={() => setLightMode(m)}
                  className="px-2.5 py-1 rounded-lg text-xs font-medium capitalize transition-all"
                  style={{
                    background: lightMode === m ? 'rgba(122,231,255,0.15)' : 'rgba(255,255,255,0.06)',
                    border: `1px solid ${lightMode === m ? 'rgba(122,231,255,0.4)' : 'rgba(255,255,255,0.08)'}`,
                    color: lightMode === m ? '#7AE7FF' : 'rgba(255,255,255,0.4)',
                  }}
                >
                  {m === 'uv' ? 'UV' : m}
                </button>
              ))}
            </div>

            {/* Rotation + Reset */}
            <div className="flex gap-2">
              <button
                onClick={() => setAutoRotate(r => !r)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
                style={{
                  background: autoRotate ? 'rgba(0,214,143,0.15)' : 'rgba(255,255,255,0.06)',
                  border: `1px solid ${autoRotate ? 'rgba(0,214,143,0.4)' : 'rgba(255,255,255,0.1)'}`,
                  color: autoRotate ? '#00D68F' : 'rgba(255,255,255,0.4)',
                }}
              >
                <Sparkles className="w-3 h-3" />
                Auto
              </button>
              <button
                onClick={() => setResetTrigger(t => t + 1)}
                className="p-2 rounded-lg transition-all"
                style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}
               aria-label="Rotate">
                <RotateCcw className="w-3.5 h-3.5 text-white/50" />
              </button>
            </div>
          </div>

          {/* Hint */}
          <p className="text-center text-white/20 text-xs mt-2">
            Drag to rotate · Pinch / scroll to zoom
          </p>
        </div>
      )}

      {/* Material property badges */}
      <div className="absolute top-12 right-3 z-20 flex flex-col gap-1.5">
        {[
          { label: 'IOR', value: preset.ior.toFixed(2) },
          { label: 'Metal', value: `${(preset.metalness * 100).toFixed(0)}%` },
          { label: 'Rough', value: `${(preset.roughness * 100).toFixed(0)}%` },
          preset.transmission > 0 && { label: 'Trans', value: `${(preset.transmission * 100).toFixed(0)}%` },
        ].filter(Boolean).map(b => (
          <div key={b.label} className="flex flex-col items-center px-2 py-1 rounded-lg"
            style={{ background: 'rgba(0,0,0,0.6)', border: '1px solid rgba(255,255,255,0.07)' }}>
            <span className="text-white/30 text-[9px] font-bold uppercase tracking-wider">{b.label}</span>
            <span className="text-white/80 text-[11px] font-bold">{b.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}