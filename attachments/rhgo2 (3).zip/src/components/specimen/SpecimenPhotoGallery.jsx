/**
 * SpecimenPhotoGallery — hero photo with thumbnail strip for multi-angle records.
 */
import React, { useState } from "react";

export default function SpecimenPhotoGallery({ photos = [], name }) {
  const [activeIdx, setActiveIdx] = useState(0);
  if (!photos.length) return null;
  const active = photos[Math.min(activeIdx, photos.length - 1)];

  return (
    <div className="space-y-2">
      <div className="rounded-2xl overflow-hidden w-full h-52 sm:h-64">
        <img src={active} alt={name || "Specimen"} className="w-full h-full object-cover" />
      </div>
      {photos.length > 1 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {photos.map((url, i) => (
            <button
              key={i}
              onClick={() => setActiveIdx(i)}
              className="rounded-xl overflow-hidden flex-shrink-0"
              style={{
                width: 56, height: 56,
                border: `2px solid ${i === activeIdx ? "#00D68F" : "rgba(255,255,255,0.1)"}`,
                opacity: i === activeIdx ? 1 : 0.6,
                minHeight: "unset", minWidth: "unset",
              }}
              aria-label={`Photo ${i + 1}`}
            >
              <img src={url} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}