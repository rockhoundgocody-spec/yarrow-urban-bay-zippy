import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { MapPin, Bell, BellOff, X, Plus, Check } from "lucide-react";

const US_STATES = [
  "Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut",
  "Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa",
  "Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan",
  "Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire",
  "New Jersey","New Mexico","New York","North Carolina","North Dakota","Ohio",
  "Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota",
  "Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia",
  "Wisconsin","Wyoming"
];

export default function RegionFollowManager({ userEmail }) {
  const [follows, setFollows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [selected, setSelected] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!userEmail) return;
    base44.entities.RegionFollow.filter({ user_email: userEmail })
      .then(setFollows)
      .finally(() => setLoading(false));
  }, [userEmail]);

  const availableStates = US_STATES.filter(
    (s) => !follows.some((f) => f.region_state.toLowerCase() === s.toLowerCase())
  );

  const handleAdd = async () => {
    if (!selected || saving) return;
    setSaving(true);
    try {
      const rec = await base44.entities.RegionFollow.create({
        user_email: userEmail,
        region_state: selected,
        region_label: selected,
        notify_new_locations: true,
        notify_new_specimens: true,
        email_enabled: true,
      });
      setFollows((prev) => [...prev, rec]);
      setSelected("");
      setAdding(false);
    } finally {
      setSaving(false);
    }
  };

  const handleToggle = async (follow, field) => {
    const updated = { ...follow, [field]: !follow[field] };
    setFollows((prev) => prev.map((f) => (f.id === follow.id ? updated : f)));
    await base44.entities.RegionFollow.update(follow.id, { [field]: !follow[field] });
  };

  const handleRemove = async (follow) => {
    setFollows((prev) => prev.filter((f) => f.id !== follow.id));
    await base44.entities.RegionFollow.delete(follow.id);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="w-5 h-5 rounded-full border-2" style={{ borderColor: "rgba(141,124,255,0.2)", borderTopColor: "#8D7CFF", animation: "spin 0.7s linear infinite" }} />
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold" style={{ color: "#fff" }}>Followed Regions</p>
          <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
            Get notified when new locations or finds are added
          </p>
        </div>
        <button
          onClick={() => setAdding(!adding)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
          style={{
            background: "rgba(141,124,255,0.18)",
            border: "1px solid rgba(141,124,255,0.4)",
            color: "#C4B5FD",
          }}
        >
          <Plus className="w-3.5 h-3.5" /> Follow Region
        </button>
      </div>

      {/* Add form */}
      {adding && (
        <div
          className="flex gap-2 p-3 rounded-xl"
          style={{ background: "rgba(141,124,255,0.08)", border: "1px solid rgba(141,124,255,0.2)" }}
        >
          <select
            value={selected}
            onChange={(e) => setSelected(e.target.value)}
            className="flex-1 rounded-lg px-3 py-2 text-sm"
            style={{
              background: "rgba(10,8,24,0.8)",
              border: "1px solid rgba(141,124,255,0.3)",
              color: "#fff",
              minHeight: "unset",
            }}
          >
            <option value="">Select a state…</option>
            {availableStates.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          <button
            onClick={handleAdd}
            disabled={!selected || saving}
            className="px-3 py-2 rounded-lg text-xs font-semibold disabled:opacity-40"
            style={{ background: "#8D7CFF", color: "#fff", minWidth: "unset", minHeight: "unset" }}
          >
            {saving ? "…" : <Check className="w-4 h-4" />}
          </button>
          <button
            onClick={() => { setAdding(false); setSelected(""); }}
            className="px-3 py-2 rounded-lg"
            style={{ color: "rgba(255,255,255,0.4)", minWidth: "unset", minHeight: "unset" }}
           aria-label="Select">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Follow list */}
      {follows.length === 0 ? (
        <div
          className="text-center py-6 rounded-xl"
          style={{ background: "rgba(12,8,28,0.6)", border: "1px solid rgba(141,124,255,0.1)" }}
        >
          <MapPin className="w-6 h-6 mx-auto mb-2" style={{ color: "rgba(141,124,255,0.4)" }} />
          <p className="text-sm" style={{ color: "rgba(255,255,255,0.35)" }}>
            No regions followed yet
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {follows.map((follow) => (
            <div
              key={follow.id}
              className="flex items-center gap-3 px-4 py-3 rounded-xl"
              style={{
                background: "rgba(12,8,28,0.8)",
                border: "1px solid rgba(141,124,255,0.15)",
              }}
            >
              <MapPin className="w-4 h-4 flex-shrink-0" style={{ color: "#8D7CFF" }} />
              <span className="flex-1 text-sm font-medium" style={{ color: "#fff" }}>
                {follow.region_label || follow.region_state}
              </span>

              {/* Toggle: locations */}
              <button
                onClick={() => handleToggle(follow, "notify_new_locations")}
                className="flex items-center gap-1 text-xs px-2 py-1 rounded-md transition-all"
                title="New locations"
                style={{
                  background: follow.notify_new_locations ? "rgba(0,214,143,0.15)" : "rgba(255,255,255,0.05)",
                  color: follow.notify_new_locations ? "#00D68F" : "rgba(255,255,255,0.3)",
                  border: `1px solid ${follow.notify_new_locations ? "rgba(0,214,143,0.3)" : "rgba(255,255,255,0.08)"}`,
                  minWidth: "unset", minHeight: "unset",
                }}
              >
                Sites
              </button>

              {/* Toggle: specimens */}
              <button
                onClick={() => handleToggle(follow, "notify_new_specimens")}
                className="flex items-center gap-1 text-xs px-2 py-1 rounded-md transition-all"
                title="New specimens"
                style={{
                  background: follow.notify_new_specimens ? "rgba(122,231,255,0.15)" : "rgba(255,255,255,0.05)",
                  color: follow.notify_new_specimens ? "#7AE7FF" : "rgba(255,255,255,0.3)",
                  border: `1px solid ${follow.notify_new_specimens ? "rgba(122,231,255,0.3)" : "rgba(255,255,255,0.08)"}`,
                  minWidth: "unset", minHeight: "unset",
                }}
              >
                Finds
              </button>

              {/* Toggle: email */}
              <button
                onClick={() => handleToggle(follow, "email_enabled")}
                title={follow.email_enabled ? "Email on" : "Email off"}
                style={{ color: follow.email_enabled ? "#C4B5FD" : "rgba(255,255,255,0.25)", minWidth: "unset", minHeight: "unset" }}
              >
                {follow.email_enabled ? <Bell className="w-4 h-4" /> : <BellOff className="w-4 h-4" />}
              </button>

              <button
                onClick={() => handleRemove(follow)}
                style={{ color: "rgba(255,255,255,0.25)", minWidth: "unset", minHeight: "unset" }}
               aria-label="Remove">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}