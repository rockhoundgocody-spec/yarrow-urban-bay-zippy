/**
 * MarketTrustStrip — provenance / trust signal bar for the Auction House.
 * Sits between the hero and the listings. Elevates perceived listing quality.
 */

import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, FileCheck, Lock, Star } from "lucide-react";

const SIGNALS = [
  { icon: ShieldCheck, label: "Provenance Tracked",  sub: "locality + origin records",   color: "#00FFC6", delay: 0 },
  { icon: FileCheck,   label: "Collector-Graded",    sub: "verified specimen quality",    color: "#7DF9FF", delay: 0.06 },
  { icon: Lock,        label: "Escrow Protected",    sub: "funds held until delivery",    color: "#B97AFF", delay: 0.12 },
  { icon: Star,        label: "Seller Reputation",   sub: "rating from real buyers",      color: "#FFD700", delay: 0.18 },
];

export default function MarketTrustStrip() {
  return (
    <div
      className="rounded-[22px] px-4 py-3 mb-5"
      style={{
        background: "linear-gradient(135deg, rgba(255,215,0,0.04) 0%, rgba(4,8,14,0.92) 100%)",
        border: "1px solid rgba(255,215,0,0.10)",
      }}
    >
      <div className="text-[9px] font-bold uppercase tracking-[0.24em] text-white/20 mb-3">
        Auction House Standards
      </div>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {SIGNALS.map(({ icon: Icon, label, sub, color, delay }) => (
          <motion.div
            key={label}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay, duration: 0.3 }}
            className="flex items-center gap-2"
          >
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl" style={{ background: `${color}10`, border: `1px solid ${color}25` }}>
              <Icon className="h-3.5 w-3.5" style={{ color }} />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold text-white/70 leading-none truncate">{label}</div>
              <div className="text-[9px] text-white/30 mt-0.5 truncate">{sub}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}