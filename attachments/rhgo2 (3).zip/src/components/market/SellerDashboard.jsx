/**
 * SellerDashboard — Pro dealer / seller tools layer.
 * Provides: listing quality scores, inventory overview, pricing guidance,
 * trust enhancements, and provenance prompts for serious sellers.
 * Design language: Auction House / premium dark.
 */

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import {
  Package, ShieldCheck, Star, AlertCircle, CheckCircle2,
  ChevronRight, DollarSign, Award, BarChart2, Zap, Sparkles
} from "lucide-react";
import { Link } from "react-router-dom";
import { hasAccess } from "@/components/subscription/entitlements";
import ProSellerUpgradeCard from "@/components/monetization/ProSellerUpgradeCard";
import ProSellerBadge from "@/components/monetization/ProSellerBadge";

// Listing quality scoring — deterministic from listing fields
function scoreListingQuality(item) {
  let score = 0;
  const tips = [];
  if (item.title?.length >= 10) score += 20; else tips.push("Add a descriptive title (10+ chars)");
  if (item.description?.length >= 40) score += 20; else tips.push("Write a detailed description");
  if (item.photos?.length > 0 || item.image_url) score += 25; else tips.push("Add at least one photo");
  if (item.price > 0) score += 15; else tips.push("Set a price");
  if (item.provenance_status && item.provenance_status !== "unknown") score += 10; else tips.push("Add provenance info");
  if (item.locality || item.location_name) score += 10; else tips.push("Specify locality/origin");
  return { score, tips };
}

function QualityRing({ score }) {
  const color = score >= 80 ? "#00FFC6" : score >= 60 ? "#FFD700" : "#FF7A59";
  const dash = 2 * Math.PI * 22;
  const offset = dash * (1 - score / 100);
  return (
    <div className="relative flex h-14 w-14 items-center justify-center">
      <svg className="absolute inset-0" viewBox="0 0 48 48">
        <circle cx="24" cy="24" r="22" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="3" />
        <motion.circle cx="24" cy="24" r="22" fill="none" stroke={color} strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={dash} strokeDashoffset={offset}
          style={{ transformOrigin: "50% 50%", rotate: "-90deg", filter: `drop-shadow(0 0 4px ${color})` }}
          initial={{ strokeDashoffset: dash }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        />
      </svg>
      <span className="text-sm font-black" style={{ color }}>{score}</span>
    </div>
  );
}

function ListingQualityCard({ item }) {
  const { score, tips } = scoreListingQuality(item);
  const [open, setOpen] = useState(false);
  const color = score >= 80 ? "#00FFC6" : score >= 60 ? "#FFD700" : "#FF7A59";

  return (
    <div className="rounded-[18px] overflow-hidden"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <button type="button" onClick={() => setOpen(o => !o)}
        className="flex w-full items-center gap-3 px-4 py-3">
        <QualityRing score={score} />
        <div className="flex-1 text-left min-w-0">
          <div className="text-sm font-bold text-white truncate">{item.title || "Untitled Listing"}</div>
          <div className="text-[10px] text-white/30 mt-0.5">
            {score >= 80 ? "Collector-grade quality" : score >= 60 ? "Good — minor improvements available" : "Needs improvement to maximize visibility"}
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {tips.length === 0 ? (
            <CheckCircle2 className="h-4 w-4" style={{ color: "#00FFC6" }} />
          ) : (
            <AlertCircle className="h-4 w-4" style={{ color }} />
          )}
        </div>
      </button>
      {open && tips.length > 0 && (
        <div className="border-t border-white/[0.05] px-4 py-3 space-y-1.5">
          {tips.map(tip => (
            <div key={tip} className="flex items-start gap-2 text-xs text-white/45">
              <Zap className="h-3 w-3 shrink-0 mt-0.5 text-amber-300" />
              {tip}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatTile({ icon: Icon, label, value, color }) {
  return (
    <div className="flex flex-col items-center gap-1.5 rounded-2xl py-3"
      style={{ background: `${color}06`, border: `1px solid ${color}15` }}>
      <Icon className="h-4 w-4" style={{ color }} />
      <span className="text-lg font-black" style={{ color }}>{value}</span>
      <span className="text-[9px] uppercase tracking-[0.14em] text-white/25">{label}</span>
    </div>
  );
}

export default function SellerDashboard({ user }) {
  const isProSeller = hasAccess(user, "seller:pro_badge");

  const { data: myListings = [], isLoading } = useQuery({
    queryKey: ["seller-listings", user?.email],
    queryFn: () => base44.entities.MarketplaceItem.filter({ created_by: user?.email }, "-created_date", 50),
    enabled: !!user?.email,
    staleTime: 60 * 1000,
  });

  const active = myListings.filter(l => l.status === "active");
  const sold = myListings.filter(l => l.status === "sold");
  const totalValue = active.reduce((s, l) => s + (l.price || 0), 0);
  const avgQuality = myListings.length > 0
    ? Math.round(myListings.reduce((s, l) => s + scoreListingQuality(l).score, 0) / myListings.length)
    : 0;

  return (
    <div className="space-y-4">
      {/* Commerce Engine CTA */}
      <Link to="/CommerceEngine"
        className="flex items-center gap-3 rounded-[18px] px-4 py-3 mb-3"
        style={{ background: "linear-gradient(135deg, rgba(168,85,247,0.12), rgba(122,231,255,0.06))", border: "1px solid rgba(168,85,247,0.3)" }}>
        <Sparkles className="h-4 w-4 text-violet-400 shrink-0" />
        <div className="flex-1">
          <div className="text-xs font-bold text-white">AI Listing Generator</div>
          <div className="text-[10px] text-white/30">Turn any specimen into a market-ready listing</div>
        </div>
        <ChevronRight className="h-4 w-4 text-white/20 shrink-0" />
      </Link>

      {/* Pro header */}
      <div className="flex items-center gap-2 mb-1">
        <Award className="h-4 w-4" style={{ color: "#FFD700" }} />
        <span className="text-xs font-black uppercase tracking-[0.22em]" style={{ color: "#FFD700" }}>Seller Intelligence</span>
        {isProSeller && <ProSellerBadge compact />}
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-4 gap-2">
        <StatTile icon={Package} label="Active" value={active.length} color="#7DF9FF" />
        <StatTile icon={CheckCircle2} label="Sold" value={sold.length} color="#00FFC6" />
        <StatTile icon={DollarSign} label="Listed" value={`$${totalValue}`} color="#FFD700" />
        <StatTile icon={BarChart2} label="Quality" value={`${avgQuality}`} color="#B97AFF" />
      </div>

      {/* Pro tips callout */}
      <div className="rounded-2xl px-4 py-3"
        style={{ background: "rgba(255,215,0,0.05)", border: "1px solid rgba(255,215,0,0.14)" }}>
        <div className="flex items-center gap-2 mb-2">
          <Star className="h-3.5 w-3.5 shrink-0" style={{ color: "#FFD700" }} />
          <span className="text-[10px] font-bold uppercase tracking-[0.18em]" style={{ color: "#FFD700" }}>Pro Seller Tips</span>
        </div>
        <ul className="space-y-1.5 text-xs text-white/45 leading-5">
          <li>• Verified provenance listings convert 2.3× better</li>
          <li>• Photos with scale reference command 18% higher prices</li>
          <li>• Locality-specific listings attract serious collectors</li>
          <li>• Quality scores ≥80 receive featured placement eligibility</li>
        </ul>
      </div>

      {/* Listing quality audit */}
      {isLoading ? (
        <div className="rounded-2xl px-4 py-8 flex justify-center"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
          <div className="h-5 w-5 animate-spin rounded-full border-2 border-amber-300/30 border-t-amber-300" />
        </div>
      ) : myListings.length === 0 ? (
        <div className="flex flex-col items-center py-10 gap-3 text-center rounded-2xl"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
          <Package className="h-8 w-8 text-white/10" />
          <p className="text-sm text-white/25">No listings yet.</p>
          <p className="text-xs text-white/15">List your first specimen to see quality guidance.</p>
        </div>
      ) : (
        <div>
          <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/25 mb-2">Listing Quality Audit</div>
          <div className="space-y-2">
            {myListings.slice(0, 5).map(item => (
              <ListingQualityCard key={item.id} item={item} />
            ))}
          </div>
        </div>
      )}

      {/* Trust enhancement CTA */}
      <div className="flex items-center gap-3 rounded-2xl px-4 py-3"
        style={{ background: "rgba(0,255,198,0.05)", border: "1px solid rgba(0,255,198,0.14)" }}>
        <ShieldCheck className="h-5 w-5 shrink-0" style={{ color: "#00FFC6" }} />
        <div className="flex-1">
          <div className="text-xs font-bold text-white/75">Add Provenance Documentation</div>
          <div className="text-[10px] text-white/30">Upload certificates or locality records to get the Verified badge.</div>
        </div>
        <ChevronRight className="h-4 w-4 text-white/20 shrink-0" />
      </div>

      {/* Pro Seller upgrade card — only shown to non-pro sellers */}
      {!isProSeller && <ProSellerUpgradeCard compact />}
    </div>
  );
}