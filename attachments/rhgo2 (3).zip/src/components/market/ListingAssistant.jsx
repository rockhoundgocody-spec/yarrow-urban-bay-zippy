/**
 * ListingAssistant — guided sell flow from collection item to published listing.
 *
 * Steps: auto-fill → pricing → provenance → publish
 *
 * Props:
 *  specimen   object   — Specimen entity to list
 *  onPublish  fn       — called with final listing data
 *  onClose    fn
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, DollarSign, Package, ChevronRight, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ProvenanceBadge from "@/components/scan/ProvenanceBadge";

const STEPS = ["details", "pricing", "provenance", "publish"];

const PROVENANCE_OPTIONS = [
  { value: "self-collected",  label: "Self-Collected" },
  { value: "seller-claimed",  label: "Purchased (claimed locality)" },
  { value: "documented",      label: "Documented Source" },
  { value: "unknown",         label: "Unknown / Unverified" },
];

export default function ListingAssistant({ specimen, onPublish, onClose }) {
  const [step, setStep] = useState(0);
  const [draft, setDraft] = useState({
    title:      specimen?.name || specimen?.mineral_type || "",
    species:    specimen?.mineral_type || "",
    locality:   specimen?.locality || "",
    price:      "",
    notes:      specimen?.notes || "",
    provenance: "unknown",
    media:      specimen?.photo_url ? [specimen.photo_url] : [],
  });
  const [pricing, setPricing] = useState(null);
  const [loadingPrice, setLoadingPrice] = useState(false);
  const [publishing, setPublishing] = useState(false);

  useEffect(() => {
    if (step === 1 && !pricing) fetchPricing();
  }, [step]);

  const fetchPricing = async () => {
    setLoadingPrice(true);
    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `Mineral market analyst. Estimate retail price range for:
Species: ${draft.species}, Locality: ${draft.locality}, Rarity: ${specimen?.rarity || "common"}
Return JSON: { low: number, mid: number, high: number, quickSale: number, premium: number, confidence: 0-1, rationale: string[] }`,
      response_json_schema: {
        type: "object",
        properties: {
          low: { type: "number" }, mid: { type: "number" }, high: { type: "number" },
          quickSale: { type: "number" }, premium: { type: "number" },
          confidence: { type: "number" }, rationale: { type: "array", items: { type: "string" } },
        },
      },
    }).catch(() => null);
    setPricing(res);
    if (res?.mid && !draft.price) setDraft((d) => ({ ...d, price: String(res.mid) }));
    setLoadingPrice(false);
  };

  const handlePublish = async () => {
    setPublishing(true);
    const listing = await base44.entities.Listing.create({
      title:            draft.title,
      mineral_type:     draft.species,
      locality:         draft.locality,
      price:            parseFloat(draft.price) || 0,
      description:      draft.notes,
      provenance_status: draft.provenance,
      photo_urls:       draft.media,
      specimen_id:      specimen?.id,
      valuation_low:    pricing?.low,
      valuation_high:   pricing?.high,
      status:           "active",
    });
    setPublishing(false);
    onPublish?.(listing);
  };

  const currentStep = STEPS[step];

  return (
    <div
      className="fixed inset-0 z-[200] flex items-end sm:items-center justify-center"
      style={{ background: "rgba(0,0,0,0.65)", backdropFilter: "blur(8px)" }}
    >
      <motion.div
        className="w-full max-w-lg overflow-hidden rounded-t-[28px] sm:rounded-[28px] border border-white/10"
        style={{ background: "linear-gradient(145deg, rgba(10,15,20,0.96) 0%, rgba(14,20,27,0.94) 100%)", maxHeight: "90vh" }}
        initial={{ y: 60, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 60, opacity: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 28 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/[0.07] px-5 py-4">
          <div>
            <div className="text-sm font-bold text-white/85">List Specimen</div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-white/30">
              Step {step + 1} of {STEPS.length} — {currentStep}
            </div>
          </div>
          <button type="button" onClick={onClose} className="text-white/30 hover:text-white/60" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Step progress */}
        <div className="flex gap-1 px-5 pt-3">
          {STEPS.map((_, i) => (
            <div
              key={i}
              className="h-1 flex-1 rounded-full transition-all duration-300"
              style={{ background: i <= step ? "#7DF9FF" : "rgba(255,255,255,0.1)" }}
            />
          ))}
        </div>

        {/* Content */}
        <div className="overflow-y-auto px-5 py-5" style={{ maxHeight: "62vh" }}>
          <AnimatePresence mode="wait">
            {/* STEP 0 — Details */}
            {currentStep === "details" && (
              <motion.div key="details" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} className="space-y-4">
                {[
                  { label: "Title", key: "title" },
                  { label: "Mineral / Species", key: "species" },
                  { label: "Locality", key: "locality" },
                  { label: "Condition Notes", key: "notes" },
                ].map(({ label, key }) => (
                  <div key={key}>
                    <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.18em] text-white/35">{label}</label>
                    <input
                      value={draft[key]}
                      onChange={(e) => setDraft((d) => ({ ...d, [key]: e.target.value }))}
                      className="w-full rounded-[18px] border border-white/10 bg-white/[0.04] px-4 py-3 text-sm text-white outline-none placeholder-white/20 focus:border-cyan-300/30"
                    />
                  </div>
                ))}
              </motion.div>
            )}

            {/* STEP 1 — Pricing */}
            {currentStep === "pricing" && (
              <motion.div key="pricing" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} className="space-y-5">
                {loadingPrice && (
                  <div className="flex items-center gap-2 text-sm text-white/40">
                    <Loader2 className="h-4 w-4 animate-spin" /> Fetching market comps…
                  </div>
                )}
                {pricing && (
                  <div className="rounded-2xl border border-amber-300/20 bg-amber-300/[0.06] p-4 space-y-3">
                    <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-300/60">Suggested Pricing</div>
                    <div className="grid grid-cols-3 gap-2 text-center">
                      {[
                        { label: "Quick Sale", value: pricing.quickSale },
                        { label: "Recommended", value: pricing.mid, highlight: true },
                        { label: "Premium Ask", value: pricing.premium },
                      ].map(({ label, value, highlight }) => (
                        <button
                          key={label}
                          type="button"
                          onClick={() => setDraft((d) => ({ ...d, price: String(value) }))}
                          className="rounded-xl py-2.5 transition-all"
                          style={{
                            background: highlight ? "rgba(255,201,74,0.15)" : "rgba(255,255,255,0.04)",
                            border: `1px solid ${highlight ? "rgba(255,201,74,0.3)" : "rgba(255,255,255,0.08)"}`,
                          }}
                        >
                          <div className="text-xs font-bold text-white/80">${value}</div>
                          <div className="text-[9px] text-white/35 mt-0.5">{label}</div>
                        </button>
                      ))}
                    </div>
                    {pricing.rationale?.length > 0 && (
                      <ul className="space-y-1 mt-2">
                        {pricing.rationale.slice(0, 2).map((r, i) => (
                          <li key={i} className="text-[11px] text-white/40 flex gap-2">
                            <span className="text-amber-300/50">·</span>{r}
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                )}
                <div>
                  <label className="mb-1.5 block text-[10px] font-bold uppercase tracking-[0.18em] text-white/35">Your Ask Price (USD)</label>
                  <div className="flex items-center gap-2 rounded-[18px] border border-white/10 bg-white/[0.04] px-4 py-3">
                    <DollarSign className="h-4 w-4 text-amber-300/60 shrink-0" />
                    <input
                      type="number"
                      value={draft.price}
                      onChange={(e) => setDraft((d) => ({ ...d, price: e.target.value }))}
                      className="flex-1 bg-transparent text-sm text-white outline-none"
                      placeholder="0.00"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 2 — Provenance */}
            {currentStep === "provenance" && (
              <motion.div key="provenance" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} className="space-y-4">
                <div className="text-xs text-white/40 leading-5">
                  Provenance directly affects buyer trust and sale price. Be accurate.
                </div>
                <div className="space-y-2">
                  {PROVENANCE_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setDraft((d) => ({ ...d, provenance: opt.value }))}
                      className="flex w-full items-center justify-between rounded-2xl border px-4 py-3 transition-all"
                      style={{
                        background: draft.provenance === opt.value ? "rgba(125,249,255,0.08)" : "rgba(255,255,255,0.03)",
                        borderColor: draft.provenance === opt.value ? "rgba(125,249,255,0.28)" : "rgba(255,255,255,0.08)",
                      }}
                    >
                      <span className="text-sm text-white/75">{opt.label}</span>
                      <ProvenanceBadge status={opt.value} compact />
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {/* STEP 3 — Publish */}
            {currentStep === "publish" && (
              <motion.div key="publish" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }} className="space-y-4">
                <div className="rounded-2xl border border-white/10 divide-y divide-white/[0.06] overflow-hidden">
                  {[
                    { label: "Title",       value: draft.title },
                    { label: "Species",     value: draft.species },
                    { label: "Locality",    value: draft.locality || "—" },
                    { label: "Ask Price",   value: draft.price ? `$${draft.price}` : "—" },
                    { label: "Provenance",  value: draft.provenance },
                  ].map(({ label, value }) => (
                    <div key={label} className="flex justify-between px-4 py-3">
                      <span className="text-[11px] uppercase tracking-[0.14em] text-white/35">{label}</span>
                      <span className="text-sm text-white/75">{value}</span>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer */}
        <div className="border-t border-white/[0.07] px-5 py-4 flex gap-3">
          {step > 0 && (
            <button
              type="button"
              onClick={() => setStep((s) => s - 1)}
              className="flex-1 rounded-2xl py-3 text-sm font-bold text-white/40 border border-white/10"
            >
              Back
            </button>
          )}
          <button
            type="button"
            disabled={publishing}
            onClick={() => step < STEPS.length - 1 ? setStep((s) => s + 1) : handlePublish()}
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold uppercase tracking-wide"
            style={{ background: "rgba(125,249,255,0.12)", border: "1px solid rgba(125,249,255,0.28)", color: "#7DF9FF" }}
          >
            {publishing
              ? <><Loader2 className="h-4 w-4 animate-spin" /> Publishing…</>
              : step < STEPS.length - 1
              ? <><ChevronRight className="h-4 w-4" /> Continue</>
              : <><Package className="h-4 w-4" /> Publish Listing</>
            }
          </button>
        </div>
      </motion.div>
    </div>
  );
}