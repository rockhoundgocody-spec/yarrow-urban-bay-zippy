/**
 * NegotiationAssistant — AI negotiation advisor panel.
 * Helps sellers and buyers decide: accept, counter, hold, decline.
 * Tasteful, practical, always preserves human control.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Scale, Loader2, TrendingUp, Minus,
  CheckCircle2, X, RefreshCw, AlertCircle, MessageSquare, ChevronRight
} from "lucide-react";

const ACTION_CONFIG = {
  accept:     { label: "Accept Offer",    color: "#00FFC6", icon: CheckCircle2 },
  counter:    { label: "Counter",         color: "#7DF9FF", icon: TrendingUp },
  hold:       { label: "Hold",            color: "#FFD700", icon: Minus },
  decline:    { label: "Decline",         color: "#FF6B6B", icon: X },
  adjust_ask: { label: "Adjust Ask",      color: "#B97AFF", icon: RefreshCw },
};

const CONFIDENCE_COLOR = { high: "#00FFC6", medium: "#FFD700", low: "#FF6B6B" };

export default function NegotiationAssistant({
  role = "seller",
  askPrice,
  offerPrice,
  mineralName,
  rarity,
  condition,
  provenanceDepth = 0,
  daysListed = 0,
  valuationLow,
  valuationHigh,
  compact = false,
}) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [advice, setAdvice] = useState(null);
  const [contextNote, setContextNote] = useState("");
  const [showTemplate, setShowTemplate] = useState(false);

  const fetchAdvice = async () => {
    setLoading(true);
    setAdvice(null);
    const res = await base44.functions.invoke("negotiationAssistant", {
      role,
      ask_price: askPrice,
      offer_price: offerPrice,
      mineral_name: mineralName,
      rarity,
      condition,
      provenance_depth: provenanceDepth,
      days_listed: daysListed,
      valuation_low: valuationLow,
      valuation_high: valuationHigh,
      context_note: contextNote || undefined,
    });
    setAdvice(res.data?.advice);
    setLoading(false);
  };

  const rec = advice ? ACTION_CONFIG[advice.recommendation] : null;
  const RecIcon = rec?.icon || Scale;

  if (compact) {
    return (
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-bold transition-all"
        style={{ background: "rgba(122,231,255,0.07)", border: "1px solid rgba(122,231,255,0.18)", color: "#7AE7FF" }}
      >
        <Scale className="w-3.5 h-3.5" />
        Negotiation Advisor
        <ChevronRight className="w-3 h-3 opacity-50" />
      </button>
    );
  }

  return (
    <div className="rounded-[22px] overflow-hidden"
      style={{ background: "rgba(10,6,20,0.97)", border: "1px solid rgba(122,231,255,0.12)" }}>
      {/* Header toggle */}
      <button type="button" onClick={() => setOpen(o => !o)}
        className="flex w-full items-center gap-3 px-4 py-3.5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl shrink-0"
          style={{ background: "rgba(122,231,255,0.1)", border: "1px solid rgba(122,231,255,0.22)" }}>
          <Scale className="h-4 w-4 text-cyan-300" />
        </div>
        <div className="flex-1 text-left">
          <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-300/70 mb-0.5">Negotiation Advisor</div>
          <div className="text-sm font-bold text-white">
            {offerPrice ? `$${offerPrice} offer · Ask $${askPrice}` : `Ask $${askPrice}`}
          </div>
        </div>
        <div className="text-[10px] text-white/25 shrink-0">{open ? "▲" : "▼"}</div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden border-t border-white/[0.06]"
          >
            <div className="px-4 py-4 space-y-4">
              {/* Context input */}
              <div>
                <label className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/30 block mb-1.5">
                  Add context (optional)
                </label>
                <input
                  value={contextNote}
                  onChange={e => setContextNote(e.target.value)}
                  placeholder="e.g. buyer seems motivated, similar listed for $300..."
                  className="w-full rounded-[12px] px-3 py-2 text-xs text-white outline-none"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
                />
              </div>

              {/* Get advice CTA */}
              <button
                type="button"
                onClick={fetchAdvice}
                disabled={loading}
                className="w-full py-2.5 rounded-[14px] flex items-center justify-center gap-2 text-xs font-bold transition-all"
                style={{ background: "rgba(122,231,255,0.1)", border: "1px solid rgba(122,231,255,0.25)", color: "#7AE7FF" }}
              >
                {loading
                  ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Analyzing deal...</>
                  : <><Scale className="w-3.5 h-3.5" /> {advice ? "Re-analyze" : "Get Tactical Advice"}</>}
              </button>

              {/* Advice output */}
              <AnimatePresence>
                {advice && !loading && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-3"
                  >
                    {/* Recommendation badge */}
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2 px-3 py-2 rounded-[14px]"
                        style={{ background: `${rec?.color}12`, border: `1px solid ${rec?.color}30` }}>
                        <RecIcon className="w-4 h-4" style={{ color: rec?.color }} />
                        <span className="text-sm font-black" style={{ color: rec?.color }}>{rec?.label}</span>
                      </div>
                      {advice.counter_price && (
                        <div className="text-sm font-black text-amber-300">→ ${advice.counter_price.toLocaleString()}</div>
                      )}
                      <div className="ml-auto text-[10px] font-bold px-2 py-1 rounded-full"
                        style={{ background: `${CONFIDENCE_COLOR[advice.confidence]}12`, color: CONFIDENCE_COLOR[advice.confidence] }}>
                        {advice.confidence}
                      </div>
                    </div>

                    {/* Reasoning */}
                    <div className="text-xs text-white/55 leading-5">{advice.reasoning}</div>

                    {/* Leverage points */}
                    {advice.leverage_points?.length > 0 && (
                      <div className="space-y-1">
                        <div className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/25">Your leverage</div>
                        {advice.leverage_points.map((pt, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-white/45">
                            <TrendingUp className="w-3 h-3 shrink-0 mt-0.5 text-cyan-400" />
                            {pt}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Risk note */}
                    {advice.risk_note && (
                      <div className="flex items-start gap-2 rounded-[12px] px-3 py-2.5"
                        style={{ background: "rgba(255,107,107,0.06)", border: "1px solid rgba(255,107,107,0.14)" }}>
                        <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-red-400" />
                        <span className="text-xs text-red-300/70">{advice.risk_note}</span>
                      </div>
                    )}

                    {/* Message template */}
                    {advice.message_template && (
                      <div>
                        <button type="button" onClick={() => setShowTemplate(o => !o)}
                          className="flex items-center gap-1.5 text-[10px] text-white/30 hover:text-white/50">
                          <MessageSquare className="w-3 h-3" />
                          {showTemplate ? "Hide" : "Show"} message template
                        </button>
                        {showTemplate && (
                          <div className="mt-2 rounded-[12px] px-3 py-2.5 text-xs text-white/55 italic"
                            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
                            "{advice.message_template}"
                          </div>
                        )}
                      </div>
                    )}

                    {/* Disclaimer */}
                    <p className="text-[10px] text-white/18">AI advisory only — you make the final call.</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}