/**
 * PricingStrategyPanel — Wholesale vs Retail vs Premium collector pricing engine.
 * Helps sellers understand where a specimen fits and how fast to move it.
 * Fully deterministic (no API call) — uses valuation + rarity + condition signals.
 */
import React, { useState } from "react";
import { motion } from "framer-motion";
import { DollarSign, Clock, Info } from "lucide-react";

const RARITY_MULT = { common: 1, uncommon: 1.7, rare: 3.2, very_rare: 7, epic: 12, legendary: 22 };
const CONDITION_MULT = { rough: 1, good: 1.3, fair: 1.1, excellent: 1.8, polished: 1.5, display: 2.0 };
const PROVENANCE_BOOST = 1.35;

const TIER_META = {
  wholesale: {
    label: "Wholesale",
    subtitle: "Fast liquidity · dealer-to-dealer",
    color: "#7DF9FF",
    speedLabel: "Days",
    speedDot: "#00FFC6",
    description: "Move quickly. Best for specimens with lower collector appeal or when you need liquidity. Typically dealer-to-dealer pricing.",
  },
  retail: {
    label: "Retail",
    subtitle: "Standard collector marketplace",
    color: "#00FFC6",
    speedLabel: "Weeks",
    speedDot: "#7DF9FF",
    description: "Standard collector market pricing. Balanced between speed and return. Works for most specimens on active platforms.",
  },
  premium: {
    label: "Premium Collector",
    subtitle: "Patient seller · maximum value",
    color: "#FFD700",
    speedLabel: "Months",
    speedDot: "#FFD700",
    description: "Maximum value for rare, high-provenance, or exceptional pieces. Requires patience and the right buyer. Not suitable for common specimens.",
  },
};

function calcPricing(valLow, valHigh, rarity = "common", condition = "good", provenanced = false) {
  const rm = RARITY_MULT[rarity] || 1;
  const cm = CONDITION_MULT[condition] || 1;
  const pm = provenanced ? PROVENANCE_BOOST : 1;
  const base = ((valLow || 20) + (valHigh || 60)) / 2;
  const retail = Math.round(base * rm * cm * pm);
  return {
    wholesale: Math.round(retail * 0.55),
    retail,
    premium: Math.round(retail * 1.65),
  };
}

function velocityLabel(rarity, condition) {
  if (["legendary", "epic"].includes(rarity)) return "patient";
  if (["very_rare", "rare"].includes(rarity) && ["excellent", "display"].includes(condition)) return "slow";
  if (["uncommon", "rare"].includes(rarity)) return "moderate";
  return "fast";
}

const VELOCITY_INFO = {
  fast: { label: "Fast Move", color: "#00FFC6", weeks: "<1 wk" },
  moderate: { label: "Moderate", color: "#7DF9FF", weeks: "2–4 wks" },
  slow: { label: "Patient", color: "#FFD700", weeks: "1–3 mo" },
  patient: { label: "Long Hold", color: "#B97AFF", weeks: "3+ mo" },
};

export default function PricingStrategyPanel({
  mineralName,
  rarity = "common",
  condition = "good",
  provenanced = false,
  valuationLow,
  valuationHigh,
  compact = false,
}) {
  const [selected, setSelected] = useState("retail");
  const [showDetail, setShowDetail] = useState(false);

  const pricing = calcPricing(valuationLow, valuationHigh, rarity, condition, provenanced);
  const velocity = velocityLabel(rarity, condition);
  const vInfo = VELOCITY_INFO[velocity];
  const tier = TIER_META[selected];

  // Recommend tier based on rarity
  const recommended = ["legendary", "epic", "very_rare"].includes(rarity) ? "premium"
    : ["rare", "uncommon"].includes(rarity) ? "retail"
    : "wholesale";

  if (compact) {
    return (
      <div className="flex items-center gap-2 flex-wrap">
        {Object.entries(pricing).map(([t, v]) => (
          <div key={t} className="flex items-center gap-1 rounded-full px-2.5 py-1"
            style={{ background: `${TIER_META[t].color}08`, border: `1px solid ${TIER_META[t].color}20` }}>
            <span className="text-[9px] font-bold uppercase text-white/30">{TIER_META[t].label}</span>
            <span className="text-xs font-black" style={{ color: TIER_META[t].color }}>${v}</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="rounded-[22px] overflow-hidden"
      style={{ background: "rgba(8,5,2,0.98)", border: "1px solid rgba(255,215,0,0.1)" }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3.5 border-b border-white/[0.05]">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl shrink-0"
          style={{ background: "rgba(255,215,0,0.1)", border: "1px solid rgba(255,215,0,0.2)" }}>
          <DollarSign className="h-4 w-4 text-amber-300" />
        </div>
        <div className="flex-1">
          <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-amber-300/70">Pricing Strategy</div>
          <div className="text-xs text-white/35">{mineralName || "Specimen"} · {rarity?.replace("_", " ")} · {condition}</div>
        </div>
        <div className="flex items-center gap-1.5 rounded-full px-2.5 py-1"
          style={{ background: `${vInfo.color}10`, border: `1px solid ${vInfo.color}25` }}>
          <Clock className="w-3 h-3" style={{ color: vInfo.color }} />
          <span className="text-[10px] font-bold" style={{ color: vInfo.color }}>{vInfo.weeks}</span>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {/* Tier selector */}
        <div className="grid grid-cols-3 gap-2">
          {(["wholesale", "retail", "premium"]).map(t => {
            const tm = TIER_META[t];
            const isRec = t === recommended;
            const isSel = t === selected;
            return (
              <button key={t} type="button" onClick={() => setSelected(t)}
                className="relative rounded-[16px] p-3 text-left transition-all"
                style={{
                  background: isSel ? `${tm.color}10` : "rgba(255,255,255,0.03)",
                  border: `1px solid ${isSel ? tm.color : "rgba(255,255,255,0.07)"}`,
                }}>
                {isRec && (
                  <div className="absolute -top-2 left-2 px-1.5 py-0.5 rounded text-[8px] font-black uppercase"
                    style={{ background: tm.color, color: "#000" }}>Rec</div>
                )}
                <div className="text-[9px] font-bold uppercase tracking-[0.12em] text-white/30 mb-1">{tm.label}</div>
                <div className="text-lg font-black" style={{ color: tm.color }}>${pricing[t]}</div>
              </button>
            );
          })}
        </div>

        {/* Selected tier detail */}
        <motion.div key={selected}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-[16px] p-3.5 space-y-2"
          style={{ background: `${tier.color}05`, border: `1px solid ${tier.color}15` }}>
          <div className="flex items-center gap-2">
            <div className="text-sm font-black" style={{ color: tier.color }}>{tier.label}</div>
            <div className="text-[10px] text-white/30">{tier.subtitle}</div>
          </div>
          <div className="text-xs text-white/45 leading-5">{tier.description}</div>
        </motion.div>

        {/* Pricing factors */}
        <div>
          <button type="button" onClick={() => setShowDetail(o => !o)}
            className="text-[10px] text-white/25 flex items-center gap-1 hover:text-white/40 transition-colors">
            <Info className="w-3 h-3" />
            {showDetail ? "Hide" : "Show"} pricing factors
          </button>
          {showDetail && (
            <div className="mt-2 space-y-1.5">
              {[
                { label: "Rarity multiplier", value: `${RARITY_MULT[rarity] || 1}×`, color: "#B97AFF" },
                { label: "Condition multiplier", value: `${CONDITION_MULT[condition] || 1}×`, color: "#7DF9FF" },
                provenanced && { label: "Provenance premium", value: "+35%", color: "#00FFC6" },
                { label: "Velocity estimate", value: vInfo.label, color: vInfo.color },
              ].filter(Boolean).map(({ label, value, color }) => (
                <div key={label} className="flex items-center justify-between text-xs">
                  <span className="text-white/30">{label}</span>
                  <span className="font-bold" style={{ color }}>{value}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}