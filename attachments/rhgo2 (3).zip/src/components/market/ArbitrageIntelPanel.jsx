/**
 * ArbitrageIntelPanel — Seller intelligence surfaces.
 * Surfaces: underpriced alerts, demand signals, stale listings, list-next recs.
 * Pro-tier intelligence panel for serious seller operators.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import {
  Zap, TrendingUp, AlertTriangle, BarChart2,
  Loader2, Package, Star, RefreshCw, Lock
} from "lucide-react";
import { hasAccess } from "@/components/subscription/entitlements";
import { Link } from "react-router-dom";

const SIGNAL_COLOR = { strong: "#00FFC6", moderate: "#7DF9FF", weak: "#FFD700" };
const URGENCY_COLOR = { now: "#00FFC6", soon: "#FFD700", hold: "#9ca3af" };

function ScoreRing({ score }) {
  const color = score >= 75 ? "#00FFC6" : score >= 50 ? "#FFD700" : "#FF6B6B";
  const circumference = 2 * Math.PI * 18;
  return (
    <div className="relative flex items-center justify-center w-12 h-12">
      <svg viewBox="0 0 44 44" className="absolute inset-0 w-full h-full -rotate-90">
        <circle cx="22" cy="22" r="18" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="3" />
        <motion.circle cx="22" cy="22" r="18" fill="none" stroke={color} strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference * (1 - score / 100) }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          style={{ filter: `drop-shadow(0 0 4px ${color})` }}
        />
      </svg>
      <span className="text-xs font-black" style={{ color }}>{score}</span>
    </div>
  );
}

export default function ArbitrageIntelPanel({ user, listings = [], marketPrices = {} }) {
  const isProSeller = hasAccess(user, "seller:analytics");
  const [loading, setLoading] = useState(false);
  const [intel, setIntel] = useState(null);
  const [ran, setRan] = useState(false);

  const { data: collection = [] } = useQuery({
    queryKey: ["unlisted-collection", user?.email],
    queryFn: () => base44.entities.Specimen.list("-created_date", 50),
    enabled: !!user,
    staleTime: 120000,
  });

  const runAnalysis = async () => {
    setLoading(true);
    const listingsWithAge = listings.map(l => ({
      ...l,
      days_listed: l.created_date
        ? Math.floor((Date.now() - new Date(l.created_date).getTime()) / 86400000)
        : 0,
    }));
    const unlistedCollection = collection.filter(s =>
      !listings.some(l => l.specimen_id === s.id)
    );
    const res = await base44.functions.invoke("sellerArbitrageIntel", {
      listings: listingsWithAge,
      collection: unlistedCollection,
      market_prices: marketPrices,
    });
    setIntel(res.data?.intel);
    setRan(true);
    setLoading(false);
  };

  if (!isProSeller) {
    return (
      <div className="rounded-[22px] p-4 text-center space-y-3"
        style={{ background: "rgba(168,85,247,0.05)", border: "1px solid rgba(168,85,247,0.15)" }}>
        <Lock className="w-6 h-6 text-violet-400 mx-auto" />
        <div className="text-sm font-bold text-white">Seller Intelligence</div>
        <div className="text-xs text-white/40">Underpriced alerts, demand signals, and next-listing recommendations — Crystal tier and above.</div>
        <Link to="/BillingAccount"
          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold"
          style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)", color: "#c084fc" }}>
          <Star className="w-3 h-3" /> Upgrade to Crystal
        </Link>
      </div>
    );
  }

  return (
    <div className="rounded-[22px] overflow-hidden"
      style={{ background: "rgba(8,6,16,0.98)", border: "1px solid rgba(122,231,255,0.1)" }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3.5 border-b border-white/[0.05]">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl shrink-0"
          style={{ background: "rgba(122,231,255,0.1)", border: "1px solid rgba(122,231,255,0.2)" }}>
          <BarChart2 className="h-4 w-4 text-cyan-300" />
        </div>
        <div className="flex-1">
          <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-cyan-300/70">Arbitrage Intelligence</div>
          <div className="text-xs text-white/35">Real-time seller opportunity analysis</div>
        </div>
        <button
          type="button"
          onClick={runAnalysis}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold transition-all"
          style={{ background: "rgba(122,231,255,0.08)", border: "1px solid rgba(122,231,255,0.2)", color: "#7AE7FF" }}
        >
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
          {ran ? "Re-analyze" : "Analyze"}
        </button>
      </div>

      <AnimatePresence>
        {loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="py-8 flex flex-col items-center gap-3">
            <Loader2 className="w-6 h-6 text-cyan-300 animate-spin" />
            <div className="text-xs text-white/30">Scanning market for opportunities...</div>
          </motion.div>
        )}

        {intel && !loading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="p-4 space-y-5">
            {/* Health score + top insight */}
            <div className="flex items-center gap-4">
              <ScoreRing score={intel.seller_health_score || 0} />
              <div className="flex-1">
                <div className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/30 mb-1">Portfolio Health</div>
                {intel.top_insight && (
                  <div className="text-xs text-white/70 leading-5">{intel.top_insight}</div>
                )}
              </div>
            </div>

            {/* Underpriced alerts */}
            {intel.underpriced_alerts?.length > 0 && (
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#00FFC6]/60 mb-2 flex items-center gap-1.5">
                  <TrendingUp className="w-3 h-3 text-[#00FFC6]" /> Underpriced — Raise Ask
                </div>
                <div className="space-y-2">
                  {intel.underpriced_alerts.map((a, i) => (
                    <div key={i} className="rounded-[16px] px-3.5 py-3 flex items-center gap-3"
                      style={{ background: "rgba(0,255,198,0.05)", border: "1px solid rgba(0,255,198,0.12)" }}>
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-white truncate">{a.title}</div>
                        <div className="text-[10px] text-white/35 mt-0.5">{a.reason}</div>
                      </div>
                      <div className="shrink-0 text-right">
                        <div className="text-xs text-white/30 line-through">${a.current_ask}</div>
                        <div className="text-sm font-black text-[#00FFC6]">${a.suggested_ask}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Demand signals */}
            {intel.demand_signals?.length > 0 && (
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#7DF9FF]/60 mb-2 flex items-center gap-1.5">
                  <Zap className="w-3 h-3 text-[#7DF9FF]" /> Demand Signals
                </div>
                <div className="flex flex-wrap gap-2">
                  {intel.demand_signals.map((s, i) => (
                    <div key={i} className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
                      style={{ background: `${SIGNAL_COLOR[s.signal_strength]}08`, border: `1px solid ${SIGNAL_COLOR[s.signal_strength]}22` }}>
                      <div className="w-1.5 h-1.5 rounded-full" style={{ background: SIGNAL_COLOR[s.signal_strength] }} />
                      <span className="text-[10px] font-bold text-white/70">{s.mineral}</span>
                      <span className="text-[10px]" style={{ color: SIGNAL_COLOR[s.signal_strength] }}>{s.signal_strength}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Stale listings */}
            {intel.stale_listings?.length > 0 && (
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-amber-400/60 mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-3 h-3 text-amber-400" /> Needs Attention
                </div>
                <div className="space-y-2">
                  {intel.stale_listings.map((s, i) => (
                    <div key={i} className="rounded-[16px] px-3.5 py-2.5 flex items-center gap-3"
                      style={{ background: "rgba(255,215,0,0.04)", border: "1px solid rgba(255,215,0,0.1)" }}>
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-white/80 truncate">{s.title}</div>
                        <div className="text-[10px] text-white/35 mt-0.5">{s.action}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* List next */}
            {intel.list_next?.length > 0 && (
              <div>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#B97AFF]/60 mb-2 flex items-center gap-1.5">
                  <Package className="w-3 h-3 text-[#B97AFF]" /> List These Next
                </div>
                <div className="space-y-2">
                  {intel.list_next.map((s, i) => (
                    <div key={i} className="rounded-[16px] px-3.5 py-2.5 flex items-center gap-3"
                      style={{ background: "rgba(185,122,255,0.05)", border: "1px solid rgba(185,122,255,0.12)" }}>
                      <div className="w-2 h-2 rounded-full shrink-0" style={{ background: URGENCY_COLOR[s.urgency] }} />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-bold text-white truncate">{s.specimen_name}</div>
                        <div className="text-[10px] text-white/35 mt-0.5">{s.reason}</div>
                      </div>
                      <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full shrink-0"
                        style={{ background: `${URGENCY_COLOR[s.urgency]}15`, color: URGENCY_COLOR[s.urgency] }}>
                        {s.urgency}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}

        {!intel && !loading && ran && (
          <div className="py-8 text-center">
            <div className="text-xs text-white/25">No data to analyze yet — add listings or specimens first.</div>
          </div>
        )}
      </AnimatePresence>

      {!ran && !loading && (
        <div className="px-4 py-5 text-center text-xs text-white/25">
          Run analysis to surface pricing gaps and opportunity signals across your portfolio.
        </div>
      )}
    </div>
  );
}