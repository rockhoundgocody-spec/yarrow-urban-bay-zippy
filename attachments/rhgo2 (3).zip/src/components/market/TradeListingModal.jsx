/**
 * TradeListingModal — list a specimen for trade with the community.
 */
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Package, ArrowRight, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

function SuccessStep({ onClose }) {
  return (
    <div className="p-8 text-center">
      <div
        className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
        style={{
          background: 'rgba(0,214,143,0.15)',
          border: '1px solid rgba(0,214,143,0.3)',
        }}
      >
        <CheckCircle2 className="w-8 h-8" style={{ color: '#00D68F' }} />
      </div>
      <h3 className="text-xl font-bold text-white mb-2">Listed for Trade!</h3>
      <p className="text-sm text-white/50 mb-6">Your specimen is now visible to the community.</p>
      <button
        onClick={onClose}
        className="w-full py-3 rounded-2xl text-sm font-bold text-white"
        style={{
          background: 'rgba(255,255,255,0.06)',
          border: '1px solid rgba(255,255,255,0.12)',
        }}
      >
        Close
      </button>
    </div>
  );
}

function ListingForm({
  specimen,
  form,
  setForm,
  loading,
  handleSubmit,
  onClose,
}) {
  return (
    <>
      {/* Header */}
      <div
        className="flex items-center justify-between px-6 pt-6 pb-4"
        style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{
              background: 'rgba(141,124,255,0.15)',
              border: '1px solid rgba(141,124,255,0.3)',
            }}
          >
            <Package className="w-5 h-5" style={{ color: '#8D7CFF' }} />
          </div>
          <div>
            <p className="text-[10px] text-white/40 uppercase tracking-widest">List for Trade</p>
            <p className="text-sm font-bold text-white">{specimen?.label || 'Specimen'}</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: 'rgba(255,255,255,0.05)' }}
          aria-label="Close"
        >
          <X className="w-4 h-4 text-white/50" />
        </button>
      </div>

      <div className="p-6 space-y-4">
        {/* Listing type */}
        <div>
          <p className="text-xs text-white/50 mb-2 uppercase tracking-widest">Listing Type</p>
          <div className="grid grid-cols-3 gap-2">
            {[
              { value: 'trade', label: 'Trade' },
              { value: 'sell', label: 'Sell' },
              { value: 'either', label: 'Either' },
            ].map(({ value, label }) => (
              <button
                key={value}
                onClick={() => setForm(f => ({ ...f, listing_type: value }))}
                className="py-2 rounded-xl text-xs font-bold transition-all"
                style={{
                  background:
                    form.listing_type === value
                      ? 'rgba(141,124,255,0.2)'
                      : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${
                    form.listing_type === value
                      ? 'rgba(141,124,255,0.4)'
                      : 'rgba(255,255,255,0.08)'
                  }`,
                  color: form.listing_type === value ? '#8D7CFF' : 'rgba(255,255,255,0.5)',
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Price */}
        {(form.listing_type === 'sell' || form.listing_type === 'either') && (
          <div>
            <p className="text-xs text-white/50 mb-2 uppercase tracking-widest">Asking Price (USD)</p>
            <input
              type="number"
              placeholder="0.00"
              value={form.asking_price}
              onChange={(e) => setForm(f => ({ ...f, asking_price: e.target.value }))}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-white/25 placeholder:text-white/25"
            />
            {specimen?.valuation_low && (
              <p className="text-xs text-white/30 mt-1.5">
                Estimated: ${specimen.valuation_low}–${specimen.valuation_high}
              </p>
            )}
          </div>
        )}

        {/* Trade for */}
        {(form.listing_type === 'trade' || form.listing_type === 'either') && (
          <div>
            <p className="text-xs text-white/50 mb-2 uppercase tracking-widest">Looking to Trade For</p>
            <input
              type="text"
              placeholder="e.g. Large Amethyst cluster, Fluorite specimen…"
              value={form.trade_for}
              onChange={(e) => setForm(f => ({ ...f, trade_for: e.target.value }))}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-white/25 placeholder:text-white/25"
            />
          </div>
        )}

        {/* Notes */}
        <div>
          <p className="text-xs text-white/50 mb-2 uppercase tracking-widest">Notes</p>
          <textarea
            rows={3}
            placeholder="Condition, provenance, details…"
            value={form.notes}
            onChange={(e) => setForm(f => ({ ...f, notes: e.target.value }))}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm resize-none focus:outline-none focus:border-white/25 placeholder:text-white/25"
          />
        </div>

        {/* Submit */}
        <motion.button
          onClick={handleSubmit}
          disabled={loading || (!form.asking_price && !form.trade_for)}
          className="w-full py-4 rounded-2xl text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
          style={{
            background:
              'linear-gradient(135deg, rgba(141,124,255,0.3), rgba(122,231,255,0.15))',
            border: '1px solid rgba(141,124,255,0.4)',
            color: '#8D7CFF',
            boxShadow: '0 0 24px rgba(141,124,255,0.2)',
          }}
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
        >
          {loading ? 'Listing…' : 'List for Trade'}
          {!loading && <ArrowRight className="w-4 h-4" />}
        </motion.button>
      </div>
    </>
  );
}

export default function TradeListingModal({ specimen, onClose }) {
  const [step, setStep] = useState('form'); // form | confirm | success
  const [form, setForm] = useState({
    asking_price: '',
    trade_for: '',
    notes: '',
    listing_type: 'trade', // trade | sell | either
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!form.asking_price && !form.trade_for) return;
    setLoading(true);
    try {
      const user = await base44.auth.me();
      await base44.entities.TradePost.create({
        specimen_id: specimen.id,
        specimen_name: specimen.label || 'Unknown Specimen',
        photo_url: specimen.photos?.[0] || null,
        asking_price: form.asking_price ? parseFloat(form.asking_price) : null,
        trade_for: form.trade_for,
        notes: form.notes,
        listing_type: form.listing_type,
        status: 'active',
        seller_name: user.full_name,
        seller_email: user.email,
        valuation_low: specimen.valuation_low,
        valuation_high: specimen.valuation_high,
      });
      setStep('success');
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[999] flex items-end sm:items-center justify-center p-4"
        style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          className="w-full max-w-md rounded-3xl overflow-hidden"
          style={{
            background: 'linear-gradient(180deg, #0A0F14 0%, #050A10 100%)',
            border: '1px solid rgba(255,255,255,0.1)',
            boxShadow: '0 24px 64px rgba(0,0,0,0.6)',
          }}
          initial={{ y: 60, opacity: 0, scale: 0.96 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          exit={{ y: 40, opacity: 0 }}
          transition={{ type: 'spring', damping: 26, stiffness: 280 }}
        >
          {step === 'success' ? (
            <SuccessStep onClose={onClose} />
          ) : (
            <ListingForm
              specimen={specimen}
              form={form}
              setForm={setForm}
              loading={loading}
              handleSubmit={handleSubmit}
              onClose={onClose}
            />
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
