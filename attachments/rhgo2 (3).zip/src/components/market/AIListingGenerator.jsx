/**
 * AIListingGenerator — Phase 6 automated listing flow.
 * Turns a specimen record into a fully structured, editable market listing.
 * Supports: scan result, collection specimen, or manual entry.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import {
  Sparkles, Loader2, CheckCircle2, Zap, Send, TrendingUp
} from "lucide-react";

const VELOCITY_LABEL = { fast: "Fast move", moderate: "Moderate", slow: "Patient", patient: "Long hold" };
const VELOCITY_COLOR = { fast: "#00FFC6", moderate: "#7DF9FF", slow: "#FFD700", patient: "#B97AFF" };
const DEMAND_COLOR = { high: "#00FFC6", moderate: "#7DF9FF", niche: "#FFD700", low: "#9ca3af" };
const PRICE_TIER_LABEL = { wholesale: "Wholesale", retail: "Retail", premium: "Premium Collector" };
const PRICE_TIER_COLOR = { wholesale: "#7DF9FF", retail: "#00FFC6", premium: "#FFD700" };

function PriceTierCard({ tier, value, recommended, onSelect, selected }) {
  const color = PRICE_TIER_COLOR[tier];
  const isRec = tier === recommended;
  return (
    <button
      type="button"
      onClick={() => onSelect(tier)}
      className="relative rounded-[18px] p-3.5 text-left transition-all"
      style={{
        background: selected ? `${color}10` : "rgba(255,255,255,0.03)",
        border: `1px solid ${selected ? color : "rgba(255,255,255,0.08)"}`,
        boxShadow: selected ? `0 0 16px ${color}20` : "none",
      }}
    >
      {isRec && (
        <div className="absolute -top-2.5 left-3 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider"
          style={{ background: color, color: "#000" }}>Recommended</div>
      )}
      <div className="text-[10px] font-bold uppercase tracking-[0.16em] mb-1" style={{ color: "rgba(255,255,255,0.35)" }}>
        {PRICE_TIER_LABEL[tier]}
      </div>
      <div className="text-xl font-black" style={{ color }}>${value?.toLocaleString() || "—"}</div>
    </button>
  );
}

export default function AIListingGenerator({ specimen, onPublish, onClose }) {
  const [step, setStep] = useState("idle"); // idle | generating | editing | publishing
  const [generated, setGenerated] = useState(null);
  const [edited, setEdited] = useState(null);
  const [selectedTier, setSelectedTier] = useState(null);
  const [publishLoading, setPublishLoading] = useState(false);

  const handleGenerate = async () => {
    setStep("generating");
    const res = await base44.functions.invoke("aiListingGenerator", {
      specimen_id: specimen?.id,
      mineral_name: specimen?.name || specimen?.mineral_name,
      variety: specimen?.variety,
      category: specimen?.category,
      condition: specimen?.condition,
      rarity: specimen?.rarity,
      color: specimen?.color,
      luster: specimen?.luster,
      hardness: specimen?.hardness,
      locality_name: specimen?.locality_name,
      land_type: specimen?.land_type,
      ai_confidence: specimen?.confidence,
      valuation_low: specimen?.valuation_low,
      valuation_high: specimen?.valuation_high,
      photo_url: specimen?.photo_url,
      formation_history: specimen?.formation_history,
      geological_significance: specimen?.geological_significance,
      notes: specimen?.notes,
    });
    const listing = res.data?.listing;
    if (listing) {
      setGenerated(listing);
      setEdited({
        title: listing.title || "",
        subtitle: listing.subtitle || "",
        description: listing.description || "",
        condition_summary: listing.condition_summary || "",
        provenance_summary: listing.provenance_summary || "",
      });
      setSelectedTier(listing.pricing?.recommended || "retail");
      setStep("editing");
    }
  };

  const handlePublish = async () => {
    setPublishLoading(true);
    setStep("publishing");
    const price = generated?.pricing?.[selectedTier] || 0;
    await base44.entities.MarketplaceItem.create({
      title: edited.title,
      description: `${edited.subtitle ? edited.subtitle + "\n\n" : ""}${edited.description}`,
      price,
      mineral_name: specimen?.name || specimen?.mineral_name,
      mineral_type: specimen?.mineral_type,
      category: specimen?.category || "mineral",
      condition: specimen?.condition || "good",
      photo_url: specimen?.photo_url,
      photo_urls: specimen?.photo_urls,
      location_found: specimen?.locality_name,
      locality: specimen?.locality_name,
      weight_grams: specimen?.weight_grams,
      status: "active",
      specimen_id: specimen?.id,
      provenance_summary: edited.provenance_summary,
      ai_confidence: specimen?.confidence,
      rarity: specimen?.rarity,
      land_type: specimen?.land_type,
      valuation_low: specimen?.valuation_low,
      valuation_high: specimen?.valuation_high,
      seller_name: "",
    });
    setPublishLoading(false);
    if (onPublish) onPublish({ price, title: edited.title });
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)" }}>
          <Sparkles className="w-4 h-4 text-violet-400" />
        </div>
        <div>
          <div className="text-xs font-black uppercase tracking-[0.18em] text-violet-400">AI Listing Generator</div>
          <div className="text-[10px] text-white/30">Collector-grade copy · pricing strategy · one tap to publish</div>
        </div>
      </div>

      {/* Specimen preview strip */}
      {specimen && (
        <div className="flex items-center gap-3 rounded-[16px] p-3"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          {specimen.photo_url && (
            <img src={specimen.photo_url} alt="" className="w-12 h-12 rounded-xl object-cover shrink-0" />
          )}
          <div className="min-w-0 flex-1">
            <div className="text-sm font-bold text-white truncate">{specimen.name || specimen.mineral_name || "Unknown specimen"}</div>
            <div className="text-[10px] text-white/30 mt-0.5">{specimen.locality_name || "No locality"} · {specimen.rarity || "unknown rarity"}</div>
          </div>
          {specimen.valuation_low && specimen.valuation_high && (
            <div className="text-sm font-black text-amber-300 shrink-0">${specimen.valuation_low}–${specimen.valuation_high}</div>
          )}
        </div>
      )}

      {/* Generate button */}
      {step === "idle" && (
        <button
          onClick={handleGenerate}
          className="w-full py-4 rounded-[20px] flex items-center justify-center gap-2.5 font-black text-sm transition-all active:scale-[0.98]"
          style={{
            background: "linear-gradient(135deg, rgba(168,85,247,0.25), rgba(122,231,255,0.12))",
            border: "1px solid rgba(168,85,247,0.45)",
            color: "#c084fc",
            boxShadow: "0 4px 24px rgba(168,85,247,0.2)",
          }}
        >
          <Sparkles className="w-4 h-4" />
          Generate Collector-Grade Listing
        </button>
      )}

      {/* Generating state */}
      {step === "generating" && (
        <div className="py-8 flex flex-col items-center gap-3">
          <div className="relative">
            <div className="w-12 h-12 rounded-full border-2 border-violet-500/30 border-t-violet-400 animate-spin" />
            <Sparkles className="absolute inset-0 m-auto w-5 h-5 text-violet-400" />
          </div>
          <div className="text-xs text-white/40 text-center">
            Analyzing specimen · writing copy · building pricing strategy...
          </div>
        </div>
      )}

      {/* Editing step */}
      <AnimatePresence>
        {step === "editing" && generated && edited && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Pricing strategy */}
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/30 mb-2">Pricing Strategy</div>
              <div className="grid grid-cols-3 gap-2">
                {["wholesale", "retail", "premium"].map(tier => (
                  <PriceTierCard
                    key={tier}
                    tier={tier}
                    value={generated.pricing?.[tier]}
                    recommended={generated.pricing?.recommended}
                    selected={selectedTier === tier}
                    onSelect={setSelectedTier}
                  />
                ))}
              </div>
              {generated.pricing?.rationale && (
                <div className="mt-2 text-[11px] text-white/35 leading-5 px-1">{generated.pricing.rationale}</div>
              )}
            </div>

            {/* Velocity + demand signals */}
            <div className="flex items-center gap-3">
              {generated.velocity_estimate && (
                <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
                  style={{ background: `${VELOCITY_COLOR[generated.velocity_estimate]}10`, border: `1px solid ${VELOCITY_COLOR[generated.velocity_estimate]}25` }}>
                  <Zap className="w-3 h-3" style={{ color: VELOCITY_COLOR[generated.velocity_estimate] }} />
                  <span className="text-[10px] font-bold" style={{ color: VELOCITY_COLOR[generated.velocity_estimate] }}>
                    {VELOCITY_LABEL[generated.velocity_estimate]}
                  </span>
                </div>
              )}
              {generated.demand_signal && (
                <div className="flex items-center gap-1.5 rounded-full px-3 py-1.5"
                  style={{ background: `${DEMAND_COLOR[generated.demand_signal]}10`, border: `1px solid ${DEMAND_COLOR[generated.demand_signal]}25` }}>
                  <TrendingUp className="w-3 h-3" style={{ color: DEMAND_COLOR[generated.demand_signal] }} />
                  <span className="text-[10px] font-bold" style={{ color: DEMAND_COLOR[generated.demand_signal] }}>
                    {generated.demand_signal} demand
                  </span>
                </div>
              )}
            </div>

            {/* Title editor */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/30 block mb-1.5">Title</label>
              <input
                value={edited.title}
                onChange={e => setEdited(p => ({ ...p, title: e.target.value }))}
                className="w-full rounded-[14px] px-3.5 py-2.5 text-sm text-white font-semibold outline-none"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
              />
            </div>

            {/* Subtitle */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/30 block mb-1.5">Hook / Subtitle</label>
              <input
                value={edited.subtitle}
                onChange={e => setEdited(p => ({ ...p, subtitle: e.target.value }))}
                className="w-full rounded-[14px] px-3.5 py-2.5 text-sm text-white outline-none"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
              />
            </div>

            {/* Description */}
            <div>
              <label className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/30 block mb-1.5">Description</label>
              <textarea
                value={edited.description}
                onChange={e => setEdited(p => ({ ...p, description: e.target.value }))}
                rows={4}
                className="w-full rounded-[14px] px-3.5 py-2.5 text-sm text-white outline-none resize-none leading-relaxed"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
              />
            </div>

            {/* Features list */}
            {generated.features?.length > 0 && (
              <div className="rounded-[16px] p-3"
                style={{ background: "rgba(0,255,198,0.04)", border: "1px solid rgba(0,255,198,0.12)" }}>
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#00FFC6]/60 mb-2">Key Features</div>
                <div className="space-y-1.5">
                  {generated.features.map((f, i) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-white/55">
                      <CheckCircle2 className="w-3 h-3 shrink-0 mt-0.5 text-[#00FFC6]" />
                      {f}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Provenance summary */}
            {edited.provenance_summary && (
              <div>
                <label className="text-[10px] font-bold uppercase tracking-[0.16em] text-white/30 block mb-1.5">Provenance Statement</label>
                <textarea
                  value={edited.provenance_summary}
                  onChange={e => setEdited(p => ({ ...p, provenance_summary: e.target.value }))}
                  rows={2}
                  className="w-full rounded-[14px] px-3.5 py-2.5 text-sm text-white outline-none resize-none"
                  style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                />
              </div>
            )}

            {/* Publish CTA */}
            <button
              onClick={handlePublish}
              disabled={publishLoading || !edited.title}
              className="w-full py-4 rounded-[20px] flex items-center justify-center gap-2.5 font-black text-sm transition-all active:scale-[0.98] disabled:opacity-50"
              style={{
                background: "linear-gradient(135deg, #00FFC6, #7AE7FF)",
                color: "#000",
                boxShadow: "0 4px 24px rgba(0,255,198,0.35)",
              }}
            >
              {publishLoading
                ? <><Loader2 className="w-4 h-4 animate-spin" /> Publishing...</>
                : <><Send className="w-4 h-4" /> Publish at ${generated.pricing?.[selectedTier]?.toLocaleString()}</>}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Published state */}
      {step === "publishing" && !publishLoading && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}
          className="py-8 flex flex-col items-center gap-3 text-center">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center"
            style={{ background: "rgba(0,255,198,0.12)", border: "1px solid rgba(0,255,198,0.3)" }}>
            <CheckCircle2 className="w-7 h-7 text-[#00FFC6]" />
          </div>
          <div className="text-sm font-bold text-white">Listing Published</div>
          <div className="text-xs text-white/35">Your specimen is now live on the Auction House</div>
        </motion.div>
      )}
    </div>
  );
}