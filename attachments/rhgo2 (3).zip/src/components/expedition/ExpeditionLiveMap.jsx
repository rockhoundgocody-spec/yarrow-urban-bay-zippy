/**
 * ExpeditionLiveMap
 * Leaflet map showing live coordinate pins for all expedition members,
 * campsite marker, hazards, and finds. Tied into GroupExpedition entity.
 */
import React, { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const PIN_COLORS = {
  member: "#7AE7FF",
  campsite: "#F5B642",
  hazard: "#ef4444",
  find: "#00D68F",
  waypoint: "#8D7CFF",
};

function makeIcon(type, initials = "?") {
  const color = PIN_COLORS[type] || "#fff";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="34" height="40" viewBox="0 0 34 40">
    <path d="M17 0C7.6 0 0 7.6 0 17c0 13 17 23 17 23s17-10 17-23C34 7.6 26.4 0 17 0z" fill="${color}" opacity="0.92"/>
    <circle cx="17" cy="17" r="9" fill="rgba(0,0,0,0.55)"/>
    <text x="17" y="21" text-anchor="middle" font-size="9" font-weight="bold" fill="white" font-family="sans-serif">${initials}</text>
  </svg>`;
  return L.divIcon({
    html: svg,
    iconSize: [34, 40],
    iconAnchor: [17, 40],
    popupAnchor: [0, -38],
    className: "",
  });
}

function FitBounds({ pins }) {
  const map = useMap();
  useEffect(() => {
    if (!pins?.length) return;
    const bounds = pins.map((p) => [p.lat, p.lng]);
    if (bounds.length === 1) {
      map.setView(bounds[0], 14);
    } else {
      map.fitBounds(bounds, { padding: [40, 40] });
    }
  }, [pins, map]);
  return null;
}

export default function ExpeditionLiveMap({ expedition, currentUserEmail }) {
  const allPins = [
    ...(expedition.live_pins || []),
    ...(expedition.campsite_lat
      ? [{
          id: "campsite",
          lat: expedition.campsite_lat,
          lng: expedition.campsite_lng,
          label: expedition.campsite_label || "Base Camp",
          pin_type: "campsite",
          display: "Camp",
        }]
      : []),
  ];

  if (!allPins.length) {
    return (
      <div className="flex items-center justify-center h-full rounded-2xl"
        style={{ background: "rgba(10,15,20,0.6)", border: "1px solid rgba(255,255,255,0.06)", minHeight: 220 }}>
        <p className="text-white/30 text-sm">No pins shared yet</p>
      </div>
    );
  }

  const center = [allPins[0].lat, allPins[0].lng];

  return (
    <div className="rounded-2xl overflow-hidden" style={{ height: 260 }}>
      <MapContainer
        center={center}
        zoom={13}
        style={{ width: "100%", height: "100%" }}
        zoomControl={false}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution=""
        />
        <FitBounds pins={allPins} />
        {allPins.map((pin) => {
          const initials = pin.display
            ? pin.display.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()
            : "?";
          const isMe = pin.email === currentUserEmail;
          return (
            <Marker
              key={pin.id}
              position={[pin.lat, pin.lng]}
              icon={makeIcon(pin.pin_type || "member", isMe ? "ME" : initials)}
            >
              <Popup>
                <div style={{ minWidth: 120 }}>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>{pin.display || pin.email}</div>
                  <div style={{ fontSize: 11, color: "#666", marginTop: 2 }}>{pin.label}</div>
                  {pin.updated_at && (
                    <div style={{ fontSize: 10, color: "#999", marginTop: 4 }}>
                      {new Date(pin.updated_at).toLocaleTimeString()}
                    </div>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}