/**
 * SafetyChecklist
 * Distributed safety checklist for group expeditions.
 * Each member checks off items independently; checked_by tracks who confirmed what.
 */
import React from "react";
import { CheckSquare, Square, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";

const DEFAULT_ITEMS = [
  { id: "first_aid", item: "First aid kit packed", category: "safety" },
  { id: "water", item: "Water (2L+ per person per day)", category: "safety" },
  { id: "emergency_contacts", item: "Emergency contacts shared with group", category: "safety" },
  { id: "maps_offline", item: "Offline maps downloaded", category: "navigation" },
  { id: "weather_checked", item: "Weather checked for all days", category: "safety" },
  { id: "sun_protection", item: "Sun protection (hat, sunscreen)", category: "gear" },
  { id: "snake_awareness", item: "Snake/wildlife awareness briefed", category: "safety" },
  { id: "permits", item: "Land access permits verified", category: "legal" },
  { id: "communication", item: "Satellite communicator or PLB", category: "safety" },
  { id: "vehicle_check", item: "Vehicle check completed", category: "logistics" },
  { id: "meeting_point", item: "Emergency meeting point established", category: "safety" },
  { id: "tools_packed", item: "Field tools packed & secured", category: "gear" },
];

const CATEGORY_COLORS = {
  safety: "#ef4444",
  navigation: "#7AE7FF",
  gear: "#00D68F",
  legal: "#F5B642",
  logistics: "#8D7CFF",
};

export default function SafetyChecklist({ checklist = [], currentUserEmail, onToggle }) {
  // Merge defaults with saved state
  const merged = DEFAULT_ITEMS.map((def) => {
    const saved = checklist.find((c) => c.id === def.id);
    return saved ? { ...def, ...saved } : { ...def, checked_by: [] };
  });

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 mb-3">
        <ShieldAlert className="w-4 h-4 text-red-400" />
        <span className="text-sm font-semibold text-white/80">Group Safety Checklist</span>
        <span className="text-xs text-white/30 ml-auto">
          {merged.filter((i) => (i.checked_by || []).length > 0).length}/{merged.length} confirmed
        </span>
      </div>

      {merged.map((item, idx) => {
        const isMeChecked = (item.checked_by || []).includes(currentUserEmail);
        const totalChecked = (item.checked_by || []).length;
        const catColor = CATEGORY_COLORS[item.category] || "#fff";

        return (
          <motion.button
            key={item.id}
            onClick={() => onToggle(item.id, !isMeChecked)}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all"
            style={{
              background: isMeChecked ? "rgba(0,214,143,0.07)" : "rgba(255,255,255,0.03)",
              border: `1px solid ${isMeChecked ? "rgba(0,214,143,0.22)" : "rgba(255,255,255,0.06)"}`,
            }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.03 }}
          >
            {isMeChecked
              ? <CheckSquare style={{ width: 16, height: 16, color: "#00D68F", flexShrink: 0 }} />
              : <Square style={{ width: 16, height: 16, color: "rgba(255,255,255,0.25)", flexShrink: 0 }} />
            }
            <div className="flex-1 min-w-0">
              <div className="text-sm text-white/80 leading-tight">{item.item}</div>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <div
                className="text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide"
                style={{ background: `${catColor}14`, color: catColor }}
              >
                {item.category}
              </div>
              {totalChecked > 0 && (
                <div className="text-[10px] text-white/30">
                  {totalChecked}✓
                </div>
              )}
            </div>
          </motion.button>
        );
      })}
    </div>
  );
}