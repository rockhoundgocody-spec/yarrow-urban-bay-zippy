import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Target, Plus, Check, Loader2, Flame, Trophy } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

const METRIC_LABELS = {
  scans: 'Scans',
  locations_visited: 'Locations Visited',
  xp: 'XP Points',
  custom: 'Custom',
};

/**
 * FieldGoalProgress — create field goals, track progress, check in.
 * Uses PersonalGoal entity (target_value, current_value, status, streak).
 */
export default function FieldGoalProgress() {
  const qc = useQueryClient();
  const [showNew, setShowNew] = useState(false);
  const [form, setForm] = useState({
    title: '', target_metric: 'scans', target_value: '', deadline: '',
  });

  const { data: goals = [], isLoading } = useQuery({
    queryKey: ['fieldGoals'],
    queryFn: () => base44.entities.PersonalGoal.list('-created_date', 50),
    staleTime: 15000,
  });

  const createGoal = useMutation({
    mutationFn: () => base44.entities.PersonalGoal.create({
      title: form.title.trim(),
      target_metric: form.target_metric,
      target_value: Number(form.target_value) || 1,
      current_value: 0,
      deadline: form.deadline || new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0],
      check_in_frequency: 'weekly',
      streak: 0,
      status: 'active',
    }),
    onSuccess: () => {
      qc.invalidateQueries(['fieldGoals']);
      setShowNew(false);
      setForm({ title: '', target_metric: 'scans', target_value: '', deadline: '' });
    },
  });

  const checkIn = useMutation({
    mutationFn: ({ goal, increment }) => {
      const newCurrent = Math.max(0, (goal.current_value || 0) + increment);
      const today = new Date().toISOString().split('T')[0];
      const lastChecked = goal.last_checked_in;
      // Streak logic: if last check-in was yesterday, increment streak; if today, keep; else reset to 1
      let newStreak = goal.streak || 0;
      if (lastChecked !== today) {
        const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
        newStreak = lastChecked === yesterday ? newStreak + 1 : 1;
      }
      const achieved = newCurrent >= (goal.target_value || 1);
      return base44.entities.PersonalGoal.update(goal.id, {
        current_value: newCurrent,
        last_checked_in: today,
        streak: newStreak,
        status: achieved ? 'achieved' : 'active',
      });
    },
    onSuccess: () => qc.invalidateQueries(['fieldGoals']),
  });

  const pct = (curr, target) => Math.min(100, Math.round(((curr || 0) / (target || 1)) * 100));

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4" style={{ color: '#00D68F' }} />
          <h3 className="text-sm font-bold text-white">Field Goal Tracker</h3>
        </div>
        <button
          onClick={() => setShowNew(!showNew)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold"
          style={{ background: 'rgba(0,214,143,0.1)', border: '1px solid rgba(0,214,143,0.25)', color: '#00D68F' }}>
          <Plus className="w-3 h-3" /> New Goal
        </button>
      </div>

      {showNew && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
          className="rounded-xl p-3 mb-3 space-y-2"
          style={{ background: 'rgba(0,214,143,0.04)', border: '1px solid rgba(0,214,143,0.15)' }}>
          <input
            value={form.title}
            onChange={(e) => setForm(f => ({ ...f, title: e.target.value }))}
            placeholder="Goal title (e.g. Find 5 new minerals this month)"
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-emerald-400/40"
          />
          <div className="grid grid-cols-2 gap-2">
            <select value={form.target_metric} onChange={(e) => setForm(f => ({ ...f, target_metric: e.target.value }))}
              className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-400/40">
              {Object.entries(METRIC_LABELS).map(([val, label]) => (
                <option key={val} value={val} className="bg-slate-900">{label}</option>
              ))}
            </select>
            <input type="number" min="1" value={form.target_value}
              onChange={(e) => setForm(f => ({ ...f, target_value: e.target.value }))}
              placeholder="Target"
              className="bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-emerald-400/40" />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-white/40">Deadline</label>
            <input type="date" value={form.deadline}
              onChange={(e) => setForm(f => ({ ...f, deadline: e.target.value }))}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-400/40" />
          </div>
          <button
            onClick={() => createGoal.mutate()}
            disabled={!form.title.trim() || !form.target_value || createGoal.isPending}
            className="w-full py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
            style={{ background: 'rgba(0,214,143,0.15)', border: '1px solid rgba(0,214,143,0.3)', color: '#00D68F' }}>
            {createGoal.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Create Goal
          </button>
        </motion.div>
      )}

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-white/30" />
        </div>
      )}

      {!isLoading && goals.length === 0 && (
        <p className="text-xs text-white/30 text-center py-6">
          No goals set. Create one to stay accountable in the field.
        </p>
      )}

      <div className="space-y-2.5">
        {goals.map((goal) => {
          const progress = pct(goal.current_value, goal.target_value);
          const achieved = goal.status === 'achieved';
          const daysLeft = goal.deadline
            ? Math.ceil((new Date(goal.deadline) - new Date()) / 86400000)
            : null;
          return (
            <div key={goal.id}
              className="rounded-xl p-3"
              style={{
                background: achieved ? 'rgba(0,214,143,0.06)' : 'rgba(255,255,255,0.03)',
                border: `1px solid ${achieved ? 'rgba(0,214,143,0.3)' : 'rgba(255,255,255,0.06)'}`,
              }}>
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-1.5">
                    {achieved && <Trophy className="w-3.5 h-3.5" style={{ color: '#F5B642' }} />}
                    <p className="text-sm font-semibold text-white">{goal.title}</p>
                  </div>
                  <p className="text-xs text-white/40 mt-0.5">
                    {METRIC_LABELS[goal.target_metric] || goal.target_metric} ·
                    {' '}{goal.current_value || 0} / {goal.target_value || 0}
                    {daysLeft !== null && !achieved && (
                      <span className="ml-2" style={{ color: daysLeft < 0 ? '#ff3366' : 'rgba(255,255,255,0.35)' }}>
                        {daysLeft < 0 ? 'Overdue' : `${daysLeft}d left`}
                      </span>
                    )}
                  </p>
                </div>
                {(goal.streak || 0) > 0 && (
                  <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: 'rgba(245,182,66,0.12)', color: '#F5B642' }}>
                    <Flame className="w-3 h-3" /> {goal.streak}
                  </span>
                )}
              </div>

              {/* Progress bar */}
              <div className="w-full h-2 rounded-full overflow-hidden mb-2"
                style={{ background: 'rgba(255,255,255,0.06)' }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="h-full rounded-full"
                  style={{
                    background: achieved
                      ? 'linear-gradient(90deg, #F5B642, #00D68F)'
                      : 'linear-gradient(90deg, #7AE7FF, #00D68F)',
                  }}
                />
              </div>

              {/* Check-in buttons */}
              {!achieved && (
                <div className="flex gap-1.5">
                  <button
                    onClick={() => checkIn.mutate({ goal, increment: -1 })}
                    disabled={checkIn.isPending}
                    className="flex-1 py-1.5 rounded-lg text-xs font-bold"
                    style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: 'rgba(255,255,255,0.4)' }} aria-label="Decrement">
                    −1
                  </button>
                  <button
                    onClick={() => checkIn.mutate({ goal, increment: 1 })}
                    disabled={checkIn.isPending}
                    className="flex-[2] py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1"
                    style={{ background: 'rgba(0,214,143,0.12)', border: '1px solid rgba(0,214,143,0.25)', color: '#00D68F' }}>
                    <Check className="w-3 h-3" /> Check In +1
                  </button>
                  <button
                    onClick={() => checkIn.mutate({ goal, increment: 5 })}
                    disabled={checkIn.isPending}
                    className="flex-1 py-1.5 rounded-lg text-xs font-bold"
                    style={{ background: 'rgba(122,231,255,0.08)', border: '1px solid rgba(122,231,255,0.2)', color: '#7AE7FF' }} aria-label="Increment">
                    +5
                  </button>
                </div>
              )}

              {achieved && (
                <p className="text-xs text-center font-bold" style={{ color: '#00D68F' }}>
                  🎉 Goal Achieved!
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}