import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calendar, ChevronDown, Check, Loader2, Plus } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

function daysBetween(s, e) {
  if (!s || !e) return 0;
  const ms = new Date(e) - new Date(s);
  return Math.max(0, Math.round(ms / 86400000)) + 1;
}

function TripRow({ trip, expanded, onToggle }) {
  const qc = useQueryClient();
  const [editStart, setEditStart] = useState(trip.start_date || '');
  const [editEnd, setEditEnd] = useState(trip.end_date || '');

  const updateDates = useMutation({
    mutationFn: ({ id, start_date, end_date }) =>
      base44.entities.ItineraryPlan.update(id, { start_date, end_date }),
    onSuccess: () => qc.invalidateQueries(['expeditionTrips']),
  });

  return (
    <div className="rounded-xl overflow-hidden"
      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
      <button onClick={() => onToggle(expanded ? null : trip.id)}
        className="w-full flex items-center justify-between px-3 py-3 text-left">
        <div>
          <p className="text-sm font-semibold text-white">{trip.name}</p>
          <p className="text-xs text-white/40">
            {trip.start_date || 'No date'} → {trip.end_date || '—'}
            {trip.start_date && trip.end_date && (
              <span className="ml-2" style={{ color: '#7AE7FF' }}>
                {daysBetween(trip.start_date, trip.end_date)} day{daysBetween(trip.start_date, trip.end_date) !== 1 ? 's' : ''}
              </span>
            )}
          </p>
        </div>
        <ChevronDown className={`w-4 h-4 text-white/30 transition-transform ${expanded ? 'rotate-180' : ''}`} />
      </button>
      {expanded && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="px-3 pb-3 grid grid-cols-2 gap-2">
          <div>
            <label className="text-[10px] uppercase tracking-wider text-white/40">Start</label>
            <input type="date" value={editStart} onChange={(e) => setEditStart(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400/40" />
          </div>
          <div>
            <label className="text-[10px] uppercase tracking-wider text-white/40">End</label>
            <input type="date" value={editEnd} onChange={(e) => setEditEnd(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-lg px-2 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400/40" />
          </div>
          <button
            onClick={() => updateDates.mutate({ id: trip.id, start_date: editStart, end_date: editEnd })}
            disabled={updateDates.isPending}
            className="col-span-2 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5"
            style={{ background: 'rgba(0,214,143,0.12)', border: '1px solid rgba(0,214,143,0.25)', color: '#00D68F' }}>
            <Check className="w-3.5 h-3.5" /> Save Dates
          </button>
        </motion.div>
      )}
    </div>
  );
}

/**
 * TripDateCard — create expeditions and set start/end dates.
 * Uses ItineraryPlan entity (start_date, end_date).
 */
export default function TripDateCard() {
  const qc = useQueryClient();
  const [expandedId, setExpandedId] = useState(null);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newStart, setNewStart] = useState('');
  const [newEnd, setNewEnd] = useState('');

  const { data: trips = [], isLoading } = useQuery({
    queryKey: ['expeditionTrips'],
    queryFn: () => base44.entities.ItineraryPlan.list('-created_date', 50),
    staleTime: 15000,
  });

  const createTrip = useMutation({
    mutationFn: () => base44.entities.ItineraryPlan.create({
      name: newName.trim() || 'Untitled Expedition',
      start_date: newStart || new Date().toISOString().split('T')[0],
      end_date: newEnd || newStart || new Date().toISOString().split('T')[0],
      days: [],
      notes: '',
    }),
    onSuccess: () => {
      qc.invalidateQueries(['expeditionTrips']);
      setShowNew(false);
      setNewName('');
      setNewStart('');
      setNewEnd('');
    },
  });

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4" style={{ color: '#7AE7FF' }} />
          <h3 className="text-sm font-bold text-white">Expedition Dates</h3>
        </div>
        <button
          onClick={() => setShowNew(!showNew)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold"
          style={{ background: 'rgba(122,231,255,0.1)', border: '1px solid rgba(122,231,255,0.25)', color: '#7AE7FF' }}>
          <Plus className="w-3 h-3" /> New Trip
        </button>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-white/30" />
        </div>
      )}

      {!isLoading && trips.length === 0 && !showNew && (
        <p className="text-xs text-white/30 text-center py-6">
          No expeditions yet. Tap "New Trip" to plan your first outing.
        </p>
      )}

      {showNew && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
          className="rounded-xl p-3 mb-3 space-y-2"
          style={{ background: 'rgba(122,231,255,0.04)', border: '1px solid rgba(122,231,255,0.15)' }}>
          <input
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Expedition name (e.g. Quartzite Spring Dig)"
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-cyan-400/40"
          />
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] uppercase tracking-wider text-white/40">Start</label>
              <input type="date" value={newStart} onChange={(e) => setNewStart(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400/40" />
            </div>
            <div>
              <label className="text-[10px] uppercase tracking-wider text-white/40">End</label>
              <input type="date" value={newEnd} onChange={(e) => setNewEnd(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400/40" />
            </div>
          </div>
          <button
            onClick={() => createTrip.mutate()}
            disabled={createTrip.isPending}
            className="w-full py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2"
            style={{ background: 'rgba(0,214,143,0.15)', border: '1px solid rgba(0,214,143,0.3)', color: '#00D68F' }}>
            {createTrip.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Create Expedition
          </button>
        </motion.div>
      )}

      <div className="space-y-2">
        {trips.map((trip) => (
          <TripRow key={trip.id} trip={trip} expanded={expandedId === trip.id} onToggle={setExpandedId} />
        ))}
      </div>
    </div>
  );
}