import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Wrench, MapPin, Plus, Check, X, Loader2, Search } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

const CATEGORY_LABELS = {
  hammer: 'Hammer', chisel: 'Chisel', uv_light: 'UV Light', magnifier: 'Magnifier',
  safety: 'Safety', bag: 'Bag', pick: 'Pick', screen: 'Screen', other: 'Other',
};

/**
 * GearLocationLinker — shows user's gear items and lets them link
 * each piece to specific RockhoundingLocation entries.
 * Uses UserGear entity (linked_location_ids, linked_location_names).
 */
export default function GearLocationLinker() {
  const qc = useQueryClient();
  const [linkingGearId, setLinkingGearId] = useState(null);
  const [search, setSearch] = useState('');
  const [showNewGear, setShowNewGear] = useState(false);
  const [newGearName, setNewGearName] = useState('');
  const [newGearCat, setNewGearCat] = useState('other');

  const { data: gear = [], isLoading: gearLoading } = useQuery({
    queryKey: ['expeditionGear'],
    queryFn: () => base44.entities.UserGear.list('-created_date', 100),
    staleTime: 15000,
  });

  const { data: locations = [], isLoading: locLoading } = useQuery({
    queryKey: ['allRockhoundLocations'],
    queryFn: () => base44.entities.RockhoundingLocation.list('-created_date', 200),
    staleTime: 60000,
  });

  const linkMutation = useMutation({
    mutationFn: ({ gearId, locIds, locNames }) =>
      base44.entities.UserGear.update(gearId, {
        linked_location_ids: locIds,
        linked_location_names: locNames,
      }),
    onSuccess: () => {
      qc.invalidateQueries(['expeditionGear']);
      setLinkingGearId(null);
    },
  });

  const createGear = useMutation({
    mutationFn: () => base44.entities.UserGear.create({
      name: newGearName.trim(),
      category: newGearCat,
      linked_location_ids: [],
      linked_location_names: [],
    }),
    onSuccess: () => {
      qc.invalidateQueries(['expeditionGear']);
      setShowNewGear(false);
      setNewGearName('');
      setNewGearCat('other');
    },
  });

  const toggleLink = (gearItem, location) => {
    const existing = gearItem.linked_location_ids || [];
    const existingNames = gearItem.linked_location_names || [];
    let newIds, newNames;
    if (existing.includes(location.id)) {
      const idx = existing.indexOf(location.id);
      newIds = existing.filter(id => id !== location.id);
      newNames = existingNames.filter((_, i) => i !== idx);
    } else {
      newIds = [...existing, location.id];
      newNames = [...existingNames, location.name];
    }
    linkMutation.mutate({ gearId: gearItem.id, locIds: newIds, locNames: newNames });
  };

  const filteredLocations = (locations || []).filter(loc =>
    loc.name?.toLowerCase().includes(search.toLowerCase()) ||
    loc.state?.toLowerCase().includes(search.toLowerCase())
  );

  const linkingGear = gear.find(g => g.id === linkingGearId);

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Wrench className="w-4 h-4" style={{ color: '#F5B642' }} />
          <h3 className="text-sm font-bold text-white">Gear &amp; Location Links</h3>
        </div>
        <button
          onClick={() => setShowNewGear(!showNewGear)}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold"
          style={{ background: 'rgba(245,182,66,0.1)', border: '1px solid rgba(245,182,66,0.25)', color: '#F5B642' }}>
          <Plus className="w-3 h-3" /> Add Gear
        </button>
      </div>

      {showNewGear && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
          className="rounded-xl p-3 mb-3 space-y-2"
          style={{ background: 'rgba(245,182,66,0.04)', border: '1px solid rgba(245,182,66,0.15)' }}>
          <input
            value={newGearName}
            onChange={(e) => setNewGearName(e.target.value)}
            placeholder="Gear name (e.g. Estwing Rock Hammer)"
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-amber-400/40"
          />
          <select value={newGearCat} onChange={(e) => setNewGearCat(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400/40">
            {Object.entries(CATEGORY_LABELS).map(([val, label]) => (
              <option key={val} value={val} className="bg-slate-900">{label}</option>
            ))}
          </select>
          <button
            onClick={() => createGear.mutate()}
            disabled={!newGearName.trim() || createGear.isPending}
            className="w-full py-2.5 rounded-lg text-sm font-bold flex items-center justify-center gap-2 disabled:opacity-40"
            style={{ background: 'rgba(245,182,66,0.15)', border: '1px solid rgba(245,182,66,0.3)', color: '#F5B642' }}>
            {createGear.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Add to Gear List
          </button>
        </motion.div>
      )}

      {gearLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-white/30" />
        </div>
      )}

      {!gearLoading && gear.length === 0 && (
        <p className="text-xs text-white/30 text-center py-6">
          No gear logged yet. Add your tools to link them to collecting sites.
        </p>
      )}

      <div className="space-y-2">
        {gear.map((item) => (
          <div key={item.id}
            className="rounded-xl p-3"
            style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                  style={{ background: 'rgba(245,182,66,0.12)', color: '#F5B642' }}>
                  {CATEGORY_LABELS[item.category] || 'Other'}
                </span>
                <p className="text-sm font-semibold text-white">{item.name}</p>
              </div>
              <button
                onClick={() => setLinkingGearId(linkingGearId === item.id ? null : item.id)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold"
                style={{
                  background: linkingGearId === item.id ? 'rgba(122,231,255,0.15)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${linkingGearId === item.id ? 'rgba(122,231,255,0.3)' : 'rgba(255,255,255,0.08)'}`,
                  color: linkingGearId === item.id ? '#7AE7FF' : 'rgba(255,255,255,0.5)',
                }}>
                <MapPin className="w-3 h-3" /> {linkingGearId === item.id ? 'Done' : 'Link'}
              </button>
            </div>

            {/* Linked locations chips */}
            {(item.linked_location_names || []).length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {item.linked_location_names.map((name, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded-full"
                    style={{ background: 'rgba(0,214,143,0.08)', border: '1px solid rgba(0,214,143,0.2)', color: '#4AE5A8' }}>
                    {name}
                  </span>
                ))}
              </div>
            )}

            {item.linked_location_names?.length === 0 && (
              <p className="text-xs text-white/25 mt-1">No locations linked yet</p>
            )}
          </div>
        ))}
      </div>

      {/* Location picker modal */}
      <AnimatePresence>
        {linkingGear && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end"
            style={{ background: 'rgba(0,0,0,0.6)' }}
            onClick={() => setLinkingGearId(null)}>
            <motion.div
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 300 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md mx-auto rounded-t-3xl p-4 max-h-[75vh] flex flex-col"
              style={{ background: '#0E141B', border: '1px solid rgba(255,255,255,0.1)' }}>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm font-bold text-white">Link Locations</p>
                  <p className="text-xs text-white/40">{linkingGear.name}</p>
                </div>
                <button onClick={() => setLinkingGearId(null)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center"
                  style={{ background: 'rgba(255,255,255,0.05)' }} aria-label="Close">
                  <X className="w-4 h-4 text-white/50" />
                </button>
              </div>

              <div className="flex items-center gap-2 mb-3 rounded-xl px-3 py-2"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <Search className="w-4 h-4 text-white/30" />
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search locations…"
                  className="flex-1 bg-transparent text-sm text-white placeholder:text-white/25 focus:outline-none"
                />
              </div>

              <div className="flex-1 overflow-y-auto space-y-1.5">
                {locLoading && <Loader2 className="w-5 h-5 animate-spin text-white/30 mx-auto" />}
                {!locLoading && filteredLocations.length === 0 && (
                  <p className="text-xs text-white/30 text-center py-4">No locations found.</p>
                )}
                {filteredLocations.map((loc) => {
                  const linked = (linkingGear.linked_location_ids || []).includes(loc.id);
                  return (
                    <button key={loc.id}
                      onClick={() => toggleLink(linkingGear, loc)}
                      className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-left transition-all"
                      style={{
                        background: linked ? 'rgba(0,214,143,0.08)' : 'rgba(255,255,255,0.03)',
                        border: `1px solid ${linked ? 'rgba(0,214,143,0.3)' : 'rgba(255,255,255,0.06)'}`,
                      }}>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5" style={{ color: linked ? '#00D68F' : 'rgba(255,255,255,0.3)' }} />
                        <div>
                          <p className="text-sm text-white">{loc.name}</p>
                          {loc.state && <p className="text-xs text-white/40">{loc.state}</p>}
                        </div>
                      </div>
                      {linked && <Check className="w-4 h-4" style={{ color: '#00D68F' }} />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}