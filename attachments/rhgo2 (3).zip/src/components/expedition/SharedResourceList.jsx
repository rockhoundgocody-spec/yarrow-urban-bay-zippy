/**
 * SharedResourceList
 * Communal equipment list for group expeditions.
 * Members can claim responsibility for bringing items.
 */
import React, { useState } from "react";
import { Package, Plus, User, X } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const DEFAULT_RESOURCES = [
  { id: "camp_stove", item: "Camp stove + fuel", category: "cooking", quantity: 1 },
  { id: "water_filter", item: "Water filter / purifier", category: "safety", quantity: 1 },
  { id: "rope", item: "50ft utility rope", category: "gear", quantity: 1 },
  { id: "tarp", item: "Emergency tarp", category: "shelter", quantity: 1 },
  { id: "rock_hammer", item: "Rock hammer", category: "tools", quantity: 2 },
  { id: "chisels", item: "Cold chisels set", category: "tools", quantity: 1 },
  { id: "safety_glasses", item: "Safety glasses (per person)", category: "safety", quantity: 0 },
  { id: "gps", item: "GPS device", category: "navigation", quantity: 1 },
  { id: "specimen_bags", item: "Specimen bags (50+)", category: "tools", quantity: 1 },
  { id: "field_guides", item: "Field guide books", category: "reference", quantity: 1 },
];

const CAT_COLORS = {
  cooking: "#F5B642",
  safety: "#ef4444",
  gear: "#00D68F",
  shelter: "#8D7CFF",
  tools: "#7AE7FF",
  navigation: "#00D68F",
  reference: "#F5B642",
};

export default function SharedResourceList({ resources = [], currentUserEmail, currentUserDisplay, onClaim, onRelease, onAdd }) {
  const [newItem, setNewItem] = useState("");
  const [showAdd, setShowAdd] = useState(false);

  const merged = DEFAULT_RESOURCES.map((def) => {
    const saved = resources.find((r) => r.id === def.id);
    return saved ? { ...def, ...saved } : def;
  });
  // Append any custom items
  const customItems = resources.filter((r) => !DEFAULT_RESOURCES.find((d) => d.id === r.id));
  const allItems = [...merged, ...customItems];

  const handleAdd = () => {
    if (!newItem.trim()) return;
    onAdd?.({ id: `custom_${Date.now()}`, item: newItem.trim(), category: "gear", quantity: 1 });
    setNewItem("");
    setShowAdd(false);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2 mb-3">
        <Package className="w-4 h-4 text-cyan-400" />
        <span className="text-sm font-semibold text-white/80">Shared Equipment</span>
        <span className="text-xs text-white/30 ml-auto">
          {allItems.filter((i) => i.claimed_by).length}/{allItems.length} claimed
        </span>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg transition-all"
          style={{ background: "rgba(0,214,143,0.1)", border: "1px solid rgba(0,214,143,0.2)", color: "#00D68F" }}
        >
          <Plus className="w-3 h-3" /> Add
        </button>
      </div>

      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="flex gap-2 mb-2"
          >
            <input
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAdd()}
              placeholder="Item name…"
              className="flex-1 px-3 py-2 rounded-xl text-sm text-white placeholder-white/25 outline-none"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
            />
            <button
              onClick={handleAdd}
              className="px-3 py-2 rounded-xl text-xs font-semibold"
              style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.3)", color: "#00D68F" }}
            >
              Add
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {allItems.map((item, idx) => {
        const isMine = item.claimed_by === currentUserEmail;
        const isClaimed = !!item.claimed_by;
        const catColor = CAT_COLORS[item.category] || "#fff";

        return (
          <motion.div
            key={item.id}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl"
            style={{
              background: isMine ? "rgba(0,214,143,0.06)" : isClaimed ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.025)",
              border: `1px solid ${isMine ? "rgba(0,214,143,0.2)" : isClaimed ? "rgba(255,255,255,0.07)" : "rgba(255,255,255,0.05)"}`,
            }}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.025 }}
          >
            <div className="flex-1 min-w-0">
              <div className="text-sm text-white/80 leading-tight truncate">{item.item}</div>
              {item.quantity > 0 && (
                <div className="text-[10px] text-white/30 mt-0.5">Qty: {item.quantity}</div>
              )}
            </div>

            <div
              className="text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wide flex-shrink-0"
              style={{ background: `${catColor}12`, color: catColor }}
            >
              {item.category}
            </div>

            {isClaimed ? (
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <User style={{ width: 11, height: 11, color: isMine ? "#00D68F" : "rgba(255,255,255,0.3)" }} />
                <span className="text-xs" style={{ color: isMine ? "#00D68F" : "rgba(255,255,255,0.4)" }}>
                  {isMine ? "You" : item.claimed_display || item.claimed_by?.split("@")[0]}
                </span>
                {isMine && (
                  <button
                    onClick={() => onRelease?.(item.id)}
                    className="ml-1 text-white/25 hover:text-red-400 transition-colors"
                   aria-label="Delete">
                    <X style={{ width: 11, height: 11 }} />
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={() => onClaim?.(item.id)}
                className="flex-shrink-0 text-xs px-2 py-1 rounded-lg transition-all"
                style={{ background: "rgba(122,231,255,0.08)", border: "1px solid rgba(122,231,255,0.18)", color: "#7AE7FF" }}
              >
                Claim
              </button>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}