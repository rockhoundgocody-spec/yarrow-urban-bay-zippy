import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  const collected = payload.find(p => p.dataKey === 'collected')?.value ?? 0;
  const goal = payload.find(p => p.dataKey === 'goal')?.value ?? 0;
  const achieved = goal > 0 && collected >= goal;
  return (
    <div style={{
      background: 'rgba(10,15,20,0.95)',
      border: `1px solid ${achieved ? 'rgba(0,214,143,0.4)' : 'rgba(122,231,255,0.25)'}`,
      borderRadius: 10,
      padding: '8px 12px',
    }}>
      <p className="text-xs font-bold text-white mb-1 truncate max-w-[140px]">{label}</p>
      <p className="text-xs" style={{ color: '#00D68F' }}>Collected: <strong>{collected}</strong></p>
      <p className="text-xs" style={{ color: '#7AE7FF' }}>Goal: <strong>{goal || '—'}</strong></p>
      {goal > 0 && (
        <p className="text-[10px] mt-1 font-semibold" style={{ color: achieved ? '#F5B642' : 'rgba(255,255,255,0.4)' }}>
          {achieved ? '🏆 Goal reached!' : `${Math.round((collected / goal) * 100)}% complete`}
        </p>
      )}
    </div>
  );
};

export default function TripMineralBarChart({ tripProgress }) {
  if (!tripProgress?.length) return null;

  const data = tripProgress.map(t => ({
    name: t.name.length > 10 ? t.name.slice(0, 10) + '…' : t.name,
    fullName: t.name,
    collected: t.collected,
    goal: t.goal || 0,
    achieved: t.achieved,
  }));

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center gap-2 mb-4">
        <span className="text-sm font-bold text-white">Minerals vs. Goal by Trip</span>
        <span className="ml-auto flex items-center gap-3 text-[10px] font-semibold">
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm" style={{ background: '#00D68F' }} />
            <span style={{ color: 'rgba(255,255,255,0.5)' }}>Collected</span>
          </span>
          <span className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 rounded-sm" style={{ background: 'rgba(122,231,255,0.4)' }} />
            <span style={{ color: 'rgba(255,255,255,0.5)' }}>Goal</span>
          </span>
        </span>
      </div>

      <ResponsiveContainer width="100%" height={180}>
        <BarChart data={data} barCategoryGap="28%" barGap={3}>
          <CartesianGrid vertical={false} stroke="rgba(255,255,255,0.05)" />
          <XAxis
            dataKey="name"
            tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }}
            axisLine={false}
            tickLine={false}
          />
          <YAxis
            tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            width={24}
            allowDecimals={false}
          />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.04)' }} />
          <Bar dataKey="goal" radius={[4, 4, 0, 0]} fill="rgba(122,231,255,0.25)" />
          <Bar dataKey="collected" radius={[4, 4, 0, 0]}>
            {data.map((entry, i) => (
              <Cell
                key={i}
                fill={entry.achieved
                  ? 'url(#achievedGradient)'
                  : entry.collected > 0 ? '#00D68F' : 'rgba(0,214,143,0.25)'}
              />
            ))}
          </Bar>
          <defs>
            <linearGradient id="achievedGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F5B642" />
              <stop offset="100%" stopColor="#00D68F" />
            </linearGradient>
          </defs>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}