import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ClipboardList, Check, Loader2, Plus } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

const CATEGORY_LABELS = {
  hammer: 'Hammer', chisel: 'Chisel', uv_light: 'UV Light', magnifier: 'Magnifier',
  safety: 'Safety', bag: 'Bag', pick: 'Pick', screen: 'Screen', other: 'Other',
};

const CATEGORY_COLORS = {
  hammer: '#F5B642', chisel: '#F5B642', uv_light: '#8D7CFF', magnifier: '#7AE7FF',
  safety: '#ff3366', bag: '#00D68F', pick: '#F5B642', screen: '#7AE7FF', other: '#6E7681',
};

function isUpcoming(trip) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const end = trip.end_date ? new Date(trip.end_date) : new Date(trip.start_date);
  end.setHours(23, 59, 59, 999);
  return end >= today;
}

export default function TripGearChecklist() {
  const qc = useQueryClient();
  const [selectedTripId, setSelectedTripId] = useState(null);
  const [newItem, setNewItem] = useState('');
  const [newCat, setNewCat] = useState('other');

  const { data: trips = [], isLoading } = useQuery({
    queryKey: ['expeditionTrips'],
    queryFn: () => base44.entities.ItineraryPlan.list('-start_date', 50),
    staleTime: 15000,
  });

  const upcoming = useMemo(() => trips.filter(isUpcoming), [trips]);

  const activeTripId = selectedTripId || upcoming[0]?.id || null;
  const activeTrip = upcoming.find(t => t.id === activeTripId);

  const checklist = activeTrip?.gear_checklist || [];
  const checkedCount = checklist.filter(g => g.checked).length;
  const totalCount = checklist.length;
  const progress = totalCount > 0 ? Math.round((checkedCount / totalCount) * 100) : 0;
  const allReady = totalCount > 0 && checkedCount === totalCount;

  const updateChecklist = useMutation({
    mutationFn: ({ tripId, gear_checklist }) =>
      base44.entities.ItineraryPlan.update(tripId, { gear_checklist }),
    onSuccess: () => qc.invalidateQueries(['expeditionTrips']),
  });

  const toggleChecked = (idx) => {
    const next = checklist.map((g, i) => i === idx ? { ...g, checked: !g.checked } : g);
    updateChecklist.mutate({ tripId: activeTrip.id, gear_checklist: next });
  };

  const addItem = () => {
    if (!newItem.trim() || !activeTrip) return;
    const next = [...checklist, { item: newItem.trim(), category: newCat, checked: false }];
    updateChecklist.mutate(
      { tripId: activeTrip.id, gear_checklist: next },
      { onSuccess: () => { setNewItem(''); setNewCat('other'); } }
    );
  };

  const removeItem = (idx) => {
    const next = checklist.filter((_, i) => i !== idx);
    updateChecklist.mutate({ tripId: activeTrip.id, gear_checklist: next });
  };

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center gap-2 mb-3">
        <ClipboardList className="w-4 h-4" style={{ color: '#7AE7FF' }} />
        <h3 className="text-sm font-bold text-white">Trip Gear Checklist</h3>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-white/30" />
        </div>
      )}

      {!isLoading && upcoming.length === 0 && (
        <p className="text-xs text-white/30 text-center py-6">
          No upcoming trips. Create one in Expedition Dates to start a gear checklist.
        </p>
      )}

      {upcoming.length > 0 && (
        <>
          <div className="flex gap-2 overflow-x-auto pb-2 mb-3 -mx-1 px-1">
            {upcoming.map((trip) => {
              const active = trip.id === activeTripId;
              const list = trip.gear_checklist || [];
              const pct = list.length > 0
                ? Math.round((list.filter(g => g.checked).length / list.length) * 100)
                : 0;
              return (
                <button
                  key={trip.id}
                  onClick={() => setSelectedTripId(trip.id)}
                  className="flex-shrink-0 px-3 py-2 rounded-xl text-left transition-all"
                  style={{
                    background: active ? 'rgba(122,231,255,0.12)' : 'rgba(255,255,255,0.03)',
                    border: `1px solid ${active ? 'rgba(122,231,255,0.4)' : 'rgba(255,255,255,0.06)'}`,
                  }}>
                  <p className="text-xs font-bold whitespace-nowrap" style={{ color: active ? '#7AE7FF' : 'rgba(255,255,255,0.7)' }}>
                    {trip.name}
                  </p>
                  <p className="text-[10px]" style={{ color: active ? 'rgba(122,231,255,0.6)' : 'rgba(255,255,255,0.3)' }}>
                    {trip.start_date} · {pct}% ready
                  </p>
                </button>
              );
            })}
          </div>

          {activeTrip && (
            <>
              <div className="mb-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-semibold" style={{ color: allReady ? '#00D68F' : 'rgba(255,255,255,0.6)' }}>
                    {allReady ? '✓ All gear ready!' : `${checkedCount} of ${totalCount} packed`}
                  </span>
                  <span className="text-xs font-black" style={{ color: allReady ? '#00D68F' : '#7AE7FF' }}>
                    {progress}%
                  </span>
                </div>
                <div className="w-full h-2.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.4, ease: 'easeOut' }}
                    className="h-full rounded-full"
                    style={{
                      background: allReady
                        ? 'linear-gradient(90deg, #00D68F, #F5B642)'
                        : 'linear-gradient(90deg, #7AE7FF, #00D68F)',
                    }}
                  />
                </div>
              </div>

              <div className="space-y-1.5 mb-3">
                {checklist.length === 0 && (
                  <p className="text-xs text-white/30 text-center py-4">
                    No gear added yet. Add items below to build your packing list.
                  </p>
                )}
                {checklist.map((g, idx) => {
                  const color = CATEGORY_COLORS[g.category] || '#6E7681';
                  return (
                    <div key={idx}
                      className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 group"
                      style={{
                        background: g.checked ? 'rgba(0,214,143,0.06)' : 'rgba(255,255,255,0.03)',
                        border: `1px solid ${g.checked ? 'rgba(0,214,143,0.25)' : 'rgba(255,255,255,0.06)'}`,
                      }}>
                      <button
                        onClick={() => toggleChecked(idx)}
                        disabled={updateChecklist.isPending}
                        className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 transition-all"
                        style={{
                          background: g.checked ? 'rgba(0,214,143,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1.5px solid ${g.checked ? '#00D68F' : 'rgba(255,255,255,0.2)'}`,
                        }}>
                        {g.checked && <Check className="w-3.5 h-3.5" style={{ color: '#00D68F' }} />}
                      </button>
                      <span className="text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                        style={{ background: `${color}1f`, color }}>
                        {CATEGORY_LABELS[g.category] || 'Other'}
                      </span>
                      <p className="text-sm flex-1" style={{
                        color: g.checked ? 'rgba(255,255,255,0.4)' : '#fff',
                        textDecoration: g.checked ? 'line-through' : 'none',
                      }}>
                        {g.item}
                      </p>
                      <button
                        onClick={() => removeItem(idx)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-white/30 hover:text-red-400 text-xs px-1" aria-label="Remove">
                        ✕
                      </button>
                    </div>
                  );
                })}
              </div>

              <div className="flex gap-2">
                <input
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addItem()}
                  placeholder="Add gear item (e.g. Rock hammer)"
                  className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm text-white placeholder:text-white/25 focus:outline-none focus:border-cyan-400/40"
                />
                <select value={newCat} onChange={(e) => setNewCat(e.target.value)}
                  className="bg-white/5 border border-white/10 rounded-lg px-2 py-2 text-xs text-white focus:outline-none focus:border-cyan-400/40">
                  {Object.entries(CATEGORY_LABELS).map(([val, label]) => (
                    <option key={val} value={val} className="bg-slate-900">{label}</option>
                  ))}
                </select>
                <button
                  onClick={addItem}
                  disabled={!newItem.trim() || updateChecklist.isPending}
                  className="px-3 py-2 rounded-lg flex items-center justify-center disabled:opacity-40"
                  style={{ background: 'rgba(122,231,255,0.12)', border: '1px solid rgba(122,231,255,0.3)', color: '#7AE7FF' }}>
                  {updateChecklist.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                </button>
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}