import React, { useState } from 'react';
import { Share2, Instagram, Copy, Check } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

/**
 * ExpeditionShareButton — composes a shareable Instagram caption from
 * the user's latest finds + active field goals, then triggers the native
 * Web Share sheet (shows Instagram as an option on iOS/Android) or
 * copies to clipboard as a fallback.
 */
export default function ExpeditionShareButton() {
  const [copied, setCopied] = useState(false);
  const [sharing, setSharing] = useState(false);

  const { data: goals = [] } = useQuery({
    queryKey: ['fieldGoals'],
    queryFn: () => base44.entities.PersonalGoal.list('-created_date', 10),
    staleTime: 30000,
  });

  const { data: finds = [] } = useQuery({
    queryKey: ['recentFindings'],
    queryFn: () => base44.entities.Finding.list('-created_date', 5),
    staleTime: 30000,
  });

  function buildCaption() {
    const activeGoals = goals.filter(g => g.status === 'active');
    const achievedGoals = goals.filter(g => g.status === 'achieved');

    const findLines = finds
      .filter(f => f.identified_mineral_name)
      .slice(0, 4)
      .map(f => `💎 ${f.identified_mineral_name}${f.site_name ? ` @ ${f.site_name}` : ''}`)
      .join('\n');

    const goalLines = activeGoals.slice(0, 2).map(g => {
      const pct = Math.round(((g.current_value || 0) / (g.target_value || 1)) * 100);
      return `🎯 ${g.title} — ${pct}%`;
    }).join('\n');

    const achievedLines = achievedGoals.slice(0, 2).map(g => `🏆 ${g.title}`).join('\n');

    const sections = [];
    if (findLines) sections.push(`Latest finds:\n${findLines}`);
    if (goalLines) sections.push(`Field goals:\n${goalLines}`);
    if (achievedLines) sections.push(`Achieved:\n${achievedLines}`);

    if (sections.length === 0) {
      sections.push('Out in the field, hunting for gems and minerals! 🪨✨');
    }

    return `${sections.join('\n\n')}\n\n#RockHoundGO #Rockhounding #MineralHunting #Geology #Crystals`;
  }

  async function handleShare() {
    const caption = buildCaption();
    setSharing(true);
    try {
      if (navigator.share) {
        await navigator.share({
          title: 'My RockHound-GO Expedition',
          text: caption,
          url: 'https://rockhound-go.app',
        });
      } else {
        await navigator.clipboard.writeText(caption);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }
    } catch {
      // user cancelled or clipboard failed — try clipboard fallback
      try {
        await navigator.clipboard.writeText(caption);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      } catch { /* silent */ }
    }
    setSharing(false);
  }

  return (
    <div
      className="rounded-2xl p-4"
      style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Instagram className="w-4 h-4" style={{ color: '#E1306C' }} />
        <h3 className="text-sm font-bold text-white">Share to Instagram</h3>
      </div>

      <p className="text-xs text-white/40 mb-3 leading-relaxed">
        Share your latest mineral finds and expedition progress. Tap below to open the share sheet — select Instagram from the options.
      </p>

      <button
        onClick={handleShare}
        disabled={sharing}
        className="w-full py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
        style={{
          background: 'linear-gradient(135deg, rgba(225,48,108,0.20) 0%, rgba(130,58,180,0.18) 100%)',
          border: '1px solid rgba(225,48,108,0.4)',
          color: '#F472B6',
        }}
      >
        {copied ? (
          <><Check className="w-4 h-4 text-emerald-400" /><span style={{ color: '#00D68F' }}>Caption copied!</span></>
        ) : (
          <><Share2 className="w-4 h-4" /> Share Expedition Progress</>
        )}
      </button>

      {!navigator.share && !copied && (
        <p className="text-[10px] text-white/25 text-center mt-2 flex items-center justify-center gap-1">
          <Copy className="w-3 h-3" /> Caption will be copied — paste it into Instagram
        </p>
      )}
    </div>
  );
}