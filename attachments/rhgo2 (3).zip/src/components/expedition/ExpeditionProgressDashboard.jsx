import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Loader2, Target, Gem, Calendar, TrendingUp } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import TripMineralBarChart from './TripMineralBarChart';

/**
 * ExpeditionProgressDashboard — summary of mineral collection progress
 * per trip. Counts Finding records whose finding_date falls within each
 * trip's date range, compared against the trip's mineral_goal.
 */
export default function ExpeditionProgressDashboard() {
  const qc = useQueryClient();
  const [editingGoal, setEditingGoal] = useState(null);
  const [goalDraft, setGoalDraft] = useState('');

  const { data: trips = [], isLoading: tripsLoading } = useQuery({
    queryKey: ['expeditionTrips'],
    queryFn: () => base44.entities.ItineraryPlan.list('-start_date', 100),
    staleTime: 15000,
  });

  const { data: findings = [], isLoading: findingsLoading } = useQuery({
    queryKey: ['expeditionFindings'],
    queryFn: () => base44.entities.Finding.list('-created_date', 500),
    staleTime: 30000,
  });

  const dateStr = (f) => f.finding_date || (f.created_date ? f.created_date.slice(0, 10) : '');

  const inRange = (d, start, end) => {
    if (!d) return false;
    if (d < start) return false;
    if (end && d > end) return false;
    if (!end && d > start) return true;
    return true;
  };

  const tripProgress = useMemo(() => {
    return trips.map((trip) => {
      const collected = findings.filter(f => inRange(dateStr(f), trip.start_date, trip.end_date)).length;
      const goal = trip.mineral_goal || 0;
      const pct = goal > 0 ? Math.min(100, Math.round((collected / goal) * 100)) : (collected > 0 ? 100 : 0);
      const achieved = goal > 0 && collected >= goal;
      return { ...trip, collected, goal, pct, achieved };
    });
  }, [trips, findings]);

  const totals = useMemo(() => {
    const totalCollected = tripProgress.reduce((s, t) => s + t.collected, 0);
    const totalGoal = tripProgress.reduce((s, t) => s + t.goal, 0);
    const overallPct = totalGoal > 0 ? Math.min(100, Math.round((totalCollected / totalGoal) * 100)) : 0;
    const achievedCount = tripProgress.filter(t => t.achieved).length;
    return { totalCollected, totalGoal, overallPct, achievedCount, tripCount: tripProgress.length };
  }, [tripProgress]);

  const updateGoal = useMutation({
    mutationFn: ({ tripId, mineral_goal }) =>
      base44.entities.ItineraryPlan.update(tripId, { mineral_goal }),
    onSuccess: () => {
      qc.invalidateQueries(['expeditionTrips']);
      setEditingGoal(null);
    },
  });

  const saveGoal = (tripId) => {
    const val = parseInt(goalDraft, 10);
    if (isNaN(val) || val < 0) { setEditingGoal(null); return; }
    updateGoal.mutate({ tripId, mineral_goal: val });
  };

  const startEdit = (trip) => {
    setEditingGoal(trip.id);
    setGoalDraft(String(trip.mineral_goal || 0));
  };

  const loading = tripsLoading || findingsLoading;

  return (
    <div className="rounded-2xl p-4" style={{ background: 'rgba(14,20,27,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="w-4 h-4" style={{ color: '#F5B642' }} />
        <h3 className="text-sm font-bold text-white">Expedition Progress</h3>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-6">
          <Loader2 className="w-5 h-5 animate-spin text-white/30" />
        </div>
      )}

      {!loading && trips.length === 0 && (
        <p className="text-xs text-white/30 text-center py-6">
          No trips yet. Create one in Expedition Dates to track collection progress.
        </p>
      )}

      {!loading && trips.length > 0 && (
        <>
          {/* Summary header */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            <StatCard icon={Gem} label="Collected" value={totals.totalCollected} color="#00D68F" />
            <StatCard icon={Target} label="Goal" value={totals.totalGoal} color="#7AE7FF" />
            <StatCard icon={Trophy} label="Trips Won" value={totals.achievedCount} color="#F5B642" />
          </div>

          {totals.totalGoal > 0 && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-semibold text-white/60 flex items-center gap-1">
                  <TrendingUp className="w-3 h-3" /> Overall Progress
                </span>
                <span className="text-xs font-black" style={{ color: '#F5B642' }}>{totals.overallPct}%</span>
              </div>
              <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${totals.overallPct}%` }}
                  transition={{ duration: 0.5, ease: 'easeOut' }}
                  className="h-full rounded-full"
                  style={{ background: 'linear-gradient(90deg, #00D68F, #F5B642)' }}
                />
              </div>
            </div>
          )}

          {/* Bar chart — collected vs goal per trip */}
          <TripMineralBarChart tripProgress={tripProgress} />

          {/* Per-trip progress */}
          <div className="space-y-2.5">
            {tripProgress.map((trip) => (
              <TripProgressCard
                key={trip.id}
                trip={trip}
                editingGoal={editingGoal}
                goalDraft={goalDraft}
                setGoalDraft={setGoalDraft}
                startEdit={startEdit}
                saveGoal={saveGoal}
                setEditingGoal={setEditingGoal}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function TripProgressCard({
  trip,
  editingGoal,
  goalDraft,
  setGoalDraft,
  startEdit,
  saveGoal,
  setEditingGoal,
}) {
  return (
    <div
      className="rounded-xl p-3"
      style={{
        background: trip.achieved ? 'rgba(0,214,143,0.05)' : 'rgba(255,255,255,0.03)',
        border: `1px solid ${trip.achieved ? 'rgba(0,214,143,0.25)' : 'rgba(255,255,255,0.06)'}`,
      }}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="text-sm font-bold text-white truncate">{trip.name}</p>
            {trip.achieved && <Trophy className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#F5B642' }} />}
          </div>
          <p className="text-[10px] flex items-center gap-1 mt-0.5" style={{ color: 'rgba(255,255,255,0.4)' }}>
            <Calendar className="w-2.5 h-2.5" />
            {trip.start_date}{trip.end_date ? ` → ${trip.end_date}` : ''}
          </p>
        </div>
        {/* Collected / Goal */}
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <span className="text-lg font-black" style={{ color: trip.achieved ? '#00D68F' : '#fff' }}>
            {trip.collected}
          </span>
          <span className="text-xs" style={{ color: 'rgba(255,255,255,0.3)' }}>/</span>
          {editingGoal === trip.id ? (
            <input
              autoFocus
              type="number"
              value={goalDraft}
              onChange={(e) => setGoalDraft(e.target.value)}
              onBlur={() => saveGoal(trip.id)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveGoal(trip.id);
                if (e.key === 'Escape') setEditingGoal(null);
              }}
              className="w-12 bg-white/5 border border-cyan-400/40 rounded px-1 py-0.5 text-sm text-white text-center focus:outline-none"
            />
          ) : (
            <button
              onClick={() => startEdit(trip)}
              className="text-sm font-bold px-1.5 py-0.5 rounded transition-colors hover:bg-white/5"
              style={{ color: trip.goal > 0 ? '#7AE7FF' : 'rgba(255,255,255,0.25)' }}
              title="Click to set goal"
            >
              {trip.goal || '—'}
            </button>
          )}
        </div>
      </div>

      {/* Progress bar */}
      {trip.goal > 0 && (
        <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${trip.pct}%` }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="h-full rounded-full"
            style={{
              background: trip.achieved
                ? 'linear-gradient(90deg, #00D68F, #F5B642)'
                : 'linear-gradient(90deg, #7AE7FF, #00D68F)',
            }}
          />
        </div>
      )}
      {trip.goal === 0 && (
        <p className="text-[10px]" style={{ color: 'rgba(255,255,255,0.3)' }}>
          Tap the goal number to set a collection target
        </p>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div className="rounded-xl p-2.5 text-center"
      style={{ background: `${color}0d`, border: `1px solid ${color}22` }}>
      <Icon className="w-3.5 h-3.5 mx-auto mb-1" style={{ color }} />
      <p className="text-lg font-black" style={{ color }}>{value}</p>
      <p className="text-[9px] uppercase tracking-wider font-semibold" style={{ color: 'rgba(255,255,255,0.4)' }}>{label}</p>
    </div>
  );
}