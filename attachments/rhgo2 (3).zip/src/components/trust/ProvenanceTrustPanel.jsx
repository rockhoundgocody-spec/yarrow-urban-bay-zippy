/**
 * ProvenanceTrustPanel — reusable trust/provenance/legality/risk panel.
 * Appears on: specimen detail, listing detail, scan result, site detail.
 *
 * Props:
 *  provenanceStatus  "unknown"|"self-collected"|"seller-claimed"|"documented"|"verified"
 *  legalityStatus    "open"|"permit"|"restricted"|"unknown"
 *  riskLevel         "low"|"moderate"|"high"|"unknown"
 *  localityName      string
 *  collectedBy       string
 *  acquiredFrom      string
 *  notes             string
 *  compact           boolean — chip-row only, no expanded panel
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, ShieldAlert, Shield, AlertTriangle, MapPin, ChevronDown, ChevronUp, User, Store } from "lucide-react";

const PROVENANCE = {
  verified:         { color: "#00FFC6", bg: "rgba(0,255,198,0.09)",   border: "rgba(0,255,198,0.28)",  label: "Verified",         icon: ShieldCheck },
  documented:       { color: "#7DF9FF", bg: "rgba(125,249,255,0.09)", border: "rgba(125,249,255,0.25)", label: "Documented",       icon: Shield },
  "self-collected": { color: "#B97AFF", bg: "rgba(185,122,255,0.09)", border: "rgba(185,122,255,0.25)", label: "Self-Collected",   icon: ShieldCheck },
  "seller-claimed": { color: "#FFD700", bg: "rgba(255,215,0,0.09)",   border: "rgba(255,215,0,0.25)",  label: "Seller-Claimed",   icon: ShieldAlert },
  unknown:          { color: "rgba(255,255,255,0.35)", bg: "rgba(255,255,255,0.04)", border: "rgba(255,255,255,0.10)", label: "Unknown", icon: Shield },
};

const LEGALITY = {
  open:       { color: "#00FFC6", label: "Open Access",       icon: ShieldCheck },
  permit:     { color: "#FFD700", label: "Permit Required",   icon: ShieldAlert },
  restricted: { color: "#FF7A59", label: "Restricted",        icon: AlertTriangle },
  unknown:    { color: "rgba(255,255,255,0.3)", label: "Access Unverified", icon: Shield },
};

const RISK = {
  low:      { color: "#00FFC6", label: "Low Risk" },
  moderate: { color: "#FFD700", label: "Moderate Risk" },
  high:     { color: "#FF7A59", label: "High Risk" },
  unknown:  { color: "rgba(255,255,255,0.25)", label: "Risk Unknown" },
};

function TrustChip({ config, label }) {
  const Icon = config.icon;
  return (
    <div
      className="flex items-center gap-1.5 rounded-full px-2.5 py-1"
      style={{ background: config.bg, border: `1px solid ${config.border || config.color + "28"}` }}
    >
      {Icon && <Icon className="h-3 w-3 shrink-0" style={{ color: config.color }} />}
      <span className="text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: config.color }}>
        {label || config.label}
      </span>
    </div>
  );
}

export default function ProvenanceTrustPanel({
  provenanceStatus = "unknown",
  legalityStatus = "unknown",
  riskLevel = "unknown",
  localityName,
  collectedBy,
  acquiredFrom,
  notes,
  compact = false,
}) {
  const [expanded, setExpanded] = useState(false);
  const prov  = PROVENANCE[provenanceStatus] || PROVENANCE.unknown;
  const legal = LEGALITY[legalityStatus]     || LEGALITY.unknown;
  const risk  = RISK[riskLevel]              || RISK.unknown;
  const LegalIcon = legal.icon;

  if (compact) {
    return (
      <div className="flex flex-wrap gap-1.5">
        <TrustChip config={prov} />
        <TrustChip config={{ ...legal, bg: `${legal.color}10`, border: `${legal.color}28` }} />
      </div>
    );
  }

  return (
    <div
      className="overflow-hidden rounded-[22px]"
      style={{ background: "rgba(5,7,10,0.90)", border: "1px solid rgba(255,255,255,0.08)" }}
    >
      {/* Header */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center justify-between px-4 py-3.5"
      >
        <div className="flex flex-wrap gap-2 items-center">
          <TrustChip config={prov} />
          <TrustChip config={{ ...legal, bg: `${legal.color}10`, border: `${legal.color}28` }} />
          {riskLevel !== "unknown" && (
            <div
              className="flex items-center gap-1 rounded-full px-2 py-1"
              style={{ background: `${risk.color}08`, border: `1px solid ${risk.color}20` }}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: risk.color }} />
              <span className="text-[10px] font-bold" style={{ color: risk.color }}>{risk.label}</span>
            </div>
          )}
        </div>
        <div className="text-white/25 ml-2">
          {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </div>
      </button>

      {/* Expanded detail */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="overflow-hidden border-t border-white/[0.06]"
          >
            <div className="px-4 py-3 space-y-2">
              {localityName && (
                <div className="flex items-center gap-2 text-xs text-white/55">
                  <MapPin className="h-3 w-3 shrink-0 text-white/25" />
                  <span>Locality: <span className="text-white/75">{localityName}</span></span>
                </div>
              )}
              {collectedBy && (
                <div className="flex items-center gap-2 text-xs text-white/55">
                  <User className="h-3 w-3 shrink-0 text-white/25" />
                  <span>Collected by: <span className="text-white/75">{collectedBy}</span></span>
                </div>
              )}
              {acquiredFrom && (
                <div className="flex items-center gap-2 text-xs text-white/55">
                  <Store className="h-3 w-3 shrink-0 text-white/25" />
                  <span>Acquired from: <span className="text-white/75">{acquiredFrom}</span></span>
                </div>
              )}
              {notes && (
                <div className="mt-1 rounded-xl px-3 py-2 text-xs text-white/45 leading-5"
                  style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                  {notes}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}