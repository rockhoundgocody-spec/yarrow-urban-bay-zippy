/**
 * BadgeGallery: "My Badges" collection screen UI with high-fidelity 3D medallions.
 * Features:
 * - Search bar & Rarity filtering (All, Common, Uncommon, Rare, Epic, Legendary, Mythic)
 * - Category filter tabs
 * - Stats overview banner (earned, total XP, completion %)
 * - AR Glow view toggle & Material Breakdown modal viewer
 * - Interactive unlock sequence replay
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Search, Filter, Eye, Layers, Play, CheckCircle2, Lock } from 'lucide-react';
import MineralEmblemBadge from './MineralEmblemBadge';
import BadgeUnlockAnimation from './BadgeUnlockAnimation';
import MaterialBreakdownModal from './MaterialBreakdownModal';
import { getAllBadges, BADGE_RARITY_COLORS } from '@/services/rewards/badgeDefinitions';

const CATEGORIES = ['All', 'Discovery', 'Exploration', 'Collection', 'Accuracy', 'Social', 'Streaks'];
const RARITIES = ['All', 'common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic'];

export default function BadgeGallery({ userBadges = [], isLoading = false }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedRarity, setSelectedRarity] = useState('All');
  const [isArGlowMode, setIsArGlowMode] = useState(false);
  const [themeMode, setThemeMode] = useState('dark'); // 'dark' | 'light'

  const [selectedBadgeForBreakdown, setSelectedBadgeForBreakdown] = useState(null);
  const [replayBadgeId, setReplayBadgeId] = useState(null);

  const allBadges = getAllBadges();

  // Set of user's unlocked badge IDs
  const unlockedSet = useMemo(() => {
    // Standard mock or unlocked badges
    const defaultUnlocked = new Set(['crystal_whisperer', 'trailblazer', 'sharp_eye', 'shared_adventure']);
    userBadges.forEach((b) => defaultUnlocked.add(b.badge_id || b.id));
    return defaultUnlocked;
  }, [userBadges]);

  // Filtered badge list
  const filteredBadges = useMemo(() => {
    return allBadges.filter((badge) => {
      const matchesSearch =
        badge.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        badge.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory =
        selectedCategory === 'All' || badge.category.toLowerCase() === selectedCategory.toLowerCase();
      const matchesRarity =
        selectedRarity === 'All' || badge.rarity.toLowerCase() === selectedRarity.toLowerCase();

      return matchesSearch && matchesCategory && matchesRarity;
    });
  }, [allBadges, searchTerm, selectedCategory, selectedRarity]);

  const unlockedCount = allBadges.filter((b) => unlockedSet.has(b.id)).length;
  const totalXP = allBadges.reduce(
    (sum, b) => (unlockedSet.has(b.id) ? sum + (b.xp_reward || 0) : sum),
    0
  );
  const completionPct = Math.round((unlockedCount / allBadges.length) * 100);

  return (
    <div className="w-full space-y-6 text-white">
      {/* Unlock Sequence Modal Replay Overlay */}
      {replayBadgeId && (
        <BadgeUnlockAnimation
          badgeId={replayBadgeId}
          visible={!!replayBadgeId}
          onDismiss={() => setReplayBadgeId(null)}
          onComplete={() => {}}
        />
      )}

      {/* Material Breakdown Modal */}
      {selectedBadgeForBreakdown && (
        <MaterialBreakdownModal
          badgeId={selectedBadgeForBreakdown}
          isOpen={!!selectedBadgeForBreakdown}
          onClose={() => setSelectedBadgeForBreakdown(null)}
        />
      )}

      {/* Stats Summary Banner */}
      <div
        className="p-6 rounded-3xl border relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, rgba(26,11,46,0.9) 0%, rgba(13,15,29,0.95) 100%)',
          borderColor: 'rgba(212, 175, 55, 0.25)',
          boxShadow: '0 0 40px rgba(141, 124, 255, 0.1)',
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <h2 className="text-2xl font-black tracking-tight flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-amber-400" />
              My Badges Collection
            </h2>
            <p className="text-xs text-slate-400">
              Photorealistic 3D Liquid Mineral Badges earned through geological exploration
            </p>
          </div>

          <div className="flex items-center gap-6">
            <div className="text-center">
              <div className="text-2xl font-black text-amber-400">{unlockedCount} / {allBadges.length}</div>
              <div className="text-[10px] font-bold uppercase text-slate-400">Unlocked</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-purple-400">+{totalXP}</div>
              <div className="text-[10px] font-bold uppercase text-slate-400">Total XP</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-black text-emerald-400">{completionPct}%</div>
              <div className="text-[10px] font-bold uppercase text-slate-400">Complete</div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2 bg-white/10 rounded-full mt-5 overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-amber-400 via-purple-500 to-emerald-400 rounded-full"
            initial={{ width: '0%' }}
            animate={{ width: `${completionPct}%` }}
            transition={{ duration: 0.8 }}
          />
        </div>
      </div>

      {/* Filter & View Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search badges..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>

        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex-shrink-0 ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-black shadow-lg'
                  : 'bg-white/5 hover:bg-white/10 text-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* AR View Toggle */}
        <button
          onClick={() => setIsArGlowMode(!isArGlowMode)}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold transition-all border ${
            isArGlowMode
              ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-500/30'
              : 'bg-slate-900 border-white/10 text-slate-300'
          }`}
        >
          <Eye className="w-4 h-4" />
          <span>{isArGlowMode ? 'AR Glow Mode ON' : 'AR Glow View'}</span>
        </button>
      </div>

      {/* Rarity Filter Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
          <Filter className="w-3 h-3" /> Rarity:
        </span>
        {RARITIES.map((r) => {
          const colors = BADGE_RARITY_COLORS[r] || { text: 'text-slate-300' };
          return (
            <button
              key={r}
              onClick={() => setSelectedRarity(r)}
              className={`px-2.5 py-1 rounded-lg text-[10px] font-extrabold uppercase transition-all border ${
                selectedRarity === r
                  ? 'bg-white/20 border-white/40 text-white'
                  : 'bg-white/5 border-white/5 text-slate-400 hover:text-slate-200'
              }`}
            >
              {r}
            </button>
          );
        })}
      </div>

      {/* Badges 3D Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {filteredBadges.map((badge) => {
          const isUnlocked = unlockedSet.has(badge.id);

          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center p-4 rounded-3xl border bg-slate-950/60 transition-all hover:bg-slate-900/80 relative group"
              style={{
                borderColor: isUnlocked ? 'rgba(212, 175, 55, 0.3)' : 'rgba(255, 255, 255, 0.08)',
              }}
            >
              {/* Badge Item Renderer */}
              <MineralEmblemBadge
                badge={badge}
                size={110}
                isUnlocked={isUnlocked}
                isArGlowMode={isArGlowMode}
                themeMode={themeMode}
                showLabel={false}
              />

              {/* Title & Category */}
              <div className="text-center mt-3 space-y-0.5">
                <h4 className="font-extrabold text-xs text-white leading-tight">{badge.name}</h4>
                <p className="text-[10px] text-slate-400 line-clamp-1">{badge.description}</p>
              </div>

              {/* Quick Action Overlay */}
              <div className="mt-3 flex items-center gap-1.5">
                <button
                  onClick={() => setSelectedBadgeForBreakdown(badge.id)}
                  className="p-1.5 rounded-xl bg-white/5 hover:bg-amber-500/20 text-slate-300 hover:text-amber-400 transition-colors border border-white/10"
                  title="View Material Breakdown"
                >
                  <Layers className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => setReplayBadgeId(badge.id)}
                  className="p-1.5 rounded-xl bg-white/5 hover:bg-purple-500/20 text-slate-300 hover:text-purple-400 transition-colors border border-white/10"
                  title="Play 5-Step Unlock Animation"
                >
                  <Play className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
