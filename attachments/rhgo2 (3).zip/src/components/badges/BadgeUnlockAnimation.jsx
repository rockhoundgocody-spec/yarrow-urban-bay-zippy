/**
 * BadgeUnlockAnimation — Photorealistic 5-step unlock animation overlay.
 * Steps:
 * 1. Initiate (dark stone medallion only)
 * 2. Charge (purple energy veins build across stone)
 * 3. Burst (crystal explosion + particle scatter)
 * 4. Reveal (full 3D glow + badge name & description appear)
 * 5. Complete (soft ambient chime + floating particles settle)
 */

import React, { useEffect, useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, X, Volume2, VolumeX } from 'lucide-react';
import OctagonalLiquidBadge3D from './OctagonalLiquidBadge3D';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

const UNLOCK_STEPS = [
  { key: 'initiate', title: '1. Initiate', label: 'Dark stone medallion awakens…', durationMs: 1200 },
  { key: 'charge', title: '2. Charge', label: 'Purple energy veins build from deep within…', durationMs: 1500 },
  { key: 'burst', title: '3. Burst', label: 'Crystal core explosion & golden particle scatter!', durationMs: 1200 },
  { key: 'reveal', title: '4. Reveal', label: 'Full 3D liquid refraction revealed', durationMs: 2000 },
  { key: 'complete', title: '5. Complete', label: 'Ambient chime sounds as golden particles settle', durationMs: 0 },
];

function AmbientParticle({ index, color }) {
  const angle = (index / 24) * 360;
  const dist = 70 + (index % 5) * 20;

  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: 4 + (index % 3) * 2,
        height: 4 + (index % 3) * 2,
        background: color,
        boxShadow: `0 0 10px ${color}`,
        top: '50%',
        left: '50%',
      }}
      initial={{ x: 0, y: 0, opacity: 0, scale: 0.2 }}
      animate={{
        x: Math.cos((angle * Math.PI) / 180) * dist,
        y: Math.sin((angle * Math.PI) / 180) * dist,
        opacity: [0, 1, 0],
        scale: [0.2, 1.2, 0.4],
      }}
      transition={{
        duration: 1.8 + Math.random() * 0.8,
        ease: 'easeOut',
        repeat: Infinity,
        repeatDelay: Math.random() * 0.5,
      }}
    />
  );
}

export default function BadgeUnlockAnimation({
  badge,
  badgeId,
  visible = true,
  onComplete = () => {},
  onDismiss = () => {},
}) {
  const [stepIdx, setStepIdx] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const badgeObj = getBadgeById(badgeId || badge?.id) || getBadgeById('crystal_whisperer');

  const cfg = badgeObj?.visualConfig || {
    liquidColor: '#8D7CFF',
    glowColor: '#C084FC',
    frameColor: '#D4AF37',
  };

  useEffect(() => {
    if (!visible || !badgeObj) return;

    let timer;
    const runSequence = (idx) => {
      setStepIdx(idx);
      const step = UNLOCK_STEPS[idx];
      if (step && step.durationMs > 0) {
        timer = setTimeout(() => {
          if (idx + 1 < UNLOCK_STEPS.length) {
            runSequence(idx + 1);
          } else {
            onComplete();
          }
        }, step.durationMs);
      }
    };

    runSequence(0);

    return () => clearTimeout(timer);
  }, [visible, badgeObj, onComplete]);

  if (!visible || !badgeObj) return null;

  const currentStep = UNLOCK_STEPS[stepIdx] || UNLOCK_STEPS[UNLOCK_STEPS.length - 1];
  const isUnlockedState = stepIdx >= 3; // Reveal and Complete

  return (
    <AnimatePresence>
      <motion.div
        key="unlock-sequence-overlay"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[9999] flex flex-col items-center justify-center p-6 text-white select-none"
        style={{
          background: 'radial-gradient(circle at center, rgba(15,10,28,0.96) 0%, rgba(4,5,10,0.98) 100%)',
          backdropFilter: 'blur(16px)',
        }}
      >
        {/* Dismiss Button */}
        {stepIdx >= 3 && (
          <button
            onClick={onDismiss}
            className="absolute top-6 right-6 p-2.5 rounded-full hover:bg-white/10 transition-colors"
            style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}
            aria-label="Close unlock sequence"
          >
            <X className="w-6 h-6 text-white/70" />
          </button>
        )}

        {/* Sound Toggle */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="absolute top-6 left-6 p-2.5 rounded-full hover:bg-white/10 transition-colors flex items-center gap-2 text-xs font-bold"
          style={{ background: 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.15)' }}
        >
          {soundEnabled ? <Volume2 className="w-5 h-5 text-amber-400" /> : <VolumeX className="w-5 h-5 text-slate-400" />}
          <span>{soundEnabled ? 'Chime ON' : 'Muted'}</span>
        </button>

        {/* Central 3D Medallion & Animation Effects */}
        <div className="relative flex items-center justify-center my-8">
          {/* Energy Veins Charge Ring */}
          {stepIdx === 1 && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: [0.8, 1.4, 1.1], opacity: [0.3, 0.9, 0.6] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="absolute rounded-full pointer-events-none"
              style={{
                width: 220,
                height: 220,
                border: `2px solid ${cfg.glowColor}`,
                boxShadow: `0 0 50px ${cfg.glowColor}, inset 0 0 30px ${cfg.glowColor}`,
              }}
            />
          )}

          {/* Burst Particle Scatter */}
          {stepIdx >= 2 && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              {Array.from({ length: 24 }).map((_, i) => (
                <AmbientParticle key={i} index={i} color={cfg.glowColor} />
              ))}
            </div>
          )}

          {/* 3D Octagonal Medallion */}
          <motion.div
            animate={{
              scale: stepIdx === 0 ? 0.85 : stepIdx === 1 ? 0.95 : stepIdx === 2 ? 1.15 : 1.0,
              rotate: stepIdx === 1 ? [0, -4, 4, 0] : 0,
            }}
            transition={{ duration: 0.6, type: 'spring' }}
          >
            <OctagonalLiquidBadge3D
              badgeId={badgeObj.id}
              size={240}
              isUnlocked={isUnlockedState}
              isArGlowMode={stepIdx >= 3}
              animationState={currentStep.key}
            />
          </motion.div>
        </div>

        {/* Step Indicator & Text Content */}
        <div className="text-center max-w-sm space-y-3 mt-4">
          <motion.div
            key={currentStep.key}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-1"
          >
            <span
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest"
              style={{
                background: 'rgba(212, 175, 55, 0.15)',
                color: cfg.frameColor,
                border: `1px solid ${cfg.frameColor}40`,
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              {currentStep.title}
            </span>
            <p className="text-sm font-semibold text-slate-300 mt-2">
              {currentStep.label}
            </p>
          </motion.div>

          {/* Badge Unlocked Title & Reward */}
          {isUnlockedState && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.2 }}
              className="space-y-2 pt-3 border-t border-white/10"
            >
              <h2 className="text-2xl font-black tracking-tight text-white">
                {badgeObj.name}
              </h2>
              <p className="text-xs text-slate-300 leading-relaxed">
                {badgeObj.unlock_message}
              </p>
              {badgeObj.xp_reward && (
                <div
                  className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full font-black text-sm mt-2"
                  style={{
                    background: 'linear-gradient(135deg, #D4AF37 0%, #F5B642 100%)',
                    color: '#000',
                    boxShadow: `0 0 15px ${cfg.glowColor}80`,
                  }}
                >
                  <Sparkles className="w-4 h-4 fill-black" />
                  +{badgeObj.xp_reward} XP
                </div>
              )}
            </motion.div>
          )}

          {/* Step Progress Bar */}
          <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mt-6">
            <motion.div
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${cfg.glowColor}, ${cfg.frameColor})` }}
              initial={{ width: '0%' }}
              animate={{ width: `${((stepIdx + 1) / UNLOCK_STEPS.length) * 100}%` }}
              transition={{ duration: 0.4 }}
            />
          </div>

          {stepIdx >= 4 && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-[11px] text-white/40 pt-2 cursor-pointer"
              onClick={onDismiss}
            >
              Tap anywhere or close to continue
            </motion.p>
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
