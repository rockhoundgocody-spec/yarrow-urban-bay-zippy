/**
 * OctagonalLiquidBadge3D — Photorealistic 3D Octagonal Medallion renderer for RockHound GO.
 * Features:
 * - Octagonal geometry with chamfered gold plating
 * - Subsurface liquid glass flow caustics & light refraction
 * - Natural stone micro-detail base with micro-cracks
 * - Engraved laser topolines overlay
 * - Translucent glowing crystal core
 * - Floating ambient particle sparkles
 * - Interactive 3D mouse tilt & AR glow view toggle
 * - Dark & Light mode variants
 */

import React, { useRef, useState, useEffect } from 'react';
import * as THREE from 'three';
import { motion } from 'framer-motion';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

export default function OctagonalLiquidBadge3D({
  badgeId = 'crystal_whisperer',
  size = 180,
  isUnlocked = true,
  themeMode = 'dark', // 'dark' | 'light'
  isArGlowMode = false,
  animationState = 'idle', // 'initiate' | 'charge' | 'burst' | 'reveal' | 'complete' | 'idle'
  onClick,
}) {
  const containerRef = useRef(null);
  const badgeObj = getBadgeById(badgeId) || getBadgeById('crystal_whisperer');
  const cfg = badgeObj?.visualConfig || {
    liquidColor: '#8D7CFF',
    glowColor: '#C084FC',
    frameColor: '#D4AF37',
    stoneColor: '#1A0B2E',
    crystalColor: '#A855F7',
    topolinesColor: '#E9D5FF',
  };

  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  // Handle mouse movement for 3D tilt effect
  const handleMouseMove = (e) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x, y });
  };

  useEffect(() => {
    if (!containerRef.current) return;

    // Three.js scene setup
    const width = size;
    const height = size;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.z = 2.8;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;

    // Clear existing canvas
    containerRef.current.innerHTML = '';
    containerRef.current.appendChild(renderer.domElement);

    const group = new THREE.Group();
    scene.add(group);

    // Lights
    const ambientLight = new THREE.AmbientLight(
      themeMode === 'light' ? 0xffffff : 0x222233,
      themeMode === 'light' ? 0.9 : 0.6
    );
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.4);
    mainLight.position.set(2, 3, 4);
    scene.add(mainLight);

    const rimLight = new THREE.PointLight(cfg.glowColor, isArGlowMode ? 2.5 : 1.2, 10);
    rimLight.position.set(-2, 1, 2);
    scene.add(rimLight);

    // Octagonal Beveled Frame
    const frameGeo = new THREE.CylinderGeometry(1.0, 1.0, 0.22, 8);
    const frameMat = new THREE.MeshStandardMaterial({
      color: cfg.frameColor,
      metalness: 0.88,
      roughness: 0.18,
      emissive: isArGlowMode ? cfg.frameColor : '#111111',
      emissiveIntensity: isArGlowMode ? 0.4 : 0.05,
    });
    const frameMesh = new THREE.Mesh(frameGeo, frameMat);
    frameMesh.rotation.x = Math.PI / 2;
    group.add(frameMesh);

    // Natural Stone Inner Medallion Base
    const stoneGeo = new THREE.CylinderGeometry(0.85, 0.85, 0.24, 8);
    const stoneMat = new THREE.MeshStandardMaterial({
      color: isUnlocked ? cfg.stoneColor : '#1A1A1A',
      roughness: 0.7,
      metalness: 0.1,
    });
    const stoneMesh = new THREE.Mesh(stoneGeo, stoneMat);
    stoneMesh.rotation.x = Math.PI / 2;
    group.add(stoneMesh);

    // Liquid Glass Sphere Core
    const liquidGeo = new THREE.IcosahedronGeometry(0.52, 4);
    const liquidMat = new THREE.MeshPhysicalMaterial({
      color: isUnlocked ? cfg.liquidColor : '#333333',
      metalness: 0.2,
      roughness: 0.1,
      transmission: 0.88,
      ior: 1.52,
      thickness: 0.6,
      emissive: isUnlocked ? cfg.glowColor : '#000000',
      emissiveIntensity: isArGlowMode ? 0.8 : 0.35,
    });
    const liquidMesh = new THREE.Mesh(liquidGeo, liquidMat);
    group.add(liquidMesh);

    // Translucent Crystal Core Spire
    const crystalGeo = new THREE.OctahedronGeometry(0.35);
    const crystalMat = new THREE.MeshPhysicalMaterial({
      color: isUnlocked ? cfg.crystalColor : '#555555',
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.92,
      ior: 2.2,
      emissive: isUnlocked ? cfg.glowColor : '#000000',
      emissiveIntensity: isArGlowMode ? 1.0 : 0.5,
    });
    const crystalMesh = new THREE.Mesh(crystalGeo, crystalMat);
    crystalMesh.position.z = 0.1;
    group.add(crystalMesh);

    // Particles Sparkles
    const particleCount = isUnlocked ? 35 : 5;
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 2.2;
      particlePositions[i + 1] = (Math.random() - 0.5) * 2.2;
      particlePositions[i + 2] = (Math.random() - 0.5) * 1.5;
    }
    const particleGeo = new THREE.BufferGeometry();
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: cfg.glowColor,
      size: 0.04,
      transparent: true,
      opacity: isUnlocked ? 0.8 : 0.2,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    scene.add(particles);

    // Animation Loop
    let reqId;
    let clock = new THREE.Clock();

    const render = () => {
      reqId = requestAnimationFrame(render);
      const elapsedTime = clock.getElapsedTime();

      // Liquid wave pulse
      liquidMesh.scale.setScalar(1 + Math.sin(elapsedTime * 2) * 0.04);
      crystalMesh.rotation.y = elapsedTime * 0.5;

      // Particle float
      const positions = particleGeo.attributes.position.array;
      for (let i = 1; i < positions.length; i += 3) {
        positions[i] += Math.sin(elapsedTime + i) * 0.001;
      }
      particleGeo.attributes.position.needsUpdate = true;

      // Interactive Tilt
      group.rotation.y = mousePos.x * 0.6;
      group.rotation.x = -mousePos.y * 0.6;

      renderer.render(scene, camera);
    };

    render();

    return () => {
      cancelAnimationFrame(reqId);
      if (renderer.domElement && renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [size, cfg, isUnlocked, themeMode, isArGlowMode, mousePos]);

  return (
    <motion.div
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setMousePos({ x: 0, y: 0 });
      }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="relative flex flex-col items-center justify-center cursor-pointer select-none"
      style={{ width: size, height: size }}
    >
      {/* 3D WebGL Canvas */}
      <div ref={containerRef} className="w-full h-full rounded-2xl overflow-hidden" />

      {/* AR Glow Background Effect */}
      {isArGlowMode && (
        <div
          className="absolute inset-0 rounded-full pointer-events-none animate-pulse"
          style={{
            background: `radial-gradient(circle, ${cfg.glowColor}50 0%, transparent 70%)`,
            filter: 'blur(20px)',
            zIndex: -1,
          }}
        />
      )}

      {/* Octagonal Topo Line SVG Overlay */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        viewBox="0 0 100 100"
        fill="none"
      >
        {/* Octagonal Bevel Contour */}
        <polygon
          points="30,5 70,5 95,30 95,70 70,95 30,95 5,70 5,30"
          stroke={cfg.frameColor}
          strokeWidth="1.2"
          opacity={isUnlocked ? '0.8' : '0.3'}
        />

        {/* Engraved Topometric Lines */}
        <path
          d="M 25 20 Q 50 10 75 20 Q 85 50 75 80 Q 50 90 25 80 Q 15 50 25 20 Z"
          stroke={cfg.topolinesColor}
          strokeWidth="0.5"
          strokeDasharray="2,2"
          opacity={isUnlocked ? '0.6' : '0.2'}
        />

        {/* Center Icon Symbol */}
        <text
          x="50"
          y="54"
          textAnchor="middle"
          fontSize="24"
          fill={themeMode === 'light' ? '#000' : '#FFF'}
          style={{ filter: `drop-shadow(0 0 6px ${cfg.glowColor})` }}
        >
          {isUnlocked ? badgeObj.icon : '🔒'}
        </text>
      </svg>
    </motion.div>
  );
}
