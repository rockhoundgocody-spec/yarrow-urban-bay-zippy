/**
 * MineralEmblemBadge — High-performance 3D octagonal medallion renderer.
 * Features octagonal metallic bevels, liquid glass subsurface caustics,
 * engraved geo topo lines, crystal core, and ambient sparkle glow.
 */
import React from 'react';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { getBadgeById, BADGE_RARITY_COLORS } from '@/services/rewards/badgeDefinitions';

export default function MineralEmblemBadge({
  badge,           // Badge object or string ID
  size = 120,
  isUnlocked = false,
  showLabel = true,
  themeMode = 'dark', // 'dark' | 'light'
  isArGlowMode = false,
  onClick,
}) {
  const badgeObj = typeof badge === 'string' ? getBadgeById(badge) : (badge || getBadgeById('crystal_whisperer'));
  const cfg = badgeObj?.visualConfig || {
    liquidColor: '#8D7CFF',
    glowColor: '#C084FC',
    frameColor: '#D4AF37',
    stoneColor: '#1A0B2E',
    crystalColor: '#A855F7',
    topolinesColor: '#E9D5FF',
  };

  const rarity = badgeObj?.rarity || 'common';
  const rarityColors = BADGE_RARITY_COLORS[rarity] || BADGE_RARITY_COLORS.common;
  const isSmall = size < 100;

  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.95 }}
      whileHover={{ scale: 1.05, y: -2 }}
      transition={{ type: 'spring', stiffness: 350, damping: 22 }}
      className="flex flex-col items-center gap-2 cursor-pointer focus:outline-none group relative"
      style={{ width: size + 20 }}
      aria-label={badgeObj?.name || 'Badge'}
    >
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        {/* AR Glow Outer Halo */}
        <div
          className="absolute inset-0 pointer-events-none transition-opacity duration-300"
          style={{
            clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)',
            background: isUnlocked
              ? `radial-gradient(circle, ${cfg.glowColor}60 0%, transparent 70%)`
              : 'none',
            boxShadow: (isUnlocked || isArGlowMode)
              ? `0 0 ${size * 0.3}px ${cfg.glowColor}80`
              : 'none',
            opacity: isUnlocked ? 0.9 : 0.2,
          }}
        />

        {/* Outer Metallic Octagonal Frame */}
        <div
          className="w-full h-full relative flex items-center justify-center p-2.5 transition-all"
          style={{
            clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)',
            background: `linear-gradient(135deg, ${cfg.frameColor} 0%, #B8960C 50%, ${cfg.frameColor} 100%)`,
            boxShadow: `inset 0 1px 2px rgba(255,255,255,0.4), inset 0 -2px 4px rgba(0,0,0,0.6)`,
          }}
        >
          {/* Stone Base & Liquid Glass Interior */}
          <div
            className="w-full h-full relative overflow-hidden flex items-center justify-center"
            style={{
              clipPath: 'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)',
              background: isUnlocked
                ? `radial-gradient(circle at 40% 35%, ${cfg.liquidColor} 0%, ${cfg.stoneColor} 80%)`
                : 'linear-gradient(145deg, #121212 0%, #2A2A2A 100%)',
            }}
          >
            {/* Topo lines SVG overlay */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none opacity-40"
              viewBox="0 0 100 100"
              fill="none"
            >
              <path
                d="M 20 30 Q 50 15 80 30 Q 85 50 80 70 Q 50 85 20 70 Q 15 50 20 30 Z"
                stroke={cfg.topolinesColor}
                strokeWidth="0.8"
                strokeDasharray="2,2"
              />
              <circle cx="50" cy="50" r="28" stroke={cfg.topolinesColor} strokeWidth="0.6" />
            </svg>

            {/* Specular Glint Refraction */}
            <div
              className="absolute pointer-events-none"
              style={{
                top: '10%',
                left: '20%',
                width: '40%',
                height: '25%',
                background: 'radial-gradient(ellipse, rgba(255,255,255,0.4) 0%, transparent 70%)',
                borderRadius: '50%',
                filter: 'blur(2px)',
              }}
            />

            {/* Center Icon or Lock */}
            <div
              className="relative z-10 flex items-center justify-center"
              style={{
                filter: isUnlocked ? `drop-shadow(0 0 8px ${cfg.glowColor})` : 'none',
              }}
            >
              {isUnlocked ? (
                <span className="select-none" style={{ fontSize: size * 0.38, lineHeight: 1 }}>
                  {badgeObj?.icon || '🔮'}
                </span>
              ) : (
                <Lock
                  style={{
                    width: size * 0.3,
                    height: size * 0.3,
                    color: 'rgba(255,255,255,0.25)',
                  }}
                />
              )}
            </div>
          </div>
        </div>

        {/* XP Reward Chip */}
        {isUnlocked && badgeObj?.xp_reward && !isSmall && (
          <div
            className="absolute -top-1 -right-1 rounded-full px-2 py-0.5 text-[9px] font-black"
            style={{
              background: cfg.frameColor,
              color: '#000',
              boxShadow: `0 0 8px ${cfg.glowColor}`,
            }}
          >
            +{badgeObj.xp_reward} XP
          </div>
        )}
      </div>

      {/* Label */}
      {showLabel && (
        <div className="text-center">
          <p
            className="font-black leading-tight tracking-tight"
            style={{
              fontSize: isSmall ? 10 : 12,
              color: isUnlocked
                ? (themeMode === 'light' ? '#0F172A' : '#FFFFFF')
                : 'rgba(255,255,255,0.35)',
            }}
          >
            {badgeObj?.name || 'Badge'}
          </p>
          {!isSmall && (
            <p className="text-[9px] font-extrabold uppercase mt-0.5" style={{ color: rarityColors.text }}>
              {rarity}
            </p>
          )}
        </div>
      )}
    </motion.button>
  );
}
