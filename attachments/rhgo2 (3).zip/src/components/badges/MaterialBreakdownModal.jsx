/**
 * MaterialBreakdownModal — Displays interactive breakdown of the 6 material layers
 * forming a Liquid Mineral Badge (Liquid Glass, Natural Stone, Metallic Inlay, Crystal Core, Geo Topo Lines, Ambient Particles).
 */

import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Layers, Sparkles, Gem, Compass, Shield, Flame } from 'lucide-react';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

const LAYER_ICONS = {
  liquidGlass: Gem,
  naturalStone: Shield,
  metallicInlay: Compass,
  crystalCore: Sparkles,
  geoTopoLines: Layers,
  ambientParticles: Flame,
};

const LAYER_TITLES = {
  liquidGlass: '1. Liquid Glass Core',
  naturalStone: '2. Natural Stone Base',
  metallicInlay: '3. Metallic Gold Inlay',
  crystalCore: '4. Translucent Crystal Core',
  geoTopoLines: '5. Engraved Geo Topo Lines',
  ambientParticles: '6. Ambient Particle Sparkles',
};

const LAYER_ACCENT_COLORS = {
  liquidGlass: '#38BDF8',
  naturalStone: '#94A3B8',
  metallicInlay: '#F5B642',
  crystalCore: '#C084FC',
  geoTopoLines: '#10B981',
  ambientParticles: '#F43F5E',
};

export default function MaterialBreakdownModal({ badgeId, isOpen = false, onClose = () => {} }) {
  if (!isOpen || !badgeId) return null;

  const badge = getBadgeById(badgeId);
  if (!badge) return null;

  const breakdown = badge.materialBreakdown || {};

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-xl max-h-[85vh] overflow-y-auto rounded-3xl p-6 shadow-2xl text-white border"
          style={{
            background: 'linear-gradient(160deg, #0D0F1D 0%, #080A14 100%)',
            borderColor: 'rgba(212, 175, 55, 0.3)',
            boxShadow: '0 0 50px rgba(212, 175, 55, 0.15), inset 0 1px 0 rgba(255, 255, 255, 0.1)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b pb-4 mb-5" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl flex items-center justify-center text-xl shadow-lg"
                style={{
                  background: 'linear-gradient(135deg, rgba(212, 175, 55, 0.3) 0%, rgba(141, 124, 255, 0.2) 100%)',
                  border: '1px solid rgba(212, 175, 55, 0.4)',
                }}
              >
                {badge.icon}
              </div>
              <div>
                <h3 className="text-lg font-black tracking-tight flex items-center gap-2">
                  <span>{badge.name}</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full uppercase font-bold tracking-wider" style={{ background: 'rgba(212, 175, 55, 0.15)', color: '#F5B642', border: '1px solid rgba(212,175,55,0.3)' }}>
                    Material Spec
                  </span>
                </h3>
                <p className="text-xs" style={{ color: 'rgba(255,255,255,0.4)' }}>
                  Photorealistic 3D Octagonal Medallion Architectural Breakdown
                </p>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/10 transition-colors"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              aria-label="Close Material Breakdown"
            >
              <X className="w-5 h-5 text-white/60" />
            </button>
          </div>

          {/* Layer List */}
          <div className="space-y-3">
            {Object.keys(LAYER_TITLES).map((key, index) => {
              const Icon = LAYER_ICONS[key] || Layers;
              const title = LAYER_TITLES[key];
              const text = breakdown[key] || 'High-fidelity material shaders applied.';
              const accent = LAYER_ACCENT_COLORS[key];

              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="p-3.5 rounded-2xl border transition-all hover:translate-x-1"
                  style={{
                    background: 'rgba(255, 255, 255, 0.03)',
                    borderColor: `${accent}25`,
                  }}
                >
                  <div className="flex items-center gap-3 mb-1.5">
                    <div
                      className="p-2 rounded-xl"
                      style={{ background: `${accent}18`, border: `1px solid ${accent}35` }}
                    >
                      <Icon className="w-4 h-4" style={{ color: accent }} />
                    </div>
                    <h4 className="font-bold text-sm" style={{ color: accent }}>
                      {title}
                    </h4>
                  </div>
                  <p className="text-xs leading-relaxed pl-11" style={{ color: 'rgba(255,255,255,0.7)' }}>
                    {text}
                  </p>
                </motion.div>
              );
            })}
          </div>

          {/* Footer note */}
          <div className="mt-5 pt-4 border-t text-center" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
            <p className="text-[11px] italic" style={{ color: 'rgba(255,255,255,0.35)' }}>
              Rendered real-time using Three.js WebGL shaders with liquid subsurface caustics & 24k gold inlay highlights.
            </p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
