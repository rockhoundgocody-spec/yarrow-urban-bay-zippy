/**
 * BadgeUnlockSequence: Interactive 5-step Liquid Mineral Badge unlock sequence controller.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import OctagonalLiquidBadge3D from './OctagonalLiquidBadge3D';
import { Sparkles, Play, Volume2, VolumeX } from 'lucide-react';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

const UNLOCK_SEQUENCE_STEPS = [
  { frame: 'initiate', label: '1. Initiate — Dark stone medallion awakens', duration: 1.2 },
  { frame: 'charge', label: '2. Charge — Energy veins build across topo lines', duration: 1.5 },
  { frame: 'burst', label: '3. Burst — Crystal explosion + particle scatter', duration: 1.2 },
  { frame: 'reveal', label: '4. Reveal — Full 3D liquid refraction glow', duration: 1.0 },
  { frame: 'complete', label: '5. Complete — Soft chime + ambient particles settle', duration: 0.5 },
];

export default function BadgeUnlockSequence({
  badgeId = 'crystal_whisperer',
  onComplete = () => {},
}) {
  const [currentFrame, setCurrentFrame] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const badgeObj = getBadgeById(badgeId) || getBadgeById('crystal_whisperer');

  useEffect(() => {
    if (!isPlaying || currentFrame >= UNLOCK_SEQUENCE_STEPS.length) return;

    const current = UNLOCK_SEQUENCE_STEPS[currentFrame];
    const timer = setTimeout(() => {
      const nextFrame = currentFrame + 1;
      if (nextFrame < UNLOCK_SEQUENCE_STEPS.length) {
        setCurrentFrame(nextFrame);
      } else {
        setIsPlaying(false);
        onComplete();
      }
    }, current.duration * 1000);

    return () => clearTimeout(timer);
  }, [isPlaying, currentFrame, onComplete]);

  const handleStart = () => {
    setCurrentFrame(0);
    setIsPlaying(true);
  };

  const currentStep = UNLOCK_SEQUENCE_STEPS[currentFrame] || UNLOCK_SEQUENCE_STEPS[0];

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-md mx-auto space-y-6 p-6 rounded-3xl border border-amber-500/30 bg-slate-950/90 shadow-2xl text-white"
    >
      {/* Central 3D Octagonal Medallion */}
      <div className="flex justify-center py-2">
        <OctagonalLiquidBadge3D
          badgeId={badgeId}
          size={220}
          isUnlocked={currentFrame >= 3}
          isArGlowMode={currentFrame >= 3}
          animationState={currentStep.frame}
        />
      </div>

      {/* Sequence Info */}
      <div className="text-center space-y-2">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <p className="text-xs font-black uppercase tracking-widest text-amber-300">
            {currentStep.label}
          </p>
          <Sparkles className="w-4 h-4 text-amber-400" />
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-purple-500 via-amber-400 to-emerald-400"
            initial={{ width: '0%' }}
            animate={{ width: `${((currentFrame + 1) / UNLOCK_SEQUENCE_STEPS.length) * 100}%` }}
            transition={{ duration: currentStep.duration }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-3">
        <motion.button
          onClick={handleStart}
          disabled={isPlaying}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="flex-1 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-purple-600 text-black font-black text-xs tracking-wider uppercase flex items-center justify-center gap-2 disabled:opacity-50 transition-all shadow-lg"
        >
          <Play className="w-4 h-4 fill-black" />
          {isPlaying ? 'Playing Sequence…' : 'Play 5-Step Unlock'}
        </motion.button>

        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className="px-4 py-3 rounded-2xl border border-white/15 bg-white/5 hover:bg-white/10 transition-colors"
          aria-label="Toggle sound"
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
        </button>
      </div>
    </motion.div>
  );
}
