/**
 * CrystalBadge3D: Wrapper component for 3D Liquid Mineral Badges system.
 * Delegates rendering to OctagonalLiquidBadge3D for photorealistic octagonal medallion aesthetics.
 */
import React from 'react';
import OctagonalLiquidBadge3D from './OctagonalLiquidBadge3D';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

export default function CrystalBadge3D({
  badgeId = 'crystal_whisperer',
  size = 200,
  isUnlocked = false,
  onUnlock = () => {},
  animationState = 'idle', // idle, initiate, charging, bursting, revealing, complete
  themeMode = 'dark',
  isArGlowMode = false,
  onClick,
}) {
  const badgeObj = getBadgeById(badgeId);

  return (
    <div className="flex flex-col items-center gap-3">
      <OctagonalLiquidBadge3D
        badgeId={badgeId}
        size={size}
        isUnlocked={isUnlocked}
        themeMode={themeMode}
        isArGlowMode={isArGlowMode}
        animationState={animationState}
        onClick={onClick}
      />

      {/* Badge Name & Description */}
      {badgeObj && (
        <div className="text-center max-w-xs">
          <h3 className="font-extrabold text-sm text-white tracking-tight flex items-center justify-center gap-1.5">
            <span>{badgeObj.name}</span>
          </h3>
          <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
            {badgeObj.description}
          </p>
        </div>
      )}

      {/* Status indicator */}
      {!isUnlocked && (
        <div className="text-[11px] font-semibold text-amber-400/80 uppercase tracking-wider bg-amber-950/30 px-2.5 py-0.5 rounded-full border border-amber-800/40">
          🔒 Locked
        </div>
      )}
    </div>
  );
}
