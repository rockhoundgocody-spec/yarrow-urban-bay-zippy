/**
 * WaypointMarker — animated geolocation game marker.
 * Renders as an inline React element (for custom overlays / divIcon HTML).
 * Provides: pulse ring, rarity color, discovery glow, collected state.
 *
 * Props:
 *   rarity      — "common"|"uncommon"|"rare"|"epic"|"legendary"
 *   collected   — boolean
 *   discovered  — boolean (first-time discovery flash)
 *   size        — number (px, default 44)
 *   label       — string (optional tooltip)
 *   onClick     — function
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { getRarityCfg } from "@/theme/crystalSystem";
import { Gem } from "lucide-react";
import { fxFlags } from "@/theme/performance";

export default function WaypointMarker({ rarity = "common", collected = false, discovered = false, size = 44, label, onClick }) {
  const cfg = getRarityCfg(rarity);
  const fx  = fxFlags();
  const color = collected ? "rgba(255,255,255,0.25)" : cfg.color;
  const glow  = collected ? "transparent" : cfg.glow;

  return (
    <motion.button
      className="relative flex items-center justify-center rounded-full focus:outline-none"
      style={{ width: size, height: size, minWidth: size, minHeight: size, background: "transparent", border: "none" }}
      whileTap={{ scale: 0.88 }}
      onClick={onClick}
      aria-label={label || `${rarity} specimen site`}
    >
      {/* Pulse rings */}
      {!collected && fx.heavyGlow && [0, 1].map(i => (
        <motion.div
          key={i}
          className="absolute rounded-full pointer-events-none"
          style={{ width: size, height: size, border: `1.5px solid ${color}`, opacity: 0 }}
          animate={{ scale: [1, 1.7, 2.2], opacity: [0.6, 0.3, 0] }}
          transition={{ duration: 2.2, repeat: Infinity, delay: i * 1.1, ease: "easeOut" }}
        />
      ))}

      {/* Discovery burst */}
      <AnimatePresence>
        {discovered && (
          <motion.div
            className="absolute rounded-full pointer-events-none"
            style={{ width: size * 1.8, height: size * 1.8, background: `radial-gradient(circle, ${color}44, transparent 70%)` }}
            initial={{ scale: 0.5, opacity: 1 }}
            animate={{ scale: 1.8, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
          />
        )}
      </AnimatePresence>

      {/* Core pin */}
      <div
        className="relative flex items-center justify-center rounded-full"
        style={{
          width: size * 0.68,
          height: size * 0.68,
          background: collected
            ? "rgba(255,255,255,0.08)"
            : `radial-gradient(circle at 35% 32%, ${color}55, ${color}22)`,
          border: `1.5px solid ${color}${collected ? "40" : "88"}`,
          boxShadow: collected || !fx.heavyGlow ? "none" : `0 0 14px ${glow}, 0 0 28px ${glow.replace(/[\d.]+\)$/, "0.12)")}`,
        }}
      >
        <Gem
          size={size * 0.28}
          style={{ color: collected ? "rgba(255,255,255,0.3)" : color, opacity: collected ? 0.5 : 1 }}
        />
      </div>

      {/* Collected check */}
      {collected && (
        <div
          className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center"
          style={{ background: "#00D68F", border: "1.5px solid rgba(0,0,0,0.5)" }}
        >
          <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
            <path d="M1.5 4L3.2 5.7L6.5 2.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
      )}
    </motion.button>
  );
}