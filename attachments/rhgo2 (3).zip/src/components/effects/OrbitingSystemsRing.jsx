/**
 * OrbitingSystemsRing v2 — holographic system readouts.
 * Premium UI panels, spectral gradients, refined motion.
 */
import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Map, Gem, ShoppingBag } from 'lucide-react';

const SYSTEMS = [
  { icon: Camera, label: 'Scan', color: '#F5B642', angle: 0 },
  { icon: Map, label: 'Explore', color: '#00D68F', angle: 90 },
  { icon: Gem, label: 'Collection', color: '#7AE7FF', angle: 180 },
  { icon: ShoppingBag, label: 'Market', color: '#8D7CFF', angle: 270 },
];

export default function OrbitingSystemsRing({ isActive }) {
  const radius = 130;

  return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
      {/* Holographic orbital rings */}
      {isActive && (
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="orbitGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#7AE7FF" stopOpacity="0.25" />
              <stop offset="50%" stopColor="#8D7CFF" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#00D68F" stopOpacity="0.1" />
            </linearGradient>
            <filter id="orbitGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur in="SourceGraphic" stdDeviation="0.3" />
            </filter>
          </defs>
          <motion.circle
            cx="50"
            cy="50"
            r="26"
            fill="none"
            stroke="url(#orbitGradient)"
            strokeWidth="0.5"
            opacity="0"
            filter="url(#orbitGlow)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            animate={{ rotate: 360 }}
            transition={{ duration: 12, repeat: Infinity, linear: true }}
          />
          <motion.circle
            cx="50"
            cy="50"
            r="35"
            fill="none"
            stroke="url(#orbitGradient)"
            strokeWidth="0.4"
            opacity="0"
            filter="url(#orbitGlow)"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.25 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            animate={{ rotate: -360 }}
            transition={{ duration: 18, repeat: Infinity, linear: true }}
          />
        </svg>
      )}

      {/* System readout panels */}
      {SYSTEMS.map((sys, i) => {
        const rad = (sys.angle * Math.PI) / 180;
        const x = Math.cos(rad) * radius;
        const y = Math.sin(rad) * radius;

        return (
          <motion.div
            key={sys.label}
            className="absolute"
            style={{ width: 140, height: 72 }}
            initial={{ opacity: 0, scale: 0, x: 0, y: 0 }}
            animate={
              isActive
                ? {
                    opacity: 1,
                    scale: 1,
                    x,
                    y,
                  }
                : { opacity: 0, scale: 0, x: 0, y: 0 }
            }
            transition={{
              delay: 0.3 + i * 0.15,
              duration: 1.2,
              ease: [0.34, 1.56, 0.64, 1],
            }}
          >
            {/* Holographic panel background */}
            <motion.div
              className="absolute inset-0 rounded-2xl overflow-hidden"
              style={{
                background: `linear-gradient(135deg, ${sys.color}18 0%, ${sys.color}08 100%)`,
                border: `1px solid ${sys.color}42`,
                backdropFilter: 'blur(20px)',
                boxShadow: `0 0 24px ${sys.color}35, inset 0 1px 0 rgba(255,255,255,0.08), 0 0 0 1px ${sys.color}15`,
              }}
              animate={{
                boxShadow: [
                  `0 0 24px ${sys.color}35, inset 0 1px 0 rgba(255,255,255,0.08)`,
                  `0 0 36px ${sys.color}55, inset 0 1px 0 rgba(255,255,255,0.12)`,
                  `0 0 24px ${sys.color}35, inset 0 1px 0 rgba(255,255,255,0.08)`,
                ],
              }}
              transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
            />

            {/* Content layer */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-3">
              {/* System icon with rotation */}
              <motion.div
                animate={{ rotate: [0, 360] }}
                transition={{ duration: 20, repeat: Infinity, linear: true }}
              >
                <sys.icon className="w-6 h-6" style={{ color: sys.color }} />
              </motion.div>

              {/* System label */}
              <motion.p
                className="text-[9px] font-bold uppercase tracking-widest mt-2"
                style={{ color: sys.color }}
                initial={{ opacity: 0 }}
                animate={isActive ? { opacity: 1 } : { opacity: 0 }}
                transition={{ delay: 0.8 + i * 0.15, duration: 0.6 }}
              >
                {sys.label}
              </motion.p>
            </div>

            {/* Pulse glow effect */}
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{
                background: `radial-gradient(circle, ${sys.color}25 0%, transparent 70%)`,
                filter: 'blur(16px)',
              }}
              animate={{ opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 2.8, repeat: Infinity, ease: 'easeInOut', delay: i * 0.2 }}
            />

            {/* Edge highlight */}
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{
                background: `linear-gradient(135deg, ${sys.color}40 0%, transparent 50%, ${sys.color}20 100%)`,
                opacity: 0,
              }}
              animate={{ opacity: [0, 0.3, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut', delay: i * 0.25 }}
            />
          </motion.div>
        );
      })}
    </div>
  );
}