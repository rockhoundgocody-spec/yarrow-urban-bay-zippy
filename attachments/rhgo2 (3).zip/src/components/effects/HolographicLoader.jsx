/**
 * HolographicLoader — crystalline orb-pulse loading state.
 * Uses OrbPulse for full-block usage, slim spinner ring for compact inline use.
 *
 * Props:
 *   label    — string
 *   color    — string (hex/rgba) — overrides preset
 *   size     — "sm"|"md"|"lg"
 *   compact  — boolean (inline vs full-block orb)
 *   preset   — OrbPulse preset: "loading"|"scan_success"|"valuation"|"clover"|"premium"
 */
import React from "react";
import { motion } from "framer-motion";
import OrbPulse from "@/components/ui/OrbPulse";

const SIZE_MAP = {
  sm: { orbSize: 28, spinnerSize: 24, fontSize: 10 },
  md: { orbSize: 44, spinnerSize: 36, fontSize: 11 },
  lg: { orbSize: 60, spinnerSize: 52, fontSize: 13 },
};

const COLOR_DEFAULT = "#8D7CFF";

export default function HolographicLoader({
  label = "Loading…",
  color,
  size = "md",
  compact = false,
  preset = "loading",
}) {
  const s = SIZE_MAP[size] ?? SIZE_MAP.md;
  const c = color ?? COLOR_DEFAULT;

  // Compact inline: slim spinner ring
  if (compact) {
    return (
      <div className="flex items-center gap-2.5">
        <div className="relative flex-shrink-0" style={{ width: s.spinnerSize, height: s.spinnerSize }}>
          <div className="absolute inset-0 rounded-full" style={{ border: "2px solid rgba(255,255,255,0.06)" }} />
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{ border: "2px solid transparent", borderTopColor: c, boxShadow: `0 0 8px ${c}88` }}
            animate={{ rotate: 360 }}
            transition={{ duration: 1.1, repeat: Infinity, ease: "linear" }}
          />
          <div className="absolute rounded-full"
            style={{ width: 5, height: 5, top: "50%", left: "50%", marginTop: -2.5, marginLeft: -2.5, background: c, boxShadow: `0 0 8px ${c}` }} />
        </div>
        <span style={{ fontSize: s.fontSize, color: `${c}99`, fontWeight: 600, letterSpacing: "0.08em" }}>{label}</span>
      </div>
    );
  }

  // Full-block: premium orb pulse
  return (
    <div className="flex flex-col items-center justify-center py-10">
      <OrbPulse preset={preset} size={s.orbSize} showLabel={true} label={label} color={color} />
    </div>
  );
}