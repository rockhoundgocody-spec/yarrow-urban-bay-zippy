/**
 * CrystalGlassPanel — reusable glass-morphism surface with crystalline motion.
 *
 * Layers:
 *   1. Frosted glass body (backdrop blur + saturation)
 *   2. Rotating conic crystal refraction (slow, subtle)
 *   3. Specular light sweep (periodic diagonal shimmer)
 *   4. Inner edge glow + top specular highlight
 *   5. Content slot
 *
 * Props:
 *   accent       — hex color for edge glow / shimmer tint
 *   field        — bool, field-mode palette (green)
 *   glowStrength — "none" | "soft" | "strong"
 *   shimmer      — bool, enable specular sweep
 *   className    — extra classes on the content wrapper
 *   style        — merge overrides
 *   children
 */
import React, { memo } from "react";

const SHIMMER_KEYFRAMES = `
@keyframes rhCrystalSweepX {
  0%   { transform: translateX(-130%) skewX(-18deg); opacity: 0; }
  8%   { opacity: 0.7; }
  92%  { opacity: 0.7; }
  100% { transform: translateX(230%) skewX(-18deg); opacity: 0; }
}
@keyframes rhCrystalConic {
  0%   { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
@keyframes rhCrystalEdgePulse {
  0%, 100% { opacity: 0.35; }
  50%      { opacity: 0.7; }
}
`;

let styleInjected = false;
function ensureStyle() {
  if (styleInjected || typeof document === "undefined") return;
  const el = document.createElement("style");
  el.id = "rh-crystal-glass-keyframes";
  el.textContent = SHIMMER_KEYFRAMES;
  document.head.appendChild(el);
  styleInjected = true;
}

const GLOW_MAP = {
  none: "0 4px 20px rgba(0,0,0,0.5)",
  soft: "0 8px 32px rgba(0,0,0,0.55), 0 0 24px rgba(141,124,255,0.06)",
  strong: "0 12px 48px rgba(0,0,0,0.65), 0 0 40px rgba(141,124,255,0.12)",
};

export default memo(function CrystalGlassPanel({
  accent = "#8D7CFF",
  field = false,
  glowStrength = "soft",
  shimmer = true,
  className = "",
  style = {},
  children,
}) {
  ensureStyle();
  const baseAccent = field ? "#4AA354" : accent;
  const glow = GLOW_MAP[glowStrength] || GLOW_MAP.soft;

  return (
    <div
      className="relative overflow-hidden"
      style={{
        background: field
          ? "linear-gradient(160deg, rgba(6,16,10,0.82) 0%, rgba(3,10,6,0.90) 100%)"
          : "linear-gradient(160deg, rgba(12,8,28,0.72) 0%, rgba(6,8,18,0.82) 100%)",
        backdropFilter: "blur(22px) saturate(1.5)",
        WebkitBackdropFilter: "blur(22px) saturate(1.5)",
        border: `1px solid ${baseAccent}28`,
        borderRadius: 22,
        boxShadow: `${glow}, inset 0 1px 0 rgba(255,255,255,0.07), inset 0 -1px 0 rgba(0,0,0,0.25)`,
        ...style,
      }}
    >
      {/* Rotating conic crystal refraction */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: "-60%", left: "-60%",
          width: "220%", height: "220%",
          background: `conic-gradient(from 0deg at 50% 50%,
            transparent 0deg,
            ${baseAccent}0D 50deg,
            transparent 110deg,
            rgba(122,231,255,0.06) 170deg,
            transparent 230deg,
            ${baseAccent}0A 300deg,
            transparent 360deg)`,
          animation: "rhCrystalConic 22s linear infinite",
          opacity: 0.9,
        }}
      />

      {/* Specular light sweep */}
      {shimmer && (
        <div
          className="absolute pointer-events-none"
          style={{
            top: 0, bottom: 0,
            width: "50%",
            left: 0,
            background: `linear-gradient(100deg, transparent 0%, ${baseAccent}14 45%, rgba(255,255,255,0.07) 50%, ${baseAccent}14 55%, transparent 100%)`,
            animation: "rhCrystalSweepX 7s ease-in-out infinite",
            animationDelay: `${Math.random() * 4}s`,
          }}
        />
      )}

      {/* Top specular edge highlight */}
      <div
        className="absolute top-0 left-0 right-0 h-px pointer-events-none"
        style={{
          background: `linear-gradient(90deg, transparent, ${baseAccent}55, rgba(122,231,255,0.30), ${baseAccent}55, transparent)`,
          animation: "rhCrystalEdgePulse 4.5s ease-in-out infinite",
        }}
      />

      {/* Content */}
      <div className={className} style={{ position: "relative", zIndex: 1 }}>
        {children}
      </div>
    </div>
  );
});