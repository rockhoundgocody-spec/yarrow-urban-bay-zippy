/**
 * EnergyParticles — Orbital particle system for Orb v3
 * Renders particles orbiting a center point with randomised speed/size/color.
 *
 * Props:
 *  count   number   — particles (capped at 16 for perf)
 *  color   string   — base particle color
 *  radius  number   — orbit radius in px
 *  active  boolean  — intensifies on true (tap/hover state)
 */

import React, { useMemo } from "react";
import { motion } from "framer-motion";

const COLORS = ["#7DF9FF", "#9B5CFF", "#00FFC6", "#FFC857"];

export default function EnergyParticles({
  count = 8,
  color,
  radius = 44,
  active = false,
}) {
  const capped = Math.min(count, 16);

  const particles = useMemo(() =>
    Array.from({ length: capped }, (_, i) => {
      const angle  = (i / capped) * 360;
      const c      = color ?? COLORS[i % COLORS.length];
      const size   = 2 + (i % 3);
      const dur    = 3 + (i % 4) * 0.8;
      const offset = (i % 2 === 0 ? 1 : -1) * (4 + (i % 3) * 6);
      return { angle, color: c, size, dur, offset };
    }),
  [capped, color]);

  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 2 }}>
      {particles.map((p, i) => {
        const rad = (p.angle * Math.PI) / 180;
        const cx = Math.cos(rad) * radius;
        const cy = Math.sin(rad) * radius;

        return (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width:  p.size,
              height: p.size,
              left:   `calc(50% + ${cx}px)`,
              top:    `calc(50% + ${cy}px)`,
              background: p.color,
              boxShadow: `0 0 ${p.size * 2}px ${p.color}`,
            }}
            animate={{
              x:       [0, p.offset, 0, -p.offset, 0],
              y:       [0, -p.offset * 0.6, p.offset, p.offset * 0.4, 0],
              opacity: active ? [0.6, 1, 0.6] : [0.25, 0.55, 0.25],
              scale:   active ? [1, 1.6, 1] : [1, 1.2, 1],
            }}
            transition={{
              duration: p.dur,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.22,
            }}
          />
        );
      })}
    </div>
  );
}