/**
 * ConfidenceRing — SVG confidence arc with animated fill.
 * Used on scan results, Geo-Dex reveals, specimen cards.
 *
 * Props:
 *   pct      number 0–100
 *   size     number (px, default 80)
 *   color    string
 *   label    string (override inner label)
 *   glow     boolean
 */
import React from "react";
import { motion } from "framer-motion";

export default function ConfidenceRing({ pct = 0, size = 80, color = "#00D68F", label, glow = true }) {
  const r    = size / 2 - 6;
  const circ = 2 * Math.PI * r;
  const dash = (Math.min(pct, 100) / 100) * circ;
  const tier = pct >= 88 ? "high" : pct >= 70 ? "mid" : pct >= 50 ? "low" : "vlow";
  const tierLabel = { high: "High", mid: "Good", low: "Low", vlow: "Weak" }[tier];

  return (
    <div className="relative flex-shrink-0 flex items-center justify-center" style={{ width: size, height: size }}>
      <svg
        width={size}
        height={size}
        style={{ position: "absolute", inset: 0, transform: "rotate(-90deg)" }}
      >
        {/* Track */}
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none"
          stroke="rgba(255,255,255,0.06)"
          strokeWidth={4}
        />
        {/* Fill arc */}
        <motion.circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none"
          stroke={color}
          strokeWidth={4}
          strokeLinecap="round"
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: circ - dash }}
          transition={{ duration: 1.4, ease: "easeOut", delay: 0.3 }}
          style={{ filter: glow ? `drop-shadow(0 0 6px ${color}99)` : "none" }}
        />
      </svg>
      {/* Inner text */}
      <div className="relative z-10 flex flex-col items-center leading-none">
        <span className="font-black" style={{ fontSize: size * 0.24, color }}>{pct}</span>
        <span style={{ fontSize: size * 0.11, color: `${color}80`, fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase" }}>
          {label ?? tierLabel}
        </span>
      </div>
    </div>
  );
}