/**
 * WipeFillBar — "Scrub clean" progress bar.
 * The fill doesn't just grow — it wipes the empty space away with a
 * sharp leading edge + shimmer sweep, giving a tactile "clearing" feel.
 *
 * Usage:
 *   <WipeFillBar value={72} max={100} color="#00D68F" label="XP Progress" />
 *
 * Props:
 *   value     — current value
 *   max       — maximum value (default 100)
 *   color     — fill color (default emerald)
 *   height    — bar height px (default 6)
 *   label     — optional label above bar
 *   showPct   — show percentage text (default true)
 *   animate   — animate on mount (default true)
 *   className
 */
import React, { useEffect } from "react";
import { motion, useSpring, useTransform } from "framer-motion";

export default function WipeFillBar({
  value = 0,
  max = 100,
  color = "#00D68F",
  height = 6,
  label,
  showPct = true,
  animate: doAnimate = true,
  className = "",
}) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100));

  // Spring-driven width for organic feel
  const springPct = useSpring(doAnimate ? 0 : pct, { stiffness: 60, damping: 18, mass: 0.8 });
  useEffect(() => { springPct.set(pct); }, [pct]);
  const widthPct = useTransform(springPct, v => `${v}%`);

  return (
    <div className={`w-full ${className}`}>
      {(label || showPct) && (
        <div className="flex items-center justify-between mb-1.5">
          {label && (
            <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.35)" }}>
              {label}
            </span>
          )}
          {showPct && (
            <motion.span
              className="text-[10px] font-black tabular-nums"
              style={{ color }}
            >
              {Math.round(pct)}%
            </motion.span>
          )}
        </div>
      )}

      {/* Track */}
      <div
        className="relative rounded-full overflow-hidden"
        style={{
          height,
          background: "rgba(255,255,255,0.06)",
          border: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        {/* Fill — the "wipe" */}
        <motion.div
          className="absolute inset-y-0 left-0 rounded-full"
          style={{
            width: widthPct,
            background: `linear-gradient(90deg, ${color}AA 0%, ${color} 80%, ${color}FF 100%)`,
            boxShadow: `0 0 8px ${color}60`,
          }}
        >
          {/* Sharp leading edge scrub line */}
          <div
            className="absolute right-0 top-0 bottom-0 w-0.5 rounded-full"
            style={{ background: "#fff", opacity: 0.5, boxShadow: `0 0 6px ${color}` }}
          />
          {/* Shimmer sweep across fill */}
          <motion.div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.25) 50%, transparent 100%)",
            }}
            animate={{ x: ["-100%", "200%"] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut", repeatDelay: 1.5 }}
          />
        </motion.div>
      </div>
    </div>
  );
}