/**
 * ScanReticle — premium hexagonal/orb scanner overlay.
 * Reference style: amethyst/cyan energy, hex relic frame, crystal glow.
 * States: idle | targeting | analyzing | identified
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const STATE_CFG = {
  idle:       { color: "rgba(141,124,255,0.65)",  glow: "rgba(141,124,255,0.18)", label: "Point at specimen",  bracketOpacity: 0.5 },
  targeting:  { color: "rgba(122,231,255,0.90)",  glow: "rgba(122,231,255,0.22)", label: "Specimen in frame",  bracketOpacity: 1.0 },
  analyzing:  { color: "rgba(141,124,255,1.0)",   glow: "rgba(141,124,255,0.30)", label: "Analyzing…",         bracketOpacity: 1.0 },
  identified: { color: "rgba(0,214,143,1.0)",     glow: "rgba(0,214,143,0.30)",   label: "Identified",         bracketOpacity: 1.0 },
};

// Hexagonal corner bracket
function HexBracket({ position, color, opacity }) {
  const arm = 24;
  const t = 2;
  const styles = {
    tl: { top: 0, left: 0, borderTop: `${t}px solid ${color}`, borderLeft: `${t}px solid ${color}` },
    tr: { top: 0, right: 0, borderTop: `${t}px solid ${color}`, borderRight: `${t}px solid ${color}` },
    bl: { bottom: 0, left: 0, borderBottom: `${t}px solid ${color}`, borderLeft: `${t}px solid ${color}` },
    br: { bottom: 0, right: 0, borderBottom: `${t}px solid ${color}`, borderRight: `${t}px solid ${color}` },
  }[position];

  return (
    <div
      className="absolute pointer-events-none"
      style={{ width: arm, height: arm, opacity, ...styles, borderRadius: 0 }}
    />
  );
}

// Rotating arc ring
function RotatingArc({ size, color, duration, reverse = false, opacity = 0.45, dashes = false }) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size, height: size,
        top: "50%", left: "50%",
        marginTop: -(size / 2), marginLeft: -(size / 2),
        border: "1.5px solid transparent",
        borderTopColor: color,
        borderRightColor: dashes ? "transparent" : color,
        opacity,
      }}
      animate={{ rotate: reverse ? -360 : 360 }}
      transition={{ duration, repeat: Infinity, ease: "linear" }}
    />
  );
}

// Crystal shard dot — orbiting accent
function CrystalShard({ index, total, radius, color, size = 4 }) {
  const angle = (index / total) * 360;
  const rad = (angle * Math.PI) / 180;
  const x = Math.cos(rad) * radius;
  const y = Math.sin(rad) * radius;
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        width: size, height: size,
        top: "50%", left: "50%",
        marginTop: -(size / 2) + y,
        marginLeft: -(size / 2) + x,
        background: color,
        borderRadius: 1,
        boxShadow: `0 0 8px ${color}`,
      }}
      animate={{ opacity: [0.3, 1, 0.3], scale: [0.7, 1.3, 0.7] }}
      transition={{ duration: 1.6 + index * 0.25, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

// Static ring
function StaticRing({ size, color, opacity, width = 1 }) {
  return (
    <div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: size, height: size,
        top: "50%", left: "50%",
        marginTop: -(size / 2), marginLeft: -(size / 2),
        border: `${width}px solid ${color}`,
        opacity,
      }}
    />
  );
}

// Scan line
function ScanLine({ boxSize, color, active }) {
  if (!active) return null;
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        left: "50%",
        width: boxSize * 0.9,
        height: 1.5,
        marginLeft: -(boxSize * 0.45),
        background: `linear-gradient(90deg, transparent, ${color}CC, transparent)`,
        boxShadow: `0 0 8px ${color}88, 0 0 16px ${color}44`,
      }}
      animate={{ top: [`${50 - (boxSize / 2) * 0.72}%`, `${50 + (boxSize / 2) * 0.72}%`] }}
      transition={{ duration: 1.8, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
    />
  );
}

// Center orb dot
function CenterDot({ color, analyzing }) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: 8, height: 8,
        top: "50%", left: "50%",
        marginTop: -4, marginLeft: -4,
        background: `radial-gradient(circle, white 0%, ${color} 60%)`,
        boxShadow: `0 0 12px ${color}, 0 0 24px ${color}88`,
      }}
      animate={analyzing
        ? { scale: [1, 1.8, 1], opacity: [0.8, 1, 0.8] }
        : { scale: [1, 1.2, 1], opacity: [0.7, 1, 0.7] }
      }
      transition={{ duration: analyzing ? 0.9 : 2.2, repeat: Infinity }}
    />
  );
}

export default function ScanReticle({ state = "idle", boxSize = 260 }) {
  const cfg = STATE_CFG[state] ?? STATE_CFG.idle;
  const isActive = state === "targeting" || state === "analyzing";
  const isAnalyzing = state === "analyzing";
  const color = cfg.color;

  return (
    <div className="relative pointer-events-none select-none" style={{ width: boxSize, height: boxSize }}>

      {/* Ambient void glow */}
      <div
        className="absolute rounded-full"
        style={{
          inset: -50,
          background: `radial-gradient(circle at 50%, ${cfg.glow}, transparent 65%)`,
          pointerEvents: "none",
        }}
      />

      {/* Outer static ring */}
      <StaticRing size={boxSize * 0.98} color={color} opacity={0.1} width={1} />

      {/* Slow rotating outer arc — violet */}
      <RotatingArc size={boxSize * 0.88} color={color} duration={24} opacity={isActive ? 0.40 : 0.20} />

      {/* Crystal shards orbiting */}
      {isActive && [0, 1, 2, 3, 4, 5].map((i) => (
        <CrystalShard
          key={i}
          index={i}
          total={6}
          radius={(boxSize * 0.44)}
          color={i % 2 === 0 ? "rgba(141,124,255,0.9)" : "rgba(122,231,255,0.9)"}
          size={i % 2 === 0 ? 4 : 3}
        />
      ))}

      {/* Inner arc — cyan counter-rotate */}
      <RotatingArc size={boxSize * 0.70} color="rgba(122,231,255,0.7)" duration={9} reverse opacity={isActive ? 0.55 : 0.25} />

      {/* Gold accent ring */}
      <StaticRing size={boxSize * 0.54} color="rgba(212,175,55,0.25)" opacity={1} width={1} />

      {/* Reticle box with hex brackets */}
      <div
        className="absolute"
        style={{
          width: boxSize * 0.62,
          height: boxSize * 0.62,
          top: "50%", left: "50%",
          marginTop: -(boxSize * 0.31),
          marginLeft: -(boxSize * 0.31),
        }}
      >
        <HexBracket position="tl" color={color} opacity={cfg.bracketOpacity} />
        <HexBracket position="tr" color={color} opacity={cfg.bracketOpacity} />
        <HexBracket position="bl" color={color} opacity={cfg.bracketOpacity} />
        <HexBracket position="br" color={color} opacity={cfg.bracketOpacity} />
      </div>

      {/* Scan line */}
      <ScanLine boxSize={boxSize * 0.62} color={color} active={isActive} />

      {/* Center orb */}
      <CenterDot color={color} analyzing={isAnalyzing} />

      {/* State label */}
      <AnimatePresence mode="wait">
        <motion.p
          key={state}
          className="absolute inset-x-0 text-center font-bold uppercase tracking-widest"
          style={{
            bottom: "8%",
            fontSize: 9,
            color,
            letterSpacing: "0.22em",
            textShadow: `0 0 12px ${color}, 0 0 24px ${color}66`,
          }}
          initial={{ opacity: 0, y: 3 }}
          animate={{ opacity: 0.9, y: 0 }}
          exit={{ opacity: 0, y: -3 }}
          transition={{ duration: 0.2 }}
        >
          {cfg.label}
        </motion.p>
      </AnimatePresence>
    </div>
  );
}