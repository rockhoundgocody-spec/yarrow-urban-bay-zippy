/**
 * FunAnimatedBackground — lively, layered animated backdrop.
 * Floating crystal shards + drifting gradient orbs + twinkle sparkles.
 * Purely decorative (pointer-events:none), performance-capped.
 */
import React, { useMemo } from "react";
import { motion } from "framer-motion";

const SHARD_COLORS = ["#8D7CFF", "#7AE7FF", "#D4AF37", "#00D68F"];

function seeded(n, seed = 1) {
  // deterministic pseudo-random so layout is stable across renders
  const x = Math.sin(seed * 999.13 + n * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

export default function FunAnimatedBackground({ variant = "amethyst", density = "normal" }) {
  const shards = useMemo(() => {
    const count = density === "dense" ? 14 : 9;
    return Array.from({ length: count }, (_, i) => {
      const s = seeded(i, 3);
      return {
        id: i,
        left: `${(seeded(i, 1) * 100).toFixed(2)}%`,
        top: `${(seeded(i, 2) * 100).toFixed(2)}%`,
        size: 14 + Math.round(seeded(i, 4) * 26),
        color: SHARD_COLORS[i % SHARD_COLORS.length],
        delay: seeded(i, 5) * 6,
        duration: 8 + seeded(i, 6) * 7,
        rotate: Math.round(seeded(i, 7) * 360),
        drift: 16 + seeded(i, 8) * 26,
      };
    });
  }, [density]);

  const sparkles = useMemo(() => {
    const count = density === "dense" ? 26 : 18;
    return Array.from({ length: count }, (_, i) => ({
      id: i,
      left: `${(seeded(i, 11) * 100).toFixed(2)}%`,
      top: `${(seeded(i, 12) * 100).toFixed(2)}%`,
      size: 1 + seeded(i, 13) * 2.4,
      delay: seeded(i, 14) * 5,
      duration: 2.4 + seeded(i, 15) * 3,
    }));
  }, [density]);

  const orbA = variant === "field" ? "#4AA354" : "#8D7CFF";
  const orbB = variant === "field" ? "#88FF99" : "#7AE7FF";
  const orbC = "#D4AF37";

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {/* Base gradient wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            variant === "field"
              ? "radial-gradient(ellipse at 30% 20%, rgba(74,163,84,0.10) 0%, transparent 55%), radial-gradient(ellipse at 70% 80%, rgba(136,255,153,0.06) 0%, transparent 50%), #010806"
              : "radial-gradient(ellipse at 30% 20%, rgba(141,124,255,0.10) 0%, transparent 55%), radial-gradient(ellipse at 70% 80%, rgba(122,231,255,0.07) 0%, transparent 50%), #04020E",
        }}
      />

      {/* Drifting gradient orbs */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 280, height: 280, left: "-6%", top: "8%",
          background: `radial-gradient(circle, ${orbA}55 0%, transparent 70%)`,
          filter: "blur(50px)",
        }}
        animate={{ x: [0, 40, 0], y: [0, 30, 0], scale: [1, 1.12, 1] }}
        transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 320, height: 320, right: "-8%", bottom: "6%",
          background: `radial-gradient(circle, ${orbB}44 0%, transparent 70%)`,
          filter: "blur(60px)",
        }}
        animate={{ x: [0, -36, 0], y: [0, -24, 0], scale: [1, 1.15, 1] }}
        transition={{ duration: 17, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute rounded-full"
        style={{
          width: 180, height: 180, left: "42%", top: "38%",
          background: `radial-gradient(circle, ${orbC}33 0%, transparent 70%)`,
          filter: "blur(44px)",
        }}
        animate={{ x: [0, 24, -18, 0], y: [0, -20, 14, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Floating crystal shards */}
      {shards.map((s) => (
        <motion.div
          key={s.id}
          className="absolute"
          style={{ left: s.left, top: s.top, width: s.size, height: s.size }}
          initial={{ opacity: 0, rotate: s.rotate, y: 0 }}
          animate={{
            opacity: [0, 0.55, 0.35, 0.55, 0],
            y: [0, -s.drift, 0],
            rotate: [s.rotate, s.rotate + 28, s.rotate],
          }}
          transition={{ duration: s.duration, delay: s.delay, repeat: Infinity, ease: "easeInOut" }}
        >
          <svg viewBox="0 0 100 100" width="100%" height="100%" fill="none">
            <polygon
              points="50,4 86,28 86,72 50,96 14,72 14,28"
              fill={`${s.color}22`}
              stroke={`${s.color}99`}
              strokeWidth="3"
            />
            <polygon points="50,4 86,28 50,52" fill={`${s.color}33`} />
            <polygon points="14,28 50,52 50,4" fill={`${s.color}1a`} />
          </svg>
        </motion.div>
      ))}

      {/* Twinkle sparkles */}
      {sparkles.map((sp) => (
        <motion.span
          key={sp.id}
          className="absolute rounded-full"
          style={{
            left: sp.left, top: sp.top, width: sp.size, height: sp.size,
            background: "rgba(255,255,255,0.9)",
            boxShadow: `0 0 ${sp.size * 3}px rgba(200,220,255,0.7)`,
          }}
          animate={{ opacity: [0, 1, 0], scale: [0.4, 1, 0.4] }}
          transition={{ duration: sp.duration, delay: sp.delay, repeat: Infinity, ease: "easeInOut" }}
        />
      ))}

      {/* Soft top sheen */}
      <div
        className="absolute inset-x-0 top-0 h-32"
        style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.04) 0%, transparent 100%)" }}
      />
    </div>
  );
}