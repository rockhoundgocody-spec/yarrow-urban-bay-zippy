/**
 * LegendaryReveal — full-screen rarity reveal ceremony.
 * Tiered: common gets nothing, rare gets a flash, epic gets a burst, legendary gets the full ceremony.
 *
 * Props:
 *  rarity        "common" | "uncommon" | "rare" | "epic" | "legendary"
 *  specimenName  string
 *  active        boolean  — trigger
 *  onDone        fn
 */

import React, { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star } from "lucide-react";
import { getRarity } from "@/theme/raritySystem";
import SuccessBurst from "@/animation/SuccessBurst";

// Common and uncommon get no overlay — just return null
const MIN_CEREMONY_TIER = ["rare", "epic", "legendary"];

function RarityLabel({ rarity, r }) {
  return (
    <motion.div
      className="flex items-center gap-2 rounded-full px-4 py-2"
      style={{ background: r.bg, border: `1px solid ${r.border}` }}
      initial={{ scale: 0.6, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 340, damping: 22, delay: 0.18 }}
    >
      <Star className="h-4 w-4" style={{ color: r.color, fill: r.color }} />
      <span className="text-sm font-bold uppercase tracking-[0.22em]" style={{ color: r.color }}>
        {r.label}
      </span>
    </motion.div>
  );
}

export default function LegendaryReveal({ rarity = "common", specimenName, active, onDone }) {
  const r = getRarity(rarity);
  const showCeremony = MIN_CEREMONY_TIER.includes(rarity);
  const isLegendary  = rarity === "legendary";
  const isEpic       = rarity === "epic";

  useEffect(() => {
    if (active && !showCeremony) { onDone?.(); return; }
    if (active) {
      const t = setTimeout(() => onDone?.(), isLegendary ? 3800 : isEpic ? 2800 : 2000);
      return () => clearTimeout(t);
    }
  }, [active, showCeremony, isLegendary, isEpic, onDone]);

  return (
    <AnimatePresence>
      {active && showCeremony && (
        <motion.div
          className="fixed inset-0 z-[350] flex flex-col items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          onClick={onDone}
        >
          {/* Blackout veil */}
          <motion.div
            className="absolute inset-0"
            style={{ background: isLegendary ? "rgba(0,0,0,0.88)" : isEpic ? "rgba(0,0,0,0.78)" : "rgba(0,0,0,0.65)" }}
          />

          {/* Legendary: solar radiance burst */}
          {isLegendary && (
            <>
              <motion.div
                className="absolute"
                style={{
                  width: 500, height: 500,
                  borderRadius: "50%",
                  background: "radial-gradient(circle, rgba(255,215,0,0.22) 0%, rgba(255,255,255,0.06) 40%, transparent 70%)",
                  filter: "blur(32px)",
                }}
                animate={{ scale: [0.6, 1.4, 1.1], opacity: [0, 1, 0.7] }}
                transition={{ duration: 1.1, ease: [0.22, 1, 0.36, 1] }}
              />
              {/* Solar rays */}
              {Array.from({ length: 12 }, (_, i) => (
                <motion.div
                  key={i}
                  className="absolute origin-center"
                  style={{
                    width: 2, height: 180,
                    background: `linear-gradient(to top, transparent, ${r.colorDim}, transparent)`,
                    rotate: `${i * 30}deg`,
                    transformOrigin: "50% 100%",
                    top: "50%", left: "50%",
                    marginLeft: -1, marginTop: -180,
                  }}
                  initial={{ opacity: 0, scaleY: 0 }}
                  animate={{ opacity: [0, 0.6, 0], scaleY: [0, 1, 0.8] }}
                  transition={{ duration: 1.6, delay: 0.2 + i * 0.04, ease: "easeOut" }}
                />
              ))}
            </>
          )}

          {/* Epic: violet spectral flash */}
          {isEpic && (
            <motion.div
              className="absolute"
              style={{
                width: 360, height: 360, borderRadius: "50%",
                background: "radial-gradient(circle, rgba(185,122,255,0.28) 0%, transparent 65%)",
                filter: "blur(24px)",
              }}
              animate={{ scale: [0.5, 1.3, 1], opacity: [0, 1, 0.6] }}
              transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
            />
          )}

          {/* Rare: cyan electric ring */}
          {rarity === "rare" && (
            <motion.div
              className="absolute rounded-full"
              style={{ width: 240, height: 240, border: `2px solid ${r.color}`, boxShadow: r.glow }}
              animate={{ scale: [0.4, 1.2, 1], opacity: [0, 1, 0.7] }}
              transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
            />
          )}

          {/* Center content */}
          <div className="relative flex flex-col items-center gap-5 px-8 text-center">
            <RarityLabel rarity={rarity} r={r} />

            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.45 }}
            >
              <div className="text-2xl font-bold text-white leading-tight max-w-[22ch]">
                {specimenName || "Specimen Identified"}
              </div>
              {isLegendary && (
                <div className="mt-2 text-sm text-amber-300/60 tracking-wide">
                  An extraordinary find.
                </div>
              )}
            </motion.div>

            {/* Particles */}
            <div className="relative h-0 w-0">
              <SuccessBurst active={active} color={r.celebrationColor} count={r.particleCount} radius={isLegendary ? 90 : isEpic ? 72 : 52} />
            </div>

            <motion.div
              className="text-[10px] text-white/25 mt-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.2 }}
            >
              tap to continue
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}