/**
 * CrystallineUnfold — subtle 3D crystalline "unfolding" entrance animation
 * matching the premium living-glass aesthetic. Triggers once when the card
 * scrolls into view. Reusable across any specimen card or glass panel.
 */
import React from "react";
import { motion } from "framer-motion";

export const crystallineUnfoldVariants = {
  hidden: { opacity: 0, rotateY: 14, rotateX: -6, scale: 0.94 },
  shown:  { opacity: 1, rotateY: 0,    rotateX: 0,    scale: 1 },
};

export const crystallineUnfoldViewport = { once: true, margin: "-40px" };
export const crystallineUnfoldTransition = { duration: 0.7, ease: [0.22, 1, 0.36, 1] };

export default function CrystallineUnfold({
  children,
  delay = 0,
  className = "",
  style,
  as = "div",
  ...rest
}) {
  const MotionTag = motion[as] || motion.div;
  return (
    <MotionTag
      variants={crystallineUnfoldVariants}
      initial="hidden"
      whileInView="shown"
      viewport={crystallineUnfoldViewport}
      transition={{ ...crystallineUnfoldTransition, delay }}
      style={{ transformPerspective: 1000, transformStyle: "preserve-3d", ...style }}
      className={className}
      {...rest}
    >
      {children}
    </MotionTag>
  );
}