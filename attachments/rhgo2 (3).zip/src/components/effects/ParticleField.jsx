import React, { useMemo } from "react";
import { motion } from "framer-motion";
import { getFXLevel } from "@/theme/performance";

function particleCount(mode, fx) {
  if (fx === "LOW") return 5;
  if (fx === "MEDIUM") return 10;
  if (mode === "scan") return 16;
  if (mode === "market") return 18;
  return 22;
}

export default function ParticleField({ mode = "adventure" }) {
  const fx = getFXLevel();
  // Empty dep array — particle positions must never re-randomize after mount (causes flash)
  const particles = useMemo(() => {
    const count = particleCount(mode, fx);
    return Array.from({ length: count }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      top: Math.random() * 100,
      size: 2 + Math.random() * 3,
      duration: 10 + Math.random() * 10,
      delay: Math.random() * 6,
      opacity: 0.10 + Math.random() * 0.18,
    }));
   
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((p) => (
        <motion.span
          key={p.id}
          className="absolute rounded-full bg-white"
          style={{
            left: `${p.left}%`,
            top: `${p.top}%`,
            width: p.size,
            height: p.size,
            opacity: p.opacity,
            filter: "blur(0.5px)",
          }}
          animate={{
            y: [0, -14, 0],
            x: [0, 6, -4, 0],
            opacity: [p.opacity * 0.6, p.opacity, p.opacity * 0.6],
            scale: [1, 1.12, 1],
          }}
          transition={{
            duration: p.duration + (fx === "LOW" ? 2 : 0),
            delay: p.delay,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      ))}
    </div>
  );
}