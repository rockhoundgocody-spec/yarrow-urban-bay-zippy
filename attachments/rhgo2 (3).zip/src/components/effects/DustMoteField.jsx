/**
 * DustMoteField — Ethereal slow-moving particle system.
 * CSS/Framer only — zero canvas overhead. Renders N floating dust motes
 * that drift lazily like underwater bubbles or spores.
 *
 * Usage:
 *   <DustMoteField count={18} color="#8D7CFF" className="absolute inset-0 pointer-events-none" />
 */
import React, { useMemo } from "react";
import { motion } from "framer-motion";

function seededRand(seed) {
  // simple deterministic pseudo-random so SSR/hydration is stable
  let s = seed;
  return () => { s = (s * 16807 + 0) % 2147483647; return (s - 1) / 2147483646; };
}

export default function DustMoteField({
  count = 18,
  color = "#8D7CFF",
  className = "",
}) {
  const motes = useMemo(() => {
    const rand = seededRand(42);
    return Array.from({ length: count }, (_, i) => {
      const size    = 1.5 + rand() * 2.5;          // px
      const x       = rand() * 100;                 // % left
      const y       = rand() * 100;                 // % top
      const dur     = 18 + rand() * 28;             // seconds per drift cycle
      const delay   = -(rand() * dur);              // stagger naturally
      const driftX  = (rand() - 0.5) * 60;         // px drift horizontal
      const driftY  = -(20 + rand() * 60);          // px drift up (bubbles rise)
      const opacity = 0.08 + rand() * 0.18;         // subtle
      return { i, size, x, y, dur, delay, driftX, driftY, opacity };
    });
  }, [count]);

  return (
    <div className={`overflow-hidden ${className}`} aria-hidden="true">
      {motes.map(({ i, size, x, y, dur, delay, driftX, driftY, opacity }) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width:  size,
            height: size,
            left:   `${x}%`,
            top:    `${y}%`,
            background: color,
            opacity,
            filter: `blur(${size * 0.4}px)`,
            willChange: "transform, opacity",
          }}
          animate={{
            x:       [0, driftX,  driftX * 0.3, 0],
            y:       [0, driftY,  driftY * 0.6, 0],
            opacity: [opacity, opacity * 1.6, opacity * 0.5, opacity],
            scale:   [1, 1.3, 0.8, 1],
          }}
          transition={{
            duration: dur,
            repeat: Infinity,
            ease: "easeInOut",
            delay,
            times: [0, 0.4, 0.7, 1],
          }}
        />
      ))}
    </div>
  );
}