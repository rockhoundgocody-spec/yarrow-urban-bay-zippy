import React, { useRef } from "react";
import { motion, useInView } from "framer-motion";

/**
 * CrystalReveal — scroll-triggered crystalline entrance for data cards.
 * One-shot: opacity + lift + subtle scale, with a diagonal shimmer sweep.
 * Wrap any card; uses viewport once for performance.
 */
export default function CrystalReveal({
  children,
  className = "",
  delay = 0,
  shimmer = true,
  entrance = true,
  clip = true,
  as = "div",
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const MotionTag = motion[as] || motion.div;

  return (
    <MotionTag
      ref={ref}
      initial={entrance ? { opacity: 0, y: 18, scale: 0.985 } : false}
      animate={entrance && inView ? { opacity: 1, y: 0, scale: 1 } : {}}
      transition={{
        duration: 0.5,
        delay,
        ease: [0.23, 1, 0.32, 1],
      }}
      className={`relative ${clip ? "overflow-hidden" : ""} ${className}`}
    >
      {children}
      {shimmer && inView && (
        <motion.span
          aria-hidden
          className="absolute inset-0 pointer-events-none z-20"
          style={{
            background:
              "linear-gradient(105deg, transparent 30%, rgba(199,208,217,0.10) 47%, rgba(122,231,255,0.14) 50%, rgba(199,208,217,0.10) 53%, transparent 70%)",
            backgroundSize: "250% 100%",
            mixBlendMode: "screen",
          }}
          initial={{ backgroundPosition: "-120% 0%" }}
          animate={{ backgroundPosition: "220% 0%" }}
          transition={{ duration: 0.9, delay: delay + 0.15, ease: "easeInOut" }}
        />
      )}
    </MotionTag>
  );
}