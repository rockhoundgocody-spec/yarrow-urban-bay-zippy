import React from "react";
import { motion } from "framer-motion";
import clsx from "clsx";

export default function ShimmerSweep({
  className = "",
  tone = "light",
  active = true,
}) {
  if (!active) return null;

  const gradient =
    tone === "cyan"
      ? "from-transparent via-cyan-100/40 to-transparent"
      : tone === "gold"
        ? "from-transparent via-amber-100/45 to-transparent"
        : "from-transparent via-white/35 to-transparent";

  return (
    <div className={clsx("pointer-events-none absolute inset-0 overflow-hidden", className)}>
      <motion.div
        className={clsx(
          "absolute -left-1/3 top-0 h-full w-1/3 rotate-[18deg] bg-gradient-to-r blur-md",
          gradient
        )}
        animate={{ x: ["-10%", "170%"] }}
        transition={{ duration: 2.2, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
}