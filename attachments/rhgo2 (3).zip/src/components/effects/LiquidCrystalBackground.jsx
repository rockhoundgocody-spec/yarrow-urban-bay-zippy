import React from "react";
import { motion } from "framer-motion";
import clsx from "clsx";
import { getFXLevel } from "@/theme/performance";

function modeClasses(mode) {
  switch (mode) {
    case "scan":
      return {
        base: "bg-[linear-gradient(180deg,#050B12_0%,#08131B_38%,#14212B_100%)]",
        orbA: "bg-cyan-300/20",
        orbB: "bg-violet-400/18",
        orbC: "bg-amber-300/14",
        orbD: "bg-sky-400/16",
      };
    case "market":
      return {
        base: "bg-[linear-gradient(180deg,#08131B_0%,#101B2B_45%,#14212B_100%)]",
        orbA: "bg-amber-300/18",
        orbB: "bg-orange-400/14",
        orbC: "bg-cyan-300/12",
        orbD: "bg-violet-400/12",
      };
    case "twilight":
      return {
        base: "bg-[linear-gradient(180deg,#071019_0%,#0D1826_42%,#14212B_100%)]",
        orbA: "bg-sky-300/18",
        orbB: "bg-violet-400/18",
        orbC: "bg-amber-300/12",
        orbD: "bg-teal-300/12",
      };
    default:
      return {
        base: "bg-[linear-gradient(180deg,#071019_0%,#0D1826_42%,#14212B_100%)]",
        orbA: "bg-cyan-300/18",
        orbB: "bg-violet-400/18",
        orbC: "bg-amber-300/12",
        orbD: "bg-teal-300/12",
      };
  }
}

export default function LiquidCrystalBackground({ mode = "adventure" }) {
  const classes = modeClasses(mode);
  const fx = getFXLevel();

  return (
    <div className={clsx("absolute inset-0 overflow-hidden", classes.base)}>
      <motion.div
        className={clsx("absolute -top-20 -left-12 h-80 w-80 rounded-full blur-3xl", classes.orbA)}
        animate={{
          x: [0, 14, -8, 0],
          y: [0, 10, 18, 0],
          scale: [1, 1.05, 0.98, 1],
          opacity: [0.28, 0.40, 0.28],
        }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className={clsx("absolute top-1/4 -right-20 h-96 w-96 rounded-full blur-3xl", classes.orbB)}
        animate={{
          x: [0, -16, 6, 0],
          y: [0, -10, 8, 0],
          scale: [1, 0.97, 1.04, 1],
          opacity: [0.20, 0.32, 0.20],
        }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className={clsx("absolute bottom-0 left-1/4 h-72 w-72 rounded-full blur-3xl", classes.orbC)}
        animate={{
          x: [0, 14, -8, 0],
          y: [0, -8, 8, 0],
          scale: [1, 1.03, 0.97, 1],
          opacity: [0.14, 0.24, 0.14],
        }}
        transition={{ duration: 24, repeat: Infinity, ease: "easeInOut" }}
      />

      {fx === "HIGH" && (
        <motion.div
          className={clsx("absolute bottom-10 right-1/3 h-64 w-64 rounded-full blur-2xl", classes.orbD)}
          animate={{
            x: [0, 14, -18, 0],
            y: [0, 8, -10, 0],
            scale: [1, 1.06, 0.96, 1],
            opacity: [0.18, 0.36, 0.18],
          }}
          transition={{ duration: 24, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      <motion.div
        className="absolute inset-0 mix-blend-screen opacity-[0.05]"
        style={{
          backgroundImage:
            "linear-gradient(115deg, transparent 0%, rgba(255,255,255,0.4) 25%, transparent 50%, rgba(91,192,255,0.25) 80%, transparent 100%)",
          backgroundSize: "200% 200%",
        }}
        animate={{
          backgroundPosition: ["0% 0%", "100% 100%", "0% 0%"],
        }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
      />
    </div>
  );
}