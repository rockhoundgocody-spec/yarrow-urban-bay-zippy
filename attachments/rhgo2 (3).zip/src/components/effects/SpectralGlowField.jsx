import React from "react";
import { motion } from "framer-motion";

export default function SpectralGlowField({
  mode = "default",
}) {
  const config =
    mode === "orb"
      ? {
          a: "bg-cyan-300/18",
          b: "bg-violet-400/16",
          c: "bg-amber-300/10",
        }
      : mode === "clover"
        ? {
            a: "bg-violet-400/18",
            b: "bg-cyan-300/14",
            c: "bg-fuchsia-300/10",
          }
        : mode === "contour"
          ? {
              a: "bg-cyan-300/14",
              b: "bg-white/10",
              c: "bg-violet-300/10",
            }
          : {
              a: "bg-cyan-300/14",
              b: "bg-violet-400/12",
              c: "bg-amber-300/10",
            };

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <motion.div
        className={`absolute -left-3 top-0 h-10 w-10 rounded-full blur-xl ${config.a}`}
        animate={{ x: [0, 8, -4, 0], y: [0, 6, -2, 0], opacity: [0.35, 0.7, 0.35] }}
        transition={{ duration: 5.8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className={`absolute right-0 top-2 h-9 w-9 rounded-full blur-xl ${config.b}`}
        animate={{ x: [0, -6, 4, 0], y: [0, -4, 4, 0], opacity: [0.28, 0.6, 0.28] }}
        transition={{ duration: 6.8, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className={`absolute bottom-0 left-1/3 h-8 w-8 rounded-full blur-xl ${config.c}`}
        animate={{ x: [0, 6, -5, 0], y: [0, -5, 3, 0], opacity: [0.2, 0.45, 0.2] }}
        transition={{ duration: 7.4, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}