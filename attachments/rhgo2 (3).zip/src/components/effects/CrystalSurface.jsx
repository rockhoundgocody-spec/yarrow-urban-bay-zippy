/**
 * CrystalSurface — reusable liquid-crystal glass panel primitive.
 *
 * Replaces ad-hoc glass divs. All transparency + glow + shimmer behaviour
 * lives here so it stays off the main thread paint budget.
 *
 * Props:
 *   glow      — "none" | "crystal" | "amethyst" | "aurora" | "gold" | "magma" | "sapphire"
 *   depth     — "micro" | "low" | "med" | "high"
 *   shimmer   — boolean (animated light sweep, ~6s)
 *   topo      — boolean (animated holographic border edge)
 *   className / style / onClick / children
 */
import React, { useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { CRYSTAL, SHADOWS } from "@/theme/crystalSystem";
import { fxFlags } from "@/theme/performance";

const GLOW_MAP = {
  none:      null,
  crystal:   CRYSTAL.glowAqua,
  amethyst:  CRYSTAL.glowAmethyst,
  aurora:    CRYSTAL.glowAurora,
  gold:      CRYSTAL.glowGold,
  magma:     CRYSTAL.glowMagma,
  sapphire:  CRYSTAL.glowSapphire,
};

const BG_MAP = {
  micro: CRYSTAL.glassMicro,
  low:   CRYSTAL.glassLow,
  med:   CRYSTAL.glassMed,
  high:  CRYSTAL.glassHigh,
};

const BORDER_MAP = {
  none:      CRYSTAL.glassBorder,
  crystal:   CRYSTAL.glassBorderAccent,
  amethyst:  "rgba(155,92,255,0.28)",
  aurora:    "rgba(0,255,198,0.28)",
  gold:      "rgba(255,200,87,0.28)",
  magma:     "rgba(255,106,61,0.28)",
  sapphire:  "rgba(91,192,255,0.28)",
};

export default function CrystalSurface({
  children,
  className = "",
  style = {},
  glow = "none",
  depth = "med",
  shimmer = false,
  topo = false,
  interactive = false,
  onClick,
  rounded = "rounded-2xl",
  padding = "",
}) {
  const fx = fxFlags();
  const shimCtrl = useAnimation();
  const intRef = useRef(null);

  useEffect(() => {
    if (!shimmer || !fx.shimmer) return;
    const run = () =>
      shimCtrl.start({ x: ["−120%", "200%"], transition: { duration: 0.8, ease: "easeInOut" } });
    run();
    intRef.current = setInterval(run, 6000);
    return () => clearInterval(intRef.current);
  }, [shimmer, fx.shimmer, shimCtrl]);

  const bg     = BG_MAP[depth] ?? BG_MAP.med;
  const border = BORDER_MAP[glow] ?? CRYSTAL.glassBorder;
  const glowV  = GLOW_MAP[glow];

  const shadow = [
    SHADOWS.card,
    glowV && fx.heavyGlow ? `0 0 24px ${glowV}, 0 0 60px ${glowV.replace(/[\d.]+\)$/, "0.08)")}` : null,
  ].filter(Boolean).join(", ");

  return (
    <motion.div
      className={`relative overflow-hidden ${rounded} ${padding} ${className}`}
      style={{
        background: bg,
        border: `1px solid ${border}`,
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        boxShadow: shadow,
        cursor: interactive ? "pointer" : undefined,
        willChange: "transform",
        ...style,
      }}
      onClick={onClick}
      whileTap={interactive ? { scale: 0.975 } : undefined}
      animate={interactive ? undefined : undefined}
    >
      {/* Inner top sheen */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 rounded-t-inherit h-px"
        style={{ background: "linear-gradient(90deg, transparent 10%, rgba(255,255,255,0.12) 50%, transparent 90%)" }}
      />

      {/* Shimmer sweep */}
      {shimmer && fx.shimmer && (
        <motion.div
          className="pointer-events-none absolute inset-y-0 w-20"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.07), transparent)",
            transform: "skewX(-14deg)",
          }}
          animate={shimCtrl}
          initial={{ x: "-120%" }}
        />
      )}

      {/* Topo holographic border */}
      {topo && (
        <motion.div
          className="pointer-events-none absolute inset-0 rounded-inherit"
          style={{
            background: "transparent",
            padding: 1,
            WebkitMask: "linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)",
            WebkitMaskComposite: "xor",
            maskComposite: "exclude",
          }}
          animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
        />
      )}

      {/* Anisotropic inner edge glow */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.09), inset 0 -1px 0 rgba(255,255,255,0.03)",
        }}
      />

      <div className="relative z-10">{children}</div>
    </motion.div>
  );
}