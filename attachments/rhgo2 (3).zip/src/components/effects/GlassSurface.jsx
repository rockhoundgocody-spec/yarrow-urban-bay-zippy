/**
 * GlassSurface — canonical blur/tint overlay shell
 * Replaces: custom backdrop-blur wrappers, action sheet surfaces, overlay divs
 */
import React from "react";

const TONE = {
  dark:   { bg: "rgba(8,19,27,0.82)",   border: "rgba(255,255,255,0.10)" },
  medium: { bg: "rgba(15,27,42,0.72)",  border: "rgba(255,255,255,0.10)" },
  light:  { bg: "rgba(255,255,255,0.10)",border: "rgba(255,255,255,0.14)" },
  mist:   { bg: "rgba(91,192,255,0.12)", border: "rgba(255,255,255,0.14)" },
  field:  { bg: "rgba(13,31,15,0.88)",  border: "rgba(74,163,84,0.25)" },
};

const RADIUS = {
  sm: 14, md: 20, lg: 24, xl: 28, hero: 32,
};

export default function GlassSurface({
  children,
  tone = "dark",
  blur = 20,
  rounded = "xl",
  shadow = true,
  padded = true,
  className = "",
  style = {},
  as: Tag = "div",
  ...props
}) {
  const t = TONE[tone] ?? TONE.dark;
  const r = RADIUS[rounded] ?? 28;
  return (
    <Tag
      className={className}
      style={{
        background: t.bg,
        backdropFilter: `blur(${blur}px)`,
        WebkitBackdropFilter: `blur(${blur}px)`,
        border: `1px solid ${t.border}`,
        borderRadius: r,
        boxShadow: shadow ? "0 8px 40px rgba(0,0,0,0.55), inset 0 1px 0 rgba(199,208,217,0.07)" : undefined,
        padding: padded ? "16px" : undefined,
        ...style,
      }}
      {...props}
    >
      {children}
    </Tag>
  );
}