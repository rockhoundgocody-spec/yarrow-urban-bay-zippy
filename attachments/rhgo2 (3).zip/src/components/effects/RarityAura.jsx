/**
 * RarityAura — pulsing aura ring tuned to specimen rarity tier.
 * Mount as absolute overlay inside any card, map pin, or orb.
 *
 * Props:
 *  rarity   "common" | "uncommon" | "rare" | "epic" | "legendary"
 *  size     number   — diameter in px (default 80)
 *  active   boolean  — pauses animation when false
 */

import React from "react";
import { motion } from "framer-motion";
import { getRarity } from "@/theme/raritySystem";

export default function RarityAura({ rarity = "common", size = 80, active = true }) {
  const r = getRarity(rarity);
  const isLegendary = rarity === "legendary";
  const isEpic      = rarity === "epic";

  return (
    <div
      className="pointer-events-none absolute inset-0 flex items-center justify-center"
      style={{ zIndex: 0 }}
    >
      {/* Base glow orb */}
      <motion.div
        style={{
          width:  size,
          height: size,
          borderRadius: "50%",
          background: `radial-gradient(circle, ${r.colorDim} 0%, transparent 70%)`,
          filter: "blur(12px)",
        }}
        animate={active ? {
          scale:   r.auraScale,
          opacity: [0.55, 0.90, 0.55],
        } : { scale: 1, opacity: 0.4 }}
        transition={{ duration: r.auraSpeed, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Ring 1 */}
      <motion.div
        className="absolute rounded-full"
        style={{
          width:  size * 1.1,
          height: size * 1.1,
          border: `1.5px solid ${r.border}`,
          boxShadow: r.glow,
        }}
        animate={active ? {
          scale:   [1, 1.08, 1],
          opacity: [0.6, 1, 0.6],
        } : {}}
        transition={{ duration: r.auraSpeed * 0.9, repeat: Infinity, ease: "easeInOut" }}
      />

      {/* Ring 2 — only rare+ */}
      {(isEpic || isLegendary || rarity === "rare") && (
        <motion.div
          className="absolute rounded-full"
          style={{
            width:  size * 1.28,
            height: size * 1.28,
            border: `1px solid ${r.colorDim}`,
          }}
          animate={active ? {
            scale:   [1, 1.12, 1],
            opacity: [0.3, 0.65, 0.3],
            rotate:  [0, 180, 360],
          } : {}}
          transition={{
            scale:   { duration: r.auraSpeed * 1.2, repeat: Infinity, ease: "easeInOut" },
            opacity: { duration: r.auraSpeed * 1.2, repeat: Infinity, ease: "easeInOut" },
            rotate:  { duration: r.auraSpeed * 3, repeat: Infinity, ease: "linear" },
          }}
        />
      )}

      {/* Legendary outer solar ring */}
      {isLegendary && (
        <motion.div
          className="absolute rounded-full"
          style={{
            width:  size * 1.55,
            height: size * 1.55,
            border: "1px solid rgba(255,215,0,0.18)",
            boxShadow: "0 0 40px rgba(255,215,0,0.25)",
          }}
          animate={active ? {
            scale:   [1, 1.06, 1],
            opacity: [0.2, 0.55, 0.2],
            rotate:  [360, 0],
          } : {}}
          transition={{
            scale:   { duration: 2.4, repeat: Infinity, ease: "easeInOut" },
            opacity: { duration: 2.4, repeat: Infinity, ease: "easeInOut" },
            rotate:  { duration: r.auraSpeed * 4, repeat: Infinity, ease: "linear" },
          }}
        />
      )}
    </div>
  );
}