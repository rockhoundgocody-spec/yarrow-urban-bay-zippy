import React from "react";
import { motion } from "framer-motion";
import { getFXLevel } from "@/theme/performance";

export default function RadiantPulseLayer() {
  const fx = getFXLevel();
  const opacity = fx === "LOW" ? [0.1, 0.18, 0.1] : [0.14, 0.26, 0.14];

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <motion.div
        className="absolute left-1/2 top-1/2 h-[70vh] w-[70vh] -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-300/10 blur-2xl"
        animate={{
          scale: [0.92, 1.06, 0.92],
          opacity: [opacity[0] * 1.3, opacity[1] * 1.3, opacity[0] * 1.3],
        }}
        transition={{
          duration: 8.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className="absolute left-[52%] top-[48%] h-[55vh] w-[55vh] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-400/10 blur-2xl"
        animate={{
          scale: [1, 1.12, 1],
          opacity: opacity,
        }}
        transition={{
          duration: 10.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
    </div>
  );
}