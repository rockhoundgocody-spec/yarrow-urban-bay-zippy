/**
 * GeologyFieldGrid v2 — sophisticated terrain intelligence grid.
 * Wave-like topology emergence with depth fog and atmospheric perspective.
 */
import React, { useMemo } from 'react';
import { motion } from 'framer-motion';

export default function GeologyFieldGrid({ isActive }) {
  const gridPoints = useMemo(() => {
    const points = [];
    const cols = 28, rows = 18;
    for (let i = 0; i < cols; i++) {
      for (let j = 0; j < rows; j++) {
        const x = (i / (cols - 1)) * 100;
        const y = (j / (rows - 1)) * 100;
        const distFromCenter = Math.sqrt(Math.pow(x - 50, 2) + Math.pow(y - 50, 2));
        const noise = Math.sin(i * 0.25) * Math.cos(j * 0.18) * (1 - distFromCenter / 70);
        points.push({
          x,
          y,
          delay: (i + j) * 0.012 + (distFromCenter / 70) * 0.3,
          noise,
          depth: distFromCenter / 70,
        });
      }
    }
    return points;
  }, []);

  return (
    <svg
      viewBox="0 0 100 100"
      className="absolute inset-0 w-full h-full opacity-0"
      style={{ perspective: '1400px' }}
    >
      <defs>
        {/* Depth-based gradient for atmospheric perspective */}
        <linearGradient id="terrainGradientPrimary" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#7AE7FF" stopOpacity="0.5" />
          <stop offset="50%" stopColor="#8D7CFF" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#00D68F" stopOpacity="0.2" />
        </linearGradient>
        <linearGradient id="terrainGradientSecondary" x1="100%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#8D7CFF" stopOpacity="0.4" />
          <stop offset="100%" stopColor="#7AE7FF" stopOpacity="0.15" />
        </linearGradient>

        {/* Fog/depth filter */}
        <filter id="terrainFog" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="0.5" />
          <feComponentTransfer>
            <feFuncA type="linear" slope="0.5" />
          </feComponentTransfer>
        </filter>
        <filter id="terrainGlowHigh" x="-100%" y="-100%" width="300%" height="300%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="0.8" />
        </filter>
      </defs>

      {/* Grid lines — topology mesh */}
      {gridPoints.map((p, i) => {
        const nextRight = gridPoints.find(
          (pt) => Math.abs(pt.x - (p.x + 100 / 28)) < 1.5 && Math.abs(pt.y - p.y) < 1
        );
        const nextDown = gridPoints.find(
          (pt) => Math.abs(pt.x - p.x) < 1.5 && Math.abs(pt.y - (p.y + 100 / 18)) < 1
        );

        return (
          <g key={i}>
            {nextRight && (
              <motion.line
                x1={p.x}
                y1={p.y + p.noise * 2.5}
                x2={nextRight.x}
                y2={nextRight.y + nextRight.noise * 2.5}
                stroke={p.depth < 0.5 ? 'url(#terrainGradientPrimary)' : 'url(#terrainGradientSecondary)'}
                strokeWidth={p.depth < 0.3 ? '0.2' : p.depth < 0.6 ? '0.15' : '0.1'}
                opacity={0}
                filter="url(#terrainFog)"
                initial={{ opacity: 0 }}
                animate={isActive ? { opacity: p.depth < 0.5 ? 0.55 : 0.3 } : { opacity: 0 }}
                transition={{
                  delay: p.delay,
                  duration: 1.6,
                  ease: [0.25, 0.46, 0.45, 0.94],
                }}
              />
            )}
            {nextDown && (
              <motion.line
                x1={p.x}
                y1={p.y + p.noise * 2.5}
                x2={nextDown.x}
                y2={nextDown.y + nextDown.noise * 2.5}
                stroke={p.depth < 0.5 ? 'url(#terrainGradientPrimary)' : 'url(#terrainGradientSecondary)'}
                strokeWidth={p.depth < 0.3 ? '0.2' : p.depth < 0.6 ? '0.15' : '0.1'}
                opacity={0}
                filter="url(#terrainFog)"
                initial={{ opacity: 0 }}
                animate={isActive ? { opacity: p.depth < 0.5 ? 0.55 : 0.3 } : { opacity: 0 }}
                transition={{
                  delay: p.delay,
                  duration: 1.6,
                  ease: [0.25, 0.46, 0.45, 0.94],
                }}
              />
            )}
          </g>
        );
      })}

      {/* Luminous terrain points — sparse, high-value highlights */}
      {gridPoints
        .filter((_, i) => i % 4 === 0 && Math.random() > 0.6)
        .map((p, i) => (
          <motion.circle
            key={`point-${i}`}
            cx={p.x}
            cy={p.y + p.noise * 2.5}
            r={p.depth < 0.4 ? '0.12' : '0.06'}
            fill={p.depth < 0.4 ? 'url(#terrainGradientPrimary)' : 'url(#terrainGradientSecondary)'}
            opacity={0}
            filter="url(#terrainGlowHigh)"
            initial={{ opacity: 0, r: 0.02 }}
            animate={isActive ? { opacity: 0.8, r: p.depth < 0.4 ? 0.12 : 0.06 } : { opacity: 0 }}
            transition={{
              delay: p.delay + 0.3,
              duration: 1.2,
              ease: 'easeOut',
            }}
          />
        ))}

      {/* Atmospheric depth haze — far-field fade */}
      <motion.defs>
        <radialGradient id="depthHaze" cx="50%" cy="50%" r="100%">
          <stop offset="0%" stopColor="rgba(0,0,0,0)" stopOpacity="0" />
          <stop offset="70%" stopColor="rgba(0,0,0,0.2)" stopOpacity="0.15" />
          <stop offset="100%" stopColor="rgba(0,0,0,0.6)" stopOpacity="0.5" />
        </radialGradient>
      </motion.defs>
      <rect
        x="0"
        y="0"
        width="100"
        height="100"
        fill="url(#depthHaze)"
        opacity={isActive ? 0.6 : 0}
      />
    </svg>
  );
}