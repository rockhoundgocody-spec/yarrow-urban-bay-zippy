/**
 * CrystalFieldLayer — Global Animated Background
 *
 * Layers:
 *  1. Deep void base
 *  2. Spectral gradient mesh (slow drift)
 *  3. Noise shimmer (CSS-based, zero JS cost)
 *  4. Particle dust (capped at 12 for perf)
 *
 * Props:
 *  intensity: "low" | "med" | "high"  (default "med")
 *  speed: number 0–1  (default 0.4)
 *  colorMode: "crystal" | "amethyst" | "aurora" | "magma"
 */

import React, { useMemo } from "react";
import { motion } from "framer-motion";
import { getFXLevel } from "@/theme/performance";

const ORB_CONFIGS = {
  crystal:  [
    { color: "rgba(125,249,255,0.18)", size: 520, x: "15%",  y: "10%",  dur: 18 },
    { color: "rgba(155,92,255,0.14)",  size: 380, x: "70%",  y: "60%",  dur: 22 },
    { color: "rgba(0,255,198,0.10)",   size: 300, x: "45%",  y: "80%",  dur: 26 },
  ],
  amethyst: [
    { color: "rgba(155,92,255,0.22)",  size: 500, x: "20%",  y: "15%",  dur: 20 },
    { color: "rgba(125,249,255,0.10)", size: 340, x: "75%",  y: "55%",  dur: 24 },
    { color: "rgba(255,106,61,0.08)",  size: 260, x: "50%",  y: "75%",  dur: 28 },
  ],
  aurora:   [
    { color: "rgba(0,255,198,0.20)",   size: 480, x: "10%",  y: "20%",  dur: 16 },
    { color: "rgba(125,249,255,0.12)", size: 360, x: "65%",  y: "50%",  dur: 20 },
    { color: "rgba(155,92,255,0.10)",  size: 280, x: "40%",  y: "85%",  dur: 24 },
  ],
  magma:    [
    { color: "rgba(255,106,61,0.18)",  size: 460, x: "25%",  y: "5%",   dur: 17 },
    { color: "rgba(255,200,87,0.12)",  size: 320, x: "60%",  y: "65%",  dur: 21 },
    { color: "rgba(155,92,255,0.10)",  size: 290, x: "35%",  y: "80%",  dur: 25 },
  ],
};

const INTENSITY_OPACITY = { low: 0.55, med: 0.80, high: 1.0 };
const PARTICLE_COUNT    = { low: 0,    med: 8,    high: 12  };

function Particle({ x, y, size, dur, color }) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{ left: x, top: y, width: size, height: size, background: color }}
      animate={{ y: [0, -18, 0], opacity: [0, 0.7, 0] }}
      transition={{ duration: dur, repeat: Infinity, delay: Math.random() * dur, ease: "easeInOut" }}
    />
  );
}

export default function CrystalFieldLayer({
  intensity = "med",
  speed = 0.4,
  colorMode = "crystal",
}) {
  const fxLevel    = getFXLevel();
  const effectiveIntensity = fxLevel === "low" ? "low" : intensity;
  const orbOpacity = INTENSITY_OPACITY[effectiveIntensity] ?? 0.8;
  const particleCount = PARTICLE_COUNT[effectiveIntensity] ?? 8;
  const orbDurScale = 1 / Math.max(0.1, speed);
  const orbs = ORB_CONFIGS[colorMode] ?? ORB_CONFIGS.crystal;

  // Deterministic particles (avoid re-generation on re-render)
  const particles = useMemo(() => {
    if (particleCount === 0) return [];
    return Array.from({ length: particleCount }, (_, i) => ({
      id: i,
      x: `${5 + ((i * 37) % 90)}%`,
      y: `${10 + ((i * 53) % 80)}%`,
      size: 2 + (i % 3),
      dur: 6 + (i % 4) * 2,
      color: i % 3 === 0 ? "rgba(125,249,255,0.6)" : i % 3 === 1 ? "rgba(155,92,255,0.5)" : "rgba(0,255,198,0.5)",
    }));
  }, [particleCount]);

  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden"
      aria-hidden="true"
      style={{ zIndex: 0 }}
    >
      {/* Layer 1 — void base (handled by AppShell bg) */}

      {/* Layer 2 — spectral gradient orbs */}
      <div style={{ opacity: orbOpacity }}>
        {orbs.map((orb, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              left: orb.x,
              top:  orb.y,
              width:  orb.size,
              height: orb.size,
              background: `radial-gradient(circle, ${orb.color} 0%, transparent 70%)`,
              transform: "translate(-50%, -50%)",
              filter: "blur(2px)",
            }}
            animate={{
              x: [0, 30, -20, 0],
              y: [0, -25, 18, 0],
              scale: [1, 1.08, 0.96, 1],
            }}
            transition={{
              duration: orb.dur * orbDurScale,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 1.8,
            }}
          />
        ))}
      </div>

      {/* Layer 3 — noise shimmer (CSS only, zero cost) */}
      {effectiveIntensity !== "low" && (
        <div
          className="absolute inset-0"
          style={{
            background: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E\")",
            opacity: 0.025,
            mixBlendMode: "overlay",
          }}
        />
      )}

      {/* Layer 4 — particle dust */}
      {particles.map(p => (
        <Particle key={p.id} {...p} />
      ))}

      {/* Vignette */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(ellipse at center, transparent 40%, rgba(5,7,10,0.6) 100%)",
        }}
      />
    </div>
  );
}