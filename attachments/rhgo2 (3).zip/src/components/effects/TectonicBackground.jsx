/**
 * TectonicBackground — Living ambient background for RockHound-GO
 * 
 * Renders a slow-shifting, liquid-deep-earth animation at very low opacity.
 * Positioned absolutely, zero pointer events, GPU-composited.
 * Designed to be always visible through glass panels for visual depth.
 */
import React from "react";
import { motion } from "framer-motion";

export default function TectonicBackground({ mode = "home" }) {
  const isField = mode === "field";

  return (
    <div
      className="absolute inset-0 pointer-events-none overflow-hidden"
      style={{ zIndex: 0 }}
      aria-hidden="true"
    >
      {/* Slow liquid magma/mercury blobs */}
      <motion.div
        style={{
          position: "absolute",
          width: 380, height: 380,
          borderRadius: "61% 39% 70% 30% / 42% 55% 45% 58%",
          background: isField
            ? "radial-gradient(ellipse at 40% 40%, rgba(74,163,84,0.09) 0%, transparent 70%)"
            : "radial-gradient(ellipse at 40% 40%, rgba(141,124,255,0.10) 0%, transparent 70%)",
          filter: "blur(40px)",
          top: "-10%", left: "-15%",
        }}
        animate={{
          borderRadius: [
            "61% 39% 70% 30% / 42% 55% 45% 58%",
            "44% 56% 38% 62% / 58% 40% 60% 42%",
            "67% 33% 55% 45% / 35% 65% 35% 65%",
            "61% 39% 70% 30% / 42% 55% 45% 58%",
          ],
          x: [0, 20, -10, 0],
          y: [0, 15, -8, 0],
        }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        style={{
          position: "absolute",
          width: 320, height: 320,
          borderRadius: "38% 62% 45% 55% / 60% 38% 62% 40%",
          background: isField
            ? "radial-gradient(ellipse at 55% 55%, rgba(136,255,153,0.06) 0%, transparent 70%)"
            : "radial-gradient(ellipse at 55% 55%, rgba(122,231,255,0.07) 0%, transparent 70%)",
          filter: "blur(50px)",
          bottom: "5%", right: "-10%",
        }}
        animate={{
          borderRadius: [
            "38% 62% 45% 55% / 60% 38% 62% 40%",
            "56% 44% 60% 40% / 42% 58% 42% 58%",
            "45% 55% 35% 65% / 58% 42% 60% 40%",
            "38% 62% 45% 55% / 60% 38% 62% 40%",
          ],
          x: [0, -18, 12, 0],
          y: [0, -12, 20, 0],
        }}
        transition={{ duration: 34, repeat: Infinity, ease: "easeInOut", delay: 4 }}
      />

      <motion.div
        style={{
          position: "absolute",
          width: 260, height: 260,
          borderRadius: "52% 48% 60% 40% / 48% 52% 48% 52%",
          background: isField
            ? "radial-gradient(ellipse at 50% 50%, rgba(74,163,84,0.05) 0%, transparent 70%)"
            : "radial-gradient(ellipse at 50% 50%, rgba(212,175,55,0.06) 0%, transparent 70%)",
          filter: "blur(45px)",
          top: "35%", left: "20%",
        }}
        animate={{
          borderRadius: [
            "52% 48% 60% 40% / 48% 52% 48% 52%",
            "40% 60% 45% 55% / 60% 40% 55% 45%",
            "58% 42% 52% 48% / 44% 56% 44% 56%",
            "52% 48% 60% 40% / 48% 52% 48% 52%",
          ],
          x: [0, 12, -14, 0],
          y: [0, -20, 10, 0],
        }}
        transition={{ duration: 24, repeat: Infinity, ease: "easeInOut", delay: 8 }}
      />

      {/* Tectonic fault grid — ultra faint */}
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 430 900"
        preserveAspectRatio="xMidYMid slice"
        fill="none"
        style={{ opacity: 0.55 }}
      >
        {[
          "M0,180 Q140,160 280,185 T430,200",
          "M0,340 Q160,315 320,345 T430,360",
          "M0,500 Q180,475 340,505 T430,520",
          "M0,660 Q150,640 300,665 T430,680",
          "M80,0 Q105,200 75,900",
          "M210,0 Q235,300 195,900",
          "M360,0 Q380,400 345,900",
        ].map((d, i) => (
          <motion.path
            key={i}
            d={d}
            stroke={isField ? "rgba(74,163,84,0.05)" : "rgba(141,124,255,0.055)"}
            strokeWidth="1"
            initial={{ opacity: 0.03 }}
            animate={{ opacity: [0.03, 0.07, 0.03] }}
            transition={{
              duration: 12 + i * 1.5,
              delay: i * 0.8,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
        ))}
      </svg>
    </div>
  );
}