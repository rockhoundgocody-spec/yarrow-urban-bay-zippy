import React from "react";
import { motion } from "framer-motion";

/**
 * CrystallineNavSheen — subtle living edge for the navigation bar.
 * A breathing top specular line + slow diagonal shimmer sweep.
 * Pure decoration: pointer-events-none, absolute, sits above header bg.
 */
export default function CrystallineNavSheen({ field = false }) {
  const accent = field ? "74,163,84" : "141,124,255";
  const accent2 = field ? "136,255,153" : "122,231,255";
  return (
    <div aria-hidden className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 1 }}>
      {/* Breathing top specular edge */}
      <motion.div
        className="absolute inset-x-0 top-0 h-px"
        style={{
          background: `linear-gradient(90deg, transparent, rgba(${accent},0.55), rgba(${accent2},0.35), transparent)`,
        }}
        animate={{ opacity: [0.5, 0.9, 0.5] }}
        transition={{ duration: 4.5, ease: "easeInOut", repeat: Infinity }}
      />
      {/* Slow diagonal shimmer sweep */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            `linear-gradient(100deg, transparent 40%, rgba(${accent2},0.05) 48%, rgba(199,208,217,0.06) 50%, rgba(${accent2},0.05) 52%, transparent 60%)`,
          backgroundSize: "280% 100%",
        }}
        animate={{ backgroundPosition: ["-80% 0%", "180% 0%"] }}
        transition={{ duration: 9, ease: "easeInOut", repeat: Infinity, repeatDelay: 5 }}
      />
    </div>
  );
}