/**
 * ScanRingSystem — GPU-friendly concentric scan ring overlay.
 * Renders scan states: idle, targeting, analyzing, identified, uncertain, error, offline.
 * Uses CSS transforms + opacity only — no layout thrash.
 *
 * Props:
 *   state    — ScanState key (see crystalSystem.SCAN_STATES)
 *   size     — number (px, default 280)
 *   showText — boolean
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SCAN_STATES } from "@/theme/crystalSystem";
import { fxFlags } from "@/theme/performance";

const RING_CONFIGS = [
  { r: 0.48, opacity: 0.55, delay: 0,    width: 1.5 },
  { r: 0.62, opacity: 0.40, delay: 0.15, width: 1 },
  { r: 0.76, opacity: 0.28, delay: 0.30, width: 1 },
  { r: 0.90, opacity: 0.16, delay: 0.45, width: 0.75 },
];

function PulseRing({ size, color, r, opacity, delay, width }) {
  const d = size * r;
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: d, height: d,
        top: "50%", left: "50%",
        transform: "translate(-50%, -50%)",
        border: `${width}px solid ${color}`,
        opacity: 0,
      }}
      animate={{
        opacity: [0, opacity, 0],
        scale:   [0.85, 1.0, 1.15],
      }}
      transition={{
        duration: 2.4,
        repeat: Infinity,
        delay,
        ease: "easeOut",
      }}
    />
  );
}

function CornerBrackets({ size, color }) {
  const s = size * 0.38;
  const arm = s * 0.28;
  const corners = [
    { top: "50%", left: "50%", mt: -(s / 2), ml: -(s / 2), borderT: true, borderL: true },
    { top: "50%", left: "50%", mt: -(s / 2), ml: s / 2 - arm, borderT: true, borderR: true },
    { top: "50%", left: "50%", mt: s / 2 - arm, ml: -(s / 2), borderB: true, borderL: true },
    { top: "50%", left: "50%", mt: s / 2 - arm, ml: s / 2 - arm, borderB: true, borderR: true },
  ];

  return (
    <>
      {corners.map((c, i) => (
        <div
          key={i}
          className="absolute pointer-events-none"
          style={{
            width: arm, height: arm,
            top: c.top, left: c.left,
            marginTop: c.mt, marginLeft: c.ml,
            borderTop:    c.borderT ? `2px solid ${color}` : "none",
            borderLeft:   c.borderL ? `2px solid ${color}` : "none",
            borderBottom: c.borderB ? `2px solid ${color}` : "none",
            borderRight:  c.borderR ? `2px solid ${color}` : "none",
          }}
        />
      ))}
    </>
  );
}

function ScanLine({ size, color }) {
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        left: "50%",
        width: size * 0.38,
        height: 1.5,
        marginLeft: -(size * 0.19),
        background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
        boxShadow: `0 0 8px ${color}`,
      }}
      animate={{ top: ["31%", "69%", "31%"] }}
      transition={{ duration: 2.0, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

function DiffractArc({ size, color, index }) {
  const angles = [30, 150, 270];
  const angle = angles[index % 3];
  const r = size * 0.43;
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        width: r, height: r,
        top: "50%", left: "50%",
        marginTop: -(r / 2), marginLeft: -(r / 2),
        borderRadius: "50%",
        border: `1px solid transparent`,
        borderTopColor: color,
        opacity: 0.5,
      }}
      animate={{ rotate: [angle, angle + 360] }}
      transition={{ duration: 4 + index * 1.2, repeat: Infinity, ease: "linear" }}
    />
  );
}

export default function ScanRingSystem({ state = "idle", size = 280, showText = true }) {
  const cfg = SCAN_STATES[state] ?? SCAN_STATES.idle;
  const fx  = fxFlags();
  const isActive = state === "targeting" || state === "analyzing";
  const isSuccess = state === "identified";

  return (
    <div className="relative pointer-events-none select-none" style={{ width: size, height: size }}>
      {/* Background vignette */}
      <div
        className="absolute inset-0 rounded-full"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${cfg.glow.replace(/[\d.]+\)$/, "0.06)")}, transparent 70%)`,
        }}
      />

      {/* Pulse rings */}
      {RING_CONFIGS.map((rc, i) => (
        <PulseRing key={i} size={size} color={cfg.color} {...rc} />
      ))}

      {/* Refraction arcs */}
      {fx.heavyGlow && isActive && [0, 1, 2].map(i => (
        <DiffractArc key={i} size={size} color={cfg.color} index={i} />
      ))}

      {/* Corner brackets — Pokédex targeting aesthetic */}
      <CornerBrackets size={size} color={cfg.color} />

      {/* Animated scan line */}
      {(isActive || isSuccess) && <ScanLine size={size} color={cfg.color} />}

      {/* Center confidence ring (for identified state) */}
      <AnimatePresence>
        {isSuccess && (
          <motion.div
            className="absolute rounded-full"
            style={{
              width: size * 0.25, height: size * 0.25,
              top: "50%", left: "50%",
              marginTop: -(size * 0.125), marginLeft: -(size * 0.125),
              border: `2px solid ${cfg.color}`,
              boxShadow: `0 0 20px ${cfg.color}, inset 0 0 12px ${cfg.glow}`,
            }}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 340, damping: 22 }}
          />
        )}
      </AnimatePresence>

      {/* State label */}
      {showText && (
        <AnimatePresence mode="wait">
          <motion.div
            key={state}
            className="absolute inset-x-0 text-center font-bold tracking-widest uppercase"
            style={{
              bottom: "14%",
              fontSize: 10,
              color: cfg.color,
              textShadow: `0 0 10px ${cfg.color}`,
              letterSpacing: "0.18em",
            }}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.25 }}
          >
            {cfg.label}
          </motion.div>
        </AnimatePresence>
      )}
    </div>
  );
}