/**
 * HolographicReveal — Pokédex / Geo-Dex style specimen card reveal animation.
 * Wraps any content with a dramatic entry sequence:
 * 1. Flash burst
 * 2. Crystal prismatic layer sweeps in
 * 3. Content fades up
 * 4. Optional rarity glow ring
 *
 * Props:
 *   rarity     — "common"|"uncommon"|"rare"|"epic"|"legendary"
 *   delay      — number (seconds before reveal starts, default 0.2)
 *   children   — content to reveal
 */
import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { getRarityCfg } from "@/theme/crystalSystem";
import { fxFlags } from "@/theme/performance";

export default function HolographicReveal({ rarity = "common", delay = 0.2, children }) {
  const [phase, setPhase] = useState("hidden"); // hidden → flash → reveal → done
  const cfg = getRarityCfg(rarity);
  const fx  = fxFlags();

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("flash"),   delay * 1000);
    const t2 = setTimeout(() => setPhase("reveal"),  (delay + 0.18) * 1000);
    const t3 = setTimeout(() => setPhase("done"),    (delay + 0.9)  * 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [delay]);

  return (
    <div className="relative">
      {/* Flash burst */}
      <AnimatePresence>
        {phase === "flash" && (
          <motion.div
            className="absolute inset-0 rounded-inherit z-50 pointer-events-none"
            style={{ background: `radial-gradient(circle at 50% 40%, ${cfg.color}60, transparent 70%)` }}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.9, 0] }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          />
        )}
      </AnimatePresence>

      {/* Prismatic sweep */}
      <AnimatePresence>
        {(phase === "flash" || phase === "reveal") && fx.shimmer && (
          <motion.div
            className="absolute inset-y-0 z-40 pointer-events-none"
            style={{
              width: "40%",
              background: `linear-gradient(90deg, transparent, ${cfg.color}22, rgba(255,255,255,0.12), transparent)`,
              transform: "skewX(-10deg)",
            }}
            initial={{ left: "-40%" }}
            animate={{ left: "140%" }}
            transition={{ duration: 0.55, ease: "easeInOut" }}
          />
        )}
      </AnimatePresence>

      {/* Content reveal */}
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.97 }}
        animate={phase !== "hidden" ? { opacity: 1, y: 0, scale: 1 } : {}}
        transition={{ duration: 0.55, ease: [0.23, 1, 0.32, 1], delay: 0.05 }}
      >
        {children}
      </motion.div>

      {/* Rarity glow ring (persistent, subtle) */}
      {phase === "done" && fx.heavyGlow && rarity !== "common" && (
        <motion.div
          className="absolute inset-0 rounded-inherit pointer-events-none"
          style={{ boxShadow: `0 0 32px ${cfg.glow}, 0 0 80px ${cfg.glow.replace(/[\d.]+\)$/, "0.08)")}` }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
        />
      )}
    </div>
  );
}