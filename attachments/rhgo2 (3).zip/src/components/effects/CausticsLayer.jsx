import React from "react";
import { motion } from "framer-motion";
import clsx from "clsx";

export default function CausticsLayer({ mode = "adventure" }) {
  const opacityClass =
    mode === "scan" || mode === "market" ? "opacity-35" : "opacity-25";

  return (
    <div className={clsx("pointer-events-none absolute inset-0 overflow-hidden mix-blend-screen", opacityClass)}>
      <motion.div
        className="absolute -left-1/4 top-0 h-[140%] w-1/2 rotate-[18deg] blur-2xl"
        style={{
          background:
            "linear-gradient(180deg, rgba(255,255,255,0.0) 0%, rgba(255,255,255,0.12) 20%, rgba(91,192,255,0.18) 52%, rgba(255,255,255,0.0) 100%)",
        }}
        animate={{
          x: ["-8%", "18%", "-8%"],
          y: ["0%", "8%", "0%"],
        }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className="absolute right-0 top-1/4 h-[120%] w-[42%] -rotate-[12deg] blur-2xl"
        style={{
          background:
            "linear-gradient(180deg, rgba(255,255,255,0.0) 0%, rgba(155,109,255,0.16) 40%, rgba(255,255,255,0.0) 100%)",
        }}
        animate={{
          x: ["4%", "-14%", "4%"],
          y: ["0%", "-6%", "0%"],
        }}
        transition={{ duration: 21, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
}