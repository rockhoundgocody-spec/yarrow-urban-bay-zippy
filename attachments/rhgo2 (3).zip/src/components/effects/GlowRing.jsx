/**
 * GlowRing — Animated concentric glow ring
 * Used by: Orb v3 (idle/active state), ScanEnergyRing
 *
 * Props:
 *  color     string   — glow color (hex / rgba)
 *  size      number   — diameter in px
 *  pulse     boolean  — enable radiant pulse animation
 *  rings     number   — concentric ring count (1–3)
 *  opacity   number   — base opacity 0–1
 */

import React from "react";
import { motion } from "framer-motion";

export default function GlowRing({
  color = "#7DF9FF",
  size = 80,
  pulse = true,
  rings = 2,
  opacity = 1,
}) {
  const ringConfigs = [
    { scale: 1,    opacityBase: 0.5,  dur: 2.0, blur: 0 },
    { scale: 1.28, opacityBase: 0.28, dur: 2.4, blur: 1 },
    { scale: 1.60, opacityBase: 0.12, dur: 2.8, blur: 2 },
  ].slice(0, rings);

  return (
    <div
      className="absolute pointer-events-none"
      style={{
        width: size,
        height: size,
        left: "50%",
        top: "50%",
        transform: "translate(-50%, -50%)",
        opacity,
      }}
    >
      {ringConfigs.map((ring, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width:  size * ring.scale,
            height: size * ring.scale,
            left:   "50%",
            top:    "50%",
            transform: "translate(-50%, -50%)",
            border: `${i === 0 ? 2 : 1}px solid ${color}`,
            boxShadow: `0 0 ${8 + i * 6}px ${color}`,
            filter: ring.blur ? `blur(${ring.blur}px)` : undefined,
          }}
          animate={pulse ? {
            opacity: [ring.opacityBase, ring.opacityBase * 1.8, ring.opacityBase],
            scale:   [1, 1.04, 1],
          } : { opacity: ring.opacityBase }}
          transition={pulse ? {
            duration: ring.dur,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.3,
          } : {}}
        />
      ))}
    </div>
  );
}