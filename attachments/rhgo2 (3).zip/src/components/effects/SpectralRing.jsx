import React from "react";
import { motion } from "framer-motion";
import clsx from "clsx";

export default function SpectralRing({
  className = "",
  intensity = "md",
  rotate = true,
  pulse = true,
  tone = "default",
}) {
  const toneClass =
    tone === "cyan"
      ? "from-cyan-300/70 via-sky-300/45 to-violet-400/60"
      : tone === "gold"
        ? "from-amber-300/70 via-orange-300/40 to-cyan-300/45"
        : tone === "violet"
          ? "from-violet-300/70 via-cyan-300/45 to-fuchsia-300/55"
          : tone === "white"
            ? "from-white/70 via-cyan-200/35 to-white/60"
            : "from-cyan-300/65 via-violet-400/45 to-amber-300/45";

  const blurClass =
    intensity === "lg"
      ? "blur-xl"
      : intensity === "sm"
        ? "blur-[2px]"
        : "blur-md";

  return (
    <motion.div
      className={clsx(
        "absolute inset-0 rounded-full bg-gradient-to-r",
        toneClass,
        blurClass,
        className
      )}
      animate={{
        rotate: rotate ? [0, 360] : 0,
        scale: pulse ? [0.98, 1.03, 0.98] : 1,
        opacity: pulse ? [0.42, 0.72, 0.42] : 0.55,
      }}
      transition={{
        rotate: { duration: 14, repeat: Infinity, ease: "linear" },
        scale: { duration: 3.8, repeat: Infinity, ease: "easeInOut" },
        opacity: { duration: 3.2, repeat: Infinity, ease: "easeInOut" },
      }}
    />
  );
}