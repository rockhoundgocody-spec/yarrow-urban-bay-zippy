/**
 * RarityGlowBadge — unified rarity display with animated crystal glow.
 * Supersedes the inline rarity badge pattern.
 *
 * Props:
 *   rarity     — "common"|"uncommon"|"rare"|"epic"|"legendary"
 *   size       — "xs"|"sm"|"md"|"lg"
 *   animated   — boolean (pulsing glow)
 *   showIcon   — boolean
 */
import React from "react";
import { motion } from "framer-motion";
import { Gem, Star, Zap, Sparkles, Crown } from "lucide-react";
import { getRarityCfg } from "@/theme/crystalSystem";
import { fxFlags } from "@/theme/performance";

const ICON_MAP = { common: Gem, uncommon: Star, rare: Zap, epic: Sparkles, legendary: Crown };

const SIZE_MAP = {
  xs: { px: "px-2 py-0.5",   text: "text-[9px]",  icon: 10, gap: "gap-1" },
  sm: { px: "px-2.5 py-1",   text: "text-[10px]", icon: 11, gap: "gap-1" },
  md: { px: "px-3 py-1.5",   text: "text-xs",     icon: 13, gap: "gap-1.5" },
  lg: { px: "px-4 py-2",     text: "text-sm",     icon: 15, gap: "gap-2" },
};

export default function RarityGlowBadge({ rarity = "common", size = "sm", animated = false, showIcon = true }) {
  const cfg  = getRarityCfg(rarity);
  const s    = SIZE_MAP[size] ?? SIZE_MAP.sm;
  const Icon = ICON_MAP[rarity] ?? Gem;
  const fx   = fxFlags();
  const shouldAnimate = animated && fx.heavyGlow;

  const inner = (
    <div
      className={`inline-flex items-center ${s.gap} ${s.px} rounded-full font-bold uppercase tracking-[0.14em] ${s.text}`}
      style={{
        background: `${cfg.color}12`,
        border: `1px solid ${cfg.color}35`,
        color: cfg.color,
        boxShadow: shouldAnimate ? `0 0 14px ${cfg.glow}` : "none",
        letterSpacing: "0.15em",
      }}
    >
      {showIcon && <Icon size={s.icon} strokeWidth={2} style={{ color: cfg.color }} />}
      {cfg.label}
    </div>
  );

  if (!shouldAnimate) return inner;

  return (
    <motion.div
      className="inline-flex rounded-full"
      animate={{ boxShadow: [`0 0 10px ${cfg.glow}`, `0 0 22px ${cfg.glow}`, `0 0 10px ${cfg.glow}`] }}
      transition={{ duration: cfg.pulse, repeat: Infinity, ease: "easeInOut" }}
    >
      {inner}
    </motion.div>
  );
}