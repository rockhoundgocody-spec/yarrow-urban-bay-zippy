/**
 * ResultStep — displays the final AI identification result with save-to-collection action.
 */
import React, { useState } from "react";
import { motion } from "framer-motion";
import { CheckCircle2, BookOpen, DollarSign, Save, RefreshCw } from "lucide-react";

const RARITY_COLORS = {
  "common":    { bg: "rgba(110,118,129,0.15)", border: "rgba(110,118,129,0.35)", text: "#9CA3AF" },
  "uncommon":  { bg: "rgba(0,214,143,0.12)",   border: "rgba(0,214,143,0.35)",   text: "#00D68F" },
  "rare":      { bg: "rgba(122,231,255,0.12)",  border: "rgba(122,231,255,0.35)", text: "#7AE7FF" },
  "very rare": { bg: "rgba(141,124,255,0.15)",  border: "rgba(141,124,255,0.4)",  text: "#C4B5FD" },
};

const CONF_COLOR = (c) => c >= 85 ? "#00D68F" : c >= 65 ? "#F5B642" : "#FF8080";

export default function ResultStep({ result, photoUrl, clarifications, saving, savedId, onSave, onViewCollection, onScanAnother }) {
  const [notes, setNotes] = useState("");
  const rarity = RARITY_COLORS[result.rarity] || RARITY_COLORS["common"];
  const confColor = CONF_COLOR(result.confidence);
  const alreadySaved = !!savedId;

  const displayName = result.variety
    ? `${result.variety} (${result.name})`
    : result.name;

  return (
    <div className="max-w-lg mx-auto pt-2">

      {/* Confidence banner */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full" style={{ background: confColor, boxShadow: `0 0 8px ${confColor}80` }} />
          <span className="text-xs font-semibold" style={{ color: confColor }}>
            {result.confidence}% confidence
          </span>
        </div>
        {result.confidence >= 75
          ? <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "rgba(0,214,143,0.12)", color: "#00D68F", border: "1px solid rgba(0,214,143,0.3)" }}>High Confidence</span>
          : <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: "rgba(245,182,66,0.12)", color: "#F5B642", border: "1px solid rgba(245,182,66,0.3)" }}>Guided Result</span>
        }
      </div>

      {/* Photo + hero card */}
      <div className="rounded-3xl overflow-hidden mb-4"
        style={{ background: "linear-gradient(145deg, rgba(12,8,28,0.96), rgba(8,6,18,0.92))", border: "1px solid rgba(141,124,255,0.25)", boxShadow: "0 0 40px rgba(141,124,255,0.1)" }}>
        {photoUrl && (
          <div className="relative w-full" style={{ height: 200 }}>
            <img src={photoUrl} alt="specimen" className="w-full h-full object-cover" />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, transparent 50%, rgba(4,2,14,0.9) 100%)" }} />
            {/* Rarity badge overlay */}
            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-xl text-[10px] font-bold uppercase tracking-wider"
              style={{ background: rarity.bg, border: `1px solid ${rarity.border}`, color: rarity.text }}>
              {result.rarity || "common"}
            </div>
          </div>
        )}

        <div className="p-5">
          <h2 className="text-2xl font-bold text-white mb-0.5">{displayName}</h2>
          {result.mineral_type && (
            <p className="text-xs mb-3" style={{ color: "rgba(141,124,255,0.7)" }}>{result.mineral_type}</p>
          )}
          <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
            {result.ai_explanation}
          </p>
        </div>
      </div>

      {/* Properties grid */}
      <div className="grid grid-cols-2 gap-2 mb-4">
        {[
          { icon: "🎨", label: "Color",        val: result.color },
          { icon: "💎", label: "Luster",       val: result.luster },
          { icon: "🔷", label: "Crystal Habit",val: result.crystal_habit },
          { icon: "👁️", label: "Transparency", val: result.transparency },
          { icon: "⚖️", label: "Hardness",     val: result.hardness_estimate ? `${result.hardness_estimate} Mohs` : clarifications?.["hardness"] ? `${clarifications["hardness"]} Mohs (user)` : null },
          { icon: "🌍", label: "Category",     val: result.category },
        ].filter((p) => p.val).map((prop) => (
          <div key={prop.label} className="rounded-2xl px-3.5 py-3"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <p className="text-[10px] font-bold uppercase tracking-wider mb-1" style={{ color: "rgba(255,255,255,0.25)" }}>
              {prop.icon} {prop.label}
            </p>
            <p className="text-sm font-semibold capitalize" style={{ color: "rgba(255,255,255,0.8)" }}>{prop.val}</p>
          </div>
        ))}
      </div>

      {/* Valuation */}
      {(result.valuation_low || result.valuation_high) && (
        <div className="mb-4 rounded-2xl p-4 flex items-center gap-4"
          style={{ background: "rgba(212,175,55,0.06)", border: "1px solid rgba(212,175,55,0.2)" }}>
          <DollarSign className="w-6 h-6 flex-shrink-0" style={{ color: "#D4AF37" }} />
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider mb-0.5" style={{ color: "rgba(212,175,55,0.5)" }}>Estimated Value</p>
            <p className="text-lg font-bold" style={{ color: "#D4AF37" }}>
              ${result.valuation_low?.toFixed(0)} – ${result.valuation_high?.toFixed(0)}
            </p>
          </div>
        </div>
      )}

      {/* Formation */}
      {result.formation_history && (
        <div className="mb-4 rounded-2xl p-4"
          style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.12)" }}>
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="w-4 h-4" style={{ color: "#7AE7FF" }} />
            <p className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "rgba(122,231,255,0.5)" }}>
              Formation
            </p>
          </div>
          <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.55)" }}>{result.formation_history}</p>
        </div>
      )}

      {/* Notes */}
      {!alreadySaved && (
        <div className="mb-4">
          <label className="block text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>
            Add a note (optional)
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Where did you find it? Any notable features…"
            rows={2}
            className="w-full rounded-2xl px-4 py-3 text-sm text-white resize-none"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.1)",
              outline: "none",
              color: "rgba(255,255,255,0.85)",
            }}
          />
        </div>
      )}

      {/* Actions */}
      {alreadySaved ? (
        <div className="space-y-3">
          <div className="flex items-center justify-center gap-2 py-3 rounded-2xl"
            style={{ background: "rgba(0,214,143,0.1)", border: "1px solid rgba(0,214,143,0.3)" }}>
            <CheckCircle2 className="w-5 h-5" style={{ color: "#00D68F" }} />
            <span className="text-sm font-bold" style={{ color: "#00D68F" }}>Saved to Collection!</span>
          </div>
          <motion.button whileTap={{ scale: 0.97 }} onClick={onViewCollection}
            className="w-full py-4 rounded-2xl font-bold text-sm"
            style={{ background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.4)", color: "#00D68F", minHeight: 52 }}>
            View Collection →
          </motion.button>
          <motion.button whileTap={{ scale: 0.97 }} onClick={onScanAnother}
            className="w-full py-3 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)", minHeight: 48 }}>
            <RefreshCw className="w-4 h-4" />
            Identify Another
          </motion.button>
        </div>
      ) : (
        <div className="space-y-3">
          <motion.button
            whileTap={{ scale: 0.97 }}
            onClick={() => onSave(notes)}
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-bold text-sm"
            style={{
              background: "linear-gradient(135deg, rgba(0,214,143,0.2), rgba(0,180,120,0.12))",
              border: "1.5px solid rgba(0,214,143,0.5)",
              color: "#00D68F",
              boxShadow: "0 0 20px rgba(0,214,143,0.15)",
              minHeight: 52,
              opacity: saving ? 0.7 : 1,
            }}
          >
            {saving ? (
              <div className="w-4 h-4 rounded-full border-2 border-t-transparent animate-spin" style={{ borderColor: "#00D68F", borderTopColor: "transparent" }} />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {saving ? "Saving…" : "Add to Collection"}
          </motion.button>

          <motion.button whileTap={{ scale: 0.97 }} onClick={onScanAnother}
            className="w-full py-3 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.35)", minHeight: 48 }}>
            <RefreshCw className="w-4 h-4" />
            Start Over
          </motion.button>
        </div>
      )}
    </div>
  );
}