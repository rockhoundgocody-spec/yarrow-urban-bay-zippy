/**
 * PhotoUploadStep — camera capture or gallery upload.
 */
import React, { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Camera, ImagePlus, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function PhotoUploadStep({ onPhotoReady }) {
  const fileRef   = useRef(null);
  const cameraRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview]     = useState(null);
  const [error, setError]         = useState(null);

  const handleFile = async (file) => {
    if (!file) return;
    setError(null);
    const localUrl = URL.createObjectURL(file);
    setPreview(localUrl);
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      onPhotoReady(file, file_url);
    } catch {
      setError("Upload failed. Please try again.");
      setPreview(null);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="max-w-lg mx-auto pt-4">
      <div className="mb-6 text-center">
        <h1 className="text-2xl font-bold text-white mb-1">Guided Identify</h1>
        <p className="text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>
          Photograph your specimen — AI + guided questions narrow the ID
        </p>
      </div>

      {/* Upload zone */}
      <motion.div
        whileTap={{ scale: 0.98 }}
        onClick={() => fileRef.current?.click()}
        className="relative flex flex-col items-center justify-center rounded-3xl cursor-pointer overflow-hidden"
        style={{
          minHeight: 240,
          background: preview
            ? "transparent"
            : "linear-gradient(145deg, rgba(12,8,28,0.95), rgba(8,6,18,0.92))",
          border: "1.5px dashed rgba(141,124,255,0.35)",
          boxShadow: "0 0 40px rgba(141,124,255,0.06)",
        }}
      >
        {preview ? (
          <img src={preview} alt="specimen preview" className="w-full h-full object-cover rounded-3xl" style={{ maxHeight: 300 }} />
        ) : (
          <div className="flex flex-col items-center gap-3 py-12 px-6 text-center">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ background: "rgba(141,124,255,0.12)", border: "1px solid rgba(141,124,255,0.3)" }}>
              <ImagePlus className="w-8 h-8" style={{ color: "#8D7CFF" }} />
            </div>
            <p className="text-base font-semibold text-white">Tap to upload photo</p>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>
              JPG, PNG · Best in natural light with neutral background
            </p>
          </div>
        )}

        {uploading && (
          <div className="absolute inset-0 flex items-center justify-center rounded-3xl"
            style={{ background: "rgba(4,2,14,0.75)" }}>
            <div className="w-8 h-8 rounded-full border-2 border-t-transparent animate-spin"
              style={{ borderColor: "#8D7CFF", borderTopColor: "transparent" }} />
          </div>
        )}

        <input ref={fileRef} type="file" accept="image/*" className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])} />
      </motion.div>

      {error && (
        <p className="mt-3 text-center text-sm" style={{ color: "#FF8080" }}>{error}</p>
      )}

      {/* Camera shortcut */}
      <motion.button
        whileTap={{ scale: 0.96 }}
        onClick={() => cameraRef.current?.click()}
        className="mt-4 w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-semibold text-sm"
        style={{
          background: "linear-gradient(135deg, rgba(141,124,255,0.18), rgba(80,40,180,0.12))",
          border: "1px solid rgba(141,124,255,0.4)",
          color: "#C4B5FD",
          boxShadow: "0 0 18px rgba(141,124,255,0.15)",
        }}
      >
        <Camera className="w-5 h-5" />
        Use Camera
      </motion.button>
      <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])} />

      {/* Tips */}
      <div className="mt-6 rounded-2xl p-4 space-y-2"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
        <p className="text-[10px] font-bold uppercase tracking-widest mb-2" style={{ color: "rgba(255,255,255,0.25)" }}>
          Photo Tips
        </p>
        {[
          "Place specimen on a flat, neutral surface",
          "Include a coin or ruler for scale if possible",
          "One photo is enough — extra angles just improve accuracy",
          "Natural light outperforms flash",
        ].map((tip) => (
          <div key={tip} className="flex items-start gap-2">
            <Sparkles className="w-3 h-3 mt-0.5 flex-shrink-0" style={{ color: "#8D7CFF" }} />
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.45)" }}>{tip}</p>
          </div>
        ))}
      </div>
    </div>
  );
}