/**
 * ClarifyStep — presents clarifying questions when AI confidence < 75%.
 * Renders select (button group) or number (slider/input) question types.
 */
import React, { useState } from "react";
import { motion } from "framer-motion";
import { HelpCircle, ChevronRight, Zap } from "lucide-react";

export default function ClarifyStep({ analysis, photoUrl, onSubmit }) {
  const questions = analysis?.clarifying_questions || [];
  const [answers, setAnswers] = useState({});

  const allAnswered = questions.every((q) => answers[q.id] !== undefined && answers[q.id] !== "");

  const handleSelect = (id, val) => setAnswers((a) => ({ ...a, [id]: val }));

  return (
    <div className="max-w-lg mx-auto pt-2">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        {photoUrl && (
          <img src={photoUrl} alt="specimen" className="w-14 h-14 rounded-2xl object-cover flex-shrink-0"
            style={{ border: "1px solid rgba(141,124,255,0.3)" }} />
        )}
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <div className="w-2 h-2 rounded-full" style={{ background: "#F5B642", boxShadow: "0 0 6px #F5B64280" }} />
            <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "#F5B642" }}>
              Low Confidence — {analysis?.confidence}%
            </p>
          </div>
          <p className="text-base font-bold text-white">Let's narrow it down</p>
          <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
            Best guess: <span className="font-semibold" style={{ color: "#C4B5FD" }}>{analysis?.name}</span>
          </p>
        </div>
      </div>

      {/* Confidence blockers */}
      {analysis?.confidence_blockers?.length > 0 && (
        <div className="mb-5 rounded-2xl p-3"
          style={{ background: "rgba(245,182,66,0.06)", border: "1px solid rgba(245,182,66,0.2)" }}>
          <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "rgba(245,182,66,0.6)" }}>
            What's unclear from the photo
          </p>
          {analysis.confidence_blockers.map((b, i) => (
            <div key={i} className="flex items-start gap-2 mt-1">
              <HelpCircle className="w-3 h-3 mt-0.5 flex-shrink-0" style={{ color: "#F5B64280" }} />
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>{b}</p>
            </div>
          ))}
        </div>
      )}

      {/* Questions */}
      <div className="space-y-5">
        {questions.map((q, idx) => (
          <motion.div
            key={q.id}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="rounded-2xl p-4"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <div className="flex items-start gap-2 mb-3">
              <div className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5"
                style={{ background: "rgba(141,124,255,0.2)", color: "#C4B5FD", border: "1px solid rgba(141,124,255,0.3)" }}>
                {idx + 1}
              </div>
              <p className="text-sm font-semibold text-white leading-snug">{q.question}</p>
            </div>

            {q.type === "select" && q.options && (
              <div className="flex flex-wrap gap-2">
                {q.options.map((opt) => {
                  const selected = answers[q.id] === opt;
                  return (
                    <button
                      key={opt}
                      onClick={() => handleSelect(q.id, opt)}
                      className="px-3 py-2 rounded-xl text-sm font-medium transition-all"
                      style={{
                        background: selected ? "rgba(141,124,255,0.25)" : "rgba(255,255,255,0.04)",
                        border: selected ? "1.5px solid rgba(141,124,255,0.7)" : "1px solid rgba(255,255,255,0.1)",
                        color: selected ? "#C4B5FD" : "rgba(255,255,255,0.55)",
                        boxShadow: selected ? "0 0 12px rgba(141,124,255,0.25)" : "none",
                        minHeight: 44,
                      }}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>
            )}

            {q.type === "number" && (
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  step="0.5"
                  min="0"
                  max="10"
                  placeholder={q.id === "hardness" ? "e.g. 6.5" : "Enter value"}
                  value={answers[q.id] ?? ""}
                  onChange={(e) => handleSelect(q.id, e.target.value)}
                  className="w-full rounded-xl px-4 py-3 text-sm font-medium text-white"
                  style={{
                    background: "rgba(255,255,255,0.05)",
                    border: "1px solid rgba(141,124,255,0.35)",
                    outline: "none",
                  }}
                />
                {q.id === "hardness" && (
                  <span className="text-xs whitespace-nowrap" style={{ color: "rgba(255,255,255,0.35)" }}>Mohs scale</span>
                )}
              </div>
            )}

            {/* Hardness reference hint */}
            {q.field === "hardness" && (
              <div className="mt-3 rounded-xl p-2.5"
                style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.12)" }}>
                <p className="text-[10px] font-bold uppercase tracking-wider mb-1.5" style={{ color: "rgba(122,231,255,0.5)" }}>
                  Quick Reference
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {[["1-2","Talc/Gypsum"],["3","Calcite"],["4-5","Fluorite/Apatite"],["6","Feldspar"],["7","Quartz"],["8-9","Topaz/Corundum"],["10","Diamond"]].map(([h, m]) => (
                    <span key={h} className="text-[10px] px-2 py-0.5 rounded-lg"
                      style={{ background: "rgba(122,231,255,0.06)", color: "rgba(122,231,255,0.6)", border: "1px solid rgba(122,231,255,0.1)" }}>
                      {h} = {m}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Submit */}
      <motion.button
        whileTap={{ scale: 0.97 }}
        onClick={() => onSubmit(answers)}
        disabled={!allAnswered}
        className="mt-6 w-full flex items-center justify-center gap-2 rounded-2xl py-4 font-bold text-sm transition-all"
        style={{
          background: allAnswered
            ? "linear-gradient(135deg, rgba(141,124,255,0.3), rgba(80,40,180,0.2))"
            : "rgba(255,255,255,0.04)",
          border: allAnswered ? "1.5px solid rgba(141,124,255,0.6)" : "1px solid rgba(255,255,255,0.08)",
          color: allAnswered ? "#C4B5FD" : "rgba(255,255,255,0.25)",
          boxShadow: allAnswered ? "0 0 20px rgba(141,124,255,0.2)" : "none",
          cursor: allAnswered ? "pointer" : "not-allowed",
          minHeight: 52,
        }}
      >
        <Zap className="w-4 h-4" />
        Re-analyze with my answers
        <ChevronRight className="w-4 h-4" />
      </motion.button>

      <p className="mt-3 text-center text-xs" style={{ color: "rgba(255,255,255,0.2)" }}>
        All questions required · Takes ~5 seconds
      </p>
    </div>
  );
}