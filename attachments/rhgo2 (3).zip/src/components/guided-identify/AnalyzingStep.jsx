/**
 * AnalyzingStep — animated loading state while AI processes the photo.
 */
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

const PHASES = [
  "Scanning visual features…",
  "Analyzing crystal structure…",
  "Checking luster & transparency…",
  "Comparing mineral database…",
  "Estimating confidence…",
];

export default function AnalyzingStep({ photoUrl }) {
  const [phaseIdx, setPhaseIdx] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setPhaseIdx((i) => (i + 1) % PHASES.length);
    }, 1800);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="max-w-lg mx-auto flex flex-col items-center pt-10 gap-8">
      {/* Photo thumbnail */}
      {photoUrl && (
        <div className="relative w-48 h-48 rounded-3xl overflow-hidden"
          style={{ border: "1.5px solid rgba(141,124,255,0.3)" }}>
          <img src={photoUrl} alt="specimen" className="w-full h-full object-cover" />
          {/* Scan line */}
          <motion.div
            className="absolute left-0 right-0 h-0.5"
            style={{ background: "linear-gradient(90deg, transparent, #8D7CFF, #7AE7FF, transparent)" }}
            animate={{ top: ["10%", "90%", "10%"] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: "linear" }}
          />
          {/* Corner brackets */}
          {[["top-2 left-2", "border-t-2 border-l-2"], ["top-2 right-2", "border-t-2 border-r-2"],
            ["bottom-2 left-2", "border-b-2 border-l-2"], ["bottom-2 right-2", "border-b-2 border-r-2"]
          ].map(([pos, border], i) => (
            <div key={i} className={`absolute w-4 h-4 ${pos} ${border}`}
              style={{ borderColor: "#8D7CFF" }} />
          ))}
        </div>
      )}

      {/* Orb pulse */}
      <div className="relative flex items-center justify-center">
        {[1, 2, 3].map((ring) => (
          <motion.div
            key={ring}
            className="absolute rounded-full"
            style={{
              width: 60 + ring * 28,
              height: 60 + ring * 28,
              border: `1px solid rgba(141,124,255,${0.25 / ring})`,
            }}
            animate={{ scale: [1, 1.08, 1], opacity: [0.4, 0.7, 0.4] }}
            transition={{ duration: 2, repeat: Infinity, delay: ring * 0.4, ease: "easeInOut" }}
          />
        ))}
        <div className="w-14 h-14 rounded-full flex items-center justify-center"
          style={{ background: "rgba(141,124,255,0.15)", border: "1.5px solid rgba(141,124,255,0.5)" }}>
          <motion.div
            className="w-5 h-5 rounded-full"
            style={{ background: "#8D7CFF" }}
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
      </div>

      {/* Phase text */}
      <div className="text-center">
        <p className="text-lg font-bold text-white mb-2">AI Analysis Running</p>
        <motion.p
          key={phaseIdx}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          className="text-sm"
          style={{ color: "#8D7CFF" }}
        >
          {PHASES[phaseIdx]}
        </motion.p>
      </div>

      <p className="text-xs text-center max-w-xs" style={{ color: "rgba(255,255,255,0.25)" }}>
        If confidence is low, we'll ask you 2-3 quick questions to sharpen the identification.
      </p>
    </div>
  );
}