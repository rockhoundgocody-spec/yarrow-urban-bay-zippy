import React, { useState } from "react";
import { Loader2, Check } from "lucide-react";

const TONES = ["warm", "concise", "scientific", "playful"];
const LEVELS = ["curious", "hobbyist", "serious", "expert"];

const input = {
  width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)",
  borderRadius: 10, padding: "10px 12px", color: "#fff", fontSize: 14, outline: "none",
};
const label = { color: "rgba(255,255,255,0.45)", fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase" };

/** Full companion personalization form — explicit Save, all profile fields. */
export default function PersonalizationForm({ profile, onSave }) {
  const [form, setForm] = useState({
    display_name: profile.display_name || "",
    pronouns: profile.pronouns || "",
    home_region: profile.home_region || "",
    experience_level: profile.experience_level || "curious",
    focus_interests: (profile.focus_interests || []).join(", "),
    companion_tone: profile.companion_tone || "warm",
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const set = (key) => (e) => { setForm((f) => ({ ...f, [key]: e.target.value })); setSaved(false); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const ok = await onSave({
      display_name: form.display_name.trim(),
      pronouns: form.pronouns.trim(),
      home_region: form.home_region.trim(),
      experience_level: form.experience_level,
      companion_tone: form.companion_tone,
      focus_interests: form.focus_interests.split(",").map((s) => s.trim()).filter(Boolean),
    });
    setSaving(false);
    if (ok) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <span style={label}>Name it calls you</span>
          <input style={input} placeholder="e.g. Todd" value={form.display_name} onChange={set("display_name")} />
        </div>
        <div className="flex flex-col gap-1.5">
          <span style={label}>Pronouns (optional)</span>
          <input style={input} placeholder="e.g. he/him" value={form.pronouns} onChange={set("pronouns")} />
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <span style={label}>Home collecting region</span>
        <input style={input} placeholder="e.g. Northern Wisconsin" value={form.home_region} onChange={set("home_region")} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="flex flex-col gap-1.5">
          <span style={label}>Experience level</span>
          <select style={input} value={form.experience_level} onChange={set("experience_level")}>
            {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div className="flex flex-col gap-1.5">
          <span style={label}>Companion tone</span>
          <select style={input} value={form.companion_tone} onChange={set("companion_tone")}>
            {TONES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <span style={label}>Interests</span>
        <input style={input} placeholder="e.g. agates, Lake Superior, fossils" value={form.focus_interests} onChange={set("focus_interests")} />
        <span className="text-xs px-1" style={{ color: "rgba(255,255,255,0.3)" }}>Separate with commas.</span>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="flex items-center justify-center gap-2 py-3.5 rounded-2xl font-bold text-sm mt-1"
        style={{
          background: saved
            ? "linear-gradient(135deg, rgba(0,214,143,0.20) 0%, rgba(0,214,143,0.12) 100%)"
            : "linear-gradient(135deg, rgba(141,124,255,0.22) 0%, rgba(80,40,180,0.15) 100%)",
          border: `1px solid ${saved ? "rgba(0,214,143,0.45)" : "rgba(141,124,255,0.45)"}`,
          color: saved ? "#4AE5A8" : "#C4B5FD",
          opacity: saving ? 0.6 : 1,
        }}
      >
        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <Check className="w-4 h-4" /> : null}
        {saving ? "Saving…" : saved ? "Saved" : "Save personalization"}
      </button>
    </form>
  );
}