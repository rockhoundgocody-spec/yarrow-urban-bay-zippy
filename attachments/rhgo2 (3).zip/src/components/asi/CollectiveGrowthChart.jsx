import React from "react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

export default function CollectiveGrowthChart({ growth = [] }) {
  const data = growth.map((g) => ({
    month: g.month?.slice(5) || "",
    Beliefs: g.beliefs,
    Finds: g.finds,
    Companions: g.companions,
  }));

  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
      }}
    >
      <div className="text-[11px] font-bold uppercase tracking-wider mb-3" style={{ color: "rgba(255,255,255,0.45)" }}>
        Collective growth · last 6 months
      </div>
      <div style={{ width: "100%", height: 220 }}>
        <ResponsiveContainer>
          <AreaChart data={data} margin={{ top: 4, right: 8, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="gBelief" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#8D7CFF" stopOpacity={0.55} />
                <stop offset="100%" stopColor="#8D7CFF" stopOpacity={0.02} />
              </linearGradient>
              <linearGradient id="gFind" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#00D68F" stopOpacity={0.45} />
                <stop offset="100%" stopColor="#00D68F" stopOpacity={0.02} />
              </linearGradient>
            </defs>
            <CartesianGrid stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis dataKey="month" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip
              contentStyle={{
                background: "rgba(8,6,24,0.96)",
                border: "1px solid rgba(141,124,255,0.3)",
                borderRadius: 12,
                fontSize: 12,
              }}
              labelStyle={{ color: "rgba(255,255,255,0.6)" }}
            />
            <Area type="monotone" dataKey="Beliefs" stroke="#8D7CFF" fill="url(#gBelief)" strokeWidth={2} />
            <Area type="monotone" dataKey="Finds" stroke="#00D68F" fill="url(#gFind)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}