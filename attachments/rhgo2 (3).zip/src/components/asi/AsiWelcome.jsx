import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Sparkles, X } from "lucide-react";

const SESSION_KEY = "rh_asi_greeted";

/** Personalized companion greeting shown once per session after sign-in. */
export default function AsiWelcome() {
  const [state, setState] = useState(null); // { greeting, personalized }
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (sessionStorage.getItem(SESSION_KEY)) return;
    let alive = true;
    (async () => {
      if (!(await base44.auth.isAuthenticated())) return;
      const res = await base44.functions.invoke("asiPresence", {});
      const payload = res?.data ?? res;
      if (!alive || !payload?.greeting) return;
      sessionStorage.setItem(SESSION_KEY, "1");
      setState(payload);
      setOpen(true);
    })();
    return () => { alive = false; };
  }, []);

  if (!state) return null;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 12 }}
          transition={{ duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
          className="fixed z-[60] rounded-2xl px-4 py-3 flex items-start gap-3"
          style={{
            left: 12,
            right: 12,
            maxWidth: 460,
            marginLeft: "auto",
            marginRight: "auto",
            bottom: "calc(5.5rem + env(safe-area-inset-bottom, 0px))",
            background: "linear-gradient(140deg, rgba(12,8,28,0.97) 0%, rgba(6,12,22,0.96) 100%)",
            border: "1px solid rgba(141,124,255,0.30)",
            boxShadow: "0 8px 32px rgba(0,0,0,0.65), 0 0 24px rgba(141,124,255,0.14)",
          }}
        >
          <Sparkles className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "#C4B5FD" }} />
          <div className="flex-1 min-w-0">
            <p className="text-sm leading-snug" style={{ color: "rgba(255,255,255,0.92)" }}>{state.greeting}</p>
            {!state.personalized && (
              <Link
                to="/PrivacyControls"
                onClick={() => setOpen(false)}
                className="inline-block mt-1.5 text-xs font-semibold"
                style={{ color: "#7AE7FF" }}
              >
                Turn on personalization
              </Link>
            )}
          </div>
          <button
            onClick={() => setOpen(false)}
            aria-label="Dismiss greeting"
            className="tap-compact p-1 flex-shrink-0"
            style={{ color: "rgba(255,255,255,0.4)", minHeight: "unset", minWidth: "unset" }}
          >
            <X className="w-4 h-4" />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}