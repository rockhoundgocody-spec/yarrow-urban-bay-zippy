import React from "react";
import { Sparkles } from "lucide-react";

function Bar({ label, count, max, color }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-[11px] w-24 truncate" style={{ color: "rgba(255,255,255,0.55)" }}>{label}</span>
      <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
        <div className="h-full rounded-full" style={{ width: `${Math.round((count / Math.max(1, max)) * 100)}%`, background: color }} />
      </div>
      <span className="text-[11px] tabular-nums w-6 text-right" style={{ color: "rgba(255,255,255,0.40)" }}>{count}</span>
    </div>
  );
}

export default function CompanionMixPanel({ learning }) {
  if (!learning) return null;
  const exp = Object.entries(learning.experience_mix || {}).sort((a, b) => b[1] - a[1]);
  const maxExp = Math.max(1, ...exp.map(([, v]) => v));
  const maxInt = Math.max(1, ...(learning.top_interests || []).map((i) => i.count));

  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Sparkles className="w-3.5 h-3.5" style={{ color: "#D4AF37" }} />
        <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>
          Who the companions serve
        </span>
      </div>

      <div className="space-y-1.5 mb-4">
        {exp.map(([label, count]) => (
          <Bar key={label} label={label} count={count} max={maxExp} color="#8D7CFF" />
        ))}
      </div>

      {(learning.top_interests || []).length > 0 && (
        <>
          <div className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "rgba(255,255,255,0.35)" }}>
            Shared focus
          </div>
          <div className="space-y-1.5">
            {learning.top_interests.map((i) => (
              <Bar key={i.label} label={i.label} count={i.count} max={maxInt} color="#7AE7FF" />
            ))}
          </div>
        </>
      )}

      <div className="mt-3 pt-3 border-t border-white/5 text-[11px]" style={{ color: "rgba(255,255,255,0.40)" }}>
        Aggregates only. Individual profiles, memories and locations are never exposed here.
      </div>
    </div>
  );
}