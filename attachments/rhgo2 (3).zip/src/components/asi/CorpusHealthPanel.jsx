import React from "react";
import { Brain } from "lucide-react";

const ROWS = [
  { key: "active", label: "Active (field-verified)", color: "#00D68F" },
  { key: "inferred", label: "Inferred (single report)", color: "#7AE7FF" },
  { key: "superseded", label: "Superseded (retired)", color: "rgba(255,255,255,0.35)" },
];

export default function CorpusHealthPanel({ corpus }) {
  if (!corpus) return null;
  const total = Math.max(1, corpus.total_beliefs);

  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <Brain className="w-3.5 h-3.5" style={{ color: "#8D7CFF" }} />
        <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>
          Belief state health
        </span>
      </div>

      <div className="space-y-2.5">
        {ROWS.map((r) => {
          const value = corpus[r.key] || 0;
          const pct = Math.round((value / total) * 100);
          return (
            <div key={r.key}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-[12px]" style={{ color: "rgba(255,255,255,0.60)" }}>{r.label}</span>
                <span className="text-[12px] font-bold tabular-nums" style={{ color: r.color }}>{value}</span>
              </div>
              <div className="h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
                <div className="h-full rounded-full" style={{ width: `${pct}%`, background: r.color }} />
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-3 pt-3 border-t border-white/5 text-[11px] leading-relaxed" style={{ color: "rgba(255,255,255,0.40)" }}>
        {corpus.confirmations} confirmations · {corpus.refutations} refutations · {Math.round(corpus.supersession_rate * 100)}% retired.
        Retired beliefs are kept for audit and never injected again — that is what keeps old conclusions from quietly steering new ones.
      </div>
    </div>
  );
}