import React from "react";
import { TrendingUp } from "lucide-react";

export default function RegionCeilingTable({ regions = [] }) {
  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
      }}
    >
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp className="w-3.5 h-3.5" style={{ color: "#00D68F" }} />
        <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>
          Regions the field has taught us
        </span>
      </div>

      {regions.length === 0 ? (
        <p className="text-[12px]" style={{ color: "rgba(255,255,255,0.35)" }}>
          No region has verified beliefs yet. The first confirmed find raises its ceiling permanently.
        </p>
      ) : (
        <div className="space-y-1.5">
          {regions.map((r) => (
            <div key={r.region_key} className="flex items-center justify-between py-1.5 border-b border-white/5 last:border-0">
              <div className="min-w-0">
                <div className="text-[13px] font-semibold text-white truncate">{r.region_key}</div>
                <div className="text-[11px]" style={{ color: "rgba(255,255,255,0.38)" }}>
                  {r.confirmed} verified · {r.beliefs} beliefs
                  {r.refuted > 0 && ` · ${r.refuted} refuted`}
                </div>
              </div>
              <div
                className="text-[13px] font-black tabular-nums ml-3"
                style={{ color: r.ceiling_lift > 0 ? "#00D68F" : "rgba(255,255,255,0.30)" }}
              >
                {r.ceiling_lift > 0 ? `+${r.ceiling_lift}%` : "—"}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}