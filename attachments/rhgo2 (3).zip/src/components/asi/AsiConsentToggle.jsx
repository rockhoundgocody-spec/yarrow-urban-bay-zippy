import React from "react";

/** Single labelled consent switch used on the privacy screen. */
export default function AsiConsentToggle({ label, help, checked, disabled, onChange }) {
  return (
    <label
      className="flex items-start gap-3 px-4 py-3.5 rounded-2xl cursor-pointer"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
    >
      <input
        type="checkbox"
        checked={!!checked}
        disabled={disabled}
        onChange={(e) => onChange(e.target.checked)}
        className="mt-0.5 w-5 h-5 flex-shrink-0 accent-violet-400 tap-compact"
        style={{ minHeight: "unset", minWidth: "unset" }}
      />
      <span className="flex-1 min-w-0">
        <span className="block text-sm font-semibold" style={{ color: "rgba(255,255,255,0.92)" }}>{label}</span>
        <span className="block text-xs mt-0.5 leading-relaxed" style={{ color: "rgba(255,255,255,0.45)" }}>{help}</span>
      </span>
    </label>
  );
}