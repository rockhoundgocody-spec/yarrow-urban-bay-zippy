import React from "react";

export default function CollectiveMetricCard({ label, value, sub, accent = "#8D7CFF", icon: Icon }) {
  return (
    <div
      className="rounded-2xl p-4 relative overflow-hidden"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: `1px solid ${accent}30`,
      }}
    >
      <div className="flex items-center gap-2 mb-2">
        {Icon && <Icon className="w-3.5 h-3.5" style={{ color: accent }} />}
        <span
          className="text-[10px] font-bold uppercase tracking-wider"
          style={{ color: "rgba(255,255,255,0.45)" }}
        >
          {label}
        </span>
      </div>
      <div className="text-2xl font-black" style={{ color: accent }}>
        {value}
      </div>
      {sub && (
        <div className="text-[11px] mt-1" style={{ color: "rgba(255,255,255,0.40)" }}>
          {sub}
        </div>
      )}
    </div>
  );
}