import React from 'react';
import { TrendingUp, Users, DollarSign, RefreshCw } from 'lucide-react';

function KPICard({ icon: IconComp, label, value, sub, color }) {
  const Icon = IconComp;
  return (
    <div className="rounded-2xl p-4 flex items-center gap-3"
      style={{ background: 'rgba(10,15,20,0.85)', border: `1px solid ${color}30` }}>
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}18`, border: `1px solid ${color}35` }}>
        <Icon className="w-5 h-5" style={{ color }} />
      </div>
      <div>
        <p className="text-xs text-white/40 uppercase tracking-widest font-semibold">{label}</p>
        <p className="text-xl font-black text-white leading-tight">{value}</p>
        {sub && <p className="text-xs mt-0.5" style={{ color }}>{sub}</p>}
      </div>
    </div>
  );
}

export default function SalesKPIStrip({ subscriptions, orders }) {
  const active = subscriptions.filter(s => s.status === 'active').length;
  const canceled = subscriptions.filter(s => s.status === 'canceled').length;
  const totalSubs = subscriptions.length;

  const TIER_PRICES = { trail_scout: 14.99, crystal_pro: 24.99, expedition_elite: 49.99 };
  const mrr = subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + (TIER_PRICES[s.plan] || 0), 0);

  const paidOrders = orders.filter(o => o.paymentStatus === 'paid');
  const orderRevenue = paidOrders.reduce((sum, o) => sum + ((o.amount || 0) / 100), 0);

  const churnRate = totalSubs > 0 ? ((canceled / totalSubs) * 100).toFixed(1) : '0.0';

  return (
    <div className="grid grid-cols-2 gap-3">
      <KPICard icon={Users}      label="Active Subs"  value={active.toLocaleString()}          sub={`${totalSubs} total`}           color="#00D68F" />
      <KPICard icon={DollarSign} label="Est. MRR"     value={`$${mrr.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`} sub="monthly recurring" color="#8D7CFF" />
      <KPICard icon={TrendingUp} label="Order Revenue" value={`$${orderRevenue.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`} sub={`${paidOrders.length} orders`} color="#7AE7FF" />
      <KPICard icon={RefreshCw}  label="Churn Rate"   value={`${churnRate}%`}                  sub={`${canceled} canceled`}         color="#F5B642" />
    </div>
  );
}