/**
 * SpectralSearchOverlay — universal cross-database search
 * Covers: local collection, discoveries, community posts
 *
 * Usage: mount once at app level, toggle via `open` prop.
 * <SpectralSearchOverlay open={open} onClose={() => setOpen(false)} />
 */

import React, { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, X, Gem, Compass, Users, Loader2 } from "lucide-react";
import { useSpectralSearch } from "./useSpectralSearch";
import { cloverVariants } from "@/animation/cloverVariants";

const FILTERS = [
  { key: "all",         label: "All",         icon: Search },
  { key: "collection",  label: "Collection",  icon: Gem },
  { key: "discoveries", label: "Discoveries", icon: Compass },
  { key: "community",   label: "Community",   icon: Users },
];

function ResultRow({ label, sub, color = "#7DF9FF", onClick }) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileHover={{ x: 4, backgroundColor: "rgba(255,255,255,0.04)" }}
      className="flex w-full items-start gap-3 rounded-xl px-3 py-3 text-left transition-colors"
    >
      <span
        className="mt-0.5 h-2 w-2 shrink-0 rounded-full"
        style={{ background: color, boxShadow: `0 0 6px ${color}` }}
      />
      <div className="min-w-0">
        <div className="truncate text-sm font-medium text-white/90">{label}</div>
        {sub && <div className="truncate text-xs text-white/40">{sub}</div>}
      </div>
    </motion.button>
  );
}

function Section({ title, count, children }) {
  if (!count) return null;
  return (
    <div className="mt-4">
      <div className="mb-1 px-3 text-[10px] font-bold uppercase tracking-[0.22em] text-white/35">
        {title} · {count}
      </div>
      {children}
    </div>
  );
}

export default function SpectralSearchOverlay({ open, onClose }) {
  const { query, handleQuery, results, loading, filter, handleFilter, clear, totalCount } = useSpectralSearch();
  const inputRef = useRef(null);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 80);
    else clear();
  }, [open]);

  useEffect(() => {
    const handler = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-[200] bg-black/70 backdrop-blur-md"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            className="fixed inset-x-4 top-[5vh] z-[201] mx-auto max-w-xl"
            variants={cloverVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
          >
            <div
              className="overflow-hidden rounded-[28px] border border-white/10"
              style={{
                background: "linear-gradient(145deg, rgba(10,15,20,0.94) 0%, rgba(14,20,27,0.90) 100%)",
                backdropFilter: "blur(28px)",
                boxShadow: "0 32px 80px rgba(0,0,0,0.7), 0 0 0 1px rgba(125,249,255,0.08)",
              }}
            >
              {/* Input row */}
              <div className="flex items-center gap-3 border-b border-white/[0.07] px-4 py-3">
                {loading
                  ? <Loader2 className="h-5 w-5 shrink-0 animate-spin text-cyan-300/70" />
                  : <Search className="h-5 w-5 shrink-0 text-white/35" />
                }
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => handleQuery(e.target.value)}
                  aria-label="Search across collection, discoveries, and community"
                  placeholder="Search specimens, minerals, discoveries…"
                  aria-label="Search"
                  className="min-w-0 flex-1 bg-transparent text-sm text-white placeholder-white/30 outline-none"
                />
                {query && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    title="Clear search"
                    onClick={clear}
                    className="text-white/30 hover:text-white/60"
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
                <button
                  type="button"
                  aria-label="Close search"
                  title="Close search"
                  onClick={onClose}
                  className="ml-1 text-white/30 hover:text-white/60"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Filter pills */}
              <div className="flex gap-2 overflow-x-auto px-4 py-2.5 scrollbar-none">
                {FILTERS.map((f) => {
                  const Icon = f.icon;
                  const active = filter === f.key;
                  return (
                    <button
                      key={f.key}
                      type="button"
                      onClick={() => handleFilter(f.key)}
                      className="flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold uppercase tracking-wide transition-all"
                      style={{
                        background: active ? "rgba(125,249,255,0.12)" : "rgba(255,255,255,0.05)",
                        border: `1px solid ${active ? "rgba(125,249,255,0.35)" : "rgba(255,255,255,0.08)"}`,
                        color: active ? "#7DF9FF" : "rgba(255,255,255,0.45)",
                      }}
                    >
                      <Icon className="h-3 w-3" />
                      {f.label}
                    </button>
                  );
                })}
              </div>

              {/* Results */}
              <div className="max-h-[58vh] overflow-y-auto px-2 pb-4">
                {!query && (
                  <div className="py-10 text-center text-sm text-white/25">
                    Start typing to search all databases…
                  </div>
                )}

                {query && !loading && totalCount === 0 && (
                  <div className="py-10 text-center text-sm text-white/25">
                    No results for "{query}"
                  </div>
                )}

                <Section title="Collection" count={results.specimens.length}>
                  {results.specimens.map((s) => (
                    <ResultRow
                      key={s.id}
                      label={s.name || s.mineral_type || "Unnamed Specimen"}
                      sub={s.locality || s.notes}
                      color="#7DF9FF"
                    />
                  ))}
                </Section>

                <Section title="Discoveries" count={results.discoveries.length}>
                  {results.discoveries.map((d) => (
                    <ResultRow
                      key={d.id}
                      label={d.mineral_name}
                      sub={d.location_name || d.notes}
                      color="#00FFC6"
                    />
                  ))}
                </Section>

                <Section title="Community" count={results.community.length}>
                  {results.community.map((p) => (
                    <ResultRow
                      key={p.id}
                      label={p.content?.slice(0, 80) || "Post"}
                      sub={p.user_display_name}
                      color="#9B5CFF"
                    />
                  ))}
                </Section>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}