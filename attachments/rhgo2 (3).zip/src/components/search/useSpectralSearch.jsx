/**
 * useSpectralSearch — unified search across Mineralpedia, Specimen, Discovery
 * Supports natural language queries + tag/type filters.
 */

import { useState, useCallback, useRef } from "react";
import { base44 } from "@/api/base44Client";

const DEBOUNCE_MS = 280;

export function useSpectralSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState({ specimens: [], discoveries: [], community: [] });
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState("all"); // all | collection | discoveries | community
  const debounceRef = useRef(null);

  const search = useCallback(async (q, f = filter) => {
    const trimmed = q.trim();
    if (!trimmed) {
      setResults({ specimens: [], discoveries: [], community: [] });
      return;
    }
    setLoading(true);

    // Build per-source filter objects
    const specimenFilter = { $or: [
      { name: { $regex: trimmed, $options: "i" } },
      { mineral_type: { $regex: trimmed, $options: "i" } },
      { tags: { $regex: trimmed, $options: "i" } },
    ]};

    const discoveryFilter = {
      mineral_name: { $regex: trimmed, $options: "i" },
    };

    const postFilter = {
      content: { $regex: trimmed, $options: "i" },
    };

    const [specimens, discoveries, community] = await Promise.all([
      f === "all" || f === "collection"
        ? base44.entities.Specimen.filter(specimenFilter, "-updated_date", 20).catch(() => [])
        : [],
      f === "all" || f === "discoveries"
        ? base44.entities.Discovery.filter(discoveryFilter, "-created_date", 12).catch(() => [])
        : [],
      f === "all" || f === "community"
        ? base44.entities.Post.filter(postFilter, "-created_date", 8).catch(() => [])
        : [],
    ]);

    setResults({ specimens, discoveries, community });
    setLoading(false);
  }, [filter]);

  const handleQuery = useCallback((q) => {
    setQuery(q);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => search(q, filter), DEBOUNCE_MS);
  }, [search, filter]);

  const handleFilter = useCallback((f) => {
    setFilter(f);
    if (query.trim()) search(query, f);
  }, [query, search]);

  const clear = useCallback(() => {
    setQuery("");
    setResults({ specimens: [], discoveries: [], community: [] });
  }, []);

  const totalCount = results.specimens.length + results.discoveries.length + results.community.length;

  return { query, handleQuery, results, loading, filter, handleFilter, clear, totalCount };
}