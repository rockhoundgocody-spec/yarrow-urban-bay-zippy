/**
 * ItineraryDayCard
 * Full day card with draggable site list, drive times, gear checklist, weather, and notes.
 * D&D uses @hello-pangea/dnd (Draggable + Droppable).
 */
import React, { useState } from "react";
import { Droppable, Draggable } from "@hello-pangea/dnd";
import { MapPin, Package, X, GripVertical } from "lucide-react";
import GearChecklistPanel from "./GearChecklistPanel";
import WeatherAlertBanner from "./WeatherAlertBanner";
import DriveTimeStrip from "./DriveTimeStrip";

function SiteRow({ site, index, dayIndex, onRemove, onSelectSite, isSelected }) {
  return (
    <Draggable draggableId={`site-${dayIndex}-${index}`} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className="rounded-xl overflow-hidden"
          style={{
            ...provided.draggableProps.style,
            background: isSelected
              ? "rgba(122,231,255,0.08)"
              : snapshot.isDragging
              ? "rgba(245,182,66,0.12)"
              : "rgba(255,255,255,0.04)",
            border: `1px solid ${
              isSelected
                ? "rgba(122,231,255,0.3)"
                : snapshot.isDragging
                ? "rgba(245,182,66,0.35)"
                : "rgba(255,255,255,0.07)"
            }`,
            boxShadow: snapshot.isDragging ? "0 8px 32px rgba(0,0,0,0.5)" : undefined,
            marginBottom: 6,
          }}
        >
          <div className="flex items-center gap-2 px-3 py-2.5">
            {/* Drag handle */}
            <div {...provided.dragHandleProps} className="cursor-grab active:cursor-grabbing shrink-0 p-0.5">
              <GripVertical className="w-3.5 h-3.5" style={{ color: "rgba(255,255,255,0.2)" }} />
            </div>

            {/* Order badge */}
            <div className="w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-black"
              style={{ background: "rgba(245,182,66,0.15)", color: "#F5B642" }}>
              {index + 1}
            </div>

            {/* Site info */}
            <button
              onClick={() => onSelectSite(site)}
              className="flex-1 min-w-0 text-left"
            >
              <p className="text-sm font-semibold text-white truncate">{site.name}</p>
              {site.notes && (
                <p className="text-[10px] text-white/35 truncate mt-0.5">{site.notes}</p>
              )}
            </button>

            {/* Type pill */}
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full shrink-0"
              style={{
                background: site.type === "rockhounding" ? "rgba(0,214,143,0.12)" : "rgba(141,124,255,0.12)",
                color: site.type === "rockhounding" ? "#00D68F" : "#8D7CFF",
                border: `1px solid ${site.type === "rockhounding" ? "rgba(0,214,143,0.25)" : "rgba(141,124,255,0.25)"}`,
              }}>
              {site.type === "rockhounding" ? "Site" : "Find"}
            </span>

            <button
              aria-label={`Remove ${site.name}`}
              title={`Remove ${site.name}`}
              onClick={() => onRemove(index)}
              className="p-1 shrink-0 transition-all hover:bg-red-500/10 rounded"
              style={{ color: "rgba(239,68,68,0.4)" }}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </Draggable>
  );
}

export default function ItineraryDayCard({ day, dayIndex, onUpdateDay, onRemoveSite, onSelectSite, selectedSiteId }) {
  const [tab, setTab] = useState("sites");
  const [dayNote, setDayNote] = useState(day.day_notes || "");
  const [noteSaved, setNoteSaved] = useState(false);

  const handleGearChange = (gear) => onUpdateDay(dayIndex, { ...day, gear });
  const handleGearUpdate = (gear) => onUpdateDay(dayIndex, { ...day, gear });

  const checkedGear = (day.gear || []).filter(g => g.checked).length;
  const totalGear = (day.gear || []).length;
  const sites = day.sites || [];

  const handleSaveDayNote = () => {
    onUpdateDay(dayIndex, { ...day, day_notes: dayNote });
    setNoteSaved(true);
    setTimeout(() => setNoteSaved(false), 2000);
  };

  return (
    <div className="rounded-2xl overflow-hidden"
      style={{ background: "rgba(14,18,26,0.9)", border: "1px solid rgba(255,255,255,0.07)" }}>

      {/* Day header */}
      <div className="px-4 py-3 flex items-center justify-between"
        style={{ background: "linear-gradient(135deg, rgba(0,214,143,0.05), rgba(122,231,255,0.03))" }}>
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: "rgba(0,214,143,0.6)" }}>Day {dayIndex + 1}</p>
          <p className="text-sm font-bold text-white">{day.label || day.date}</p>
        </div>
        <div className="flex items-center gap-3 text-xs">
          <span className="flex items-center gap-1" style={{ color: "rgba(255,255,255,0.35)" }}>
            <MapPin className="w-3 h-3" />{sites.length}
          </span>
          {totalGear > 0 && (
            <span className="flex items-center gap-1"
              style={{ color: checkedGear === totalGear ? "#00D68F" : "rgba(255,255,255,0.35)" }}>
              <Package className="w-3 h-3" />{checkedGear}/{totalGear}
            </span>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
        {[
          { key: "sites",   label: `Sites (${sites.length})` },
          { key: "gear",    label: totalGear ? `Gear (${checkedGear}/${totalGear})` : "Gear" },
          { key: "weather", label: "Weather" },
          { key: "notes",   label: "Notes" },
        ].map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className="flex-1 py-2 text-xs font-semibold transition-all"
            style={{
              color: tab === t.key ? "#7AE7FF" : "rgba(255,255,255,0.28)",
              borderBottom: tab === t.key ? "2px solid #7AE7FF" : "2px solid transparent",
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="p-4">

        {/* ── Sites tab with D&D ── */}
        {tab === "sites" && (
          <Droppable droppableId={`day-${dayIndex}`} type="SITE">
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className="min-h-[40px] transition-all rounded-xl"
                style={{
                  background: snapshot.isDraggingOver ? "rgba(0,214,143,0.04)" : "transparent",
                  border: snapshot.isDraggingOver ? "1px dashed rgba(0,214,143,0.25)" : "1px solid transparent",
                }}
              >
                {sites.length === 0 && !snapshot.isDraggingOver ? (
                  <div className="flex flex-col items-center gap-2 py-6 text-center">
                    <MapPin className="w-6 h-6" style={{ color: "rgba(255,255,255,0.1)" }} />
                    <p className="text-xs text-white/25">No sites yet — drag one here or use the pin button below.</p>
                  </div>
                ) : (
                  <>
                    {sites.map((site, i) => (
                      <React.Fragment key={`${site.id}-${i}`}>
                        <SiteRow
                          site={site}
                          index={i}
                          dayIndex={dayIndex}
                          onRemove={(idx) => onRemoveSite(dayIndex, idx)}
                          onSelectSite={onSelectSite}
                          isSelected={selectedSiteId === site.id}
                        />
                        {/* Drive time between consecutive sites */}
                        {i < sites.length - 1 && (
                          <DriveTimeStrip fromSite={sites[i]} toSite={sites[i + 1]} />
                        )}
                      </React.Fragment>
                    ))}
                  </>
                )}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        )}

        {/* ── Gear tab ── */}
        {tab === "gear" && (
          <GearChecklistPanel
            gear={day.gear || []}
            onChange={(gear) => onUpdateDay(dayIndex, { ...day, gear })}
          />
        )}

        {/* ── Weather tab ── */}
        {tab === "weather" && (
          <WeatherAlertBanner
            sites={sites}
            date={day.date}
            weatherFetched={day.weather_fetched}
            onWeatherFetched={(w) => onUpdateDay(dayIndex, { ...day, weather_fetched: w })}
          />
        )}

        {/* ── Notes tab ── */}
        {tab === "notes" && (
          <div className="space-y-3">
            <textarea
              value={dayNote}
              onChange={e => setDayNote(e.target.value)}
              placeholder={`Notes for ${day.label || `Day ${dayIndex + 1}`}…`}
              rows={5}
              className="w-full px-3 py-2.5 rounded-xl text-sm text-white placeholder-white/25 outline-none resize-none"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
            />
            <button
              onClick={handleSaveDayNote}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all"
              style={{
                background: noteSaved ? "rgba(0,214,143,0.15)" : "rgba(255,255,255,0.06)",
                color: noteSaved ? "#00D68F" : "rgba(255,255,255,0.5)",
                border: `1px solid ${noteSaved ? "rgba(0,214,143,0.3)" : "rgba(255,255,255,0.08)"}`,
              }}
            >
              {noteSaved ? "✓ Saved" : "Save Note"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}