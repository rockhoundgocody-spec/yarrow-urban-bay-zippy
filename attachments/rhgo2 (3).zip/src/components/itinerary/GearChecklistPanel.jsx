import React, { useState } from "react";
import { Plus, Check, Trash2, Package } from "lucide-react";

const PRESET_CATEGORIES = {
  Safety: ["First aid kit", "Emergency whistle", "Sun protection", "Water (2L+)", "Headlamp"],
  Tools: ["Rock hammer", "Chisels", "Pry bar", "Hand lens (10x)", "Field notebook"],
  Collection: ["Collection bags", "Bubble wrap", "Labels/markers", "Field ID guide"],
  Navigation: ["GPS device", "Topo map", "Compass"],
};

export default function GearChecklistPanel({ gear = [], onChange }) {
  const [newItem, setNewItem] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Tools");
  const [showPresets, setShowPresets] = useState(false);

  const toggleItem = (idx) => {
    const updated = gear.map((g, i) => i === idx ? { ...g, checked: !g.checked } : g);
    onChange(updated);
  };

  const addItem = (item, category = selectedCategory) => {
    if (!item.trim()) return;
    onChange([...gear, { item: item.trim(), checked: false, category }]);
    setNewItem("");
  };

  const removeItem = (idx) => {
    onChange(gear.filter((_, i) => i !== idx));
  };

  const addPreset = (item, category) => {
    if (!gear.find(g => g.item === item)) addItem(item, category);
  };

  const groupedGear = gear.reduce((acc, g, i) => {
    const cat = g.category || "Other";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push({ ...g, _idx: i });
    return acc;
  }, {});

  const checked = gear.filter(g => g.checked).length;

  return (
    <div className="space-y-3">
      {/* Progress */}
      <div className="flex items-center justify-between text-xs text-white/50 mb-1">
        <span className="flex items-center gap-1.5"><Package className="w-3.5 h-3.5" /> Gear Checklist</span>
        <span className={`font-semibold ${checked === gear.length && gear.length > 0 ? "text-emerald-400" : "text-white/40"}`}>
          {checked}/{gear.length} packed
        </span>
      </div>

      {gear.length > 0 && (
        <div className="w-full h-1 rounded-full bg-white/5">
          <div
            className="h-1 rounded-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all"
            style={{ width: `${gear.length ? (checked / gear.length) * 100 : 0}%` }}
          />
        </div>
      )}

      {/* Items grouped by category */}
      {Object.entries(groupedGear).map(([cat, items]) => (
        <div key={cat}>
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/25 mb-1.5">{cat}</p>
          <div className="space-y-1">
            {items.map((g) => (
              <div key={g._idx} className="flex items-center gap-2 group">
                <button
                  aria-label={g.checked ? `Uncheck ${g.item}` : `Check ${g.item}`}
                  title={g.checked ? `Uncheck ${g.item}` : `Check ${g.item}`}
                  onClick={() => toggleItem(g._idx)}
                  className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all ${
                    g.checked ? "bg-emerald-500 border-emerald-400" : "border-white/20 bg-white/5"
                  }`}
                >
                  {g.checked && <Check className="w-3 h-3 text-white" />}
                </button>
                <span className={`flex-1 text-sm transition-all ${g.checked ? "line-through text-white/30" : "text-white/70"}`}>
                  {g.item}
                </span>
                <button
                  aria-label={`Remove ${g.item}`}
                  title={`Remove ${g.item}`}
                  onClick={() => removeItem(g._idx)}
                  className="opacity-0 group-hover:opacity-100 p-1 text-red-400/60 hover:text-red-400 transition-all"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Add item */}
      <div className="flex gap-2 pt-1">
        <select
          value={selectedCategory}
          onChange={e => setSelectedCategory(e.target.value)}
          className="bg-white/5 border border-white/10 rounded-xl text-xs text-white/60 px-2 py-2 focus:outline-none"
        >
          {Object.keys(PRESET_CATEGORIES).map(c => <option key={c} value={c}>{c}</option>)}
          <option value="Other">Other</option>
        </select>
        <input
          value={newItem}
          onChange={e => setNewItem(e.target.value)}
          onKeyDown={e => e.key === "Enter" && addItem(newItem)}
          placeholder="Add gear item..."
          className="flex-1 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder:text-white/25 px-3 py-2 focus:outline-none focus:border-amber-500/40"
        />
        <button
          aria-label="Add custom gear item"
          title="Add custom gear item"
          onClick={() => addItem(newItem)}
          className="w-9 h-9 flex items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 transition-all"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {/* Presets */}
      <button
        onClick={() => setShowPresets(v => !v)}
        className="text-xs text-cyan-400/60 hover:text-cyan-400 transition-all"
      >
        {showPresets ? "▲ Hide" : "▼ Add"} presets
      </button>

      {showPresets && (
        <div className="space-y-2 mt-1">
          {Object.entries(PRESET_CATEGORIES).map(([cat, items]) => (
            <div key={cat}>
              <p className="text-[10px] font-bold uppercase text-white/25 mb-1">{cat}</p>
              <div className="flex flex-wrap gap-1.5">
                {items.map(item => {
                  const added = !!gear.find(g => g.item === item);
                  return (
                    <button
                      key={item}
                      onClick={() => addPreset(item, cat)}
                      disabled={added}
                      className={`text-[11px] px-2 py-1 rounded-full border transition-all ${
                        added
                          ? "border-emerald-500/30 text-emerald-400/50 bg-emerald-500/5"
                          : "border-white/10 text-white/50 bg-white/5 hover:border-amber-500/40 hover:text-amber-400"
                      }`}
                    >
                      {added ? "✓ " : "+ "}{item}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}