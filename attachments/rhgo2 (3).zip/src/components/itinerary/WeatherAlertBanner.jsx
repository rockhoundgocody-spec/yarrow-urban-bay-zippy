import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import { CloudSun, CloudRain, Wind, AlertTriangle, RefreshCw } from "lucide-react";

const conditionIcon = (desc = "") => {
  const d = desc.toLowerCase();
  if (d.includes("storm") || d.includes("thunder")) return "⛈️";
  if (d.includes("rain") || d.includes("shower")) return "🌧️";
  if (d.includes("snow")) return "❄️";
  if (d.includes("cloud")) return "☁️";
  if (d.includes("fog") || d.includes("mist")) return "🌫️";
  return "☀️";
};

const getSeverity = (weather) => {
  if (!weather) return null;
  const alerts = [];
  if (weather.wind_mph > 30) alerts.push({ text: `High winds: ${weather.wind_mph} mph`, color: "text-orange-400" });
  if (weather.precip_chance > 60) alerts.push({ text: `${weather.precip_chance}% rain chance`, color: "text-blue-400" });
  if (weather.temp_high_f > 95) alerts.push({ text: `Extreme heat: ${weather.temp_high_f}°F`, color: "text-red-400" });
  if (weather.temp_low_f < 32) alerts.push({ text: `Freezing temps: ${weather.temp_low_f}°F`, color: "text-cyan-400" });
  return alerts;
};

export default function WeatherAlertBanner({ date, latitude, longitude, cachedWeather, onWeatherFetched }) {
  const [weather, setWeather] = useState(cachedWeather || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (cachedWeather) { setWeather(cachedWeather); return; }
    if (date && latitude && longitude) fetchWeather();
  }, [date, latitude, longitude]);

  const fetchWeather = async () => {
    if (!date || !latitude || !longitude) return;
    setLoading(true);
    setError(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Provide a brief weather forecast for coordinates (${latitude}, ${longitude}) on ${date}. Use your geographic knowledge to estimate realistic conditions for that region and season. Return as JSON.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            condition: { type: "string" },
            temp_high_f: { type: "number" },
            temp_low_f: { type: "number" },
            precip_chance: { type: "number" },
            wind_mph: { type: "number" },
            summary: { type: "string" },
            field_advisory: { type: "string" }
          }
        }
      });
      setWeather(result);
      onWeatherFetched?.(result);
    } catch {
      setError("Weather unavailable");
    }
    setLoading(false);
  };

  if (!date) return null;

  if (loading) {
    return (
      <div className="flex items-center gap-2 py-2 px-3 rounded-xl bg-white/5 border border-white/8">
        <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
        <span className="text-xs text-white/40">Fetching weather for {date}...</span>
      </div>
    );
  }

  if (error || !weather) {
    return (
      <button
        onClick={fetchWeather}
        className="flex items-center gap-2 py-2 px-3 rounded-xl bg-white/5 border border-white/8 text-xs text-white/35 hover:text-cyan-400 transition-all w-full text-left"
      >
        <CloudSun className="w-3.5 h-3.5" />
        Fetch weather forecast for {date}
      </button>
    );
  }

  const alerts = getSeverity(weather);

  return (
    <div className="rounded-xl bg-[#0c1a2e] border border-blue-500/15 p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-lg leading-none">{conditionIcon(weather.condition)}</span>
          <div>
            <p className="text-xs font-semibold text-white/80">{weather.condition}</p>
            <p className="text-[10px] text-white/35">{date}</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-sm font-bold text-white">{weather.temp_high_f}°<span className="text-white/30 text-xs">/{weather.temp_low_f}°F</span></p>
          <div className="flex items-center gap-2 text-[10px] text-white/35 justify-end">
            <span className="flex items-center gap-0.5"><CloudRain className="w-2.5 h-2.5" />{weather.precip_chance}%</span>
            <span className="flex items-center gap-0.5"><Wind className="w-2.5 h-2.5" />{weather.wind_mph}mph</span>
          </div>
        </div>
      </div>

      {weather.summary && (
        <p className="text-xs text-white/50 leading-relaxed">{weather.summary}</p>
      )}

      {alerts?.length > 0 && (
        <div className="space-y-1">
          {alerts.map((a, i) => (
            <div key={i} className={`flex items-center gap-1.5 text-xs ${a.color}`}>
              <AlertTriangle className="w-3 h-3 shrink-0" />
              {a.text}
            </div>
          ))}
        </div>
      )}

      {weather.field_advisory && (
        <div className="bg-amber-500/8 border border-amber-500/20 rounded-lg px-2.5 py-1.5">
          <p className="text-[11px] text-amber-300/80">⛏ Field note: {weather.field_advisory}</p>
        </div>
      )}

      <button onClick={fetchWeather} className="text-[10px] text-white/20 hover:text-cyan-400 transition-all">
        ↻ Refresh
      </button>
    </div>
  );
}