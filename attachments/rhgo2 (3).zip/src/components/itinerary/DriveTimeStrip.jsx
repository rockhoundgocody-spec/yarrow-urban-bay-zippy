/**
 * DriveTimeStrip
 * Shows estimated drive time + distance between consecutive sites on a day.
 * Uses Haversine for distance and 45mph average speed for time estimate.
 * Lightweight — no API key required.
 */
import React from "react";
import { Car, Clock } from "lucide-react";

const EARTH_KM = 6371;
const AVG_SPEED_MPH = 45;
const KM_TO_MI = 0.621371;

function toRad(deg) { return (deg * Math.PI) / 180; }

function haversineMi(lat1, lng1, lat2, lng2) {
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return EARTH_KM * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) * KM_TO_MI;
}

function formatTime(hours) {
  const h = Math.floor(hours);
  const m = Math.round((hours - h) * 60);
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

export default function DriveTimeStrip({ fromSite, toSite }) {
  if (
    fromSite?.latitude == null || fromSite?.longitude == null ||
    toSite?.latitude == null  || toSite?.longitude == null
  ) return null;

  const distMi = haversineMi(fromSite.latitude, fromSite.longitude, toSite.latitude, toSite.longitude);
  const driveHrs = distMi / AVG_SPEED_MPH;

  return (
    <div className="flex items-center justify-center gap-3 py-1.5 mx-4">
      <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.06)" }} />
      <div className="flex items-center gap-2 px-3 py-1 rounded-full shrink-0"
        style={{ background: "rgba(245,182,66,0.07)", border: "1px solid rgba(245,182,66,0.18)" }}>
        <Car className="w-3 h-3" style={{ color: "#F5B642" }} />
        <span className="text-[10px] font-bold" style={{ color: "#F5B642" }}>
          {distMi.toFixed(1)} mi
        </span>
        <span className="text-[9px] text-white/25">·</span>
        <Clock className="w-3 h-3" style={{ color: "rgba(245,182,66,0.7)" }} />
        <span className="text-[10px] font-semibold text-white/40">{formatTime(driveHrs)}</span>
      </div>
      <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.06)" }} />
    </div>
  );
}