import React, { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Polyline, Popup, useMap } from "react-leaflet";
import L from "leaflet";

// Haversine distance in km
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Nearest-neighbor TSP approximation for route optimization
function optimizeRoute(sites) {
  if (sites.length <= 2) return sites;
  const remaining = [...sites];
  const route = [remaining.shift()];
  while (remaining.length > 0) {
    const last = route[route.length - 1];
    let nearest = 0;
    let minDist = Infinity;
    remaining.forEach((s, i) => {
      const d = Math.hypot(s.latitude - last.latitude, s.longitude - last.longitude);
      if (d < minDist) { minDist = d; nearest = i; }
    });
    route.push(remaining.splice(nearest, 1)[0]);
  }
  return route;
}

function makeIcon(label, color) {
  return L.divIcon({
    className: "",
    html: `<div style="
      width:30px;height:30px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);
      background:${color};border:2px solid rgba(255,255,255,0.8);
      display:flex;align-items:center;justify-content:center;
      box-shadow:0 2px 8px rgba(0,0,0,0.5);
    ">
      <span style="transform:rotate(45deg);color:white;font-weight:700;font-size:11px;">${label}</span>
    </div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
  });
}

function FitBounds({ positions }) {
  const map = useMap();
  useEffect(() => {
    if (positions.length > 0) {
      map.fitBounds(positions, { padding: [40, 40], maxZoom: 13 });
    }
  }, [positions.length]);
  return null;
}

export default function ItineraryMap({ days, onSiteClick, selectedSiteId }) {
  // Flatten all sites across days with day index
  const allSites = [];
  days.forEach((day, di) => {
    (day.sites || []).forEach((site, si) => {
      allSites.push({ ...site, _dayIndex: di, _siteIndex: si, _globalIndex: allSites.length });
    });
  });

  const validSites = allSites.filter(s => s.latitude && s.longitude);
  const optimized = optimizeRoute(validSites);
  const routePositions = optimized.map(s => [s.latitude, s.longitude]);

  const DAY_COLORS = ["#00f5ff", "#ff00ff", "#00ffaa", "#ff6600", "#a78bfa", "#fbbf24"];

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden border border-white/8">
      <MapContainer
        center={validSites.length > 0 ? [validSites[0].latitude, validSites[0].longitude] : [39.8, -98.5]}
        zoom={validSites.length > 0 ? 7 : 4}
        style={{ width: "100%", height: "100%" }}
        zoomControl={true}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_matter_nolabels/{z}/{x}/{y}{r}.png"
          attribution='&copy; CartoDB'
        />

        {validSites.length > 0 && <FitBounds positions={routePositions} />}

        {/* Optimized route line */}
        {routePositions.length > 1 && (
          <Polyline
            positions={routePositions}
            pathOptions={{
              color: "#00f5ff",
              weight: 2.5,
              opacity: 0.7,
              dashArray: "8 6",
            }}
          />
        )}

        {/* Site markers */}
        {optimized.map((site, i) => {
          const color = DAY_COLORS[site._dayIndex % DAY_COLORS.length];
          const isSelected = selectedSiteId === site.id;
          return (
            <Marker
              key={`${site._dayIndex}-${site._siteIndex}`}
              position={[site.latitude, site.longitude]}
              icon={makeIcon(i + 1, isSelected ? "#d4af37" : color)}
              eventHandlers={{ click: () => onSiteClick?.(site) }}
            >
              <Popup>
                <div className="text-xs font-semibold">{site.name}</div>
                <div className="text-xs text-gray-500 capitalize">{site.type} · Day {site._dayIndex + 1}</div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {/* Legend */}
      {days.length > 1 && (
        <div className="absolute top-3 right-3 z-[1000] rounded-xl bg-black/80 border border-white/10 px-3 py-2 backdrop-blur-sm">
          <p className="text-[10px] text-white/40 font-bold uppercase mb-1.5">Days</p>
          {days.map((day, i) => (
            <div key={i} className="flex items-center gap-1.5 mb-0.5">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: DAY_COLORS[i % DAY_COLORS.length] }} />
              <span className="text-[10px] text-white/60">Day {i + 1} · {(day.sites || []).length} sites</span>
            </div>
          ))}
        </div>
      )}

      {/* Route stats */}
      {validSites.length > 1 && (() => {
        let totalKm = 0;
        for (let i = 1; i < optimized.length; i++) {
          totalKm += haversineKm(optimized[i-1].latitude, optimized[i-1].longitude, optimized[i].latitude, optimized[i].longitude);
        }
        return (
          <div className="absolute bottom-3 left-3 z-[1000] rounded-xl bg-black/80 border border-cyan-500/20 px-3 py-2 backdrop-blur-sm">
            <p className="text-[10px] text-cyan-400 font-semibold">
              {validSites.length} stops · {totalKm.toFixed(0)} km · optimized route
            </p>
          </div>
        );
      })()}
    </div>
  );
}