import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Gem, MapPin, FileText, ChevronDown, ChevronUp } from "lucide-react";

// Aggregate discoveries and location logs linked to sites in the itinerary
function LinkedDiscoveriesSection({ allSiteIds, allSiteNames }) {
  const [expanded, setExpanded] = useState(true);

  const { data: specimens = [] } = useQuery({
    queryKey: ["trip-specimens"],
    queryFn: () => base44.entities.Specimen.list("-created_date", 100),
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["trip-logs"],
    queryFn: () => base44.entities.LocationLog.list("-created_date", 100),
  });

  // Match specimens whose location_found matches any site name (fuzzy)
  const linkedSpecimens = specimens.filter(s =>
    allSiteNames.some(name => s.location_found?.toLowerCase().includes(name.toLowerCase()))
  );

  // Match location logs to site IDs
  const linkedLogs = logs.filter(l => allSiteIds.includes(l.location_id));

  return (
    <div className="rounded-2xl bg-[#0f0f1e] border border-white/6 overflow-hidden">
      <button
        onClick={() => setExpanded(v => !v)}
        className="w-full flex items-center justify-between px-4 py-3"
        style={{ background: "linear-gradient(135deg, rgba(167,139,250,0.06), rgba(0,214,143,0.04))" }}
      >
        <div className="flex items-center gap-2">
          <Gem className="w-4 h-4 text-purple-400" />
          <span className="text-sm font-bold text-white">Linked Field Data</span>
          <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-semibold">
            {linkedSpecimens.length + linkedLogs.length}
          </span>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {expanded && (
        <div className="p-4 space-y-4">
          {/* Specimens */}
          {linkedSpecimens.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-purple-400/70 mb-2">Specimen Discoveries ({linkedSpecimens.length})</p>
              <div className="space-y-1.5">
                {linkedSpecimens.slice(0, 12).map(s => (
                  <div key={s.id} className="flex items-center gap-2.5 p-2 rounded-xl bg-white/[0.02] border border-white/5">
                    {s.photo_url
                      ? <img src={s.photo_url} className="w-8 h-8 rounded-lg object-cover shrink-0" />
                      : <div className="w-8 h-8 rounded-lg bg-purple-500/15 flex items-center justify-center shrink-0"><Gem className="w-3.5 h-3.5 text-purple-400" /></div>
                    }
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">{s.name}</p>
                      <p className="text-[10px] text-white/35 truncate">{s.location_found} · {s.category || "mineral"}</p>
                    </div>
                    {s.confidence_score && (
                      <span className="text-[10px] text-emerald-400 shrink-0 font-semibold ml-auto">{s.confidence_score}%</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Location logs */}
          {linkedLogs.length > 0 && (
            <div>
              <p className="text-[10px] font-bold uppercase tracking-widest text-cyan-400/70 mb-2">Field Observations ({linkedLogs.length})</p>
              <div className="space-y-1.5">
                {linkedLogs.slice(0, 8).map(l => (
                  <div key={l.id} className="p-2.5 rounded-xl bg-white/[0.02] border border-white/5">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-white">{l.location_name}</p>
                      <p className="text-[10px] text-white/35">{l.visit_date}</p>
                    </div>
                    {l.notes && <p className="text-[11px] text-white/50 mt-1 line-clamp-2">{l.notes}</p>}
                    {(l.specimens_found || []).length > 0 && (
                      <p className="text-[10px] text-emerald-400 mt-1">{l.specimens_found.slice(0, 5).join(" · ")}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {linkedSpecimens.length === 0 && linkedLogs.length === 0 && (
            <p className="text-xs text-white/25 text-center py-4">No linked field data yet — discoveries and logs from pinned sites will appear here automatically.</p>
          )}
        </div>
      )}
    </div>
  );
}

export default function TripNotesPanel({ plan, onUpdateNotes, onUpdateSiteNote }) {
  const [noteText, setNoteText] = useState(plan.notes || "");
  const [saved, setSaved] = useState(false);

  const allSiteIds = (plan.days || []).flatMap(d => (d.sites || []).map(s => s.id));
  const allSiteNames = (plan.days || []).flatMap(d => (d.sites || []).map(s => s.name).filter(Boolean));

  const handleSaveNote = () => {
    onUpdateNotes(noteText);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Plan-level notes */}
      <div className="rounded-2xl bg-[#14141e] border border-white/6 overflow-hidden">
        <div className="px-4 py-3 flex items-center gap-2 border-b border-white/5"
          style={{ background: "linear-gradient(135deg, rgba(245,182,66,0.06), rgba(0,214,143,0.04))" }}>
          <FileText className="w-4 h-4 text-amber-400" />
          <span className="text-sm font-bold text-white">Trip Field Notes</span>
        </div>
        <div className="p-4">
          <textarea
            value={noteText}
            onChange={e => setNoteText(e.target.value)}
            placeholder="Record overall trip observations, geology notes, weather conditions, access info, tips for future visits..."
            className="w-full bg-white/[0.03] border border-white/8 rounded-xl text-sm text-white placeholder:text-white/25 p-3 focus:outline-none focus:border-amber-500/40 resize-none"
            rows={5}
          />
          <div className="flex items-center justify-between mt-2">
            <p className="text-[10px] text-white/25">{noteText.length} chars</p>
            <button
              onClick={handleSaveNote}
              className={`text-xs font-semibold px-3 py-1.5 rounded-lg transition-all ${
                saved ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400 hover:bg-amber-500/30"
              }`}
            >
              {saved ? "Saved ✓" : "Save Notes"}
            </button>
          </div>
        </div>
      </div>

      {/* Site-level notes */}
      {allSiteNames.length > 0 && (
        <div className="rounded-2xl bg-[#14141e] border border-white/6 overflow-hidden">
          <div className="px-4 py-3 border-b border-white/5"
            style={{ background: "linear-gradient(135deg, rgba(0,245,255,0.04), rgba(139,0,255,0.04))" }}>
            <p className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" /> Site Observations
            </p>
          </div>
          <div className="p-4 space-y-3">
            {(plan.days || []).map((day, di) =>
              (day.sites || []).map((site, si) => (
                <SiteNoteRow
                  key={`${di}-${si}`}
                  site={site}
                  dayIndex={di}
                  siteIndex={si}
                  onSave={(note) => onUpdateSiteNote(di, si, note)}
                />
              ))
            )}
          </div>
        </div>
      )}

      {/* Linked field data */}
      {allSiteIds.length > 0 && (
        <LinkedDiscoveriesSection allSiteIds={allSiteIds} allSiteNames={allSiteNames} />
      )}
    </div>
  );
}

function SiteNoteRow({ site, dayIndex, siteIndex, onSave }) {
  const [note, setNote] = useState(site.field_note || site.notes || "");
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    onSave(note);
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5">
      <div className="flex items-center justify-between mb-1.5">
        <p className="text-xs font-semibold text-white truncate flex-1">{site.name}</p>
        <div className="flex items-center gap-1.5 ml-2">
          <span className="text-[10px] text-white/30">Day {dayIndex + 1}</span>
          {saved && <span className="text-[10px] text-emerald-400">Saved ✓</span>}
          {!editing
            ? <button onClick={() => setEditing(true)} className="text-[10px] text-cyan-400/60 hover:text-cyan-400 transition-all">Edit</button>
            : <button onClick={handleSave} className="text-[10px] text-emerald-400 hover:text-emerald-300 transition-all">Save</button>
          }
        </div>
      </div>
      {editing ? (
        <textarea
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="Field observations, minerals found, access notes..."
          className="w-full bg-white/[0.03] border border-white/8 rounded-lg text-xs text-white placeholder:text-white/20 p-2 focus:outline-none focus:border-cyan-500/30 resize-none"
          rows={3}
          autoFocus
        />
      ) : (
        <p className="text-[11px] text-white/40 leading-relaxed">
          {note || <span className="italic text-white/20">No observations recorded</span>}
        </p>
      )}
    </div>
  );
}