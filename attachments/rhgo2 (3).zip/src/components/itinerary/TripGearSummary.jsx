/**
 * TripGearSummary
 * Aggregates all per-day gear lists into a single trip-level checklist view.
 * Groups by category across all days, shows which day each item belongs to.
 */
import React, { useMemo, useState } from "react";
import { Package, Check, ChevronDown, ChevronUp } from "lucide-react";

export default function TripGearSummary({ days = [] }) {
  const [expanded, setExpanded] = useState({});

  // Build category → [{item, checked, category, day}]
  const grouped = useMemo(() => {
    const acc = {};
    days.forEach((day, di) => {
      (day.gear || []).forEach(g => {
        const cat = g.category || "Other";
        if (!acc[cat]) acc[cat] = [];
        acc[cat].push({ ...g, dayLabel: day.label || `Day ${di + 1}` });
      });
    });
    return acc;
  }, [days]);

  const allItems = days.flatMap(d => d.gear || []);
  const checkedCount = allItems.filter(g => g.checked).length;
  const total = allItems.length;

  if (total === 0) {
    return (
      <div className="flex flex-col items-center gap-3 py-10 text-center">
        <Package className="w-8 h-8" style={{ color: "rgba(245,182,66,0.25)" }} />
        <p className="text-sm text-white/35">No gear added yet.</p>
        <p className="text-xs text-white/20">Open a day and add items from the Gear tab.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary bar */}
      <div className="rounded-2xl p-4 space-y-2"
        style={{ background: "rgba(245,182,66,0.06)", border: "1px solid rgba(245,182,66,0.18)" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-4 h-4" style={{ color: "#F5B642" }} />
            <span className="text-sm font-black text-white">Trip Gear Summary</span>
          </div>
          <span className="text-xs font-black" style={{ color: checkedCount === total ? "#00D68F" : "#F5B642" }}>
            {checkedCount}/{total} packed
          </span>
        </div>
        <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
          <div className="h-full rounded-full transition-all"
            style={{ width: `${total ? (checkedCount / total) * 100 : 0}%`, background: "linear-gradient(90deg, #F5B642, #00D68F)" }} />
        </div>
      </div>

      {/* Grouped by category */}
      {Object.entries(grouped).map(([cat, items]) => {
        const catChecked = items.filter(i => i.checked).length;
        const open = expanded[cat] !== false; // default open
        return (
          <div key={cat} className="rounded-2xl overflow-hidden"
            style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <button
              onClick={() => setExpanded(e => ({ ...e, [cat]: !open }))}
              className="w-full flex items-center justify-between px-4 py-3">
              <span className="text-xs font-black uppercase tracking-widest text-white/40">{cat}</span>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold" style={{ color: catChecked === items.length ? "#00D68F" : "rgba(255,255,255,0.3)" }}>
                  {catChecked}/{items.length}
                </span>
                {open ? <ChevronUp className="w-3.5 h-3.5 text-white/25" /> : <ChevronDown className="w-3.5 h-3.5 text-white/25" />}
              </div>
            </button>
            {open && (
              <div className="px-4 pb-3 space-y-1.5 border-t border-white/[0.05]">
                {items.map((g, i) => (
                  <div key={i} className="flex items-center gap-2.5 py-1">
                    <div className={`w-4 h-4 rounded flex items-center justify-center shrink-0 ${g.checked ? "bg-emerald-500" : "border border-white/20 bg-white/5"}`}>
                      {g.checked && <Check className="w-2.5 h-2.5 text-white" />}
                    </div>
                    <span className={`flex-1 text-sm ${g.checked ? "line-through text-white/25" : "text-white/70"}`}>{g.item}</span>
                    <span className="text-[9px] text-white/20 shrink-0">{g.dayLabel}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}