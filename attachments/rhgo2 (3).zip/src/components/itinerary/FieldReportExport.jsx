import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Download, FileText, Loader2, CheckCircle } from "lucide-react";

// Haversine distance in km
function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function calcTotalDistance(days) {
  const sites = days.flatMap(d => (d.sites || []).filter(s => s.latitude && s.longitude));
  let dist = 0;
  for (let i = 1; i < sites.length; i++) {
    dist += haversineKm(sites[i - 1].latitude, sites[i - 1].longitude, sites[i].latitude, sites[i].longitude);
  }
  return dist;
}

export default function FieldReportExport({ plan }) {
  const [generating, setGenerating] = useState(false);
  const [done, setDone] = useState(false);

  const allSiteIds = (plan.days || []).flatMap(d => (d.sites || []).map(s => s.id));
  const allSiteNames = (plan.days || []).flatMap(d => (d.sites || []).map(s => s.name).filter(Boolean));

  const { data: specimens = [] } = useQuery({
    queryKey: ["trip-specimens"],
    queryFn: () => base44.entities.Specimen.list("-created_date", 200),
  });

  const { data: logs = [] } = useQuery({
    queryKey: ["trip-logs"],
    queryFn: () => base44.entities.LocationLog.list("-created_date", 200),
  });

  const linkedSpecimens = specimens.filter(s =>
    allSiteNames.some(name => s.location_found?.toLowerCase().includes(name.toLowerCase()))
  );
  const linkedLogs = logs.filter(l => allSiteIds.includes(l.location_id));
  const totalDist = calcTotalDistance(plan.days || []);
  const totalSites = (plan.days || []).reduce((acc, d) => acc + (d.sites || []).length, 0);

  const generateReport = async () => {
    setGenerating(true);

    const lines = [];
    const hr = "─".repeat(60);

    lines.push("╔══════════════════════════════════════════════════════════╗");
    lines.push("║           ROCKHOUND-GO  ·  FIELD REPORT                 ║");
    lines.push("╚══════════════════════════════════════════════════════════╝");
    lines.push("");
    lines.push(`TRIP NAME:    ${plan.name}`);
    lines.push(`DATES:        ${plan.start_date} → ${plan.end_date}`);
    lines.push(`DURATION:     ${(plan.days || []).length} days`);
    lines.push(`TOTAL SITES:  ${totalSites}`);
    lines.push(`EST. DISTANCE:${totalDist > 0 ? ` ${totalDist.toFixed(0)} km` : " N/A"}`);
    lines.push(`GENERATED:    ${new Date().toLocaleString()}`);
    lines.push("");
    lines.push(hr);
    lines.push("ITINERARY");
    lines.push(hr);
    lines.push("");

    (plan.days || []).forEach((day, di) => {
      lines.push(`DAY ${di + 1}  ·  ${day.label || day.date}`);
      lines.push("");
      if ((day.sites || []).length === 0) {
        lines.push("  No sites pinned.");
      } else {
        (day.sites || []).forEach((site, si) => {
          lines.push(`  [${si + 1}] ${site.name}`);
          lines.push(`      Type: ${site.type || "location"}`);
          if (site.latitude) lines.push(`      GPS:  ${site.latitude.toFixed(5)}, ${site.longitude.toFixed(5)}`);
          if (site.field_note || site.notes) lines.push(`      Notes: ${site.field_note || site.notes}`);
          lines.push("");
        });
      }
      if ((day.gear || []).length > 0) {
        const checked = day.gear.filter(g => g.checked);
        lines.push(`  GEAR: ${checked.length}/${day.gear.length} packed`);
        day.gear.forEach(g => lines.push(`    ${g.checked ? "[✓]" : "[ ]"} ${g.item}`));
        lines.push("");
      }
    });

    if (plan.notes) {
      lines.push(hr);
      lines.push("TRIP FIELD NOTES");
      lines.push(hr);
      lines.push("");
      lines.push(plan.notes);
      lines.push("");
    }

    if (linkedSpecimens.length > 0) {
      lines.push(hr);
      lines.push(`SPECIMEN DISCOVERIES  (${linkedSpecimens.length} found)`);
      lines.push(hr);
      lines.push("");
      linkedSpecimens.forEach(s => {
        lines.push(`• ${s.name}`);
        if (s.category) lines.push(`  Category: ${s.category}`);
        if (s.hardness) lines.push(`  Hardness: ${s.hardness} Mohs`);
        if (s.location_found) lines.push(`  Found at: ${s.location_found}`);
        if (s.confidence_score) lines.push(`  AI Confidence: ${s.confidence_score}%`);
        if (s.notes) lines.push(`  Notes: ${s.notes}`);
        lines.push("");
      });
    }

    if (linkedLogs.length > 0) {
      lines.push(hr);
      lines.push(`LOCATION FIELD OBSERVATIONS  (${linkedLogs.length} entries)`);
      lines.push(hr);
      lines.push("");
      linkedLogs.forEach(l => {
        lines.push(`📍 ${l.location_name}  —  ${l.visit_date}`);
        if (l.conditions) lines.push(`   Conditions: ${l.conditions}`);
        if ((l.specimens_found || []).length > 0) lines.push(`   Specimens: ${l.specimens_found.join(", ")}`);
        if (l.notes) lines.push(`   Notes: ${l.notes}`);
        lines.push("");
      });
    }

    lines.push(hr);
    lines.push("END OF REPORT  ·  RockHound-GO Field Intelligence System");
    lines.push(hr);

    const content = lines.join("\n");
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${plan.name.replace(/\s+/g, "_")}_FieldReport.txt`;
    a.click();
    URL.revokeObjectURL(url);

    setGenerating(false);
    setDone(true);
    setTimeout(() => setDone(false), 3000);
  };

  return (
    <div className="rounded-2xl bg-[#14141e] border border-white/6 overflow-hidden">
      <div className="px-4 py-3 border-b border-white/5"
        style={{ background: "linear-gradient(135deg, rgba(0,214,143,0.07), rgba(122,231,255,0.04))" }}>
        <p className="text-sm font-bold text-white flex items-center gap-2">
          <FileText className="w-4 h-4 text-emerald-400" /> Field Report Export
        </p>
      </div>
      <div className="p-4 space-y-3">
        {/* Summary stats */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Sites", value: totalSites, color: "#00f5ff" },
            { label: "Specimens", value: linkedSpecimens.length, color: "#a78bfa" },
            { label: "Field Logs", value: linkedLogs.length, color: "#10b981" },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-xl bg-white/[0.02] border border-white/5 p-2.5 text-center">
              <p className="text-lg font-black" style={{ color }}>{value}</p>
              <p className="text-[10px] text-white/35 font-semibold uppercase tracking-wide">{label}</p>
            </div>
          ))}
        </div>

        {totalDist > 0 && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-white/[0.02] border border-white/5">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <p className="text-xs text-white/60">Estimated route: <span className="text-cyan-400 font-semibold">{totalDist.toFixed(0)} km</span> total driving distance</p>
          </div>
        )}

        <button
          onClick={generateReport}
          disabled={generating}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all"
          style={{
            background: done
              ? "linear-gradient(135deg, rgba(16,185,129,0.25), rgba(16,185,129,0.15))"
              : "linear-gradient(135deg, #00D68F, #7AE7FF)",
            color: done ? "#10b981" : "#000",
            border: done ? "1px solid rgba(16,185,129,0.4)" : "none",
            opacity: generating ? 0.7 : 1,
          }}
        >
          {generating
            ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</>
            : done
            ? <><CheckCircle className="w-4 h-4" /> Downloaded!</>
            : <><Download className="w-4 h-4" /> Download Field Report (.txt)</>
          }
        </button>

        <p className="text-[10px] text-white/25 text-center">
          Includes itinerary, all pinned sites, gear lists, trip notes, specimen discoveries & field observations
        </p>
      </div>
    </div>
  );
}