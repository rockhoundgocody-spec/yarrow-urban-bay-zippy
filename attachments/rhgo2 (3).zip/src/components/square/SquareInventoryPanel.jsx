import React from 'react';

export default function SquareInventoryPanel({ items, inventory }) {
  const nameMap = {};
  (items || []).forEach(i => (i.variations || []).forEach(v => {
    nameMap[v.id] = `${i.name}${v.name ? ` · ${v.name}` : ''}`;
  }));
  if (!inventory?.length) {
    return <div className="text-white/40 text-sm py-6 text-center">No inventory counts available.</div>;
  }
  return (
    <div className="space-y-1.5 max-h-80 overflow-y-auto">
      {inventory.map((c, i) => (
        <div key={i} className="flex items-center justify-between gap-2 py-1.5 border-b border-white/5 last:border-0">
          <span className="text-sm text-white/70 truncate">
            {nameMap[c.catalog_object_id] || (c.catalog_object_id || '').slice(0, 14) || '—'}
          </span>
          <span className="text-sm font-semibold text-emerald-300 whitespace-nowrap">
            {Number(c.quantity).toLocaleString()} <span className="text-white/40 text-xs">{c.state}</span>
          </span>
        </div>
      ))}
    </div>
  );
}