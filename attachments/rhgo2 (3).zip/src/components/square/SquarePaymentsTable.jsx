import React from 'react';

const statusColor = {
  CAPTURED: 'text-emerald-400', APPROVED: 'text-emerald-400', PENDING: 'text-amber-400',
  FAILED: 'text-red-400', CANCELED: 'text-white/40',
};

export default function SquarePaymentsTable({ payments, fmt }) {
  if (!payments?.length) {
    return <div className="text-white/40 text-sm py-6 text-center">No recent payments in this range.</div>;
  }
  return (
    <div className="overflow-x-auto -mx-1">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-white/40 text-left text-[11px] uppercase tracking-wider">
            <th className="py-2 pr-3 font-medium">Date</th>
            <th className="py-2 pr-3 font-medium">Amount</th>
            <th className="py-2 pr-3 font-medium">Status</th>
            <th className="py-2 pr-3 font-medium">Source</th>
          </tr>
        </thead>
        <tbody>
          {payments.map(p => (
            <tr key={p.id} className="border-t border-white/5">
              <td className="py-2 pr-3 text-white/70 whitespace-nowrap">{p.created_at?.slice(0, 16).replace('T', ' ') || '—'}</td>
              <td className="py-2 pr-3 font-semibold text-emerald-300 whitespace-nowrap">{fmt(p.amount_cents, p.currency)}</td>
              <td className={`py-2 pr-3 whitespace-nowrap ${statusColor[p.status] || 'text-white/60'}`}>{p.status}</td>
              <td className="py-2 pr-3 text-white/50">{p.source_type || '—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}