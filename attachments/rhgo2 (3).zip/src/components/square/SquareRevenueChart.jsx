import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function SquareRevenueChart({ data }) {
  const chartData = (data || []).map(d => ({ date: d.date, gross: (d.gross_cents || 0) / 100, net: (d.net_cents || 0) / 100 }));
  if (!chartData.length) {
    return <div className="text-white/40 text-sm py-10 text-center">No captured payments in this range.</div>;
  }
  return (
    <ResponsiveContainer width="100%" height={260}>
      <AreaChart data={chartData} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id="sqGross" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00D68F" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#00D68F" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
        <XAxis dataKey="date" stroke="rgba(255,255,255,0.4)" fontSize={11} tickFormatter={d => d.slice(5)} />
        <YAxis stroke="rgba(255,255,255,0.4)" fontSize={11} tickFormatter={v => `$${(v / 1000).toFixed(1)}k`} width={48} />
        <Tooltip
          contentStyle={{ background: '#0E141B', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#fff' }}
          labelStyle={{ color: '#fff' }}
          formatter={(v, name) => [`$${Number(v).toLocaleString()}`, name === 'gross' ? 'Gross' : 'Net']}
        />
        <Area type="monotone" dataKey="gross" stroke="#00D68F" strokeWidth={2} fill="url(#sqGross)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}