import React from 'react';

const invColor = {
  PAID: 'text-emerald-400', UNPAID: 'text-amber-400', PARTIALLY_PAID: 'text-amber-400',
  PAYMENT_PENDING: 'text-amber-400', DRAFT: 'text-white/40', CANCELED: 'text-red-400',
};

export default function SquareInvoicesPanel({ invoices, fmt }) {
  if (!invoices?.length) {
    return <div className="text-white/40 text-sm py-6 text-center">No invoices found for the primary location.</div>;
  }
  return (
    <div className="space-y-1.5 max-h-80 overflow-y-auto">
      {invoices.map(i => (
        <div key={i.id} className="flex items-center justify-between gap-2 py-1.5 border-b border-white/5 last:border-0">
          <div className="min-w-0">
            <div className="text-sm text-white/70 truncate">{i.invoice_number || i.id.slice(0, 10)}</div>
            <div className="text-[11px] text-white/40">Due {i.due_date || '—'}</div>
          </div>
          <div className="text-right">
            <div className="text-sm font-semibold text-emerald-300">{fmt(i.total_cents, i.currency)}</div>
            <div className={`text-[11px] ${invColor[i.status] || 'text-white/50'}`}>{i.status}</div>
          </div>
        </div>
      ))}
    </div>
  );
}