import React from 'react';

const stateColor = {
  COMPLETED: 'text-emerald-400', OPEN: 'text-amber-400', CANCELED: 'text-red-400', DRAFT: 'text-white/40',
};

export default function SquareOrdersTable({ orders, fmt }) {
  if (!orders?.length) {
    return <div className="text-white/40 text-sm py-6 text-center">No recent orders in this range.</div>;
  }
  return (
    <div className="overflow-x-auto -mx-1">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-white/40 text-left text-[11px] uppercase tracking-wider">
            <th className="py-2 pr-3 font-medium">Date</th>
            <th className="py-2 pr-3 font-medium">Total</th>
            <th className="py-2 pr-3 font-medium">State</th>
            <th className="py-2 pr-3 font-medium">Items</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(o => (
            <tr key={o.id} className="border-t border-white/5">
              <td className="py-2 pr-3 text-white/70 whitespace-nowrap">{o.created_at?.slice(0, 16).replace('T', ' ') || '—'}</td>
              <td className="py-2 pr-3 font-semibold text-emerald-300 whitespace-nowrap">{fmt(o.total_cents, o.currency)}</td>
              <td className={`py-2 pr-3 whitespace-nowrap ${stateColor[o.state] || 'text-white/60'}`}>{o.state}</td>
              <td className="py-2 pr-3 text-white/50">{o.line_item_count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}