import React from 'react';

export default function SquareKPI({ label, value, sub, accent }) {
  return (
    <div className="rounded-2xl p-4 border border-white/10 bg-white/[0.02]">
      <div className="text-[11px] uppercase tracking-wider text-white/40">{label}</div>
      <div className="text-2xl font-bold mt-1" style={{ color: accent || '#fff' }}>{value}</div>
      {sub ? <div className="text-xs text-white/40 mt-1">{sub}</div> : null}
    </div>
  );
}