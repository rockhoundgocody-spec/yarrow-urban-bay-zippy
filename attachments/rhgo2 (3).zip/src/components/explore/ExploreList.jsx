/**
 * ExploreList — accessible list alternative to the adventure map.
 *
 * Blueprint RG-019/RG-050: "Every published map result is available in an
 * accessible list with the same filters." Screen-reader users can browse
 * and select every result without map gestures.
 */
import React from "react";
import { MapPin, Gem, ChevronRight } from "lucide-react";
import { deriveAccessStatus } from "@/components/map/locationSignals";

function distanceMiles(lat1, lng1, lat2, lng2) {
  if (lat1 == null || lat2 == null) return null;
  const R = 3959, toRad = d => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const ACCESS_TONE = {
  ok:      { bg: "rgba(0,214,143,0.10)",  border: "rgba(0,214,143,0.30)",  text: "#00D68F" },
  info:    { bg: "rgba(122,231,255,0.08)", border: "rgba(122,231,255,0.25)", text: "#7AE7FF" },
  warning: { bg: "rgba(245,182,66,0.10)",  border: "rgba(245,182,66,0.30)",  text: "#F5B642" },
  danger:  { bg: "rgba(255,107,107,0.10)", border: "rgba(255,107,107,0.30)", text: "#ff6b6b" },
  unknown: { bg: "rgba(255,255,255,0.04)", border: "rgba(255,255,255,0.10)", text: "rgba(255,255,255,0.4)" },
};

export default function ExploreList({ sites, userLat, userLng, onSelect }) {
  if (!sites || sites.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
        <MapPin className="w-8 h-8 mb-3" style={{ color: "rgba(255,255,255,0.2)" }} />
        <p className="text-sm font-semibold text-white/40">No sites found nearby</p>
        <p className="text-xs mt-1 text-white/30">Try expanding your search radius or adjusting filters.</p>
      </div>
    );
  }

  // Sort by distance when user location is available
  const sorted = [...sites].map(s => {
    const dist = distanceMiles(userLat, userLng, s.latitude ?? s.lat, s.longitude ?? s.lng);
    return { site: s, dist };
  }).sort((a, b) => (a.dist ?? 999) - (b.dist ?? 999));

  return (
    <div className="overflow-y-auto flex-1" style={{ WebkitOverflowScrolling: "touch" }}>
      <div className="space-y-2 px-3 pb-4">
        <p className="text-xs font-bold uppercase tracking-widest pt-2 pb-1" style={{ color: "rgba(255,255,255,0.3)" }}>
          {sorted.length} site{sorted.length !== 1 ? "s" : ""} nearby
        </p>
        {sorted.map(({ site, dist }) => {
          const access = deriveAccessStatus(site);
          const tone = ACCESS_TONE[access.accessTone] || ACCESS_TONE.unknown;
          const minerals = site.minerals || site.minerals_available || site.minerals_found || [];
          return (
            <button
              key={site.id || site.name}
              onClick={() => onSelect?.(site)}
              className="w-full text-left rounded-2xl p-3.5 flex items-start gap-3 transition-all active:scale-[0.98]"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
            >
              {/* Status dot */}
              <div className="w-2.5 h-2.5 rounded-full shrink-0 mt-1.5" style={{ background: tone.text }} />

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-bold text-white truncate">{site.name || site.location_name || "Unnamed site"}</h3>
                  {dist != null && (
                    <span className="text-xs font-semibold shrink-0" style={{ color: "rgba(255,255,255,0.35)" }}>
                      {dist < 0.2 ? `${Math.round(dist * 5280)} ft` : dist < 10 ? `${dist.toFixed(1)} mi` : `${Math.round(dist)} mi`}
                    </span>
                  )}
                </div>

                {/* Access status chip */}
                <div className="flex items-center gap-1.5 mt-1.5">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{ background: tone.bg, border: `1px solid ${tone.border}`, color: tone.text }}>
                    {access.accessLabel}
                  </span>
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)" }}>
                    {access.collectionLabel}
                  </span>
                </div>

                {/* Minerals */}
                {minerals.length > 0 && (
                  <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                    {minerals.slice(0, 3).map(m => (
                      <span key={m} className="text-[10px] font-semibold flex items-center gap-0.5" style={{ color: "rgba(122,231,255,0.6)" }}>
                        <Gem className="w-2.5 h-2.5" /> {m}
                      </span>
                    ))}
                    {minerals.length > 3 && (
                      <span className="text-[10px] text-white/30">+{minerals.length - 3}</span>
                    )}
                  </div>
                )}
              </div>

              <ChevronRight className="w-4 h-4 shrink-0 mt-1.5" style={{ color: "rgba(255,255,255,0.2)" }} />
            </button>
          );
        })}
      </div>
    </div>
  );
}