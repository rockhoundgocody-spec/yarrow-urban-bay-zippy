/**
 * IntelligenceHeroBar — Phase 4 Explore hero.
 * Field intelligence surface: signal strength, site count, risk level, saved state.
 * Replaces ExploreHeroBar on the Explore page.
 *
 * Props:
 *  nearbyCount    number
 *  hotspotName    string
 *  rarityPeak     string — rarity tier of best nearby site
 *  riskLevel      "low" | "moderate" | "high" | "unknown"
 *  accessStatus   "open" | "permit" | "restricted" | "unknown"
 *  signalStrength number — 0-1 (how rich the nearby data is)
 */

import React from "react";
import { motion } from "framer-motion";
import { Radar, ShieldCheck, ShieldAlert, Shield, AlertTriangle, MapPin } from "lucide-react";
import { getRarity } from "@/theme/raritySystem";

const RISK_CONFIG = {
  low:        { color: "#00FFC6", label: "Low Risk",        icon: ShieldCheck },
  moderate:   { color: "#FFD700", label: "Moderate Risk",   icon: ShieldAlert },
  high:       { color: "#FF7A59", label: "High Risk",       icon: AlertTriangle },
  unknown:    { color: "rgba(255,255,255,0.3)", label: "Risk Unknown", icon: Shield },
};

const ACCESS_CONFIG = {
  open:       { color: "#00FFC6", label: "Open Access" },
  permit:     { color: "#FFD700", label: "Permit Required" },
  restricted: { color: "#FF7A59", label: "Restricted" },
  unknown:    { color: "rgba(255,255,255,0.3)", label: "Access Unverified" },
};

function SignalBar({ strength = 0.5 }) {
  const filled = Math.round(strength * 5);
  return (
    <div className="flex gap-0.5 items-end">
      {Array.from({ length: 5 }, (_, i) => (
        <div
          key={i}
          className="w-1 rounded-sm"
          style={{
            height: 6 + i * 2,
            background: i < filled ? "#7DF9FF" : "rgba(255,255,255,0.12)",
            boxShadow: i < filled ? "0 0 4px rgba(125,249,255,0.7)" : "none",
            transition: "background 0.3s",
          }}
        />
      ))}
    </div>
  );
}

export default function IntelligenceHeroBar({
  nearbyCount = 0,
  hotspotName,
  rarityPeak = "common",
  riskLevel = "unknown",
  accessStatus = "unknown",
  signalStrength = 0.5,
}) {
  const r    = getRarity(rarityPeak);
  const risk = RISK_CONFIG[riskLevel] || RISK_CONFIG.unknown;
  const acc  = ACCESS_CONFIG[accessStatus] || ACCESS_CONFIG.unknown;
  const RiskIcon = risk.icon;

  return (
    <div
      className="relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, rgba(4,8,14,0.97) 0%, rgba(6,10,20,0.94) 100%)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        boxShadow: "0 4px 32px rgba(0,0,0,0.65)",
      }}
    >
      {/* Radar pulse — top-right anchor */}
      <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2">
        {[1, 1.7, 2.5].map((scale, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{ width: 44, height: 44, border: `1px solid ${r.color}`, left: -22, top: -22, opacity: 0 }}
            animate={{ scale: [1, scale], opacity: [0.55, 0] }}
            transition={{ duration: 2.6, delay: i * 0.75, repeat: Infinity, ease: "easeOut" }}
          />
        ))}
        <div
          className="flex h-11 w-11 items-center justify-center rounded-full"
          style={{ background: `${r.color}14`, border: `1px solid ${r.color}30` }}
        >
          <Radar className="h-5 w-5" style={{ color: r.color }} />
        </div>
      </div>

      <div className="px-4 pt-4 pb-3 pr-20">
        {/* Eyebrow + signal */}
        <div className="flex items-center gap-2.5 mb-2">
          <motion.div
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 1.8, repeat: Infinity }}
            className="h-1.5 w-1.5 rounded-full"
            style={{ background: r.color, boxShadow: `0 0 6px ${r.color}` }}
          />
          <span className="text-[10px] font-bold uppercase tracking-[0.24em]" style={{ color: r.color }}>
            Field Intelligence
          </span>
          <SignalBar strength={signalStrength} />
          {nearbyCount > 0 && (
            <span className="text-[10px] text-white/30">{nearbyCount} sites</span>
          )}
        </div>

        {/* Headline */}
        <h1 className="text-[1.6rem] font-black tracking-tight text-white leading-tight mb-2" style={{ letterSpacing: "-0.02em" }}>
          Wonders Near You
        </h1>

        {/* Hotspot */}
        {hotspotName && (
          <div className="flex items-center gap-1.5 text-xs text-white/35 mb-3">
            <MapPin className="h-3 w-3" />
            <span>Best signal: <span className="font-semibold text-white/60">{hotspotName}</span></span>
          </div>
        )}

        {/* Trust/risk strip */}
        <div className="flex flex-wrap gap-2">
          {/* Risk */}
          <div
            className="flex items-center gap-1.5 rounded-full px-2.5 py-1"
            style={{ background: `${risk.color}10`, border: `1px solid ${risk.color}28` }}
          >
            <RiskIcon className="h-3 w-3 shrink-0" style={{ color: risk.color }} />
            <span className="text-[10px] font-bold" style={{ color: risk.color }}>{risk.label}</span>
          </div>

          {/* Access */}
          <div
            className="flex items-center gap-1.5 rounded-full px-2.5 py-1"
            style={{ background: `${acc.color}10`, border: `1px solid ${acc.color}28` }}
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: acc.color }} />
            <span className="text-[10px] font-bold" style={{ color: acc.color }}>{acc.label}</span>
          </div>
        </div>
      </div>
    </div>
  );
}