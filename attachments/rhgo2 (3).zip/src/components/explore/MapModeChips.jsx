import React from "react";
import LiquidButton from "@/components/ui/LiquidButton";

const MODES = [
  { key: "discover", label: "Discover", variant: "primary" },
  { key: "family", label: "Family", variant: "gold" },
  { key: "advanced", label: "Advanced", variant: "premium" },
  { key: "claims", label: "Access", variant: "ghost" },
];

export default function MapModeChips({ activeMode, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {MODES.map((mode) => (
        <LiquidButton
          key={mode.key}
          variant={activeMode === mode.key ? mode.variant : "ghost"}
          size="sm"
          onClick={() => onChange?.(mode.key)}
        >
          {mode.label}
        </LiquidButton>
      ))}
    </div>
  );
}