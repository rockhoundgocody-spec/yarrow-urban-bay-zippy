/**
 * ExploreEmptyState — Friendly fallback when GPS or locations unavailable
 * Offers three paths: Enable Location, Use Demo Data, Manual Search
 */
import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Zap, Search } from 'lucide-react';

export default function ExploreEmptyState({ onRequestLocation, onUseSeedData, onSearch }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="min-h-[50vh] flex flex-col items-center justify-center px-6 text-center gap-8">

      {/* Hero icon */}
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: "rgba(122,231,255,0.12)" }}>
        <MapPin className="w-8 h-8" style={{ color: '#7AE7FF' }} />
      </div>

      {/* Message */}
      <div className="space-y-3 max-w-sm">
        <h2 className="text-xl font-bold text-white">Explore Nearby Rockhounding</h2>
        <p className="text-sm text-white/60">
          Enable location access to discover mineral deposits, public sites, and collecting opportunities around you.
        </p>
      </div>

      {/* Actions */}
      <div className="w-full max-w-sm space-y-3">
        {/* Primary: Enable location */}
        <button
          onClick={onRequestLocation}
          className="w-full py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
          style={{
            background: 'rgba(122,231,255,0.15)',
            border: '1px solid rgba(122,231,255,0.35)',
            color: '#7AE7FF'
          }}>
          <MapPin className="w-4.5 h-4.5" />
          Enable Location
        </button>

        {/* Secondary: Demo data for Chicago area */}
        <button
          onClick={onUseSeedData}
          className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
          style={{
            background: 'rgba(0,214,143,0.1)',
            border: '1px solid rgba(0,214,143,0.25)',
            color: '#00D68F'
          }}>
          <Zap className="w-4 h-4" />
          View Chicago Demo Sites
        </button>

        {/* Tertiary: Manual search */}
        <button
          onClick={onSearch}
          className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
          style={{
            background: 'rgba(255,255,255,0.03)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'rgba(255,255,255,0.5)'
          }}>
          <Search className="w-4 h-4" />
          Search by Location
        </button>
      </div>

      {/* Info note */}
      <p className="text-xs text-white/30 max-w-sm leading-relaxed">
        💡 Tip: RockHound-GO works best with location enabled. All your discoveries are private and never shared.
      </p>
    </motion.div>
  );
}