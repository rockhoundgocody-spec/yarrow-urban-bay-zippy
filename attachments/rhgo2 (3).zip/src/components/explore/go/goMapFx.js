/**
 * goMapFx — MysteryMap marker factories + FX stylesheet.
 * Mystery question-mark markers, blue-dot player, teal-green palette.
 * Pure DOM helpers, no React.
 */

export const MYSTERY_COLORS = {
  common:    "#5ae4b7",
  uncommon:  "#48D9B2",
  rare:      "#4FD1C5",
  epic:      "#8D7CFF",
  legendary: "#F5B642",
  default:   "#5ae4b7",
};

export const MYSTERY_MAP_CSS = `
  .rh-mystery-map { position: relative; overflow: hidden; }
  .rh-mystery-map .maplibregl-map { filter: sepia(0.35) hue-rotate(130deg) saturate(0.55) brightness(0.55); }

  /* ── Fog of war overlay ── */
  .rh-fog-overlay {
    position: absolute; inset: 0; pointer-events: none; z-index: 5;
    background: radial-gradient(ellipse 45% 45% at 50% 50%,
      transparent 0%, transparent 35%, rgba(16,30,30,0.35) 65%, rgba(16,30,30,0.6) 100%);
    transition: opacity 0.4s ease;
  }

  /* ── Mystery markers ── */
  .rh-mystery-marker {
    cursor: pointer; position: relative; width: 38px; height: 38px;
    animation: rhMysterySpawn 0.45s cubic-bezier(0.34,1.56,0.64,1) backwards;
  }
  @keyframes rhMysterySpawn {
    0% { transform: scale(0) translateY(8px); opacity: 0; }
    100% { transform: scale(1) translateY(0); opacity: 1; }
  }
  .rh-mystery-bubble {
    position: absolute; inset: 0; border-radius: 50%;
    background: linear-gradient(145deg, #152427 0%, #101e1e 100%);
    border: 2.5px solid var(--mystery);
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 0 12px var(--mystery), 0 2px 8px rgba(0,0,0,0.6);
    animation: rhMysteryBob 2.4s ease-in-out infinite;
  }
  .rh-mystery-bubble::after {
    content: '?'; font-size: 20px; font-weight: 800;
    color: var(--mystery); font-family: 'Sora', sans-serif;
    text-shadow: 0 0 8px var(--mystery);
  }
  .rh-mystery-ring {
    position: absolute; inset: -4px; border-radius: 50%;
    border: 2px solid var(--mystery); opacity: 0;
    animation: rhMysteryRing 2.6s ease-out infinite;
  }
  @keyframes rhMysteryBob {
    0%,100% { transform: translateY(0); }
    50% { transform: translateY(-6px); }
  }
  @keyframes rhMysteryRing {
    0% { transform: scale(0.85); opacity: 0.7; }
    100% { transform: scale(1.8); opacity: 0; }
  }

  /* ── Cluster bubbles ── */
  .rh-mystery-cluster {
    cursor: pointer; border-radius: 50%;
    background: rgba(74,140,126,0.4);
    border: 2.5px solid #5ae4b7;
    display: flex; align-items: center; justify-content: center;
    font-family: 'Sora', sans-serif; font-weight: 800; font-size: 14px;
    color: #5ae4b7; text-shadow: 0 0 6px rgba(90,228,183,0.5);
    box-shadow: 0 0 16px rgba(90,228,183,0.3);
  }

  /* ── Player: blue dot with trail ── */
  .rh-mystery-player { position: relative; width: 24px; height: 24px; pointer-events: none; }
  .rh-mystery-player-dot {
    position: absolute; inset: 4px; border-radius: 50%; z-index: 3;
    background: #4299E1;
    border: 3px solid #ffffff;
    box-shadow: 0 0 14px rgba(66,153,225,0.7), 0 2px 6px rgba(0,0,0,0.5);
  }
  .rh-mystery-player-pulse {
    position: absolute; inset: 0; border-radius: 50%; z-index: 1;
    border: 2px solid rgba(66,153,225,0.6);
    animation: rhMysteryPulse 2s ease-out infinite;
  }
  .rh-mystery-player-pulse.s2 { animation-delay: 0.7s; border-color: rgba(66,153,225,0.4); }
  @keyframes rhMysteryPulse {
    0% { transform: scale(0.6); opacity: 0.8; }
    100% { transform: scale(2.5); opacity: 0; }
  }

  .maplibregl-ctrl-attrib { font-size: 9px !important; background: rgba(16,30,30,0.85) !important; }
  .maplibregl-ctrl-attrib a { color: rgba(90,228,183,0.4) !important; }
`;

export function makeMysteryMarker(colorKey, onClick, index = 0) {
  const color = MYSTERY_COLORS[colorKey] || MYSTERY_COLORS.default;
  const el = document.createElement("div");
  el.className = "rh-mystery-marker";
  el.style.animationDelay = `${Math.min(index * 60, 1000)}ms`;

  const bubble = document.createElement("div");
  bubble.className = "rh-mystery-bubble";
  bubble.style.setProperty("--mystery", color);

  const ring = document.createElement("div");
  ring.className = "rh-mystery-ring";
  ring.style.setProperty("--mystery", color);
  ring.style.animationDelay = `${(index % 5) * 0.5}s`;

  el.appendChild(ring);
  el.appendChild(bubble);

  el.addEventListener("click", (e) => { e.stopPropagation(); onClick(); });
  return el;
}

export function makeMysteryClusterEl(count) {
  const el = document.createElement("div");
  el.className = "rh-mystery-cluster";
  const size = Math.max(28, Math.min(44, 22 + count));
  el.style.width = `${size}px`;
  el.style.height = `${size}px`;
  el.textContent = String(count);
  return el;
}

export function makeMysteryPlayerMarker() {
  const el = document.createElement("div");
  el.className = "rh-mystery-player";

  const pulse1 = document.createElement("div");
  pulse1.className = "rh-mystery-player-pulse";
  const pulse2 = document.createElement("div");
  pulse2.className = "rh-mystery-player-pulse s2";

  const dot = document.createElement("div");
  dot.className = "rh-mystery-player-dot";

  el.append(pulse1, pulse2, dot);
  return el;
}