import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, CircleMarker, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import { AnimatePresence } from "framer-motion";
import GoSiteSheet from "./GoSiteSheet";
import MysteryMapStatsBar from "./MysteryMapStatsBar";
import MysteryMapBottomPanel from "./MysteryMapBottomPanel";
import { classifySite } from "./specimenTypes";
import WebGLFallbackBanner from "@/components/map/WebGLFallbackBanner";

const TILE_URL = "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png";
const TILE_SUB = "abcd";
const TILE_ATTR = '&copy; OpenStreetMap, &copy; CARTO';

const playerIcon = L.divIcon({
  className: "rh-go-fallback-player",
  html: '<div style="width:20px;height:20px;border-radius:50%;background:#5ae4b7;border:3px solid #fff;box-shadow:0 0 12px rgba(90,228,183,0.6);"></div>',
  iconSize: [20, 20],
  iconAnchor: [10, 10],
});

/** Recenter helper — flies to user location on mount. */
function RecenterOnUser({ lat, lng }) {
  const map = useMap();
  useEffect(() => {
    if (lat && lng) map.setView([lat, lng], 14);
  }, [lat, lng, map]);
  return null;
}

/**
 * GoFallbackMap — Leaflet version of GoMap3D for WebGL-unsupported devices.
 * Renders CircleMarkers for sites, player Marker, preserves the
 * onsite-click → setSelected → GoSiteSheet flow. All UI chrome
 * (StatsBar, BottomPanel) is identical.
 */
export default function GoFallbackMap({ sites = [], zones = [], userLat, userLng, height = 460, coordLabel }) {
  const [selected, setSelected] = useState(null);

  const centerLat = userLat || 41.8;
  const centerLng = userLng || -87.83;

  const siteMarkers = sites
    .filter((s) => (s.latitude ?? s.lat) != null && (s.longitude ?? s.lng) != null)
    .slice(0, 200)
    .map((site, i) => {
      const lat = site.latitude ?? site.lat;
      const lng = site.longitude ?? site.lng;
      const type = classifySite(site);
      // Color-code by specimen type — fallback from heatmap
      const fillColor = type.color || "#5ae4b7";
      return (
        <CircleMarker
          key={site.id || i}
          center={[lat, lng]}
          radius={8}
          pathOptions={{
            color: "rgba(90,228,183,0.6)",
            weight: 2,
            fillColor,
            fillOpacity: 0.75,
          }}
          eventHandlers={{ click: () => setSelected(site) }}
        >
          <Popup>
            <div style={{ fontWeight: 700, fontSize: 13 }}>{site.name || "Site"}</div>
            {site.minerals_found?.length > 0 && (
              <div style={{ fontSize: 11, marginTop: 4, color: "#666" }}>
                {site.minerals_found.slice(0, 4).join(", ")}
              </div>
            )}
          </Popup>
        </CircleMarker>
      );
    });

  const zoneMarkers = zones
    .filter((z) => (z.latitude ?? z.lat) != null && (z.longitude ?? z.lng) != null)
    .map((z, i) => {
      const lat = z.latitude ?? z.lat;
      const lng = z.longitude ?? z.lng;
      const conf = z.confidence || 50;
      const opacity = Math.max(0.2, Math.min(0.6, conf / 100));
      return (
        <CircleMarker
          key={`zone-${i}`}
          center={[lat, lng]}
          radius={12}
          pathOptions={{
            color: "rgba(90,228,183,0.3)",
            weight: 1,
            fillColor: "#5ae4b7",
            fillOpacity: opacity,
          }}
        />
      );
    });

  return (
    <div
      className="rh-mystery-map relative overflow-hidden"
      style={{
        height,
        borderRadius: 18,
        border: "1px solid rgba(90,228,183,0.20)",
        boxShadow: "0 8px 32px rgba(0,0,0,0.6), 0 0 24px rgba(90,228,183,0.08), inset 0 1px 0 rgba(255,255,255,0.05)",
        background: "#101e1e",
      }}
    >
      <WebGLFallbackBanner />

      <div style={{ position: "absolute", inset: 0, top: 32 }}>
        <MapContainer
          center={[centerLat, centerLng]}
          zoom={14}
          style={{ width: "100%", height: "100%", background: "#101e1e" }}
          zoomControl={true}
          attributionControl={true}
        >
          <TileLayer url={TILE_URL} subdomains={TILE_SUB} attribution={TILE_ATTR} maxZoom={21} />
          <RecenterOnUser lat={userLat} lng={userLng} />
          {siteMarkers}
          {zoneMarkers}
          {userLat && userLng && <Marker position={[userLat, userLng]} icon={playerIcon} />}
        </MapContainer>
      </div>

      {/* Top stats bar — identical to GoMap3D */}
      <MysteryMapStatsBar onExplorationClick={() => {}} siteCount={sites.length} />

      {/* Bottom location panel — identical to GoMap3D */}
      <MysteryMapBottomPanel locationName={coordLabel} mysteryCount={sites.length} />

      {/* Site detail sheet — same flow as GoMap3D */}
      <AnimatePresence>
        {selected && (
          <GoSiteSheet site={selected} userLat={userLat} userLng={userLng} onClose={() => setSelected(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}