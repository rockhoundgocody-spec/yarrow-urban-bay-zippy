/**
 * specimenTypes — classifies a site into a specimen type for custom
 * geo-caching style map icons. Pure logic, no DOM/React.
 */

export const SPECIMEN_TYPES = {
  crystal: { icon: "💎", color: "#8D7CFF", label: "Crystal" },
  agate:   { icon: "🔮", color: "#7AE7FF", label: "Agate" },
  fossil:  { icon: "🦴", color: "#F5B642", label: "Fossil" },
  gold:    { icon: "🪙", color: "#FFD700", label: "Precious Metal" },
  geode:   { icon: "🥚", color: "#D3C4F1", label: "Geode" },
  copper:  { icon: "⛏️", color: "#FF8C5A", label: "Ore / Metal" },
  gemstone:{ icon: "💠", color: "#00D68F", label: "Gemstone" },
  mineral: { icon: "🪨", color: "#C7D0D9", label: "Mineral" },
};

const KEYWORD_MAP = [
  { key: "fossil",  words: ["fossil", "trilobite", "crinoid", "coral", "brachiopod", "shark", "bone", "petrified"] },
  { key: "agate",   words: ["agate", "jasper", "chert", "chalcedony", "flint", "carnelian"] },
  { key: "geode",   words: ["geode", "septarian", "thunderegg", "vug"] },
  { key: "gold",    words: ["gold", "silver", "platinum", "placer"] },
  { key: "copper",  words: ["copper", "iron", "ore", "galena", "pyrite", "magnetite", "hematite", "sphalerite"] },
  { key: "crystal", words: ["quartz", "crystal", "amethyst", "calcite", "fluorite", "celestite", "selenite", "gypsum"] },
  { key: "gemstone",words: ["beryl", "garnet", "topaz", "tourmaline", "opal", "emerald", "sapphire", "peridot", "diamond"] },
];

/** Classify a site by its minerals list + name → SPECIMEN_TYPES entry. */
export function classifySite(site) {
  const haystack = [
    site?.name,
    site?.title,
    ...(Array.isArray(site?.minerals) ? site.minerals : []),
    ...(Array.isArray(site?.minerals_available) ? site.minerals_available : []),
    site?.primary_mineral,
    site?.description,
  ].filter(Boolean).join(" ").toLowerCase();

  for (const { key, words } of KEYWORD_MAP) {
    if (words.some((w) => haystack.includes(w))) return { key, ...SPECIMEN_TYPES[key] };
  }
  return { key: "mineral", ...SPECIMEN_TYPES.mineral };
}

/** Popularity weight 30–100 for heatmap intensity. */
export function siteHeatWeight(site) {
  const finds = (site?.find_count || site?.finds || 0) * 10;
  const rating = (site?.rating || site?.trust_score || 0) * 12;
  const minerals = ((site?.minerals?.length || site?.minerals_available?.length || 0)) * 8;
  return Math.max(30, Math.min(100, 40 + finds + rating + minerals));
}