/**
 * GoMap3D — MysteryMap adventure map.
 * Teal-green palette, mystery question-mark markers, blue-dot player,
 * fog of war, user stats bar, floating controls, map style/display settings
 * modals, exploration progress modal. Tap-to-open site sheet preserved.
 */
import React, { useRef, useEffect, useState, useCallback } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import GoSiteSheet from "./GoSiteSheet";
import { classifySite, siteHeatWeight } from "./specimenTypes";
import MysteryMapStatsBar from "./MysteryMapStatsBar";
import MysteryMapControls from "./MysteryMapControls";
import MysteryMapBottomPanel from "./MysteryMapBottomPanel";
import MapStyleModal from "./MapStyleModal";
import MapDisplaySettingsModal from "./MapDisplaySettingsModal";
import ExplorationProgressModal from "./ExplorationProgressModal";
import {
  MYSTERY_MAP_CSS,
  makeMysteryMarker, makeMysteryPlayerMarker,
} from "./goMapFx";
import { useWebGLSupport } from "@/hooks/useWebGLSupport";
import GoFallbackMap from "./GoFallbackMap";
import MapErrorBoundary from "@/components/map/MapErrorBoundary";

const GAME_STYLE = "https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json";
const CLUSTER_MAX_ZOOM = 12.8;

// Teal-mint heat gradient
const HEAT_PAINT = {
  "heatmap-weight": ["interpolate", ["linear"], ["get", "w"], 0, 0.3, 100, 1],
  "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 9, 0.8, 15, 1.6],
  "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 9, 26, 13, 55, 16, 90],
  "heatmap-opacity": 0.55,
  "heatmap-color": [
    "interpolate", ["linear"], ["heatmap-density"],
    0, "rgba(0,0,0,0)",
    0.15, "rgba(74,140,126,0.18)",
    0.4, "rgba(90,228,183,0.42)",
    0.65, "rgba(72,217,178,0.6)",
    0.85, "rgba(79,209,197,0.7)",
    1, "rgba(245,182,66,0.85)"
  ]
};

function toHeatFeatures(sites, zones) {
  const feats = [];
  for (const s of sites) {
    const lat = s.latitude ?? s.lat, lng = s.longitude ?? s.lng;
    if (lat == null || lng == null) continue;
    feats.push({ type: "Feature", geometry: { type: "Point", coordinates: [lng, lat] }, properties: { w: siteHeatWeight(s) } });
  }
  for (const z of zones) {
    const lat = z.latitude ?? z.lat, lng = z.longitude ?? z.lng;
    if (lat == null || lng == null) continue;
    feats.push({ type: "Feature", geometry: { type: "Point", coordinates: [lng, lat] }, properties: { w: z.confidence || 50 } });
  }
  return { type: "FeatureCollection", features: feats };
}

export default function GoMap3D(props) {
  const webglStatus = useWebGLSupport();
  if (webglStatus === "unsupported") {
    return (
      <MapErrorBoundary height={props.height}>
        <GoFallbackMap {...props} />
      </MapErrorBoundary>
    );
  }
  return <GoMap3DInner {...props} />;
}

function GoMap3DInner({ sites = [], zones = [], userLat, userLng, height = 460, coordLabel }) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const markersRef = useRef([]);
  const playerRef = useRef(null);
  const styleReadyRef = useRef(false);
  const driftRef = useRef({ raf: null, idleTimer: null, active: true });
  const [selected, setSelected] = useState(null);
  const [is3D, setIs3D] = useState(true);
  const [showStyleModal, setShowStyleModal] = useState(false);
  const [showDisplayModal, setShowDisplayModal] = useState(false);
  const [showExploration, setShowExploration] = useState(false);
  const [fogColor, setFogColor] = useState("#4a8c7e");
  const [layers, setLayers] = useState({ mystery: true, explored: true, position: true, outline: true });
  const [exploredCells, setExploredCells] = useState(0);

  const centerLat = userLat || 41.8;
  const centerLng = userLng || -87.83;

  // Init map once
  useEffect(() => {
    if (mapRef.current || !containerRef.current) return;
    const map = new maplibregl.Map({
      container: containerRef.current,
      style: GAME_STYLE,
      center: [centerLng, centerLat],
      zoom: 14.2,
      pitch: 62,
      bearing: -18,
      attributionControl: { compact: true },
      dragRotate: true,
      touchPitch: true
    });
    mapRef.current = map;
    map.on("load", () => { styleReadyRef.current = true; syncHeat(); syncClusters(); });

    map.on("zoom", () => {
      const show = map.getZoom() >= CLUSTER_MAX_ZOOM;
      markersRef.current.forEach((m) => { m.getElement().style.display = show ? "" : "none"; });
    });

    // Idle camera drift
    const drift = driftRef.current;
    let last = performance.now();
    const tick = (now) => {
      const dt = now - last; last = now;
      if (drift.active && mapRef.current && !document.hidden) {
        mapRef.current.setBearing(mapRef.current.getBearing() + dt * 0.0016);
      }
      drift.raf = requestAnimationFrame(tick);
    };
    drift.raf = requestAnimationFrame(tick);

    const pause = () => {
      drift.active = false;
      clearTimeout(drift.idleTimer);
      drift.idleTimer = setTimeout(() => { drift.active = true; last = performance.now(); }, 7000);
    };
    ["mousedown", "touchstart", "wheel"].forEach((ev) =>
      map.getCanvas().addEventListener(ev, pause, { passive: true })
    );

    return () => {
      cancelAnimationFrame(drift.raf);
      clearTimeout(drift.idleTimer);
      map.remove();
      mapRef.current = null;
      styleReadyRef.current = false;
    };
  }, []);

  // ── Heat layer sync ──
  const syncHeat = useCallback(() => {
    const map = mapRef.current;
    if (!map || !styleReadyRef.current) return;
    if (!layers.outline) {
      if (map.getLayer("go-heat-glow")) map.setLayoutProperty("go-heat-glow", "visibility", "none");
      return;
    }
    const fc = toHeatFeatures(sites, zones);
    if (map.getSource("go-heat")) {
      map.getSource("go-heat").setData(fc);
      if (map.getLayer("go-heat-glow")) map.setLayoutProperty("go-heat-glow", "visibility", "visible");
    } else {
      map.addSource("go-heat", { type: "geojson", data: fc });
      map.addLayer({ id: "go-heat-glow", type: "heatmap", source: "go-heat", paint: HEAT_PAINT });
    }
  }, [sites, zones, layers.outline]);

  useEffect(() => { syncHeat(); }, [syncHeat]);

  // ── Cluster bubbles ──
  const syncClusters = useCallback(() => {
    const map = mapRef.current;
    if (!map || !styleReadyRef.current) return;
    const fc = {
      type: "FeatureCollection",
      features: sites
        .filter((s) => (s.latitude ?? s.lat) != null && (s.longitude ?? s.lng) != null)
        .map((s) => ({
          type: "Feature",
          geometry: { type: "Point", coordinates: [s.longitude ?? s.lng, s.latitude ?? s.lat] },
          properties: { w: siteHeatWeight(s) }
        }))
    };
    if (map.getSource("go-clusters")) {
      map.getSource("go-clusters").setData(fc);
      return;
    }
    map.addSource("go-clusters", {
      type: "geojson", data: fc,
      cluster: true, clusterRadius: 55, clusterMaxZoom: CLUSTER_MAX_ZOOM - 1
    });
    map.addLayer({
      id: "go-cluster-bubble", type: "circle", source: "go-clusters",
      filter: ["has", "point_count"],
      paint: {
        "circle-color": "rgba(74,140,126,0.4)",
        "circle-stroke-color": "#5ae4b7",
        "circle-stroke-width": 2.5,
        "circle-radius": ["step", ["get", "point_count"], 16, 5, 22, 12, 30],
        "circle-blur": 0.1
      }
    });
    map.addLayer({
      id: "go-cluster-count", type: "symbol", source: "go-clusters",
      filter: ["has", "point_count"],
      layout: { "text-field": "{point_count_abbreviated}", "text-size": 13 },
      paint: { "text-color": "#5ae4b7", "text-halo-color": "#101e1e", "text-halo-width": 1.2 }
    });
    map.on("click", "go-cluster-bubble", async (e) => {
      const feat = map.queryRenderedFeatures(e.point, { layers: ["go-cluster-bubble"] })[0];
      if (!feat) return;
      const zoom = await map.getSource("go-clusters").getClusterExpansionZoom(feat.properties.cluster_id);
      map.easeTo({ center: feat.geometry.coordinates, zoom: Math.max(zoom, CLUSTER_MAX_ZOOM), duration: 700 });
    });
    map.on("mouseenter", "go-cluster-bubble", () => { map.getCanvas().style.cursor = "pointer"; });
    map.on("mouseleave", "go-cluster-bubble", () => { map.getCanvas().style.cursor = ""; });
  }, [sites]);

  useEffect(() => { syncClusters(); }, [syncClusters]);

  // Player marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !userLat || !userLng) return;
    if (!layers.position) {
      if (playerRef.current) playerRef.current.getElement().style.display = "none";
      return;
    }
    if (!playerRef.current) {
      playerRef.current = new maplibregl.Marker({ element: makeMysteryPlayerMarker(), anchor: "center" })
        .setLngLat([userLng, userLat]).addTo(map);
      map.flyTo({ center: [userLng, userLat], zoom: 14.8, pitch: 62, duration: 1800 });
    } else {
      playerRef.current.setLngLat([userLng, userLat]);
      playerRef.current.getElement().style.display = "";
    }
  }, [userLat, userLng, layers.position]);

  // Mystery markers
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    markersRef.current.forEach((m) => m.remove());
    if (!layers.mystery) { markersRef.current = []; return; }
    markersRef.current = sites
      .filter((s) => (s.latitude ?? s.lat) && (s.longitude ?? s.lng))
      .slice(0, 60)
      .map((site, i) => {
        const type = classifySite(site);
        const colorKey = type.key === "fossil" ? "rare" : type.key === "gold" ? "legendary" : type.key === "gemstone" ? "epic" : "default";
        const el = makeMysteryMarker(colorKey, () => {
          setSelected(site);
          map.flyTo({
            center: [site.longitude ?? site.lng, site.latitude ?? site.lat],
            zoom: Math.max(map.getZoom(), 15), duration: 900
          });
        }, i);
        if (map.getZoom() < CLUSTER_MAX_ZOOM) el.style.display = "none";
        return new maplibregl.Marker({ element: el, anchor: "center" })
          .setLngLat([site.longitude ?? site.lng, site.latitude ?? site.lat])
          .addTo(map);
      });
  }, [sites, layers.mystery]);

  // Fetch explored cells for stats
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const specimens = await base44.entities.Specimen.list("-created_date", 200);
        if (!active) return;
        const cells = new Set();
        specimens.forEach((s) => {
          if (s.latitude && s.longitude) cells.add(`${s.latitude.toFixed(2)},${s.longitude.toFixed(2)}`);
        });
        setExploredCells(cells.size);
      } catch { /* non-critical */ }
    })();
    return () => { active = false; };
  }, []);

  const recenter = useCallback(() => {
    mapRef.current?.flyTo({ center: [centerLng, centerLat], zoom: 14.8, pitch: is3D ? 62 : 0, bearing: -18, duration: 1200 });
  }, [centerLng, centerLat, is3D]);

  const toggleTilt = useCallback((next3D) => {
    setIs3D(next3D);
    mapRef.current?.easeTo({ pitch: next3D ? 62 : 0, bearing: next3D ? -18 : 0, duration: 800 });
  }, []);

  const toggleLayer = useCallback((key) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const exploredAreaKm2 = exploredCells * 1.2;
  const explorationPct = (exploredAreaKm2 / 510072000) * 100;

  return (
    <MapErrorBoundary
      height={height}
      fallback={
        <GoFallbackMap
          sites={sites}
          zones={zones}
          userLat={userLat}
          userLng={userLng}
          height={height}
          coordLabel={coordLabel}
        />
      }
    >
      <div className="rh-mystery-map relative overflow-hidden"
        style={{
          height,
          borderRadius: 18,
          border: "1px solid rgba(90,228,183,0.20)",
          boxShadow: "0 8px 32px rgba(0,0,0,0.6), 0 0 24px rgba(90,228,183,0.08), inset 0 1px 0 rgba(255,255,255,0.05)",
          background: "#101e1e"
        }}>
        <style>{MYSTERY_MAP_CSS}</style>

        <div ref={containerRef} className="absolute inset-0" />

        {/* Fog of war overlay */}
        <div className="rh-fog-overlay" style={{ opacity: layers.outline ? 0.7 : 0 }} />

        {/* Top stats bar */}
        <MysteryMapStatsBar
          onExplorationClick={() => setShowExploration(true)}
          siteCount={sites.length}
        />

        {/* Floating controls */}
        <MysteryMapControls
          onSettings={() => setShowStyleModal(true)}
          onLayers={() => setShowDisplayModal(true)}
          onCompass={recenter}
          onZoomIn={() => mapRef.current?.zoomIn()}
          onZoomOut={() => mapRef.current?.zoomOut()}
        />

        {/* Bottom location panel */}
        <MysteryMapBottomPanel
          locationName={coordLabel}
          mysteryCount={sites.length}
        />

        {/* Modals */}
        <AnimatePresence>
          {showStyleModal &&
            <MapStyleModal
              key="map-style"
              open={showStyleModal}
              onClose={() => setShowStyleModal(false)}
              is3D={is3D}
              onToggle3D={toggleTilt}
              fogColor={fogColor}
              onFogChange={setFogColor}
            />
          }
          {showDisplayModal &&
            <MapDisplaySettingsModal
              key="display-settings"
              open={showDisplayModal}
              onClose={() => setShowDisplayModal(false)}
              layers={layers}
              onToggle={toggleLayer}
            />
          }
          {showExploration &&
            <ExplorationProgressModal
              key="exploration"
              open={showExploration}
              onClose={() => setShowExploration(false)}
              explorationPct={explorationPct}
              exploredCells={exploredCells}
            />
          }
        </AnimatePresence>

        {/* Site detail sheet */}
        <AnimatePresence>
          {selected &&
            <GoSiteSheet site={selected} userLat={userLat} userLng={userLng} onClose={() => setSelected(null)} />
          }
        </AnimatePresence>
      </div>
    </MapErrorBoundary>
  );
}