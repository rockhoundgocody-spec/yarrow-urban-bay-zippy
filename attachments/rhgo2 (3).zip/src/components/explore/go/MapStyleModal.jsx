/**
 * MapStyleModal — Customize Mystery Map.
 * Two tabs: Fog Color and Map Style (3D / 2D).
 */
import React, { useState } from "react";
import { motion } from "framer-motion";
import { X, Check } from "lucide-react";

const FOG_PRESETS = [
  { key: "teal",   color: "#4a8c7e", label: "Deep Teal" },
  { key: "dark",   color: "#101e1e", label: "Midnight" },
  { key: "amber",  color: "#3a3020", label: "Amber Dust" },
  { key: "violet", color: "#1a1530", label: "Amethyst" },
];

export default function MapStyleModal({ open, onClose, is3D, onToggle3D, fogColor, onFogChange }) {
  const [tab, setTab] = useState("style");
  if (!open) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="absolute inset-0 z-40 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.5)" }}
      onClick={onClose}>
      <motion.div
        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-3xl p-5 pb-6"
        style={{ background: "#152021", border: "1px solid rgba(90,228,183,0.2)", borderTop: "1px solid rgba(90,228,183,0.35)" }}>

        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">Customize Mystery Map</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center tap-compact"
            style={{ background: "rgba(255,255,255,0.06)" }}>
            <X className="w-4 h-4" style={{ color: "rgba(255,255,255,0.5)" }} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-6 mb-5 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          {[
            { key: "fog", label: "Fog Color" },
            { key: "style", label: "Map Style" },
          ].map((t) => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className="pb-2.5 text-sm font-semibold transition-colors tap-compact relative"
              style={{ color: tab === t.key ? "#ffffff" : "#707A7A" }}>
              {t.label}
              {tab === t.key && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full" style={{ background: "#48D9B2" }} />
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        {tab === "style" ? (
          <div className="grid grid-cols-2 gap-3 mb-5">
            {[
              { key: true,  label: "3D Map", sub: "High quality view", img: "https://images.unsplash.com/photo-1543387146-1f4ec5ad7a4a?w=300&h=200&fit=crop" },
              { key: false, label: "2D Map", sub: "Smooth performance", img: "https://images.unsplash.com/photo-1524661135-423995f22d20?w=300&h=200&fit=crop" },
            ].map((opt) => (
              <button key={opt.key} onClick={() => onToggle3D(opt.key)}
                className="text-left rounded-2xl overflow-hidden tap-compact transition-all"
                style={{
                  border: is3D === opt.key ? "2px solid #48D9B2" : "2px solid rgba(255,255,255,0.06)",
                  background: is3D === opt.key ? "rgba(72,217,178,0.08)" : "transparent",
                }}>
                <div className="aspect-[3/2] overflow-hidden">
                  <img src={opt.img} alt={opt.label} className="w-full h-full object-cover" loading="lazy" />
                </div>
                <div className="p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-bold text-white">{opt.label}</span>
                    <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center"
                      style={{ borderColor: is3D === opt.key ? "#48D9B2" : "rgba(255,255,255,0.2)", background: is3D === opt.key ? "#48D9B2" : "transparent" }}>
                      {is3D === opt.key && <Check className="w-3 h-3" style={{ color: "#152021" }} />}
                    </div>
                  </div>
                  <p className="text-[11px] mt-0.5" style={{ color: "#707A7A" }}>{opt.sub}</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 mb-5">
            {FOG_PRESETS.map((f) => (
              <button key={f.key} onClick={() => onFogChange(f.color)}
                className="text-left rounded-2xl p-3 tap-compact transition-all"
                style={{
                  border: fogColor === f.color ? "2px solid #48D9B2" : "2px solid rgba(255,255,255,0.06)",
                  background: fogColor === f.color ? "rgba(72,217,178,0.08)" : "transparent",
                }}>
                <div className="w-full h-12 rounded-lg mb-2" style={{ background: f.color }} />
                <span className="text-sm font-bold text-white">{f.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* Select button */}
        <button onClick={onClose}
          className="w-full py-3.5 rounded-2xl text-sm font-bold tap-compact transition-all active:scale-[0.98]"
          style={{ background: "#48D9B2", color: "#152021" }}>
          Select
        </button>
      </motion.div>
    </motion.div>
  );
}