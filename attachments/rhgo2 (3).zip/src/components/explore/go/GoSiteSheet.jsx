/**
 * GoSiteSheet — friendly bottom sheet when a site marker is tapped.
 * Big text, big buttons, plain language.
 *
 * Legal-first: surfaces the 5 location signals (access, collecting,
 * coordinate quality, evidence, gated action) and conditionally blocks
 * navigation for closed / private-permission sites.
 */
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { X, Navigation, Gem, MapPin, Compass, ShieldAlert, Info, ExternalLink, CheckCircle2 } from "lucide-react";
import { deriveAccessStatus } from "@/components/map/locationSignals";
import LocationStatusSignals from "@/components/map/LocationStatusSignals";
import { track } from "@/lib/analyticsEvents";

function distanceMiles(lat1, lng1, lat2, lng2) {
  if (!lat1 || !lat2) return null;
  const R = 3959, toRad = d => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default function GoSiteSheet({ site, userLat, userLng, onClose }) {
  const [rulesAcked, setRulesAcked] = useState(false);
  if (!site) return null;
  const lat = site.latitude ?? site.lat;
  const lng = site.longitude ?? site.lng;
  const minerals = site.minerals || site.minerals_available || site.mineral_types || site.minerals_found || [];
  const dist = distanceMiles(userLat, userLng, lat, lng);
  const access = deriveAccessStatus(site);

  const navUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
  const blocked = !access.canNavigate;

  // Source links — blueprint RG-026
  const sourceUrls = (site.data_sources || []).filter(s => typeof s === "string" && s.startsWith("http"));
  const ownershipSource = site.ownership_source;
  const allSources = [...sourceUrls, ...(ownershipSource && ownershipSource.startsWith("http") ? [ownershipSource] : [])];
  const lastVerified = site.last_verified;

  // Rule acknowledgment required for navigable managed/fee sites — blueprint RG-027
  const needsAck = !blocked && (access.accessLabel === "Managed access" || access.accessLabel === "Fee dig" || access.accessLabel === "Verify access");
  const canProceed = blocked || !needsAck || rulesAcked;

  return (
    <motion.div
      initial={{ y: "110%" }} animate={{ y: 0 }} exit={{ y: "110%" }}
      transition={{ type: "spring", damping: 28, stiffness: 320 }}
      className="absolute inset-x-2 bottom-2 z-30 rounded-3xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(10,16,24,0.97), rgba(8,12,20,0.97))",
        border: `1.5px solid ${blocked ? "rgba(255,107,107,0.4)" : "rgba(0,214,143,0.35)"}`,
        boxShadow: "0 -8px 40px rgba(0,0,0,0.6), 0 0 24px rgba(0,214,143,0.12)",
      }}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3 min-w-0">
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center shrink-0"
            style={{ background: blocked ? "rgba(255,107,107,0.14)" : "rgba(0,214,143,0.14)",
                     border: `1px solid ${blocked ? "rgba(255,107,107,0.35)" : "rgba(0,214,143,0.35)"}` }}>
            <Gem className="w-5 h-5" style={{ color: blocked ? "#ff6b6b" : "#00D68F" }} />
          </div>
          <div className="min-w-0">
            <h3 className="text-base font-bold text-white leading-snug">{site.name || site.location_name || "Rockhounding Site"}</h3>
            <p className="flex items-center gap-1 text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
              <MapPin className="w-3 h-3" />
              {dist != null
                ? dist < 0.2
                  ? `${Math.round(dist * 5280)} ft away`
                  : `${dist < 10 ? dist.toFixed(1) : Math.round(dist)} mi away`
                : "Distance unknown"}
            </p>
          </div>
        </div>
        <button onClick={onClose} className="tap-compact p-2 rounded-xl shrink-0" aria-label="Close"
          style={{ background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.5)" }}>
          <X className="w-4 h-4" />
        </button>
      </div>

      {minerals.length > 0 && (
        <div className="flex gap-1.5 flex-wrap mt-3">
          {minerals.slice(0, 5).map(m => (
            <span key={m} className="px-2.5 py-1 rounded-full text-[11px] font-bold"
              style={{ background: "rgba(122,231,255,0.1)", border: "1px solid rgba(122,231,255,0.3)", color: "#7AE7FF" }}>
              💎 {m}
            </span>
          ))}
        </div>
      )}

      {site.description && (
        <p className="text-xs mt-3 leading-relaxed line-clamp-3" style={{ color: "rgba(255,255,255,0.5)" }}>
          {site.description}
        </p>
      )}

      {/* 5 location signals */}
      <LocationStatusSignals site={site} />

      {/* Access warning for restricted / closed sites */}
      {blocked && (
        <div className="mt-3 px-3 py-2.5 rounded-xl flex items-start gap-2"
          style={{ background: "rgba(255,107,107,0.08)", border: "1px solid rgba(255,107,107,0.25)" }}>
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" style={{ color: "#ff6b6b" }} />
          <p className="text-[11px] leading-snug" style={{ color: "rgba(255,107,107,0.85)" }}>
            {access.actionLabel === "Do not collect"
              ? "This site is closed or high-risk. Do not collect here."
              : "Permission required — contact the owner before visiting. Coordinates are approximate, not dig boundaries."}
          </p>
        </div>
      )}

      {/* Rule acknowledgment — required before navigation to managed/fee sites */}
      {needsAck && !rulesAcked && (
        <div className="mt-3 px-3 py-2.5 rounded-xl"
          style={{ background: "rgba(245,182,66,0.08)", border: "1px solid rgba(245,182,66,0.25)" }}>
          <button
            onClick={() => {
              setRulesAcked(true);
              track.hotspotRulesAcknowledged(site.id || site.name, "v1", access.collectionLabel, null);
            }}
            className="w-full flex items-start gap-2.5 text-left"
          >
            <div className="w-5 h-5 rounded-md border-2 shrink-0 mt-0.5 flex items-center justify-center"
              style={{ borderColor: "rgba(245,182,66,0.5)" }} />
            <div>
              <p className="text-xs font-bold" style={{ color: "#F5B642" }}>Verify current rules before traveling</p>
              <p className="text-[11px] mt-0.5 leading-snug" style={{ color: "rgba(255,255,255,0.5)" }}>
                Access, fees, permits, and collection limits can change. I acknowledge my responsibility to confirm current rules with the managing authority.
              </p>
            </div>
          </button>
        </div>
      )}

      {/* Source links — blueprint RG-026 */}
      {(allSources.length > 0 || lastVerified) && (
        <div className="mt-3 px-3 py-2.5 rounded-xl"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
          {lastVerified && (
            <p className="text-[10px] mb-1.5" style={{ color: "rgba(255,255,255,0.35)" }}>
              Last verified: {new Date(lastVerified).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" })}
            </p>
          )}
          {allSources.length > 0 && (
            <div className="space-y-1">
              {allSources.slice(0, 3).map((url, i) => {
                let domain = url;
                try { domain = new URL(url).hostname.replace("www.", ""); } catch {}
                return (
                  <a key={i} href={url} target="_blank" rel="noopener noreferrer"
                    onClick={() => track.hotspotSourceOpened(site.id || site.name, "agency", domain, null)}
                    className="flex items-center gap-1.5 text-[11px] font-semibold transition-opacity hover:opacity-70"
                    style={{ color: "#7AE7FF" }}>
                    <ExternalLink className="w-3 h-3 shrink-0" />
                    <span className="truncate">{domain}</span>
                  </a>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Conditional action buttons */}
      <div className="grid grid-cols-2 gap-2 mt-4">
        {blocked ? (
          <div className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold"
            style={{ background: "rgba(255,107,107,0.08)", border: "1px solid rgba(255,107,107,0.25)", color: "#ff6b6b" }}>
            <ShieldAlert className="w-4 h-4" /> {access.actionLabel}
          </div>
        ) : needsAck && !rulesAcked ? (
          <div className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold opacity-50"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.4)" }}>
            <CheckCircle2 className="w-4 h-4" /> Acknowledge first
          </div>
        ) : (
          <a href={navUrl} target="_blank" rel="noopener noreferrer"
            onClick={() => track.hotspotPrimaryAction(site.id || site.name, access.actionLabel, true, { access_status: access.accessLabel, collection_status: access.collectionLabel })}
            className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold"
            style={{ background: "linear-gradient(120deg, rgba(0,214,143,0.25), rgba(122,231,255,0.2))",
                     border: "1px solid rgba(0,214,143,0.45)", color: "#00D68F" }}>
            <Navigation className="w-4 h-4" /> {access.actionLabel}
          </a>
        )}
        <Link to="/TripPlanner"
          className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-sm font-bold"
          style={{ background: "rgba(141,124,255,0.12)", border: "1px solid rgba(141,124,255,0.35)", color: "#B8ACFF" }}>
          <Compass className="w-4 h-4" /> Plan trip
        </Link>
      </div>

      {/* Access info / permit details if available */}
      {site.access_info && (
        <div className="mt-3 px-3 py-2.5 rounded-xl flex items-start gap-2"
          style={{ background: "rgba(122,231,255,0.05)", border: "1px solid rgba(122,231,255,0.15)" }}>
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" style={{ color: "#7AE7FF" }} />
          <p className="text-[11px] leading-snug" style={{ color: "rgba(255,255,255,0.6)" }}>{site.access_info}</p>
        </div>
      )}
    </motion.div>
  );
}