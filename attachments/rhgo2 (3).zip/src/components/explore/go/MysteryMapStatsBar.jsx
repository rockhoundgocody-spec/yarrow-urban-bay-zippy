/**
 * MysteryMapStatsBar — Top user stats overlay.
 * Left: avatar + name + streak. Right: level, rank, XP bar, exploration %.
 */
import React, { useEffect, useState } from "react";
import { Flame, Lock, Globe, ChevronUp } from "lucide-react";
import { base44 } from "@/api/base44Client";

function rankForLevel(level) {
  if (level >= 30) return { tier: "Diamond", roman: "I", color: "#7AE7FF" };
  if (level >= 20) return { tier: "Platinum", roman: "I", color: "#C4B5FD" };
  if (level >= 10) return { tier: "Gold", roman: "V", color: "#F5B642" };
  if (level >= 5) return { tier: "Silver", roman: "V", color: "#C7D0D9" };
  return { tier: "Bronze", roman: "V", color: "#CD7F32" };
}

function xpForLevel(level) {
  return Math.floor(100 * Math.pow(level, 1.4));
}

export default function MysteryMapStatsBar({ onExplorationClick, siteCount = 0 }) {
  const [user, setUser] = useState(null);
  const [xp, setXp] = useState(null);
  const [exploredCells, setExploredCells] = useState(0);

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const me = await base44.auth.me();
        if (!active) return;
        setUser(me);

        const xpList = await base44.entities.UserXP.filter(
          { user_email: me.email }, "-created_date", 1
        );
        if (xpList.length > 0) setXp(xpList[0]);

        // Count unique visited locations from specimens
        const specimens = await base44.entities.Specimen.list("-created_date", 200);
        const cells = new Set();
        specimens.forEach((s) => {
          if (s.latitude && s.longitude) {
            cells.add(`${s.latitude.toFixed(2)},${s.longitude.toFixed(2)}`);
          }
        });
        setExploredCells(cells.size);
      } catch {
        // Non-critical — stats bar shows defaults
      }
    })();
    return () => { active = false; };
  }, []);

  const level = xp?.level || 1;
  const totalXp = xp?.total_xp || 0;
  const rank = rankForLevel(level);
  const nextLevelXp = xpForLevel(level + 1);
  const prevLevelXp = xpForLevel(level);
  const levelProgress = Math.min(100, ((totalXp - prevLevelXp) / (nextLevelXp - prevLevelXp)) * 100);

  // Earth surface ≈ 510,072,000 km². Each explored cell ≈ 1.2 km² (0.1° grid)
  const exploredAreaKm2 = exploredCells * 1.2;
  const explorationPct = (exploredAreaKm2 / 510072000) * 100;
  const pctStr = explorationPct.toFixed(9).replace(/0+$/, "");
  const pctLabel = pctStr.length > 6 ? pctStr.slice(0, -3) : pctStr;
  const pctSuffix = pctStr.length > 6 ? pctStr.slice(-3) : "";

  const displayName = user?.full_name?.split(" ")[0] || "Explorer";
  const streak = 0; // TODO: wire to daily quest streak

  const BAR_BG = "rgba(16,30,30,0.88)";
  const BAR_BORDER = "rgba(90,228,183,0.25)";

  return (
    <div className="absolute top-0 left-0 right-0 z-20 pointer-events-none">
      <div className="flex items-start justify-between px-3 pt-2 gap-2">
        {/* Left: avatar + name + streak */}
        <div className="flex items-center gap-2 pointer-events-auto rounded-2xl px-2.5 py-2"
          style={{ background: BAR_BG, border: `1px solid ${BAR_BORDER}`, backdropFilter: "blur(10px)" }}>
          <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 text-sm font-bold"
            style={{ background: "linear-gradient(145deg, #1a3a3a, #152427)", border: "1.5px solid rgba(90,228,183,0.4)", color: "#5ae4b7" }}>
            {displayName.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <div className="text-[13px] font-bold text-white leading-tight truncate">{displayName}</div>
            <div className="flex items-center gap-1 mt-0.5">
              <Flame className="w-3 h-3" style={{ color: "#F5B642" }} />
              <span className="text-[10px] font-semibold" style={{ color: "rgba(255,255,255,0.5)" }}>{streak}</span>
            </div>
          </div>
        </div>

        {/* Right: level + rank + progress + exploration */}
        <div className="flex flex-col items-end gap-1.5 pointer-events-auto">
          <div className="flex items-center gap-2 rounded-2xl px-2.5 py-1.5"
            style={{ background: BAR_BG, border: `1px solid ${BAR_BORDER}`, backdropFilter: "blur(10px)" }}>
            <span className="text-[11px] font-bold" style={{ color: "#5ae4b7" }}>{level} lvl</span>
            <span className="text-[11px] font-bold" style={{ color: rank.color }}>{rank.tier} {rank.roman}</span>
            <div className="flex items-center gap-1">
              <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.1)" }}>
                <div className="h-full rounded-full" style={{ width: `${levelProgress}%`, background: rank.color }} />
              </div>
              <span className="text-[9px] font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>{totalXp}/{nextLevelXp}</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-xl px-2 py-1"
              style={{ background: BAR_BG, border: `1px solid ${BAR_BORDER}`, backdropFilter: "blur(10px)" }}>
              <Lock className="w-3 h-3" style={{ color: "rgba(255,255,255,0.3)" }} />
              <span className="text-[9px] font-semibold" style={{ color: "rgba(255,255,255,0.35)" }}>Locked</span>
            </div>
            <button onClick={onExplorationClick}
              className="flex items-center gap-1 rounded-xl px-2 py-1 tap-compact transition-opacity hover:opacity-80"
              style={{ background: BAR_BG, border: `1px solid ${BAR_BORDER}`, backdropFilter: "blur(10px)" }}>
              <Globe className="w-3 h-3" style={{ color: "#5ae4b7" }} />
              <span className="text-[9px] font-semibold" style={{ color: "rgba(255,255,255,0.5)" }}>{pctLabel}</span>
              <span className="text-[9px] font-bold" style={{ color: "#5ae4b7" }}>{pctSuffix}%</span>
              <ChevronUp className="w-2.5 h-2.5" style={{ color: "rgba(255,255,255,0.3)" }} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}