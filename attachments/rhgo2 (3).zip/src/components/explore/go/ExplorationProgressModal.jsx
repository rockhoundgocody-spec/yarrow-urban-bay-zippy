/**
 * ExplorationProgressModal — World exploration percentage.
 * Earth icon, tiny percentage, "Explore the world!" heading.
 */
import React from "react";
import { motion } from "framer-motion";
import { X } from "lucide-react";

export default function ExplorationProgressModal({ open, onClose, explorationPct = 0, exploredCells = 0 }) {
  if (!open) return null;

  const pctStr = explorationPct.toFixed(9).replace(/0+$/, "") || "0";
  const splitAt = Math.max(0, pctStr.length - 3);
  const prefix = pctStr.slice(0, splitAt);
  const suffix = pctStr.slice(splitAt);

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="absolute inset-0 z-40 flex items-center justify-center"
      style={{ background: "rgba(0,0,0,0.6)" }}
      onClick={onClose}>
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
        transition={{ type: "spring", damping: 26, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="max-w-sm w-full mx-4 rounded-3xl p-6 text-center relative"
        style={{ background: "#152427", border: "1px solid rgba(90,228,183,0.2)" }}>

        <button onClick={onClose} className="absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center tap-compact"
          style={{ background: "rgba(255,255,255,0.06)" }}>
          <X className="w-4 h-4" style={{ color: "rgba(255,255,255,0.5)" }} />
        </button>

        {/* Earth icon */}
        <div className="w-20 h-20 mx-auto mb-4 rounded-full flex items-center justify-center"
          style={{
            background: "radial-gradient(circle at 35% 30%, #4299E1 0%, #2B6CB0 40%, #1A365D 100%)",
            border: "2px solid rgba(90,228,183,0.3)",
            boxShadow: "0 0 32px rgba(66,153,225,0.3), inset 0 0 16px rgba(90,228,183,0.1)",
          }}>
          <svg viewBox="0 0 24 24" className="w-12 h-12" fill="none" stroke="rgba(255,255,255,0.8)" strokeWidth="1.2">
            <circle cx="12" cy="12" r="10" />
            <path d="M2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20" />
            <path d="M5 7c3 2 4 2 7 0s4-2 7 0M5 17c3-2 4-2 7 0s4 2 7 0" opacity="0.5" />
          </svg>
        </div>

        {/* Percentage */}
        <div className="mb-3">
          <span className="text-2xl font-bold" style={{ color: "rgba(255,255,255,0.7)" }}>{prefix}</span>
          <span className="text-2xl font-bold" style={{ color: "#46E0B3" }}>{suffix}%</span>
        </div>

        {/* Heading */}
        <h3 className="text-lg font-bold mb-2" style={{ color: "#46E0B3" }}>Explore the world!</h3>

        {/* Body */}
        <p className="text-sm leading-relaxed mb-2" style={{ color: "rgba(255,255,255,0.65)" }}>
          Here we show you how much of our planet you've explored. Dive into adventure and let yourself be captivated by discovering new places and uncovering unknown landscapes waiting for your exploration.
        </p>

        {exploredCells > 0 && (
          <p className="text-[11px] mt-3" style={{ color: "rgba(255,255,255,0.35)" }}>
            {exploredCells} unique areas explored · {explorationPct.toFixed(12).replace(/0+$/, "")}% of Earth
          </p>
        )}
      </motion.div>
    </motion.div>
  );
}