/**
 * MysteryMapBottomPanel — Bottom location bar.
 * Shows current area name + mystery place count.
 */
import React from "react";
import { HelpCircle, MapPin } from "lucide-react";

export default function MysteryMapBottomPanel({ locationName, mysteryCount = 0 }) {
  return (
    <div className="absolute inset-x-0 bottom-0 z-20 pointer-events-none">
      <div className="mx-3 mb-2 flex items-center justify-between rounded-2xl px-3.5 py-3 pointer-events-auto"
        style={{
          background: "rgba(16,30,30,0.92)",
          border: "1px solid rgba(90,228,183,0.25)",
          boxShadow: "0 -4px 24px rgba(0,0,0,0.4)",
          backdropFilter: "blur(12px)",
        }}>
        <div className="flex items-center gap-2 min-w-0">
          <MapPin className="w-4 h-4 shrink-0" style={{ color: "#5ae4b7" }} />
          <span className="text-sm font-bold text-white truncate">
            {locationName || "Unknown Area"}
          </span>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <HelpCircle className="w-4 h-4" style={{ color: "#5ae4b7" }} />
          <span className="text-sm font-bold" style={{ color: "#5ae4b7" }}>{mysteryCount}</span>
        </div>
      </div>
    </div>
  );
}