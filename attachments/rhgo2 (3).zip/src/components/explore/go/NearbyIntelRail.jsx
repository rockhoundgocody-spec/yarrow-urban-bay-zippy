/**
 * NearbyIntelRail — AI-predicted local spots within 5 miles.
 * Horizontal card rail overlaid at the bottom of the GO map.
 * Caches per rounded location in sessionStorage to avoid repeat LLM calls.
 */
import React, { useEffect, useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Sparkles, RefreshCw, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { haversineMiles } from "@/features/explore/utils";
import { SPECIMEN_TYPES } from "./specimenTypes";

const RADIUS_MI = 5;

export default function NearbyIntelRail({ sites = [], userLat, userLng, onFocusSpot }) {
  const [spots, setSpots] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const run = useCallback(async () => {
    if (!userLat || !userLng) return;
    const cacheKey = `rh_intel_${userLat.toFixed(2)},${userLng.toFixed(2)}`;
    const cached = sessionStorage.getItem(cacheKey);
    if (cached) { setSpots(JSON.parse(cached)); return; }

    setLoading(true); setError(false);
    try {
      const within = sites
        .map((s) => ({ ...s, _lat: s.latitude ?? s.lat, _lng: s.longitude ?? s.lng }))
        .filter((s) => s._lat != null && s._lng != null)
        .map((s) => ({ ...s, _mi: haversineMiles(userLat, userLng, s._lat, s._lng) }))
        .filter((s) => s._mi <= RADIUS_MI)
        .slice(0, 15);

      const siteList = within.map((s, i) =>
        `${i}: ${s.name || s.title || "Unnamed site"} (${s._mi.toFixed(1)} mi) minerals: ${(s.minerals || s.minerals_available || []).join(", ") || "unknown"}`
      ).join("\n");

      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a rockhounding field intelligence engine. User is at ${userLat.toFixed(4)}, ${userLng.toFixed(4)}.
Known collecting sites within ${RADIUS_MI} miles (index: name, distance, minerals):
${siteList || "(none known — use regional geology knowledge)"}

Suggest 3-5 specific local spots to explore TODAY, all within ${RADIUS_MI} miles of the user. Prefer the known sites above (set match_site_index to their index); you may add 1-2 plausible geology-based spots (creek beds, gravel exposures, road cuts) with match_site_index -1 and realistic coordinates within ${RADIUS_MI} miles. For each: predict the 2-3 most likely minerals/specimens and give a one-sentence field reason.`,
        response_json_schema: {
          type: "object",
          properties: {
            spots: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  latitude: { type: "number" },
                  longitude: { type: "number" },
                  distance_mi: { type: "number" },
                  predicted_minerals: { type: "array", items: { type: "string" } },
                  reason: { type: "string" },
                  specimen_type: { type: "string", enum: Object.keys(SPECIMEN_TYPES) },
                  match_site_index: { type: "number" }
                }
              }
            }
          }
        }
      });

      const list = (res?.spots || []).slice(0, 5).map((sp) => ({
        ...sp,
        _site: sp.match_site_index >= 0 ? within[sp.match_site_index] : null
      }));
      setSpots(list);
      sessionStorage.setItem(cacheKey, JSON.stringify(list));
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  }, [sites, userLat, userLng]);

  useEffect(() => { run(); }, [run]);

  if (!userLat || !userLng) return null;

  return (
    <div className="absolute inset-x-0 bottom-2 z-20 pointer-events-none">
      <div className="flex items-center gap-1.5 px-3 mb-1">
        <Sparkles className="w-3 h-3" style={{ color: "#F5B642" }} />
        <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "#F5B642", textShadow: "0 1px 4px rgba(0,0,0,0.8)" }}>
          AI Nearby Intel · within {RADIUS_MI} mi
        </span>
        {loading && <RefreshCw className="w-3 h-3 animate-spin" style={{ color: "rgba(245,182,66,0.7)" }} />}
        {error && !loading && (
          <button onClick={run} className="pointer-events-auto tap-compact text-[10px] font-bold px-2 py-0.5 rounded-md"
            style={{ color: "#F5B642", background: "rgba(245,182,66,0.12)", border: "1px solid rgba(245,182,66,0.3)" }}>
            Retry
          </button>
        )}
      </div>

      <div className="flex gap-2 overflow-x-auto px-3 pb-1 pointer-events-auto" style={{ scrollbarWidth: "none" }}>
        {loading && !spots && [0, 1, 2].map((i) => (
          <div key={i} className="shrink-0 w-44 h-[74px] rounded-xl animate-pulse"
            style={{ background: "rgba(12,8,28,0.75)", border: "1px solid rgba(141,124,255,0.2)" }} />
        ))}
        {spots?.map((sp, i) => {
          const type = SPECIMEN_TYPES[sp.specimen_type] || SPECIMEN_TYPES.mineral;
          return (
            <motion.button key={i}
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
              onClick={() => onFocusSpot?.(sp)}
              className="shrink-0 w-44 text-left rounded-xl px-2.5 py-2 tap-compact"
              style={{
                background: "rgba(12,8,28,0.88)",
                border: `1px solid ${type.color}55`,
                boxShadow: `0 4px 16px rgba(0,0,0,0.5), 0 0 12px ${type.color}22`,
                backdropFilter: "blur(8px)"
              }}>
              <div className="flex items-center gap-1.5">
                <span className="text-sm leading-none">{type.icon}</span>
                <span className="text-[11px] font-bold truncate" style={{ color: "#F3F7FA" }}>{sp.name}</span>
              </div>
              <div className="flex items-center gap-1 mt-1">
                <MapPin className="w-2.5 h-2.5 shrink-0" style={{ color: type.color }} />
                <span className="text-[9px] font-semibold" style={{ color: type.color }}>
                  {(sp._site?._mi ?? sp.distance_mi ?? 0).toFixed(1)} mi · {(sp.predicted_minerals || []).slice(0, 2).join(", ")}
                </span>
              </div>
              <p className="text-[9px] mt-0.5 leading-tight line-clamp-2" style={{ color: "rgba(255,255,255,0.55)" }}>
                {sp.reason}
              </p>
            </motion.button>
          );
        })}
        {spots && spots.length === 0 && !loading && (
          <div className="shrink-0 px-3 py-2 rounded-xl text-[10px]"
            style={{ background: "rgba(12,8,28,0.8)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.1)" }}>
            No intel for this area yet — try refreshing after moving.
          </div>
        )}
      </div>
    </div>
  );
}