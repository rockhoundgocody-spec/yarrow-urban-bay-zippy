/**
 * MapDisplaySettingsModal — Toggle map layers.
 * Mystery Places, Explored Places, Current Position, Area Outline.
 */
import React from "react";
import { motion } from "framer-motion";
import { X, Check } from "lucide-react";

const LAYERS = [
  { key: "mystery",  label: "Mystery Places",    icon: "shield",   color: "#D69E2E" },
  { key: "explored", label: "Explored Places",   icon: "arch",     color: "#48D9B2" },
  { key: "position", label: "Current Position",  icon: "dot",      color: "#4299E1" },
  { key: "outline", label: "Area Outline",      icon: "shield-o", color: "#5ae4b7" },
];

function LayerIcon({ icon, color }) {
  const s = { width: 32, height: 32, borderRadius: 10, background: `${color}22`, border: `1px solid ${color}55`, display: "flex", alignItems: "center", justifyContent: "center" };
  if (icon === "shield") return <div style={s}><span style={{ fontSize: 16 }}>🛡️</span></div>;
  if (icon === "arch")  return <div style={s}><span style={{ fontSize: 16 }}>🏞️</span></div>;
  if (icon === "dot")   return <div style={s}><div style={{ width: 12, height: 12, borderRadius: "50%", background: color, boxShadow: `0 0 8px ${color}` }} /></div>;
  return <div style={s}><span style={{ fontSize: 16 }}>📐</span></div>;
}

export default function MapDisplaySettingsModal({ open, onClose, layers, onToggle }) {
  if (!open) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="absolute inset-0 z-40 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.5)" }}
      onClick={onClose}>
      <motion.div
        initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-3xl p-5 pb-6"
        style={{ background: "#1A202C", border: "1px solid rgba(90,228,183,0.2)", borderTop: "1px solid rgba(90,228,183,0.35)" }}>

        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-bold text-white">Map Display Settings</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center tap-compact"
            style={{ background: "rgba(255,255,255,0.06)" }}>
            <X className="w-4 h-4" style={{ color: "rgba(255,255,255,0.5)" }} />
          </button>
        </div>

        <div className="space-y-2 mb-5">
          {LAYERS.map((layer) => {
            const enabled = layers[layer.key];
            return (
              <button key={layer.key} onClick={() => onToggle(layer.key)}
                className="w-full flex items-center gap-3 p-3 rounded-2xl tap-compact transition-all"
                style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <LayerIcon icon={layer.icon} color={layer.color} />
                <span className="flex-1 text-left text-sm font-semibold text-white">{layer.label}</span>
                <div className="w-6 h-6 rounded-md flex items-center justify-center transition-all"
                  style={{
                    background: enabled ? "#4FD1C5" : "transparent",
                    border: enabled ? "none" : "2px solid rgba(255,255,255,0.15)",
                  }}>
                  {enabled && <Check className="w-4 h-4" style={{ color: "#1A202C" }} />}
                </div>
              </button>
            );
          })}
        </div>

        <button onClick={onClose}
          className="w-full py-3.5 rounded-2xl text-sm font-bold tap-compact transition-all active:scale-[0.98]"
          style={{ background: "#4FD1C5", color: "#1A202C" }}>
          Got it!
        </button>
      </motion.div>
    </motion.div>
  );
}