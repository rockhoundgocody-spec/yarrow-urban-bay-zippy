/**
 * MysteryMapControls — Floating map controls.
 * Right: settings cog, layers, compass. Left: zoom +/-, speedometer.
 */
import React, { useEffect, useState } from "react";
import { Settings, Layers, Compass, Plus, Minus, Gauge } from "lucide-react";

const BTN_BASE = {
  width: 42, height: 42, borderRadius: 14,
  display: "flex", alignItems: "center", justifyContent: "center",
  background: "rgba(16,30,30,0.88)",
  border: "1px solid rgba(90,228,183,0.25)",
  boxShadow: "0 4px 16px rgba(0,0,0,0.5)",
  color: "#5ae4b7",
  backdropFilter: "blur(10px)",
};

export default function MysteryMapControls({
  onSettings, onLayers, onCompass,
  onZoomIn, onZoomOut,
}) {
  const [speed, setSpeed] = useState(0);

  useEffect(() => {
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const ms = pos.coords.speed;
        if (ms != null && !isNaN(ms)) {
          setSpeed(Math.max(0, Math.round(ms * 3.6))); // m/s → km/h
        }
      },
      () => {},
      { enableHighAccuracy: true, maximumAge: 3000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  return (
    <>
      {/* Left: zoom + speedometer */}
      <div className="absolute left-3 top-1/2 -translate-y-1/2 z-20 flex flex-col items-center gap-2">
        <div className="flex flex-col rounded-2xl overflow-hidden"
          style={{ background: "rgba(16,30,30,0.88)", border: "1px solid rgba(90,228,183,0.25)", backdropFilter: "blur(10px)" }}>
          <button onClick={onZoomIn} style={{ ...BTN_BASE, borderRadius: 0, border: "none", borderBottom: "1px solid rgba(90,228,183,0.15)" }} aria-label="Zoom in">
            <Plus className="w-5 h-5" />
          </button>
          <button onClick={onZoomOut} style={{ ...BTN_BASE, borderRadius: 0, border: "none" }} aria-label="Zoom out">
            <Minus className="w-5 h-5" />
          </button>
        </div>
        <div className="flex items-center gap-1 rounded-xl px-2.5 py-1.5"
          style={{ background: "rgba(16,30,30,0.88)", border: "1px solid rgba(90,228,183,0.25)", backdropFilter: "blur(10px)" }}>
          <Gauge className="w-3 h-3" style={{ color: "rgba(90,228,183,0.6)" }} />
          <span className="text-[10px] font-bold" style={{ color: "rgba(255,255,255,0.6)" }}>{speed}</span>
          <span className="text-[8px] font-semibold" style={{ color: "rgba(255,255,255,0.3)" }}>km/h</span>
        </div>
      </div>

      {/* Right: settings, layers, compass */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
        <button onClick={onSettings} style={BTN_BASE} aria-label="Map settings">
          <Settings className="w-5 h-5" />
        </button>
        <button onClick={onLayers} style={BTN_BASE} aria-label="Map layers">
          <Layers className="w-5 h-5" />
        </button>
        <button onClick={onCompass} style={BTN_BASE} aria-label="Recenter">
          <Compass className="w-5 h-5" />
        </button>
      </div>
    </>
  );
}