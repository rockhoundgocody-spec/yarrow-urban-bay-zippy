/**
 * GoMapHUD — crystal-styled map controls: recenter, zoom, 2D/3D tilt.
 * Single vertical column on the right side — stays clear of the bottom sheet.
 */
import React from "react";
import { Crosshair, Plus, Minus, Box } from "lucide-react";

const BTN = {
  width: 44, height: 44, borderRadius: 12,
  display: "flex", alignItems: "center", justifyContent: "center",
  background: "rgba(12,8,28,0.85)",
  border: "1px solid rgba(141,124,255,0.35)",
  boxShadow: "0 4px 16px rgba(0,0,0,0.5)",
  color: "#C4B5FD",
  backdropFilter: "blur(8px)",
};

const BTN_ACTIVE = {
  ...BTN,
  background: "rgba(141,124,255,0.22)",
  borderColor: "rgba(141,124,255,0.6)",
};

export default function GoMapHUD({ onRecenter, onZoomIn, onZoomOut, onToggleTilt, is3D }) {
  return (
    <div className="absolute right-3 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-2">
      <button onClick={onZoomIn} style={BTN} aria-label="Zoom in" title="Zoom in"><Plus className="w-5 h-5" /></button>
      <button onClick={onZoomOut} style={BTN} aria-label="Zoom out" title="Zoom out"><Minus className="w-5 h-5" /></button>
      <button onClick={onToggleTilt} aria-label="Toggle 3D view" title="Toggle 3D view"
        style={is3D ? BTN_ACTIVE : BTN}>
        <Box className="w-5 h-5" />
      </button>
      <button onClick={onRecenter} aria-label="Center on me" title="Center on me"
        style={BTN_ACTIVE}>
        <Crosshair className="w-5 h-5" />
      </button>
    </div>
  );
}