/**
 * SeedsMapWithZoom: map component showing seeded locations with zoom/recenter controls
 * Integrates MapLibre, seed data, and interactive discovery
 */
import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import { seedDataService } from '@/services/map/seedDataService';
import MapZoomControls from '@/components/map/MapZoomControls';
import SeedLocationDetail from '@/components/map/SeedLocationDetail';
import { AlertCircle } from 'lucide-react';
import { offlineMapDownloader } from '@/lib/services/offlineMapDownloader';
import { toast } from 'sonner';

export default function SeedsMapWithZoom({ userLat, userLng, radiusFilter = 50 }) {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [nearbyLocations, setNearbyLocations] = useState([]);
  const [loading, setLoading] = useState(true);

  // Initialize map and seed data
  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    // Create map
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://tiles.openfreemap.org/styles/liberty',
      center: [userLng || -87.78, userLat || 41.79],
      zoom: 11,
      pitch: 0,
      bearing: 0,
      attributionControl: false,
    });

    // Load nearby locations
    const nearby = seedDataService.getLocationsNearby(
      userLat || 41.79,
      userLng || -87.78,
      radiusFilter
    );
    setNearbyLocations(nearby);

    // Add markers
    nearby.forEach((loc) => {
      const el = document.createElement('div');
      el.className = 'marker';
      el.style.cssText = `
        width: 40px;
        height: 40px;
        background: linear-gradient(135deg, #00D68F 0%, #7AE7FF 100%);
        border-radius: 50%;
        border: 3px solid white;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        transition: all 0.2s;
      `;
      el.innerHTML = '📍';
      el.onclick = () => setSelectedLocation(loc);

      new maplibregl.Marker({ element: el })
        .setLngLat([loc.lng, loc.lat])
        .addTo(map.current);
    });

    // User location marker
    if (userLat && userLng) {
      const userEl = document.createElement('div');
      userEl.style.cssText = `
        width: 16px;
        height: 16px;
        background: #F5B642;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 0 12px rgba(245, 182, 66, 0.6);
      `;
      new maplibregl.Marker({ element: userEl })
        .setLngLat([userLng, userLat])
        .addTo(map.current);
    }

    setLoading(false);
  }, [userLat, userLng, radiusFilter]);

  const handleLocate = () => {
    if (navigator.geolocation && map.current) {
      navigator.geolocation.getCurrentPosition((pos) => {
        map.current.easeTo({
          center: [pos.coords.longitude, pos.coords.latitude],
          zoom: 14,
          duration: 500,
        });
      });
    }
  };

  const handleOpenMaps = (lat, lng, name) => {
    const url = `https://maps.google.com/?q=${lat},${lng}`;
    window.open(url, '_blank');
  };

  const handleSaveOffline = async (locationId) => {
    const loc = nearbyLocations.find(l => l.id === locationId);
    if (!loc) return;

    const toastId = toast.loading(`Downloading map data for ${loc.name}...`);

    try {
      // Define a bounding box (~1km radius)
      const offset = 0.01;
      const bbox = {
        north_lat: loc.lat + offset,
        south_lat: loc.lat - offset,
        east_lng: loc.lng + offset,
        west_lng: loc.lng - offset
      };

      // Download tiles for zoom levels 12-16
      // Using OSM raster tiles as a reliable offline fallback
      const result = await offlineMapDownloader.downloadRegion(
        `loc_${locationId}`,
        bbox,
        12,
        16,
        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
        (progress) => {
          toast.loading(`Downloading ${loc.name}: ${Math.round((progress.current / progress.total) * 100)}%`, { id: toastId });
        }
      );

      if (result.success) {
        toast.success(`Saved "${loc.name}" for offline usage (${result.tileCount} tiles, ~${result.estimatedMB.toFixed(1)}MB).`, { id: toastId });
      }
    } catch (err) {
      console.error('Offline download failed:', err);
      toast.error(`Failed to save map: ${err.message}`, { id: toastId });
    }
  };

  if (loading) {
    return (
      <div className="w-full h-96 rounded-lg border border-border bg-secondary flex items-center justify-center">
        <div className="animate-spin w-6 h-6 border-3 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (nearbyLocations.length === 0) {
    return (
      <div className="w-full h-96 rounded-lg border border-border bg-card flex flex-col items-center justify-center gap-3 p-4">
        <AlertCircle className="w-8 h-8 text-muted-foreground" />
        <div className="text-center">
          <p className="font-semibold text-sm">No locations found</p>
          <p className="text-xs text-muted-foreground mt-1">
            Try expanding the search radius or sharing your location.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative rounded-lg overflow-hidden border border-border" style={{ height: 400 }}>
      {/* Map container */}
      <div ref={mapContainer} style={{ width: '100%', height: '100%' }} />

      {/* Zoom controls */}
      <MapZoomControls map={map.current} onLocate={handleLocate} />

      {/* Results badge */}
      <div className="absolute top-4 left-4 bg-background/90 backdrop-blur-sm px-3 py-1.5 rounded-lg text-xs font-semibold border border-border">
        {nearbyLocations.length} site{nearbyLocations.length !== 1 ? 's' : ''} found
      </div>

      {/* Detail sheet */}
      {selectedLocation && (
        <SeedLocationDetail
          location={selectedLocation}
          onClose={() => setSelectedLocation(null)}
          onOpenMaps={handleOpenMaps}
          onSaveOffline={handleSaveOffline}
        />
      )}
    </div>
  );
}