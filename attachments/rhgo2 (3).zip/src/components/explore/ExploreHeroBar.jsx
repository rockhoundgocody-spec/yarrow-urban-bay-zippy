/**
 * ExploreHeroBar — Explore screen discovery radar bar. Shock Pass v1.
 * Treasure radar, not a map header.
 */

import React from "react";
import { motion } from "framer-motion";
import { Radar, MapPin } from "lucide-react";

export default function ExploreHeroBar({ nearbyCount = 0, hotspotName, rarityPeak = "common" }) {
  const RARITY_COLOR = {
    common: "#7DF9FF", uncommon: "#00FFC6", rare: "#5BC0FF", epic: "#B97AFF", legendary: "#FFD700",
  };
  const peakColor = RARITY_COLOR[rarityPeak] || RARITY_COLOR.common;

  return (
    <div
      className="relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, rgba(4,8,14,0.95) 0%, rgba(6,10,20,0.92) 100%)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        boxShadow: "0 4px 32px rgba(0,0,0,0.6)",
      }}
    >
      {/* Radar pulse background */}
      <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2">
        {[1, 1.6, 2.3].map((scale, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: 48, height: 48,
              border: `1px solid ${peakColor}`,
              left: -24, top: -24,
              opacity: 0,
            }}
            animate={{ scale: [1, scale], opacity: [0.5, 0] }}
            transition={{ duration: 2.4, delay: i * 0.7, repeat: Infinity, ease: "easeOut" }}
          />
        ))}
        <div
          className="flex h-12 w-12 items-center justify-center rounded-full"
          style={{ background: `${peakColor}18`, border: `1px solid ${peakColor}35` }}
        >
          <Radar className="h-5 w-5" style={{ color: peakColor }} />
        </div>
      </div>

      {/* Content */}
      <div className="px-4 py-4 pr-20">
        {/* Eyebrow */}
        <div className="flex items-center gap-2 mb-2">
          <motion.div
            animate={{ opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 1.6, repeat: Infinity }}
            className="h-1.5 w-1.5 rounded-full"
            style={{ background: peakColor, boxShadow: `0 0 6px ${peakColor}` }}
          />
          <span className="text-[10px] font-bold uppercase tracking-[0.24em]" style={{ color: peakColor }}>
            Rarity Radar Online
          </span>
          {nearbyCount > 0 && (
            <>
              <span className="text-[10px] text-white/20">·</span>
              <span className="text-[10px] text-white/35">{nearbyCount} sites in range</span>
            </>
          )}
        </div>

        {/* Headline */}
        <h1 className="text-2xl font-black tracking-tight text-white leading-tight" style={{ letterSpacing: "-0.02em" }}>
          Wonders Near You
        </h1>

        {hotspotName ? (
          <div className="mt-1.5 flex items-center gap-1.5 text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
            <MapPin className="h-3 w-3" />
            <span>Nearest hotspot: <span className="text-white/65 font-semibold">{hotspotName}</span></span>
          </div>
        ) : (
          <div className="mt-1.5 text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>
            Mineral fog · live crystal pulse pins · terrain intelligence
          </div>
        )}
      </div>
    </div>
  );
}