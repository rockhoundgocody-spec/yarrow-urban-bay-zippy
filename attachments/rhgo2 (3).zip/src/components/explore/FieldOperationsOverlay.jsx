/**
 * FieldOperationsOverlay — Expedition console HUD for Field Mode Explore.
 * Live operational status: access/risk/hazard, offline zones, signal strength,
 * active opportunity, saved region indicators, session status.
 *
 * Field Mode only — hidden in Home Mode.
 * Designed for outdoor readability: high contrast, large targets, no noise.
 */
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Shield, WifiOff, AlertTriangle, MapPin, Compass,
  Circle, ChevronUp, ChevronDown, Zap, Lock
} from "lucide-react";
import { useModeStore } from "@/lib/modeStore.jsx";

// ── Status dot ────────────────────────────────────────────────────────────────
function StatusDot({ active, color = "#4AA354" }) {
  return (
    <motion.div
      className="rounded-full flex-shrink-0"
      style={{ width: 7, height: 7, background: active ? color : "rgba(255,255,255,0.15)" }}
      animate={active ? { boxShadow: [`0 0 0px ${color}00`, `0 0 8px ${color}CC`, `0 0 0px ${color}00`] } : {}}
      transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
    />
  );
}

// ── Indicator row ─────────────────────────────────────────────────────────────
function IndicatorRow({ icon: Icon, label, value, color, status = "ok", pulse = false }) {
  const statusColor = status === "risk" ? "#ef4444" : status === "warn" ? "#F5B642" : color || "#4AA354";
  return (
    <div className="flex items-center gap-2.5 py-1.5">
      <StatusDot active={pulse || status !== "ok"} color={statusColor} />
      <Icon className="w-3.5 h-3.5 flex-shrink-0" style={{ color: statusColor }} />
      <span className="text-[10px] font-semibold flex-1 leading-none" style={{ color: "rgba(240,255,244,0.65)" }}>{label}</span>
      <span className="text-[10px] font-black" style={{ color: statusColor }}>{value}</span>
    </div>
  );
}

export default function FieldOperationsOverlay({
  // Optional live props from parent
  legalityStatus,
  hazardCount = 0,
  isOfflineReady = false,
  opportunityZone = false,
  savedRegions = 0,
  sessionActive = false,
  nearbyCount = 0,
}) {
  const { isField } = useModeStore();
  const [collapsed, setCollapsed] = useState(false);
  const [gpsSignal, setGpsSignal] = useState("acquiring");

  useEffect(() => {
    if (!isField) return;
    if (!navigator.geolocation) { setGpsSignal("unavailable"); return; }
    const w = navigator.geolocation.watchPosition(
      () => setGpsSignal("strong"),
      () => setGpsSignal("weak"),
      { enableHighAccuracy: true, timeout: 8000 }
    );
    return () => navigator.geolocation.clearWatch(w);
  }, [isField]);

  if (!isField) return null;

  const legalColor =
    legalityStatus === "public_open" ? "#4AA354" :
    legalityStatus === "permit"      ? "#F5B642" :
    legalityStatus === "private"     ? "#ef4444" : "rgba(240,255,244,0.35)";

  const legalLabel =
    legalityStatus === "public_open" ? "Open Access" :
    legalityStatus === "permit"      ? "Permit Zone" :
    legalityStatus === "private"     ? "Private Land" : "Verify Access";

  return (
    <motion.div
      className="pointer-events-auto"
      style={{
        background: "rgba(3,10,6,0.94)",
        border: "1px solid rgba(74,163,84,0.28)",
        borderRadius: 16,
        backdropFilter: "blur(16px)",
        boxShadow: "0 4px 24px rgba(0,0,0,0.7), 0 0 14px rgba(74,163,84,0.08)",
        minWidth: 200,
        overflow: "hidden",
      }}
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.28, ease: [0.23, 1, 0.32, 1] }}
    >
      {/* Header bar */}
      <button
        className="w-full flex items-center justify-between px-3 py-2"
        onClick={() => setCollapsed(c => !c)}
        style={{ borderBottom: collapsed ? "none" : "1px solid rgba(74,163,84,0.14)" }}
      >
        <div className="flex items-center gap-2">
          <motion.div className="w-1.5 h-1.5 rounded-full"
            style={{ background: "#4AA354", boxShadow: "0 0 6px rgba(74,163,84,0.9)" }}
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 1.6, repeat: Infinity }} />
          <span className="text-[9px] font-black uppercase tracking-[0.22em]" style={{ color: "#4AA354" }}>
            Field Ops
          </span>
        </div>
        {collapsed ? <ChevronDown className="w-3 h-3" style={{ color: "rgba(74,163,84,0.5)" }} /> :
                     <ChevronUp   className="w-3 h-3" style={{ color: "rgba(74,163,84,0.5)" }} />}
      </button>

      {/* Body */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: "easeInOut" }}
            className="overflow-hidden px-3 pb-2"
          >
            {/* GPS */}
            <IndicatorRow
              icon={Compass}
              label="GPS"
              value={gpsSignal === "strong" ? "Strong" : gpsSignal === "weak" ? "Weak" : "…"}
              status={gpsSignal === "strong" ? "ok" : "warn"}
              pulse={gpsSignal === "strong"}
            />

            {/* Legality */}
            <IndicatorRow
              icon={legalityStatus === "private" ? Lock : Shield}
              label="Access"
              value={legalLabel}
              color={legalColor}
              status={legalityStatus === "private" ? "risk" : legalityStatus === "permit" ? "warn" : "ok"}
            />

            {/* Hazards */}
            {hazardCount > 0 && (
              <IndicatorRow
                icon={AlertTriangle}
                label="Hazards"
                value={`${hazardCount} flagged`}
                status="risk"
                pulse
              />
            )}

            {/* Offline */}
            <IndicatorRow
              icon={WifiOff}
              label="Offline Map"
              value={isOfflineReady ? "Cached" : "Not cached"}
              status={isOfflineReady ? "ok" : "warn"}
              pulse={isOfflineReady}
            />

            {/* Opportunity zone */}
            {opportunityZone && (
              <IndicatorRow
                icon={Zap}
                label="Opportunity"
                value="Active Zone"
                color="#FFCC44"
                pulse
              />
            )}

            {/* Nearby sites */}
            {nearbyCount > 0 && (
              <IndicatorRow
                icon={MapPin}
                label="Nearby Sites"
                value={`${nearbyCount} in range`}
                color="#88FF99"
                pulse
              />
            )}

            {/* Session */}
            <IndicatorRow
              icon={Circle}
              label="Session"
              value={sessionActive ? "Active" : "Idle"}
              color={sessionActive ? "#88FF99" : "rgba(240,255,244,0.25)"}
              status="ok"
              pulse={sessionActive}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}