/**
 * HotspotSelectPulse — rarity flare + pulse when a high-value map hotspot is tapped.
 * Mount as an absolute overlay inside the map marker or location card.
 *
 * Props:
 *  active    boolean
 *  rarity    "common" | "rare" | "legendary"
 *  onDone    fn
 */

import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const RARITY_COLOR = {
  common:    "#7DF9FF",
  uncommon:  "#00FFC6",
  rare:      "#9B5CFF",
  legendary: "#FFC857",
};

export default function HotspotSelectPulse({ active, rarity = "rare", onDone }) {
  const color = RARITY_COLOR[rarity] || RARITY_COLOR.rare;

  return (
    <AnimatePresence onExitComplete={onDone}>
      {active && (
        <>
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="pointer-events-none absolute inset-0 rounded-full"
              style={{ border: `1.5px solid ${color}`, boxShadow: `0 0 12px ${color}` }}
              initial={{ scale: 1, opacity: 0.8 }}
              animate={{ scale: 2.4 + i * 0.4, opacity: 0 }}
              transition={{ duration: 0.9, delay: i * 0.16, ease: "easeOut" }}
            />
          ))}
          <motion.div
            className="pointer-events-none absolute inset-0 rounded-full"
            style={{ background: `radial-gradient(circle, ${color}30 0%, transparent 70%)` }}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 0] }}
            transition={{ duration: 0.55 }}
          />
        </>
      )}
    </AnimatePresence>
  );
}