/**
 * CollectorProspectingReport
 * High-fidelity Clover-driven field intelligence report.
 * Surfaces probability zones, legality, geology, and Clover's brief.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, MapPin, Shield, AlertTriangle, CheckCircle, ChevronDown,
  ChevronUp, Gem, Layers, Clock, Target, Info
} from "lucide-react";

const TIER_CONFIG = {
  high:   { color: "#00D68F", bg: "rgba(0,214,143,0.1)",   border: "rgba(0,214,143,0.3)",   label: "High Probability" },
  medium: { color: "#F5B642", bg: "rgba(245,182,66,0.1)",  border: "rgba(245,182,66,0.3)",  label: "Moderate Signal" },
  low:    { color: "#7AE7FF", bg: "rgba(122,231,255,0.08)", border: "rgba(122,231,255,0.25)", label: "Speculative" },
};

const LEGALITY_CONFIG = {
  "Safe Public":  { color: "#00D68F", icon: CheckCircle },
  "Likely Legal": { color: "#7AE7FF", icon: CheckCircle },
  "Use Caution":  { color: "#F5B642", icon: AlertTriangle },
  "High Risk":    { color: "#ef4444", icon: AlertTriangle },
};

const POTENTIAL_CONFIG = {
  high:     { color: "#00D68F", label: "High Formation Potential" },
  moderate: { color: "#F5B642", label: "Moderate Formation Potential" },
  low:      { color: "#7AE7FF", label: "Low Formation Potential" },
};

function ConfidenceMeter({ value }) {
  const color = value >= 70 ? "#00D68F" : value >= 45 ? "#F5B642" : "#7AE7FF";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.08)" }}>
        <motion.div
          className="h-full rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>
      <span className="text-[11px] font-bold tabular-nums" style={{ color }}>{value}%</span>
    </div>
  );
}

function ZoneCard({ zone, index }) {
  const [open, setOpen] = useState(index === 0);
  const tier = TIER_CONFIG[zone.tier] || TIER_CONFIG.medium;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06 }}
      className="rounded-2xl overflow-hidden"
      style={{ background: tier.bg, border: `1px solid ${tier.border}` }}
    >
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-3 text-left"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: `${tier.color}20`, border: `1px solid ${tier.color}40` }}>
            <Target className="w-3.5 h-3.5" style={{ color: tier.color }} />
          </div>
          <div>
            <p className="text-sm font-bold text-white">{zone.name}</p>
            <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: tier.color }}>{tier.label}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="text-right">
            <p className="text-base font-black" style={{ color: tier.color }}>{zone.probability}%</p>
            <p className="text-[9px] text-white/30 uppercase tracking-wide">probability</p>
          </div>
          {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
        </div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-3" style={{ borderTop: `1px solid ${tier.border}` }}>
              {/* Minerals */}
              <div className="pt-3">
                <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2">Target Minerals</p>
                <div className="flex flex-wrap gap-1.5">
                  {(zone.predicted_minerals || []).map(m => (
                    <span key={m} className="px-2.5 py-1 rounded-full text-[11px] font-semibold"
                      style={{ background: `${tier.color}18`, border: `1px solid ${tier.color}35`, color: tier.color }}>
                      {m}
                    </span>
                  ))}
                </div>
              </div>

              {/* Geology type */}
              {zone.geology_type && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-1">Formation Type</p>
                  <div className="flex items-center gap-1.5">
                    <Layers className="w-3 h-3 text-white/30" />
                    <p className="text-xs text-white/60">{zone.geology_type}</p>
                  </div>
                </div>
              )}

              {/* Rationale */}
              {zone.rationale && (
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-1">Geological Basis</p>
                  <p className="text-xs text-white/55 leading-relaxed">{zone.rationale}</p>
                </div>
              )}

              {/* Radius */}
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3 h-3 text-white/25" />
                <p className="text-[11px] text-white/35">{zone.radius_km} km search radius · {zone.lat?.toFixed(4)}, {zone.lng?.toFixed(4)}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function CollectorProspectingReport({ report, loading, onRefresh }) {
  if (loading) {
    return (
      <div className="rounded-2xl p-6 flex flex-col items-center justify-center gap-4 min-h-[280px]"
        style={{ background: "rgba(0,214,143,0.04)", border: "1px solid rgba(0,214,143,0.15)" }}>
        <div className="relative w-12 h-12">
          <motion.div className="absolute inset-0 rounded-full"
            style={{ border: "1.5px solid #00D68F" }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0, 0.5] }}
            transition={{ duration: 1.2, repeat: Infinity }} />
          <div className="absolute inset-2 rounded-full flex items-center justify-center"
            style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.3)" }}>
            <Sparkles className="w-4 h-4" style={{ color: "#00D68F" }} />
          </div>
        </div>
        <div className="text-center">
          <p className="text-sm font-bold text-white/70">Generating Field Intelligence</p>
          <p className="text-xs text-white/30 mt-1">Analyzing geological data & site density…</p>
        </div>
      </div>
    );
  }

  if (!report) {
    return (
      <div className="rounded-2xl p-6 text-center min-h-[200px] flex flex-col items-center justify-center gap-3"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
        <Target className="w-8 h-8 text-white/15" />
        <div>
          <p className="text-sm font-semibold text-white/40">No Report Generated</p>
          <p className="text-xs text-white/25 mt-1">Share your location to generate a Collector Prospecting Report.</p>
        </div>
        {onRefresh && (
          <button onClick={onRefresh}
            className="px-4 py-2 rounded-xl text-xs font-bold transition-all"
            style={{ background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.3)", color: "#00D68F" }}>
            Generate Report
          </button>
        )}
      </div>
    );
  }

  const legality = report.access_summary?.legality_status || "Use Caution";
  const legalCfg = LEGALITY_CONFIG[legality] || LEGALITY_CONFIG["Use Caution"];
  const LegalIcon = legalCfg.icon;
  const potential = POTENTIAL_CONFIG[report.formation_potential] || POTENTIAL_CONFIG.moderate;

  return (
    <div className="space-y-4">
      {/* Clover Brief */}
      {report.clover_brief && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl p-4 flex items-start gap-3"
          style={{ background: "rgba(0,214,143,0.06)", border: "1px solid rgba(0,214,143,0.2)" }}
        >
          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.3)" }}>
            <Sparkles className="w-3.5 h-3.5" style={{ color: "#00D68F" }} />
          </div>
          <div className="flex-1">
            <p className="text-[10px] font-black uppercase tracking-widest text-white/30 mb-1">Clover Field Brief</p>
            <p className="text-sm text-white/80 leading-relaxed font-medium">{report.clover_brief}</p>
          </div>
        </motion.div>
      )}

      {/* Report header stats */}
      <div className="grid grid-cols-3 gap-3">
        {/* Confidence */}
        <div className="rounded-2xl p-3 col-span-3"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center justify-between mb-2">
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/30">Report Confidence</p>
            <span className="text-[10px] text-white/25">{report.data_basis}</span>
          </div>
          <ConfidenceMeter value={report.confidence || 0} />
        </div>

        {/* Formation potential */}
        <div className="rounded-2xl p-3 col-span-2"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-1.5 mb-1">
            <Layers className="w-3 h-3 text-white/25" />
            <p className="text-[10px] font-bold uppercase tracking-widest text-white/30">Formation</p>
          </div>
          <p className="text-sm font-bold" style={{ color: potential.color }}>{potential.label}</p>
          {report.formation_notes && (
            <p className="text-[10px] text-white/35 mt-1 leading-relaxed line-clamp-2">{report.formation_notes}</p>
          )}
        </div>

        {/* Zone count */}
        <div className="rounded-2xl p-3 flex flex-col items-center justify-center"
          style={{ background: "rgba(0,214,143,0.05)", border: "1px solid rgba(0,214,143,0.15)" }}>
          <p className="text-2xl font-black text-white">{report.probability_zones?.length || 0}</p>
          <p className="text-[9px] font-bold uppercase tracking-wider text-white/30 text-center">Active<br/>Zones</p>
        </div>
      </div>

      {/* Top target minerals */}
      {report.top_targets?.length > 0 && (
        <div className="rounded-2xl p-4"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2.5">Top Targets This Region</p>
          <div className="flex flex-wrap gap-1.5">
            {report.top_targets.map((m, i) => (
              <span key={m} className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold"
                style={{ background: "rgba(122,231,255,0.08)", border: "1px solid rgba(122,231,255,0.2)", color: "#7AE7FF" }}>
                <Gem className="w-2.5 h-2.5" />
                {m}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Probability zones */}
      {report.probability_zones?.length > 0 && (
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-3">
            Probability Zones · {report.probability_zones.length} detected
          </p>
          <div className="space-y-2">
            {report.probability_zones.map((zone, i) => (
              <ZoneCard key={zone.name || i} zone={zone} index={i} />
            ))}
          </div>
        </div>
      )}

      {/* Access & Legality */}
      {report.access_summary && (
        <div className="rounded-2xl overflow-hidden"
          style={{ border: `1px solid ${legalCfg.color}30` }}>
          <div className="flex items-center gap-2 px-4 py-3"
            style={{ background: `${legalCfg.color}0A`, borderBottom: `1px solid ${legalCfg.color}18` }}>
            <LegalIcon className="w-3.5 h-3.5" style={{ color: legalCfg.color }} />
            <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: legalCfg.color }}>
              {legality} — {report.access_summary.primary_land_manager}
            </p>
          </div>
          <div className="px-4 py-3 space-y-2.5" style={{ background: "rgba(255,255,255,0.02)" }}>
            <p className="text-xs text-white/55 leading-relaxed">{report.access_summary.legality_notes}</p>
            {report.access_summary.permit_required && (
              <div className="flex items-start gap-2 rounded-xl p-2.5"
                style={{ background: "rgba(245,182,66,0.08)", border: "1px solid rgba(245,182,66,0.2)" }}>
                <Shield className="w-3.5 h-3.5 shrink-0 mt-0.5" style={{ color: "#F5B642" }} />
                <p className="text-[11px] text-white/60 leading-relaxed">{report.access_summary.permit_notes}</p>
              </div>
            )}
            {report.access_summary.best_access_season && (
              <div className="flex items-center gap-1.5">
                <Clock className="w-3 h-3 text-white/25" />
                <p className="text-[11px] text-white/40">Best season: {report.access_summary.best_access_season}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Regional geology */}
      {report.regional_geology && (
        <div className="rounded-2xl p-4"
          style={{ background: "rgba(141,124,255,0.06)", border: "1px solid rgba(141,124,255,0.15)" }}>
          <div className="flex items-center gap-1.5 mb-2">
            <Info className="w-3 h-3" style={{ color: "#8D7CFF" }} />
            <p className="text-[10px] font-bold uppercase tracking-widest" style={{ color: "#8D7CFF" }}>Regional Geology</p>
          </div>
          <p className="text-xs text-white/55 leading-relaxed">{report.regional_geology}</p>
        </div>
      )}

      {/* Footer */}
      <div className="flex items-center justify-between pt-1">
        <p className="text-[10px] text-white/20">
          {report.source === "ai_backbone" ? "AI Backbone · " : "OpenRouter · "}
          {report.generated_at ? new Date(report.generated_at).toLocaleTimeString() : ""}
        </p>
        {onRefresh && (
          <button onClick={onRefresh}
            className="text-[11px] font-semibold transition-colors"
            style={{ color: "rgba(0,214,143,0.5)" }}>
            Refresh Report
          </button>
        )}
      </div>
    </div>
  );
}