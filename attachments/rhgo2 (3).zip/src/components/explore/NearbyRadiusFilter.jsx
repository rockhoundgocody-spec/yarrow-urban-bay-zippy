/**
 * NearbyRadiusFilter: radius toggle for nearby discovery
 */
import React from 'react';
import { motion } from 'framer-motion';

const RADIUS_OPTIONS = [10, 25, 50, 100];

export default function NearbyRadiusFilter({ selectedRadius, onRadiusChange }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center gap-2 flex-wrap"
    >
      <label className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        Search Radius:
      </label>
      <div className="flex gap-1.5">
        {RADIUS_OPTIONS.map((radius) => (
          <button
            key={radius}
            onClick={() => onRadiusChange(radius)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              selectedRadius === radius
                ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20'
                : 'bg-secondary hover:bg-secondary/80 text-foreground border border-border'
            }`}
          >
            {radius} mi
          </button>
        ))}
      </div>
    </motion.div>
  );
}