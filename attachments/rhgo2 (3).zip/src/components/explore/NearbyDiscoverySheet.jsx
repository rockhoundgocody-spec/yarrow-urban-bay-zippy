import React from "react";
import { MapPin, Sparkles } from "lucide-react";
import CrystalCard from "@/components/ui/CrystalCard";
import StatusChip from "@/components/ui/StatusChip";

export default function NearbyDiscoverySheet({ items = [], onSelect }) {
  return (
    <CrystalCard tone="dark">
      <div className="flex items-center justify-between gap-3">
        <div>
          <div className="text-[11px] uppercase tracking-[0.18em] text-cyan-300">
            Nearby Discoveries
          </div>
          <div className="mt-1 text-xl font-semibold text-white">
            Hotspots around you
          </div>
        </div>

        <StatusChip tone="discovery" icon={<Sparkles className="h-3.5 w-3.5" />}>
          {items.length} live
        </StatusChip>
      </div>

      <div className="mt-4 space-y-3">
        {items.length === 0 ? (
          <div className="text-sm text-white/60">
            No nearby spots loaded yet.
          </div>
        ) : (
          items.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelect?.(item)}
              className="w-full rounded-[22px] border border-white/12 bg-white/8 px-4 py-4 text-left transition hover:bg-white/14"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-base font-semibold text-white">
                    {item.name}
                  </div>
                  <div className="mt-1 flex items-center gap-1 text-sm text-white/60">
                    <MapPin className="h-4 w-4 text-cyan-500" />
                    {item.distanceLabel || "Nearby"}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 justify-end">
                  {item.tags?.slice(0, 2)?.map((tag) => (
                    <StatusChip key={tag} tone="info">
                      {tag}
                    </StatusChip>
                  ))}
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    </CrystalCard>
  );
}