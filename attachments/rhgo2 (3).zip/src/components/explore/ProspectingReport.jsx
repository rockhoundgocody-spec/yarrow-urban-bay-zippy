import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles, Shield, Mountain, MapPin, CheckCircle,
  ChevronDown, ChevronUp, Gem, Clock, Target
} from "lucide-react";

const RARITY_COLOR = {
  common: "#7AE7FF",
  uncommon: "#00D68F",
  rare: "#F5B642",
  "very rare": "#a855f7",
  legendary: "#ff4d4d",
};

const RISK_COLOR = {
  low: "#00D68F",
  medium: "#F5B642",
  high: "#ef4444",
};

function ProbBar({ value, color = "#00D68F" }) {
  return (
    <div className="relative h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.07)" }}>
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${value}%` }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="absolute inset-y-0 left-0 rounded-full"
        style={{ background: `linear-gradient(90deg, ${color}99, ${color})` }}
      />
    </div>
  );
}

function Section({ title, icon: Icon, color = "#00D68F", children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-4 py-3.5 text-left"
        style={{ borderBottom: open ? "1px solid rgba(255,255,255,0.06)" : "none" }}
      >
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${color}18`, border: `1px solid ${color}30` }}>
            <Icon className="w-3.5 h-3.5" style={{ color }} />
          </div>
          <span className="text-sm font-bold text-white/80">{title}</span>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-4 py-4">{children}</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function ProspectingReport({ report, onClose }) {
  if (!report) return null;

  const overallColor = report.overall_score >= 70 ? "#00D68F" : report.overall_score >= 40 ? "#F5B642" : "#7AE7FF";

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 16 }}
      transition={{ duration: 0.3 }}
      className="space-y-3"
    >
      {/* Header */}
      <div className="rounded-2xl p-4" style={{ background: "linear-gradient(135deg, rgba(0,214,143,0.08) 0%, rgba(122,231,255,0.04) 100%)", border: "1px solid rgba(0,214,143,0.2)" }}>
        <div className="flex items-start justify-between gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="w-4 h-4" style={{ color: "#00D68F" }} />
              <span className="text-[10px] font-black uppercase tracking-widest" style={{ color: "#00D68F" }}>Collector Prospecting Report</span>
            </div>
            <h2 className="text-lg font-black text-white leading-tight">{report.region_name || "Regional Intelligence"}</h2>
            <p className="text-xs text-white/40 mt-0.5 flex items-center gap-1.5">
              <Clock className="w-3 h-3" />
              {report.nearby_site_count} known sites analyzed · {new Date(report.generated_at).toLocaleTimeString()}
            </p>
          </div>
          <div className="text-center shrink-0">
            <div className="text-3xl font-black" style={{ color: overallColor }}>{report.overall_score ?? "—"}</div>
            <div className="text-[9px] uppercase tracking-widest text-white/30">Zone Score</div>
          </div>
        </div>
        <p className="text-[13px] text-white/60 leading-relaxed">{report.regional_overview}</p>
      </div>

      {/* Clover Briefing */}
      {report.clover_briefing && (
        <div className="rounded-2xl p-4 flex gap-3" style={{ background: "rgba(141,124,255,0.07)", border: "1px solid rgba(141,124,255,0.2)" }}>
          <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: "rgba(141,124,255,0.15)", border: "1px solid rgba(141,124,255,0.3)" }}>
            <Sparkles className="w-4 h-4" style={{ color: "#8D7CFF" }} />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest mb-1" style={{ color: "#8D7CFF" }}>Clover Field Briefing</p>
            <p className="text-[13px] text-white/70 leading-relaxed">{report.clover_briefing}</p>
          </div>
        </div>
      )}

      {/* Top Minerals */}
      {report.top_minerals?.length > 0 && (
        <Section title="Mineral Probability Map" icon={Gem} color="#F5B642">
          <div className="space-y-3">
            {report.top_minerals.map((m, i) => {
              const color = RARITY_COLOR[m.rarity?.toLowerCase()] || "#7AE7FF";
              return (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white/85">{m.name}</span>
                      {m.rarity && (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full uppercase" style={{ background: `${color}18`, color, border: `1px solid ${color}30` }}>
                          {m.rarity}
                        </span>
                      )}
                    </div>
                    <span className="text-sm font-black" style={{ color }}>{m.probability}%</span>
                  </div>
                  <ProbBar value={m.probability} color={color} />
                  {m.rationale && <p className="text-[11px] text-white/35 mt-1 leading-snug">{m.rationale}</p>}
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {/* Predicted Hotspot Zones */}
      {report.predicted_zones?.length > 0 && (
        <Section title="Predicted Hotspot Zones" icon={Target} color="#7AE7FF">
          <div className="space-y-3">
            {report.predicted_zones.map((z, i) => (
              <div key={i} className="rounded-xl p-3" style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.1)" }}>
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div>
                    <p className="text-sm font-bold text-white/85">{z.name}</p>
                    <p className="text-[10px] text-white/35 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3 h-3" />{z.lat?.toFixed(4)}, {z.lng?.toFixed(4)} · r={z.radius_km}km
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-base font-black" style={{ color: z.probability >= 70 ? "#00D68F" : z.probability >= 45 ? "#F5B642" : "#7AE7FF" }}>
                      {z.probability}%
                    </span>
                    <ProbBar value={z.probability} color={z.probability >= 70 ? "#00D68F" : "#F5B642"} />
                  </div>
                </div>
                {z.minerals?.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-1.5">
                    {z.minerals.map(m => (
                      <span key={m} className="text-[10px] px-1.5 py-0.5 rounded-full text-white/50" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)" }}>{m}</span>
                    ))}
                  </div>
                )}
                {z.rationale && <p className="text-[11px] text-white/35 leading-snug">{z.rationale}</p>}
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* Legal Intelligence */}
      {report.legal_intel && (
        <Section title="Legal & Access Intelligence" icon={Shield} color="#00D68F" defaultOpen={false}>
          <div className="space-y-3">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[11px] font-bold text-white/50">Risk Level:</span>
              <span className="text-[11px] font-black px-2 py-0.5 rounded-full uppercase" style={{
                color: RISK_COLOR[report.legal_intel.risk_level?.toLowerCase()] || "#7AE7FF",
                background: `${RISK_COLOR[report.legal_intel.risk_level?.toLowerCase()] || "#7AE7FF"}15`,
                border: `1px solid ${RISK_COLOR[report.legal_intel.risk_level?.toLowerCase()] || "#7AE7FF"}30`,
              }}>
                {report.legal_intel.risk_level || "Unknown"}
              </span>
            </div>
            {report.legal_intel.land_managers?.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {report.legal_intel.land_managers.map(lm => (
                  <span key={lm} className="text-[11px] px-2 py-0.5 rounded-full text-white/55" style={{ background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.15)" }}>
                    <CheckCircle className="w-2.5 h-2.5 inline mr-1" style={{ color: "#00D68F" }} />{lm}
                  </span>
                ))}
              </div>
            )}
            <p className="text-[12px] text-white/55 leading-relaxed">{report.legal_intel.summary}</p>
            {report.legal_intel.permit_notes && (
              <div className="rounded-xl p-3" style={{ background: "rgba(245,182,66,0.07)", border: "1px solid rgba(245,182,66,0.15)" }}>
                <p className="text-[10px] font-black uppercase tracking-widest mb-1" style={{ color: "#F5B642" }}>Permit Notes</p>
                <p className="text-[11px] text-white/50 leading-snug">{report.legal_intel.permit_notes}</p>
              </div>
            )}
            {report.legal_intel.access_tips && (
              <p className="text-[11px] text-white/40 leading-snug">{report.legal_intel.access_tips}</p>
            )}
          </div>
        </Section>
      )}

      {/* Formation Potential */}
      {report.formation_potential && (
        <Section title="Geological Formation Potential" icon={Mountain} color="#8D7CFF" defaultOpen={false}>
          <p className="text-[12px] text-white/55 leading-relaxed mb-3">{report.formation_potential.summary}</p>
          {report.formation_potential.key_formations?.map((f, i) => (
            <div key={i} className="mb-3 last:mb-0">
              <p className="text-sm font-semibold text-white/80 mb-0.5">{f.name}</p>
              {f.minerals?.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-1">
                  {f.minerals.map(m => (
                    <span key={m} className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: "rgba(141,124,255,0.1)", border: "1px solid rgba(141,124,255,0.2)", color: "#8D7CFF" }}>{m}</span>
                  ))}
                </div>
              )}
              {f.notes && <p className="text-[11px] text-white/35 leading-snug">{f.notes}</p>}
            </div>
          ))}
        </Section>
      )}

      {onClose && (
        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl text-xs font-semibold text-white/40 hover:text-white/60 transition-colors"
          style={{ border: "1px solid rgba(255,255,255,0.07)" }}
        >
          Clear Report
        </button>
      )}
    </motion.div>
  );
}