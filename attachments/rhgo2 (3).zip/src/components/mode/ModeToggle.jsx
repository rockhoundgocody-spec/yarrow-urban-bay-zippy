/**
 * ModeToggle — Home ↔ Field mode switch with feedback.
 * Premium compression + glow burst on toggle.
 */
import React from "react";
import { motion } from "framer-motion";
import { Home, Compass } from "lucide-react";
import { useModeStore } from "@/lib/modeStore.jsx";
import { feedback } from "@/lib/feedbackSystem";

export default function ModeToggle() {
  const { isField, toggleMode } = useModeStore();

  const handleToggle = (e) => {
    feedback.modeSwitch();
    toggleMode();
  };

  return (
    <motion.button
      onClick={handleToggle}
      className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all"
      style={{
        background: isField
          ? "linear-gradient(135deg, rgba(74,163,84,0.20), rgba(74,163,84,0.10))"
          : "linear-gradient(135deg, rgba(122,231,255,0.14), rgba(0,214,143,0.08))",
        border: isField
          ? "1px solid rgba(74,163,84,0.42)"
          : "1px solid rgba(122,231,255,0.28)",
        boxShadow: isField
          ? "0 0 12px rgba(74,163,84,0.20)"
          : "0 0 12px rgba(122,231,255,0.12)",
      }}
      whileTap={{ scale: 0.93, transition: { duration: 0.08 } }}
      whileHover={{ scale: 1.03 }}
    >
      <motion.div
        animate={{ rotate: isField ? 0 : 0 }}
        style={{ display: "flex", alignItems: "center" }}
      >
        {isField
          ? <Compass className="w-3.5 h-3.5" style={{ color: "#4AA354" }} />
          : <Home    className="w-3.5 h-3.5" style={{ color: "#7AE7FF" }} />}
      </motion.div>
      <span
        className="text-[9px] font-black uppercase tracking-widest"
        style={{ color: isField ? "#4AA354" : "#7AE7FF" }}
      >
        {isField ? "Field" : "Home"}
      </span>

      {/* Mode indicator pulse */}
      <motion.div
        className="w-1.5 h-1.5 rounded-full"
        style={{ background: isField ? "#4AA354" : "#7AE7FF" }}
        animate={{ opacity: [0.5, 1, 0.5], boxShadow: isField
          ? ["0 0 0px rgba(74,163,84,0)", "0 0 6px rgba(74,163,84,0.9)", "0 0 0px rgba(74,163,84,0)"]
          : ["0 0 0px rgba(122,231,255,0)", "0 0 6px rgba(122,231,255,0.9)", "0 0 0px rgba(122,231,255,0)"]
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />
    </motion.button>
  );
}