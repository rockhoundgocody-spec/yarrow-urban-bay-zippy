/**
 * CrystalParticleField — ambient crystal shimmer overlay.
 * Lightweight CSS-only. Reduced-motion safe.
 */
import React from "react";

const SHIMMER_POINTS = [
  { x: "18%", y: "22%", size: 4, delay: 0,   dur: 3.5, color: "#a78bfa" },
  { x: "72%", y: "18%", size: 3, delay: 1.2, dur: 4.2, color: "#7dd3fc" },
  { x: "35%", y: "60%", size: 5, delay: 0.6, dur: 5,   color: "#c4b5fd" },
  { x: "85%", y: "45%", size: 3, delay: 2.1, dur: 3.8, color: "#fbbf24" },
  { x: "55%", y: "30%", size: 4, delay: 0.3, dur: 4.5, color: "#a78bfa" },
  { x: "10%", y: "58%", size: 3, delay: 1.7, dur: 6,   color: "#7dd3fc" },
  { x: "92%", y: "72%", size: 4, delay: 0.9, dur: 4,   color: "#c4b5fd" },
  { x: "48%", y: "75%", size: 3, delay: 3,   dur: 5.5, color: "#fbbf24" },
];

export default function CrystalParticleField({ reduced }) {
  if (reduced) return null;

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 2 }}>
      <style>{`
        @keyframes rhShimmer {
          0%, 100% { opacity: 0; transform: scale(0.5) rotate(0deg); }
          30%       { opacity: 1; transform: scale(1.2) rotate(15deg); }
          60%       { opacity: 0.6; transform: scale(0.9) rotate(-10deg); }
        }
      `}</style>
      {SHIMMER_POINTS.map((p, i) => (
        <div
          key={i}
          className="absolute"
          style={{
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            animation: `rhShimmer ${p.dur}s ease-in-out ${p.delay}s infinite`,
          }}
        >
          {/* Diamond sparkle shape */}
          <div
            style={{
              width: p.size * 3,
              height: p.size * 3,
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%) rotate(45deg)",
              background: p.color,
              boxShadow: `0 0 ${p.size * 4}px ${p.color}, 0 0 ${p.size * 8}px ${p.color}60`,
              opacity: 0.8,
            }}
          />
        </div>
      ))}
    </div>
  );
}