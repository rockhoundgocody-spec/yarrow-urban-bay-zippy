/**
 * CinematicAuthScene — The animated layered background for the auth title screen.
 * Pure CSS/Tailwind animation, no heavy 3D libs. Mobile-first, reduced-motion safe.
 */
import React, { useEffect, useState } from "react";

const useReducedMotion = () => {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = (e) => setReduced(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);
  return reduced;
};

// Crystal cluster SVG — embedded inline for zero network cost
const CrystalCluster = ({ style, className, color = "#a78bfa", size = 80 }) => (
  <svg
    width={size}
    height={size * 1.2}
    viewBox="0 0 80 96"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    style={style}
    className={className}
  >
    <polygon points="40,4 58,30 52,88 40,92 28,88 22,30" fill={color} fillOpacity="0.18" stroke={color} strokeWidth="1.2" strokeOpacity="0.7" />
    <polygon points="40,4 58,30 52,60" fill={color} fillOpacity="0.32" />
    <polygon points="55,18 72,44 62,82 55,84 48,80 42,44" fill={color} fillOpacity="0.12" stroke={color} strokeWidth="0.8" strokeOpacity="0.5" />
    <polygon points="25,22 38,46 32,78 24,80 16,76 12,46" fill="#7dd3fc" fillOpacity="0.10" stroke="#7dd3fc" strokeWidth="0.8" strokeOpacity="0.4" />
    <line x1="40" y1="4" x2="40" y2="92" stroke={color} strokeWidth="0.5" strokeOpacity="0.3" />
    {/* Inner highlight */}
    <polygon points="40,12 50,28 46,50" fill="white" fillOpacity="0.12" />
  </svg>
);

// Floating dust/spark particle
const Particle = ({ style, reduced }) => {
  if (reduced) return null;
  return (
    <div
      className="absolute rounded-full pointer-events-none"
      style={{
        width: style.size,
        height: style.size,
        left: style.left,
        top: style.top,
        background: style.color,
        boxShadow: `0 0 ${style.size * 2}px ${style.color}`,
        animation: `rhAuthFloat ${style.duration}s ease-in-out ${style.delay}s infinite alternate`,
        opacity: style.opacity,
        filter: "blur(0.5px)",
      }}
    />
  );
};

const PARTICLES = [
  { size: 3, left: "12%", top: "25%", color: "#c4b5fd", duration: 6, delay: 0, opacity: 0.7 },
  { size: 2, left: "28%", top: "55%", color: "#7dd3fc", duration: 8, delay: 1.2, opacity: 0.6 },
  { size: 4, left: "65%", top: "30%", color: "#fbbf24", duration: 7, delay: 0.4, opacity: 0.5 },
  { size: 2, left: "78%", top: "68%", color: "#a78bfa", duration: 9, delay: 2, opacity: 0.65 },
  { size: 3, left: "45%", top: "15%", color: "#7dd3fc", duration: 5, delay: 0.8, opacity: 0.55 },
  { size: 2, left: "90%", top: "42%", color: "#c4b5fd", duration: 10, delay: 1.5, opacity: 0.5 },
  { size: 5, left: "8%", top: "72%", color: "#fbbf24", duration: 7.5, delay: 3, opacity: 0.4 },
  { size: 2, left: "55%", top: "80%", color: "#a78bfa", duration: 8.5, delay: 0.6, opacity: 0.6 },
  { size: 3, left: "36%", top: "40%", color: "#7dd3fc", duration: 6.5, delay: 2.5, opacity: 0.45 },
  { size: 2, left: "70%", top: "18%", color: "#c4b5fd", duration: 9.5, delay: 1.8, opacity: 0.7 },
];

export default function CinematicAuthScene({ children, reduced: reducedProp }) {
  const reducedSystem = useReducedMotion();
  const reduced = reducedProp || reducedSystem;

  return (
    <div
      className="fixed inset-0 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0a0514 0%, #0d0a1f 30%, #0f1423 60%, #050c18 100%)" }}
    >
      <style>{`
        @keyframes rhAuthFloat {
          from { transform: translateY(0px) scale(1); opacity: var(--op, 0.6); }
          to   { transform: translateY(-18px) scale(1.15); opacity: calc(var(--op, 0.6) * 0.5); }
        }
        @keyframes rhAuthDrift {
          0%   { transform: translateX(0px) translateY(0px); }
          25%  { transform: translateX(6px) translateY(-4px); }
          50%  { transform: translateX(12px) translateY(2px); }
          75%  { transform: translateX(4px) translateY(-6px); }
          100% { transform: translateX(0px) translateY(0px); }
        }
        @keyframes rhCrystalPulse {
          0%, 100% { opacity: 0.18; filter: brightness(1); }
          50%      { opacity: 0.42; filter: brightness(1.6); }
        }
        @keyframes rhVeinGlow {
          0%, 100% { opacity: 0.12; stroke-opacity: 0.25; }
          50%      { opacity: 0.38; stroke-opacity: 0.7; }
        }
        @keyframes rhLanternSweep {
          0%   { opacity: 0.35; transform: translateX(-8px); }
          50%  { opacity: 0.55; transform: translateX(8px); }
          100% { opacity: 0.35; transform: translateX(-8px); }
        }
        @keyframes rhMistDrift {
          0%   { transform: translateX(-30px); opacity: 0.12; }
          50%  { transform: translateX(30px); opacity: 0.22; }
          100% { transform: translateX(-30px); opacity: 0.12; }
        }
        @keyframes rhSilhouetteWalk {
          0%   { transform: translateX(-6px); }
          50%  { transform: translateX(6px); }
          100% { transform: translateX(-6px); }
        }
        @keyframes rhTitleGlow {
          0%, 100% { text-shadow: 0 0 30px rgba(167,139,250,0.35), 0 0 60px rgba(125,211,252,0.15); }
          50%      { text-shadow: 0 0 50px rgba(167,139,250,0.6), 0 0 90px rgba(125,211,252,0.25), 0 0 20px rgba(251,191,36,0.2); }
        }
        @keyframes rhAuroraShift {
          0%   { opacity: 0.07; transform: rotate(0deg) scale(1); }
          50%  { opacity: 0.13; transform: rotate(2deg) scale(1.05); }
          100% { opacity: 0.07; transform: rotate(0deg) scale(1); }
        }
      `}</style>

      {/* ── Layer 1: Deep sky aurora bands ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 120% 60% at 20% 0%, rgba(88,28,135,0.18) 0%, transparent 70%), radial-gradient(ellipse 80% 50% at 80% 10%, rgba(30,58,138,0.15) 0%, transparent 60%)",
          animation: reduced ? "none" : "rhAuroraShift 14s ease-in-out infinite",
        }}
      />

      {/* ── Layer 2: Canyon silhouette shapes (pure CSS geometry) ── */}
      <div className="absolute inset-x-0 bottom-0 pointer-events-none" style={{ height: "65%" }}>
        {/* Far left canyon wall */}
        <div
          className="absolute bottom-0 left-0"
          style={{
            width: "32%",
            height: "85%",
            background: "linear-gradient(170deg, #0c0a1a 0%, #12102a 40%, #0a0814 100%)",
            clipPath: "polygon(0% 100%, 0% 30%, 15% 15%, 30% 22%, 45% 8%, 60% 18%, 80% 12%, 100% 20%, 100% 100%)",
          }}
        />
        {/* Far right canyon wall */}
        <div
          className="absolute bottom-0 right-0"
          style={{
            width: "35%",
            height: "80%",
            background: "linear-gradient(190deg, #0c0a1a 0%, #110f28 40%, #090714 100%)",
            clipPath: "polygon(0% 20%, 20% 10%, 40% 18%, 55% 6%, 70% 14%, 85% 8%, 100% 16%, 100% 100%, 0% 100%)",
          }}
        />
        {/* Ground plane */}
        <div
          className="absolute bottom-0 inset-x-0"
          style={{
            height: "28%",
            background: "linear-gradient(180deg, #080614 0%, #0a0818 50%, #060410 100%)",
          }}
        />
        {/* Ground mineral vein glow */}
        <div
          className="absolute bottom-0 inset-x-0"
          style={{
            height: "18%",
            background: "linear-gradient(180deg, transparent 0%, rgba(124,58,237,0.06) 40%, rgba(167,139,250,0.12) 100%)",
            animation: reduced ? "none" : "rhVeinGlow 5s ease-in-out infinite",
          }}
        />
      </div>

      {/* ── Layer 3: Mid-ground ridge ── */}
      <div
        className="absolute inset-x-0 pointer-events-none"
        style={{
          bottom: "22%",
          height: "30%",
          background: "linear-gradient(175deg, transparent 0%, rgba(15,12,30,0.7) 50%, #0c0a1e 100%)",
          clipPath: "polygon(0% 100%, 0% 55%, 8% 45%, 18% 52%, 28% 38%, 38% 48%, 50% 35%, 62% 46%, 72% 30%, 82% 42%, 92% 32%, 100% 40%, 100% 100%)",
        }}
      />

      {/* ── Layer 4: Amethyst crystal clusters (left canyon wall) ── */}
      <div
        className="absolute pointer-events-none"
        style={{
          left: "4%",
          top: "35%",
          animation: reduced ? "none" : "rhCrystalPulse 4s ease-in-out infinite",
          animationDelay: "0s",
        }}
      >
        <CrystalCluster size={70} color="#a78bfa" />
      </div>
      <div
        className="absolute pointer-events-none"
        style={{
          left: "14%",
          top: "48%",
          animation: reduced ? "none" : "rhCrystalPulse 5.5s ease-in-out infinite",
          animationDelay: "1.2s",
        }}
      >
        <CrystalCluster size={45} color="#c4b5fd" />
      </div>
      {/* Right wall crystals */}
      <div
        className="absolute pointer-events-none"
        style={{
          right: "5%",
          top: "38%",
          transform: "scaleX(-1)",
          animation: reduced ? "none" : "rhCrystalPulse 6s ease-in-out infinite",
          animationDelay: "2s",
        }}
      >
        <CrystalCluster size={60} color="#818cf8" />
      </div>
      <div
        className="absolute pointer-events-none"
        style={{
          right: "16%",
          top: "52%",
          transform: "scaleX(-1)",
          animation: reduced ? "none" : "rhCrystalPulse 4.5s ease-in-out infinite",
          animationDelay: "0.7s",
        }}
      >
        <CrystalCluster size={38} color="#7dd3fc" />
      </div>

      {/* ── Layer 5: Ground-embedded glowing mineral veins (SVG lines) ── */}
      <svg
        className="absolute inset-x-0 bottom-0 pointer-events-none w-full"
        style={{ height: "28%", opacity: 0.6 }}
        viewBox="0 0 400 120"
        preserveAspectRatio="none"
      >
        <defs>
          <filter id="veinGlow">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <g filter="url(#veinGlow)" style={{ animation: reduced ? "none" : "rhVeinGlow 6s ease-in-out infinite" }}>
          <path d="M0,90 Q60,70 100,80 Q140,88 180,72 Q220,60 260,75 Q300,85 340,68 Q370,56 400,70" stroke="#a78bfa" strokeWidth="1.5" fill="none" strokeOpacity="0.5" />
          <path d="M0,105 Q50,95 90,100 Q130,104 170,94 Q210,84 250,98 Q290,108 330,92 Q360,80 400,95" stroke="#7dd3fc" strokeWidth="1" fill="none" strokeOpacity="0.35" />
          <path d="M40,115 Q90,105 140,112 Q190,118 240,108 Q280,100 320,110 Q360,118 400,108" stroke="#fbbf24" strokeWidth="0.8" fill="none" strokeOpacity="0.25" />
        </g>
      </svg>

      {/* ── Layer 6: Explorer silhouette ── */}
      <div
        className="absolute pointer-events-none"
        style={{
          bottom: "22%",
          left: "50%",
          transform: "translateX(-50%)",
          animation: reduced ? "none" : "rhSilhouetteWalk 8s ease-in-out infinite",
        }}
      >
        <svg width="28" height="72" viewBox="0 0 28 72" fill="none">
          {/* Body */}
          <ellipse cx="14" cy="20" rx="5" ry="6" fill="#0d0b1e" />
          <rect x="10" y="26" width="8" height="20" rx="3" fill="#0d0b1e" />
          {/* Legs (walking pose suggestion) */}
          <line x1="12" y1="46" x2="9" y2="64" stroke="#0d0b1e" strokeWidth="3" strokeLinecap="round" />
          <line x1="16" y1="46" x2="19" y2="62" stroke="#0d0b1e" strokeWidth="3" strokeLinecap="round" />
          {/* Arms */}
          <line x1="10" y1="30" x2="4" y2="42" stroke="#0d0b1e" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="18" y1="30" x2="24" y2="40" stroke="#0d0b1e" strokeWidth="2.5" strokeLinecap="round" />
          {/* Lantern glow */}
          <circle cx="24" cy="40" r="6" fill="#fbbf24" fillOpacity="0.18" style={{ animation: reduced ? "none" : "rhLanternSweep 3s ease-in-out infinite" }} />
          <circle cx="24" cy="40" r="3" fill="#fbbf24" fillOpacity="0.55" />
          {/* Headlamp */}
          <ellipse cx="14" cy="15" rx="6" ry="4" fill="#fbbf24" fillOpacity="0.15" style={{ animation: reduced ? "none" : "rhLanternSweep 3s ease-in-out infinite" }} />
        </svg>
      </div>

      {/* ── Layer 7: Lantern light cone ── */}
      <div
        className="absolute pointer-events-none"
        style={{
          bottom: "22%",
          left: "calc(50% + 12px)",
          width: "120px",
          height: "80px",
          background: "conic-gradient(from 165deg at 0% 50%, rgba(251,191,36,0.18) 0deg, transparent 40deg)",
          filter: "blur(8px)",
          transformOrigin: "left center",
          animation: reduced ? "none" : "rhLanternSweep 3s ease-in-out infinite",
        }}
      />

      {/* ── Layer 8: Floating mist bands ── */}
      <div
        className="absolute inset-x-0 pointer-events-none"
        style={{
          bottom: "20%",
          height: "12%",
          background: "linear-gradient(180deg, transparent 0%, rgba(167,139,250,0.05) 50%, transparent 100%)",
          filter: "blur(12px)",
          animation: reduced ? "none" : "rhMistDrift 12s ease-in-out infinite",
        }}
      />
      <div
        className="absolute inset-x-0 pointer-events-none"
        style={{
          bottom: "28%",
          height: "8%",
          background: "linear-gradient(180deg, transparent 0%, rgba(125,211,252,0.04) 50%, transparent 100%)",
          filter: "blur(16px)",
          animation: reduced ? "none" : "rhMistDrift 18s ease-in-out infinite",
          animationDelay: "4s",
        }}
      />

      {/* ── Layer 9: Floating dust particles ── */}
      {PARTICLES.map((p, i) => (
        <Particle key={i} style={p} reduced={reduced} />
      ))}

      {/* ── Layer 10: Spectral rim vignette ── */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: "radial-gradient(ellipse 100% 100% at 50% 50%, transparent 40%, rgba(0,0,0,0.7) 100%)",
        }}
      />

      {/* Content slot — scrollable so short screens can reach the menu */}
      <div className="absolute inset-0 z-10 overflow-y-auto" style={{ WebkitOverflowScrolling: "touch" }}>{children}</div>
    </div>
  );
}