/**
 * AuthIntroSequence — optional one-time cinematic intro.
 * Black → mineral vein glows → lantern sweep → crystals ignite → title.
 * Auto-skips after 3.5s or on tap. Respects reduced-motion.
 */
import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function AuthIntroSequence({ onComplete, reduced }) {
  const [phase, setPhase] = useState(0); // 0=black, 1=veins, 2=lantern, 3=crystals, 4=done
  const [skipped, setSkipped] = useState(false);

  useEffect(() => {
    if (reduced) { onComplete(); return; }

    const timings = [400, 900, 700, 800];
    let total = 0;
    const timers = timings.map((t, i) => {
      total += t;
      return setTimeout(() => setPhase(i + 1), total);
    });
    const doneTimer = setTimeout(() => onComplete(), total + 500);

    return () => { timers.forEach(clearTimeout); clearTimeout(doneTimer); };
  }, [reduced, onComplete]);

  const handleSkip = () => {
    setSkipped(true);
    setTimeout(onComplete, 300);
  };

  if (skipped) return null;

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 flex items-center justify-center cursor-pointer"
        style={{ background: "#000", zIndex: 9999 }}
        onClick={handleSkip}
        initial={{ opacity: 1 }}
        exit={{ opacity: 0, transition: { duration: 0.5 } }}
      >
        {/* Phase 1: mineral vein glow from bottom */}
        <AnimatePresence>
          {phase >= 1 && (
            <motion.div
              className="absolute inset-x-0 bottom-0"
              style={{ height: "30%", background: "linear-gradient(180deg, transparent 0%, rgba(167,139,250,0.12) 50%, rgba(124,58,237,0.22) 100%)" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
            />
          )}
        </AnimatePresence>

        {/* Phase 2: lantern light sweep */}
        <AnimatePresence>
          {phase >= 2 && (
            <motion.div
              className="absolute"
              style={{
                width: 200,
                height: 200,
                borderRadius: "50%",
                background: "radial-gradient(circle, rgba(251,191,36,0.25) 0%, transparent 70%)",
                top: "55%",
                left: "48%",
              }}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1.5 }}
              transition={{ duration: 0.7 }}
            />
          )}
        </AnimatePresence>

        {/* Phase 3: crystal ignition */}
        <AnimatePresence>
          {phase >= 3 && (
            <motion.div
              className="absolute inset-0 flex items-center justify-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6 }}
              style={{
                background: "radial-gradient(ellipse 60% 40% at 50% 60%, rgba(167,139,250,0.18) 0%, transparent 70%)",
              }}
            />
          )}
        </AnimatePresence>

        {/* Phase 4: title flash */}
        <AnimatePresence>
          {phase >= 4 && (
            <motion.div
              className="text-center relative px-6 py-4"
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
            >
              <div
                className="absolute inset-0 -z-10 rounded-2xl"
                style={{ background: "rgba(0,0,0,0.4)" }}
              />
              <h1
                className="font-black uppercase tracking-widest"
                style={{
                  fontSize: "clamp(2rem, 10vw, 3.5rem)",
                  background: "linear-gradient(135deg, #fbbf24, #c4b5fd, #7dd3fc)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                  filter: "drop-shadow(0 0 30px rgba(167,139,250,0.6))",
                }}
              >
                ROCKHOUND-GO
              </h1>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Skip hint */}
        <motion.p
          className="absolute bottom-8 text-xs tracking-widest uppercase"
          style={{ color: "rgba(167,139,250,0.35)" }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          Tap to skip
        </motion.p>
      </motion.div>
    </AnimatePresence>
  );
}