/**
 * AdminRoute — client-side role gate for admin/internal pages.
 * Non-admin (or logged-out) users are redirected to Home.
 * Note: real data protection lives in entity RLS + backend role checks;
 * this removes the UI exposure surface.
 */
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';

export default function AdminRoute({ children }) {
  const { user, isLoadingAuth } = useAuth();

  if (isLoadingAuth) return null;
  if (user?.role !== 'admin') return <Navigate to="/" replace />;

  return children;
}