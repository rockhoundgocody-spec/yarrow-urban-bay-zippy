/**
 * AuthGlassPanel — compact floating glass panel for Sign In / Create Account.
 * Slides in over the cinematic scene. Delegates actual auth to base44.auth.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Mail, Lock, User, Eye, EyeOff, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const panelVariants = {
  hidden: { opacity: 0, y: 60, scale: 0.97 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.55, ease: [0.23, 1, 0.32, 1] } },
  exit: { opacity: 0, y: 40, scale: 0.96, transition: { duration: 0.3, ease: "easeIn" } },
};

const FieldInput = ({ icon: IconComponent, placeholder, type = "text", value, onChange, rightElement }) => (
  <div
    className="relative flex items-center rounded-xl overflow-hidden"
    style={{
      background: "rgba(255,255,255,0.05)",
      border: "1px solid rgba(167,139,250,0.2)",
    }}
  >
    <div className="flex-shrink-0 pl-4">
      <IconComponent className="w-4 h-4" style={{ color: "rgba(167,139,250,0.6)" }} />
    </div>
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      className="flex-1 bg-transparent px-3 py-4 text-sm outline-none placeholder:text-white/25"
      style={{ color: "rgba(255,255,255,0.88)", minHeight: 52 }}
      autoComplete={type === "password" ? "current-password" : type === "email" ? "email" : "name"}
    />
    {rightElement && <div className="pr-3">{rightElement}</div>}
  </div>
);

export default function AuthGlassPanel({ mode, onBack, onSuccess }) {
  const isSignIn = mode === "signin";
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      // RockHound-GO uses base44 platform auth — redirect to platform login flow
      // The platform handles the actual credential verification.
      // We redirect to login with current page as the return URL.
      base44.auth.redirectToLogin(window.location.href);
    } catch (err) {
      setError(err?.message || "Authentication failed. Please try again.");
      setLoading(false);
    }
  };

  const handleForgotPassword = () => {
    base44.auth.redirectToLogin(window.location.href);
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={mode}
        className="w-full max-w-sm mx-auto px-5"
        variants={panelVariants}
        initial="hidden"
        animate="visible"
        exit="exit"
      >
        <div
          className="rounded-3xl p-6"
          style={{
            background: "linear-gradient(145deg, rgba(8,4,20,0.92) 0%, rgba(14,9,32,0.9) 100%)",
            border: "1px solid rgba(167,139,250,0.25)",
            backdropFilter: "blur(28px)",
            WebkitBackdropFilter: "blur(28px)",
            boxShadow: "0 16px 80px rgba(0,0,0,0.75), inset 0 1px 0 rgba(167,139,250,0.15), 0 0 60px rgba(124,58,237,0.1)",
          }}
        >
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <button
              onClick={onBack}
              className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-200"
              style={{
                background: "rgba(167,139,250,0.1)",
                border: "1px solid rgba(167,139,250,0.2)",
                color: "#a78bfa",
                minHeight: "unset",
                minWidth: "unset",
              }}
             aria-label="Go back" title="Go back">
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h2 className="font-bold text-base text-white">
                {isSignIn ? "Sign In to RockHound-GO" : "Create Field Profile"}
              </h2>
              <p className="text-xs" style={{ color: "rgba(167,139,250,0.55)" }}>
                {isSignIn ? "Access your collection & field data" : "Start your discovery journey"}
              </p>
            </div>
          </div>

          {/* Spectral divider */}
          <div
            className="mb-5 h-px rounded-full"
            style={{ background: "linear-gradient(90deg, transparent, rgba(167,139,250,0.3), transparent)" }}
          />

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            {!isSignIn && (
              <FieldInput
                icon={User}
                placeholder="Full Name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            )}
            <FieldInput
              icon={Mail}
              placeholder="Email address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <FieldInput
              icon={Lock}
              placeholder="Password"
              type={showPassword ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              rightElement={
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)} aria-label={showPassword ? "Hide password" : "Show password"} title={showPassword ? "Hide password" : "Show password"}
                  style={{ color: "rgba(167,139,250,0.5)", minHeight: "unset", minWidth: "unset", background: "none", border: "none" }}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
            />

            {error && (
              <p className="text-xs text-red-400 px-1">{error}</p>
            )}

            {/* Primary CTA */}
            <button
              type="submit"
              disabled={loading}
              className="relative w-full rounded-xl font-bold text-sm flex items-center justify-center gap-2 mt-2 transition-all duration-200 overflow-hidden"
              style={{
                minHeight: 54,
                background: loading
                  ? "rgba(251,191,36,0.25)"
                  : "linear-gradient(135deg, rgba(251,191,36,0.85) 0%, rgba(245,158,11,0.9) 100%)",
                border: "1px solid rgba(251,191,36,0.5)",
                color: loading ? "rgba(251,191,36,0.6)" : "#0a0514",
                boxShadow: loading ? "none" : "0 4px 24px rgba(251,191,36,0.25)",
              }}
            >
              {loading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                isSignIn ? "Enter Field Mode" : "Create Field Profile"
              )}
            </button>

            {/* Forgot password */}
            {isSignIn && (
              <button
                type="button"
                onClick={handleForgotPassword}
                className="text-xs text-center transition-colors duration-200"
                style={{ color: "rgba(167,139,250,0.5)", background: "none", border: "none", minHeight: "unset" }}
              >
                Forgot password?
              </button>
            )}
          </form>

          {/* Data persistence trust message */}
          <div className="mt-5 rounded-xl px-3 py-2.5"
            style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.12)" }}>
            <p className="text-[11px] leading-relaxed text-center"
              style={{ color: "rgba(122,231,255,0.55)" }}>
              🔒 Your finds, map pins, badges, scan history, and progress are saved to your account and restored on every sign-in.
            </p>
          </div>

          {/* Bottom info */}
          <p
            className="text-center text-xs mt-4"
            style={{ color: "rgba(255,255,255,0.18)" }}
          >
            {isSignIn ? "Don't have an account? " : "Already have an account? "}
            <button
              onClick={onBack}
              style={{ color: "rgba(167,139,250,0.5)", background: "none", border: "none", minHeight: "unset", display: "inline" }}
              className="text-xs"
            >
              {isSignIn ? "Go back" : "Sign in instead"}
            </button>
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}