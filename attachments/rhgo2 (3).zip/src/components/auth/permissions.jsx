// RBAC Permission System
export const ROLES = {
  admin: "admin",
  moderator: "moderator",
  data_analyst: "data_analyst",
  user: "user",
  viewer: "viewer",
};

const ROLE_PERMISSIONS = {
  viewer: ["sites:view"],
  user: ["sites:view", "sites:create"],
  moderator: [
    "sites:view", "sites:create", "sites:edit", "sites:verify",
    "moderation:view_queue", "moderation:resolve_flags",
  ],
  data_analyst: ["sites:view", "analytics:view", "analytics:export"],
  admin: [
    "sites:view", "sites:create", "sites:edit", "sites:delete", "sites:verify",
    "moderation:view_queue", "moderation:resolve_flags",
    "users:view", "users:edit", "users:assign_roles",
    "analytics:view", "analytics:export", "admin:settings",
  ],
};

export function getPermissions(role) {
  return ROLE_PERMISSIONS[role] || ROLE_PERMISSIONS.viewer;
}

export function hasPermission(user, permission) {
  if (!user) return false;
  return getPermissions(user.role || "user").includes(permission);
}

export const ROLE_LABELS = {
  admin: "Admin",
  moderator: "Moderator",
  data_analyst: "Data Analyst",
  user: "User",
  viewer: "Viewer",
};

export const ROLE_COLORS = {
  admin: "bg-red-500/15 text-red-400 border-red-500/25",
  moderator: "bg-purple-500/15 text-purple-400 border-purple-500/25",
  data_analyst: "bg-cyan-500/15 text-cyan-400 border-cyan-500/25",
  user: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  viewer: "bg-white/10 text-white/50 border-white/15",
};

/**
 * Combined role + subscription check helper.
 * Usage: canAccess(user, { role: "moderator" }) or canAccess(user, { tier: "crystal" })
 */
export function canAccess(user, { role, tier } = {}) {
  if (!user) return false;
  if (role && !hasPermission(user, role)) return false;
  // Tier check deferred to entitlements module — this is just role-based
  return true;
}