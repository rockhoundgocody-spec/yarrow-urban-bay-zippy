/**
 * FloatingStartMenu — cinematic title + start menu overlay.
 * First thing users see. No auth form visible here.
 */
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LogIn, UserPlus, Eye } from "lucide-react";

const MENU_ITEMS = [
  {
    id: "demo",
    label: "🔥 Try Full Demo (No Sign-Up)",
    icon: Eye,
    primary: true,
    description: "Takes 8 seconds • No account needed",
  },
  {
    id: "signin",
    label: "Sign In",
    icon: LogIn,
    primary: false,
    description: "Return to your collection",
  },
  {
    id: "register",
    label: "Create Account",
    icon: UserPlus,
    primary: false,
    description: "Free forever — begin your journey",
  },
];

export default function FloatingStartMenu({ onSelectSignIn, onSelectRegister, onSelectDemo, visible = true }) {
  const [hoveredId, setHoveredId] = useState(null);
  const [titleVisible, setTitleVisible] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);

  useEffect(() => {
    if (!visible) return;
    const t1 = setTimeout(() => setTitleVisible(true), 300);
    const t2 = setTimeout(() => setMenuVisible(true), 900);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [visible]);

  const handleSelect = (id) => {
    if (id === "signin") onSelectSignIn();
    else if (id === "register") onSelectRegister();
    else if (id === "demo") onSelectDemo();
  };

  return (
    <div className="min-h-full flex flex-col items-center justify-between pointer-events-none" style={{ zIndex: 20 }}>

      {/* ── Title block ── */}
      <AnimatePresence>
        {titleVisible && (
          <motion.div
            className="flex flex-col items-center text-center mt-16 px-6 pointer-events-none"
            initial={{ opacity: 0, y: -24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.1, ease: [0.23, 1, 0.32, 1] }}
          >
            {/* Logo image */}
            <div className="w-20 h-20 rounded-2xl overflow-hidden mb-5 shadow-lg" style={{ boxShadow: "0 0 40px rgba(167,139,250,0.35), 0 0 80px rgba(125,211,252,0.12)" }}>
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/699b620aabda6503e72aa4f2/b4bbf8913_20260221_213444-IMG_STYLE.jpg"
                alt="RockHound-GO"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Title */}
            <h1
              className="font-black uppercase tracking-wider mb-2"
              style={{
                fontSize: "clamp(2rem, 8vw, 3.2rem)",
                letterSpacing: "0.08em",
                background: "linear-gradient(135deg, #fbbf24 0%, #c4b5fd 45%, #7dd3fc 80%, #fbbf24 100%)",
                backgroundSize: "200% 200%",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
                animation: "rhTitleGold 6s ease infinite",
                filter: "drop-shadow(0 0 20px rgba(167,139,250,0.4))",
              }}
            >
              ROCKHOUND<span style={{ WebkitTextFillColor: "transparent" }}>-GO</span>
            </h1>

            <style>{`
              @keyframes rhTitleGold {
                0%  { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100%{ background-position: 0% 50%; }
              }
            `}</style>

            {/* Hero tagline */}
            <p
              className="text-sm font-bold leading-snug text-center mb-2 px-2"
              style={{ color: "rgba(255,255,255,0.85)", maxWidth: 300, fontSize: 13 }}
            >
              The only Rockhounding OS that finds rocks → IDs them with AI → builds your collection while you're still muddy 🔥
            </p>
            <p
              className="text-xs font-semibold tracking-widest uppercase mb-1"
              style={{ color: "rgba(167,139,250,0.8)", letterSpacing: "0.22em" }}
            >
              Discover · Scan · Collect
            </p>
            <p
              className="text-xs font-medium"
              style={{ color: "rgba(125,211,252,0.5)", maxWidth: 260, textAlign: "center" }}
            >
              Used by rockhounds in 47 states · Built in Illinois
            </p>

            {/* Spectral divider */}
            <div className="mt-4 flex items-center gap-3">
              <div style={{ width: 40, height: 1, background: "linear-gradient(90deg, transparent, rgba(167,139,250,0.5))" }} />
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#a78bfa", boxShadow: "0 0 10px #a78bfa" }} />
              <div style={{ width: 40, height: 1, background: "linear-gradient(90deg, rgba(167,139,250,0.5), transparent)" }} />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Floating Start Menu ── */}
      <AnimatePresence>
        {menuVisible && (
          <motion.div
            className="w-full max-w-sm mx-auto mb-10 px-5 pointer-events-auto"
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.23, 1, 0.32, 1] }}
          >
            {/* Glass container */}
            <div
              className="rounded-3xl p-5 flex flex-col gap-3 relative"
              style={{
                background: "linear-gradient(145deg, rgba(10,5,25,0.82) 0%, rgba(15,10,35,0.78) 100%)",
                border: "1px solid rgba(167,139,250,0.2)",
                backdropFilter: "blur(24px)",
                WebkitBackdropFilter: "blur(24px)",
                boxShadow: "0 8px 64px rgba(0,0,0,0.7), inset 0 1px 0 rgba(167,139,250,0.12), 0 0 40px rgba(124,58,237,0.08)",
              }}
            >
              {/* Spectral top accent line */}
              <div
                className="absolute top-0 inset-x-4 h-px rounded-full"
                style={{ background: "linear-gradient(90deg, transparent, rgba(167,139,250,0.6), rgba(125,211,252,0.4), transparent)" }}
              />

              {MENU_ITEMS.map((item, idx) => {
                const Icon = item.icon;
                const isPrimary = item.primary;
                const isHovered = hoveredId === item.id;

                return (
                  <motion.button
                    key={item.id}
                    onClick={() => handleSelect(item.id)}
                    onMouseEnter={() => setHoveredId(item.id)}
                    onMouseLeave={() => setHoveredId(null)}
                    className="relative w-full flex items-center gap-4 rounded-2xl transition-all duration-300 overflow-hidden"
                    style={{
                      minHeight: 60,
                      padding: "14px 18px",
                      background: isPrimary
                        ? isHovered
                          ? "linear-gradient(135deg, rgba(251,191,36,0.22) 0%, rgba(167,139,250,0.18) 100%)"
                          : "linear-gradient(135deg, rgba(251,191,36,0.15) 0%, rgba(167,139,250,0.12) 100%)"
                        : isHovered
                          ? "rgba(167,139,250,0.1)"
                          : "rgba(255,255,255,0.04)",
                      border: isPrimary
                        ? `1px solid ${isHovered ? "rgba(251,191,36,0.5)" : "rgba(251,191,36,0.3)"}`
                        : `1px solid ${isHovered ? "rgba(167,139,250,0.35)" : "rgba(255,255,255,0.08)"}`,
                      boxShadow: isPrimary && isHovered
                        ? "0 0 24px rgba(251,191,36,0.15), inset 0 1px 0 rgba(251,191,36,0.15)"
                        : isHovered
                          ? "0 0 16px rgba(167,139,250,0.1)"
                          : "none",
                    }}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 + 0.2, duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
                    whileTap={{ scale: 0.97 }}
                  >
                    {/* Shimmer on tap */}
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        background: "linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.06) 50%, transparent 100%)",
                        opacity: isHovered ? 1 : 0,
                        transition: "opacity 0.3s ease",
                      }}
                    />

                    {/* Icon */}
                    <div
                      className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{
                        background: isPrimary
                          ? "rgba(251,191,36,0.15)"
                          : "rgba(167,139,250,0.1)",
                        border: isPrimary
                          ? "1px solid rgba(251,191,36,0.3)"
                          : "1px solid rgba(167,139,250,0.2)",
                      }}
                    >
                      <Icon
                        className="w-5 h-5"
                        style={{ color: isPrimary ? "#fbbf24" : "#a78bfa" }}
                      />
                    </div>

                    {/* Label + description */}
                    <div className="flex flex-col items-start">
                      <span
                        className="font-bold text-sm tracking-wide"
                        style={{ color: isPrimary ? "#fbbf24" : "rgba(255,255,255,0.88)" }}
                      >
                        {item.label}
                      </span>
                      <span
                        className="text-xs"
                        style={{ color: isPrimary ? "rgba(251,191,36,0.55)" : "rgba(167,139,250,0.5)" }}
                      >
                        {item.description}
                      </span>
                    </div>

                    {/* Right chevron */}
                    <div className="ml-auto">
                      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                        <path d="M6 4l4 4-4 4" stroke={isPrimary ? "#fbbf24" : "rgba(167,139,250,0.5)"} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                      </svg>
                    </div>
                  </motion.button>
                );
              })}

              {/* Trust line */}
              <p className="text-center text-[11px] mt-1 leading-relaxed px-2"
                style={{ color: "rgba(122,231,255,0.40)" }}>
                🔒 Free to try · Your finds, badges &amp; XP save to your account
              </p>
              <p className="text-center text-[10px] mt-0.5" style={{ color: "rgba(167,139,250,0.25)" }}>
                AI Mineral ID + Maps + Collections · Free Demo
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}