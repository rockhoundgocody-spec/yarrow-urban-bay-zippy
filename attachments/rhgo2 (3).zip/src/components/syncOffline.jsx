/**
 * Legacy shim — delegates to SyncEngine.processQueue.
 * Kept for backward compat; prefer startNetworkMonitor() from SyncEngine.
 */
import { processQueue } from "./offline/SyncEngine";

export async function syncOffline() {
  const result = await processQueue();
  return { ok: true, synced: result?.synced ?? 0 };
}