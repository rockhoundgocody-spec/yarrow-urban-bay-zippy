/**
 * ProvenanceLedgerPanel — Immutable append-only provenance timeline.
 * Shows structured events for a specimen with tamper-evident presentation.
 */
import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  MapPin, Camera, FlaskConical, DollarSign, ShoppingBag, ArrowRightLeft,
  ShieldCheck, StickyNote, Image, User, CheckCircle2, Lock, Plus, Upload, Loader2
} from "lucide-react";
import { base44 } from "@/api/base44Client";

const EVENT_META = {
  found_in_field:       { icon: MapPin,          color: "#00D68F", label: "Found in Field" },
  scanned:              { icon: Camera,          color: "#7AE7FF", label: "AI Scan" },
  re_identified:        { icon: Camera,          color: "#a78bfa", label: "Re-identified" },
  lab_report_attached:  { icon: FlaskConical,    color: "#F5B642", label: "Lab Report" },
  valuation_updated:    { icon: DollarSign,      color: "#4ade80", label: "Valuation Updated" },
  listed_for_sale:      { icon: ShoppingBag,     color: "#fb923c", label: "Listed for Sale" },
  sold:                 { icon: ShoppingBag,     color: "#f87171", label: "Sold" },
  transferred:          { icon: ArrowRightLeft,  color: "#c084fc", label: "Ownership Transfer" },
  verified:             { icon: ShieldCheck,     color: "#00D68F", label: "Verified" },
  note_added:           { icon: StickyNote,      color: "#94a3b8", label: "Note Added" },
  photo_added:          { icon: Image,           color: "#7AE7FF", label: "Photo Added" },
  ownership_claimed:    { icon: User,            color: "#F5B642", label: "Ownership Claimed" },
};

function EventNode({ event, index, isLast }) {
  const meta = EVENT_META[event.event_type] || { icon: StickyNote, color: "#94a3b8", label: event.event_type };
  const Icon = meta.icon;
  const ts = event.created_date ? new Date(event.created_date) : null;

  return (
    <motion.div
      initial={{ opacity: 0, x: -12 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.04, duration: 0.25 }}
      className="flex gap-3"
    >
      {/* Timeline spine */}
      <div className="flex flex-col items-center" style={{ width: 32, flexShrink: 0 }}>
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 z-10"
          style={{ background: `${meta.color}18`, border: `1.5px solid ${meta.color}50`, boxShadow: `0 0 10px ${meta.color}22` }}
        >
          <Icon style={{ width: 14, height: 14, color: meta.color }} />
        </div>
        {!isLast && <div className="w-px flex-1 mt-1" style={{ background: "rgba(255,255,255,0.07)", minHeight: 20 }} />}
      </div>

      {/* Event card */}
      <div className="pb-4 flex-1 min-w-0">
        <div
          className="rounded-2xl px-4 py-3"
          style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div>
              <span className="text-sm font-semibold" style={{ color: meta.color }}>{meta.label}</span>
              {event.actor_display && (
                <span className="text-xs text-white/30 ml-2">by {event.actor_display}</span>
              )}
            </div>
            <div className="flex items-center gap-1.5">
              {event.is_verified && (
                <CheckCircle2 style={{ width: 12, height: 12, color: "#00D68F" }} />
              )}
              {ts && (
                <span className="text-[10px] text-white/30 font-mono tabular-nums">
                  {ts.toLocaleDateString()} {ts.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </span>
              )}
            </div>
          </div>

          {event.note && <p className="text-xs text-white/55 mt-1.5 leading-relaxed">{event.note}</p>}

          <div className="flex flex-wrap gap-3 mt-2">
            {event.locality_name && (
              <span className="text-[10px] text-white/35 flex items-center gap-1">
                <MapPin style={{ width: 10, height: 10 }} /> {event.locality_name}
              </span>
            )}
            {event.scan_confidence && (
              <span className="text-[10px] font-mono" style={{ color: "#7AE7FF" }}>
                {event.scan_confidence}% confidence
              </span>
            )}
            {(event.valuation_low || event.valuation_high) && (
              <span className="text-[10px]" style={{ color: "#4ade80" }}>
                ${event.valuation_low}–${event.valuation_high}
              </span>
            )}
          </div>

          {event.attachment_url && (
            <a
              href={event.attachment_url}
              target="_blank"
              rel="noreferrer"
              className="mt-2 flex items-center gap-1.5 text-[10px] underline underline-offset-2"
              style={{ color: "#F5B642" }}
            >
              <Upload style={{ width: 10, height: 10 }} />
              {event.attachment_label || "View Attachment"}
            </a>
          )}

          {/* Tamper-evidence hash */}
          {event.event_hash && (
            <div className="mt-2 flex items-center gap-1.5">
              <Lock style={{ width: 9, height: 9, color: "rgba(255,255,255,0.2)" }} />
              <span className="text-[9px] font-mono text-white/20 truncate">{event.event_hash}</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

function AddEventForm({ specimenId, user, onAdded }) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("note_added");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!note.trim()) return;
    setSaving(true);
    const hash = btoa(`${specimenId}:${type}:${Date.now()}`).slice(0, 20);
    await base44.entities.ProvenanceLedger.create({
      specimen_id: specimenId,
      event_type: type,
      actor_email: user?.email,
      actor_display: user?.full_name || user?.email?.split("@")[0],
      note: note.trim(),
      event_hash: hash,
    });
    setNote("");
    setOpen(false);
    setSaving(false);
    onAdded?.();
  };

  return (
    <div>
      {!open ? (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 text-xs px-4 py-2.5 rounded-xl transition-all"
          style={{ background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.22)", color: "#00D68F" }}
        >
          <Plus style={{ width: 13, height: 13 }} /> Add Provenance Event
        </button>
      ) : (
        <div className="rounded-2xl p-4 space-y-3" style={{ background: "rgba(0,214,143,0.05)", border: "1px solid rgba(0,214,143,0.2)" }}>
          <select
            value={type}
            onChange={e => setType(e.target.value)}
            className="w-full rounded-xl px-3 py-2 text-sm text-white bg-transparent outline-none"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)" }}
          >
            {Object.entries(EVENT_META).map(([k, v]) => (
              <option key={k} value={k} style={{ background: "#0a0f14" }}>{v.label}</option>
            ))}
          </select>
          <textarea
            value={note}
            onChange={e => setNote(e.target.value)}
            placeholder="Event note (required)..."
            rows={2}
            className="w-full rounded-xl px-3 py-2 text-sm text-white resize-none outline-none"
            style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.12)" }}
          />
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={saving || !note.trim()}
              className="flex items-center gap-1.5 text-xs px-4 py-2 rounded-xl font-semibold transition-all disabled:opacity-50"
              style={{ background: "rgba(0,214,143,0.18)", border: "1px solid rgba(0,214,143,0.3)", color: "#00D68F" }}
            >
              {saving ? <Loader2 style={{ width: 12, height: 12 }} className="animate-spin" /> : null}
              {saving ? "Saving…" : "Append Event"}
            </button>
            <button onClick={() => setOpen(false)} className="text-xs px-3 py-2 rounded-xl text-white/40 hover:text-white/60">Cancel</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ProvenanceLedgerPanel({ specimenId, user }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const items = await base44.entities.ProvenanceLedger.filter({ specimen_id: specimenId }, "-created_date", 50);
    // Sort ascending for timeline
    setEvents([...items].reverse());
    setLoading(false);
  };

  useEffect(() => { if (specimenId) load(); }, [specimenId]);

  // Trust score based on event count + verification
  const verifiedCount = events.filter(e => e.is_verified).length;
  const trustScore = Math.min(100, events.length * 12 + verifiedCount * 20);
  const trustLabel = trustScore >= 80 ? "High Provenance" : trustScore >= 40 ? "Partial Provenance" : "Minimal Provenance";
  const trustColor = trustScore >= 80 ? "#00D68F" : trustScore >= 40 ? "#F5B642" : "#94a3b8";

  return (
    <div className="space-y-4">
      {/* Certificate-style trust view */}
      <div className="rounded-2xl overflow-hidden"
        style={{ border: `1.5px solid ${trustColor}35`, boxShadow: `0 0 32px ${trustColor}10` }}>
        {/* Certificate header bar */}
        <div className="px-5 py-3 flex items-center justify-between"
          style={{ background: `linear-gradient(135deg, ${trustColor}22, ${trustColor}0A)`, borderBottom: `1px solid ${trustColor}20` }}>
          <div className="flex items-center gap-2">
            <ShieldCheck style={{ width: 16, height: 16, color: trustColor }} />
            <span className="text-[10px] font-black uppercase tracking-[0.2em]" style={{ color: trustColor }}>Provenance Certificate</span>
          </div>
          <Lock style={{ width: 12, height: 12, color: `${trustColor}60` }} />
        </div>

        {/* Certificate body */}
        <div className="px-5 py-4" style={{ background: "rgba(5,7,10,0.85)" }}>
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-xl font-black" style={{ color: trustColor }}>{trustLabel}</div>
              <div className="text-[10px] text-white/35 mt-0.5">{events.length} ledger entries · {verifiedCount} verified</div>
            </div>
            {/* Trust score ring */}
            <div className="relative w-14 h-14 flex items-center justify-center">
              <svg className="absolute inset-0" viewBox="0 0 56 56">
                <circle cx="28" cy="28" r="24" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="4" />
                <circle cx="28" cy="28" r="24" fill="none" stroke={trustColor} strokeWidth="4"
                  strokeDasharray={`${(trustScore / 100) * 150.8} 150.8`}
                  strokeLinecap="round" transform="rotate(-90 28 28)" style={{ opacity: 0.85 }} />
              </svg>
              <span className="text-sm font-black" style={{ color: trustColor }}>{trustScore}</span>
            </div>
          </div>

          {/* Authenticity markers */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: "Events", value: events.length, ok: events.length > 0 },
              { label: "Verified", value: verifiedCount, ok: verifiedCount > 0 },
              { label: "Score", value: `${trustScore}/100`, ok: trustScore >= 40 },
            ].map(({ label, value, ok }) => (
              <div key={label} className="rounded-xl px-3 py-2 text-center"
                style={{ background: ok ? `${trustColor}0D` : "rgba(255,255,255,0.03)", border: `1px solid ${ok ? trustColor + "25" : "rgba(255,255,255,0.07)"}` }}>
                <div className="text-base font-black" style={{ color: ok ? trustColor : "#94a3b8" }}>{value}</div>
                <div className="text-[9px] font-semibold uppercase tracking-widest mt-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Certificate footer */}
        <div className="px-5 py-2.5 flex items-center gap-2"
          style={{ background: "rgba(255,255,255,0.02)", borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          <Lock style={{ width: 10, height: 10, color: "rgba(255,255,255,0.2)" }} />
          <span className="text-[9px] text-white/20 font-mono">Append-only · tamper-evident · immutable ledger</span>
        </div>
      </div>

      {/* Timeline */}
      {loading ? (
        <div className="flex items-center gap-2 py-6 justify-center text-white/30">
          <Loader2 style={{ width: 16, height: 16 }} className="animate-spin" />
          <span className="text-sm">Loading ledger…</span>
        </div>
      ) : events.length === 0 ? (
        <div className="py-6 text-center text-white/25 text-sm">No provenance events recorded yet.</div>
      ) : (
        <div className="pt-2">
          {events.map((event, i) => (
            <EventNode key={event.id} event={event} index={i} isLast={i === events.length - 1} />
          ))}
        </div>
      )}

      {user && <AddEventForm specimenId={specimenId} user={user} onAdded={load} />}
    </div>
  );
}