/**
 * ProvenanceCertificate — Certificate-style tamper-resistant provenance timeline.
 * Append-only chain: Discovery → Scan → Lab → Ownership → Valuation
 * Renders as a printable trust certificate with SHA-style event hashes.
 */
import React, { useEffect, useState } from "react";
import { base44 } from "@/api/base44Client";
import {
  Shield, MapPin, Microscope, FlaskConical, User, DollarSign,
  CheckCircle2, Clock, Hash, Award, ChevronDown, ChevronUp, Loader2
} from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";

const EVENT_META = {
  found_in_field:      { icon: MapPin,       color: "#00D68F", label: "Field Discovery",       tier: 1 },
  scanned:             { icon: Microscope,   color: "#7AE7FF", label: "AI Scan",                tier: 2 },
  re_identified:       { icon: Microscope,   color: "#7AE7FF", label: "Re-Identified",          tier: 2 },
  lab_report_attached: { icon: FlaskConical, color: "#8D7CFF", label: "Lab Report",             tier: 3 },
  verified:            { icon: CheckCircle2, color: "#00D68F", label: "Expert Verified",         tier: 3 },
  valuation_updated:   { icon: DollarSign,   color: "#F5B642", label: "Valuation Update",       tier: 4 },
  listed_for_sale:     { icon: DollarSign,   color: "#F5B642", label: "Listed for Sale",        tier: 4 },
  sold:                { icon: Award,         color: "#F5B642", label: "Sold",                   tier: 4 },
  transferred:         { icon: User,          color: "#8D7CFF", label: "Ownership Transfer",    tier: 4 },
  ownership_claimed:   { icon: User,          color: "#8D7CFF", label: "Ownership Claimed",     tier: 4 },
  photo_added:         { icon: Microscope,   color: "#7AE7FF", label: "Photo Added",            tier: 2 },
  note_added:          { icon: Hash,          color: "rgba(255,255,255,0.4)", label: "Note",    tier: 5 },
};

function hashSnippet(str) {
  // Deterministic short hash for display — NOT cryptographic, just tamper-evidence UI hint
  if (!str) return "0x000000";
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = (h * 0x01000193) >>> 0; }
  return "0x" + h.toString(16).padStart(8, "0").toUpperCase();
}

function EventNode({ event, index, isLast }) {
  const [expanded, setExpanded] = useState(false);
  const meta = EVENT_META[event.event_type] || { icon: Hash, color: "rgba(255,255,255,0.3)", label: event.event_type };
  const Icon = meta.icon;
  const hash = event.event_hash || hashSnippet(event.id + event.event_type + (event.actor_email || ""));

  return (
    <div className="flex gap-3">
      {/* Timeline spine */}
      <div className="flex flex-col items-center flex-shrink-0">
        <div className="w-8 h-8 rounded-full flex items-center justify-center z-10"
          style={{ background: `${meta.color}18`, border: `1.5px solid ${meta.color}55`, boxShadow: `0 0 12px ${meta.color}25` }}>
          <Icon className="w-3.5 h-3.5" style={{ color: meta.color }} />
        </div>
        {!isLast && <div className="w-px flex-1 mt-1" style={{ background: "rgba(255,255,255,0.07)", minHeight: 20 }} />}
      </div>

      {/* Event body */}
      <div className="flex-1 pb-4 min-w-0">
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full text-left rounded-xl px-3 py-2.5 transition-all"
          style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${expanded ? meta.color + "30" : "rgba(255,255,255,0.07)"}` }}>
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-xs font-bold" style={{ color: meta.color }}>{meta.label}</span>
              {event.is_verified && (
                <span className="flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                  style={{ background: "rgba(0,214,143,0.12)", color: "#00D68F", border: "1px solid rgba(0,214,143,0.25)" }}>
                  <CheckCircle2 className="w-2.5 h-2.5" /> Verified
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <span className="text-[9px]" style={{ color: "rgba(255,255,255,0.25)" }}>
                {formatDistanceToNow(new Date(event.created_date), { addSuffix: true })}
              </span>
              {expanded ? <ChevronUp className="w-3 h-3 text-white/20" /> : <ChevronDown className="w-3 h-3 text-white/20" />}
            </div>
          </div>
        </button>

        {expanded && (
          <div className="mt-1 px-3 py-2.5 rounded-xl space-y-2"
            style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)" }}>
            {event.actor_display && (
              <div className="flex items-center gap-2">
                <User className="w-3 h-3 text-white/30" />
                <span className="text-[11px] text-white/55">{event.actor_display}</span>
              </div>
            )}
            {event.note && (
              <p className="text-[11px] text-white/60 leading-relaxed">{event.note}</p>
            )}
            {event.locality_name && (
              <div className="flex items-center gap-2">
                <MapPin className="w-3 h-3 text-white/30" />
                <span className="text-[11px] text-white/45">{event.locality_name}</span>
              </div>
            )}
            {(event.valuation_low || event.valuation_high) && (
              <div className="text-[11px] font-bold" style={{ color: "#F5B642" }}>
                ${event.valuation_low ?? "?"} – ${event.valuation_high ?? "?"} USD
              </div>
            )}
            {event.scan_confidence && (
              <div className="text-[11px]" style={{ color: "#7AE7FF" }}>
                AI Confidence: {Math.round(event.scan_confidence)}%
              </div>
            )}
            {event.attachment_url && (
              <a href={event.attachment_url} target="_blank" rel="noopener noreferrer"
                className="text-[11px] underline" style={{ color: "#8D7CFF" }}>
                {event.attachment_label || "View Attachment"}
              </a>
            )}
            {/* Tamper-evidence hash */}
            <div className="flex items-center gap-1.5 mt-1 pt-2 border-t border-white/5">
              <Hash className="w-2.5 h-2.5 text-white/20" />
              <span className="font-mono text-[9px] text-white/20">{hash}</span>
              <span className="text-[9px] text-white/15">·</span>
              <span className="text-[9px] text-white/20">{format(new Date(event.created_date), "yyyy-MM-dd HH:mm:ss")}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function TrustScore({ events }) {
  const verifiedCount = events.filter(e => e.is_verified).length;
  const hasLab = events.some(e => e.event_type === "lab_report_attached");
  const hasScan = events.some(e => e.event_type === "scanned" || e.event_type === "re_identified");
  const hasDiscovery = events.some(e => e.event_type === "found_in_field");

  const score = Math.min(100,
    (hasDiscovery ? 25 : 0) +
    (hasScan ? 20 : 0) +
    (hasLab ? 30 : 0) +
    (verifiedCount * 10) +
    (events.length * 2)
  );

  const tier = score >= 80 ? { label: "High Trust", color: "#00D68F" }
    : score >= 50 ? { label: "Moderate Trust", color: "#F5B642" }
    : { label: "Minimal Record", color: "rgba(255,255,255,0.35)" };

  return (
    <div className="rounded-2xl p-4 mb-4"
      style={{ background: `linear-gradient(135deg, ${tier.color}10, ${tier.color}05)`, border: `1px solid ${tier.color}30` }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4" style={{ color: tier.color }} />
          <span className="text-xs font-black uppercase tracking-widest" style={{ color: tier.color }}>
            Provenance Certificate
          </span>
        </div>
        <div className="text-right">
          <div className="text-2xl font-black" style={{ color: tier.color }}>{score}</div>
          <div className="text-[9px] font-bold" style={{ color: `${tier.color}80` }}>TRUST SCORE</div>
        </div>
      </div>

      {/* Score bar */}
      <div className="h-1.5 rounded-full w-full mb-2" style={{ background: "rgba(255,255,255,0.08)" }}>
        <div className="h-full rounded-full transition-all duration-700"
          style={{ width: `${score}%`, background: `linear-gradient(90deg, ${tier.color}88, ${tier.color})` }} />
      </div>

      {/* Trust factors */}
      <div className="flex flex-wrap gap-2 mt-3">
        {[
          { label: "Field Discovery", ok: hasDiscovery },
          { label: "AI Scanned", ok: hasScan },
          { label: "Lab Report", ok: hasLab },
          { label: `${verifiedCount} Verified`, ok: verifiedCount > 0 },
          { label: `${events.length} Events`, ok: events.length > 0 },
        ].map(({ label, ok }) => (
          <span key={label} className="flex items-center gap-1 text-[9px] font-semibold px-2 py-0.5 rounded-full"
            style={{
              background: ok ? "rgba(0,214,143,0.10)" : "rgba(255,255,255,0.04)",
              border: ok ? "1px solid rgba(0,214,143,0.25)" : "1px solid rgba(255,255,255,0.08)",
              color: ok ? "#00D68F" : "rgba(255,255,255,0.25)",
            }}>
            {ok ? <CheckCircle2 className="w-2.5 h-2.5" /> : <Clock className="w-2.5 h-2.5" />}
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}

export default function ProvenanceCertificate({ specimenId }) {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!specimenId) return;
    base44.entities.ProvenanceLedger.filter({ specimen_id: specimenId }, "created_date", 100)
      .then(setEvents)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [specimenId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-10">
        <Loader2 className="w-6 h-6 animate-spin" style={{ color: "#00D68F" }} />
      </div>
    );
  }

  return (
    <div>
      <TrustScore events={events} />

      {events.length === 0 ? (
        <div className="text-center py-8">
          <Shield className="w-10 h-10 mx-auto mb-3" style={{ color: "rgba(255,255,255,0.12)" }} />
          <p className="text-sm text-white/30">No provenance events recorded yet.</p>
          <p className="text-xs mt-1 text-white/20">Events are logged automatically during scanning and verification.</p>
        </div>
      ) : (
        <div className="relative">
          {events.map((event, i) => (
            <EventNode key={event.id} event={event} index={i} isLast={i === events.length - 1} />
          ))}
        </div>
      )}
    </div>
  );
}