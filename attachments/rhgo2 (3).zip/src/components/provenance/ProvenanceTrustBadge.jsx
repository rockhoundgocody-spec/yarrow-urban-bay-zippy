/**
 * ProvenanceTrustBadge — compact inline trust/authenticity indicator.
 * Used on marketplace cards, collection items, and detail modals.
 */
import React, { useEffect, useState } from "react";
import { ShieldCheck, ShieldAlert, Shield } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function ProvenanceTrustBadge({ specimenId, compact = false }) {
  const [data, setData] = useState(null);

  useEffect(() => {
    if (!specimenId) return;
    base44.entities.ProvenanceLedger.filter({ specimen_id: specimenId }, "-created_date", 20)
      .then(events => {
        const count = events.length;
        const verified = events.filter(e => e.is_verified).length;
        const score = Math.min(100, count * 12 + verified * 20);
        setData({ count, verified, score });
      })
      .catch(() => {});
  }, [specimenId]);

  if (!data) return null;

  const { score, count, verified } = data;
  const high = score >= 70;
  const mid = score >= 35;
  const color = high ? "#00D68F" : mid ? "#F5B642" : "#6b7280";
  const label = high ? "Verified Provenance" : mid ? "Partial Provenance" : "Minimal History";
  const Icon = high ? ShieldCheck : mid ? ShieldAlert : Shield;

  if (compact) {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.5 rounded-full"
        style={{ background: `${color}15`, border: `1px solid ${color}35`, color }}>
        <Icon style={{ width: 9, height: 9 }} />
        {count} events
      </span>
    );
  }

  return (
    <div className="flex items-center gap-2.5 px-3 py-2 rounded-xl"
      style={{ background: `${color}0D`, border: `1px solid ${color}28` }}>
      <Icon style={{ width: 16, height: 16, color }} />
      <div>
        <div className="text-xs font-bold" style={{ color }}>{label}</div>
        <div className="text-[10px] text-white/35">{count} events recorded · {verified} verified</div>
      </div>
      <div className="ml-auto text-lg font-black" style={{ color, opacity: 0.8 }}>{score}</div>
    </div>
  );
}