import React, { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Users, Plus } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import CreateGuildEventDialog from "./CreateGuildEventDialog";

export default function GuildEventList({ guildId, events = [] }) {
  const [showCreate, setShowCreate] = useState(false);

  const upcomingEvents = events.filter(e => e.status === 'upcoming').slice(0, 5);
  const pastEvents = events.filter(e => e.status === 'completed').slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button onClick={() => setShowCreate(true)} className="bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30">
          <Plus className="w-4 h-4 mr-1.5" /> New Event
        </Button>
      </div>

      {upcomingEvents.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-white mb-3">Upcoming Events</h3>
          <div className="space-y-3">
            {upcomingEvents.map(event => (
              <Card key={event.id} className="bg-[#14141e] border-white/5 p-4">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-medium text-white">{event.title}</h4>
                      <Badge className="text-[10px] bg-cyan-500/20 text-cyan-300 border-cyan-500/30 capitalize">{event.event_type}</Badge>
                    </div>
                    <p className="text-xs text-white/50 mb-3">{event.description}</p>
                    <div className="flex flex-wrap gap-3 text-xs text-white/40">
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {new Date(event.start_date).toLocaleDateString()}</span>
                      {event.location && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {event.location}</span>}
                      {event.max_participants && <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {event.participants?.length || 0}/{event.max_participants}</span>}
                    </div>
                  </div>
                  <Button size="sm" variant="outline" className="border-white/10 text-white/60 shrink-0">
                    Join
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {pastEvents.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-white mb-3">Past Events</h3>
          <div className="space-y-2">
            {pastEvents.map(event => (
              <Card key={event.id} className="bg-[#14141e] border-white/5 p-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm text-white">{event.title}</p>
                    <p className="text-xs text-white/40 mt-0.5">{formatDistanceToNow(new Date(event.start_date), { addSuffix: true })}</p>
                  </div>
                  <Badge className="text-[10px] bg-green-500/20 text-green-300 border-green-500/30">Completed</Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {events.length === 0 && (
        <div className="text-center py-12 text-white/30">No events scheduled yet</div>
      )}

      <CreateGuildEventDialog guildId={guildId} open={showCreate} onOpenChange={setShowCreate} />
    </div>
  );
}