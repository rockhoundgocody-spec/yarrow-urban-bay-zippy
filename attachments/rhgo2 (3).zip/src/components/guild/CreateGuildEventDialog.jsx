import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function CreateGuildEventDialog({ guildId, open, onOpenChange }) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    event_type: "field_trip",
    location: "",
    start_date: "",
    max_participants: "",
    xp_reward: "100",
  });
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.GuildEvent.create({
      ...data,
      guild_id: guildId,
      participants: [],
      max_participants: data.max_participants ? parseInt(data.max_participants) : null,
      xp_reward: parseInt(data.xp_reward),
      status: "upcoming",
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guild-events"] });
      setFormData({ title: "", description: "", event_type: "field_trip", location: "", start_date: "", max_participants: "", xp_reward: "100" });
      onOpenChange(false);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title.trim() || !formData.start_date) return;
    mutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Guild Event</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-xs text-white/60">Event Title *</Label>
            <Input
              placeholder="e.g., Crystal Hunting Expedition"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Event Type</Label>
            <Select value={formData.event_type} onValueChange={(v) => setFormData({ ...formData, event_type: v })}>
              <SelectTrigger className="bg-[#0a0a0f] border-white/10 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="field_trip">Field Trip</SelectItem>
                <SelectItem value="competition">Competition</SelectItem>
                <SelectItem value="workshop">Workshop</SelectItem>
                <SelectItem value="social">Social</SelectItem>
                <SelectItem value="challenge">Challenge</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-xs text-white/60">Description</Label>
            <Textarea
              placeholder="Describe the event..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1 h-20"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Location</Label>
            <Input
              placeholder="e.g., Crystal Cave, Colorado"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Start Date & Time *</Label>
            <Input
              type="datetime-local"
              value={formData.start_date}
              onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs text-white/60">Max Participants</Label>
              <Input
                type="number"
                placeholder="Leave empty for unlimited"
                value={formData.max_participants}
                onChange={(e) => setFormData({ ...formData, max_participants: e.target.value })}
                className="bg-[#0a0a0f] border-white/10 text-white mt-1"
              />
            </div>
            <div>
              <Label className="text-xs text-white/60">XP Reward</Label>
              <Input
                type="number"
                value={formData.xp_reward}
                onChange={(e) => setFormData({ ...formData, xp_reward: e.target.value })}
                className="bg-[#0a0a0f] border-white/10 text-white mt-1"
              />
            </div>
          </div>

          <div className="flex gap-2 justify-end pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-white/10 text-white/60">
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !formData.title.trim() || !formData.start_date} className="bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30">
              {mutation.isPending ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : null}
              Create Event
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}