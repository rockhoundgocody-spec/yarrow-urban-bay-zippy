import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Loader2, Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import GuildCard from "./GuildCard";
import CreateGuildDialog from "./CreateGuildDialog";

export default function GuildBrowser({ onSelectGuild }) {
  const [search, setSearch] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const [showDetail, setShowDetail] = useState(false);
  const [selectedGuild, setSelectedGuild] = useState(null);
  const queryClient = useQueryClient();

  const { data: currentUser } = useQuery({
    queryKey: ["me"],
    queryFn: () => base44.auth.me(),
    retry: false,
  });

  const { data: guilds = [], isLoading } = useQuery({
    queryKey: ["guilds"],
    queryFn: () => base44.entities.Guild.list("-member_count", 100),
  });

  const joinGuildMutation = useMutation({
    mutationFn: async (guildId) => {
      const guild = await base44.entities.Guild.filter({ id: guildId }).then(res => res[0]);
      const newMembers = [...(guild.members || []), currentUser.email];
      return base44.entities.Guild.update(guildId, { 
        members: newMembers, 
        member_count: newMembers.length 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guilds"] });
    },
  });

  const filtered = guilds.filter(g => 
    g.name.toLowerCase().includes(search.toLowerCase()) ||
    g.description?.toLowerCase().includes(search.toLowerCase())
  );

  const userGuilds = guilds.filter(g => g.members?.includes(currentUser?.email));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
          <Input
            placeholder="Search guilds..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-[#14141e] border-white/10 text-white placeholder:text-white/30"
          />
        </div>
        <Button onClick={() => setShowCreate(true)} className="bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30 shrink-0">
          <Plus className="w-4 h-4 mr-1.5" /> Create
        </Button>
      </div>

      {currentUser && userGuilds.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-white mb-3">My Guilds</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {userGuilds.map(g => (
              <GuildCard 
                key={g.id} 
                guild={g} 
                onSelect={() => { setSelectedGuild(g); onSelectGuild?.(g); }}
                isMember={true}
              />
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="text-sm font-semibold text-white mb-3">Discover Guilds</h3>
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 text-white/30">
            {search ? "No guilds match your search" : "No guilds available"}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filtered.map(g => (
              <GuildCard
                key={g.id}
                guild={g}
                onSelect={() => { setSelectedGuild(g); onSelectGuild?.(g); }}
                onJoin={() => joinGuildMutation.mutate(g.id)}
                isMember={g.members?.includes(currentUser?.email)}
              />
            ))}
          </div>
        )}
      </div>

      <CreateGuildDialog open={showCreate} onOpenChange={setShowCreate} />
    </div>
  );
}