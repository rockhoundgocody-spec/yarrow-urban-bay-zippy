import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Users, Zap, MapPin } from "lucide-react";
import GuildEventList from "./GuildEventList";
import GuildDiscoveryFeed from "./GuildDiscoveryFeed";
import GuildLeaderboard from "./GuildLeaderboard";

export default function GuildDetail({ guild }) {
  const { data: events = [], isLoading: eventsLoading } = useQuery({
    queryKey: ["guild-events", guild?.id],
    enabled: !!guild?.id,
    queryFn: () => base44.entities.GuildEvent.filter({ guild_id: guild.id }, "-start_date"),
  });

  const { data: discoveries = [], isLoading: discoveriesLoading } = useQuery({
    queryKey: ["guild-discoveries", guild?.id],
    enabled: !!guild?.id,
    queryFn: () => base44.entities.GuildDiscovery.filter({ guild_id: guild.id }, "-created_date"),
  });

  if (!guild) return null;

  return (
    <div className="space-y-6">
      {/* Guild Header */}
      <Card className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border-white/10 overflow-hidden">
        {guild.banner_url && (
          <div className="h-32 bg-cover bg-center" style={{ backgroundImage: `url(${guild.banner_url})` }} />
        )}
        <div className="p-6">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl font-bold text-white">{guild.name}</h2>
                {guild.icon_url && <img src={guild.icon_url} alt={guild.name} className="w-12 h-12 rounded-lg" />}
              </div>
              {guild.tagline && <p className="text-sm text-white/60 mb-2">{guild.tagline}</p>}
              <p className="text-white/40 text-sm mb-4">{guild.description}</p>
              
              <div className="flex flex-wrap gap-4">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-white/40" />
                  <span className="text-sm text-white/60">{guild.member_count} members</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <span className="text-sm text-white/60">{guild.total_guild_xp} XP</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-white/40" />
                  <span className="text-sm text-white/60">{guild.total_discoveries} discoveries</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="discoveries">
        <TabsList className="bg-white/5 border-white/10">
          <TabsTrigger value="discoveries">Discoveries</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="discoveries" className="mt-4">
          {discoveriesLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
            </div>
          ) : discoveries.length === 0 ? (
            <div className="text-center py-12 text-white/30">No discoveries yet</div>
          ) : (
            <GuildDiscoveryFeed discoveries={discoveries} />
          )}
        </TabsContent>

        <TabsContent value="events" className="mt-4">
          {eventsLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
            </div>
          ) : (
            <GuildEventList guildId={guild.id} events={events} />
          )}
        </TabsContent>

        <TabsContent value="leaderboard" className="mt-4">
          <GuildLeaderboard guildId={guild.id} guildMembers={guild.members} />
        </TabsContent>
      </Tabs>
    </div>
  );
}