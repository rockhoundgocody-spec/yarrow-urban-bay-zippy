import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trophy } from "lucide-react";

export default function GuildLeaderboard({ guildId, guildMembers = [] }) {
  const { data: memberXPs = [], isLoading } = useQuery({
    queryKey: ["guild-leaderboard", guildId],
    enabled: !!guildId && guildMembers?.length > 0,
    queryFn: async () => {
      const allXPs = await base44.entities.UserXP.list("-total_xp", 100);
      return allXPs.filter(xp => guildMembers?.includes(xp.created_by));
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-12">
        <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
      </div>
    );
  }

  if (memberXPs.length === 0) {
    return <div className="text-center py-12 text-white/30">No member data yet</div>;
  }

  return (
    <div className="space-y-2">
      {memberXPs.map((member, idx) => (
        <Card key={member.id} className="bg-[#14141e] border-white/5 p-4 flex items-center gap-4">
          <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center font-bold text-sm shrink-0">
            {idx === 0 && <Trophy className="w-5 h-5 text-yellow-400" />}
            {idx === 1 && <Trophy className="w-5 h-5 text-gray-300" />}
            {idx === 2 && <Trophy className="w-5 h-5 text-orange-400" />}
            {idx > 2 && <span className="text-white/60">#{idx + 1}</span>}
          </div>

          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{member.created_by}</p>
            <div className="flex items-center gap-2 mt-1">
              <Badge className="text-[10px] bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                Level {member.level}
              </Badge>
              <span className="text-xs text-white/40">{member.locations_visited} locations visited</span>
            </div>
          </div>

          <div className="text-right shrink-0">
            <p className="text-lg font-bold text-yellow-400">{member.total_xp}</p>
            <p className="text-[10px] text-white/40">XP</p>
          </div>
        </Card>
      ))}
    </div>
  );
}