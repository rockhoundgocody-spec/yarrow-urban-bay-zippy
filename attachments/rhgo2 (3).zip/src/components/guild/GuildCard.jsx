import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, MapPin } from "lucide-react";

export default function GuildCard({ guild, onSelect, onJoin, isMember }) {
  return (
    <Card className="bg-[#14141e] border-white/5 overflow-hidden hover:border-white/10 transition-all cursor-pointer group" onClick={onSelect}>
      {guild.banner_url && (
        <div className="h-24 bg-gradient-to-r from-amber-500/20 to-orange-500/20 overflow-hidden">
          <img src={guild.banner_url} alt={guild.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
        </div>
      )}
      
      <div className="p-4">
        <div className="flex items-start justify-between gap-3 mb-2">
          <div className="flex-1">
            <h3 className="font-bold text-white">{guild.name}</h3>
            {guild.tagline && <p className="text-xs text-white/40 mt-0.5">{guild.tagline}</p>}
          </div>
          {guild.icon_url && (
            <img src={guild.icon_url} alt={guild.name} className="w-10 h-10 rounded-lg" />
          )}
        </div>

        {guild.description && (
          <p className="text-xs text-white/50 mb-3 line-clamp-2">{guild.description}</p>
        )}

        <div className="flex items-center gap-4 mb-3 text-xs text-white/40">
          <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {guild.member_count} members</span>
          <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {guild.total_discoveries} discoveries</span>
        </div>

        <div className="flex items-center gap-2">
          <Badge className="text-[10px] bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
            {guild.total_guild_xp} XP
          </Badge>
          {guild.visibility !== 'public' && (
            <Badge className="text-[10px] bg-red-500/20 text-red-300 border-red-500/30">
              {guild.visibility === 'private' ? 'Private' : 'Invite Only'}
            </Badge>
          )}
        </div>

        {!isMember && (
          <Button size="sm" onClick={(e) => { e.stopPropagation(); onJoin?.(); }} className="w-full mt-3 bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30">
            Join Guild
          </Button>
        )}
      </div>
    </Card>
  );
}