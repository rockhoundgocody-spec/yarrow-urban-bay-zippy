import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function CreateGuildDialog({ open, onOpenChange }) {
  const [formData, setFormData] = useState({
    name: "",
    tagline: "",
    description: "",
    visibility: "public",
  });
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.Guild.create({
      ...data,
      members: [],
      member_count: 1,
      total_discoveries: 0,
      total_guild_xp: 0,
      founded_date: new Date().toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["guilds"] });
      setFormData({ name: "", tagline: "", description: "", visibility: "public" });
      onOpenChange(false);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) return;
    mutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white">
        <DialogHeader>
          <DialogTitle>Create New Guild</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-xs text-white/60">Guild Name *</Label>
            <Input
              placeholder="Enter guild name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Tagline</Label>
            <Input
              placeholder="Short tagline (e.g., 'Crystal Hunters of the West')"
              value={formData.tagline}
              onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
              maxLength={100}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1 text-sm"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Description</Label>
            <Textarea
              placeholder="Tell others about your guild..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              maxLength={500}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1 text-sm h-24"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Visibility</Label>
            <Select value={formData.visibility} onValueChange={(v) => setFormData({ ...formData, visibility: v })}>
              <SelectTrigger className="bg-[#0a0a0f] border-white/10 text-white mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="public">Public</SelectItem>
                <SelectItem value="private">Private</SelectItem>
                <SelectItem value="invite_only">Invite Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex gap-2 justify-end pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-white/10 text-white/60">
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !formData.name.trim()} className="bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30">
              {mutation.isPending ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : null}
              Create Guild
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}