import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function GuildDiscoveryFeed({ discoveries = [] }) {
  return (
    <div className="space-y-4">
      {discoveries.length === 0 ? (
        <div className="text-center py-12 text-white/30">No discoveries shared yet</div>
      ) : (
        discoveries.map(discovery => (
          <Card key={discovery.id} className="bg-[#14141e] border-white/5 p-4">
            <div className="flex items-start justify-between gap-4 mb-3">
              <div className="flex-1">
                <h4 className="font-medium text-white">{discovery.title}</h4>
                <p className="text-xs text-white/40 mt-0.5">
                  {formatDistanceToNow(new Date(discovery.created_date), { addSuffix: true })}
                </p>
              </div>
              {discovery.rating && (
                <Badge className="text-[10px] bg-yellow-500/20 text-yellow-300 border-yellow-500/30">
                  ★ {discovery.rating}/5
                </Badge>
              )}
            </div>

            {discovery.description && (
              <p className="text-sm text-white/60 mb-3">{discovery.description}</p>
            )}

            {discovery.specimens?.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-3">
                {discovery.specimens.map((spec, idx) => (
                  <Badge key={idx} className="text-[10px] bg-emerald-500/20 text-emerald-300 border-emerald-500/30">
                    {spec}
                  </Badge>
                ))}
              </div>
            )}

            {discovery.photos?.length > 0 && (
              <div className="grid grid-cols-3 gap-2 mb-3">
                {discovery.photos.slice(0, 3).map((photo, idx) => (
                  <img key={idx} src={photo} alt="discovery" className="w-full h-24 object-cover rounded" />
                ))}
              </div>
            )}

            <div className="flex items-center gap-3 pt-3 border-t border-white/5">
              <Button size="sm" variant="ghost" className="text-white/40 hover:text-red-400">
                <Heart className="w-4 h-4 mr-1" /> {discovery.likes_count || 0}
              </Button>
              <Button size="sm" variant="ghost" className="text-white/40 hover:text-white/60">
                <MessageCircle className="w-4 h-4 mr-1" /> Comment
              </Button>
            </div>
          </Card>
        ))
      )}
    </div>
  );
}