import React from "react";
import { Loader2, CheckCircle2, AlertTriangle, GitMerge, Rocket, RefreshCw, ExternalLink, Circle } from "lucide-react";
import { AUDIT_CATEGORY_META } from "@/lib/audit/domainPresets";

const STATUS_META = {
  draft: { icon: Circle, color: "#94A3B8", label: "Draft" },
  queued: { icon: Circle, color: "#94A3B8", label: "Queued" },
  running: { icon: Loader2, color: "#7AE7FF", label: "Running", spin: true },
  plan_ready: { icon: AlertTriangle, color: "#F5B642", label: "Plan ready" },
  completed: { icon: CheckCircle2, color: "#00D68F", label: "Completed" },
  merged: { icon: GitMerge, color: "#D4AF37", label: "Merged" },
  failed: { icon: AlertTriangle, color: "#ff3366", label: "Failed" },
};

export default function DomainCard({ domain, busy, onLaunch, onRefresh, onMerge, onApprove }) {
  const meta = STATUS_META[domain.status] || STATUS_META.draft;
  const Icon = meta.icon;
  const cat = AUDIT_CATEGORY_META[domain.category] || { color: "#94A3B8", label: domain.category };

  return (
    <div className="rh-artifact-panel p-3 flex flex-col gap-2" style={{ borderRadius: 14 }}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="rh-gem-badge" style={{ background: `${cat.color}1A`, color: cat.color }}>
              {cat.label}
            </span>
          </div>
          <div className="text-white font-semibold text-sm mt-1.5 truncate">{domain.label}</div>
          {domain.deep_mode && (domain.max_iterations || 1) > 1 && (
            <div className="flex items-center gap-1 mt-1 flex-wrap">
              <span className="rh-gem-badge" style={{ background: "rgba(212,175,55,0.12)", color: "#D4AF37" }}>
                DEEP ×{(domain.max_iterations || 1)}
              </span>
              {(domain.iteration || 0) > 0 && (
                <span className="text-[10px] text-white/40">pass {domain.iteration}/{domain.max_iterations}</span>
              )}
              {domain.deep_converged && (
                <span className="rh-gem-badge" style={{ background: "rgba(0,214,143,0.12)", color: "#00D68F" }}>
                  CONVERGED
                </span>
              )}
            </div>
          )}
        </div>
        <Icon className="w-4 h-4 flex-shrink-0 mt-1" style={{ color: meta.color, animation: meta.spin ? "spin 1.2s linear infinite" : undefined }} />
      </div>

      {domain.error && (
        <div className="text-[11px] text-red-400/80 line-clamp-2">{domain.error}</div>
      )}

      <div className="flex items-center gap-2 text-[11px] text-white/40">
        <span style={{ color: meta.color }}>{meta.label}</span>
        {domain.session_url && (
          <a href={domain.session_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-[var(--rh-cyan)]">
            session <ExternalLink className="w-2.5 h-2.5" />
          </a>
        )}
        {domain.pr_url && (
          <a href={domain.pr_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-[var(--rh-emerald)]">
            PR #{domain.pr_number} <ExternalLink className="w-2.5 h-2.5" />
          </a>
        )}
      </div>

      <div className="flex items-center gap-1.5 mt-auto pt-1">
        {domain.status === "draft" && (
          <button
            onClick={() => onLaunch(domain)}
            disabled={busy}
            className="rh-crystal-btn px-2.5 py-1.5 text-xs flex items-center gap-1 disabled:opacity-40"
            aria-label={`Launch ${domain.label}`}
          >
            <Rocket className="w-3 h-3" /> Launch
          </button>
        )}
        {domain.status === "plan_ready" && (
          <button
            onClick={() => onApprove(domain)}
            disabled={busy}
            className="px-2.5 py-1.5 text-xs rounded-lg flex items-center gap-1 disabled:opacity-40"
            style={{ background: "rgba(245,182,66,0.14)", border: "1px solid rgba(245,182,66,0.40)", color: "#F5B642" }}
            aria-label={`Approve plan for ${domain.label}`}
          >
            <CheckCircle2 className="w-3 h-3" /> Approve
          </button>
        )}
        {domain.session_id && domain.status !== "merged" && (
          <button
            onClick={() => onRefresh(domain)}
            disabled={busy}
            className="px-2.5 py-1.5 text-xs rounded-lg bg-white/5 border border-white/10 text-white/70 hover:bg-white/10 flex items-center gap-1 disabled:opacity-40"
            aria-label={`Refresh ${domain.label}`}
          >
            <RefreshCw className="w-3 h-3" /> Refresh
          </button>
        )}
        {domain.pr_number && !domain.pr_merged && (
          <button
            onClick={() => onMerge(domain)}
            disabled={busy}
            className="px-2.5 py-1.5 text-xs rounded-lg flex items-center gap-1 disabled:opacity-40"
            style={{ background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.35)", color: "#00D68F" }}
            aria-label={`Merge ${domain.label} PR`}
          >
            <GitMerge className="w-3 h-3" /> Merge
          </button>
        )}
        {domain.pr_merged && (
          <span className="text-[11px] flex items-center gap-1" style={{ color: "#D4AF37" }}>
            <GitMerge className="w-3 h-3" /> Merged
          </span>
        )}
      </div>
    </div>
  );
}