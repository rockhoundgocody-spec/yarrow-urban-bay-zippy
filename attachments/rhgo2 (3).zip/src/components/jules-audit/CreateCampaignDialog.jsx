import React, { useState, useEffect } from "react";
import { X, Search, Loader2, Check } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { AUDIT_DOMAIN_PRESETS, AUDIT_CATEGORY_META } from "@/lib/audit/domainPresets";

export default function CreateCampaignDialog({ onClose, onCreated }) {
  const [name, setName] = useState("");
  const [repoOwner, setRepoOwner] = useState("");
  const [repoName, setRepoName] = useState("");
  const [baseBranch, setBaseBranch] = useState("main");
  const [sourceId, setSourceId] = useState("");
  const [sources, setSources] = useState([]);
  const [loadingSources, setLoadingSources] = useState(false);
  const [selectedKeys, setSelectedKeys] = useState(() => new Set(AUDIT_DOMAIN_PRESETS.map((d) => d.key)));
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState("");
  const [deepMode, setDeepMode] = useState(false);
  const [maxIterations, setMaxIterations] = useState(2);

  const discoverSources = async () => {
    setLoadingSources(true);
    try {
      const res = await base44.functions.invoke("julesAuditOrchestrator", { action: "discoverSource" });
      setSources(res.data.sources || []);
      if (!sourceId && (res.data.sources || []).length) {
        const first = res.data.sources[0];
        setSourceId(first.name || first.id || "");
      }
    } catch (e) {
      setError("Could not discover Jules sources: " + (e.message || "unknown"));
    } finally {
      setLoadingSources(false);
    }
  };

  useEffect(() => { discoverSources(); }, []);

  const toggle = (key) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const handleSubmit = async () => {
    setError("");
    if (!name || !repoOwner || !repoName || !sourceId) {
      setError("Name, repo owner, repo name, and Jules source are required.");
      return;
    }
    const domains = AUDIT_DOMAIN_PRESETS.filter((d) => selectedKeys.has(d.key));
    if (!domains.length) { setError("Select at least one audit domain."); return; }
    setCreating(true);
    try {
      const campaign = await base44.entities.AuditCampaign.create({
        name, repo_owner: repoOwner, repo_name: repoName,
        jules_source_id: sourceId, base_branch: baseBranch,
        status: "draft",
      });
      await base44.entities.AuditDomain.bulkCreate(
        domains.map((d) => ({
          campaign_id: campaign.id,
          campaign_name: name,
          key: d.key, label: d.label, category: d.category,
          scope_prompt: d.scope_prompt, branch_suffix: d.branch_suffix,
          status: "draft",
          deep_mode: deepMode,
          max_iterations: deepMode ? maxIterations : 1,
          iteration: 0,
        }))
      );
      onCreated(campaign);
    } catch (e) {
      setError(e.message || "Failed to create campaign");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="rh-artifact-panel w-full max-w-lg max-h-[90vh] overflow-y-auto p-5" style={{ borderRadius: 20 }}>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-white font-bold text-lg">New Audit Campaign</h2>
          <button onClick={onClose} className="p-2 rounded-lg text-white/50 hover:text-white" aria-label="Close dialog">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          <Field label="Campaign name">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Deep audit — July 2026"
              className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Repo owner">
              <input value={repoOwner} onChange={(e) => setRepoOwner(e.target.value)} placeholder="cgrs"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
            </Field>
            <Field label="Repo name">
              <input value={repoName} onChange={(e) => setRepoName(e.target.value)} placeholder="RockHound-GO"
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Base branch">
              <input value={baseBranch} onChange={(e) => setBaseBranch(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white text-sm" />
            </Field>
            <Field label="Jules source">
              <div className="flex gap-1.5">
                <select value={sourceId} onChange={(e) => setSourceId(e.target.value)}
                  className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2 py-2 text-white text-xs">
                  {loadingSources && <option>Loading…</option>}
                  {sources.map((s) => (
                    <option key={s.name || s.id} value={s.name || s.id} className="bg-[#0E0B1E]">
                      {s.name || s.id}
                    </option>
                  ))}
                </select>
                <button onClick={discoverSources} disabled={loadingSources}
                  className="px-2.5 rounded-lg bg-white/5 border border-white/10 text-white/70 hover:bg-white/10 flex items-center"
                  aria-label="Refresh sources">
                  {loadingSources ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
                </button>
              </div>
            </Field>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-white/60 uppercase tracking-wider">Audit domains ({selectedKeys.size}/{AUDIT_DOMAIN_PRESETS.length})</span>
              <div className="flex gap-2">
                <button onClick={() => setSelectedKeys(new Set(AUDIT_DOMAIN_PRESETS.map((d) => d.key)))} className="text-[11px] text-[var(--rh-cyan)] hover:underline">All</button>
                <button onClick={() => setSelectedKeys(new Set())} className="text-[11px] text-white/40 hover:underline">None</button>
              </div>
            </div>
            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
              {AUDIT_DOMAIN_PRESETS.map((d) => {
                const cat = AUDIT_CATEGORY_META[d.category];
                const on = selectedKeys.has(d.key);
                return (
                  <button key={d.key} onClick={() => toggle(d.key)}
                    className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-all"
                    style={{
                      background: on ? `${cat.color}12` : "rgba(255,255,255,0.03)",
                      border: `1px solid ${on ? `${cat.color}40` : "rgba(255,255,255,0.06)"}`,
                    }}>
                    <div className="w-5 h-5 rounded-md flex items-center justify-center flex-shrink-0"
                      style={{ background: on ? cat.color : "rgba(255,255,255,0.08)" }}>
                      {on && <Check className="w-3 h-3 text-black" />}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">{d.label}</div>
                      <div className="text-[10px] text-white/40 truncate">{cat.label}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-lg px-3 py-2.5 flex items-center justify-between gap-3"
            style={{ background: deepMode ? "rgba(212,175,55,0.08)" : "rgba(255,255,255,0.03)", border: `1px solid ${deepMode ? "rgba(212,175,55,0.25)" : "rgba(255,255,255,0.06)"}` }}>
            <div className="min-w-0">
              <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                Deep audit mode
                {deepMode && <span className="rh-gem-badge" style={{ background: "rgba(212,175,55,0.15)", color: "#D4AF37" }}>DEEP</span>}
              </div>
              <div className="text-[10px] text-white/40 leading-snug">
                {deepMode ? `Each domain re-audits up to ${maxIterations} passes — Jules re-runs on merged main to catch regressions.` : "Re-run each domain iteratively after its PR merges."}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              {deepMode && (
                <select value={maxIterations} onChange={(e) => setMaxIterations(parseInt(e.target.value, 10))}
                  className="bg-white/5 border border-white/10 rounded-md px-1.5 py-1 text-white text-xs" aria-label="Max deep passes">
                  {[2, 3, 4, 5].map((n) => <option key={n} value={n} className="bg-[#0E0B1E]">{n}×</option>)}
                </select>
              )}
              <button onClick={() => setDeepMode((v) => !v)}
                className="w-10 h-6 rounded-full flex items-center transition-all"
                style={{ background: deepMode ? "#D4AF37" : "rgba(255,255,255,0.12)", justifyContent: deepMode ? "flex-end" : "flex-start" }}
                role="switch" aria-checked={deepMode} aria-label="Toggle deep audit mode">
                <span className="w-5 h-5 rounded-full bg-white block mx-0.5" />
              </button>
            </div>
          </div>

          {error && <div className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{error}</div>}

          <div className="flex gap-2 pt-1">
            <button onClick={onClose} className="flex-1 px-4 py-2.5 rounded-lg bg-white/5 border border-white/10 text-white/70 text-sm">Cancel</button>
            <button onClick={handleSubmit} disabled={creating}
              className="flex-1 rh-crystal-btn px-4 py-2.5 text-sm flex items-center justify-center gap-2 disabled:opacity-50">
              {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
              {creating ? "Creating…" : "Create campaign"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block mb-1">{label}</label>
      {children}
    </div>
  );
}