import React from "react";
import { CheckCircle2, GitMerge, Loader2, AlertTriangle, FileCode2, ChevronRight } from "lucide-react";

const STATUS_META = {
  draft: { icon: FileCode2, color: "#94A3B8", label: "Draft" },
  running: { icon: Loader2, color: "#7AE7FF", label: "Running", spin: true },
  partial: { icon: AlertTriangle, color: "#F5B642", label: "Partial" },
  completed: { icon: CheckCircle2, color: "#00D68F", label: "Completed" },
  failed: { icon: AlertTriangle, color: "#ff3366", label: "Failed" },
};

export default function CampaignCard({ campaign, onOpen }) {
  const meta = STATUS_META[campaign.status] || STATUS_META.draft;
  const Icon = meta.icon;
  const pct = campaign.domains_count > 0 ? Math.round((campaign.domains_merged / campaign.domains_count) * 100) : 0;

  return (
    <button
      onClick={() => onOpen(campaign)}
      className="w-full text-left rh-artifact-panel p-4 hover:border-[var(--rh-panel-border)] transition-all"
      style={{ borderRadius: 16 }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-white font-bold text-sm truncate">{campaign.name}</div>
          <div className="text-white/40 text-xs mt-0.5 truncate">
            {campaign.repo_owner}/{campaign.repo_name} · {campaign.base_branch || "main"}
          </div>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Icon className="w-4 h-4" style={{ color: meta.color, animation: meta.spin ? "spin 1.2s linear infinite" : undefined }} />
          <span className="text-xs font-semibold" style={{ color: meta.color }}>{meta.label}</span>
          <ChevronRight className="w-4 h-4 text-white/30" />
        </div>
      </div>

      <div className="flex items-center gap-4 mt-3 text-xs">
        <span className="text-white/50">{campaign.domains_count || 0} domains</span>
        <span className="text-white/50">{campaign.domains_completed || 0} done</span>
        <span className="flex items-center gap-1" style={{ color: "#00D68F" }}>
          <GitMerge className="w-3 h-3" /> {campaign.domains_merged || 0} merged
        </span>
      </div>

      <div className="mt-3 h-1.5 rounded-full bg-white/5 overflow-hidden">
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${pct}%`, background: "linear-gradient(90deg, #00D68F, #7AE7FF)" }}
        />
      </div>
    </button>
  );
}