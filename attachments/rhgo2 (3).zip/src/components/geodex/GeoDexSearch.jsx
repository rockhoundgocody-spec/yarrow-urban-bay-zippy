/**
 * GeoDexSearch — mineral/specimen knowledge search hub for GeoDex page.
 * AI-powered: enters a mineral name, returns structured profile data.
 * Designed as the primary interactive surface for the GeoDex module.
 *
 * Props: none (self-contained)
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Loader2, Sparkles, BookOpen } from "lucide-react";
import { base44 } from "@/api/base44Client";
import MineralProfileCard from "./MineralProfileCard";

const FEATURED = [
  "Quartz", "Amethyst", "Pyrite", "Malachite", "Tourmaline", "Fluorite", "Azurite", "Obsidian",
];

export default function GeoDexSearch({ onScan, onMarket }) {
  const [query,   setQuery]   = useState("");
  const [loading, setLoading] = useState(false);
  const [result,  setResult]  = useState(null);
  const [error,   setError]   = useState(null);

  const lookup = async (name) => {
    if (!name?.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);

    const data = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a mineralogist database. Return structured data for: "${name}".
If it's not a real mineral, return null for all fields.`,
      response_json_schema: {
        type: "object",
        properties: {
          name:          { type: "string" },
          formula:       { type: "string" },
          hardness:      { type: "string" },
          crystal_system:{ type: "string" },
          luster:        { type: "string" },
          color:         { type: "string" },
          rarity:        { type: "string", enum: ["common","uncommon","rare","epic","legendary"] },
          occurrence:    { type: "string" },
          localities:    { type: "array", items: { type: "string" } },
          compLow:       { type: "number" },
          compHigh:      { type: "number" },
          description:   { type: "string" },
        },
      },
    }).catch(() => null);

    if (!data?.name) setError("No data found. Try a different mineral name.");
    else setResult(data);
    setLoading(false);
  };

  const handleSubmit = (e) => { e.preventDefault(); lookup(query); };

  return (
    <div className="space-y-4">
      {/* Search bar */}
      <form onSubmit={handleSubmit}>
        <div
          className="flex items-center gap-3 rounded-2xl px-4 py-3"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)" }}
        >
          <Search className="h-4 w-4 shrink-0 text-white/25" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Enter mineral name — e.g. Rhodonite, Spessartine…"
            className="flex-1 bg-transparent text-sm text-white placeholder-white/20 outline-none"
          />
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold uppercase tracking-wide transition-all disabled:opacity-30"
            style={{ background: "rgba(125,249,255,0.12)", border: "1px solid rgba(125,249,255,0.28)", color: "#7DF9FF" }}
          >
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
            {loading ? "Looking up…" : "Identify"}
          </button>
        </div>
      </form>

      {/* Featured quick-lookup chips */}
      {!result && !loading && (
        <div>
          <div className="text-[9px] font-bold uppercase tracking-[0.22em] text-white/20 mb-2">
            <BookOpen className="h-3 w-3 inline mr-1" /> Common Species
          </div>
          <div className="flex flex-wrap gap-1.5">
            {FEATURED.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => { setQuery(m); lookup(m); }}
                className="rounded-full px-3 py-1.5 text-[11px] text-white/50 transition-all hover:text-white/80"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                {m}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="flex items-center gap-2 text-sm text-white/30 py-4">
          <Loader2 className="h-4 w-4 animate-spin text-cyan-300" />
          Consulting mineralogy database…
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="rounded-2xl px-4 py-3 text-xs text-white/40" style={{ background: "rgba(255,122,89,0.06)", border: "1px solid rgba(255,122,89,0.15)" }}>
          {error}
        </div>
      )}

      {/* Result card */}
      <AnimatePresence>
        {result && !loading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <MineralProfileCard
              mineral={result}
              onCollect={onScan}
              onMarket={onMarket ? () => onMarket(result) : undefined}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}