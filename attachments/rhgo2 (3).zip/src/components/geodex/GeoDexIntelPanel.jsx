/**
 * GeoDexIntelPanel
 * AI intelligence surface for mineral detail in GeoDex.
 * Shows: comp value range, rarity context, field availability,
 * collection status, and a Clover-generated insight note.
 */

import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { TrendingUp, MapPin, Layers, Sparkles, CheckCircle2, Lock, Brain, Zap } from "lucide-react";
import { geodexIntelligence } from "@/lib/aiService";

// Comp value bands by rarity (collector-grade estimates, clearly framed as estimates)
const COMP_BANDS = {
  common:    { low: 1,    high: 15,    label: "Entry level",      trend: "stable" },
  uncommon:  { low: 8,    high: 80,    label: "Mid-tier",         trend: "rising" },
  rare:      { low: 45,   high: 400,   label: "Collector grade",  trend: "rising" },
  very_rare: { low: 200,  high: 2500,  label: "Premium",          trend: "strong" },
  legendary: { low: 1000, high: 15000, label: "Investment grade", trend: "strong" },
};

const FIELD_TIPS = {
  common:    "Found across most sedimentary and igneous formations. Widely accessible.",
  uncommon:  "Requires targeted prospecting. Found in specific mineralizing environments.",
  rare:      "Limited locality distribution. Research known deposits before trips.",
  very_rare: "Few active collecting localities exist. Permit-required sites likely.",
  legendary: "Extremely restricted. Primarily available through established dealers and auction.",
};

const TREND_COLORS = {
  stable: "#9ca3af",
  rising: "#00D68F",
  strong: "#F5B642",
};

function StatBlock({ icon: Icon, label, value, color }) {
  return (
    <div className="rounded-xl p-3 flex items-start gap-2.5"
      style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <Icon className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color }} />
      <div>
        <p className="text-[10px] uppercase tracking-widest font-semibold mb-0.5" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</p>
        <p className="text-sm font-bold text-white/80">{value}</p>
      </div>
    </div>
  );
}

export default function GeoDexIntelPanel({ entry, inCollection = false, rc }) {
  const accentColor = rc?.color || "#00D68F";

  const [intel, setIntel] = useState(null);
  const [intelLoading, setIntelLoading] = useState(true);
  const [intelSource, setIntelSource] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setIntelLoading(true);
    geodexIntelligence({
      mineralName: entry.name,
      userLocality: null,
      collectionContext: `${entry.rarity} rarity, ${entry.crystal_system} crystal system, Mohs ${entry.hardness}`,
    }).then(({ data, source }) => {
      if (!cancelled) { setIntel(data); setIntelSource(source); }
    }).catch(() => {}).finally(() => { if (!cancelled) setIntelLoading(false); });
    return () => { cancelled = true; };
  }, [entry.id]);

  // Use AI-backed comp if available, else fall back to static bands
  const staticBand = COMP_BANDS[entry.rarity] || COMP_BANDS.common;
  const valueLow = intel?.market_context ? staticBand.low : staticBand.low;
  const valueHigh = staticBand.high;
  const trendKey = staticBand.trend;
  const trendColor = TREND_COLORS[trendKey] || "#9ca3af";
  const fieldTip = intel?.collector_notes || FIELD_TIPS[entry.rarity] || FIELD_TIPS.common;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.15 }}
      className="mt-5 space-y-3"
    >
      {/* Section header */}
      <div className="flex items-center gap-2">
        <Brain className="w-3.5 h-3.5" style={{ color: accentColor }} />
        <span className="text-[10px] font-black uppercase tracking-[0.18em]" style={{ color: accentColor }}>AI Intelligence</span>
        {intelSource === "ai_backbone" && (
          <span className="ml-auto text-[9px] font-bold px-2 py-0.5 rounded-full"
            style={{ background: `${accentColor}15`, color: `${accentColor}99`, border: `1px solid ${accentColor}25` }}>
            Live
          </span>
        )}
      </div>

      {/* Comp value range */}
      <div className="rounded-2xl p-4"
        style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${accentColor}22` }}>
        <div className="flex items-center justify-between mb-2">
          <span className="text-[10px] font-semibold uppercase tracking-widest text-white/30">Est. Comp Range</span>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
            style={{ background: `${trendColor}15`, color: trendColor, border: `1px solid ${trendColor}30` }}>
            {trendKey === "stable" ? "Stable" : trendKey === "rising" ? "↑ Rising" : "↑↑ Strong"}
          </span>
        </div>
        <div className="flex items-end gap-2 mb-1">
          <span className="text-2xl font-black text-white">${valueLow.toLocaleString()}</span>
          <span className="text-white/30 mb-1">–</span>
          <span className="text-2xl font-black" style={{ color: accentColor }}>${valueHigh.toLocaleString()}</span>
        </div>
        <p className="text-[10px] text-white/30">{staticBand.label} · Collector market estimate · Varies by quality &amp; provenance</p>

        {/* Value gradient bar */}
        <div className="mt-3 h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.06)" }}>
          <div className="h-full rounded-full" style={{
            width: `${Math.min(90, (["common","uncommon","rare","very_rare","legendary"].indexOf(entry.rarity) + 1) * 18)}%`,
            background: `linear-gradient(90deg, ${accentColor}88, ${accentColor})`,
            boxShadow: `0 0 8px ${accentColor}66`,
          }} />
        </div>
      </div>

      {/* Stat grid */}
      <div className="grid grid-cols-2 gap-2">
        <StatBlock icon={MapPin} label="Field Access" value={entry.rarity === "legendary" || entry.rarity === "very_rare" ? "Restricted" : "Accessible"} color={accentColor} />
        <StatBlock icon={TrendingUp} label="Market Trend" value={trendKey.charAt(0).toUpperCase() + trendKey.slice(1)} color={trendColor} />
        <StatBlock icon={Layers} label="Hardness" value={`Mohs ${entry.hardness}`} color="rgba(255,255,255,0.5)" />
        <StatBlock icon={inCollection ? CheckCircle2 : Lock} label="Your Vault" value={inCollection ? "In collection" : "Not collected"} color={inCollection ? "#00D68F" : "rgba(255,255,255,0.25)"} />
      </div>

      {/* Field notes — AI-backed when available */}
      <div className="rounded-xl px-3.5 py-3" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
        <p className="text-[10px] font-bold uppercase tracking-widest text-white/25 mb-1">Field Notes</p>
        <p className="text-xs text-white/55 leading-relaxed">{fieldTip}</p>
      </div>

      {/* AI collector intelligence */}
      <div className="rounded-xl px-3.5 py-3 flex items-start gap-2.5"
        style={{ background: `${accentColor}08`, border: `1px solid ${accentColor}22` }}>
        <Sparkles className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" style={{ color: accentColor }} />
        <div className="flex-1">
          <p className="text-[10px] font-black uppercase tracking-widest mb-1" style={{ color: accentColor }}>Clover Intel</p>
          {intelLoading ? (
            <div className="flex gap-0.5 items-end">
              {[0,1,2].map(i => (
                <motion.span key={i} className="block rounded-full"
                  style={{ width: 3, height: 3, background: accentColor }}
                  animate={{ scaleY: [1, 2.2, 1] }}
                  transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.15 }} />
              ))}
            </div>
          ) : (
            <p className="text-xs text-white/65 leading-relaxed">
              {intel?.collector_notes || intel?.rarity_context || "Analyzing mineral profile…"}
            </p>
          )}
          {intel?.look_alikes?.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {intel.look_alikes.slice(0, 3).map((la, i) => (
                <span key={i} className="text-[9px] px-1.5 py-0.5 rounded-full"
                  style={{ background: `${accentColor}12`, color: `${accentColor}88`, border: `1px solid ${accentColor}20` }}>
                  vs {la}
                </span>
              ))}
            </div>
          )}
        </div>
        {intel?.identification_tips && (
          <Zap className="w-3 h-3 flex-shrink-0" style={{ color: `${accentColor}44` }} />
        )}
      </div>
    </motion.div>
  );
}