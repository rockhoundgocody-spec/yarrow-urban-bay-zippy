/**
 * MineralProfileCard — structured mineral/specimen knowledge card for GeoDex.
 * Shows: identity, classification, properties, rarity, occurrence, comp range.
 *
 * Props:
 *  mineral   object — { name, formula, hardness, luster, crystal_system, color, 
 *                       rarity, occurrence, localities, compLow, compHigh, description }
 *  onCollect fn     — CTA to scan/add to collection
 *  onMarket  fn     — CTA to view market comps
 */

import React, { useState } from "react";
import { motion } from "framer-motion";
import { Gem, MapPin, DollarSign, ChevronDown, ChevronUp, Zap } from "lucide-react";
import { getRarity } from "@/theme/raritySystem";
import RarityBadge from "@/components/ui/RarityBadge";

const PROP_ROW = ({ label, value, color }) => (
  <div className="flex justify-between items-baseline py-1.5 border-b border-white/[0.05]">
    <span className="text-[10px] uppercase tracking-[0.16em] text-white/30">{label}</span>
    <span className="text-xs font-semibold" style={{ color: color || "rgba(255,255,255,0.70)" }}>{value || "—"}</span>
  </div>
);

export default function MineralProfileCard({ mineral = {}, onCollect, onMarket }) {
  const [expanded, setExpanded] = useState(false);
  const r = getRarity(mineral.rarity || "common");

  return (
    <motion.div
      whileHover={{ y: -1 }}
      className="overflow-hidden rounded-[26px]"
      style={{
        background: "linear-gradient(145deg, rgba(8,12,20,0.97) 0%, rgba(12,8,24,0.95) 100%)",
        border: `1px solid ${r.border}`,
        boxShadow: `0 4px 24px rgba(0,0,0,0.6), ${r.glow}`,
      }}
    >
      {/* Header */}
      <div className="px-5 pt-5 pb-4">
        <div className="flex items-start gap-3">
          <div
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl"
            style={{ background: r.bg, border: `1px solid ${r.border}` }}
          >
            <Gem className="h-6 w-6" style={{ color: r.color }} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-base font-black text-white leading-tight tracking-tight">{mineral.name || "Unknown Mineral"}</h3>
              <RarityBadge rarity={mineral.rarity || "common"} size="xs" />
            </div>
            {mineral.formula && (
              <div className="text-[11px] font-mono" style={{ color: "rgba(125,249,255,0.55)" }}>{mineral.formula}</div>
            )}
          </div>
        </div>

        {/* Description */}
        {mineral.description && (
          <p className="mt-3 text-xs leading-5 text-white/40 line-clamp-2">{mineral.description}</p>
        )}

        {/* Comp range */}
        {(mineral.compLow != null || mineral.compHigh != null) && (
          <div
            className="mt-3 flex items-center gap-2 rounded-xl px-3 py-2"
            style={{ background: "rgba(255,215,0,0.06)", border: "1px solid rgba(255,215,0,0.15)" }}
          >
            <DollarSign className="h-3.5 w-3.5 text-amber-300 shrink-0" />
            <div className="text-xs">
              <span className="font-bold text-amber-300">${mineral.compLow || 0}–${mineral.compHigh || 0}</span>
              <span className="text-white/30 ml-1.5">collector comp range</span>
            </div>
          </div>
        )}
      </div>

      {/* Properties table — collapsible */}
      <div className="border-t border-white/[0.06]">
        <button
          type="button"
          onClick={() => setExpanded(!expanded)}
          className="flex w-full items-center justify-between px-5 py-3"
        >
          <span className="text-[10px] font-bold uppercase tracking-[0.20em] text-white/30">Properties</span>
          {expanded ? <ChevronUp className="h-3.5 w-3.5 text-white/25" /> : <ChevronDown className="h-3.5 w-3.5 text-white/25" />}
        </button>

        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            className="overflow-hidden px-5 pb-4"
          >
            <PROP_ROW label="Hardness (Mohs)"  value={mineral.hardness}      color="#7DF9FF" />
            <PROP_ROW label="Crystal System"   value={mineral.crystal_system} />
            <PROP_ROW label="Luster"           value={mineral.luster} />
            <PROP_ROW label="Color"            value={mineral.color} />
            <PROP_ROW label="Occurrence"       value={mineral.occurrence} />
            {mineral.localities && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {mineral.localities.slice(0, 4).map((loc) => (
                  <div key={loc} className="flex items-center gap-1 rounded-full px-2 py-0.5"
                    style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.09)" }}>
                    <MapPin className="h-2.5 w-2.5 text-white/25" />
                    <span className="text-[9px] text-white/45">{loc}</span>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </div>

      {/* CTAs */}
      {(onCollect || onMarket) && (
        <div className="flex gap-2 border-t border-white/[0.06] px-4 py-3">
          {onCollect && (
            <button
              type="button"
              onClick={onCollect}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-2.5 text-xs font-bold uppercase tracking-wide"
              style={{ background: r.bg, border: `1px solid ${r.border}`, color: r.color }}
            >
              <Zap className="h-3.5 w-3.5" /> Scan to Identify
            </button>
          )}
          {onMarket && (
            <button
              type="button"
              onClick={onMarket}
              className="flex flex-1 items-center justify-center gap-1.5 rounded-2xl py-2.5 text-xs font-bold uppercase tracking-wide"
              style={{ background: "rgba(255,215,0,0.08)", border: "1px solid rgba(255,215,0,0.22)", color: "#FFD700" }}
            >
              <DollarSign className="h-3.5 w-3.5" /> View Comps
            </button>
          )}
        </div>
      )}
    </motion.div>
  );
}