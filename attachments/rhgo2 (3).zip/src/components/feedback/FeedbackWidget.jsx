import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Star } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useLocation } from 'react-router-dom';

export default function FeedbackWidget() {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState('general');
  const [rating, setRating] = useState(0);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const location = useLocation();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    setLoading(true);
    try {
      const response = await base44.functions.invoke('submitFeedback', {
        message: message.trim(),
        category,
        page: location.pathname,
        rating: rating > 0 ? rating : null,
      });

      if (response?.data?.success) {
        setSuccess(true);
        setMessage('');
        setCategory('general');
        setRating(0);
        setTimeout(() => {
          setOpen(false);
          setSuccess(false);
        }, 2000);
      }
    } catch (error) {
      console.error('Feedback error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating liquid pool button */}
      <motion.button
        onClick={() => setOpen(true)}
        className="fixed bottom-20 left-6 px-3.5 py-1.75 rounded-full flex items-center gap-1.5 z-40 text-xs font-semibold"
        style={{
          background: 'linear-gradient(135deg, rgba(0,214,143,0.12), rgba(122,231,255,0.12))',
          border: '1px solid rgba(122,231,255,0.3)',
          color: '#7AE7FF',
          backdropFilter: 'blur(12px)',
          opacity: 0.3,
          boxShadow: '0 0 24px rgba(122,231,255,0.15), inset 0 0 20px rgba(122,231,255,0.06)',
          animation: 'liquidPoolGlow 4s ease-in-out infinite',
        }}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        initial={{ opacity: 0.3, scale: 0.85 }}
        animate={{ opacity: 0.3, scale: 1 }}
        transition={{ delay: 0.5 }}
      >
        <Send className="w-3 h-3" />
        <span className="hidden sm:inline">Feedback</span>
      </motion.button>

      {/* Modal */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end md:items-center justify-end md:justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
          >
            <motion.div
              className="w-full md:w-96 rounded-2xl overflow-hidden shadow-2xl max-h-[80vh] flex flex-col"
              style={{
                background: 'linear-gradient(135deg, rgba(10,15,22,0.98) 0%, rgba(6,10,18,0.99) 100%)',
                border: '1px solid rgba(0,214,143,0.2)',
              }}
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-5 border-b border-white/5">
                <h2 className="text-lg font-bold text-white">Send Feedback</h2>
                <button
                  onClick={() => setOpen(false)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors"
                  style={{ minHeight: 'unset', minWidth: 'unset' }}
                 aria-label="Close">
                  <X className="w-5 h-5 text-white/60" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4">
                {success ? (
                  <div className="flex flex-col items-center justify-center gap-3 py-8">
                    <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                      <span className="text-2xl">✓</span>
                    </div>
                    <p className="text-white font-semibold">Thanks for your feedback!</p>
                    <p className="text-white/50 text-sm text-center">We'll review it shortly</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Category */}
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50 mb-2 block">
                        Category
                      </label>
                      <select
                        value={category}
                        onChange={(e) => setCategory(e.target.value)}
                        className="w-full px-3 py-2.5 rounded-lg bg-white/8 border border-white/15 text-black text-sm focus:outline-none focus:border-emerald-400/50"
                      >
                        <option value="general" style={{ color: '#000' }}>General</option>
                        <option value="bug" style={{ color: '#000' }}>Bug Report</option>
                        <option value="feature_request" style={{ color: '#000' }}>Feature Request</option>
                        <option value="ui_improvement" style={{ color: '#000' }}>UI Improvement</option>
                        <option value="performance" style={{ color: '#000' }}>Performance Issue</option>
                      </select>
                    </div>

                    {/* Rating */}
                     <div>
                       <label className="text-xs font-bold uppercase tracking-widest text-white/50 mb-2 block">
                         How satisfied are you?
                       </label>
                       <div className="flex gap-2">
                         {[1, 2, 3, 4, 5].map((star) => {
                           const colors = ['#FF6B6B', '#FF8C42', '#FFB700', '#A8E63D', '#00D68F'];
                           const starColor = rating >= star ? colors[star - 1] : 'rgba(255,255,255,0.2)';
                           return (
                             <motion.button
                               key={star}
                               type="button"
                               onClick={() => setRating(star)}
                               className="p-1"
                               style={{ minHeight: 'unset', minWidth: 'unset' }}
                               whileHover={{ scale: 1.15 }}
                               whileTap={{ scale: 0.95 }}
                             >
                               <Star
                                 className="w-6 h-6"
                                 fill={starColor}
                                 color={starColor}
                               />
                             </motion.button>
                           );
                         })}
                       </div>
                     </div>

                    {/* Message */}
                    <div>
                      <label className="text-xs font-bold uppercase tracking-widest text-white/50 mb-2 block">
                        Message
                      </label>
                      <textarea
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        placeholder="Tell us what you think..."
                        className="w-full px-3 py-2.5 rounded-lg bg-white border border-gray-300 text-black text-sm placeholder-black/60 focus:outline-none focus:border-emerald-400 resize-none h-24"
                      />
                    </div>

                    {/* Submit */}
                    <button
                      type="submit"
                      disabled={!message.trim() || loading}
                      className="w-full py-3 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-opacity disabled:opacity-50"
                      style={{
                        background: 'linear-gradient(135deg, #00D68F, #7AE7FF)',
                        color: '#000',
                      }}
                    >
                      {loading ? (
                        <div className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                      {loading ? 'Sending...' : 'Send Feedback'}
                    </button>
                  </form>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}