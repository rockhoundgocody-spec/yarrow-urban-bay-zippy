/**
 * Legacy shim — delegates to SyncEngine.
 * Kept for backward compat; prefer SyncEngine helpers directly.
 */
export { enqueueOperation as enqueue, getQueueItems as getQueue, clearFailedItems as clearQueue } from "./offline/SyncEngine";