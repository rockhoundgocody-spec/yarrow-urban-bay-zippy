import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Share2, X, Shuffle } from "lucide-react";
import { toast } from "sonner";

const TEMPLATES = [
  {
    id: "drakeyes",
    label: "Drake Approves",
    top: "Regular dirt? 🙄",
    bottom: "Wait— is that FLUORITE?! 🤩",
    topStyle: { color: "#fff", fontSize: 14, fontWeight: 800 },
    bottomStyle: { color: "#00D68F", fontSize: 14, fontWeight: 800 },
    bg: "linear-gradient(135deg, #1a1a2e 0%, #0a0a1a 100%)",
    emoji: "👀",
  },
  {
    id: "astronaut",
    label: "Always Has Been",
    top: "Wait — it's all minerals?",
    bottom: "Always has been. 🔫",
    topStyle: { color: "#7AE7FF", fontSize: 13, fontWeight: 700 },
    bottomStyle: { color: "#fff", fontSize: 13, fontWeight: 700 },
    bg: "linear-gradient(135deg, #001a33 0%, #000510 100%)",
    emoji: "🚀",
  },
  {
    id: "distracted",
    label: "Distracted Geologist",
    top: "School 📚",
    bottom: "THAT ROCK IS PYRITE 😱",
    topStyle: { color: "#ef4444", fontSize: 14, fontWeight: 800 },
    bottomStyle: { color: "#D4AF37", fontSize: 15, fontWeight: 900 },
    bg: "linear-gradient(135deg, #1a0a00 0%, #0d0500 100%)",
    emoji: "🏃",
  },
  {
    id: "thisis",
    label: "This Is Fine",
    top: "My backyard is just dirt",
    bottom: "THIS IS FINE 🔥",
    topStyle: { color: "#fff", fontSize: 13, fontWeight: 700 },
    bottomStyle: { color: "#F5B642", fontSize: 15, fontWeight: 900 },
    bg: "linear-gradient(135deg, #1a0800 0%, #0d0400 100%)",
    emoji: "🐶",
  },
  {
    id: "epichandshake",
    label: "Epic Handshake",
    top: "Geologists & Kids",
    bottom: "CALLING EVERY ROCK LEGENDARY",
    topStyle: { color: "#8D7CFF", fontSize: 12, fontWeight: 700 },
    bottomStyle: { color: "#fff", fontSize: 12, fontWeight: 800 },
    bg: "linear-gradient(135deg, #0a0518 0%, #04020E 100%)",
    emoji: "🤝",
  },
  {
    id: "stonks",
    label: "Stonks",
    top: "Bought rocks at a yard sale for $2",
    bottom: "AI says: RARE SPECIMEN 📈 +$800",
    topStyle: { color: "#fff", fontSize: 12, fontWeight: 700 },
    bottomStyle: { color: "#00D68F", fontSize: 12, fontWeight: 800 },
    bg: "linear-gradient(135deg, #001a00 0%, #000d00 100%)",
    emoji: "📈",
  },
];

export default function MemeYourFind({ specimen, onClose }) {
  const [selected, setSelected] = useState(TEMPLATES[0]);
  const [customTop, setCustomTop] = useState("");
  const [customBottom, setCustomBottom] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [memeUrl, setMemeUrl] = useState(null);
  const canvasRef = useRef(null);

  const specimenName = specimen?.name || "Mystery Rock";
  const specimenEmoji = specimen?.category === "crystal" ? "💎"
    : specimen?.category === "gemstone" ? "💍"
    : specimen?.category === "fossil" ? "🦕"
    : "🪨";

  const topText = customTop || selected.top;
  const bottomText = customBottom || selected.bottom.replace("MYSTERY ROCK", specimenName.toUpperCase());

  const drawMeme = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = 400, H = 400;
    canvas.width = W;
    canvas.height = H;

    // Background gradient
    const grd = ctx.createLinearGradient(0, 0, W, H);
    const colors = selected.bg.match(/#[a-fA-F0-9]{6}/g) || ["#0a0518", "#04020E"];
    grd.addColorStop(0, colors[0]);
    grd.addColorStop(1, colors[1] || colors[0]);
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, W, H);

    // Grid overlay
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (let x = 0; x < W; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke(); }
    for (let y = 0; y < H; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke(); }

    // Big emoji center
    ctx.font = "100px serif";
    ctx.textAlign = "center";
    ctx.fillText(selected.emoji, W / 2, H / 2 + 30);

    // Specimen emoji overlay
    ctx.font = "36px serif";
    ctx.fillText(specimenEmoji, W / 2 + 60, H / 2 - 30);

    // Top text
    ctx.font = `${selected.topStyle.fontSize * 1.6}px Inter, sans-serif`;
    ctx.fillStyle = selected.topStyle.color;
    ctx.textAlign = "center";
    wrapText(ctx, topText, W / 2, 50, W - 40, selected.topStyle.fontSize * 2);

    // Bottom text
    ctx.font = `bold ${selected.bottomStyle.fontSize * 1.6}px Inter, sans-serif`;
    ctx.fillStyle = selected.bottomStyle.color;
    wrapText(ctx, bottomText, W / 2, H - 60, W - 40, selected.bottomStyle.fontSize * 2);

    // Branding
    ctx.font = "bold 11px Inter, sans-serif";
    ctx.fillStyle = "rgba(141,124,255,0.6)";
    ctx.textAlign = "right";
    ctx.fillText("RockHound-GO", W - 16, H - 16);

    setMemeUrl(canvas.toDataURL("image/png"));
  };

  function wrapText(ctx, text, x, y, maxW, lineH) {
    const words = text.split(" ");
    let line = "";
    let curY = y;
    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + " ";
      const metrics = ctx.measureText(testLine);
      if (metrics.width > maxW && n > 0) {
        ctx.fillText(line, x, curY);
        line = words[n] + " ";
        curY += lineH;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, curY);
  }

  useEffect(() => { drawMeme(); }, [selected, customTop, customBottom]);

  const handleShare = async () => {
    if (!memeUrl) return;
    if (navigator.share) {
      try {
        const blob = await (await fetch(memeUrl)).blob();
        const file = new File([blob], "rockhound-meme.png", { type: "image/png" });
        await navigator.share({ files: [file], title: "Check my rock find!", text: `${specimenName} found with RockHound-GO 🪨` });
        toast.success("Shared!");
      } catch {
        toast.error("Share cancelled.");
      }
    } else {
      const a = document.createElement("a");
      a.href = memeUrl;
      a.download = "rockhound-meme.png";
      a.click();
      toast.success("Meme downloaded!");
    }
  };

  const shuffle = () => {
    const remaining = TEMPLATES.filter(t => t.id !== selected.id);
    setSelected(remaining[Math.floor(Math.random() * remaining.length)]);
    setCustomTop("");
    setCustomBottom("");
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 60 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 60 }}
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)" }}
    >
      <div className="w-full max-w-md rounded-t-3xl overflow-hidden max-h-[90vh] flex flex-col"
        style={{ background: "linear-gradient(180deg, #0A0518 0%, #04020E 100%)", border: "1px solid rgba(141,124,255,0.3)" }}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 flex-shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-lg">😂</span>
            <span className="text-sm font-black text-white tracking-wider uppercase">Meme Your Find</span>
          </div>
          <button aria-label="Close meme editor" title="Close meme editor" onClick={onClose} className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.07)", minWidth: "unset", minHeight: "unset" }}>
            <X className="w-4 h-4 text-white/50" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 px-5 pb-8 space-y-4">
          {/* Hidden canvas */}
          <canvas ref={canvasRef} className="hidden" />

          {/* Preview */}
          {memeUrl && (
            <div className="rounded-2xl overflow-hidden border" style={{ borderColor: "rgba(141,124,255,0.25)" }}>
              <img src={memeUrl} alt="meme preview" className="w-full" />
            </div>
          )}

          {/* Template selector */}
          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {TEMPLATES.map(t => (
              <button key={t.id} onClick={() => { setSelected(t); setCustomTop(""); setCustomBottom(""); }}
                className="flex-shrink-0 px-3 py-2 rounded-xl text-[10px] font-bold uppercase tracking-wide transition-all"
                style={{
                  background: selected.id === t.id ? "rgba(141,124,255,0.25)" : "rgba(255,255,255,0.05)",
                  border: `1px solid ${selected.id === t.id ? "rgba(141,124,255,0.5)" : "rgba(255,255,255,0.1)"}`,
                  color: selected.id === t.id ? "#C4B5FD" : "rgba(255,255,255,0.5)",
                  minHeight: "unset", minWidth: "unset"
                }}>
                {t.emoji} {t.label}
              </button>
            ))}
          </div>

          {/* Custom text toggle */}
          <button onClick={() => setEditMode(v => !v)}
            className="w-full py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider text-center transition-all"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.5)" }}>
            ✏️ {editMode ? "Hide Custom Text" : "Edit Caption Text"}
          </button>

          <AnimatePresence>
            {editMode && (
              <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }} className="space-y-2 overflow-hidden">
                <input value={customTop} onChange={e => setCustomTop(e.target.value)}
                  placeholder={`Top: "${selected.top}"`}
                  className="w-full px-3 py-3 rounded-xl text-xs text-white placeholder:text-white/25 outline-none"
                  style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.1)" }} />
                <input value={customBottom} onChange={e => setCustomBottom(e.target.value)}
                  placeholder={`Bottom: "${selected.bottom}"`}
                  className="w-full px-3 py-3 rounded-xl text-xs text-white placeholder:text-white/25 outline-none"
                  style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.1)" }} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Actions */}
          <div className="grid grid-cols-2 gap-3">
            <button onClick={shuffle}
              className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-xs font-bold uppercase tracking-wider transition-all"
              style={{ background: "rgba(122,231,255,0.1)", border: "1px solid rgba(122,231,255,0.25)", color: "#7AE7FF" }}>
              <Shuffle className="w-4 h-4" /> Shuffle
            </button>
            <button onClick={handleShare}
              className="flex items-center justify-center gap-2 py-3.5 rounded-2xl text-xs font-bold uppercase tracking-widest transition-all"
              style={{ background: "linear-gradient(135deg, #8D7CFF, #7AE7FF)", color: "#000" }}>
              <Share2 className="w-4 h-4" /> Share
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}