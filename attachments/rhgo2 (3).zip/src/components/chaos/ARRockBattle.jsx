import React, { useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Swords, X } from "lucide-react";

const BATTLE_STATS = {
  quartz:    { name: "Quartz",    emoji: "💎", hp: 80, atk: 70, def: 60, color: "#7AE7FF" },
  obsidian:  { name: "Obsidian",  emoji: "🖤", hp: 90, atk: 85, def: 75, color: "#6E7681" },
  amethyst:  { name: "Amethyst", emoji: "💜", hp: 75, atk: 90, def: 55, color: "#8D7CFF" },
  pyrite:    { name: "Pyrite",    emoji: "✨", hp: 70, atk: 75, def: 80, color: "#D4AF37" },
  fluorite:  { name: "Fluorite", emoji: "🟢", hp: 85, atk: 65, def: 70, color: "#00D68F" },
  granite:   { name: "Granite",  emoji: "🪨", hp: 95, atk: 60, def: 90, color: "#8B7355" },
};

const ATTACKS = ["Rock Smash", "Crystal Burst", "Geo Slam", "Mineral Strike", "Shard Blast", "Lava Surge"];

function pickRandom(obj) {
  const keys = Object.keys(obj);
  return obj[keys[Math.floor(Math.random() * keys.length)]];
}

function simulate(a, b) {
  const log = [];
  let aHp = a.hp, bHp = b.hp;
  let round = 1;
  while (aHp > 0 && bHp > 0 && round <= 10) {
    const aDmg = Math.max(1, Math.floor(a.atk * (0.7 + Math.random() * 0.6) - b.def * 0.3));
    const bDmg = Math.max(1, Math.floor(b.atk * (0.7 + Math.random() * 0.6) - a.def * 0.3));
    aHp = Math.max(0, aHp - bDmg);
    bHp = Math.max(0, bHp - aDmg);
    log.push({
      round,
      aAtk: ATTACKS[Math.floor(Math.random() * ATTACKS.length)],
      bAtk: ATTACKS[Math.floor(Math.random() * ATTACKS.length)],
      aDmg, bDmg, aHp, bHp
    });
    round++;
  }
  const winner = aHp > bHp ? "player" : "rival";
  return { log, winner, finalAHp: aHp, finalBHp: bHp };
}

export default function ARRockBattle({ onClose, onXPEarned }) {
  const [phase, setPhase] = useState("intro"); // intro | fighting | result
  const [player, setPlayer] = useState(null);
  const [rival, setRival] = useState(null);
  const [battle, setBattle] = useState(null);
  const [logIdx, setLogIdx] = useState(0);
  const intervalRef = useRef(null);

  const startBattle = () => {
    const p = pickRandom(BATTLE_STATS);
    const r = pickRandom(BATTLE_STATS);
    const result = simulate(p, r);
    setPlayer(p);
    setRival(r);
    setBattle(result);
    setLogIdx(0);
    setPhase("fighting");

    let i = 0;
    intervalRef.current = setInterval(() => {
      i++;
      setLogIdx(i);
      if (i >= result.log.length) {
        clearInterval(intervalRef.current);
        setTimeout(() => setPhase("result"), 600);
      }
    }, 700);
  };

  const handleClose = () => {
    clearInterval(intervalRef.current);
    onClose?.();
  };

  const handleClaim = () => {
    const xp = battle?.winner === "player" ? 75 : 25;
    onXPEarned?.(xp);
    handleClose();
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.88 }}
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.85)", backdropFilter: "blur(8px)" }}
    >
      <div className="w-full max-w-md rounded-t-3xl overflow-hidden"
        style={{ background: "linear-gradient(180deg, #0A0518 0%, #04020E 100%)", border: "1px solid rgba(141,124,255,0.3)" }}>

        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3">
          <div className="flex items-center gap-2">
            <Swords className="w-5 h-5" style={{ color: "#8D7CFF" }} />
            <span className="text-sm font-black text-white tracking-wider uppercase">Rock Battle</span>
          </div>
          <button aria-label="Close battle" title="Close battle" onClick={handleClose} className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: "rgba(255,255,255,0.07)", minWidth: "unset", minHeight: "unset" }}>
            <X className="w-4 h-4 text-white/50" />
          </button>
        </div>

        <div className="px-5 pb-8 space-y-4">
          {/* INTRO */}
          {phase === "intro" && (
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-5 py-4">
              <div className="text-5xl">⚔️</div>
              <p className="text-white font-bold text-base">Two random rocks. One arena. No mercy.</p>
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
                Stats are based on real mineral hardness, density, and luster. Science = power.
              </p>
              <button onClick={startBattle}
                className="w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all"
                style={{ background: "linear-gradient(135deg, #8D7CFF, #7AE7FF)", color: "#000" }}>
                ⚡ Start Battle
              </button>
            </motion.div>
          )}

          {/* FIGHTING */}
          {phase === "fighting" && player && rival && battle && (
            <div className="space-y-4">
              {/* Fighters */}
              <div className="grid grid-cols-2 gap-3">
                {[
                  { rock: player, side: "YOU", flip: false },
                  { rock: rival, side: "RIVAL", flip: true }
                ].map(({ rock, side, flip }) => {
                  const currentLog = battle.log[Math.max(0, logIdx - 1)];
                  const hp = side === "YOU"
                    ? (currentLog?.aHp ?? rock.hp)
                    : (currentLog?.bHp ?? rock.hp);
                  const pct = Math.round((hp / rock.hp) * 100);
                  return (
                    <div key={side} className="rounded-2xl p-3 text-center space-y-2"
                      style={{ background: "rgba(255,255,255,0.04)", border: `1px solid ${rock.color}40` }}>
                      <p className="text-[9px] font-bold uppercase tracking-widest" style={{ color: rock.color }}>{side}</p>
                      <motion.div
                        animate={logIdx > 0 ? { scale: [1, 1.2, 1] } : {}}
                        transition={{ duration: 0.4 }}
                        className="text-4xl">
                        {rock.emoji}
                      </motion.div>
                      <p className="text-xs font-bold text-white">{rock.name}</p>
                      <div className="h-1.5 w-full rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.1)" }}>
                        <motion.div className="h-full rounded-full" animate={{ width: `${pct}%` }} transition={{ duration: 0.5 }}
                          style={{ background: pct > 50 ? "#00D68F" : pct > 25 ? "#F5B642" : "#ef4444" }} />
                      </div>
                      <p className="text-[9px] text-white/40">{hp}/{rock.hp} HP</p>
                    </div>
                  );
                })}
              </div>

              {/* Battle log */}
              <div className="rounded-2xl p-3 space-y-1.5 min-h-[90px]"
                style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.08)" }}>
                <AnimatePresence mode="popLayout">
                  {battle.log.slice(0, logIdx).slice(-3).map((entry, i) => (
                    <motion.div key={entry.round}
                      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      className="text-[10px] text-white/70">
                      <span style={{ color: player.color }}>⚔️ {entry.aAtk}</span>
                      <span className="text-white/30 mx-1">vs</span>
                      <span style={{ color: rival.color }}>{entry.bAtk} ⚔️</span>
                      <span className="text-white/40 ml-1">(-{entry.bDmg} / -{entry.aDmg})</span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>
          )}

          {/* RESULT */}
          {phase === "result" && battle && player && rival && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-4 py-2">
              <motion.div animate={{ rotate: [0, -10, 10, -10, 10, 0] }} transition={{ duration: 0.6 }}
                className="text-6xl">{battle.winner === "player" ? "🏆" : "💀"}</motion.div>
              <div>
                <p className="text-lg font-black text-white">
                  {battle.winner === "player" ? `${player.name} Wins!` : `${rival.name} Wins!`}
                </p>
                <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>
                  {battle.winner === "player"
                    ? "Your rock dominated! Shard stolen. +75 XP"
                    : "Tough loss. Keep hunting stronger specimens. +25 XP"}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 rounded-2xl" style={{ background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.2)" }}>
                  <p className="text-lg font-black" style={{ color: "#00D68F" }}>{battle.winner === "player" ? "+75" : "+25"}</p>
                  <p className="text-[9px] text-white/40 uppercase tracking-wider">XP Earned</p>
                </div>
                <div className="p-3 rounded-2xl" style={{ background: "rgba(141,124,255,0.08)", border: "1px solid rgba(141,124,255,0.2)" }}>
                  <p className="text-lg font-black" style={{ color: "#8D7CFF" }}>
                    {battle.winner === "player" ? player.emoji : rival.emoji}
                  </p>
                  <p className="text-[9px] text-white/40 uppercase tracking-wider">Winner</p>
                </div>
              </div>
              <button onClick={handleClaim}
                className="w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest"
                style={{ background: "linear-gradient(135deg, #00D68F, #7AE7FF)", color: "#000" }}>
                Claim Reward
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}