import React from "react";
import { Activity } from "lucide-react";

const AGENT_COLORS = {
  MDA: "#C4B5FD",
  SRSA: "#7AE7FF",
  FTPA: "#00D68F",
  EMVA: "#F5B642",
  KSA: "#FF6B9D",
};

/** Live reasoning log emitted by each agent during a synthesis run. */
export default function AgentTelemetryPanel({ telemetry, running }) {
  return (
    <div className="rounded-2xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <div className="flex items-center gap-2 mb-3">
        <Activity className="w-4 h-4" style={{ color: running ? "#00D68F" : "rgba(255,255,255,0.35)" }} />
        <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.5)" }}>
          Agent telemetry
        </span>
      </div>

      {!telemetry?.length && (
        <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>
          {running ? "Agents working…" : "Run a synthesis to see agent reasoning."}
        </p>
      )}

      <div className="flex flex-col gap-2">
        {(telemetry || []).map((t, i) => (
          <div key={i} className="flex gap-2.5 items-start">
            <span
              className="text-[10px] font-black px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5"
              style={{ background: `${AGENT_COLORS[t.agent] || "#888"}22`, color: AGENT_COLORS[t.agent] || "#888" }}
            >
              {t.agent}
            </span>
            <span className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.72)" }}>{t.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}