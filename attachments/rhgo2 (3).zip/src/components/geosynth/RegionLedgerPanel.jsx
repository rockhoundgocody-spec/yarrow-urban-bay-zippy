import React from "react";
import { BookLock } from "lucide-react";

const STATUS_COLOR = {
  active: "#00D68F",
  inferred: "#7AE7FF",
  exploratory: "rgba(255,255,255,0.4)",
};

/**
 * What this region has learned from the field, and how much ceiling that
 * earned. Empty state is meaningful here: no verified beliefs means the
 * synthesis is running purely on the static catalogue.
 */
export default function RegionLedgerPanel({ ledger }) {
  if (!ledger) return null;
  const { beliefs = [], ceiling_lift = 0, confirmed = 0, region_key } = ledger;

  return (
    <div
      className="rounded-2xl p-4"
      style={{
        background: "linear-gradient(160deg, rgba(12,8,28,0.94) 0%, rgba(8,12,22,0.92) 100%)",
        border: "1px solid rgba(141,124,255,0.20)",
      }}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <BookLock className="w-3.5 h-3.5" style={{ color: "#8D7CFF" }} />
          <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>
            Region ledger {region_key ? `· ${region_key}` : ""}
          </span>
        </div>
        <span className="text-[12px] font-black" style={{ color: ceiling_lift > 0 ? "#00D68F" : "rgba(255,255,255,0.3)" }}>
          {ceiling_lift > 0 ? `+${ceiling_lift}% ceiling` : "no lift yet"}
        </span>
      </div>

      {beliefs.length === 0 ? (
        <p className="text-[12px]" style={{ color: "rgba(255,255,255,0.38)" }}>
          Nothing field-verified here yet — this synthesis ran on the catalogue alone. Report a find below and the ceiling moves for everyone.
        </p>
      ) : (
        <div className="space-y-2">
          {beliefs.slice(0, 8).map((b) => (
            <div key={b.id || b.canonical_name} className="border-b border-white/5 pb-2 last:border-0 last:pb-0">
              <div className="flex items-center gap-2">
                <span
                  className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded"
                  style={{
                    color: STATUS_COLOR[b.epistemic_status] || "rgba(255,255,255,0.4)",
                    background: `${STATUS_COLOR[b.epistemic_status] || "#888"}18`,
                  }}
                >
                  {b.epistemic_status}
                </span>
                <span className="text-[13px] text-white truncate">{b.claim}</span>
              </div>
              {b.why_it_matters && (
                <div className="text-[11px] mt-0.5" style={{ color: "rgba(255,255,255,0.42)" }}>
                  {b.why_it_matters}
                </div>
              )}
            </div>
          ))}
          <div className="text-[11px] pt-1" style={{ color: "rgba(255,255,255,0.35)" }}>
            {confirmed} field-verified belief{confirmed === 1 ? "" : "s"} standing in this region.
          </div>
        </div>
      )}
    </div>
  );
}