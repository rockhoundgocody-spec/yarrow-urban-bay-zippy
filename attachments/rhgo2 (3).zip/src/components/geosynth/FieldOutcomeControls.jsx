import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Check, X, Loader2 } from "lucide-react";

/**
 * Confirm / refute a proposed target at a location. Each independent report
 * changes the region's belief state and its permanent confidence ceiling.
 */
export default function FieldOutcomeControls({ targets = [], latitude, longitude, onRecorded }) {
  const [busy, setBusy] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const submit = async (subject, outcome) => {
    setBusy(`${subject}:${outcome}`);
    setError(null);
    try {
      const res = await base44.functions.invoke("recordFieldOutcome", {
        latitude, longitude, subject, outcome,
        belief_type: outcome === "refuted" ? "absence" : "mineral_occurrence",
      });
      const data = res?.data ?? res;
      setResult(data);
      onRecorded?.(data);
    } catch (e) {
      setError(e?.message || "Could not record that outcome.");
    } finally {
      setBusy(null);
    }
  };

  if (!targets.length || !Number.isFinite(latitude)) return null;

  return (
    <div className="rounded-2xl p-4" style={{ background: "rgba(0,214,143,0.05)", border: "1px solid rgba(0,214,143,0.22)" }}>
      <div className="text-[11px] font-bold uppercase tracking-wider mb-1" style={{ color: "rgba(255,255,255,0.45)" }}>
        Report what you actually found
      </div>
      <p className="text-[11px] mb-3" style={{ color: "rgba(255,255,255,0.40)" }}>
        Every independent report moves this region's ceiling permanently — up when confirmed, down when refuted.
      </p>

      <div className="space-y-2">
        {targets.slice(0, 6).map((t) => (
          <div key={t} className="flex items-center justify-between gap-2">
            <span className="text-[13px] text-white truncate">{t}</span>
            <div className="flex gap-1.5 flex-shrink-0">
              <button
                onClick={() => submit(t, "confirmed")}
                disabled={!!busy}
                className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1 disabled:opacity-40"
                style={{ background: "rgba(0,214,143,0.14)", border: "1px solid rgba(0,214,143,0.35)", color: "#4AE5A8", minHeight: 32, minWidth: 32 }}
              >
                {busy === `${t}:confirmed` ? <Loader2 className="w-3 h-3 animate-spin" /> : <Check className="w-3 h-3" />}
                Found
              </button>
              <button
                onClick={() => submit(t, "refuted")}
                disabled={!!busy}
                className="px-2.5 py-1.5 rounded-lg text-[11px] font-bold flex items-center gap-1 disabled:opacity-40"
                style={{ background: "rgba(255,80,80,0.10)", border: "1px solid rgba(255,80,80,0.28)", color: "#FF8A8A", minHeight: 32, minWidth: 32 }}
              >
                {busy === `${t}:refuted` ? <Loader2 className="w-3 h-3 animate-spin" /> : <X className="w-3 h-3" />}
                Not there
              </button>
            </div>
          </div>
        ))}
      </div>

      {result && (
        <div className="mt-3 text-[11px]" style={{ color: "#4AE5A8" }}>{result.message}</div>
      )}
      {error && <div className="mt-3 text-[11px]" style={{ color: "#FF8A8A" }}>{error}</div>}
    </div>
  );
}