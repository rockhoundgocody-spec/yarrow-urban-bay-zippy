import React from "react";
import { Route, TrendingUp } from "lucide-react";

/** MCTS route output: ordered stops with per-leg distance and information gain. */
export default function RoutePlanPanel({ plan }) {
  if (!plan?.route?.length) return null;

  return (
    <div className="rounded-2xl p-4" style={{ background: "rgba(0,214,143,0.05)", border: "1px solid rgba(0,214,143,0.20)" }}>
      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Route className="w-4 h-4" style={{ color: "#00D68F" }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.5)" }}>
            Planned route
          </span>
        </div>
        <span className="text-xs" style={{ color: "rgba(0,214,143,0.8)" }}>
          {plan.total_km} km{plan.total_gain_m > 0 ? ` · ${plan.total_gain_m} m climb` : ""} · depth {plan.search_depth} · {plan.iterations} rollouts
        </span>
      </div>

      <ol className="flex flex-col gap-2">
        {plan.route.map((stop, i) => (
          <li key={stop.id} className="flex items-center gap-3">
            <span
              className="w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-black flex-shrink-0"
              style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.4)", color: "#00D68F" }}
            >
              {i + 1}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold truncate" style={{ color: "rgba(255,255,255,0.9)" }}>{stop.name}</div>
              <div className="text-[11px]" style={{ color: "rgba(255,255,255,0.4)" }}>
                {stop.leg_km} km leg · value {stop.value}
                {stop.elevation_m !== undefined && ` · ${stop.elevation_m} m, ${stop.slope_deg}°`}
              </div>
            </div>
            <span className="flex items-center gap-1 text-[11px] flex-shrink-0" style={{ color: "#FF6B9D" }}>
              <TrendingUp className="w-3 h-3" />
              ΔI {stop.information_gain.toFixed(2)}
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
}