import React from "react";
import { Mountain, Compass } from "lucide-react";

const cardStyle = { background: "rgba(245,182,66,0.05)", border: "1px solid rgba(245,182,66,0.20)" };

/** SRTM DEM geomorphometry — measured elevation, slope and derived exposure proxy. */
export default function TerrainPanel({ summary, candidates }) {
  if (!summary) return null;

  if (!summary.resolved) {
    return (
      <div className="rounded-2xl p-4" style={cardStyle}>
        <div className="flex items-center gap-2 mb-1">
          <Mountain className="w-4 h-4" style={{ color: "#F5B642" }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.5)" }}>Terrain</span>
        </div>
        <p className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>
          Elevation model unreachable for this region. Routing ran without terrain weighting rather than with estimated ground.
        </p>
      </div>
    );
  }

  const withTerrain = (candidates || []).filter((c) => c.terrain);
  const steepest = [...withTerrain].sort((a, b) => b.terrain.slope_deg - a.terrain.slope_deg).slice(0, 3);

  return (
    <div className="rounded-2xl p-4" style={cardStyle}>
      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Mountain className="w-4 h-4" style={{ color: "#F5B642" }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.5)" }}>Terrain</span>
        </div>
        <span className="text-[11px]" style={{ color: "rgba(245,182,66,0.75)" }}>
          {summary.source} · {summary.resolved}/{summary.requested} resolved
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-3">
        <div className="rounded-xl px-3 py-2 text-center" style={{ background: "rgba(0,0,0,0.25)" }}>
          <div className="text-base font-bold" style={{ color: "#F5B642" }}>{summary.mean_slope_deg}°</div>
          <div className="text-[10px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>Mean slope</div>
        </div>
        <div className="rounded-xl px-3 py-2 text-center" style={{ background: "rgba(0,0,0,0.25)" }}>
          <div className="text-base font-bold" style={{ color: "#F5B642" }}>{summary.mean_exposure_proxy}</div>
          <div className="text-[10px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>Exposure proxy</div>
        </div>
      </div>

      <ul className="flex flex-col gap-1.5">
        {steepest.map((c) => (
          <li key={c.id} className="flex items-center gap-2 text-[11px]">
            <Compass className="w-3 h-3 flex-shrink-0" style={{ color: "rgba(245,182,66,0.7)" }} />
            <span className="flex-1 truncate" style={{ color: "rgba(255,255,255,0.8)" }}>{c.name}</span>
            <span style={{ color: "rgba(255,255,255,0.5)" }}>
              {c.terrain.elevation_m} m · {c.terrain.slope_deg}° · {c.terrain.landform}
            </span>
          </li>
        ))}
      </ul>

      <p className="text-[10px] mt-2.5 italic" style={{ color: "rgba(255,255,255,0.35)" }}>
        Elevation, slope, aspect and relief are measured from the DEM. Exposure is a slope-and-relief proxy for bedrock exposure, not a survey.
      </p>
    </div>
  );
}