import React from "react";
import { ShieldAlert, ShieldCheck, Shield, Swords, FlaskConical } from "lucide-react";

const VERDICT = {
  supported:   { label: "Supported",   color: "#00D68F", Icon: ShieldCheck },
  provisional: { label: "Provisional", color: "#F5B642", Icon: Shield },
  unsupported: { label: "Unsupported", color: "#FF6B9D", Icon: ShieldAlert },
};

const SEVERITY_COLOR = { high: "#FF6B9D", medium: "#F5B642", low: "rgba(255,255,255,0.5)" };

/**
 * The falsification gate: what the records actually support, what the
 * adversarial critic could not refute, and what would overturn the result.
 */
export default function FalsificationPanel({ falsification, critique }) {
  if (!falsification) return null;
  const v = VERDICT[falsification.verdict] ?? VERDICT.provisional;
  const { Icon } = v;

  return (
    <div className="rounded-2xl p-4 flex flex-col gap-3" style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${v.color}33` }}>
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4" style={{ color: v.color }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.5)" }}>Falsification</span>
        </div>
        <span className="text-[11px] font-bold px-2 py-1 rounded-lg" style={{ background: `${v.color}1F`, color: v.color }}>
          {v.label}
        </span>
      </div>

      <div className="flex items-center gap-2 text-xs" style={{ color: "rgba(255,255,255,0.7)" }}>
        <span>Confidence</span>
        <span style={{ color: "rgba(255,255,255,0.4)", textDecoration: falsification.final_confidence < falsification.proposed_confidence ? "line-through" : "none" }}>
          {falsification.proposed_confidence}%
        </span>
        {falsification.final_confidence < falsification.proposed_confidence && (
          <span className="font-bold" style={{ color: v.color }}>→ {falsification.final_confidence}%</span>
        )}
        <span style={{ color: "rgba(255,255,255,0.35)" }}>
          · ceiling {falsification.confidence_ceiling}% · evidence {Math.round(falsification.evidence_density * 100)}%
        </span>
      </div>

      {falsification.ungrounded_targets?.length > 0 && (
        <p className="text-xs" style={{ color: "#FF6B9D" }}>
          Ungrounded targets: {falsification.ungrounded_targets.join(", ")}
        </p>
      )}

      {falsification.findings?.length > 0 && (
        <ul className="flex flex-col gap-2">
          {falsification.findings.map((f, i) => (
            <li key={i} className="text-[11px] leading-relaxed">
              <span className="font-bold" style={{ color: SEVERITY_COLOR[f.severity] }}>{f.claim}</span>
              <span style={{ color: "rgba(255,255,255,0.6)" }}> — {f.reason}</span>
              <div style={{ color: "rgba(255,255,255,0.4)" }}>Resolve by: {f.resolving_observation}</div>
            </li>
          ))}
        </ul>
      )}

      {critique?.refutation_attempts?.length > 0 && (
        <div className="flex flex-col gap-1.5 pt-1" style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-1.5 mt-1">
            <Swords className="w-3.5 h-3.5" style={{ color: "#8D7CFF" }} />
            <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>Adversarial review</span>
            {falsification.refutation_survival && (
              <span className="text-[11px]" style={{ color: "rgba(255,255,255,0.4)" }}>
                {falsification.refutation_survival.survived}/{falsification.refutation_survival.attempted} survived
              </span>
            )}
          </div>
          {critique.refutation_attempts.map((r, i) => (
            <div key={i} className="text-[11px] leading-relaxed">
              <span style={{ color: r.survives ? "#00D68F" : "#FF6B9D" }}>{r.survives ? "survives" : "refuted"}</span>
              <span style={{ color: "rgba(255,255,255,0.75)" }}> · {r.claim}</span>
              <div style={{ color: "rgba(255,255,255,0.45)" }}>{r.challenge}</div>
            </div>
          ))}
          {critique.strongest_alternative && (
            <p className="text-[11px] mt-1" style={{ color: "rgba(255,255,255,0.6)" }}>
              <b style={{ color: "#8D7CFF" }}>Strongest alternative:</b> {critique.strongest_alternative}
            </p>
          )}
        </div>
      )}

      {critique?.falsifiable_predictions?.length > 0 && (
        <div className="flex flex-col gap-1 pt-1" style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-1.5 mt-1">
            <FlaskConical className="w-3.5 h-3.5" style={{ color: "#7AE7FF" }} />
            <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.45)" }}>Test in the field</span>
          </div>
          {critique.falsifiable_predictions.map((p, i) => (
            <p key={i} className="text-[11px]" style={{ color: "rgba(255,255,255,0.65)" }}>· {p}</p>
          ))}
          {critique.overturning_observation && (
            <p className="text-[11px] mt-1 italic" style={{ color: "rgba(255,107,157,0.85)" }}>
              Would overturn this: {critique.overturning_observation}
            </p>
          )}
        </div>
      )}
    </div>
  );
}