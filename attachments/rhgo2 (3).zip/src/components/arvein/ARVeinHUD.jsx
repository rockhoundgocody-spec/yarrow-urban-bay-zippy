import React, { memo } from "react";
import { motion } from "framer-motion";
import { Sparkles, CheckCircle2 } from "lucide-react";

// HUD — primary vein card revealed on target lock
const HUDTopResult = memo(function HUDTopResult({ result, logged }) {
  if (!result) return null;
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0, y: 10 }}
      animate={{ scale: 1, opacity: 1, y: 0 }}
      transition={{ type: "spring", stiffness: 260, damping: 22 }}
      className="absolute inset-x-5 top-[18%] z-20 pointer-events-none"
    >
      <div className="rh-living-glass rounded-2xl p-4 text-center" style={{
        background: `linear-gradient(160deg, ${result.color}22 0%, rgba(8,6,18,0.78) 100%)`,
        border: `1px solid ${result.color}66`,
        boxShadow: `0 8px 40px rgba(0,0,0,0.6), 0 0 32px ${result.color}33, inset 0 1px 0 rgba(255,255,255,0.06)`,
        backdropFilter: "blur(18px)",
      }}>
        <div className="flex items-center justify-center gap-2 mb-1.5">
          <span className="text-[9px] font-black tracking-[0.2em] uppercase" style={{ color: result.color }}>Primary Vein</span>
          <Sparkles className="w-3 h-3" style={{ color: result.color }} />
        </div>
        <div className="text-3xl mb-1" style={{ filter: `drop-shadow(0 0 10px ${result.color}88)` }}>{result.icon}</div>
        <div className="font-bold text-white text-lg leading-tight">{result.label}</div>

        {/* confidence meter */}
        <div className="mt-2.5 mx-auto max-w-[160px]">
          <div className="flex items-center justify-between text-[10px] mb-1">
            <span className="text-white/40 uppercase tracking-wider">Confidence</span>
            <span className="font-bold" style={{ color: result.color }}>{result.confidence}%</span>
          </div>
          <div className="h-1 rounded-full bg-white/10 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${result.color}, #7AE7FF)`, boxShadow: `0 0 8px ${result.color}` }}
              initial={{ width: 0 }}
              animate={{ width: `${result.confidence}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            />
          </div>
        </div>

        {logged && (
          <motion.div
            initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}
            className="mt-2.5 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold"
            style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.4)", color: "#4AE5A8" }}
          >
            <CheckCircle2 className="w-3 h-3" /> Saved to Collection
          </motion.div>
        )}
      </div>
    </motion.div>
  );
});

export default HUDTopResult;