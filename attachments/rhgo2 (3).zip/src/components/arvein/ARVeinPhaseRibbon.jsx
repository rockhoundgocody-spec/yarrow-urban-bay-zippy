import React, { memo } from "react";
import { motion } from "framer-motion";

// The 4 chapters of the scanning transit
const CHAPTERS = [
  { key: "calibrate", label: "Calibrate",     sub: "Acquiring geological context" },
  { key: "sweep",     label: "Spectral Sweep", sub: "Scanning mineral signature" },
  { key: "strata",    label: "Strata Read",    sub: "Reading depth horizons" },
  { key: "lock",      label: "Vein Lock",      sub: "Converging on target" },
];

// Phase transit ribbon — journey progress through the scan chapters, with
// chapter index and an active-chapter time pulse.
const PhaseRibbon = memo(function PhaseRibbon({ phase }) {
  const activeIdx = Math.max(0, CHAPTERS.findIndex(c => c.key === phase));
  const active = CHAPTERS[activeIdx] || CHAPTERS[0];

  return (
    <div className="absolute inset-x-0 top-[39%] flex flex-col items-center gap-2.5 pointer-events-none" style={{ zIndex: 20 }}>
      {/* chapter label + index */}
      <motion.div
        key={active.key}
        initial={{ opacity: 0, y: 6 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="flex flex-col items-center"
      >
        <div className="flex items-center gap-2">
          <span className="text-[9px] font-bold tracking-[0.18em] uppercase text-white/40">
            CH {activeIdx + 1} / {CHAPTERS.length}
          </span>
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase rh-glow-cyan" style={{ color: "#7AE7FF" }}>
            {active.label}
          </span>
        </div>
        <span className="text-[9px] text-white/45 mt-0.5">{active.sub}</span>
      </motion.div>

      {/* transit line with chapter nodes */}
      <div className="relative w-[230px] h-3 flex items-center">
        {/* base line */}
        <div className="absolute left-2 right-2 h-px bg-white/12" />
        {/* transit progress fill */}
        <motion.div
          className="absolute left-2 h-px"
          style={{ background: "linear-gradient(90deg, #8D7CFF, #7AE7FF)", boxShadow: "0 0 8px rgba(122,231,255,0.7)" }}
          animate={{ width: `calc((100% - 16px) * ${activeIdx / (CHAPTERS.length - 1)})` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
        {/* moving shimmer along the line */}
        <motion.div
          className="absolute left-2 right-2 h-px overflow-hidden"
          style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent)", backgroundSize: "60px 100%" }}
          animate={{ backgroundPosition: ["0px 0px", "230px 0px"] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: "linear" }}
        />
        {/* chapter nodes */}
        {CHAPTERS.map((c, i) => {
          const done = i < activeIdx;
          const current = i === activeIdx;
          return (
            <div key={c.key} className="relative z-10 flex-1 flex justify-center">
              <motion.div
                className="rounded-full"
                animate={{
                  scale: current ? 1.3 : 1,
                  boxShadow: current
                    ? "0 0 12px rgba(122,231,255,0.9), 0 0 24px rgba(141,124,255,0.5)"
                    : done
                      ? "0 0 6px rgba(0,255,170,0.6)"
                      : "0 0 0px rgba(255,255,255,0)",
                }}
                transition={{ duration: 0.3 }}
                style={{
                  width: current ? 8 : 6,
                  height: current ? 8 : 6,
                  background: current ? "#7AE7FF" : done ? "#00ffaa" : "rgba(255,255,255,0.25)",
                }}
              />
              {/* active node breathing ring */}
              {current && (
                <motion.div
                  className="absolute rounded-full"
                  style={{ border: "1px solid #7AE7FF", width: 14, height: 14, top: -3, left: "50%", marginLeft: -7 }}
                  animate={{ scale: [1, 1.8], opacity: [0.7, 0] }}
                  transition={{ duration: 1.4, repeat: Infinity, ease: "easeOut" }}
                />
              )}
            </div>
          );
        })}
      </div>

      {/* active chapter time pulse — conveys elapsed time in the current chapter */}
      <div className="relative w-[180px] h-1 rounded-full bg-white/8 overflow-hidden">
        <motion.div
          className="absolute left-0 top-0 bottom-0 rounded-full"
          style={{ background: "linear-gradient(90deg, #8D7CFF, #7AE7FF)", boxShadow: "0 0 6px rgba(122,231,255,0.6)" }}
          animate={{ width: ["0%", "100%"] }}
          transition={{ duration: 0.8, repeat: Infinity, ease: "linear", key: active.key }}
        />
      </div>
    </div>
  );
});

export default PhaseRibbon;