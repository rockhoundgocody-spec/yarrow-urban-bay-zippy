import React, { memo } from "react";
import { motion } from "framer-motion";
import ARVeinCrossSection from "./ARVeinCrossSection";

// Spectral mineral palette for strata bands
const SPECTRAL = ["#8D7CFF", "#7AE7FF", "#00ffaa", "#f59e0b", "#f43f5e", "#a855f7"];

// ── Crystal corner reticle ───────────────────────────────────────────────────
const CornerReticle = memo(function CornerReticle() {
  const corners = [
    { c: "top-5 left-5 border-t-[1.5px] border-l-[1.5px] rounded-tl-xl", g: "top-4 left-4" },
    { c: "top-5 right-5 border-t-[1.5px] border-r-[1.5px] rounded-tr-xl", g: "top-4 right-4" },
    { c: "bottom-5 left-5 border-b-[1.5px] border-l-[1.5px] rounded-bl-xl", g: "bottom-4 left-4" },
    { c: "bottom-5 right-5 border-b-[1.5px] border-r-[1.5px] rounded-br-xl", g: "bottom-4 right-4" },
  ];
  return (
    <>
      {corners.map((b, i) => (
        <div key={i} className={`absolute w-7 h-7 ${b.c}`} style={{ borderColor: "rgba(141,124,255,0.55)" }}>
          <div className={`absolute w-1 h-1 rounded-full ${b.g}`} style={{ background: "#7AE7FF", boxShadow: "0 0 8px rgba(122,231,255,0.9)" }} />
        </div>
      ))}
    </>
  );
});

// ── Scan beam — amethyst→cyan with glow trail ────────────────────────────────
const ScanBeam = memo(function ScanBeam() {
  return (
    <>
      <motion.div
        className="absolute left-5 right-5 h-px"
        style={{ background: "linear-gradient(90deg, transparent, #8D7CFF 30%, #7AE7FF 70%, transparent)", boxShadow: "0 0 16px rgba(122,231,255,0.7), 0 0 32px rgba(141,124,255,0.4)" }}
        initial={{ top: "12%" }}
        animate={{ top: "88%" }}
        transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }}
      />
      <motion.div
        className="absolute left-5 right-5 h-16"
        style={{ background: "linear-gradient(to bottom, rgba(141,124,255,0.10), transparent)" }}
        initial={{ top: "12%" }}
        animate={{ top: "88%" }}
        transition={{ duration: 2.6, repeat: Infinity, ease: "linear" }}
      />
    </>
  );
});

// ── Spectral strata — drifting mineral bands (vein cross-section transit) ────
const SpectralStrata = memo(function SpectralStrata({ phase }) {
  const intense = phase === "strata";
  const bands = [
    { color: SPECTRAL[0], top: "22%", h: 26, dur: 7,  delay: 0,   amp: 60 },
    { color: SPECTRAL[1], top: "38%", h: 18, dur: 5.5, delay: 0.4, amp: 80 },
    { color: SPECTRAL[4], top: "54%", h: 32, dur: 8,  delay: 0.8, amp: 50 },
    { color: SPECTRAL[2], top: "68%", h: 20, dur: 6,  delay: 0.2, amp: 70 },
    { color: SPECTRAL[3], top: "80%", h: 14, dur: 4.5, delay: 0.6, amp: 90 },
  ];
  return (
    <div className="absolute inset-0 overflow-hidden">
      {bands.map((b, i) => (
        <motion.div
          key={i}
          className="absolute left-0 right-0"
          style={{
            top: b.top,
            height: b.h,
            background: `linear-gradient(90deg, transparent, ${b.color}${intense ? "33" : "1f"}, ${b.color}${intense ? "22" : "11"}, transparent)`,
            filter: "blur(6px)",
            opacity: intense ? 0.9 : 0.6,
            mixBlendMode: "screen",
          }}
          animate={{ x: [-b.amp, b.amp, -b.amp] }}
          transition={{ duration: b.dur, repeat: Infinity, ease: "easeInOut", delay: b.delay }}
        />
      ))}
      {/* vertical drift overlay — sense of forward transit */}
      <motion.div
        className="absolute inset-0"
        style={{ background: "radial-gradient(ellipse at 50% 50%, transparent 40%, rgba(141,124,255,0.05) 100%)" }}
        animate={{ opacity: [0.4, 0.7, 0.4] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
      />
    </div>
  );
});

// ── World anchors — crystal pins with pulse rings ────────────────────────────
const WorldAnchors = memo(function WorldAnchors({ anchors }) {
  if (!anchors?.length) return null;
  return (
    <>
      {anchors.map(anchor => (
        <motion.div
          key={anchor.id}
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: anchor.id * 0.12, type: "spring", stiffness: 300, damping: 18 }}
          className="absolute flex items-center justify-center"
          style={{
            left: `${anchor.x}%`,
            top: `${anchor.y}%`,
            width: anchor.radius * 2,
            height: anchor.radius * 2,
            marginLeft: -anchor.radius,
            marginTop: -anchor.radius,
            borderRadius: "50%",
            background: `${anchor.color}14`,
            border: `1.5px solid ${anchor.color}80`,
            boxShadow: `0 0 24px ${anchor.color}55, inset 0 0 12px ${anchor.color}22`,
            backdropFilter: "blur(2px)",
          }}
        >
          <motion.div
            animate={{ scale: [1, 1.5, 1], opacity: [0.9, 0.35, 0.9] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
            className="w-2 h-2 rounded-full"
            style={{ background: anchor.color, boxShadow: `0 0 10px ${anchor.color}` }}
          />
          <motion.div
            className="absolute inset-0 rounded-full"
            style={{ border: `1px solid ${anchor.color}` }}
            animate={{ scale: [1, 1.8], opacity: [0.6, 0] }}
            transition={{ duration: 2.6, repeat: Infinity, ease: "easeOut", delay: anchor.id * 0.2 }}
          />
        </motion.div>
      ))}
    </>
  );
});

// ── Main overlay field ───────────────────────────────────────────────────────
const ScanOverlay = memo(function ScanOverlay({ scanning, locked, scanPhase, anchors }) {
  // Chapter handoff: spectral bands own "sweep"; cross-section owns "strata" onward.
  // Rendering both during strata stacked two strata layers → doubled look.
  const showStrata = scanPhase === "sweep";
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 10 }}>
      <CornerReticle />

      {/* Geological grid — amethyst, subtle */}
      <div className="absolute inset-0 opacity-[0.06]" style={{
        backgroundImage: "linear-gradient(rgba(141,124,255,0.4) 1px, transparent 1px), linear-gradient(90deg, rgba(122,231,255,0.3) 1px, transparent 1px)",
        backgroundSize: "44px 44px"
      }} />

      {/* Spectral strata — vein cross-section transit during sweep/strata */}
      {showStrata && <SpectralStrata phase={scanPhase} />}

      {/* Scan beam during active scanning */}
      {scanning && <ScanBeam />}

      {/* Geological vein cross-section — builds during strata, settles on lock */}
      {(scanPhase === "strata" || locked) && (
        <ARVeinCrossSection phase={scanPhase} locked={locked} />
      )}

      {/* World anchors on lock */}
      {locked && <WorldAnchors anchors={anchors} />}
    </div>
  );
});

export default ScanOverlay;