import React, { memo } from "react";
import { motion } from "framer-motion";

// Result row — mineral accent rail + confidence crystal fill
const ResultCard = memo(function ResultCard({ vein, rank }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: rank * 0.07, type: "spring", stiffness: 300, damping: 24 }}
      className="rh-living-glass flex items-stretch gap-0 rounded-xl overflow-hidden"
      style={{
        background: rank === 0 ? `${vein.color}14` : "rgba(12,8,24,0.55)",
        border: `1px solid ${rank === 0 ? vein.color + "55" : "rgba(255,255,255,0.07)"}`,
        backdropFilter: "blur(14px)",
      }}
    >
      <div className="w-1 flex-shrink-0" style={{ background: vein.color, boxShadow: `0 0 8px ${vein.color}88` }} />
      <div className="flex items-center gap-3 p-3 flex-1 min-w-0">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 text-base"
          style={{ background: `${vein.color}1a`, border: `1px solid ${vein.color}44` }}>
          {vein.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="text-white text-xs font-semibold truncate">{vein.label}</span>
            <span className="text-xs font-bold shrink-0" style={{ color: vein.color }}>{vein.confidence}%</span>
          </div>
          <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
            <motion.div
              className="h-full rounded-full"
              style={{ background: `linear-gradient(90deg, ${vein.color}, #7AE7FF)`, boxShadow: `0 0 6px ${vein.color}66` }}
              initial={{ width: 0 }}
              animate={{ width: `${Math.max(4, vein.confidence)}%` }}
              transition={{ duration: 0.7, delay: rank * 0.07 + 0.15, ease: "easeOut" }}
            />
          </div>
          {rank === 0 && (
            <div className="flex flex-wrap gap-1 mt-1.5">
              {vein.minerals.map(m => (
                <span key={m} className="text-[9px] px-1.5 py-0.5 rounded-full" style={{ background: `${vein.color}20`, color: vein.color }}>{m}</span>
              ))}
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-white/50">H: {vein.hardness}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-white/10 text-white/50">{vein.crystal_system}</span>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
});

export default ResultCard;