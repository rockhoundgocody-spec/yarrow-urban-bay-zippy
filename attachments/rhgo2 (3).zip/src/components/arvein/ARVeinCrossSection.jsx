import React, { memo } from "react";
import { motion } from "framer-motion";

// Geological horizons — bottom (deep) to top (surface)
const HORIZONS = [
  { id: "wall",     label: "Wall Rock",    color: "#6E7681", depth: "6–8m", opacity: 0.30 },
  { id: "primary",  label: "Primary Vein", color: "#8D7CFF", depth: "4–6m", opacity: 0.55 },
  { id: "oxide",    label: "Oxide Zone",   color: "#f59e0b", depth: "2–4m", opacity: 0.40 },
  { id: "surface",  label: "Surface",      color: "#e2e8f0", depth: "0–2m", opacity: 0.28 },
];

// Vein cross-section that builds horizon-by-horizon during the Strata chapter,
// then settles into a faint parallax field on Vein Lock.
const ARVeinCrossSection = memo(function ARVeinCrossSection({ phase, locked }) {
  const building = phase === "strata";
  // marker rises (descends in depth) as the scan progresses
  const markerTop = locked ? "18%" : building ? ["92%", "60%", "34%", "18%"] : "92%";
  const markerStages = building ? [0, 0.34, 0.67, 1] : undefined;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Horizon stack — centered lower field */}
      <div className="absolute left-[10%] right-[10%] bottom-[8%] flex flex-col-reverse gap-1.5">
        {HORIZONS.map((h, i) => {
          // build order: deepest first (bottom), so index 0 (wall) builds first
          const buildDelay = building ? i * 0.35 : 0;
          return (
            <motion.div
              key={h.id}
              className="relative rounded-lg overflow-hidden"
              style={{
                height: i === 1 ? 34 : 22, // primary vein thicker
                background: `linear-gradient(90deg, transparent, ${h.color}${Math.round(h.opacity * 255).toString(16).padStart(2, "0")}, ${h.color}10, transparent)`,
                border: `1px solid ${h.color}30`,
                boxShadow: i === 1 ? `0 0 18px ${h.color}40, inset 0 0 12px ${h.color}20` : "none",
                mixBlendMode: "screen",
              }}
              initial={{ scaleX: 0.4, opacity: 0 }}
              animate={{ scaleX: 1, opacity: locked ? 0.55 : (building ? 0.9 : 0) }}
              transition={{
                delay: buildDelay,
                duration: building ? 0.5 : 0.6,
                ease: "easeOut",
              }}
            >
              {/* horizon label chip */}
              <motion.span
                className="absolute left-2 top-1/2 -translate-y-1/2 text-[8px] font-bold tracking-[0.15em] uppercase whitespace-nowrap"
                style={{ color: h.color, textShadow: `0 0 6px ${h.color}99` }}
                initial={{ opacity: 0 }}
                animate={{ opacity: locked ? 0.5 : (building ? 0.85 : 0) }}
                transition={{ delay: buildDelay + 0.2, duration: 0.3 }}
              >
                {h.label} · {h.depth}
              </motion.span>

              {/* mineral flecks in primary vein */}
              {i === 1 && (
                <div className="absolute inset-0">
                  {Array.from({ length: 5 }).map((_, k) => (
                    <motion.div
                      key={k}
                      className="absolute w-1 h-1 rounded-full"
                      style={{
                        left: `${15 + k * 18}%`,
                        top: `${30 + (k % 2) * 40}%`,
                        background: "#7AE7FF",
                        boxShadow: "0 0 4px #7AE7FF",
                      }}
                      animate={{ opacity: [0.3, 1, 0.3] }}
                      transition={{ duration: 1.4, repeat: Infinity, delay: k * 0.2 }}
                    />
                  ))}
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Depth gauge — right edge */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 h-[42%] flex flex-col items-center" style={{ width: 28 }}>
        {/* gauge track */}
        <div className="relative w-px h-full" style={{ background: "linear-gradient(to bottom, rgba(122,231,255,0.4), rgba(141,124,255,0.15))" }}>
          {/* tick marks */}
          {[0, 25, 50, 75, 100].map(p => (
            <div key={p} className="absolute -left-1 w-2 h-px" style={{ top: `${p}%`, background: "rgba(255,255,255,0.2)" }} />
          ))}
          {/* depth marker */}
          <motion.div
            className="absolute -left-2 w-3 h-3 rounded-full"
            style={{
              background: "#7AE7FF",
              boxShadow: "0 0 10px #7AE7FF, 0 0 20px rgba(122,231,255,0.5)",
              border: "1px solid rgba(255,255,255,0.6)",
            }}
            animate={{ top: markerTop }}
            transition={{
              duration: building ? 2.4 : 0.5,
              ease: building ? "easeInOut" : "easeOut",
              times: markerStages,
              repeat: building ? 0 : 0,
            }}
          />
          {/* trailing glow */}
          <motion.div
            className="absolute -left-1 w-1 rounded-full"
            style={{ background: "linear-gradient(to bottom, #7AE7FF, transparent)" }}
            animate={{ top: markerTop, height: ["0%", "40%"] }}
            transition={{ duration: building ? 2.4 : 0.5, ease: "easeInOut", times: markerStages }}
          />
        </div>
        {/* depth label */}
        <motion.span
          className="mt-1.5 text-[8px] font-bold tracking-[0.1em] uppercase whitespace-nowrap"
          style={{ color: "#7AE7FF" }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.6, repeat: Infinity }}
        >
          DEPTH
        </motion.span>
      </div>
    </div>
  );
});

export default ARVeinCrossSection;