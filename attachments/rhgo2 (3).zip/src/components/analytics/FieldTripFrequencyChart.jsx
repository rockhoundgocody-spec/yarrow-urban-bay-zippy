import React, { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { format, startOfWeek, subWeeks } from "date-fns";

export default function FieldTripFrequencyChart({ logs }) {
  const chartData = useMemo(() => {
    const now = new Date();
    const weeks = [];

    // Pre-calculate target weeks to avoid formatting overhead in the O(N) loop
    for (let i = 7; i >= 0; i--) {
      const d = startOfWeek(subWeeks(now, i));
      weeks.push({
        year: d.getFullYear(),
        month: d.getMonth(),
        dateValue: d.getDate(),
        label: format(d, "M/d"),
        trips: 0
      });
    }

    // Single-pass optimization: native integer comparison instead of date-fns inside loop
    for (let i = 0; i < logs.length; i++) {
      const d = new Date(logs[i].visit_date || logs[i].created_date);
      // We still need the start of the week for comparison, but doing it on a native date is faster
      // than full string formatting. However, calculating the start of week without date-fns
      // inside the loop is a bit complex due to edge cases.
      // A safe compromise is to use startOfWeek to get the normalized date, then compare integers
      const weekStart = startOfWeek(d);
      const year = weekStart.getFullYear();
      const month = weekStart.getMonth();
      const dateValue = weekStart.getDate();

      for (let j = 0; j < weeks.length; j++) {
        if (weeks[j].year === year && weeks[j].month === month && weeks[j].dateValue === dateValue) {
          weeks[j].trips++;
          break;
        }
      }
    }

    return weeks;
  }, [logs]);

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <XAxis dataKey="label" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <YAxis allowDecimals={false} tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "#1a1a2e", border: "1px solid rgba(0,245,255,0.2)", borderRadius: 12, color: "#fff", fontSize: 13 }}
          cursor={{ fill: "rgba(0,245,255,0.06)" }}
        />
        <Bar dataKey="trips" fill="#a855f7" radius={[6, 6, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}