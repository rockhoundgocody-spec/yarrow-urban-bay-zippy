import React from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

const COLORS = ["#00f5ff", "#a855f7", "#00ffaa", "#ff6600", "#ffd700", "#ff00ff", "#3b82f6", "#ef4444"];

export default function MostFoundMineralsChart({ specimens }) {
  const counts = {};
  specimens.forEach(s => {
    const name = s.name?.trim();
    if (name) counts[name] = (counts[name] || 0) + 1;
  });

  const data = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name: name.length > 12 ? name.slice(0, 12) + "…" : name, count }));

  if (data.length === 0) {
    return <p className="text-white/30 text-sm text-center py-8">No specimens yet</p>;
  }

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <YAxis allowDecimals={false} tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "#1a1a2e", border: "1px solid rgba(0,245,255,0.2)", borderRadius: 12, color: "#fff", fontSize: 13 }}
          cursor={{ fill: "rgba(0,245,255,0.06)" }}
        />
        <Bar dataKey="count" radius={[6, 6, 0, 0]}>
          {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}