import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { TrendingUp, TrendingDown, Minus, Sparkles, Loader2, AlertTriangle, DollarSign, Gem } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { format, subMonths, startOfMonth } from "date-fns";

const RARITY_WEIGHTS = {
  gemstone: 5, crystal: 4, mineral: 3, metamorphic: 2.5,
  igneous: 2, fossil: 3.5, sedimentary: 1.5, unknown: 1,
};

const DIRECTION_META = {
  rising:  { icon: TrendingUp,   color: "#4ade80", label: "Rising",  bg: "rgba(74,222,128,0.08)",  border: "rgba(74,222,128,0.25)" },
  stable:  { icon: Minus,        color: "#60a5fa", label: "Stable",  bg: "rgba(96,165,250,0.08)",  border: "rgba(96,165,250,0.25)" },
  softening:{ icon: TrendingDown, color: "#f97316", label: "Softening", bg: "rgba(249,115,22,0.08)", border: "rgba(249,115,22,0.25)" },
};

function buildMonthlyScarcity(specimens) {
  const now = new Date();
  return Array.from({ length: 6 }, (_, i) => {
    const d = startOfMonth(subMonths(now, 5 - i));
    const label = format(d, "MMM");
    const inMonth = specimens.filter(s => {
      const sd = new Date(s.created_date);
      return sd >= d && sd < subMonths(d, -1);
    });
    const rarityScore = inMonth.reduce((sum, s) => sum + (RARITY_WEIGHTS[s.category] || 1), 0);
    const uniqueCount = new Set(inMonth.map(s => s.name)).size;
    return { label, count: inMonth.length, rarityScore: Math.round(rarityScore * 10) / 10, unique: uniqueCount };
  });
}

function ForecastCard({ mineral, onSelect, selected }) {
  const meta = DIRECTION_META[mineral.direction] || DIRECTION_META.stable;
  const Icon = meta.icon;
  return (
    <button onClick={() => onSelect(mineral)}
      className="w-full text-left rounded-xl p-3.5 transition-all"
      style={{
        background: selected ? meta.bg : "rgba(255,255,255,0.025)",
        border: `1px solid ${selected ? meta.border : "rgba(255,255,255,0.07)"}`,
      }}>
      <div className="flex items-start gap-2.5">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0" style={{ background: `${meta.color}15` }}>
          <Gem className="w-4 h-4" style={{ color: meta.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-semibold text-white/85 truncate">{mineral.name}</span>
            <Icon className="w-3.5 h-3.5 shrink-0" style={{ color: meta.color }} />
          </div>
          <p className="text-[10px] text-white/35 mt-0.5">{mineral.category} · {mineral.occurrences} finds</p>
        </div>
        <div className="text-right shrink-0">
          <div className="text-xs font-bold" style={{ color: meta.color }}>{meta.label}</div>
          <div className="text-[9px] text-white/30 mt-0.5">{mineral.valueRange}</div>
        </div>
      </div>
    </button>
  );
}

export default function ValueForecastModule({ specimens }) {
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedMineral, setSelectedMineral] = useState(null);

  const monthlyData = useMemo(() => buildMonthlyScarcity(specimens), [specimens]);

  // Pre-compute per-mineral stats for quick display before AI call
  const mineralStats = useMemo(() => {
    const map = {};
    specimens.forEach(s => {
      if (!s.name) return;
      if (!map[s.name]) map[s.name] = { name: s.name, category: s.category || "unknown", occurrences: 0, values: [], lastSeen: null };
      map[s.name].occurrences++;
      if (s.estimated_value) map[s.name].values.push(s.estimated_value);
      const d = new Date(s.created_date);
      if (!map[s.name].lastSeen || d > map[s.name].lastSeen) map[s.name].lastSeen = d;
    });

    // Compute recency trend per mineral
    const now = new Date();
    const cut30 = new Date(now - 30 * 86400000);
    const cut60 = new Date(now - 60 * 86400000);
    const recent30 = {}, prior30 = {};
    specimens.forEach(s => {
      if (!s.name) return;
      const d = new Date(s.created_date);
      if (d >= cut30) recent30[s.name] = (recent30[s.name] || 0) + 1;
      else if (d >= cut60) prior30[s.name] = (prior30[s.name] || 0) + 1;
    });

    return Object.values(map)
      .map(m => {
        const r = recent30[m.name] || 0;
        const p = prior30[m.name] || 0;
        const delta = p === 0 ? (r > 0 ? 50 : 0) : ((r - p) / p) * 100;
        const direction = delta > 15 ? "rising" : delta < -15 ? "softening" : "stable";
        const rarityW = RARITY_WEIGHTS[m.category] || 1;
        return { ...m, direction, delta: Math.round(delta), rarityWeight: rarityW, valueRange: m.values[0] || "Est. unknown" };
      })
      .sort((a, b) => b.rarityWeight * b.occurrences - a.rarityWeight * a.occurrences)
      .slice(0, 12);
  }, [specimens]);

  const runForecast = async () => {
    setLoading(true);
    setForecast(null);
    setSelectedMineral(null);

    const summary = mineralStats.slice(0, 8).map(m =>
      `${m.name} (${m.category}): ${m.occurrences} finds, trend ${m.direction}, delta ${m.delta}%, rarity weight ${m.rarityWeight}`
    ).join("\n");

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a mineral market analyst for a rockhounding platform. Based on this community collection data from the past 60 days, generate value forecasts:

${summary}

For each mineral, provide a JSON array of forecasts:
{
  "forecasts": [
    {
      "mineral": "name",
      "direction": "rising|stable|softening",
      "confidence": 60-95,
      "value_note": "1 sentence on why value is moving",
      "scarcity_driver": "1 sentence on supply/demand signal",
      "collector_tip": "practical tip for collectors"
    }
  ],
  "market_summary": "2-3 sentence overview of current market conditions for rockhound collectors",
  "hot_pick": "single mineral name that looks most promising right now"
}`,
      response_json_schema: {
        type: "object",
        properties: {
          forecasts: { type: "array", items: { type: "object" } },
          market_summary: { type: "string" },
          hot_pick: { type: "string" },
        },
      },
    });

    setForecast(res);
    setLoading(false);
  };

  const aiDetail = selectedMineral && forecast?.forecasts?.find(f => f.mineral?.toLowerCase() === selectedMineral.name?.toLowerCase());

  if (specimens.length < 3) {
    return (
      <div className="flex flex-col items-center gap-3 py-10">
        <AlertTriangle className="w-7 h-7 text-amber-400/50" />
        <p className="text-white/35 text-sm text-center">Need at least 3 specimens in the community database<br />to generate value forecasts.</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Scarcity trend line */}
      <div>
        <p className="text-xs text-white/35 mb-3">Community rarity score trend (weighted by mineral category)</p>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={monthlyData} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="rarityGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#a855f7" />
                <stop offset="100%" stopColor="#fbbf24" />
              </linearGradient>
            </defs>
            <XAxis dataKey="label" tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: "rgba(255,255,255,0.25)", fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: "#0d0d22", border: "1px solid rgba(168,85,247,0.2)", borderRadius: 10, color: "#fff", fontSize: 12 }}
              formatter={(v, n) => [v, n === "rarityScore" ? "Rarity Score" : "Finds"]} />
            <Line type="monotone" dataKey="rarityScore" stroke="url(#rarityGrad)" strokeWidth={2.5} dot={{ fill: "#a855f7", r: 3 }} name="Rarity Score" />
            <Line type="monotone" dataKey="count" stroke="rgba(0,245,255,0.4)" strokeWidth={1.5} dot={false} strokeDasharray="4 2" name="Finds" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Hot minerals grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs text-white/35">Community-tracked minerals</p>
          <Button onClick={runForecast} disabled={loading} size="sm"
            className="h-8 gap-1.5 text-xs rounded-lg px-3"
            style={{ background: "linear-gradient(120deg, #a855f7, #8b5cf6)", boxShadow: "0 0 16px rgba(168,85,247,0.3)", color: "#fff", border: "none" }}>
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {loading ? "Forecasting…" : forecast ? "Refresh AI Forecast" : "Run AI Forecast"}
          </Button>
        </div>

        <div className="space-y-2">
          {mineralStats.map(m => (
            <ForecastCard key={m.name} mineral={m} onSelect={setSelectedMineral} selected={selectedMineral?.name === m.name} />
          ))}
        </div>
      </div>

      {/* AI Forecast results */}
      <AnimatePresence>
        {forecast && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-4">
            {/* Market summary */}
            <div className="rounded-xl p-4" style={{ background: "rgba(168,85,247,0.06)", border: "1px solid rgba(168,85,247,0.2)" }}>
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="w-4 h-4 text-purple-400" />
                <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider">Market Overview</span>
              </div>
              <p className="text-sm text-white/60 leading-relaxed">{forecast.market_summary}</p>
              {forecast.hot_pick && (
                <div className="mt-3 flex items-center gap-2">
                  <span className="text-[10px] text-white/30 uppercase tracking-wider">Hot Pick:</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold" style={{ background: "rgba(250,204,21,0.12)", color: "#fbbf24", border: "1px solid rgba(250,204,21,0.3)" }}>
                    ⚡ {forecast.hot_pick}
                  </span>
                </div>
              )}
            </div>

            {/* Selected mineral AI detail */}
            {aiDetail && (
              <motion.div key={selectedMineral.name} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
                className="rounded-xl p-4 space-y-3"
                style={{ background: "rgba(0,245,255,0.04)", border: "1px solid rgba(0,245,255,0.15)" }}>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-cyan-400">{selectedMineral.name}</span>
                  <span className="text-[9px] px-2 py-0.5 rounded-full"
                    style={{ background: `${DIRECTION_META[aiDetail.direction]?.color}15`, color: DIRECTION_META[aiDetail.direction]?.color, border: `1px solid ${DIRECTION_META[aiDetail.direction]?.color}30` }}>
                    {aiDetail.direction} · {aiDetail.confidence}% confidence
                  </span>
                </div>
                {aiDetail.value_note && <p className="text-xs text-white/55 leading-relaxed">💰 {aiDetail.value_note}</p>}
                {aiDetail.scarcity_driver && <p className="text-xs text-white/45 leading-relaxed">📦 {aiDetail.scarcity_driver}</p>}
                {aiDetail.collector_tip && (
                  <div className="rounded-lg px-3 py-2" style={{ background: "rgba(250,204,21,0.06)", border: "1px solid rgba(250,204,21,0.15)" }}>
                    <p className="text-[11px] text-amber-400/80">💡 {aiDetail.collector_tip}</p>
                  </div>
                )}
              </motion.div>
            )}

            {selectedMineral && !aiDetail && (
              <p className="text-xs text-white/25 text-center">Select a mineral above to see its AI forecast detail</p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}