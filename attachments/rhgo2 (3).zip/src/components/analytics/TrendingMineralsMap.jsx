import React, { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { MapPin, ArrowUp, ArrowDown, Minus } from "lucide-react";

const REGION_MAP = {
  AZ: "Arizona", NV: "Nevada", CA: "California", CO: "Colorado",
  UT: "Utah", NM: "New Mexico", ID: "Idaho", MT: "Montana",
  WY: "Wyoming", OR: "Oregon", WA: "Washington", TX: "Texas",
  NC: "N. Carolina", VA: "Virginia", AR: "Arkansas", MO: "Missouri",
};

const COLORS = ["#00f5ff", "#a855f7", "#00ffaa", "#ff6600", "#ffd700", "#ff00ff", "#3b82f6", "#f43f5e"];

function trendIcon(delta) {
  if (delta > 10) return <ArrowUp className="w-3 h-3 text-green-400" />;
  if (delta < -10) return <ArrowDown className="w-3 h-3 text-red-400" />;
  return <Minus className="w-3 h-3 text-white/25" />;
}

export default function TrendingMineralsMap({ specimens, logs }) {
  const [selectedRegion, setSelectedRegion] = useState(null);

  // Derive region → mineral counts from specimens + location logs
  const regionData = useMemo(() => {
    const map = {}; // region → { mineral → count }

    // Use location_found field on specimens
    specimens.forEach(s => {
      if (!s.name) return;
      const loc = s.location_found || "";
      // Try to extract state abbreviation
      const match = loc.match(/\b([A-Z]{2})\b/) || [];
      const region = match[1] && REGION_MAP[match[1]] ? match[1] : "Other";
      if (!map[region]) map[region] = {};
      map[region][s.name] = (map[region][s.name] || 0) + 1;
    });

    // Supplement with location logs that have state data
    logs.forEach(log => {
      if (!log.specimens_found?.length) return;
      const locName = log.location_name || "";
      const match = locName.match(/\b([A-Z]{2})\b/) || [];
      const region = match[1] && REGION_MAP[match[1]] ? match[1] : null;
      if (!region) return;
      log.specimens_found.forEach(name => {
        if (!map[region]) map[region] = {};
        map[region][name] = (map[region][name] || 0) + 1;
      });
    });

    return map;
  }, [specimens, logs]);

  // Global top minerals + trend delta (simulated from last-30-day vs prior)
  const globalTrending = useMemo(() => {
    const now = new Date();
    const cutoff30 = new Date(now - 30 * 86400000);
    const cutoff60 = new Date(now - 60 * 86400000);

    const recent = {};
    const prior = {};
    specimens.forEach(s => {
      if (!s.name) return;
      const d = new Date(s.created_date);
      if (d >= cutoff30) recent[s.name] = (recent[s.name] || 0) + 1;
      else if (d >= cutoff60) prior[s.name] = (prior[s.name] || 0) + 1;
    });

    const allNames = new Set([...Object.keys(recent), ...Object.keys(prior)]);
    return Array.from(allNames)
      .map(name => {
        const r = recent[name] || 0;
        const p = prior[name] || 0;
        const delta = p === 0 ? (r > 0 ? 100 : 0) : Math.round(((r - p) / p) * 100);
        return { name, recent: r, prior: p, delta };
      })
      .sort((a, b) => b.recent - a.recent)
      .slice(0, 10);
  }, [specimens]);

  // Region breakdown for selected region
  const regionBreakdown = useMemo(() => {
    if (!selectedRegion) return [];
    const minerals = regionData[selectedRegion] || {};
    return Object.entries(minerals)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([name, count], i) => ({ name: name.length > 14 ? name.slice(0, 14) + "…" : name, count, color: COLORS[i % COLORS.length] }));
  }, [selectedRegion, regionData]);

  const regionList = Object.entries(regionData)
    .map(([code, minerals]) => ({ code, total: Object.values(minerals).reduce((s, v) => s + v, 0) }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 8);

  if (specimens.length === 0) {
    return <p className="text-white/30 text-sm text-center py-10">No community data yet</p>;
  }

  return (
    <div className="space-y-5">
      {/* Global trending bar chart */}
      <div>
        <p className="text-xs text-white/35 mb-3">Global trending — last 30 days vs prior 30 days</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={globalTrending} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
            <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 10 }} axisLine={false} tickLine={false}
              tickFormatter={v => v.length > 9 ? v.slice(0, 9) + "…" : v} />
            <YAxis allowDecimals={false} tick={{ fill: "rgba(255,255,255,0.25)", fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip
              contentStyle={{ background: "#0d0d22", border: "1px solid rgba(0,245,255,0.2)", borderRadius: 10, color: "#fff", fontSize: 12 }}
              cursor={{ fill: "rgba(0,245,255,0.04)" }}
              formatter={(v, n) => [v, n === "recent" ? "Last 30d" : "Prior 30d"]}
            />
            <Bar dataKey="prior" radius={[4, 4, 0, 0]} fill="rgba(255,255,255,0.08)" name="Prior 30d" />
            <Bar dataKey="recent" radius={[4, 4, 0, 0]} name="Last 30d">
              {globalTrending.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Trend table */}
      <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="grid grid-cols-[1fr_auto_auto_auto] gap-0 text-[10px] text-white/30 uppercase tracking-wider px-4 py-2"
          style={{ background: "rgba(255,255,255,0.03)" }}>
          <span>Mineral</span><span className="text-right">Recent</span><span className="text-right px-3">Prior</span><span className="text-right">Trend</span>
        </div>
        {globalTrending.map((row, i) => (
          <div key={row.name} className="grid grid-cols-[1fr_auto_auto_auto] gap-0 px-4 py-2.5 text-sm items-center"
            style={{ background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.015)", borderTop: "1px solid rgba(255,255,255,0.04)" }}>
            <span className="text-white/70 font-medium truncate">{row.name}</span>
            <span className="text-white/60 text-right tabular-nums">{row.recent}</span>
            <span className="text-white/30 text-right px-3 tabular-nums">{row.prior}</span>
            <span className="flex items-center justify-end gap-1 text-xs font-semibold"
              style={{ color: row.delta > 10 ? "#4ade80" : row.delta < -10 ? "#f87171" : "rgba(255,255,255,0.25)" }}>
              {trendIcon(row.delta)}
              {row.delta > 0 ? "+" : ""}{row.delta}%
            </span>
          </div>
        ))}
      </div>

      {/* Region selector */}
      {regionList.length > 0 && (
        <div>
          <p className="text-xs text-white/35 mb-2 flex items-center gap-1.5"><MapPin className="w-3 h-3" /> Filter by region</p>
          <div className="flex flex-wrap gap-2">
            {regionList.map(r => (
              <button key={r.code}
                onClick={() => setSelectedRegion(s => s === r.code ? null : r.code)}
                className="px-3 py-1 rounded-full text-xs font-semibold transition-all"
                style={{
                  background: selectedRegion === r.code ? "rgba(0,245,255,0.15)" : "rgba(255,255,255,0.04)",
                  border: `1px solid ${selectedRegion === r.code ? "rgba(0,245,255,0.4)" : "rgba(255,255,255,0.08)"}`,
                  color: selectedRegion === r.code ? "#00f5ff" : "rgba(255,255,255,0.4)",
                }}>
                {REGION_MAP[r.code] || r.code} <span className="opacity-50">({r.total})</span>
              </button>
            ))}
          </div>

          {selectedRegion && regionBreakdown.length > 0 && (
            <div className="mt-4">
              <p className="text-xs text-white/30 mb-3">{REGION_MAP[selectedRegion] || selectedRegion} — top minerals</p>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={regionBreakdown} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
                  <XAxis dataKey="name" tick={{ fill: "rgba(255,255,255,0.35)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fill: "rgba(255,255,255,0.25)", fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ background: "#0d0d22", border: "1px solid rgba(168,85,247,0.2)", borderRadius: 10, color: "#fff", fontSize: 12 }} cursor={{ fill: "rgba(168,85,247,0.04)" }} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {regionBreakdown.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      )}
    </div>
  );
}