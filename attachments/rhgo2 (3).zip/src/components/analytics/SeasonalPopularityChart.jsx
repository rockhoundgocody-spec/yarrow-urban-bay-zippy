import React, { useMemo, useState } from "react";
import { getMonth, getYear, subMonths } from "date-fns";
import { Calendar, Sun, Cloud, Snowflake, Leaf } from "lucide-react";

const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const SEASON_META = {
  winter: { label: "Winter", icon: Snowflake, color: "#60a5fa", months: [11, 0, 1] },
  spring: { label: "Spring", icon: Leaf, color: "#4ade80", months: [2, 3, 4] },
  summer: { label: "Summer", icon: Sun, color: "#fbbf24", months: [5, 6, 7] },
  fall:   { label: "Fall",   icon: Cloud, color: "#f97316", months: [8, 9, 10] },
};

function getSeason(monthIdx) {
  for (const [k, v] of Object.entries(SEASON_META)) {
    if (v.months.includes(monthIdx)) return k;
  }
  return "winter";
}

function cellColor(count, max) {
  if (max === 0 || count === 0) return "rgba(255,255,255,0.04)";
  const intensity = count / max;
  if (intensity < 0.25) return "rgba(0,245,255,0.12)";
  if (intensity < 0.5)  return "rgba(0,245,255,0.28)";
  if (intensity < 0.75) return "rgba(0,245,255,0.50)";
  return "rgba(0,245,255,0.80)";
}

function cellTextColor(count, max) {
  if (max === 0 || count === 0) return "rgba(255,255,255,0.15)";
  const intensity = count / max;
  return intensity > 0.6 ? "#000" : "rgba(255,255,255,0.7)";
}

export default function SeasonalPopularityChart({ logs, specimens }) {
  const [view, setView] = useState("monthly"); // monthly | seasonal

  // Build month activity grid: year rows × month columns
  const { grid, years, maxCount } = useMemo(() => {
    const counts = {}; // "YYYY-MM" → count

    logs.forEach(log => {
      if (!log.visit_date && !log.created_date) return;
      const d = new Date(log.visit_date || log.created_date);
      const key = `${getYear(d)}-${String(getMonth(d)).padStart(2, "0")}`;
      counts[key] = (counts[key] || 0) + 1;
    });

    specimens.forEach(s => {
      const d = new Date(s.created_date);
      const key = `${getYear(d)}-${String(getMonth(d)).padStart(2, "0")}`;
      counts[key] = (counts[key] || 0) + Math.ceil(0.3); // weight specimens lighter
    });

    // Round counts
    Object.keys(counts).forEach(k => { counts[k] = Math.round(counts[k]); });

    const yearSet = new Set(Object.keys(counts).map(k => k.split("-")[0]));
    const now = new Date();
    yearSet.add(String(getYear(now)));
    yearSet.add(String(getYear(subMonths(now, 12))));
    const years = Array.from(yearSet).sort();

    const maxCount = Math.max(1, ...Object.values(counts));

    const grid = years.map(year => ({
      year,
      months: MONTH_LABELS.map((label, mi) => {
        const key = `${year}-${String(mi).padStart(2, "0")}`;
        return { label, count: counts[key] || 0, monthIdx: mi };
      }),
    }));

    return { grid, years, maxCount };
  }, [logs, specimens]);

  // Seasonal aggregation
  const seasonalData = useMemo(() => {
    const totals = { winter: 0, spring: 0, summer: 0, fall: 0 };
    grid.forEach(yr => {
      yr.months.forEach(m => {
        const season = getSeason(m.monthIdx);
        totals[season] += m.count;
      });
    });
    return totals;
  }, [grid]);

  // Peak month (across all years combined)
  const monthTotals = useMemo(() => {
    const t = Array(12).fill(0);
    grid.forEach(yr => yr.months.forEach(m => { t[m.monthIdx] += m.count; }));
    return t;
  }, [grid]);
  const peakMonthIdx = monthTotals.indexOf(Math.max(...monthTotals));

  return (
    <div className="space-y-5">
      {/* View toggle */}
      <div className="flex items-center gap-2">
        {["monthly", "seasonal"].map(v => (
          <button key={v} onClick={() => setView(v)}
            className="px-3 py-1 rounded-full text-xs font-semibold transition-all capitalize"
            style={{
              background: view === v ? "rgba(168,85,247,0.15)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${view === v ? "rgba(168,85,247,0.4)" : "rgba(255,255,255,0.07)"}`,
              color: view === v ? "#a855f7" : "rgba(255,255,255,0.4)",
            }}>
            {v}
          </button>
        ))}
        <span className="text-[10px] text-white/25 ml-auto flex items-center gap-1">
          <Calendar className="w-3 h-3" /> Peak month: <strong className="text-white/50">{MONTH_LABELS[peakMonthIdx]}</strong>
        </span>
      </div>

      {view === "monthly" ? (
        <div className="space-y-3">
          {/* Month header */}
          <div className="grid gap-1" style={{ gridTemplateColumns: "3rem repeat(12, 1fr)" }}>
            <div />
            {MONTH_LABELS.map(m => (
              <div key={m} className="text-center text-[9px] text-white/30 font-semibold">{m}</div>
            ))}
          </div>

          {/* Year rows */}
          {grid.map(yr => (
            <div key={yr.year} className="grid gap-1" style={{ gridTemplateColumns: "3rem repeat(12, 1fr)" }}>
              <div className="text-[10px] text-white/30 flex items-center">{yr.year}</div>
              {yr.months.map(m => (
                <div key={m.label} title={`${MONTH_LABELS[m.monthIdx]} ${yr.year}: ${m.count} activities`}
                  className="aspect-square rounded-md flex items-center justify-center text-[9px] font-bold transition-all cursor-default hover:scale-110"
                  style={{ background: cellColor(m.count, maxCount), color: cellTextColor(m.count, maxCount) }}>
                  {m.count > 0 ? m.count : ""}
                </div>
              ))}
            </div>
          ))}

          {/* Legend */}
          <div className="flex items-center gap-2 justify-end mt-1">
            <span className="text-[9px] text-white/25">Less</span>
            {[0, 0.2, 0.5, 0.8, 1].map(v => (
              <div key={v} className="w-4 h-4 rounded-sm" style={{ background: cellColor(v * maxCount, maxCount) }} />
            ))}
            <span className="text-[9px] text-white/25">More</span>
          </div>
        </div>
      ) : (
        /* Seasonal view */
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(SEASON_META).map(([key, meta]) => {
            const Icon = meta.icon;
            const total = seasonalData[key];
            const grandTotal = Object.values(seasonalData).reduce((s, v) => s + v, 0);
            const pct = grandTotal > 0 ? Math.round((total / grandTotal) * 100) : 0;
            return (
              <div key={key} className="rounded-xl p-4" style={{ background: `${meta.color}0d`, border: `1px solid ${meta.color}25` }}>
                <div className="flex items-center gap-2 mb-3">
                  <Icon className="w-4 h-4" style={{ color: meta.color }} />
                  <span className="text-sm font-semibold text-white/80">{meta.label}</span>
                </div>
                <div className="text-2xl font-bold mb-1" style={{ color: meta.color }}>{total}</div>
                <p className="text-[10px] text-white/30">activities · {pct}% of annual total</p>
                <div className="mt-3 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                  <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: meta.color }} />
                </div>
                <div className="mt-2 flex gap-1 flex-wrap">
                  {meta.months.map(mi => (
                    <span key={mi} className="text-[9px] px-1.5 py-0.5 rounded-full"
                      style={{ background: `${meta.color}15`, color: meta.color }}>
                      {MONTH_LABELS[mi]}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}