import React, { useMemo } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { format, startOfMonth, subMonths } from "date-fns";

export default function DiscoveryTrendsChart({ specimens }) {
  const chartData = useMemo(() => {
    const now = new Date();
    const months = [];

    // Pre-calculate target months to avoid formatting overhead in the O(N) loop
    for (let i = 5; i >= 0; i--) {
      const d = startOfMonth(subMonths(now, i));
      months.push({
        year: d.getFullYear(),
        month: d.getMonth(),
        label: format(d, "MMM"),
        count: 0
      });
    }

    // Single-pass optimization: native integer comparison instead of date-fns inside loop
    for (let i = 0; i < specimens.length; i++) {
      const created = new Date(specimens[i].created_date);
      const year = created.getFullYear();
      const month = created.getMonth();

      for (let j = 0; j < months.length; j++) {
        if (months[j].year === year && months[j].month === month) {
          months[j].count++;
          break;
        }
      }
    }

    return months;
  }, [specimens]);

  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={chartData} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
        <defs>
          <linearGradient id="trendGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#00f5ff" stopOpacity={0.4} />
            <stop offset="100%" stopColor="#00f5ff" stopOpacity={0} />
          </linearGradient>
        </defs>
        <XAxis dataKey="label" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <YAxis allowDecimals={false} tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "#1a1a2e", border: "1px solid rgba(0,245,255,0.2)", borderRadius: 12, color: "#fff", fontSize: 13 }}
        />
        <Area type="monotone" dataKey="count" stroke="#00f5ff" strokeWidth={2} fill="url(#trendGrad)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}