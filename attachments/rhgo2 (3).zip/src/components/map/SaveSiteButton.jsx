/**
 * SaveSiteButton — Heart/bookmark toggle for a rockhounding location.
 * Persists a Bookmark entity keyed by location_id + user email.
 */
import React, { useState, useEffect } from "react";
import { Heart } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function SaveSiteButton({ location, user, size = "sm" }) {
  const [saved, setSaved] = useState(false);
  const [bookmarkId, setBookmarkId] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user || !location?.id) return;
    base44.entities.Bookmark.filter({ created_by: user.email, reference_id: location.id })
      .then((res) => {
        if (res[0]) { setSaved(true); setBookmarkId(res[0].id); }
      })
      .catch(() => {});
  }, [user?.email, location?.id]);

  const toggle = async (e) => {
    e.stopPropagation();
    if (!user || loading) return;
    setLoading(true);
    try {
      if (saved && bookmarkId) {
        await base44.entities.Bookmark.delete(bookmarkId);
        setSaved(false);
        setBookmarkId(null);
      } else {
        const bm = await base44.entities.Bookmark.create({
          reference_entity: "RockhoundingLocation",
          reference_id: location.id,
          label: location.name,
          notes: location.state || "",
        });
        setSaved(true);
        setBookmarkId(bm.id);
      }
    } catch (err) {
      console.error("SaveSiteButton toggle:", err);
    } finally {
      setLoading(false);
    }
  };

  const iconSize = size === "lg" ? "w-5 h-5" : "w-4 h-4";
  const btnSize  = size === "lg" ? "w-10 h-10" : "w-8 h-8";

  return (
    <button
      onClick={toggle}
      disabled={loading}
      aria-label={saved ? "Remove from saved sites" : "Save this site"}
      className={`${btnSize} flex items-center justify-center rounded-full transition-all duration-200 active:scale-90`}
      style={{
        background: saved ? "rgba(239,68,68,0.15)" : "rgba(255,255,255,0.08)",
        border: `1px solid ${saved ? "rgba(239,68,68,0.45)" : "rgba(255,255,255,0.12)"}`,
        boxShadow: saved ? "0 0 14px rgba(239,68,68,0.25)" : "none",
      }}
    >
      <Heart
        className={`${iconSize} transition-all`}
        style={{ color: saved ? "#EF4444" : "rgba(255,255,255,0.4)" }}
        fill={saved ? "#EF4444" : "none"}
      />
    </button>
  );
}