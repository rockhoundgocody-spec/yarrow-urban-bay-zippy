import React from "react";
import { Marker, Popup } from "react-leaflet";
import L from "leaflet";
import LocationCard from "./LocationCard";
import GeologyLayer from "./GeologyLayer";

const LEGALITY_COLORS = {
  "Safe Public": "#22c55e",
  "Likely Legal": "#eab308",
  "Use Caution": "#f97316",
  "High Risk": "#ef4444",
};

const SITE_TYPE_ICONS = {
  public_land: "🏜️",
  mine: "⛏️",
  quarry: "🪨",
  beach: "🏖️",
  riverbed: "🌊",
  desert: "🏜️",
  mountain: "⛰️",
  roadcut: "🛣️",
  fee_dig: "💰",
  other: "📍",
};

function createLegendIcon(color, type) {
  return L.divIcon({
    html: `<div style="background-color: ${color}; border: 2px solid white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 0 8px rgba(0,0,0,0.4);">${type}</div>`,
    iconSize: [24, 24],
    className: "legend-icon",
  });
}

export default function FilteredMapLayers({
  locations = [],
  layers = {},
  shops = [],
}) {
  const filteredLocations = locations.filter((loc) => {
    const legality = loc.legality_status;
    if (legality === "Safe Public" && !layers.show_safe_public) return false;
    if (legality === "Likely Legal" && !layers.show_likely_legal) return false;
    if (legality === "High Risk" && !layers.show_high_risk) return false;
    if (legality === "Use Caution" && !layers.show_likely_legal) return false;
    if (loc.is_saved && !layers.show_user_visited) return false;

    // Historical mining: mines & quarries
    const isMiningType = loc.site_type === "mine" || loc.site_type === "quarry";
    if (isMiningType && !layers.show_historical_mining) return false;

    // User POIs: user-submitted locations (non-admin created)
    if (loc.is_user_poi && !layers.show_user_pois) return false;

    return true;
  });

  const filteredShops = shops.filter(
    (shop) => shop.approved && layers.show_shops
  );

  return (
    <>
      {/* Geology WMS overlay */}
      <GeologyLayer visible={!!layers.show_geology_layer} />

      {/* Location Markers */}
      {filteredLocations.map((loc) => {
        const color = LEGALITY_COLORS[loc.legality_status] || "#666";
        const icon = SITE_TYPE_ICONS[loc.site_type] || "📍";

        return (
          <Marker
            key={loc.id}
            position={[loc.latitude, loc.longitude]}
            icon={createLegendIcon(color, icon)}
          >
            <Popup className="location-popup" closeButton={true}>
              <LocationCard location={loc} compact={false} />
            </Popup>
          </Marker>
        );
      })}

      {/* Shop Markers */}
      {filteredShops.map((shop) => (
        <Marker
          key={`shop-${shop.id}`}
          position={[shop.latitude, shop.longitude]}
          icon={createLegendIcon("#06b6d4", "🏬")}
        >
          <Popup closeButton={true}>
            <div className="text-xs md:text-sm space-y-1">
              <strong>{shop.shop_name}</strong>
              <p className="text-[9px] text-gray-600">{shop.address}</p>
              {shop.specialty_minerals.length > 0 && (
                <p className="text-[9px]">
                  <strong>Specialties:</strong> {shop.specialty_minerals.join(", ")}
                </p>
              )}
              {shop.community_rating_count > 0 && (
                <p className="text-[9px]">⭐ {shop.community_rating.toFixed(1)} ({shop.community_rating_count})</p>
              )}
            </div>
          </Popup>
        </Marker>
      ))}
    </>
  );
}