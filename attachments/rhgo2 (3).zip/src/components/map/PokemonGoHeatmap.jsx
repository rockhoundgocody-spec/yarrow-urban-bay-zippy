import React, { useEffect, useMemo } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet.heat";
import { escapeHtml } from "@/utils";

const MINERAL_COLORS = {
  "Quartz": "#ff6b9d",
  "Amethyst": "#b366ff",
  "Topaz": "#ffd700",
  "Emerald": "#00ff88",
  "Ruby": "#ff0033",
  "Sapphire": "#0066ff",
  "Turquoise": "#00ffdd",
  "Garnet": "#cc0000",
  "Opal": "#ff99ff",
  "Tourmaline": "#00cc99",
  "Fluorite": "#ffaa00",
  "Calcite": "#ffffff",
};

// Fallback color by mineral category
const CATEGORY_COLORS = {
  "igneous": "#ff6b4a",
  "sedimentary": "#d4a574",
  "metamorphic": "#a367bd",
  "mineral": "#ffeb3b",
  "crystal": "#64b5f6",
  "fossil": "#8d6e63",
  "gemstone": "#ff1493",
  "unknown": "#9e9e9e",
};

export default function PokemonGoHeatmap({ locations = [], visible = true }) {
  const map = useMap();
  const heatmapLayer = React.useRef(null);
  const circleMarkers = React.useRef([]);

  const heatmapData = useMemo(() => {
    if (!locations.length) return [];

    return locations
      .filter((loc) => loc.latitude && loc.longitude)
      .map((loc) => {
        const intensity = (loc.mineral_prediction_confidence || 50) / 100;
        return [loc.latitude, loc.longitude, intensity];
      });
  }, [locations]);

  useEffect(() => {
    if (!map || !visible) return;

    // Clear existing markers
    circleMarkers.current.forEach((marker) => map.removeLayer(marker));
    circleMarkers.current = [];

    // Remove old heatmap layer
    if (heatmapLayer.current) {
      map.removeLayer(heatmapLayer.current);
    }

    if (heatmapData.length === 0) return;

    // Add Pokemon GO style circle markers for each location
    locations.forEach((loc) => {
      if (!loc.latitude || !loc.longitude) return;

      const minerals = loc.predicted_minerals || loc.minerals_found || [];
      const primaryMineral = minerals[0];
      const color = MINERAL_COLORS[primaryMineral] || CATEGORY_COLORS[loc.category] || "#ffeb3b";
      const confidence = loc.mineral_prediction_confidence || 50;

      const marker = L.circleMarker([loc.latitude, loc.longitude], {
        radius: Math.max(4, (confidence / 100) * 12),
        fillColor: color,
        color: "white",
        weight: 2,
        opacity: 0.9,
        fillOpacity: 0.7,
      })
        .bindPopup(`
          <div class="text-xs md:text-sm">
            <strong>${escapeHtml(loc.name)}</strong>
            <p>${escapeHtml(minerals.join(", "))}</p>
            <p>Confidence: ${escapeHtml(confidence)}%</p>
          </div>
        `)
        .addTo(map);

      circleMarkers.current.push(marker);
    });

    // Add gradient heatmap layer for mineral density
    if (L.heatLayer && heatmapData.length > 0) {
      // Guard: leaflet.heat crashes if the map container has zero dimensions
      const container = map.getContainer();
      if (!container || container.clientWidth === 0 || container.clientHeight === 0) return;

      try {
        heatmapLayer.current = L.heatLayer(heatmapData, {
          radius: 40,
          blur: 25,
          maxZoom: 18,
          gradient: {
            0.0: "#0066ff",
            0.25: "#00ffdd",
            0.5: "#ffeb3b",
            0.75: "#ff6b4a",
            1.0: "#ff1493",
          },
        }).addTo(map);
      } catch (e) {
        // Silently ignore canvas sizing errors on initial render
      }
    }

    return () => {
      circleMarkers.current.forEach((marker) => {
        if (map.hasLayer(marker)) map.removeLayer(marker);
      });
      if (heatmapLayer.current && map.hasLayer(heatmapLayer.current)) {
        map.removeLayer(heatmapLayer.current);
      }
    };
  }, [map, heatmapData, visible, locations]);

  return null;
}