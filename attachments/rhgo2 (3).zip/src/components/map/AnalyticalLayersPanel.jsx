import React, { useState } from "react";
import { FlaskConical, ShieldAlert, MapPinOff, Flame, ChevronDown, ChevronUp, Info } from "lucide-react";

export const ANALYTICAL_LAYERS = [
  {
    key: "hazard_zones",
    label: "Geological Hazard Zones",
    sublabel: "Unstable terrain, flood risk, mine shafts",
    icon: ShieldAlert,
    color: "#ef4444",
    fillColor: "rgba(239,68,68,0.15)",
    strokeColor: "#ef4444",
    description: "Sites flagged with active geological hazards (unstable slopes, shaft hazards, flooding, contamination). Radius indicates risk area.",
  },
  {
    key: "restricted_land",
    label: "Restricted Land Use",
    sublabel: "Permits, wilderness, monuments, tribal land",
    icon: MapPinOff,
    color: "#f4b544",
    fillColor: "rgba(244,181,68,0.12)",
    strokeColor: "#f4b544",
    description: "Areas requiring permits, or managed as Wilderness/Monument/Tribal land. Collecting may be restricted or prohibited.",
  },
  {
    key: "find_density",
    label: "Historical Find Density",
    sublabel: "Concentration of documented discoveries",
    icon: Flame,
    color: "#00d47e",
    fillColor: "rgba(0,212,126,0.12)",
    strokeColor: "#00d47e",
    description: "Zones with the highest documented mineral discoveries. Larger radius = more historical finds in the area.",
  },
];

// ── Legend tooltip ────────────────────────────────────────────────────────────
function LegendTooltip({ layer, visible }) {
  const [show, setShow] = useState(false);
  const Icon = layer.icon;
  return (
    <div className="relative inline-block">
      <button
        onClick={() => setShow(s => !s)}
        className="w-5 h-5 flex items-center justify-center rounded-full transition-colors"
        style={{ background: show ? `${layer.color}22` : "rgba(255,255,255,.06)", color: visible ? layer.color : "rgba(255,255,255,.25)" }}
       aria-label="Info">
        <Info className="w-3 h-3" />
      </button>
      {show && (
        <div className="absolute left-6 top-0 z-50 w-56 rounded-xl p-3 text-xs leading-relaxed shadow-2xl"
          style={{ background: "rgba(8,10,20,.97)", border: `1px solid ${layer.color}33`, color: "rgba(255,255,255,.65)", boxShadow: `0 0 20px ${layer.color}18` }}>
          <p className="font-bold mb-1" style={{ color: layer.color }}>{layer.label}</p>
          {layer.description}
          <div className="absolute -left-1.5 top-2 w-3 h-3 rotate-45" style={{ background: "rgba(8,10,20,.97)", borderLeft: `1px solid ${layer.color}33`, borderBottom: `1px solid ${layer.color}33` }} />
        </div>
      )}
    </div>
  );
}

// ── Main panel ────────────────────────────────────────────────────────────────
export default function AnalyticalLayersPanel({ activeLayers, onToggle, counts = {} }) {
  const [open, setOpen] = useState(false);

  const activeCount = ANALYTICAL_LAYERS.filter(l => activeLayers[l.key]).length;

  return (
    <div className="relative">
      {/* Toggle button */}
      <button
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-black tracking-wider font-mono transition-all"
        style={{
          background: activeCount > 0 ? "rgba(0,212,126,.1)" : "rgba(10,10,21,.82)",
          border: activeCount > 0 ? "1px solid rgba(0,212,126,.35)" : "1px solid rgba(255,255,255,.1)",
          backdropFilter: "blur(8px)",
          color: activeCount > 0 ? "#00d47e" : "rgba(255,255,255,.6)",
          boxShadow: activeCount > 0 ? "0 0 12px rgba(0,212,126,.15)" : "none",
        }}
      >
        <FlaskConical className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">ANALYSIS</span>
        {activeCount > 0 && (
          <span className="w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black" style={{ background: "#00d47e", color: "#000" }}>
            {activeCount}
          </span>
        )}
        {open ? <ChevronUp className="w-3 h-3 opacity-50" /> : <ChevronDown className="w-3 h-3 opacity-50" />}
      </button>

      {/* Dropdown panel */}
      {open && (
        <div className="absolute top-full mt-2 right-0 z-50 w-72 rounded-2xl overflow-hidden shadow-2xl"
          style={{ background: "rgba(6,8,18,.97)", border: "1px solid rgba(255,255,255,.08)", backdropFilter: "blur(20px)" }}>

          <div className="px-4 py-3 border-b" style={{ borderColor: "rgba(255,255,255,.06)" }}>
            <p className="text-[10px] font-black tracking-[.22em] text-white/40 font-mono">ANALYTICAL LAYERS</p>
            <p className="text-[9px] text-white/20 font-mono mt-0.5">Overlay intelligence on field map</p>
          </div>

          <div className="p-3 space-y-2">
            {ANALYTICAL_LAYERS.map(layer => {
              const Icon = layer.icon;
              const active = activeLayers[layer.key];
              const count = counts[layer.key] || 0;

              return (
                <div key={layer.key}
                  className="flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all group"
                  style={{
                    background: active ? `${layer.color}0e` : "rgba(255,255,255,.02)",
                    border: `1px solid ${active ? `${layer.color}35` : "rgba(255,255,255,.05)"}`,
                  }}
                  onClick={() => onToggle(layer.key)}
                >
                  {/* Toggle dot */}
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-all" style={{
                    background: active ? `${layer.color}20` : "rgba(255,255,255,.04)",
                    border: `1px solid ${active ? `${layer.color}50` : "rgba(255,255,255,.08)"}`,
                    boxShadow: active ? `0 0 8px ${layer.color}30` : "none",
                  }}>
                    <Icon className="w-4 h-4" style={{ color: active ? layer.color : "rgba(255,255,255,.3)" }} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-black text-white leading-tight truncate" style={{ fontFamily: "Sora, sans-serif" }}>{layer.label}</p>
                      {count > 0 && (
                        <span className="text-[8px] font-bold font-mono px-1.5 py-0.5 rounded-full shrink-0" style={{ background: `${layer.color}15`, color: layer.color, border: `1px solid ${layer.color}30` }}>
                          {count}
                        </span>
                      )}
                    </div>
                    <p className="text-[9px] text-white/30 font-mono mt-0.5 truncate">{layer.sublabel}</p>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <LegendTooltip layer={layer} visible={active} />
                    {/* Toggle pill */}
                    <div className="w-8 h-4 rounded-full relative transition-all" style={{
                      background: active ? layer.color : "rgba(255,255,255,.1)",
                      boxShadow: active ? `0 0 8px ${layer.color}50` : "none",
                    }}>
                      <div className="absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all" style={{ left: active ? "18px" : "2px" }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Color legend */}
          <div className="px-4 pb-4">
            <p className="text-[9px] font-bold tracking-[.18em] text-white/20 font-mono mb-2">ZONE LEGEND</p>
            <div className="space-y-1.5">
              {ANALYTICAL_LAYERS.map(layer => (
                <div key={layer.key} className="flex items-center gap-2">
                  <div className="w-6 h-2.5 rounded-sm shrink-0" style={{ background: layer.fillColor, border: `1px solid ${layer.strokeColor}60` }} />
                  <div className="w-1 h-1 rounded-full shrink-0" style={{ background: layer.strokeColor, boxShadow: `0 0 4px ${layer.strokeColor}` }} />
                  <span className="text-[9px] text-white/30 font-mono truncate">{layer.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}