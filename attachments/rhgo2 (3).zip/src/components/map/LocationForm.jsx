import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, MapPin } from "lucide-react";
import { base44 } from "@/api/base44Client";

const SITE_TYPES = [
  { value: "creek", label: "Creek" },
  { value: "river", label: "River" },
  { value: "roadcut", label: "Roadcut" },
  { value: "quarry", label: "Quarry" },
  { value: "tailings_pile", label: "Tailings Pile" },
  { value: "beach", label: "Beach" },
  { value: "pay_to_dig", label: "Pay-to-Dig" },
  { value: "public_land", label: "Public Land (BLM/USFS)" },
  { value: "private_land", label: "Private Land" },
  { value: "mine", label: "Mine" },
  { value: "desert", label: "Desert" },
  { value: "mountain", label: "Mountain" },
  { value: "other", label: "Other" },
];

const DIFFICULTIES = [
  { value: "easy", label: "Easy" },
  { value: "moderate", label: "Moderate" },
  { value: "difficult", label: "Difficult" },
  { value: "expert", label: "Expert" },
];

function FieldError({ error }) {
  if (!error) return null;
  return <p className="text-red-400 text-xs mt-1">{error}</p>;
}

function validateForm(form) {
  const errors = {};
  if (!form.name || form.name.trim().length < 3) errors.name = "Name must be at least 3 characters.";
  if (form.name && form.name.trim().length > 80) errors.name = "Name must be 80 characters or fewer.";
  if (!form.latitude || isNaN(parseFloat(form.latitude)) || parseFloat(form.latitude) < -90 || parseFloat(form.latitude) > 90)
    errors.latitude = "Latitude must be between -90 and 90.";
  if (!form.longitude || isNaN(parseFloat(form.longitude)) || parseFloat(form.longitude) < -180 || parseFloat(form.longitude) > 180)
    errors.longitude = "Longitude must be between -180 and 180.";
  if (!form.site_type) errors.site_type = "Site type is required.";
  if (!form.difficulty) errors.difficulty = "Difficulty is required.";
  if (!form.description || form.description.trim().length < 30)
    errors.description = "Description must be at least 30 characters.";
  if (form.site_type === "private_land") {
    if (!form.access_info || form.access_info.trim().length < 5)
      errors.access_info = "Access notes are required for private land.";
    if (!form.permission_confirmed)
      errors.permission_confirmed = "You must confirm you have permission to access private land.";
  }
  return errors;
}

export default function LocationForm({ initialValues = {}, onSubmit, onCancel, submitLabel = "Save Location", isSubmitting = false, isAdmin = false }) {
  const [form, setForm] = useState({
    name: "",
    address: "",
    latitude: "",
    longitude: "",
    state: "",
    minerals_found: "",
    site_type: "public_land",
    difficulty: "moderate",
    description: "",
    access_info: "",
    permission_confirmed: false,
    public_access_notes: "",
    commercial_collecting_details: "",
    ...initialValues,
    minerals_found: Array.isArray(initialValues.minerals_found)
      ? initialValues.minerals_found.join(", ")
      : (initialValues.minerals_found || ""),
  });
  const [errors, setErrors] = useState({});
  const [geocoding, setGeocoding] = useState(false);
  const [geoError, setGeoError] = useState("");

  const set = (key, val) => {
    setForm(f => ({ ...f, [key]: val }));
    if (errors[key]) setErrors(e => ({ ...e, [key]: null }));
  };

  const fetchCoords = async () => {
    if (!form.address.trim()) return;
    setGeocoding(true);
    setGeoError("");
    const response = await base44.functions.invoke("geocodeAddress", { address: form.address });
    const data = response.data;
    if (data && data.latitude != null && data.longitude != null) {
      setForm(f => ({
        ...f,
        latitude: parseFloat(data.latitude).toFixed(6),
        longitude: parseFloat(data.longitude).toFixed(6),
      }));
      setErrors(e => ({ ...e, latitude: null, longitude: null }));
    } else {
      setGeoError(data?.error || "Address not found. Try a different query.");
    }
    setGeocoding(false);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validateForm(form);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      const firstKey = Object.keys(errs)[0];
      document.getElementById(`locform-${firstKey}`)?.focus();
      return;
    }
    const minerals = form.minerals_found.split(",").map(m => m.trim()).filter(Boolean);
    const submitData = {
      ...form,
      latitude: parseFloat(form.latitude),
      longitude: parseFloat(form.longitude),
      minerals_found: minerals,
      public_access_notes: form.public_access_notes?.trim().slice(0, 2000),
      commercial_collecting_details: form.commercial_collecting_details?.trim().slice(0, 2000),
    };
    delete submitData.permission_confirmed;
    onSubmit(submitData);
  };

  const isPrivate = form.site_type === "private_land";

  return (
    <form onSubmit={handleSubmit} className="space-y-4 text-sm">
      {/* Name */}
      <div>
        <Label className="text-white/60 text-xs">Site Name *</Label>
        <Input
          id="locform-name"
          value={form.name}
          onChange={e => set("name", e.target.value)}
          placeholder="e.g. Crystal Mountain BLM Site"
          className="bg-white/5 border-white/10 mt-1 text-white"
          maxLength={80}
        />
        <FieldError error={errors.name} />
      </div>

      {/* Address → Coords */}
      <div>
        <Label className="text-white/60 text-xs">Address / Place Name (optional)</Label>
        <div className="flex gap-2 mt-1">
          <Input
            value={form.address}
            onChange={e => set("address", e.target.value)}
            placeholder="Enter address or place to auto-fill coordinates"
            className="bg-white/5 border-white/10 text-white flex-1"
          />
          <Button
            type="button"
            onClick={fetchCoords}
            disabled={geocoding || !form.address.trim()}
            className="bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 border border-cyan-500/20 shrink-0"
            size="sm"
          >
            {geocoding ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MapPin className="w-3.5 h-3.5" />}
          </Button>
        </div>
        {geoError && <p className="text-orange-400 text-xs mt-1">{geoError}</p>}
      </div>

      {/* Lat/Lng */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-white/60 text-xs">Latitude *</Label>
          <Input
            id="locform-latitude"
            type="number"
            step="any"
            value={form.latitude}
            onChange={e => set("latitude", e.target.value)}
            className="bg-white/5 border-white/10 mt-1 text-white"
            placeholder="-90 to 90"
          />
          <FieldError error={errors.latitude} />
        </div>
        <div>
          <Label className="text-white/60 text-xs">Longitude *</Label>
          <Input
            id="locform-longitude"
            type="number"
            step="any"
            value={form.longitude}
            onChange={e => set("longitude", e.target.value)}
            className="bg-white/5 border-white/10 mt-1 text-white"
            placeholder="-180 to 180"
          />
          <FieldError error={errors.longitude} />
        </div>
      </div>

      {/* State */}
      <div>
        <Label className="text-white/60 text-xs">State / Region</Label>
        <Input
          value={form.state}
          onChange={e => set("state", e.target.value)}
          className="bg-white/5 border-white/10 mt-1 text-white"
          placeholder="e.g. Arizona"
        />
      </div>

      {/* Site Type + Difficulty */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label className="text-white/60 text-xs">Site Type *</Label>
          <Select value={form.site_type} onValueChange={v => set("site_type", v)}>
            <SelectTrigger id="locform-site_type" className="bg-white/5 border-white/10 mt-1 text-white text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SITE_TYPES.map(t => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldError error={errors.site_type} />
        </div>
        <div>
          <Label className="text-white/60 text-xs">Difficulty *</Label>
          <Select value={form.difficulty} onValueChange={v => set("difficulty", v)}>
            <SelectTrigger id="locform-difficulty" className="bg-white/5 border-white/10 mt-1 text-white text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DIFFICULTIES.map(d => (
                <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FieldError error={errors.difficulty} />
        </div>
      </div>

      {/* Minerals */}
      <div>
        <Label className="text-white/60 text-xs">Minerals Found (comma separated)</Label>
        <Input
          value={form.minerals_found}
          onChange={e => set("minerals_found", e.target.value)}
          placeholder="Quartz, Amethyst, Garnet"
          className="bg-white/5 border-white/10 mt-1 text-white"
        />
      </div>

      {/* Description */}
      <div>
        <Label className="text-white/60 text-xs">Description * <span className="text-white/30">(min 30 chars)</span></Label>
        <Textarea
          id="locform-description"
          value={form.description}
          onChange={e => set("description", e.target.value)}
          className="bg-white/5 border-white/10 mt-1 text-white"
          rows={3}
          placeholder="Describe the site, what to look for, conditions, geological notes..."
        />
        <div className="flex justify-between items-center mt-0.5">
          <FieldError error={errors.description} />
          <span className={`text-[10px] ml-auto ${form.description.length < 30 ? "text-white/20" : "text-emerald-400"}`}>
            {form.description.length} chars
          </span>
        </div>
      </div>

      {/* Access Info */}
      <div>
        <Label className="text-white/60 text-xs">
          Access Notes {isPrivate && <span className="text-orange-400">*</span>}
        </Label>
        <Textarea
          id="locform-access_info"
          value={form.access_info}
          onChange={e => set("access_info", e.target.value)}
          className="bg-white/5 border-white/10 mt-1 text-white"
          rows={2}
          placeholder="Parking, trail distance, gate codes, landowner contacts..."
        />
        <FieldError error={errors.access_info} />
      </div>

      {/* Private land confirmation */}
      {isPrivate && (
        <div id="locform-permission_confirmed" className={`flex items-start gap-3 p-3 rounded-lg border ${errors.permission_confirmed ? "border-red-500/40 bg-red-500/5" : "border-orange-500/20 bg-orange-500/5"}`}>
          <input
            type="checkbox"
            id="perm-check"
            checked={form.permission_confirmed}
            onChange={e => set("permission_confirmed", e.target.checked)}
            className="accent-orange-500 mt-0.5 shrink-0"
          />
          <label htmlFor="perm-check" className="text-xs text-orange-300 cursor-pointer leading-relaxed">
            I confirm I have legal permission from the landowner to access and collect at this private property, and I understand sharing this location publicly may affect that permission.
          </label>
        </div>
      )}
      {errors.permission_confirmed && <FieldError error={errors.permission_confirmed} />}

      {/* Admin-only fields */}
      {isAdmin && (
        <>
          <div>
            <Label className="text-white/60 text-xs">Public Access Notes <span className="text-white/30">(admin, max 2000)</span></Label>
            <Textarea
              value={form.public_access_notes}
              onChange={e => set("public_access_notes", e.target.value)}
              className="bg-white/5 border-white/10 mt-1 text-white"
              rows={3}
              maxLength={2000}
              placeholder="General guidance on public access rules for this land type..."
            />
            <span className={`text-[10px] ${form.public_access_notes.length > 1800 ? "text-orange-400" : "text-white/20"}`}>
              {form.public_access_notes.length}/2000
            </span>
          </div>
          <div>
            <Label className="text-white/60 text-xs">Commercial Collecting Details <span className="text-white/30">(admin, max 2000)</span></Label>
            <Textarea
              value={form.commercial_collecting_details}
              onChange={e => set("commercial_collecting_details", e.target.value)}
              className="bg-white/5 border-white/10 mt-1 text-white"
              rows={3}
              maxLength={2000}
              placeholder="Commercial collecting rules and restrictions..."
            />
            <span className={`text-[10px] ${form.commercial_collecting_details.length > 1800 ? "text-orange-400" : "text-white/20"}`}>
              {form.commercial_collecting_details.length}/2000
            </span>
          </div>
        </>
      )}

      {/* Actions */}
      <div className="flex gap-2 pt-1">
        <Button
          type="submit"
          disabled={isSubmitting}
          className="flex-1 bg-gradient-to-r from-amber-500 to-orange-600 text-white font-semibold"
        >
          {isSubmitting ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
          {submitLabel}
        </Button>
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel} className="text-white/40 hover:text-white/70">
            Cancel
          </Button>
        )}
      </div>
    </form>
  );
}