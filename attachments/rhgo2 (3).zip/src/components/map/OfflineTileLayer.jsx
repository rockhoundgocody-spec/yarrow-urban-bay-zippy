/**
 * OfflineTileLayer
 * A Leaflet TileLayer that automatically serves cached tiles from IndexedDB
 * when the device is offline, and live OSM tiles when online.
 *
 * Drop-in replacement for a standard Leaflet TileLayer in any react-leaflet map.
 */
import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { getCachedTile } from "@/lib/services/offlineTileCache";
import { OSM_TILE_URL } from "@/lib/services/MapDownloader";

// Custom Leaflet TileLayer that serves IndexedDB-cached tiles when offline
const OfflineTileLayerClass = L.TileLayer.extend({
  createTile(coords, done) {
    const tile = document.createElement("img");
    const url  = OSM_TILE_URL(coords.z, coords.x, coords.y);

    tile.setAttribute("role", "presentation");
    tile.setAttribute("alt",  "");
    tile.style.opacity = "0";
    tile.style.transition = "opacity 0.2s";

    const onLoad = () => {
      tile.style.opacity = "1";
      done(null, tile);
    };
    const onError = (err) => done(err, tile);

    if (navigator.onLine) {
      tile.src = url;
      tile.onload  = onLoad;
      tile.onerror = onError;
    } else {
      // Offline: serve from IndexedDB cache
      getCachedTile(url).then((dataUrl) => {
        if (dataUrl) {
          tile.src = dataUrl;
          tile.onload  = onLoad;
          tile.onerror = onError;
        } else {
          // No cache: show placeholder
          tile.style.opacity = "0.15";
          tile.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
          done(null, tile);
        }
      }).catch(() => done(null, tile));
    }

    return tile;
  },
});

export default function OfflineTileLayer({ attribution, ...props }) {
  const map       = useMap();
  const layerRef  = useRef(null);
  const onlineRef = useRef(navigator.onLine);

  useEffect(() => {
    // Create and add the custom layer
    const layer = new OfflineTileLayerClass("", {
      attribution: attribution || '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
      ...props,
    });
    layer.addTo(map);
    layerRef.current = layer;

    // Reload tiles on network change so the map re-fetches / re-serves from cache
    const handleOnline = () => {
      if (!onlineRef.current) {
        onlineRef.current = true;
        layer.redraw();
      }
    };
    const handleOffline = () => {
      onlineRef.current = false;
      layer.redraw();
    };

    window.addEventListener("online",  handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      window.removeEventListener("online",  handleOnline);
      window.removeEventListener("offline", handleOffline);
      map.removeLayer(layer);
    };
  }, [map]);  

  return null;
}