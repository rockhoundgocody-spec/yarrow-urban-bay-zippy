/**
 * LocationPopup — map location details with integrated field guide.
 * Shows location info (minerals found, difficulty, access) + AI field guide
 * if the location's primary mineral has been enriched.
 * 
 * Used in GeoSearchMap, RockhoundingMap, and other map components.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import FieldGuidePanel from '@/components/fieldguide/FieldGuidePanel';
import { base44 } from '@/api/base44Client';

export default function LocationPopup({ location, onClose }) {
  const [fieldGuide, setFieldGuide] = useState(null);
  const [guideLoading, setGuideLoading] = useState(false);
  const [guideFetched, setGuideFetched] = useState(false);

  // Fetch field guide on first mount using primary mineral
  useEffect(() => {
    if (!location || guideFetched) return;

    const primaryMineral = location.minerals_found?.[0] || location.name;
    if (!primaryMineral) return;

    setGuideLoading(true);
    setGuideFetched(true);

    base44.functions
      .invoke('fieldGuideEnrich', {
        mineral_name: primaryMineral,
        location: `${location.state || ''} ${location.county || ''}`.trim(),
        rarity_tier: location.rarity || undefined,
        confidence: 85,
      })
      .then((res) => {
        if (res?.data?.guide) {
          setFieldGuide(res.data.guide);
        }
      })
      .catch((err) => {
        console.warn('Field guide fetch failed:', err);
      })
      .finally(() => {
        setGuideLoading(false);
      });
  }, [location, guideFetched]);

  if (!location) return null;

  return (
    <motion.div
      className="rounded-xl overflow-hidden shadow-2xl"
      style={{
        background: 'linear-gradient(135deg, rgba(10,15,22,0.97) 0%, rgba(6,10,18,0.99) 100%)',
        border: '1px solid rgba(0,214,143,0.2)',
        boxShadow: '0 8px 40px rgba(0,0,0,0.7), 0 0 20px rgba(0,214,143,0.08)',
      }}
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -10, scale: 0.95 }}
      transition={{ duration: 0.2 }}
    >
      <div className="p-4 space-y-3 max-w-sm max-h-[70vh] overflow-y-auto">
        {/* Header */}
        <div>
          <h3 className="text-sm font-bold text-white">{location.name}</h3>
          {location.state && (
            <p className="text-xs text-white/50 mt-0.5">
              {location.state}
              {location.county && ` • ${location.county}`}
            </p>
          )}
        </div>

        {/* Location details */}
        {(location.difficulty || location.minerals_found?.length > 0) && (
          <div className="rounded-lg bg-white/5 border border-white/8 p-2.5 text-xs space-y-1.5">
            {location.difficulty && (
              <div className="flex items-center justify-between">
                <span className="text-white/50">Difficulty:</span>
                <span
                  className="font-semibold px-2 py-0.5 rounded text-[10px]"
                  style={{
                    background:
                      location.difficulty === 'easy'
                        ? 'rgba(34,197,94,0.2)'
                        : location.difficulty === 'moderate'
                        ? 'rgba(245,158,11,0.2)'
                        : 'rgba(239,68,68,0.2)',
                    color:
                      location.difficulty === 'easy'
                        ? '#22C55E'
                        : location.difficulty === 'moderate'
                        ? '#F59E0B'
                        : '#EF4444',
                  }}
                >
                  {location.difficulty}
                </span>
              </div>
            )}
            {location.minerals_found?.length > 0 && (
              <div>
                <p className="text-white/50 mb-1">Minerals Found:</p>
                <div className="flex flex-wrap gap-1">
                  {location.minerals_found.slice(0, 4).map((m, i) => (
                    <span
                      key={i}
                      className="text-[10px] px-2 py-0.5 rounded"
                      style={{
                        background: 'rgba(0,214,143,0.12)',
                        color: '#00D68F',
                        border: '1px solid rgba(0,214,143,0.25)',
                      }}
                    >
                      {m}
                    </span>
                  ))}
                  {location.minerals_found.length > 4 && (
                    <span className="text-[10px] px-2 py-0.5 text-white/40">
                      +{location.minerals_found.length - 4} more
                    </span>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Access info */}
        {location.access_info && (
          <div className="rounded-lg bg-white/5 border border-white/8 p-2.5 text-xs text-white/70">
            <p className="font-semibold text-white mb-1">Access Info:</p>
            <p className="line-clamp-2">{location.access_info}</p>
          </div>
        )}

        {/* Field guide */}
        {(fieldGuide || guideLoading) && (
          <div className="border-t border-white/5 pt-3">
            <FieldGuidePanel guide={fieldGuide} loading={guideLoading} compact={true} />
          </div>
        )}

        {/* Close button */}
        <button
          onClick={onClose}
          className="w-full py-2 rounded-lg text-xs font-semibold transition-colors"
          style={{
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            color: 'rgba(255,255,255,0.6)',
            minHeight: 'unset',
          }}
        >
          Close
        </button>
      </div>
    </motion.div>
  );
}