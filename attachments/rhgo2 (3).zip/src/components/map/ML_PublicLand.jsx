import { useEffect } from 'react';
import { useMapLibre } from './MapLibreContext';

const MANAGER_COLORS = {
  'BLM': '#22c55e', 'USFS': '#16a34a', 'NPS': '#eab308',
  'FWS': '#3b82f6', 'State Park': '#f59e0b', 'State Land': '#84cc16',
};
const EXCLUDE = ['Private', 'Unknown', 'Tribal'];
const SOURCE = 'public-land';

export default function ML_PublicLand({ locations, visible }) {
  const map = useMapLibre();

  useEffect(() => {
    if (!map) return;

    const removeLayers = () => {
      try { if (map.getLayer('public-land-fill')) map.removeLayer('public-land-fill'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };

    const addLayers = () => {
      if (!visible || !locations?.length) { removeLayers(); return; }

      const features = locations
        .filter(l => l.land_manager && !EXCLUDE.includes(l.land_manager) && l.latitude && l.longitude)
        .map(l => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [l.longitude, l.latitude] },
          properties: { color: MANAGER_COLORS[l.land_manager] || '#6b7280', manager: l.land_manager }
        }));

      const geojson = { type: 'FeatureCollection', features };

      if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); return; }
      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({
        id: 'public-land-fill', type: 'circle', source: SOURCE,
        paint: {
          'circle-color': ['get', 'color'],
          'circle-radius': 12,
          'circle-opacity': 0.08,
          'circle-stroke-width': 1.5,
          'circle-stroke-color': ['get', 'color'],
          'circle-stroke-opacity': 0.5,
          // note: circle layers don't support dasharray (line layers only)
        }
      });
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, locations, visible]);

  return null;
}