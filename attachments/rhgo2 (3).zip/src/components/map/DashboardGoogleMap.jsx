import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import WaypointManager from "./WaypointManager";
import MapOfflineCache from "./MapOfflineCache";
import AnalyticalLayersPanel from "./AnalyticalLayersPanel";
import { Loader2, MapPin, Navigation, Layers, Download, Plus } from "lucide-react";

// ── Google Maps loader ────────────────────────────────────────────────────────
let gmapsLoadPromise = null;
function loadGoogleMaps(apiKey) {
  if (window.google?.maps) return Promise.resolve();
  if (gmapsLoadPromise) return gmapsLoadPromise;
  gmapsLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places,geometry`;
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Failed to load Google Maps"));
    document.head.appendChild(script);
  });
  return gmapsLoadPromise;
}

// ── Optimized pin colors with better contrast for field visibility ─────────────
const SITE_COLORS = {
  mine: "#ef4444",
  quarry: "#f97316",
  public_land: "#22c55e",
  beach: "#06b6d4",
  riverbed: "#3b82f6",
  desert: "#eab308",
  mountain: "#a855f7",
  roadcut: "#ec4899",
  fee_dig: "#f59e0b",
  other: "#64748b",
};

const DIFFICULTY_SIZE = { easy: 10, moderate: 12, difficult: 14, expert: 16 };
const MARKER_CACHE = new Map();

function buildPinSVG(color, size = 12, rating = 0) {
  const cacheKey = `${color}-${size}-${rating}`;
  if (MARKER_CACHE.has(cacheKey)) return MARKER_CACHE.get(cacheKey);
  
  const stars = rating >= 4.5 ? "★" : rating >= 3.5 ? "☆" : "";
  const svg = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="${size * 3}" height="${size * 3 + 8}" viewBox="0 0 ${size * 3} ${size * 3 + 8}">
      <defs><filter id="drop"><feDropShadow dx="0" dy="1" stdDeviation="2" flood-opacity="0.4"/></filter></defs>
      <circle cx="${size * 1.5}" cy="${size * 1.5}" r="${size * 1.4}" fill="${color}" stroke="white" stroke-width="2" opacity="1" filter="url(#drop)"/>
      ${stars ? `<text x="${size * 1.5}" y="${size * 1.8}" text-anchor="middle" font-size="${size * 0.85}" fill="white" font-weight="bold" font-family="system-ui">${stars}</text>` : ""}
      <polygon points="${size * 1.5},${size * 3 + 8} ${size},${size * 2.6} ${size * 2},${size * 2.6}" fill="${color}" opacity="1" filter="url(#drop)"/>
    </svg>
  `)}` ;
  MARKER_CACHE.set(cacheKey, svg);
  return svg;
}

function buildWaypointSVG(color = "#a855f7") {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="36" viewBox="0 0 28 36">
      <path d="M14 0 C6.268 0 0 6.268 0 14 C0 22 14 36 14 36 C14 36 28 22 28 14 C28 6.268 21.732 0 14 0Z" fill="${color}" stroke="white" stroke-width="2"/>
      <circle cx="14" cy="14" r="5" fill="white" opacity="0.9"/>
    </svg>
  `)}`;
}

export default function DashboardGoogleMap() {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const waypointMarkersRef = useRef([]);
  const infoWindowRef = useRef(null);
  const analyticalOverlaysRef = useRef([]);
  const addingWaypointRef = useRef(false);

  const [apiKey, setApiKey] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [locations, setLocations] = useState([]);
  const [waypoints, setWaypoints] = useState([]);
  const [activePanel, setActivePanel] = useState(null);
  const [addingWaypoint, setAddingWaypoint] = useState(false);
  const [mapTypeIndex, setMapTypeIndex] = useState(0);
  const [pendingLatLng, setPendingLatLng] = useState(null);
  const [analyticalLayers, setAnalyticalLayers] = useState({
    hazard_zones: false,
    restricted_land: false,
    find_density: false,
  });
  const MAP_TYPES = ["roadmap", "satellite", "terrain", "hybrid"];

  // ── 1. Fetch API key + locations ──────────────────────────────────────────
  useEffect(() => {
    async function init() {
      try {
        const [keyRes, locs, wpts] = await Promise.all([
          base44.functions.invoke("getGoogleMapsKey"),
          base44.entities.RockhoundingLocation.list("-rating_avg", 300),
          loadWaypoints(),
        ]);
        setApiKey(keyRes.data.apiKey);
        setLocations(locs);
        setWaypoints(wpts);
      } catch (e) {
        setError(e.message);
      }
    }
    init();
  }, []);

  async function loadWaypoints() {
    try {
      return await base44.entities.SavedMapConfig.list("-created_date", 100);
    } catch { return []; }
  }

  // ── 2. Init Google Map ────────────────────────────────────────────────────
  useEffect(() => {
    if (!apiKey || !mapRef.current) return;
    loadGoogleMaps(apiKey).then(() => {
      const map = new window.google.maps.Map(mapRef.current, {
        center: { lat: 39.5, lng: -98.35 },
        zoom: 5,
        mapTypeId: "roadmap",
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
        zoomControlOptions: { position: window.google.maps.ControlPosition.RIGHT_CENTER },
        styles: darkMapStyles,
      });
      mapInstanceRef.current = map;
      infoWindowRef.current = new window.google.maps.InfoWindow();
      map.addListener("click", (e) => {
        if (!addingWaypointRef.current) return;
        openWaypointForm(e.latLng.lat(), e.latLng.lng());
      });
      setLoading(false);
    }).catch(e => setError(e.message));
  }, [apiKey]);

  // ── 3. Render location pins (memoized with clustering) ───────────────────────
  const clusteredLocations = useMemo(() => {
    if (!locations.length) return [];
    const visible = locations.filter(l => l.latitude && l.longitude);
    // Simple grid-based clustering at zoom 4
    const map = new Map();
    visible.forEach(loc => {
      const gridKey = `${Math.floor(loc.latitude * 2)},${Math.floor(loc.longitude * 2)}`;
      if (!map.has(gridKey)) map.set(gridKey, []);
      map.get(gridKey).push(loc);
    });
    return Array.from(map.values()).map(group => group[0]); // One marker per grid cell
  }, [locations]);

  useEffect(() => {
    if (!mapInstanceRef.current || !window.google) return;
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = [];
    clusteredLocations.forEach(loc => {
      if (!loc.latitude || !loc.longitude) return;
      const color = SITE_COLORS[loc.site_type] || "#888";
      const size = DIFFICULTY_SIZE[loc.difficulty] || 11;
      const marker = new window.google.maps.Marker({
        position: { lat: loc.latitude, lng: loc.longitude },
        map: mapInstanceRef.current,
        icon: {
          url: buildPinSVG(color, size, loc.rating_avg || 0),
          scaledSize: new window.google.maps.Size(size * 3, size * 3 + 8),
          anchor: new window.google.maps.Point(size * 1.5, size * 3 + 8),
        },
        title: loc.name,
      });
      marker.addListener("click", () => {
        const minerals = loc.minerals_found?.slice(0, 4).join(", ") || "Unknown";
        const stars = "★".repeat(Math.round(loc.rating_avg || 0));
        infoWindowRef.current.setContent(`
          <div style="font-family:system-ui;max-width:240px;padding:4px">
            <div style="font-weight:700;font-size:14px;margin-bottom:4px">${loc.name}</div>
            <div style="color:${color};font-size:11px;font-weight:600;margin-bottom:6px;text-transform:uppercase;letter-spacing:.5px">${loc.site_type || "site"}</div>
            ${stars ? `<div style="color:#f59e0b;font-size:13px;margin-bottom:4px">${stars} (${(loc.rating_avg||0).toFixed(1)})</div>` : ""}
            <div style="font-size:12px;color:#555;margin-bottom:4px">💎 ${minerals}</div>
            ${loc.difficulty ? `<div style="font-size:11px;color:#777">Difficulty: ${loc.difficulty}</div>` : ""}
            ${loc.access_type ? `<div style="font-size:11px;color:#777">Access: ${loc.access_type}</div>` : ""}
            ${loc.state ? `<div style="font-size:11px;color:#999;margin-top:4px">${loc.state}${loc.county ? `, ${loc.county}` : ""}</div>` : ""}
          </div>
        `);
        infoWindowRef.current.open(mapInstanceRef.current, marker);
      });
      markersRef.current.push(marker);
      });
      }, [clusteredLocations, mapInstanceRef.current]);

  // ── 4. Render waypoint markers ────────────────────────────────────────────
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google) return;
    waypointMarkersRef.current.forEach(m => m.setMap(null));
    waypointMarkersRef.current = [];
    waypoints.forEach(wp => {
      if (!wp.center_lat || !wp.center_lng) return;
      const marker = new window.google.maps.Marker({
        position: { lat: wp.center_lat, lng: wp.center_lng },
        map: mapInstanceRef.current,
        icon: {
          url: buildWaypointSVG(wp.color || "#a855f7"),
          scaledSize: new window.google.maps.Size(28, 36),
          anchor: new window.google.maps.Point(14, 36),
        },
        title: wp.name,
      });
      marker.addListener("click", () => {
        infoWindowRef.current.setContent(`
          <div style="font-family:system-ui;max-width:200px;padding:4px">
            <div style="font-weight:700;font-size:14px;margin-bottom:2px">${wp.name}</div>
            <div style="font-size:11px;color:#888;margin-bottom:4px">📍 Custom Waypoint</div>
            ${wp.notes ? `<div style="font-size:12px;color:#555">${wp.notes}</div>` : ""}
          </div>
        `);
        infoWindowRef.current.open(mapInstanceRef.current, marker);
      });
      waypointMarkersRef.current.push(marker);
    });
  }, [waypoints, mapInstanceRef.current]);

  // ── 5. Waypoint add-mode ref ──────────────────────────────────────────────
  useEffect(() => { addingWaypointRef.current = addingWaypoint; }, [addingWaypoint]);

  function openWaypointForm(lat, lng) {
    setPendingLatLng({ lat, lng });
    setAddingWaypoint(false);
    setActivePanel("waypoints");
  }

  // ── 6. Analytical layer overlays ──────────────────────────────────────────
  useEffect(() => {
    if (!mapInstanceRef.current || !window.google || !locations.length) return;
    analyticalOverlaysRef.current.forEach(o => o.setMap(null));
    analyticalOverlaysRef.current = [];
    const map = mapInstanceRef.current;
    const iw = infoWindowRef.current;

    // Hazard Zones
    if (analyticalLayers.hazard_zones) {
      locations.filter(loc => loc.hazards?.length > 0 && loc.latitude && loc.longitude).forEach(loc => {
        const circle = new window.google.maps.Circle({
          center: { lat: loc.latitude, lng: loc.longitude },
          radius: 8000,
          map,
          fillColor: "#ef4444",
          fillOpacity: 0.13,
          strokeColor: "#ef4444",
          strokeOpacity: 0.7,
          strokeWeight: 1.5,
          clickable: true,
        });
        circle.addListener("click", () => {
          iw.setContent(`<div style="font-family:system-ui;max-width:220px;padding:4px">
            <div style="color:#ef4444;font-weight:700;font-size:12px;letter-spacing:.5px;margin-bottom:4px">⚠ HAZARD ZONE</div>
            <div style="font-weight:600;font-size:13px;margin-bottom:4px">${loc.name}</div>
            <div style="font-size:11px;color:#666">${loc.hazards.join(" · ")}</div>
          </div>`);
          iw.setPosition({ lat: loc.latitude, lng: loc.longitude });
          iw.open(map);
        });
        analyticalOverlaysRef.current.push(circle);
      });
    }

    // Restricted Land
    if (analyticalLayers.restricted_land) {
      locations
        .filter(loc => loc.latitude && loc.longitude &&
          (loc.permit_required || loc.wilderness_overlap || loc.monument_overlap ||
           ["NPS", "FWS", "Tribal"].includes(loc.land_manager)))
        .forEach(loc => {
          const circle = new window.google.maps.Circle({
            center: { lat: loc.latitude, lng: loc.longitude },
            radius: 12000,
            map,
            fillColor: "#f4b544",
            fillOpacity: 0.10,
            strokeColor: "#f4b544",
            strokeOpacity: 0.6,
            strokeWeight: 1.5,
            clickable: true,
          });
          circle.addListener("click", () => {
            const reasons = [
              loc.permit_required && "Permit required",
              loc.wilderness_overlap && "Wilderness overlap",
              loc.monument_overlap && "Monument overlap",
              loc.land_manager && `Managed: ${loc.land_manager}`,
            ].filter(Boolean);
            iw.setContent(`<div style="font-family:system-ui;max-width:220px;padding:4px">
              <div style="color:#f4b544;font-weight:700;font-size:12px;letter-spacing:.5px;margin-bottom:4px">🚧 RESTRICTED LAND</div>
              <div style="font-weight:600;font-size:13px;margin-bottom:4px">${loc.name}</div>
              <div style="font-size:11px;color:#666">${reasons.join(" · ")}</div>
            </div>`);
            iw.setPosition({ lat: loc.latitude, lng: loc.longitude });
            iw.open(map);
          });
          analyticalOverlaysRef.current.push(circle);
        });
    }

    // Historical Find Density
    if (analyticalLayers.find_density) {
      locations
        .filter(loc => loc.latitude && loc.longitude && (loc.minerals_found?.length || 0) > 0)
        .forEach(loc => {
          const count = loc.minerals_found?.length || 1;
          const radius = Math.min(4000 + count * 1800, 28000);
          const circle = new window.google.maps.Circle({
            center: { lat: loc.latitude, lng: loc.longitude },
            radius,
            map,
            fillColor: "#00d47e",
            fillOpacity: Math.min(0.06 + count * 0.015, 0.22),
            strokeColor: "#00d47e",
            strokeOpacity: 0.5,
            strokeWeight: 1,
            clickable: true,
          });
          circle.addListener("click", () => {
            iw.setContent(`<div style="font-family:system-ui;max-width:220px;padding:4px">
              <div style="color:#00d47e;font-weight:700;font-size:12px;letter-spacing:.5px;margin-bottom:4px">💎 FIND DENSITY ZONE</div>
              <div style="font-weight:600;font-size:13px;margin-bottom:4px">${loc.name}</div>
              <div style="font-size:11px;color:#555;margin-bottom:3px">${count} documented mineral${count !== 1 ? "s" : ""}</div>
              <div style="font-size:11px;color:#777">${loc.minerals_found?.slice(0, 5).join(", ")}</div>
            </div>`);
            iw.setPosition({ lat: loc.latitude, lng: loc.longitude });
            iw.open(map);
          });
          analyticalOverlaysRef.current.push(circle);
        });
    }
  }, [analyticalLayers, locations, mapInstanceRef.current]);

  const toggleAnalyticalLayer = useCallback((key) => {
    setAnalyticalLayers(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const analyticalCounts = {
    hazard_zones: locations.filter(l => l.hazards?.length > 0).length,
    restricted_land: locations.filter(l =>
      l.permit_required || l.wilderness_overlap || l.monument_overlap ||
      ["NPS", "FWS", "Tribal"].includes(l.land_manager)).length,
    find_density: locations.filter(l => (l.minerals_found?.length || 0) > 0).length,
  };

  // ── Map type cycle ────────────────────────────────────────────────────────
  const cycleMapType = useCallback(() => {
    const next = (mapTypeIndex + 1) % MAP_TYPES.length;
    setMapTypeIndex(next);
    mapInstanceRef.current?.setMapTypeId(MAP_TYPES[next]);
  }, [mapTypeIndex]);

  // ── Center on user ────────────────────────────────────────────────────────
  const centerOnUser = useCallback(() => {
    navigator.geolocation?.getCurrentPosition(({ coords }) => {
      mapInstanceRef.current?.panTo({ lat: coords.latitude, lng: coords.longitude });
      mapInstanceRef.current?.setZoom(11);
    });
  }, []);

  const refreshWaypoints = async () => {
    const wpts = await loadWaypoints();
    setWaypoints(wpts);
  };

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="relative w-full rounded-2xl overflow-hidden" style={{ height: 420, background: "#111" }}>

      <div ref={mapRef} className="absolute inset-0" />

      {loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0a0a15] z-20">
          <Loader2 className="w-7 h-7 text-cyan-400 animate-spin mb-3" />
          <p className="text-white/50 text-sm">Loading live map...</p>
        </div>
      )}

      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0a0a15] z-20 p-6 text-center">
          <MapPin className="w-8 h-8 text-red-400/50 mb-3" />
          <p className="text-white/50 text-sm">{error}</p>
        </div>
      )}

      {!loading && !error && (
        <div className="absolute top-3 left-3 z-10 px-3 py-1.5 rounded-xl text-xs font-semibold text-white/80"
          style={{ background: "rgba(10,10,21,0.75)", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.08)" }}>
          <span className="text-cyan-400">{locations.length}</span> sites · <span className="text-purple-400">{waypoints.length}</span> waypoints
        </div>
      )}

      {!loading && !error && (
        <div className="absolute top-3 right-14 z-10">
          <AnalyticalLayersPanel
            activeLayers={analyticalLayers}
            onToggle={toggleAnalyticalLayer}
            counts={analyticalCounts}
          />
        </div>
      )}

      {!loading && !error && (
        <div className="absolute right-3 top-3 z-10 flex flex-col gap-2">
          {[
            { icon: Navigation, label: "My Location", action: centerOnUser, color: "text-cyan-400" },
            { icon: Layers, label: "Map Type", action: cycleMapType, color: "text-amber-400" },
            {
              icon: Plus, label: addingWaypoint ? "Cancel" : "Add Waypoint",
              action: () => setAddingWaypoint(w => !w),
              color: addingWaypoint ? "text-red-400" : "text-purple-400",
            },
            { icon: Download, label: "Offline Cache", action: () => setActivePanel(p => p === "offline" ? null : "offline"), color: "text-emerald-400" },
          ].map(({ icon: Icon, label, action, color }) => (
            <button key={label} onClick={action} title={label} aria-label={label}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:scale-105 active:scale-95"
              style={{ background: "rgba(10,10,21,0.82)", backdropFilter: "blur(8px)", border: "1px solid rgba(255,255,255,0.1)" }}>
              <Icon className={`w-4 h-4 ${color}`} />
            </button>
          ))}
        </div>
      )}

      {addingWaypoint && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 px-4 py-2 rounded-xl text-sm font-medium text-white"
          style={{ background: "rgba(168,85,247,0.85)", backdropFilter: "blur(8px)" }}>
          Tap anywhere on the map to place a waypoint
        </div>
      )}

      {!loading && !error && (
        <div className="absolute bottom-3 left-3 z-10 flex flex-wrap gap-1.5 max-w-[60%]">
          {Object.entries(SITE_COLORS).slice(0, 5).map(([type, color]) => (
            <span key={type} className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium text-white/70"
              style={{ background: "rgba(10,10,21,0.75)", border: `1px solid ${color}40` }}>
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: color }} />
              {type.replace("_", " ")}
            </span>
          ))}
        </div>
      )}

      {activePanel === "waypoints" && (
        <div className="absolute inset-y-0 right-0 w-72 z-20 overflow-y-auto"
          style={{ background: "rgba(10,10,21,0.95)", backdropFilter: "blur(16px)", borderLeft: "1px solid rgba(255,255,255,0.08)" }}>
          <WaypointManager
            pendingLatLng={pendingLatLng}
            onClose={() => { setActivePanel(null); setPendingLatLng(null); }}
            onSaved={refreshWaypoints}
          />
        </div>
      )}

      {activePanel === "offline" && (
        <div className="absolute inset-y-0 right-0 w-72 z-20 overflow-y-auto"
          style={{ background: "rgba(10,10,21,0.95)", backdropFilter: "blur(16px)", borderLeft: "1px solid rgba(255,255,255,0.08)" }}>
          <MapOfflineCache
            mapInstance={mapInstanceRef.current}
            locations={locations}
            onClose={() => setActivePanel(null)}
          />
        </div>
      )}
    </div>
  );
}

// ── Enhanced dark map style with better contrast ───────────────────────────────
const darkMapStyles = [
  { elementType: "geometry", stylers: [{ color: "#0f172a" }] },
  { elementType: "labels.text.fill", stylers: [{ color: "#94a3b8" }] },
  { elementType: "labels.text.stroke", stylers: [{ color: "#1e293b" }] },
  { featureType: "water", elementType: "geometry", stylers: [{ color: "#0c2542" }] },
  { featureType: "water", elementType: "labels.text.fill", stylers: [{ color: "#64748b" }] },
  { featureType: "road", elementType: "geometry", stylers: [{ color: "#334155" }] },
  { featureType: "road", elementType: "geometry.stroke", stylers: [{ color: "#1e293b" }] },
  { featureType: "road.highway", elementType: "geometry", stylers: [{ color: "#475569" }] },
  { featureType: "road.highway", elementType: "geometry.stroke", stylers: [{ color: "#334155" }] },
  { featureType: "poi", elementType: "geometry", stylers: [{ color: "#1e3a8a" }] },
  { featureType: "poi.park", elementType: "geometry", stylers: [{ color: "#15803d" }] },
  { featureType: "administrative", elementType: "geometry", stylers: [{ color: "#1e293b" }] },
  { featureType: "administrative", elementType: "geometry.stroke", stylers: [{ color: "#475569" }] },
  { featureType: "administrative.country", elementType: "labels.text.fill", stylers: [{ color: "#cbd5e1" }] },
  { featureType: "transit", stylers: [{ color: "#334155" }] },
];