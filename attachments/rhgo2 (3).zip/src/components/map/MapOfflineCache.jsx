import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, Download, Trash2, Wifi, WifiOff, CheckCircle2, Loader2, Database } from "lucide-react";

const CACHE_DB_NAME = "rockhound_offline_map";
const CACHE_STORE = "locations";

// ── IndexedDB helpers ─────────────────────────────────────────────────────
async function openCache() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(CACHE_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(CACHE_STORE)) {
        db.createObjectStore(CACHE_STORE, { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("regions")) {
        db.createObjectStore("regions", { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function cacheLocations(locations, regionName) {
  const db = await openCache();
  const tx = db.transaction([CACHE_STORE, "regions"], "readwrite");
  locations.forEach(loc => tx.objectStore(CACHE_STORE).put({ ...loc }));
  tx.objectStore("regions").put({
    id: regionName,
    name: regionName,
    cachedAt: new Date().toISOString(),
    count: locations.length,
    sizeKB: Math.round(JSON.stringify(locations).length / 1024),
  });
  return new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
}

async function getCachedRegions() {
  const db = await openCache();
  return new Promise((resolve, reject) => {
    const tx = db.transaction("regions", "readonly");
    const req = tx.objectStore("regions").getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function deleteRegion(regionId) {
  const db = await openCache();
  const tx = db.transaction("regions", "readwrite");
  tx.objectStore("regions").delete(regionId);
  return new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
}

async function getTotalCachedCount() {
  const db = await openCache();
  return new Promise((resolve) => {
    const tx = db.transaction(CACHE_STORE, "readonly");
    const req = tx.objectStore(CACHE_STORE).count();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => resolve(0);
  });
}

// ── Preset regions ────────────────────────────────────────────────────────
const PRESET_REGIONS = [
  { id: "southwest_us", name: "Southwest US", label: "AZ, NM, UT, NV", filter: (l) => ["AZ", "NM", "UT", "NV"].includes(l.state) },
  { id: "rocky_mountains", name: "Rocky Mountains", label: "CO, WY, MT, ID", filter: (l) => ["CO", "WY", "MT", "ID"].includes(l.state) },
  { id: "pacific_coast", name: "Pacific Coast", label: "CA, OR, WA", filter: (l) => ["CA", "OR", "WA"].includes(l.state) },
  { id: "appalachians", name: "Appalachians", label: "NC, VA, TN, GA", filter: (l) => ["NC", "VA", "TN", "GA"].includes(l.state) },
  { id: "all_sites", name: "All Sites", label: "Full database", filter: () => true },
];

export default function MapOfflineCache({ locations = [], onClose }) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [cachedRegions, setCachedRegions] = useState([]);
  const [totalCached, setTotalCached] = useState(0);
  const [downloading, setDownloading] = useState(null);
  const [done, setDone] = useState(null);

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    refreshStats();
    return () => { window.removeEventListener("online", onOnline); window.removeEventListener("offline", onOffline); };
  }, []);

  async function refreshStats() {
    const [regions, count] = await Promise.all([getCachedRegions(), getTotalCachedCount()]);
    setCachedRegions(regions);
    setTotalCached(count);
  }

  async function handleDownload(preset) {
    if (!isOnline) return;
    setDownloading(preset.id);
    setDone(null);
    try {
      const filtered = locations.filter(preset.filter);
      // If we need more data for "all_sites", fetch fresh
      let data = filtered;
      if (preset.id === "all_sites" && locations.length < 50) {
        data = await base44.entities.RockhoundingLocation.list("-rating_avg", 2000);
      }
      await cacheLocations(data, preset.id);
      await refreshStats();
      setDone(preset.id);
      setTimeout(() => setDone(null), 2500);
    } finally {
      setDownloading(null);
    }
  }

  async function handleDelete(regionId) {
    await deleteRegion(regionId);
    await refreshStats();
  }

  const cachedIds = new Set(cachedRegions.map(r => r.id));

  return (
    <div className="p-4 space-y-4 h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white/90 flex items-center gap-2">
          <Database className="w-4 h-4 text-emerald-400" /> Offline Cache
        </h3>
        <button onClick={onClose} aria-label="Close offline cache" title="Close" className="text-white/30 hover:text-white/60">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Status */}
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-medium"
        style={{ background: isOnline ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)", border: `1px solid ${isOnline ? "rgba(16,185,129,0.2)" : "rgba(239,68,68,0.2)"}` }}>
        {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-red-400" />}
        <span className={isOnline ? "text-emerald-400" : "text-red-400"}>
          {isOnline ? "Online — download regions for field use" : "Offline — using cached data"}
        </span>
      </div>

      {/* Stats */}
      {totalCached > 0 && (
        <div className="flex items-center gap-2 text-xs text-white/40">
          <span className="text-cyan-400 font-semibold">{totalCached}</span> locations cached locally
        </div>
      )}

      {/* Preset regions */}
      <div className="space-y-2">
        <p className="text-[10px] text-white/30 uppercase tracking-widest">Download Region</p>
        {PRESET_REGIONS.map(preset => {
          const isCached = cachedIds.has(preset.id);
          const isDownloading = downloading === preset.id;
          const isDone = done === preset.id;
          const cached = cachedRegions.find(r => r.id === preset.id);

          return (
            <div key={preset.id} className="flex items-center gap-2 p-2.5 rounded-xl bg-white/[0.03] border border-white/6">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white/85">{preset.name}</p>
                <p className="text-[10px] text-white/35 mt-0.5">
                  {isCached
                    ? `✓ ${cached?.count} sites · ${cached?.sizeKB}KB · ${new Date(cached.cachedAt).toLocaleDateString()}`
                    : preset.label}
                </p>
              </div>
              <div className="flex gap-1 shrink-0">
                {isCached && (
                  <button onClick={() => handleDelete(preset.id)}
                    aria-label={`Delete ${preset.name} cache`} title={`Delete ${preset.name} cache`}
                    className="p-1.5 rounded-lg text-white/20 hover:text-red-400 transition-all">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
                <button
                  onClick={() => handleDownload(preset)}
                  disabled={isDownloading || !isOnline}
                  aria-label={`Download ${preset.name} region`} title={`Download ${preset.name} region`}
                  className="p-1.5 rounded-lg transition-all disabled:opacity-40"
                  style={{ background: isDone ? "rgba(16,185,129,0.2)" : "rgba(0,245,255,0.1)" }}>
                  {isDownloading
                    ? <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                    : isDone
                    ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    : <Download className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <p className="text-[10px] text-white/25 leading-relaxed pt-1">
        Cached data is stored in your browser's IndexedDB and available offline. Clear browser data to remove.
      </p>
    </div>
  );
}