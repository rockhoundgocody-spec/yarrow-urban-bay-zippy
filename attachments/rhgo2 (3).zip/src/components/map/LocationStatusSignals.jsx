/**
 * LocationStatusSignals — compact display of the 5 legal-first location
 * signals (access, collecting, coordinate quality, evidence) inside a
 * hotspot detail sheet. The 5th signal — the gated action — is consumed
 * by the parent (GoSiteSheet) to drive the navigation button.
 */
import React from "react";
import { ShieldCheck, Gem, Crosshair, FileCheck } from "lucide-react";
import { deriveLocationSignals } from "./locationSignals";

const TONE_STYLES = {
  ok:      { color: "#00D68F",            bg: "rgba(0,214,143,0.10)",   border: "rgba(0,214,143,0.30)" },
  info:    { color: "#7AE7FF",            bg: "rgba(122,231,255,0.10)", border: "rgba(122,231,255,0.30)" },
  warning: { color: "#F5B642",            bg: "rgba(245,182,66,0.10)",  border: "rgba(245,182,66,0.30)" },
  danger:  { color: "#ff6b6b",            bg: "rgba(255,107,107,0.10)", border: "rgba(255,107,107,0.30)" },
  unknown: { color: "rgba(255,255,255,0.5)", bg: "rgba(255,255,255,0.05)", border: "rgba(255,255,255,0.12)" },
};

function SignalRow({ icon: Icon, label, value, tone }) {
  const s = TONE_STYLES[tone] || TONE_STYLES.unknown;
  return (
    <div className="flex items-center gap-2.5 py-1.5">
      <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
        style={{ background: s.bg, border: `1px solid ${s.border}` }}>
        <Icon className="w-3.5 h-3.5" style={{ color: s.color }} />
      </div>
      <span className="text-[10px] font-bold uppercase tracking-wide shrink-0"
        style={{ color: "rgba(255,255,255,0.4)" }}>{label}</span>
      <span className="text-xs font-bold ml-auto text-right min-w-0 break-words"
        style={{ color: s.color }}>{value}</span>
    </div>
  );
}

export default function LocationStatusSignals({ site }) {
  const { access, collection, coordinates, evidence } = deriveLocationSignals(site);
  return (
    <div className="mt-3 rounded-2xl p-3 space-y-0.5"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <SignalRow icon={ShieldCheck} label="Access" value={access.label} tone={access.tone} />
      <SignalRow icon={Gem} label="Collecting" value={collection.label} tone={collection.tone} />
      <SignalRow icon={Crosshair} label="Coordinates" value={coordinates.label} tone={coordinates.tone} />
      <SignalRow icon={FileCheck} label="Evidence"
        value={`${evidence.source} · ${evidence.lastVerified}`}
        tone={evidence.isVerified ? "ok" : "warning"} />
    </div>
  );
}