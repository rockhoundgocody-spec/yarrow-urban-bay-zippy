/**
 * ProximityRangeFilter
 * Quick-toggle buttons that filter map locations by distance bands
 * from the user's current GPS position.
 *
 * Ranges: 1-5 mi, 5-10 mi, 10-20 mi.
 * Mutually exclusive — selecting the active range clears it.
 */
import React from "react";
import { Navigation2 } from "lucide-react";

const RANGES = [
  { key: "1-5",   label: "1-5 mi",   min: 1,  max: 5  },
  { key: "5-10",  label: "5-10 mi",  min: 5,  max: 10 },
  { key: "10-20", label: "10-20 mi", min: 10, max: 20 },
];

export { RANGES };

export default function ProximityRangeFilter({ activeRange, onSelect, disabled }) {
  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      <span className="text-[10px] font-bold uppercase tracking-widest text-white/25 mr-0.5 flex items-center gap-1">
        <Navigation2 className="w-2.5 h-2.5" /> Near me
      </span>
      {RANGES.map(r => {
        const active = activeRange === r.key;
        return (
          <button
            key={r.key}
            onClick={() => onSelect(active ? null : r.key)}
            disabled={disabled}
            className="text-[11px] px-2.5 py-1 rounded-full font-semibold transition-all disabled:opacity-40"
            style={{
              background: active ? "rgba(122,231,255,0.15)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${active ? "rgba(122,231,255,0.4)" : "rgba(255,255,255,0.08)"}`,
              color: active ? "#7AE7FF" : "rgba(255,255,255,0.35)",
            }}
          >
            {r.label}
          </button>
        );
      })}
    </div>
  );
}