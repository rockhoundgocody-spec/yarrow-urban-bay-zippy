import { useEffect, useState, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useMapLibre } from './MapLibreContext';

export function pointInPolygon(lat, lng, polygon) {
  let inside = false;
  const n = polygon.length;
  for (let i = 0, j = n - 1; i < n; j = i++) {
    const [yi, xi] = polygon[i];
    const [yj, xj] = polygon[j];
    if ((yi > lat) !== (yj > lat) && lng < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

export function FilterPolygon({ positions, onClear }) {
  const map = useMapLibre();
  const SOURCE = 'filter-polygon';

  useEffect(() => {
    if (!map) return;

    const addPoly = () => {
      if (!positions || positions.length < 3) {
        try { if (map.getLayer('filter-poly-fill')) map.removeLayer('filter-poly-fill'); } catch (_) {}
        try { if (map.getLayer('filter-poly-line')) map.removeLayer('filter-poly-line'); } catch (_) {}
        try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
        return;
      }
      const coords = [...positions, positions[0]].map(([lat, lng]) => [lng, lat]);
      const geojson = { type: 'Feature', geometry: { type: 'Polygon', coordinates: [coords] }, properties: {} };

      if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); return; }
      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({ id: 'filter-poly-fill', type: 'fill', source: SOURCE, paint: { 'fill-color': '#f59e0b', 'fill-opacity': 0.1 } });
      map.addLayer({ id: 'filter-poly-line', type: 'line', source: SOURCE, paint: { 'line-color': '#f59e0b', 'line-width': 2.5 } });
    };

    if (map.isStyleLoaded()) addPoly(); else map.once('load', addPoly);

    return () => {
      try { if (map.getLayer('filter-poly-fill')) map.removeLayer('filter-poly-fill'); } catch (_) {}
      try { if (map.getLayer('filter-poly-line')) map.removeLayer('filter-poly-line'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };
  }, [map, positions]);

  return null;
}

export default function ML_PolygonDrawer({ active, onComplete, onCancel }) {
  const map = useMapLibre();
  const [points, setPoints] = useState([]);
  const pointsRef = useRef([]);
  const markersRef = useRef([]);
  const SOURCE = 'draw-polygon';

  useEffect(() => {
    if (!map) return;
    if (!active) {
      setPoints([]);
      pointsRef.current = [];
      map.getCanvas().style.cursor = '';
      markersRef.current.forEach(m => m.remove());
      markersRef.current = [];
      ['draw-poly-fill', 'draw-poly-line'].forEach(id => { try { if (map.getLayer(id)) map.removeLayer(id); } catch (_) {} });
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
      return;
    }
    map.getCanvas().style.cursor = 'crosshair';
    return () => { map.getCanvas().style.cursor = ''; };
  }, [active, map]);

  useEffect(() => {
    if (!map || !active) return;

    const onClick = (e) => {
      const newPt = [e.lngLat.lat, e.lngLat.lng];
      pointsRef.current = [...pointsRef.current, newPt];
      setPoints([...pointsRef.current]);

      // Dot marker
      const el = document.createElement('div');
      el.style.cssText = 'width:10px;height:10px;border-radius:50%;background:#f59e0b;border:2px solid white;box-shadow:0 1px 4px rgba(0,0,0,0.4);';
      markersRef.current.push(new maplibregl.Marker({ element: el }).setLngLat([e.lngLat.lng, e.lngLat.lat]).addTo(map));

      // Update polygon preview
      const pts = pointsRef.current;
      if (pts.length >= 2) {
        const coords = [...pts, pts[0]].map(([lat, lng]) => [lng, lat]);
        const geojson = { type: 'Feature', geometry: { type: 'Polygon', coordinates: [coords] }, properties: {} };
        if (map.isStyleLoaded()) {
          if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); }
          else {
            map.addSource(SOURCE, { type: 'geojson', data: geojson });
            map.addLayer({ id: 'draw-poly-fill', type: 'fill', source: SOURCE, paint: { 'fill-color': '#f59e0b', 'fill-opacity': 0.12 } });
            map.addLayer({ id: 'draw-poly-line', type: 'line', source: SOURCE, paint: { 'line-color': '#f59e0b', 'line-width': 2, 'line-dasharray': [6, 4] } });
          }
        }
      }
    };

    const onDblClick = (e) => {
      e.preventDefault();
      if (pointsRef.current.length < 3) return;
      onComplete(pointsRef.current);
      pointsRef.current = [];
      setPoints([]);
    };

    map.on('click', onClick);
    map.on('dblclick', onDblClick);
    return () => { map.off('click', onClick); map.off('dblclick', onDblClick); };
  }, [map, active, onComplete]);

  return null;
}