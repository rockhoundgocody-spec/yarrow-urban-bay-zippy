import { createContext, useContext } from 'react';

export const MapLibreContext = createContext(null);

export function useMapLibre() {
  return useContext(MapLibreContext);
}

/**
 * Helper: safely add sources/layers, handling style.load re-fires (e.g. on setStyle).
 * Returns an off() cleanup function.
 */
export function useLayerLifecycle(map, addFn, deps = []) {
  // Not a hook — call this from useEffect
  const add = () => addFn(map);
  if (map.isStyleLoaded()) add();
  else map.once('load', add);
  map.on('style.load', add);
  return () => map.off('style.load', add);
}

/** Remove a source + layers safely */
export function safeRemove(map, layerIds, sourceId) {
  if (!map) return;
  layerIds.forEach(id => { try { if (map.getLayer(id)) map.removeLayer(id); } catch (_) {} });
  if (sourceId) { try { if (map.getSource(sourceId)) map.removeSource(sourceId); } catch (_) {} }
}