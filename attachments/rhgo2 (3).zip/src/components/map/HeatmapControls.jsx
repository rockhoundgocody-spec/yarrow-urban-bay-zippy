import React, { useState } from "react";
import { Layers, RefreshCw, Loader2, X, ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

// Score gradient stops matching GeoHeatmapLayer
const SCORE_LEGEND = [
  { stop: "0%",   color: "#4338ca", label: "Sparse" },
  { stop: "25%",  color: "#2563eb", label: "Low" },
  { stop: "50%",  color: "#06b6d4", label: "Medium" },
  { stop: "70%",  color: "#10b981", label: "Good" },
  { stop: "85%",  color: "#f59e0b", label: "High" },
  { stop: "100%", color: "#dc2626", label: "Prime" },
];

const LAND_OPTIONS = [
  { value: "all",         label: "All Land",     color: "#9ca3af" },
  { value: "public_only", label: "Public Only",  color: "#22c55e" },
  { value: "BLM",         label: "BLM",          color: "#f59e0b" },
  { value: "USFS",        label: "Forest Svc",   color: "#22c55e" },
  { value: "State Land",  label: "State Land",   color: "#38bdf8" },
  { value: "State Park",  label: "State Park",   color: "#a78bfa" },
  { value: "Private",     label: "Private",      color: "#f87171" },
];

const MGR_DOTS = [
  { label: "BLM",         color: "#f59e0b" },
  { label: "Forest Svc",  color: "#22c55e" },
  { label: "State Land",  color: "#38bdf8" },
  { label: "State Park",  color: "#a78bfa" },
  { label: "Wildlife",    color: "#06b6d4" },
  { label: "Natl Park",   color: "#818cf8" },
  { label: "Tribal",      color: "#fb923c" },
  { label: "Private",     color: "#f87171" },
];

export default function HeatmapControls({
  visible, onToggle, loading, onRefresh,
  stats, mineralFilter, onMineralFilterChange,
  landFilter, onLandFilterChange, cacheAge,
}) {
  const [filterInput, setFilterInput] = useState(mineralFilter || "");
  const [panelOpen, setPanelOpen] = useState(false);

  const handleFilterSubmit = (e) => {
    e.preventDefault();
    onMineralFilterChange(filterInput.trim() || null);
  };

  const activeLand = LAND_OPTIONS.find(o => o.value === (landFilter || "all")) || LAND_OPTIONS[0];

  return (
    <div className="absolute bottom-24 left-3 z-[1000] flex flex-col items-start gap-2 pointer-events-none">

      {/* ── Toggle FAB ── */}
      <div className="pointer-events-auto">
        <button
          onClick={onToggle}
          className="flex items-center gap-2 h-9 px-3.5 rounded-2xl text-xs font-bold tracking-wide transition-all select-none"
          style={{
            background: visible
              ? "linear-gradient(135deg, rgba(245,158,11,0.2), rgba(220,38,38,0.15))"
              : "rgba(10,9,28,0.88)",
            border: visible
              ? "1px solid rgba(245,158,11,0.45)"
              : "1px solid rgba(255,255,255,0.1)",
            color: visible ? "#fcd34d" : "rgba(255,255,255,0.45)",
            boxShadow: visible ? "0 0 20px rgba(245,158,11,0.2), 0 4px 16px rgba(0,0,0,0.5)" : "0 4px 16px rgba(0,0,0,0.4)",
            backdropFilter: "blur(20px)",
          }}
        >
          <Layers className="w-3.5 h-3.5" />
          Mineral Intel
          {visible && stats?.total_cells ? (
            <span className="ml-1 text-[9px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ background: "rgba(245,158,11,0.18)", color: "#fcd34d", border: "1px solid rgba(245,158,11,0.3)" }}>
              {stats.total_cells}
            </span>
          ) : null}
          {visible && (
            <span className="opacity-40 ml-0.5">
              {panelOpen ? <ChevronDown className="w-3 h-3 inline" /> : <ChevronUp className="w-3 h-3 inline" />}
            </span>
          )}
        </button>
      </div>

      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.96 }}
            transition={{ duration: 0.2, ease: [0.34, 1.56, 0.64, 1] }}
            className="pointer-events-auto rounded-2xl overflow-hidden"
            style={{
              width: 228,
              background: "linear-gradient(160deg, rgba(8,6,22,0.97), rgba(16,6,32,0.97))",
              border: "1px solid rgba(255,255,255,0.08)",
              boxShadow: "0 0 0 1px rgba(255,255,255,0.03), 0 20px 60px rgba(0,0,0,0.7), 0 0 40px rgba(245,158,11,0.05)",
              backdropFilter: "blur(28px)",
            }}
          >
            {/* Gradient accent bar */}
            <div className="h-[2px] w-full" style={{ background: "linear-gradient(90deg, #4338ca, #06b6d4 40%, #10b981 70%, #f59e0b 85%, #dc2626)" }} />

            {/* Header */}
            <div className="flex items-center justify-between px-3.5 pt-3 pb-2">
              <p className="text-[10px] font-bold uppercase tracking-[0.14em] text-white/45">Mineral Probability</p>
              <div className="flex items-center gap-2">
                {cacheAge && <span className="text-[8px] font-mono text-white/18">{cacheAge}</span>}
                <button
                  onClick={onRefresh}
                  disabled={loading}
                  className="text-white/25 hover:text-amber-400 transition-colors"
                >
                  {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                </button>
              </div>
            </div>

            {/* Gradient legend bar */}
            <div className="px-3.5 pb-3">
              <div className="h-3 w-full rounded-full overflow-hidden mb-1.5"
                style={{ background: "linear-gradient(90deg, #4338ca 0%, #2563eb 20%, #06b6d4 40%, #10b981 60%, #f59e0b 80%, #dc2626 100%)" }} />
              <div className="flex justify-between">
                {["Low", "Mid", "High", "Prime"].map(l => (
                  <span key={l} className="text-[8px] text-white/25 font-mono">{l}</span>
                ))}
              </div>
            </div>

            {/* Land ownership dots legend */}
            <div className="px-3.5 pb-3 border-t border-white/5 pt-2.5">
              <p className="text-[8px] font-bold uppercase tracking-[0.14em] text-white/25 mb-2">Corner dot = ownership</p>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
                {MGR_DOTS.map(({ label, color }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color, boxShadow: `0 0 4px ${color}` }} />
                    <span className="text-[9px] text-white/40">{label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Land filter pills */}
            <div className="px-3.5 pb-3 border-t border-white/5 pt-2.5">
              <p className="text-[8px] font-bold uppercase tracking-[0.14em] text-white/25 mb-2">Land Access Filter</p>
              <div className="flex flex-wrap gap-1">
                {LAND_OPTIONS.map((opt) => {
                  const active = (landFilter || "all") === opt.value;
                  return (
                    <button
                      key={opt.value}
                      onClick={() => onLandFilterChange(opt.value)}
                      className="text-[9px] font-semibold rounded-full px-2 py-1 transition-all"
                      style={{
                        border: `1px solid ${active ? opt.color : "rgba(255,255,255,0.1)"}`,
                        color: active ? opt.color : "rgba(255,255,255,0.35)",
                        background: active ? `${opt.color}1a` : "transparent",
                        boxShadow: active ? `0 0 8px ${opt.color}30` : "none",
                      }}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Mineral filter */}
            <div className="px-3.5 pb-3 border-t border-white/5 pt-2.5">
              <p className="text-[8px] font-bold uppercase tracking-[0.14em] text-white/25 mb-2">Mineral Filter</p>
              <form onSubmit={handleFilterSubmit} className="flex gap-1.5">
                <div className="flex-1 relative">
                  <input
                    value={filterInput}
                    onChange={(e) => setFilterInput(e.target.value)}
                    placeholder="e.g. Turquoise..."
                    className="w-full h-7 bg-white/5 border border-white/10 rounded-xl px-2.5 text-[10px] text-white placeholder-white/20 focus:outline-none focus:border-amber-500/50 focus:bg-white/8 transition-all"
                  />
                </div>
                {filterInput ? (
                  <button
                    type="button"
                    onClick={() => { setFilterInput(""); onMineralFilterChange(null); }}
                    className="h-7 w-7 flex items-center justify-center rounded-xl text-white/30 hover:text-white/60 transition border border-white/8"
                    style={{ background: "rgba(255,255,255,0.04)" }}
                   aria-label="Close">
                    <X className="w-3 h-3" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="h-7 px-2 rounded-xl text-[10px] font-bold text-amber-400/60 hover:text-amber-400 transition border border-white/8"
                    style={{ background: "rgba(255,255,255,0.04)" }}
                   aria-label="Close">→</button>
                )}
              </form>
              {mineralFilter && (
                <p className="text-[9px] text-amber-400/70 mt-1.5 font-mono">Filtering: "{mineralFilter}"</p>
              )}
            </div>

            {/* Stats row */}
            {stats && (
              <div className="grid grid-cols-4 border-t border-white/5">
                {[
                  ["Sites", stats.total_locations],
                  ["Reviews", stats.total_reviews],
                  ["Verif.", stats.total_verifications],
                  ["Cells", stats.total_cells],
                ].map(([label, val]) => (
                  <div key={label} className="flex flex-col items-center py-2.5 border-r border-white/5 last:border-0">
                    <span className="text-[11px] font-bold text-white/60">{val ?? "–"}</span>
                    <span className="text-[8px] text-white/20 uppercase tracking-wider">{label}</span>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}