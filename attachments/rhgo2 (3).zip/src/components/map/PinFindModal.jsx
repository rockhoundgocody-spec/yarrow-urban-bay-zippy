import { useState, useId } from "react";
import { base44 } from "@/api/base44Client";
import { X, MapPin, Camera } from "lucide-react";
import { snapCoords } from "@/lib/geoPrivacy";

const RARITIES = ["common", "uncommon", "rare", "very rare"];
const CATEGORIES = ["mineral", "crystal", "gemstone", "igneous", "sedimentary", "metamorphic", "fossil"];

export default function PinFindModal({ coords, onClose, onSaved }) {
  const fieldId = useId();
  const [form, setForm] = useState({
    mineral_name: "",
    description: "",
    locality_name: "",
    rarity: "uncommon",
    category: "mineral",
    visit_date: new Date().toISOString().split("T")[0],
    finder_display_name: "",
    photo_url: "",
  });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set("photo_url", file_url);
    } catch {
      setError("Photo upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!form.mineral_name.trim()) { setError("Mineral name required."); return; }
    setSaving(true);
    setError(null);
    try {
      // VerifiedFind rows are readable by every signed-in user, so the exact
      // dig spot is never stored — only the ~1 km cell.
      const publicCoords = snapCoords({ lat: coords.lat, lng: coords.lng });
      const record = await base44.entities.VerifiedFind.create({
        ...form,
        latitude: publicCoords.lat,
        longitude: publicCoords.lng,
        verified_by_user: true,
        is_public: true,
      });
      onSaved(record);
    } catch (err) {
      setError(err?.message || "Save failed.");
    } finally {
      setSaving(false);
    }
  };

  const inputStyle = {
    width: "100%", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 10, padding: "10px 12px", color: "#fff", fontSize: 14, outline: "none",
  };
  const labelStyle = { color: "rgba(255,255,255,0.45)", fontSize: 11, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase", display: "block", marginBottom: 5 };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(6px)" }}>
      <div
        className="w-full rounded-t-3xl flex flex-col"
        style={{ maxHeight: "88vh", background: "linear-gradient(160deg, rgba(10,8,22,0.98) 0%, rgba(6,12,20,0.97) 100%)", border: "1px solid rgba(141,124,255,0.20)", borderBottom: "none" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-2">
            <MapPin className="w-5 h-5" style={{ color: "#7AE7FF" }} />
            <span className="font-bold text-base" style={{ color: "#fff" }}>Pin Verified Find</span>
          </div>
          <button onClick={onClose} aria-label="Close" title="Close" className="tap-compact p-1" style={{ color: "rgba(255,255,255,0.4)", minHeight: "unset", minWidth: "unset" }}>
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <div className="overflow-y-auto flex-1 px-5 py-4 flex flex-col gap-4">
          {/* Coords display */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: "rgba(122,231,255,0.06)", border: "1px solid rgba(122,231,255,0.15)" }}>
            <MapPin className="w-4 h-4 flex-shrink-0" style={{ color: "#7AE7FF" }} />
            <div className="flex flex-col">
              <span style={{ color: "rgba(122,231,255,0.8)", fontSize: 12, fontFamily: "monospace" }}>
                {snapCoords({ lat: coords.lat, lng: coords.lng }).lat}, {snapCoords({ lat: coords.lat, lng: coords.lng }).lng}
              </span>
              <span style={{ color: "rgba(122,231,255,0.45)", fontSize: 10 }}>
                Shared as a ~1 km area — your exact spot stays private
              </span>
            </div>
          </div>

          <div>
            <label htmlFor={`${fieldId}-mineral`} style={labelStyle}>Mineral / Rock Name *</label>
            <input id={`${fieldId}-mineral`} aria-invalid={!!error} aria-describedby={error ? `${fieldId}-error` : undefined} style={inputStyle} placeholder="e.g. Amethyst, Quartz, Pyrite…" value={form.mineral_name} onChange={(e) => set("mineral_name", e.target.value)} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor={`${fieldId}-rarity`} style={labelStyle}>Rarity</label>
              <select id={`${fieldId}-rarity`} style={inputStyle} value={form.rarity} onChange={(e) => set("rarity", e.target.value)}>
                {RARITIES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor={`${fieldId}-category`} style={labelStyle}>Category</label>
              <select id={`${fieldId}-category`} style={inputStyle} value={form.category} onChange={(e) => set("category", e.target.value)}>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor={`${fieldId}-locality`} style={labelStyle}>Location Name</label>
            <input id={`${fieldId}-locality`} style={inputStyle} placeholder="e.g. Crystal Cave, AZ" value={form.locality_name} onChange={(e) => set("locality_name", e.target.value)} />
          </div>

          <div>
            <label htmlFor={`${fieldId}-date`} style={labelStyle}>Visit Date</label>
            <input id={`${fieldId}-date`} type="date" style={inputStyle} value={form.visit_date} onChange={(e) => set("visit_date", e.target.value)} />
          </div>

          <div>
            <label htmlFor={`${fieldId}-finder`} style={labelStyle}>Your Display Name</label>
            <input id={`${fieldId}-finder`} style={inputStyle} placeholder="How you'll appear on the map" value={form.finder_display_name} onChange={(e) => set("finder_display_name", e.target.value)} />
          </div>

          <div>
            <label htmlFor={`${fieldId}-notes`} style={labelStyle}>Field Notes</label>
            <textarea
              id={`${fieldId}-notes`}
              style={{ ...inputStyle, minHeight: 72, resize: "none" }}
              placeholder="Describe where and how you found it…"
              value={form.description}
              onChange={(e) => set("description", e.target.value)}
            />
          </div>

          {/* Photo upload */}
          <div>
            <label style={labelStyle}>Photo</label>
            {form.photo_url ? (
              <div className="relative rounded-xl overflow-hidden" style={{ height: 120 }}>
                <img src={form.photo_url} alt="find" className="w-full h-full object-cover" />
                <button onClick={() => set("photo_url", "")} aria-label="Remove photo" title="Remove photo" className="absolute top-2 right-2 rounded-full p-1 tap-compact" style={{ background: "rgba(0,0,0,0.6)", minHeight: "unset", minWidth: "unset" }}>
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 rounded-xl cursor-pointer focus-within:ring-2 focus-within:ring-white/50 focus-within:outline-none" style={{ height: 72, border: "1.5px dashed rgba(122,231,255,0.25)", background: "rgba(122,231,255,0.03)", color: "rgba(122,231,255,0.5)", fontSize: 13 }}>
                <Camera className="w-4 h-4" />
                {uploading ? "Uploading…" : "Tap to add photo"}
                <input type="file" accept="image/*" className="sr-only" onChange={handlePhoto} disabled={uploading} />
              </label>
            )}
          </div>

          {error && <p id={`${fieldId}-error`} role="alert" style={{ color: "#ff6b6b", fontSize: 13, textAlign: "center" }}>{error}</p>}
        </div>

        {/* Save */}
        <div className="px-5 pb-8 pt-3" style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
          <button
            onClick={handleSave}
            disabled={saving || uploading}
            className="w-full py-4 rounded-2xl font-bold text-base transition-all"
            style={{
              background: (saving || uploading) ? "rgba(0,214,143,0.06)" : "linear-gradient(135deg, rgba(0,214,143,0.20) 0%, rgba(122,231,255,0.14) 100%)",
              border: "1.5px solid rgba(0,214,143,0.45)",
              boxShadow: (saving || uploading) ? "none" : "0 0 24px rgba(0,214,143,0.25)",
              color: (saving || uploading) ? "rgba(0,214,143,0.35)" : "#00D68F",
              letterSpacing: "0.06em",
            }}
          >
            {saving ? "Saving…" : "Pin to Community Map"}
          </button>
        </div>
      </div>
    </div>
  );
}