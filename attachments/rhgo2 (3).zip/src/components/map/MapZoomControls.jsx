/**
 * MapZoomControls: zoom, recenter, locate controls for MapLibre
 */
import React from 'react';
import { ZoomIn, ZoomOut, MapPin, Crosshair } from 'lucide-react';
import { motion } from 'framer-motion';

export default function MapZoomControls({ map, onLocate }) {
  const handleZoom = (delta) => {
    if (!map) return;
    map.easeTo({
      zoom: map.getZoom() + delta,
      duration: 300,
    });
  };

  const handleRecenter = () => {
    if (!map) return;
    map.easeTo({
      center: [map.getCenter().lng, map.getCenter().lat],
      zoom: 12,
      duration: 500,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      className="fixed right-4 bottom-32 z-20 flex flex-col gap-2"
    >
      {/* Zoom In */}
      <button
        onClick={() => handleZoom(1)}
        className="w-12 h-12 rounded-lg bg-white border border-border shadow-lg flex items-center justify-center hover:bg-background transition-colors"
        title="Zoom in"
        aria-label="Zoom in"
      >
        <ZoomIn className="w-5 h-5 text-foreground" />
      </button>

      {/* Zoom Out */}
      <button
        onClick={() => handleZoom(-1)}
        className="w-12 h-12 rounded-lg bg-white border border-border shadow-lg flex items-center justify-center hover:bg-background transition-colors"
        title="Zoom out"
        aria-label="Zoom out"
      >
        <ZoomOut className="w-5 h-5 text-foreground" />
      </button>

      {/* Recenter */}
      <button
        onClick={handleRecenter}
        className="w-12 h-12 rounded-lg bg-white border border-border shadow-lg flex items-center justify-center hover:bg-background transition-colors"
        title="Recenter map"
        aria-label="Recenter map"
      >
        <Crosshair className="w-5 h-5 text-foreground" />
      </button>

      {/* Locate Me */}
      <button
        onClick={onLocate}
        className="w-12 h-12 rounded-lg bg-primary text-primary-foreground border border-primary shadow-lg flex items-center justify-center hover:bg-primary/90 transition-colors"
        title="Find my location"
        aria-label="Find my location"
      >
        <MapPin className="w-5 h-5" />
      </button>
    </motion.div>
  );
}