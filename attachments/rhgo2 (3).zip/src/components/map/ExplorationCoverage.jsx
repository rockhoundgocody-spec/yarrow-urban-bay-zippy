import React, { useMemo } from "react";
import { useMap } from "react-leaflet";
import { Badge } from "@/components/ui/badge";

function ExplorationCoverageInner({ userVisited = [] }) {
  const map = useMap();

  const explorationPercentage = useMemo(() => {
    if (!userVisited.length || !map) return 0;
    const bounds = map.getBounds();
    const visibleArea = bounds.toBBoxString().split(",");
    const visibleLat = parseFloat(visibleArea[2]) - parseFloat(visibleArea[0]);
    const visibleLng = parseFloat(visibleArea[3]) - parseFloat(visibleArea[1]);

    let visitedInView = 0;
    userVisited.forEach((loc) => {
      if (
        loc.latitude >= parseFloat(visibleArea[0]) &&
        loc.latitude <= parseFloat(visibleArea[2]) &&
        loc.longitude >= parseFloat(visibleArea[1]) &&
        loc.longitude <= parseFloat(visibleArea[3])
      ) {
        visitedInView++;
      }
    });

    const approximateGridSize = Math.sqrt(visibleLat * visibleLng) / 5;
    const maxPossiblePoints = Math.ceil((visibleLat / approximateGridSize) * (visibleLng / approximateGridSize));
    const percentage = maxPossiblePoints > 0 ? Math.round((visitedInView / maxPossiblePoints) * 100) : 0;
    return Math.min(percentage, 100);
  }, [userVisited, map]);

  return (
    <div className="absolute bottom-6 left-4 z-[400] bg-[#14141e]/95 backdrop-blur-sm border border-white/10 rounded-lg p-3 md:p-4 space-y-2">
      <div className="flex items-center gap-2">
        <span className="text-xs md:text-sm font-semibold text-white">🗺 Region Coverage</span>
        <Badge className="bg-blue-500/20 text-blue-300 text-[10px]">{explorationPercentage}%</Badge>
      </div>
      <div className="w-32 md:w-40 h-2 bg-white/10 rounded-full overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-500"
          style={{ width: `${explorationPercentage}%` }}
        />
      </div>
      <p className="text-[10px] md:text-xs text-white/50">
        {explorationPercentage === 100 ? "Fully explored! 🎉" : "Keep exploring this region"}
      </p>
    </div>
  );
}

// Wraps with a visibility guard — must be placed inside MapContainer
export default function ExplorationCoverage({ userVisited = [], visible = true }) {
  if (!visible) return null;
  return <ExplorationCoverageInner userVisited={userVisited} />;
}