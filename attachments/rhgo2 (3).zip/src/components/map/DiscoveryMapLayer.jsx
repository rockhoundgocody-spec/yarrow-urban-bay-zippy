import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { Star, Heart, MessageCircle } from 'lucide-react';

// Custom discovery marker icon
const createDiscoveryMarker = (rarity) => {
  const rarityColors = {
    common: '#7AE7FF',
    uncommon: '#F5B642',
    rare: '#8D7CFF',
    epic: '#00D68F',
    legendary: '#FF006E',
  };

  const color = rarityColors[rarity] || '#7AE7FF';
  const html = `
    <div style="
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background: ${color}20;
      border: 2px solid ${color};
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 0 12px ${color}60;
    ">
      <div style="
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: ${color};
      "></div>
    </div>
  `;

  return L.divIcon({
    html,
    iconSize: [36, 36],
    className: 'discovery-marker',
  });
};

export default function DiscoveryMapLayer({ onDiscoveryClick }) {
  const { data: discoveries = [] } = useQuery({
    queryKey: ['discoveries_map'],
    queryFn: async () => {
      try {
        const result = await base44.entities.Discovery.filter({
          is_shared: true,
        });
        return result || [];
      } catch (err) {
        console.error('Failed to fetch discoveries:', err);
        return [];
      }
    },
    refetchInterval: 60000, // Refresh every minute
  });

  return (
    <>
      {discoveries.map((discovery) => {
        const lat = discovery.latitude_display || discovery.latitude;
        const lng = discovery.longitude_display || discovery.longitude;

        if (!lat || !lng) return null;

        return (
          <Marker
            key={discovery.id}
            position={[lat, lng]}
            icon={createDiscoveryMarker(discovery.rarity_tier)}
            eventHandlers={{
              click: () => onDiscoveryClick?.(discovery),
            }}
          >
            <Popup className="discovery-popup">
              <div className="p-2 min-w-[200px]">
                <p className="font-bold text-sm">{discovery.mineral_name}</p>
                {discovery.variety && (
                  <p className="text-xs text-gray-600">{discovery.variety}</p>
                )}

                {discovery.photo_urls?.[0] && (
                  <img
                    src={discovery.photo_urls[0]}
                    alt={discovery.mineral_name}
                    className="w-full h-32 object-cover rounded-lg mt-2"
                  />
                )}

                <div className="flex gap-3 mt-2 text-xs text-gray-700">
                  {discovery.confirmation_count > 0 && (
                    <span className="flex items-center gap-1">
                      <Star className="w-3 h-3" /> {discovery.confirmation_count}
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <Heart className="w-3 h-3" /> {discovery.like_count}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-3 h-3" /> {discovery.comment_count}
                  </span>
                </div>

                {discovery.discoverer_name && (
                  <p className="text-xs text-gray-500 mt-2">
                    Found by{' '}
                    {discovery.share_privacy === 'attributed'
                      ? discovery.discoverer_name
                      : 'Anonymous Collector'}
                  </p>
                )}
              </div>
            </Popup>
          </Marker>
        );
      })}
    </>
  );
}