import { useEffect } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";

const PIN_COLORS = {
  find:      { bg: "#10b981", emoji: "💎" },
  hazard:    { bg: "#ef4444", emoji: "⚠️" },
  base_camp: { bg: "#3b82f6", emoji: "⛺" },
  note:      { bg: "#f59e0b", emoji: "📝" },
};

export default function FieldPinMarkers({ pins, onPinClick }) {
  const map = useMap();

  useEffect(() => {
    const markers = [];

    pins.forEach((pin) => {
      const cfg = PIN_COLORS[pin.type] || PIN_COLORS.note;
      const icon = L.divIcon({
        className: "",
        html: `<div style="
          background:${cfg.bg};
          width:32px;height:32px;border-radius:50% 50% 50% 0;
          transform:rotate(-45deg);
          border:2px solid white;
          box-shadow:0 2px 6px rgba(0,0,0,0.35);
          display:flex;align-items:center;justify-content:center;
        ">
          <span style="transform:rotate(45deg);font-size:13px;">${cfg.emoji}</span>
        </div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
      });

      const marker = L.marker([pin.lat, pin.lng], { icon })
        .addTo(map)
        .on("click", () => onPinClick(pin));
      markers.push(marker);
    });

    return () => markers.forEach(m => m.remove());
  }, [pins, map, onPinClick]);

  return null;
}