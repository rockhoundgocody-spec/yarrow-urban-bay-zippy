import { useEffect, useRef, useMemo } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet.heat";
import { escapeHtml } from "@/utils";

export const MINERAL_CATEGORIES = [
  { id: "all",      label: "All Finds",          color: "#ffeb3b", keywords: [] },
  { id: "quartz",   label: "Quartz & Silicates",  color: "#e040fb", keywords: ["quartz","amethyst","agate","jasper","chert","flint","opal","obsidian","feldspar","mica","chalcedony","carnelian","citrine","onyx","sardonyx"] },
  { id: "gemstone", label: "Gemstones",            color: "#ff1493", keywords: ["emerald","ruby","sapphire","topaz","garnet","tourmaline","aquamarine","beryl","spinel","tanzanite","zircon","diamond","alexandrite","peridot","chrysoberyl"] },
  { id: "metallic", label: "Metallic Minerals",    color: "#ffd700", keywords: ["gold","silver","copper","iron","pyrite","galena","magnetite","hematite","chalcopyrite","malachite","azurite","sphalerite","molybdenite","cassiterite","wolframite"] },
  { id: "fossil",   label: "Fossils",              color: "#d4a574", keywords: ["fossil","trilobite","ammonite","coral","shell","bone","teeth","trace","crinoid","echinoderm","brachiopod","belemnite","shark","dinosaur"] },
  { id: "crystal",  label: "Crystals",             color: "#64b5f6", keywords: ["crystal","selenite","calcite","fluorite","barite","celestite","gypsum","halite","aragonite","stibnite","tourmaline","kunzite","hiddenite","wulfenite"] },
  { id: "volcanic", label: "Volcanic / Igneous",   color: "#ff6b4a", keywords: ["basalt","granite","rhyolite","pumice","obsidian","olivine","pyroxene","hornblende","biotite","diorite","gabbro","andesite","tuff","perlite"] },
  { id: "rare",     label: "Rare Minerals",        color: "#00ffaa", keywords: ["benitoite","grandidierite","musgravite","jeremejevite","red beryl","painite","serendibite","alexandrite","demantoid","tsavorite","paraiba","tanzanite"] },
];

function scoreLocation(loc, category) {
  const found = loc.minerals_found || [];
  const predicted = loc.predicted_minerals || [];
  const totalLength = found.length + predicted.length;

  if (category.id === "all") return totalLength > 0 ? Math.min(totalLength, 10) : 1;

  let score = 0;
  // ⚡ Bolt: Replaced inline [...a, ...b].map() with direct iteration.
  // This eliminates O(N*M) array allocations and memory overhead during map rendering.
  for (let i = 0; i < found.length; i++) {
    const m = found[i].toLowerCase();
    if (category.keywords.some(kw => m.includes(kw))) score++;
  }
  for (let i = 0; i < predicted.length; i++) {
    const m = predicted[i].toLowerCase();
    if (category.keywords.some(kw => m.includes(kw))) score++;
  }
  return score;
}

export default function MineralHotspotLayer({ locations = [], activeCategoryId = "all", visible = false }) {
  const map = useMap();
  const circlesRef = useRef([]);
  const heatRef = useRef(null);

  const category = useMemo(
    () => MINERAL_CATEGORIES.find(c => c.id === activeCategoryId) || MINERAL_CATEGORIES[0],
    [activeCategoryId]
  );

  const scored = useMemo(() => {
    return locations
      .filter(l => l.latitude && l.longitude)
      .map(l => ({ loc: l, score: scoreLocation(l, category) }))
      .filter(({ score }) => score > 0);
  }, [locations, category]);

  useEffect(() => {
    // Clean up previous layers
    circlesRef.current.forEach(c => { if (map.hasLayer(c)) map.removeLayer(c); });
    circlesRef.current = [];
    if (heatRef.current && map.hasLayer(heatRef.current)) {
      map.removeLayer(heatRef.current);
      heatRef.current = null;
    }

    if (!visible || scored.length === 0) return;

    const maxScore = Math.max(...scored.map(s => s.score), 1);

    // Background heat layer
    const heatData = scored.map(({ loc, score }) => [loc.latitude, loc.longitude, score / maxScore]);
    const container = map.getContainer();
    if (container && container.clientWidth > 0 && L.heatLayer) {
      try {
        heatRef.current = L.heatLayer(heatData, {
          radius: 45,
          blur: 30,
          maxZoom: 18,
          gradient: buildGradient(category.color),
        }).addTo(map);
      } catch (_) {}
    }

    // Foreground circle markers
    scored.forEach(({ loc, score }) => {
      const norm = score / maxScore;
      const radius = 5 + norm * 14;
      const opacity = 0.4 + norm * 0.5;

      const circle = L.circleMarker([loc.latitude, loc.longitude], {
        radius,
        fillColor: category.color,
        color: "white",
        weight: 1.5,
        opacity: 0.9,
        fillOpacity: opacity,
        pane: "markerPane",
      }).bindTooltip(
        `<strong>${escapeHtml(loc.name)}</strong><br/>${escapeHtml(buildMineralSummary(loc, category))}<br/><span style="color:#aaa;font-size:10px">${score} match${score !== 1 ? "es" : ""}</span>`,
        { className: "leaflet-tooltip-light", direction: "top", offset: [0, -4] }
      ).addTo(map);

      circlesRef.current.push(circle);
    });

    return () => {
      circlesRef.current.forEach(c => { if (map.hasLayer(c)) map.removeLayer(c); });
      if (heatRef.current && map.hasLayer(heatRef.current)) map.removeLayer(heatRef.current);
    };
  }, [map, scored, visible, category]);

  return null;
}

function buildGradient(hex) {
  return {
    0.0: "#0033aa",
    0.3: hex + "88",
    0.6: hex,
    1.0: "#ffffff",
  };
}

function buildMineralSummary(loc, category) {
  const found = loc.minerals_found || [];
  const predicted = loc.predicted_minerals || [];

  // ⚡ Bolt: Replaced inline [...a, ...b].filter() with direct iteration and short-circuiting.
  // This avoids full array passes and garbage collection spikes when rendering hundreds of popups.
  if (category.id === "all") {
    let summary = [];
    for (let i = 0; i < found.length && summary.length < 3; i++) summary.push(found[i]);
    for (let i = 0; i < predicted.length && summary.length < 3; i++) summary.push(predicted[i]);
    return summary.length > 0 ? summary.join(", ") : "—";
  }

  let matches = [];
  let fallback = [];
  for (let i = 0; i < found.length; i++) {
    if (fallback.length < 2) fallback.push(found[i]);
    if (matches.length < 3 && category.keywords.some(kw => found[i].toLowerCase().includes(kw))) matches.push(found[i]);
  }
  for (let i = 0; i < predicted.length; i++) {
    if (fallback.length < 2) fallback.push(predicted[i]);
    if (matches.length < 3 && category.keywords.some(kw => predicted[i].toLowerCase().includes(kw))) matches.push(predicted[i]);
  }

  return matches.length > 0 ? matches.join(", ") : fallback.length > 0 ? fallback.join(", ") : "—";
}