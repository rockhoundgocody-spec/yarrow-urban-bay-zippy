import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useMapLibre } from './MapLibreContext';

const PIN_COLORS = {
  find:      { bg: '#10b981', emoji: '💎' },
  hazard:    { bg: '#ef4444', emoji: '⚠️' },
  base_camp: { bg: '#3b82f6', emoji: '⛺' },
  note:      { bg: '#f59e0b', emoji: '📝' },
};

export default function ML_FieldPins({ pins, onPinClick }) {
  const map = useMapLibre();
  const markersRef = useRef([]);

  useEffect(() => {
    if (!map) return;

    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    pins.forEach(pin => {
      const cfg = PIN_COLORS[pin.type] || PIN_COLORS.note;
      const el = document.createElement('div');
      el.style.cssText = "width:32px;height:32px;";

      const pinInner = document.createElement("div");
      pinInner.style.background = cfg.bg;
      pinInner.style.width = "32px";
      pinInner.style.height = "32px";
      pinInner.style.borderRadius = "50% 50% 50% 0";
      pinInner.style.transform = "rotate(-45deg)";
      pinInner.style.border = "2px solid white";
      pinInner.style.boxShadow = "0 2px 6px rgba(0,0,0,0.35)";
      pinInner.style.display = "flex";
      pinInner.style.alignItems = "center";
      pinInner.style.justifyContent = "center";
      pinInner.style.cursor = "pointer";

      const emojiSpan = document.createElement("span");
      emojiSpan.style.transform = "rotate(45deg)";
      emojiSpan.style.fontSize = "13px";
      emojiSpan.textContent = cfg.emoji;

      pinInner.appendChild(emojiSpan);
      el.appendChild(pinInner);
      el.addEventListener('click', () => onPinClick(pin));

      const marker = new maplibregl.Marker({ element: el, anchor: 'bottom-left' })
        .setLngLat([pin.lng, pin.lat])
        .addTo(map);
      markersRef.current.push(marker);
    });

    return () => { markersRef.current.forEach(m => m.remove()); markersRef.current = []; };
  }, [map, pins, onPinClick]);

  return null;
}
