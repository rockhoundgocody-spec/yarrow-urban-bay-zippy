import React, { useEffect, useRef, useState } from 'react';
import maplibregl from 'maplibre-gl';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { X } from 'lucide-react';

export default function DiscoveryMapView() {
  const navigate = useNavigate();
  const mapContainer = useRef(null);
  const map = useRef(null);
  const markersRef = useRef([]);
  const [selectedDiscovery, setSelectedDiscovery] = useState(null);

  const { data: discoveries = [] } = useQuery({
    queryKey: ['discoveries_map_view'],
    queryFn: async () => {
      try {
        const result = await base44.entities.Discovery.filter({ is_shared: true });
        return result || [];
      } catch {
        return [];
      }
    },
    refetchInterval: 60000,
  });

  // Init map
  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://basemaps.cartocdn.com/gl/dark-matter-nolabels-gl-style/style.json',
      center: [-98.5795, 39.8283],
      zoom: 4,
      attributionControl: false,
    });

    map.current.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-right');

    // Geolocate on load
    map.current.on('load', () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            map.current?.flyTo({ center: [pos.coords.longitude, pos.coords.latitude], zoom: 10, duration: 1200 });
          },
          () => {}
        );
      }
    });

    return () => { map.current?.remove(); map.current = null; };
  }, []);

  // Render discovery markers whenever data changes
  useEffect(() => {
    if (!map.current) return;

    // Clear old markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    const addMarkers = () => {
      discoveries.forEach((d) => {
        if (!d.latitude || !d.longitude) return;

        const el = document.createElement('div');
        el.style.cssText = `
          width:32px;height:32px;border-radius:50%;
          background:linear-gradient(135deg,#00D68F,#7AE7FF);
          border:2.5px solid rgba(255,255,255,0.6);
          box-shadow:0 0 12px rgba(0,214,143,0.5);
          cursor:pointer;display:flex;align-items:center;justify-content:center;
          font-size:14px;
        `;
        el.textContent = '💎';
        el.title = d.mineral_name || 'Discovery';

        const marker = new maplibregl.Marker({ element: el })
          .setLngLat([d.longitude, d.latitude])
          .addTo(map.current);

        el.addEventListener('click', () => setSelectedDiscovery(d));
        markersRef.current.push(marker);
      });
    };

    if (map.current.isStyleLoaded()) addMarkers();
    else map.current.once('load', addMarkers);
  }, [discoveries]);

  return (
    <div className="absolute inset-0 flex flex-col">
      <div ref={mapContainer} className="absolute inset-0" />

      {/* Count badge */}
      <div className="absolute top-3 left-3 z-10 px-3 py-1.5 rounded-lg text-xs font-bold text-white/80"
        style={{ background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)' }}>
        {discoveries.length} discoveries shared
      </div>

      {/* Selected discovery panel */}
      {selectedDiscovery && (
        <div className="absolute bottom-4 left-4 right-4 z-40">
          <div className="rounded-2xl p-4 space-y-2 shadow-lg"
            style={{
              background: 'linear-gradient(135deg, rgba(10,15,22,0.95) 0%, rgba(6,10,18,0.98) 100%)',
              border: '1px solid rgba(0,214,143,0.2)',
            }}>
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-white">{selectedDiscovery.mineral_name}</h3>
                {selectedDiscovery.variety && (
                  <p className="text-xs text-white/50">{selectedDiscovery.variety}</p>
                )}
              </div>
              <button onClick={() => setSelectedDiscovery(null)} className="text-white/40 hover:text-white"
                style={{ minHeight: 'unset', minWidth: 'unset' }} aria-label="Select">
                <X className="w-4 h-4" />
              </button>
            </div>

            {selectedDiscovery.photo_urls?.[0] && (
              <img src={selectedDiscovery.photo_urls[0]} alt={selectedDiscovery.mineral_name}
                className="w-full h-36 object-cover rounded-lg" />
            )}

            <div className="flex flex-wrap gap-2 text-xs">
              {selectedDiscovery.location_name && (
                <span className="px-2 py-1 rounded-lg bg-white/5 text-white/60">{selectedDiscovery.location_name}</span>
              )}
              {selectedDiscovery.discoverer_name && (
                <span className="px-2 py-1 rounded-lg bg-white/5 text-white/60">
                  {selectedDiscovery.share_privacy === 'attributed' ? selectedDiscovery.discoverer_name : 'Anonymous'}
                </span>
              )}
            </div>

            <button
              onClick={() => navigate('/SocialDiscoveryFeed')}
              className="w-full py-2 rounded-lg font-semibold text-sm text-black transition-all"
              style={{ background: 'linear-gradient(135deg, #00D68F, #7AE7FF)', minHeight: 'unset' }}>
              View Feed
            </button>
          </div>
        </div>
      )}
    </div>
  );
}