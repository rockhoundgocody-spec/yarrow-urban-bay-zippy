import { useState, useEffect } from "react";
import maplibregl from "maplibre-gl";
import { useMapLibre, safeRemove } from "./MapLibreContext";
import { base44 } from "@/api/base44Client";
import { escapeHtml } from "@/utils";

/**
 * ML_GoogleMyMapsLayer — MapLibre overlay rendering ALL placemarks from a
 * Google My Maps KML source as small cyan circle markers.
 *
 * This is a read-only reference layer, separate from imported
 * RockhoundingLocation entities — it shows the full source dataset for
 * visual context, even locations not yet imported as entities.
 *
 * Props:
 *   - url: Google My Maps URL (must contain mid= parameter)
 *   - visible: boolean toggle
 */
const SOURCE_ID = "google-my-maps-ref";
const LAYER_ID = "google-my-maps-ref-layer";

export default function ML_GoogleMyMapsLayer({ url, visible = false }) {
  const map = useMapLibre();
  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch GeoJSON from backend proxy
  useEffect(() => {
    if (!visible || !url) return;
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);
      try {
        const res = await base44.functions.invoke("getGoogleMyMapsGeoJson", { url });
        if (cancelled) return;
        if (res?.geoJson?.features) {
          setFeatures(res.geoJson.features);
        } else {
          setError(res?.error || "No features returned");
        }
      } catch (e) {
        if (!cancelled) setError(e.message || "Failed to load reference map");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => { cancelled = true; };
  }, [url, visible]);

  // Add/remove MapLibre source + layer
  useEffect(() => {
    if (!map) return;

    const addLayer = () => {
      if (!visible || features.length === 0) {
        safeRemove(map, [LAYER_ID], SOURCE_ID);
        return;
      }

      const geojson = {
        type: "FeatureCollection",
        features: features.map((f) => ({
          type: "Feature",
          geometry: {
            type: "Point",
            coordinates: f.geometry.coordinates, // [lon, lat]
          },
          properties: f.properties,
        })),
      };

      // Remove existing then re-add (handles data updates)
      safeRemove(map, [LAYER_ID], SOURCE_ID);

      map.addSource(SOURCE_ID, { type: "geojson", data: geojson });
      map.addLayer({
        id: LAYER_ID,
        type: "circle",
        source: SOURCE_ID,
        paint: {
          "circle-radius": 4,
          "circle-color": "#7AE7FF",
          "circle-opacity": 0.35,
          "circle-stroke-width": 1,
          "circle-stroke-color": "#7AE7FF",
          "circle-stroke-opacity": 0.8,
        },
      });

      // Popup on click
      const popup = new maplibregl.Popup({ closeButton: false, offset: 8 });
      map.on("click", LAYER_ID, (e) => {
        const f = e.features?.[0];
        if (!f) return;
        const props = f.properties;
        const html = `<div style="font-size:11px;max-width:180px">
          <div style="font-weight:700;color:#0f172a;margin-bottom:2px">${escapeHtml(props.name || "Unnamed")}</div>
          ${props.state ? `<div style="color:#475569">${escapeHtml(props.state)}</div>` : ""}
          ${props.folder ? `<div style="color:#94a3b8;font-size:9px;margin-top:2px">${escapeHtml(props.folder)}</div>` : ""}
        </div>`;
        popup.setLngLat(e.lngLat).setHTML(html).addTo(map);
      });

      // Cursor on hover
      map.on("mouseenter", LAYER_ID, () => (map.getCanvas().style.cursor = "pointer"));
      map.on("mouseleave", LAYER_ID, () => (map.getCanvas().style.cursor = ""));
    };

    if (map.isStyleLoaded()) addLayer();
    else map.once("load", addLayer);

    return () => {
      safeRemove(map, [LAYER_ID], SOURCE_ID);
      map.off("click", LAYER_ID);
      map.off("mouseenter", LAYER_ID);
      map.off("mouseleave", LAYER_ID);
    };
  }, [map, visible, features]);

  if (!visible) return null;

  return (
    <>
      {loading && (
        <div
          className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full text-xs font-medium shadow-lg"
          style={{
            background: "rgba(10,15,20,0.92)",
            border: "1px solid rgba(122,231,255,0.3)",
            color: "#7AE7FF",
          }}
        >
          Loading reference map…
        </div>
      )}
      {error && (
        <div
          className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full text-xs font-medium shadow-lg max-w-80 text-center"
          style={{
            background: "rgba(50,10,10,0.92)",
            border: "1px solid rgba(239,68,68,0.3)",
            color: "#fca5a5",
          }}
        >
          {error}
        </div>
      )}
    </>
  );
}