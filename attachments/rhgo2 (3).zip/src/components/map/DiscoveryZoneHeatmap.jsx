/**
 * DiscoveryZoneHeatmap — Community vs. private collection discovery zone layer.
 *
 * Modes:
 *  - community: public Discovery records (all users, fuzzed locations)
 *  - private:   current user's Specimen records (exact locations)
 *
 * Each mode has two heatmap sub-modes: density | rarity
 * Toggle lives in the map overlay — no external state needed.
 */
import React, { useEffect, useRef, useState, useCallback } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Lock, BarChart3, Zap, Layers, Loader2, Globe } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { escapeHtml } from "@/utils";

// ── Rarity weight → numeric score ─────────────────────────────────────────────
const RARITY_WEIGHT = { legendary: 5, epic: 4.5, rare: 4, uncommon: 2.5, common: 1 };

function specimenWeight(item, dataMode, heatMode) {
  if (heatMode === "rarity") {
    // Use rarity field from Discovery or Specimen
    const rarity = (item.rarity_tier || item.rarity || "common").toLowerCase();
    return RARITY_WEIGHT[rarity] || 1;
  }
  // density mode — all equal weight
  return 1;
}

function buildGeoJSON(items, dataMode, heatMode) {
  const features = items
    .filter(item => {
      const lat = item.latitude ?? item.fuzzed_latitude;
      const lng = item.longitude ?? item.fuzzed_longitude;
      return lat && lng;
    })
    .map(item => {
      const lat = item.latitude ?? item.fuzzed_latitude;
      const lng = item.longitude ?? item.fuzzed_longitude;
      const weight = specimenWeight(item, dataMode, heatMode);
      const name = item.name || item.mineral_name || item.locality_name || "Find";
      const mineral = item.mineral_type || item.name || "";
      const rarity = item.rarity_tier || item.rarity || "common";
      return {
        type: "Feature",
        geometry: { type: "Point", coordinates: [lng, lat] },
        properties: { weight: Math.min(weight, 5), name, mineral, rarity },
      };
    });
  return { type: "FeatureCollection", features };
}

// ── Color palettes ─────────────────────────────────────────────────────────────
const PALETTES = {
  community_density: {
    label: "Community Discoveries",
    colors: ["rgba(0,214,143,0)", "rgba(0,214,143,0.3)", "rgba(122,231,255,0.55)", "rgba(141,124,255,0.75)", "rgba(245,182,66,0.9)", "rgba(248,113,113,1)"],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
    circleColor: "rgba(0,214,143,0.9)",
  },
  community_rarity: {
    label: "Community · Rarity",
    colors: ["rgba(0,0,0,0)", "rgba(141,124,255,0.25)", "rgba(141,124,255,0.5)", "rgba(245,182,66,0.7)", "rgba(248,113,113,0.85)", "rgba(255,215,0,1)"],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
    circleColor: "rgba(255,215,0,0.9)",
  },
  private_density: {
    label: "My Collection · Density",
    colors: ["rgba(122,231,255,0)", "rgba(122,231,255,0.28)", "rgba(122,231,255,0.5)", "rgba(141,124,255,0.72)", "rgba(245,182,66,0.88)", "rgba(248,113,113,1)"],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
    circleColor: "rgba(122,231,255,0.9)",
  },
  private_rarity: {
    label: "My Collection · Rarity",
    colors: ["rgba(0,0,0,0)", "rgba(122,231,255,0.2)", "rgba(141,124,255,0.45)", "rgba(245,182,66,0.68)", "rgba(255,140,0,0.85)", "rgba(255,215,0,1)"],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
    circleColor: "rgba(245,182,66,0.9)",
  },
};

function renderLayers(mapRef, geojson, paletteKey) {
  if (!mapRef.current) return;
  const cfg = PALETTES[paletteKey];

  if (mapRef.current.getSource("dzh-source")) {
    mapRef.current.getSource("dzh-source").setData(geojson);
  } else {
    mapRef.current.addSource("dzh-source", { type: "geojson", data: geojson });
  }

  ["dzh-heatmap", "dzh-circles"].forEach(id => {
    if (mapRef.current.getLayer(id)) mapRef.current.removeLayer(id);
  });

  mapRef.current.addLayer({
    id: "dzh-heatmap",
    type: "heatmap",
    source: "dzh-source",
    maxzoom: 14,
    paint: {
      "heatmap-weight": ["interpolate", ["linear"], ["get", "weight"], 0, 0, 5, 1],
      "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 0, 1.2, 9, 3.5],
      "heatmap-color": ["interpolate", ["linear"], ["heatmap-density"],
        ...cfg.stops.flatMap((stop, i) => [stop, cfg.colors[i]])
      ],
      "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 0, 28, 9, 44],
      "heatmap-opacity": 0.85,
    },
  }, "waterway-label");

  mapRef.current.addLayer({
    id: "dzh-circles",
    type: "circle",
    source: "dzh-source",
    minzoom: 12,
    paint: {
      "circle-radius": 8,
      "circle-color": cfg.circleColor,
      "circle-stroke-width": 1.5,
      "circle-stroke-color": "rgba(255,255,255,0.25)",
      "circle-opacity": 0.9,
    },
  });
}

// ── Main component ─────────────────────────────────────────────────────────────
export default function DiscoveryZoneHeatmap() {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [dataMode, setDataMode] = useState("community"); // community | private
  const [heatMode, setHeatMode] = useState("density");   // density | rarity
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [error, setError] = useState(null);

  const paletteKey = `${dataMode}_${heatMode}`;
  const cfg = PALETTES[paletteKey];

  const loadData = useCallback(async (dm, hm) => {
    if (!map.current?.loaded()) return;
    setLoading(true);
    setError(null);
    try {
      let items = [];
      if (dm === "community") {
        // Public discoveries
        const discoveries = await base44.entities.Discovery.list("-created_date", 500);
        items = discoveries.filter(d => (d.latitude || d.fuzzed_latitude) && (d.longitude || d.fuzzed_longitude));
      } else {
        // User's own specimens
        const user = await base44.auth.me();
        const specimens = await base44.entities.Specimen.filter({ found_by: user.email }, "-created_date", 500);
        items = specimens.filter(s => s.latitude && s.longitude);
      }
      setCount(items.length);
      const geojson = buildGeoJSON(items, dm, hm);
      renderLayers(map, geojson, `${dm}_${hm}`);
    } catch (err) {
      setError("Failed to load discovery data.");
    } finally {
      setLoading(false);
    }
  }, []);

  // Init map
  useEffect(() => {
    if (!mapContainer.current) return;
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: "https://tiles.openfreemap.org/styles/positron",
      center: [-105, 39],
      zoom: 4,
      attributionControl: false,
    });
    map.current.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");

    map.current.on("load", () => loadData("community", "density"));

    // Popup on circle click
    map.current.on("click", "dzh-circles", (e) => {
      const props = e.features[0]?.properties;
      if (!props) return;
      new maplibregl.Popup({ closeButton: false, className: "geo-cell-tooltip" })
        .setLngLat(e.lngLat)
        .setHTML(`
          <div style="background:#0e141b;border:1px solid rgba(0,214,143,0.3);border-radius:10px;padding:10px 12px;min-width:150px">
            <div style="font-weight:700;color:#fff;font-size:13px">${escapeHtml(props.name)}</div>
            <div style="color:#00D68F;font-size:11px;margin-top:2px">${escapeHtml(props.mineral)}</div>
            <div style="color:rgba(255,255,255,0.4);font-size:10px;margin-top:4px">Rarity: ${escapeHtml(props.rarity)}</div>
          </div>
        `)
        .addTo(map.current);
    });
    map.current.on("mouseenter", "dzh-circles", () => { map.current.getCanvas().style.cursor = "pointer"; });
    map.current.on("mouseleave", "dzh-circles", () => { map.current.getCanvas().style.cursor = ""; });

    return () => { map.current?.remove(); map.current = null; };
  }, []);

  // Reload when controls change
  useEffect(() => {
    if (!map.current) return;
    if (map.current.loaded()) {
      loadData(dataMode, heatMode);
    } else {
      map.current.once("load", () => loadData(dataMode, heatMode));
    }
  }, [dataMode, heatMode, loadData]);

  return (
    <div className="absolute inset-0 flex flex-col">
      {/* ── Controls overlay ── */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2" style={{ maxWidth: 200 }}>

        {/* Data source toggle */}
        <div className="flex items-center gap-1 rounded-2xl p-1"
          style={{ background: "rgba(8,11,16,0.92)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(14px)" }}>
          {[
            { id: "community", label: "Community", icon: Globe },
            { id: "private",   label: "Mine",      icon: Lock },
          ].map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setDataMode(id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all"
              style={{
                background: dataMode === id ? "rgba(0,214,143,0.15)" : "transparent",
                border: dataMode === id ? "1px solid rgba(0,214,143,0.35)" : "1px solid transparent",
                color: dataMode === id ? "#00D68F" : "rgba(255,255,255,0.35)",
              }}>
              <Icon style={{ width: 12, height: 12 }} />
              {label}
            </button>
          ))}
        </div>

        {/* Heat mode toggle */}
        <div className="flex items-center gap-1 rounded-2xl p-1"
          style={{ background: "rgba(8,11,16,0.9)", border: "1px solid rgba(255,255,255,0.08)", backdropFilter: "blur(14px)" }}>
          {[
            { id: "density", label: "Density", icon: BarChart3 },
            { id: "rarity",  label: "Rarity",  icon: Zap },
          ].map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setHeatMode(id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all"
              style={{
                background: heatMode === id ? "rgba(122,231,255,0.12)" : "transparent",
                border: heatMode === id ? "1px solid rgba(122,231,255,0.3)" : "1px solid transparent",
                color: heatMode === id ? "#7AE7FF" : "rgba(255,255,255,0.35)",
              }}>
              <Icon style={{ width: 12, height: 12 }} />
              {label}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="rounded-2xl px-3 py-2.5"
          style={{ background: "rgba(8,11,16,0.88)", border: "1px solid rgba(255,255,255,0.07)", backdropFilter: "blur(12px)" }}>
          <div className="flex items-center gap-1.5 mb-2">
            <Layers style={{ width: 11, height: 11, color: "#00D68F" }} />
            <span className="text-[10px] font-bold text-white/55 uppercase tracking-widest truncate">{cfg.label}</span>
          </div>
          <div className="h-2 rounded-full w-28" style={{
            background: `linear-gradient(90deg, ${cfg.colors[1]}, ${cfg.colors[3]}, ${cfg.colors[5]})`
          }} />
          <div className="flex justify-between mt-1">
            <span className="text-[9px] text-white/30">Low</span>
            <span className="text-[9px] text-white/30">High</span>
          </div>
          {count > 0 && (
            <div className="mt-2 text-[9px] text-white/25">{count} finds plotted</div>
          )}
        </div>
      </div>

      {/* Loading overlay */}
      {loading && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3"
          style={{ background: "rgba(8,11,16,0.72)", backdropFilter: "blur(8px)" }}>
          <Loader2 style={{ width: 28, height: 28, color: "#00D68F" }} className="animate-spin" />
          <span className="text-sm text-white/50">Loading {dataMode === "community" ? "community discoveries" : "your collection"}…</span>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="absolute bottom-16 left-3 right-3 z-10 rounded-xl p-3 text-center"
          style={{ background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.3)" }}>
          <p className="text-xs text-red-400">{error}</p>
        </div>
      )}

      {/* Map */}
      <div ref={mapContainer} className="absolute inset-0" />
    </div>
  );
}