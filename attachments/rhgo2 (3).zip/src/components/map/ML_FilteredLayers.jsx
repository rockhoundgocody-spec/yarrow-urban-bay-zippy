import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useMapLibre } from './MapLibreContext';


const LEGALITY_COLORS = {
  'Safe Public': '#22c55e', 'Likely Legal': '#eab308',
  'Use Caution': '#f97316', 'High Risk': '#ef4444',
};
const SITE_EMOJIS = {
  public_land: '🏜️', mine: '⛏️', quarry: '🪨', beach: '🏖️',
  riverbed: '🌊', desert: '🏜️', mountain: '⛰️', roadcut: '🛣️', fee_dig: '💰', other: '📍',
};

export default function ML_FilteredLayers({ locations = [], layers = {}, shops = [] }) {
  const map = useMapLibre();
  const markersRef = useRef([]);
  const shopMarkersRef = useRef([]);

  useEffect(() => {
    if (!map) return;

    // Clear old markers
    markersRef.current.forEach(m => m.remove());
    markersRef.current = [];

    const filtered = locations.filter(loc => {
      const leg = loc.legality_status;
      if (leg === 'Safe Public' && !layers.show_safe_public) return false;
      if (leg === 'Likely Legal' && !layers.show_likely_legal) return false;
      if (leg === 'High Risk' && !layers.show_high_risk) return false;
      if (leg === 'Use Caution' && !layers.show_likely_legal) return false;
      if (loc.is_saved && !layers.show_user_visited) return false;
      const isMine = loc.site_type === 'mine' || loc.site_type === 'quarry';
      if (isMine && !layers.show_historical_mining) return false;
      if (loc.is_user_poi && !layers.show_user_pois) return false;
      return true;
    });

    filtered.forEach(loc => {
      const color = LEGALITY_COLORS[loc.legality_status] || '#6366f1';
      const emoji = SITE_EMOJIS[loc.site_type] || '📍';
      const el = document.createElement('div');
      const inner = document.createElement('div');
      inner.style.cssText = `background:${color};border:2px solid #fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;box-shadow:0 0 8px rgba(0,0,0,0.4);font-size:11px;cursor:pointer;`;
      inner.textContent = emoji;
      el.appendChild(inner);
      el.style.cssText = 'width:24px;height:24px;';
      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([loc.longitude, loc.latitude])
        .setPopup(new maplibregl.Popup({ offset: 14, maxWidth: '260px' })
          .setDOMContent((() => {
            const container = document.createElement('div');
            const nameEl = document.createElement('div');
            nameEl.style.cssText = 'font-size:12px;font-weight:700';
            nameEl.textContent = loc.name;
            const mineralsEl = document.createElement('div');
            mineralsEl.style.cssText = 'font-size:10px;color:#888;margin-top:2px';
            mineralsEl.textContent = (loc.minerals_found || []).slice(0, 3).join(', ') || '—';
            container.appendChild(nameEl);
            container.appendChild(mineralsEl);
            return container;
          })()))
        .addTo(map);
      markersRef.current.push(marker);
    });

    return () => { markersRef.current.forEach(m => m.remove()); markersRef.current = []; };
  }, [map, locations, layers]);

  useEffect(() => {
    if (!map) return;

    shopMarkersRef.current.forEach(m => m.remove());
    shopMarkersRef.current = [];

    if (!layers.show_shops) return;

    shops.filter(s => s.approved && s.latitude && s.longitude).forEach(shop => {
      const el = document.createElement('div');
      const inner = document.createElement('div');
      inner.style.cssText = 'background:#06b6d4;border:2px solid #fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;cursor:pointer;';
      inner.textContent = '🏬';
      el.appendChild(inner);
      el.style.cssText = 'width:24px;height:24px;';
      const marker = new maplibregl.Marker({ element: el })
        .setLngLat([shop.longitude, shop.latitude])
        .setPopup(new maplibregl.Popup({ offset: 14 }).setDOMContent((() => {
            const nameEl = document.createElement('div');
            nameEl.style.cssText = 'font-size:12px;font-weight:700';
            nameEl.textContent = shop.shop_name;
            return nameEl;
          })()))
        .addTo(map);
      shopMarkersRef.current.push(marker);
    });

    return () => { shopMarkersRef.current.forEach(m => m.remove()); shopMarkersRef.current = []; };
  }, [map, shops, layers.show_shops]);

  return null;
}