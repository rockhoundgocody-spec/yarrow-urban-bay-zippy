import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronDown, Layers } from "lucide-react";
import { cn } from "@/lib/utils";

const LAYER_GROUPS = [
  {
    label: "Legality",
    keys: [
      { key: "show_safe_public", label: "🟢 Safe Public", color: "bg-emerald-500" },
      { key: "show_likely_legal", label: "🟡 Likely Legal", color: "bg-amber-500" },
      { key: "show_high_risk", label: "🔴 High Risk", color: "bg-red-500" },
    ],
  },
  {
    label: "Site Types",
    keys: [
      { key: "show_pay_to_mine", label: "⛏ Pay-to-Mine", color: "bg-orange-600" },
      { key: "show_private_sites", label: "🌲 Private Access", color: "bg-green-700" },
      { key: "show_historical_mining", label: "🪨 Historical Mining", color: "bg-stone-500" },
    ],
  },
  {
    label: "Discovery",
    keys: [
      { key: "show_mineral_hotspots", label: "💎 Mineral Hotspots", color: "bg-pink-500" },
      { key: "show_user_visited", label: "📍 My Visited", color: "bg-blue-500" },
      { key: "show_user_pois", label: "🏴 User POIs", color: "bg-violet-500" },
      { key: "show_guild_activity", label: "🏆 Guild Activity", color: "bg-purple-500" },
    ],
  },
  {
    label: "Overlays",
    keys: [
      { key: "show_shops", label: "🏬 Partner Shops", color: "bg-cyan-500" },
      { key: "show_geology_layer", label: "🗺 Geology Map", color: "bg-teal-600" },
      { key: "show_exploration_coverage", label: "📊 Coverage %", color: null },
      { key: "show_mineral_occurrence", label: "💠 Mineral Occurrence", color: "bg-indigo-500" },
      { key: "show_mineral_density", label: "🟡 High Density Zones", color: "bg-yellow-500" },
      { key: "show_unexplored", label: "🟢 Unexplored Areas", color: "bg-emerald-500" },
      { key: "show_public_land", label: "🏛 Public Land Boundaries", color: "bg-lime-600" },
      { key: "show_topo_heatmap", label: "🌡 Topographic Heatmap", color: "bg-rose-500" },
      { key: "show_google_my_maps", label: "📍 Google My Maps Reference", color: "bg-cyan-400" },
    ],
  },
];

export default function MapLayerToggle({ layers, onToggle }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <Button
        onClick={() => setOpen(!open)}
        className="h-9 px-3 bg-transparent border-0 text-gray-600 hover:bg-gray-100 hover:text-gray-800 text-xs md:text-sm shadow-none"
        variant="ghost"
      >
        <Layers className="w-4 h-4" />
        <span className="hidden sm:inline ml-1.5 font-semibold">Layers</span>
        <ChevronDown className={cn("w-3 h-3 ml-1 transition-transform text-gray-400", open && "rotate-180")} />
      </Button>

      {open && (
        <div className="absolute top-full mt-2 right-0 z-50 bg-white border border-gray-200 rounded-xl p-3 min-w-60 max-h-[75vh] overflow-y-auto shadow-2xl shadow-black/15">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider px-2 pb-2">Map Layers</p>
          {LAYER_GROUPS.map((group) => (
            <div key={group.label} className="mb-3">
              <p className="text-[9px] font-bold text-gray-300 uppercase tracking-widest px-2 py-1">{group.label}</p>
              {group.keys.map(({ key, label, color }) => (
                <label
                  key={key}
                  className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer text-xs text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <Checkbox
                    checked={layers[key] || false}
                    onCheckedChange={() => onToggle(key)}
                    className="border-gray-300 h-3.5 w-3.5 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
                  />
                  {color && <div className={cn("w-2.5 h-2.5 rounded-full shrink-0", color)} />}
                  <span className="truncate font-medium">{label}</span>
                </label>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}