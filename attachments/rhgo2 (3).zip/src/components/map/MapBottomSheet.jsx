import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Card from '@/components/design-system/Card';
import Button from '@/components/design-system/Button';
import Badge from '@/components/design-system/Badge';
import theme from '@/lib/theme';
import { ChevronUp, ChevronDown, MapPin, Star, Users } from 'lucide-react';

export default function MapBottomSheet({ location, onClose }) {
  const [expanded, setExpanded] = useState(false);

  if (!location) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 300 }}
        className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-4 pointer-events-none"
      >
        <Card
          variant="elevated"
          className={`
            mx-auto max-w-md pointer-events-auto
            transition-all ${theme.motion.standard}
            ${expanded ? 'max-h-[70vh] overflow-y-auto' : 'max-h-auto'}
          `}
        >
          {/* Header */}
          <div
            role="button"
            tabIndex={0}
            aria-expanded={expanded}
            aria-label={expanded ? "Collapse details" : "Expand details"}
            className="flex items-start justify-between p-4 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500/50 rounded-t-xl"
            onClick={() => setExpanded(!expanded)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                setExpanded(!expanded);
              }
            }}
          >
            <div className="flex-1 pointer-events-none">
              <div className="flex items-center gap-2 mb-2">
                <Badge label={location.site_type || 'Site'} variant="info" />
                {location.rating_avg && (
                  <div className="flex items-center gap-1 text-xs text-amber-400">
                    <Star className="w-3 h-3 fill-current" />
                    {location.rating_avg.toFixed(1)}
                  </div>
                )}
              </div>
              <h2 className="text-lg font-bold text-white">{location.name}</h2>
              <p className="text-xs text-slate-400 mt-1">{location.state}, {location.country}</p>
            </div>
            <div
              className="text-slate-400 hover:text-cyan-300 flex items-center"
              aria-hidden="true"
            >
              {expanded ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
            </div>
          </div>

          {/* Expandable Content */}
          <AnimatePresence>
            {expanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="border-t border-slate-700/50 p-4 space-y-4"
              >
                {/* Description */}
                {location.description && (
                  <div>
                    <p className="text-xs font-semibold text-slate-300 mb-1">About</p>
                    <p className="text-xs text-slate-400 line-clamp-3">{location.description}</p>
                  </div>
                )}

                {/* Minerals */}
                {location.minerals_found?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-slate-300 mb-2">Minerals Found</p>
                    <div className="flex flex-wrap gap-2">
                      {location.minerals_found.slice(0, 4).map((m, i) => (
                        <Badge key={i} label={m} variant="success" />
                      ))}
                    </div>
                  </div>
                )}

                {/* Difficulty */}
                {location.difficulty && (
                  <div>
                    <p className="text-xs font-semibold text-slate-300 mb-1">Difficulty</p>
                    <Badge label={location.difficulty.toUpperCase()} variant="warning" />
                  </div>
                )}

                {/* Access Info */}
                {location.access_info && (
                  <div>
                    <p className="text-xs font-semibold text-slate-300 mb-1">Access</p>
                    <p className="text-xs text-slate-400">{location.access_info}</p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-2 border-t border-slate-700/30">
                  <Button variant="primary" size="sm" className="flex-1">Save Location</Button>
                  <Button variant="secondary" size="sm" className="flex-1">Route</Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Collapsed Stats */}
          {!expanded && location.minerals_found?.length > 0 && (
            <div className="px-4 pb-4 flex items-center gap-3 text-xs">
              <div className="flex items-center gap-1 text-emerald-400">
                <MapPin className="w-3 h-3" />
                {location.minerals_found.length} minerals
              </div>
              {location.rating_count > 0 && (
                <div className="flex items-center gap-1 text-cyan-400">
                  <Users className="w-3 h-3" />
                  {location.rating_count} reviews
                </div>
              )}
            </div>
          )}
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}