/**
 * locationSignals — pure derivation of the 5 legal-first location signals
 * from a RockhoundingLocation record.
 *
 * Signals: access, collection, coordinate quality, evidence (source + date),
 * and the gated action label (navigate / verify / do-not-collect).
 *
 * Every tone maps to a consistent color family consumed by the UI:
 *   ok | info | warning | danger | unknown
 */

export function deriveAccessStatus(site) {
  const accessType = site.access_type;
  const legality = site.legality_status;

  if (accessType === "Closed" || legality === "High Risk") {
    return { label: "Closed", tone: "danger", canNavigate: false, actionLabel: "Do not collect" };
  }
  if (accessType === "Private Permission") {
    return { label: "Permission required", tone: "warning", canNavigate: false, actionLabel: "Contact owner" };
  }
  if (accessType === "Permit Required") {
    return { label: "Permit required", tone: "warning", canNavigate: true, actionLabel: "Get permit, then go" };
  }
  if (accessType === "Fee Area") {
    return { label: "Fee area", tone: "info", canNavigate: true, actionLabel: "Go here" };
  }
  if (accessType === "Free Public") {
    return { label: "Public access", tone: "ok", canNavigate: true, actionLabel: "Go here" };
  }
  // Fallback to legality_status when access_type is absent
  if (legality === "Safe Public" || legality === "Likely Legal") {
    return { label: legality, tone: "ok", canNavigate: true, actionLabel: "Go here" };
  }
  if (legality === "Use Caution") {
    return { label: "Use caution", tone: "warning", canNavigate: true, actionLabel: "Verify, then go" };
  }
  return { label: "Unknown — verify before visiting", tone: "unknown", canNavigate: true, actionLabel: "Go here" };
}

export function deriveCollectionStatus(site) {
  if (site.access_type === "Closed") return { label: "No collecting", tone: "danger" };
  if (site.access_type === "Private Permission") return { label: "With owner permission", tone: "warning" };
  if (site.commercial_collecting_allowed === false && site.collection_limit) {
    return { label: `Personal limit: ${site.collection_limit}`, tone: "info" };
  }
  if (site.commercial_collecting_allowed === true) return { label: "Collecting allowed", tone: "ok" };
  return { label: "Unknown", tone: "unknown" };
}

export function deriveCoordinateQuality(site) {
  const conf = site.ownership_confidence;
  if (site.land_status_verified && typeof conf === "number" && conf >= 0.8) {
    return { label: "Official site", tone: "ok" };
  }
  if (typeof conf === "number" && conf >= 0.5) {
    return { label: "Approximate locality", tone: "info" };
  }
  if (typeof conf === "number" && conf > 0) {
    return { label: "Approximate region", tone: "warning" };
  }
  return { label: "Unverified", tone: "unknown" };
}

export function deriveEvidence(site) {
  const sources = site.data_sources || [];
  const sourceLabel = sources.length > 0
    ? sources.join(", ")
    : (site.ownership_source || "Community-submitted");
  const lastVerified = site.last_verified;
  return {
    source: sourceLabel,
    lastVerified: lastVerified ? new Date(lastVerified).toLocaleDateString() : "Not verified",
    isVerified: !!lastVerified,
  };
}

export function deriveLocationSignals(site) {
  return {
    access: deriveAccessStatus(site),
    collection: deriveCollectionStatus(site),
    coordinates: deriveCoordinateQuality(site),
    evidence: deriveEvidence(site),
  };
}