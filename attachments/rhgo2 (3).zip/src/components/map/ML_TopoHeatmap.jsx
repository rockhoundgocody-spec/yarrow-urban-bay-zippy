import { useEffect } from 'react';
import { useMapLibre } from './MapLibreContext';

const SOURCE = 'topo-heat';

export default function ML_TopoHeatmap({ locations, visible }) {
  const map = useMapLibre();

  useEffect(() => {
    if (!map) return;

    const removeLayers = () => {
      try { if (map.getLayer('topo-heat-layer')) map.removeLayer('topo-heat-layer'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };

    const addLayers = () => {
      if (!visible || !locations?.length) { removeLayers(); return; }

      const geojson = {
        type: 'FeatureCollection',
        features: locations.filter(l => l.latitude && l.longitude).map(l => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [l.longitude, l.latitude] },
          properties: {}
        }))
      };

      if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); return; }
      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({
        id: 'topo-heat-layer', type: 'heatmap', source: SOURCE,
        paint: {
          'heatmap-weight': 0.6,
          'heatmap-intensity': ['interpolate', ['linear'], ['zoom'], 0, 1, 12, 3],
          'heatmap-radius': ['interpolate', ['linear'], ['zoom'], 0, 15, 12, 30],
          'heatmap-color': [
            'interpolate', ['linear'], ['heatmap-density'],
            0, 'rgba(49,54,149,0)', 0.2, '#4575b4',
            0.4, '#74add1', 0.6, '#fee090', 0.8, '#f46d43', 1, '#a50026'
          ],
          'heatmap-opacity': 0.7,
        }
      });
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, locations, visible]);

  return null;
}