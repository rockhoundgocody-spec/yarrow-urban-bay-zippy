import { useEffect, useMemo } from 'react';
import { useMapLibre } from './MapLibreContext';

export const MINERAL_CATEGORIES = [
  { id: 'all', label: 'All Finds', color: '#ffeb3b', keywords: [] },
  { id: 'quartz', label: 'Quartz & Silicates', color: '#e040fb', keywords: ['quartz', 'amethyst', 'agate', 'jasper', 'chert', 'flint', 'opal', 'obsidian', 'feldspar', 'mica', 'chalcedony', 'carnelian', 'citrine', 'onyx', 'sardonyx'] },
  { id: 'gemstone', label: 'Gemstones', color: '#ff1493', keywords: ['emerald', 'ruby', 'sapphire', 'topaz', 'garnet', 'tourmaline', 'aquamarine', 'beryl', 'spinel', 'tanzanite', 'zircon', 'diamond', 'alexandrite', 'peridot', 'chrysoberyl'] },
  { id: 'metallic', label: 'Metallic Minerals', color: '#ffd700', keywords: ['gold', 'silver', 'copper', 'iron', 'pyrite', 'galena', 'magnetite', 'hematite', 'chalcopyrite', 'malachite', 'azurite', 'sphalerite', 'molybdenite', 'cassiterite', 'wolframite'] },
  { id: 'fossil', label: 'Fossils', color: '#d4a574', keywords: ['fossil', 'trilobite', 'ammonite', 'coral', 'shell', 'bone', 'teeth', 'trace', 'crinoid', 'echinoderm', 'brachiopod', 'belemnite', 'shark', 'dinosaur'] },
  { id: 'crystal', label: 'Crystals', color: '#64b5f6', keywords: ['crystal', 'selenite', 'calcite', 'fluorite', 'barite', 'celestite', 'gypsum', 'halite', 'aragonite', 'stibnite', 'tourmaline', 'kunzite', 'hiddenite', 'wulfenite'] },
  { id: 'volcanic', label: 'Volcanic / Igneous', color: '#ff6b4a', keywords: ['basalt', 'granite', 'rhyolite', 'pumice', 'obsidian', 'olivine', 'pyroxene', 'hornblende', 'biotite', 'diorite', 'gabbro', 'andesite', 'tuff', 'perlite'] },
  { id: 'rare', label: 'Rare Minerals', color: '#00ffaa', keywords: ['benitoite', 'grandidierite', 'musgravite', 'jeremejevite', 'red beryl', 'painite', 'serendibite', 'alexandrite', 'demantoid', 'tsavorite', 'paraiba', 'tanzanite'] },
];

function scoreLocation(loc, cat) {
  const found = loc.minerals_found || [];
  const predicted = loc.predicted_minerals || [];

  if (cat.id === 'all') {
    const totalCount = found.length + predicted.length;
    return totalCount > 0 ? Math.min(totalCount, 10) : 1;
  }

  let score = 0;
  for (let i = 0; i < found.length; i++) {
    const m = found[i].toLowerCase();
    if (cat.keywords.some(kw => m.includes(kw))) score++;
  }
  for (let i = 0; i < predicted.length; i++) {
    const m = predicted[i].toLowerCase();
    if (cat.keywords.some(kw => m.includes(kw))) score++;
  }
  return score;
}

const SOURCE = 'mineral-hotspot';

export default function ML_MineralHotspot({ locations = [], activeCategoryId = 'all', visible = false }) {
  const map = useMapLibre();

  const category = useMemo(() => MINERAL_CATEGORIES.find(c => c.id === activeCategoryId) || MINERAL_CATEGORIES[0], [activeCategoryId]);

  const scored = useMemo(() => {
    return locations.filter(l => l.latitude && l.longitude)
      .map(l => ({ loc: l, score: scoreLocation(l, category) }))
      .filter(({ score }) => score > 0);
  }, [locations, category]);

  useEffect(() => {
    if (!map) return;

    const removeLayers = () => {
      try { if (map.getLayer('hotspot-circles')) map.removeLayer('hotspot-circles'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };

    const addLayers = () => {
      if (!visible || scored.length === 0) { removeLayers(); return; }

      const maxScore = Math.max(...scored.map(s => s.score), 1);
      const geojson = {
        type: 'FeatureCollection',
        features: scored.map(({ loc, score }) => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [loc.longitude, loc.latitude] },
          properties: { score, norm: score / maxScore, color: category.color, name: loc.name }
        }))
      };

      if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); return; }

      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({
        id: 'hotspot-circles',
        type: 'circle',
        source: SOURCE,
        paint: {
          'circle-color': ['get', 'color'],
          'circle-radius': ['interpolate', ['linear'], ['get', 'norm'], 0, 5, 1, 18],
          'circle-opacity': ['interpolate', ['linear'], ['get', 'norm'], 0, 0.4, 1, 0.85],
          'circle-stroke-width': 1.5,
          'circle-stroke-color': '#fff',
        }
      });
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, scored, visible, category]);

  return null;
}