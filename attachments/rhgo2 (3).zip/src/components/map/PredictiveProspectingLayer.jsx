import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { escapeHtml } from "@/utils";

// Color ramp: low → mid → high probability
function probColor(score) {
  if (score >= 80) return { fill: "#00ff88", stroke: "#00cc6a" };
  if (score >= 65) return { fill: "#7aff3c", stroke: "#55cc20" };
  if (score >= 50) return { fill: "#f5c842", stroke: "#cc9f20" };
  if (score >= 35) return { fill: "#ff9640", stroke: "#cc6e20" };
  return { fill: "#ff4d4d", stroke: "#cc2020" };
}

export default function PredictiveProspectingLayer({ zones = [], visible, onZoneClick }) {
  const map = useMap();
  const layerGroupRef = useRef(null);

  useEffect(() => {
    if (!layerGroupRef.current) {
      layerGroupRef.current = L.layerGroup().addTo(map);
    }

    const group = layerGroupRef.current;
    group.clearLayers();

    if (!visible || zones.length === 0) return;

    zones.forEach((zone) => {
      if (!zone.lat || !zone.lng) return;
      const { fill, stroke } = probColor(zone.probability ?? 50);
      const radius = (zone.radius_km ?? 2) * 1000; // meters

      // Outer pulse ring
      const pulse = L.circle([zone.lat, zone.lng], {
        radius: radius * 1.18,
        color: stroke,
        fillColor: fill,
        fillOpacity: 0.07,
        weight: 1,
        dashArray: "6 4",
        opacity: 0.5,
      });

      // Main zone circle
      const circle = L.circle([zone.lat, zone.lng], {
        radius,
        color: stroke,
        fillColor: fill,
        fillOpacity: 0.18,
        weight: 1.5,
        opacity: 0.85,
      });

      // Label marker
      const labelIcon = L.divIcon({
        className: "",
        iconSize: [0, 0],
        html: `
          <div style="
            background: rgba(8,7,22,0.88);
            border: 1px solid ${stroke};
            border-radius: 10px;
            padding: 4px 8px;
            white-space: nowrap;
            box-shadow: 0 0 10px ${fill}44;
            pointer-events: none;
            transform: translateX(-50%);
          ">
            <span style="font-size:10px;font-weight:700;color:${fill};letter-spacing:0.03em">${escapeHtml(zone.probability ?? "?")}%</span>
            <span style="font-size:9px;color:rgba(255,255,255,0.6);margin-left:4px">${escapeHtml(zone.name?.slice(0, 22) ?? "Zone")}</span>
          </div>
        `,
      });
      const label = L.marker([zone.lat, zone.lng], { icon: labelIcon, interactive: false });

      // Popup
      const minerals = (zone.predicted_minerals || []).slice(0, 4).join(", ");
      circle.bindPopup(`
        <div style="font-family:sans-serif;min-width:180px">
          <div style="font-weight:700;font-size:13px;margin-bottom:4px">${escapeHtml(zone.name)}</div>
          <div style="font-size:11px;color:#888;margin-bottom:6px">${escapeHtml(zone.geology_type || "Mixed geology")}</div>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <div style="width:36px;height:6px;border-radius:3px;background:linear-gradient(90deg,#ff4d4d,#f5c842,#00ff88)">
              <div style="height:100%;width:${escapeHtml(zone.probability)}%;background:${fill};border-radius:3px;opacity:0.85"></div>
            </div>
            <span style="font-size:12px;font-weight:700;color:${fill}">${escapeHtml(zone.probability)}% match</span>
          </div>
          ${minerals ? `<div style="font-size:10px;color:#666;margin-bottom:4px">💎 ${escapeHtml(minerals)}</div>` : ""}
          <div style="font-size:10px;color:#444;line-height:1.4">${escapeHtml(zone.rationale || "")}</div>
        </div>
      `, { maxWidth: 240 });

      if (onZoneClick) circle.on("click", () => onZoneClick(zone));

      pulse.addTo(group);
      circle.addTo(group);
      label.addTo(group);
    });

    return () => group.clearLayers();
  }, [zones, visible, map, onZoneClick]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (layerGroupRef.current) {
        layerGroupRef.current.clearLayers();
        map.removeLayer(layerGroupRef.current);
        layerGroupRef.current = null;
      }
    };
  }, []);

  return null;
}