import React, { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Gem, MapPin, X, ChevronRight, Zap } from "lucide-react";
import { loadProximityConfig } from "./ProximityAlertConfig";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { AnimatePresence, motion } from "framer-motion";

const WATCH_INTERVAL_MS = 30_000;
const EARTH_R = 3958.8;
const ENTER_RADIUS_MI = 0.31;

function haversineMi(lat1, lon1, lat2, lon2) {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return EARTH_R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function potentialScore(loc) {
  return (
    (loc.mineral_prediction_confidence || 0) * 0.4 +
    ((loc.rating_avg || 0) / 5) * 100 * 0.3 +
    (loc.legality_status === "Safe Public"
      ? 100
      : loc.legality_status === "Likely Legal"
      ? 70
      : 30) *
      0.3
  );
}

export default function ProximityAlertBanner() {
  const [alerts, setAlerts] = useState([]);
  const [dismissed, setDismissed] = useState(new Set());
  const locationsRef = useRef([]);
  const watchIdRef = useRef(null);
  const [_config, setConfig] = useState(() => loadProximityConfig());

  // Re-read config when user saves settings
  useEffect(() => {
    const handler = (e) => setConfig(e.detail || loadProximityConfig());
    window.addEventListener("proximityConfigUpdated", handler);
    return () => window.removeEventListener("proximityConfigUpdated", handler);
  }, []);

  useEffect(() => {
    base44.entities.RockhoundingLocation.list("-rating_avg", 500).then((locs) => {
      locationsRef.current = locs.filter((l) => l.latitude && l.longitude && potentialScore(l) >= 45);
    });
  }, []);

  const evaluate = useCallback((latitude, longitude) => {
    const cfg = loadProximityConfig();
    if (!cfg.enabled) return;
    const radiusMi = cfg.radius_m / 1609.34;

    const favSet = new Set(cfg.favorite_minerals.map(f => f.toLowerCase()));
    const isFav = (m) => favSet.has(m.toLowerCase());

    const scored = [];
    // ⚡ Bolt: Use a single-pass for loop to avoid allocating objects for out-of-bounds locations
    for (let i = 0; i < locationsRef.current.length; i++) {
      const loc = locationsRef.current[i];
      const _dist = haversineMi(latitude, longitude, loc.latitude, loc.longitude);
      if (_dist > radiusMi) continue;

      if (cfg.notify_types[0] !== "all" && !cfg.notify_types.includes(loc.site_type)) continue;

      if (cfg.notify_favorites_only && cfg.favorite_minerals.length > 0) {
        if (!loc.minerals_found?.some(isFav) && !loc.predicted_minerals?.some(isFav)) {
          continue;
        }
      }

      scored.push({ ...loc, _dist, _score: potentialScore(loc) });
    }
    scored.sort((a, b) => a._dist - b._dist);

    setAlerts((prev) => {
      // Only surface NEW locations (not already shown and not dismissed)
      const prevIds = new Set(prev.map((a) => a.id));
      const fresh = scored.filter((l) => !prevIds.has(l.id) && !dismissed.has(l.id));
      // Keep existing valid alerts, add fresh ones (cap at 3 total)
      const still = prev.filter(
        (a) => scored.some((s) => s.id === a.id) && !dismissed.has(a.id)
      );
      return [...still, ...fresh].slice(0, 3);
    });
  }, [dismissed]);

  useEffect(() => {
    if (!navigator.geolocation) return;

    // Initial fix
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => evaluate(coords.latitude, coords.longitude),
      () => {},
      { timeout: 8000, enableHighAccuracy: true }
    );

    // Continuous watch
    watchIdRef.current = navigator.geolocation.watchPosition(
      ({ coords }) => evaluate(coords.latitude, coords.longitude),
      () => {},
      { timeout: 15000, maximumAge: WATCH_INTERVAL_MS, enableHighAccuracy: false }
    );

    return () => {
      if (watchIdRef.current != null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, [evaluate]);

  const visible = alerts.filter((a) => !dismissed.has(a.id));

  if (visible.length === 0) return null;

  return (
    <div className="absolute bottom-20 left-0 right-0 z-40 px-4 space-y-2 pointer-events-none">
      <AnimatePresence>
        {visible.slice(0, 2).map((loc) => {
          const isEntering = loc._dist <= ENTER_RADIUS_MI;
          return (
            <motion.div
              key={loc.id}
              initial={{ opacity: 0, y: 20, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.96 }}
              className="pointer-events-auto"
            >
              <div
                className={`rounded-2xl border backdrop-blur-xl shadow-xl flex items-center gap-3 px-4 py-3 ${
                  isEntering
                    ? "border-amber-500/40 bg-[#1a140a]/95"
                    : "border-indigo-500/30 bg-[#0e0d1a]/93"
                }`}
              >
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                    isEntering ? "bg-amber-500/15" : "bg-indigo-500/15"
                  }`}
                >
                  {isEntering ? (
                    <Zap className="w-4 h-4 text-amber-400" />
                  ) : (
                    <Gem className="w-4 h-4 text-indigo-400" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <p
                    className={`text-xs font-semibold uppercase tracking-wider ${
                      isEntering ? "text-amber-400" : "text-indigo-400"
                    }`}
                  >
                    {isEntering ? "⚡ Entering High-Potential Zone" : "◎ Promising Area Nearby"}
                  </p>
                  <p className="text-sm font-medium text-white/90 truncate">{loc.name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    <MapPin className="w-2.5 h-2.5 text-white/30" />
                    <p className="text-[11px] text-white/40">
                      {loc._dist < 0.1
                        ? "< 0.1 mi"
                        : `${loc._dist.toFixed(1)} mi`}{" "}
                      ·{" "}
                      {(loc.minerals_found || loc.predicted_minerals || [])
                        .slice(0, 2)
                        .join(", ") || loc.site_type || "collecting site"}
                    </p>
                  </div>
                </div>

                <Link
                  to={createPageUrl("RockhoundingMap")}
                  className={`p-1.5 rounded-lg transition-all ${
                    isEntering
                      ? "text-amber-400 hover:bg-amber-500/15"
                      : "text-indigo-400 hover:bg-indigo-500/15"
                  }`}
                >
                  <ChevronRight className="w-4 h-4" />
                </Link>
                <button
                  onClick={() => setDismissed((d) => new Set([...d, loc.id]))}
                  className="p-1.5 rounded-lg text-white/30 hover:text-white/60 transition-all"
                 aria-label="Close">
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}