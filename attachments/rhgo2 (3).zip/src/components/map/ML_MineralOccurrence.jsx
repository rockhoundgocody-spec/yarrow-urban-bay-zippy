import { useEffect } from 'react';
import { useMapLibre } from './MapLibreContext';

const SOURCE_PREFIX = 'mineral-occur';

const MINERAL_COLORS = {
  quartz: '#a855f7', amethyst: '#9333ea', pyrite: '#fbbf24', gold: '#f59e0b',
  obsidian: '#374151', tourmaline: '#06b6d4', garnet: '#dc2626', agate: '#f97316', jasper: '#ea580c',
};

function getMineralColor(m) {
  return MINERAL_COLORS[m?.toLowerCase().trim()] || '#6366f1';
}

const EMPTY_SET = new Set();

export default function ML_MineralOccurrence({ locations, visible, mode = 'occurrences', visitedLocationIds = EMPTY_SET }) {
  const map = useMapLibre();
  const sourceId = `${SOURCE_PREFIX}-${mode}`;
  const layerId = `${SOURCE_PREFIX}-layer-${mode}`;

  useEffect(() => {
    if (!map) return;

    const removeLayers = () => {
      try { if (map.getLayer(layerId)) map.removeLayer(layerId); } catch (_) {}
      try { if (map.getSource(sourceId)) map.removeSource(sourceId); } catch (_) {}
    };

    const addLayers = () => {
      if (!visible || !locations?.length) { removeLayers(); return; }

      let features = [];

      if (mode === 'density') {
        const cells = {};
        locations.forEach(loc => {
          if (!loc.latitude || !loc.longitude) return;
          const key = `${Math.floor(loc.latitude * 2) / 2},${Math.floor(loc.longitude * 2) / 2}`;
          cells[key] = (cells[key] || 0) + (loc.minerals_found?.length || 1);
        });
        const maxCount = Math.max(...Object.values(cells), 1);
        features = Object.entries(cells).map(([key, count]) => {
          const [lat, lng] = key.split(',').map(Number);
          const ratio = count / maxCount;
          return { type: 'Feature', geometry: { type: 'Point', coordinates: [lng + 0.25, lat + 0.25] }, properties: { color: ratio > 0.7 ? '#f5c842' : ratio > 0.4 ? '#7aff3c' : '#00ccff', size: ratio } };
        });
      } else if (mode === 'unexplored') {
        features = locations.filter(l => l.latitude && l.longitude).map(loc => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [loc.longitude, loc.latitude] },
          properties: {
            visited: visitedLocationIds.has(loc.id),
            color: visitedLocationIds.has(loc.id) ? '#6b7280' : '#00ff88',
          }
        }));
      } else {
        // occurrences
        locations.forEach(loc => {
          const minerals = loc.minerals_found || [];
          if (!minerals.length || !loc.latitude || !loc.longitude) return;
          minerals.forEach((m, i) => features.push({
            type: 'Feature',
            geometry: { type: 'Point', coordinates: [loc.longitude + i * 0.0003, loc.latitude + i * 0.0003] },
            properties: { color: getMineralColor(m), name: m, loc_name: loc.name }
          }));
        });
      }

      const geojson = { type: 'FeatureCollection', features };

      if (map.getSource(sourceId)) { map.getSource(sourceId).setData(geojson); return; }
      map.addSource(sourceId, { type: 'geojson', data: geojson });
      map.addLayer({
        id: layerId, type: 'circle', source: sourceId,
        paint: {
          'circle-color': ['get', 'color'],
          'circle-radius': mode === 'unexplored' ? ['case', ['get', 'visited'], 4, 8] : 6,
          'circle-opacity': mode === 'unexplored' ? ['case', ['get', 'visited'], 0.3, 0.75] : 0.7,
          'circle-stroke-width': 1, 'circle-stroke-color': '#fff',
        }
      });
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, locations, visible, mode, visitedLocationIds]);

  return null;
}