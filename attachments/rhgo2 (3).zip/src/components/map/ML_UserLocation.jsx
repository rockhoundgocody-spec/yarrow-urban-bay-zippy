import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useMapLibre } from './MapLibreContext';

export default function ML_UserLocation({ position, accuracy }) {
  const map = useMapLibre();
  const markerRef = useRef(null);
  const circleRef = useRef(null);

  useEffect(() => {
    if (!map || !position) return;

    // Remove existing
    if (markerRef.current) markerRef.current.remove();
    if (circleRef.current) {
      if (map.getLayer('user-accuracy')) map.removeLayer('user-accuracy');
      if (map.getSource('user-accuracy')) map.removeSource('user-accuracy');
    }

    // Accuracy circle as GeoJSON
    if (accuracy && accuracy < 50000) {
      const addCircle = () => {
        if (map.getSource('user-accuracy')) return;
        map.addSource('user-accuracy', {
          type: 'geojson',
          data: { type: 'Feature', geometry: { type: 'Point', coordinates: [position[1], position[0]] }, properties: {} }
        });
        map.addLayer({
          id: 'user-accuracy',
          type: 'circle',
          source: 'user-accuracy',
          paint: {
            'circle-radius': { stops: [[8, accuracy / 600], [12, accuracy / 60]] },
            'circle-color': '#3b82f6',
            'circle-opacity': 0.1,
            'circle-stroke-width': 1,
            'circle-stroke-color': '#3b82f6',
            'circle-stroke-opacity': 0.4,
          }
        });
      };
      if (map.isStyleLoaded()) addCircle(); else map.once('load', addCircle);
      circleRef.current = true;
    }

    // User dot marker
    const el = document.createElement('div');
    el.style.cssText = `width:14px;height:14px;background:#3b82f6;border:3px solid #fff;border-radius:50%;box-shadow:0 0 0 3px rgba(59,130,246,0.4),0 2px 8px rgba(0,0,0,0.5);`;
    markerRef.current = new maplibregl.Marker({ element: el })
      .setLngLat([position[1], position[0]])
      .setPopup(new maplibregl.Popup({ offset: 12 }).setText('You are here'))
      .addTo(map);

    return () => {
      if (markerRef.current) markerRef.current.remove();
      try { if (map.getLayer('user-accuracy')) map.removeLayer('user-accuracy'); } catch (_) {}
      try { if (map.getSource('user-accuracy')) map.removeSource('user-accuracy'); } catch (_) {}
    };
  }, [map, position, accuracy]);

  return null;
}