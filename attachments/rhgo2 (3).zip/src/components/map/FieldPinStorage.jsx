// Offline-capable field pin storage using localStorage as cache
const STORAGE_KEY = "rockhound_field_pins";

export function loadPins() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

export function savePins(pins) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(pins));
}

export function addPin(pin) {
  const pins = loadPins();
  const newPin = { ...pin, id: `pin_${Date.now()}`, created_at: new Date().toISOString() };
  pins.push(newPin);
  savePins(pins);
  return newPin;
}

export function updatePin(id, updates) {
  const pins = loadPins();
  const idx = pins.findIndex(p => p.id === id);
  if (idx !== -1) { pins[idx] = { ...pins[idx], ...updates }; savePins(pins); }
  return pins;
}

export function deletePin(id) {
  const pins = loadPins().filter(p => p.id !== id);
  savePins(pins);
  return pins;
}