import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Camera, X, ChevronLeft, ChevronRight, ImagePlus, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function LocationPhotoGallery({ locationId, locationName }) {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [lightboxIdx, setLightboxIdx] = useState(null);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [form, setForm] = useState({ specimen_name: "", description: "", location_found: "" });
  const [selectedFile, setSelectedFile] = useState(null);
  const fileRef = useRef(null);

  const load = async () => {
    setLoading(true);
    const results = await base44.entities.LocationPhoto.filter({ location_id: locationId }, "-created_date", 30);
    setPhotos(results);
    setLoading(false);
  };

  useEffect(() => {
    if (locationId) load();
  }, [locationId]);

  const handleUpload = async () => {
    if (!selectedFile) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
      await base44.entities.LocationPhoto.create({
        location_id: locationId,
        photo_url: file_url,
        specimen_name: form.specimen_name,
        description: form.description,
        location_found: form.location_found,
      });
      setForm({ specimen_name: "", description: "", location_found: "" });
      setSelectedFile(null);
      setShowUploadForm(false);
      load();
    } catch (err) {
      console.error("Upload failed", err);
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-6">
        <Loader2 className="w-5 h-5 animate-spin" style={{ color: "rgba(122,231,255,0.5)" }} />
      </div>
    );
  }

  return (
    <div className="mt-4">
      <div className="flex items-center justify-between mb-3 px-1">
        <div>
          <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "rgba(122,231,255,0.6)" }}>
            Photo Gallery
          </p>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
            {photos.length} photo{photos.length !== 1 ? "s" : ""} from this site
          </p>
        </div>
        <button
          onClick={() => setShowUploadForm(v => !v)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold"
          style={{
            background: "rgba(0,214,143,0.1)",
            border: "1px solid rgba(0,214,143,0.35)",
            color: "#00D68F",
            minHeight: "unset",
          }}
        >
          <Camera className="w-3.5 h-3.5" /> Add Photo
        </button>
      </div>

      {/* Upload form */}
      <AnimatePresence>
        {showUploadForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-3 overflow-hidden"
          >
            <div
              className="p-3 rounded-2xl space-y-2"
              style={{ background: "rgba(0,214,143,0.05)", border: "1px solid rgba(0,214,143,0.2)" }}
            >
              {/* File picker */}
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => setSelectedFile(e.target.files?.[0] || null)} />
              <button
                onClick={() => fileRef.current?.click()}
                className="w-full py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
                style={{ background: "rgba(255,255,255,0.06)", border: "1px dashed rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.6)", minHeight: "unset" }}
              >
                <ImagePlus className="w-4 h-4" />
                {selectedFile ? selectedFile.name : "Choose Photo"}
              </button>
              <input
                placeholder="Specimen name (e.g. Amethyst)"
                value={form.specimen_name}
                onChange={e => setForm(f => ({ ...f, specimen_name: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl text-xs bg-transparent outline-none"
                style={{ border: "1px solid rgba(255,255,255,0.12)", color: "#fff" }}
              />
              <input
                placeholder="Where found at this site (optional)"
                value={form.location_found}
                onChange={e => setForm(f => ({ ...f, location_found: e.target.value }))}
                className="w-full px-3 py-2 rounded-xl text-xs bg-transparent outline-none"
                style={{ border: "1px solid rgba(255,255,255,0.12)", color: "#fff" }}
              />
              <textarea
                placeholder="Notes about this find (optional)"
                value={form.description}
                onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                rows={2}
                className="w-full px-3 py-2 rounded-xl text-xs bg-transparent outline-none resize-none"
                style={{ border: "1px solid rgba(255,255,255,0.12)", color: "#fff" }}
              />
              <div className="flex gap-2">
                <button
                  onClick={() => { setShowUploadForm(false); setSelectedFile(null); }}
                  className="flex-1 py-2 rounded-xl text-xs font-bold"
                  style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.4)", minHeight: "unset" }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpload}
                  disabled={!selectedFile || uploading}
                  className="flex-1 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1"
                  style={{ background: "rgba(0,214,143,0.2)", border: "1px solid rgba(0,214,143,0.5)", color: "#00D68F", minHeight: "unset", opacity: !selectedFile ? 0.5 : 1 }}
                >
                  {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Upload"}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Photo grid */}
      {photos.length === 0 ? (
        <div
          className="flex flex-col items-center justify-center py-8 rounded-2xl"
          style={{ background: "rgba(255,255,255,0.02)", border: "1px dashed rgba(255,255,255,0.08)" }}
        >
          <Camera className="w-8 h-8 mb-2" style={{ color: "rgba(255,255,255,0.15)" }} />
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.25)" }}>No photos yet — be the first to share a find!</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1.5">
          {photos.map((p, i) => (
            <button
              key={p.id}
              onClick={() => setLightboxIdx(i)}
              className="aspect-square rounded-xl overflow-hidden relative"
              style={{ minHeight: "unset", minWidth: "unset", background: "rgba(255,255,255,0.04)" }}
            >
              <img
                src={p.photo_url}
                alt={p.specimen_name || "Find"}
                className="w-full h-full object-cover"
              />
              {p.specimen_name && (
                <div
                  className="absolute bottom-0 left-0 right-0 px-1.5 py-1"
                  style={{ background: "linear-gradient(transparent, rgba(0,0,0,0.7))" }}
                >
                  <p className="text-[9px] font-bold text-white truncate">{p.specimen_name}</p>
                </div>
              )}
            </button>
          ))}
        </div>
      )}

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxIdx !== null && photos[lightboxIdx] && (
          <motion.div
            className="fixed inset-0 z-[9999] flex flex-col"
            style={{ background: "rgba(0,0,0,0.96)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="flex items-center justify-between px-4 py-4" style={{ paddingTop: "max(20px, env(safe-area-inset-top, 20px))" }}>
              <button onClick={() => setLightboxIdx(null)} style={{ minHeight: "unset", minWidth: "unset" }} aria-label="Close">
                <X className="w-6 h-6 text-white/60" />
              </button>
              <span className="text-sm font-bold text-white">{photos[lightboxIdx].specimen_name || locationName}</span>
              <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>{lightboxIdx + 1} / {photos.length}</span>
            </div>

            <div className="flex-1 flex items-center justify-center px-4 relative">
              <img
                src={photos[lightboxIdx].photo_url}
                alt={photos[lightboxIdx].specimen_name || "Find"}
                className="max-h-full max-w-full object-contain rounded-2xl"
              />
              {lightboxIdx > 0 && (
                <button
                  onClick={() => setLightboxIdx(i => i - 1)}
                  className="absolute left-2 w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "rgba(0,0,0,0.5)", minHeight: "unset", minWidth: "unset" }}
                 aria-label="Previous">
                  <ChevronLeft className="w-5 h-5 text-white" />
                </button>
              )}
              {lightboxIdx < photos.length - 1 && (
                <button
                  onClick={() => setLightboxIdx(i => i + 1)}
                  className="absolute right-2 w-10 h-10 rounded-xl flex items-center justify-center"
                  style={{ background: "rgba(0,0,0,0.5)", minHeight: "unset", minWidth: "unset" }}
                 aria-label="Next">
                  <ChevronRight className="w-5 h-5 text-white" />
                </button>
              )}
            </div>

            {(photos[lightboxIdx].description || photos[lightboxIdx].location_found) && (
              <div className="px-4 pb-8 pt-3">
                {photos[lightboxIdx].location_found && (
                  <p className="text-xs mb-1" style={{ color: "rgba(122,231,255,0.6)" }}>📍 {photos[lightboxIdx].location_found}</p>
                )}
                {photos[lightboxIdx].description && (
                  <p className="text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>{photos[lightboxIdx].description}</p>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}