import React from 'react';
import { Flame } from 'lucide-react';

const ZONE_STYLES = {
  blue:   { color: '#60A5FA', label: 'Low Activity' },
  green:  { color: '#4AE5A8', label: 'Promising' },
  yellow: { color: '#FBBF24', label: 'Active Zone' },
  orange: { color: '#FB923C', label: 'Hot Zone' },
  red:    { color: '#F87171', label: 'Prime Zone' },
  purple: { color: '#A78BFA', label: 'Legendary Zone' },
};

export default function HeatZoneBadge({ location, compact }) {
  if (!location?.heat_zone) return null;
  const zone = ZONE_STYLES[location.heat_zone];
  if (!zone) return null;
  return (
    <span
      className="inline-flex items-center gap-1 rounded-md font-bold uppercase tracking-wide"
      style={{
        background: `${zone.color}14`,
        border: `1px solid ${zone.color}33`,
        color: zone.color,
        fontSize: 9,
        padding: compact ? '1px 5px' : '2px 7px',
      }}
      title={typeof location.discovery_score === 'number' ? `Discovery score ${Math.round(location.discovery_score)}/100` : undefined}
    >
      <Flame className="w-2.5 h-2.5" />
      {zone.label}
      {typeof location.discovery_score === 'number' && ` · ${Math.round(location.discovery_score)}`}
    </span>
  );
}