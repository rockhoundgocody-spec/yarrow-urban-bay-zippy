/**
 * ExploreLayerToggle
 * Top-pill toggle for Explore view: Property | Prediction | Heat
 */
import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Sparkles, Flame } from "lucide-react";

const LAYERS = [
  { key: "property",   label: "Property",   icon: ShieldCheck, color: "#7AE7FF" },
  { key: "prediction", label: "Prediction",  icon: Sparkles,    color: "#8D7CFF" },
  { key: "heat",       label: "Heat",        icon: Flame,       color: "#F5B642" },
];

export default function ExploreLayerToggle({ active, onChange }) {
  return (
    <div
      className="flex items-center gap-1 p-1 rounded-2xl"
      style={{
        background: "rgba(8,8,20,0.92)",
        border: "1px solid rgba(255,255,255,0.08)",
        backdropFilter: "blur(16px)",
        boxShadow: "0 4px 20px rgba(0,0,0,0.55)",
      }}
    >
      {LAYERS.map(({ key, label, icon: Icon, color }) => {
        const isActive = active === key;
        return (
          <button
            key={key}
            onClick={() => onChange(key)}
            className="relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all duration-200"
            style={{
              color: isActive ? color : "rgba(255,255,255,0.35)",
              minWidth: 88,
              justifyContent: "center",
            }}
          >
            {isActive && (
              <motion.div
                layoutId="explore-pill"
                className="absolute inset-0 rounded-xl"
                style={{
                  background: `${color}14`,
                  border: `1px solid ${color}45`,
                  boxShadow: `0 0 12px ${color}25`,
                }}
                transition={{ type: "spring", stiffness: 340, damping: 30 }}
              />
            )}
            <Icon
              className="w-3.5 h-3.5 relative z-10"
              style={{ color: isActive ? color : "rgba(255,255,255,0.3)", strokeWidth: 2 }}
            />
            <span className="relative z-10 tracking-wide" style={{ letterSpacing: "0.05em" }}>
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}