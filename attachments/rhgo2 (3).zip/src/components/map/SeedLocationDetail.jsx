/**
 * SeedLocationDetail: bottom sheet showing detailed info for a seeded location
 */
import React from 'react';
import { X, AlertCircle, Zap, Compass, Shield } from 'lucide-react';
import { motion } from 'framer-motion';

export default function SeedLocationDetail({ location, onClose, onOpenMaps, onSaveOffline }) {
  if (!location) return null;

  const categoryIcons = {
    gravel_bar: '⛱️',
    lake_beach: '🏖️',
    quarry: '⚒️',
    public_park: '🌳',
    museum: '🏛️',
    crystal_shop: '💎',
    floodplain: '🌊',
    rock_outcrop: '🪨',
    nature_preserve: '🦅',
    industrial_beach: '⚙️',
    landscaped_area: '🌲',
    state_park: '🏞️',
  };

  const accessBadges = {
    public: { label: 'Public Access', color: 'bg-green-100 text-green-800' },
    permit_required: { label: 'Permit Required', color: 'bg-red-100 text-red-800' },
    permission_required: { label: 'Permission Required', color: 'bg-amber-100 text-amber-800' },
  };

  const accessBadge = accessBadges[location.accessType];

  return (
    <motion.div
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      className="fixed inset-x-0 bottom-0 z-40 bg-background rounded-t-xl border-t border-border shadow-2xl"
    >
      {/* Close button */}
      <button
        onClick={onClose}
        className="absolute top-4 right-4 p-2 hover:bg-secondary rounded-lg transition-colors"
       aria-label="Close">
        <X className="w-5 h-5" />
      </button>

      {/* Content */}
      <div className="max-h-[80vh] overflow-y-auto p-4 space-y-4">
        {/* Header */}
        <div className="pr-10">
          <div className="flex items-start gap-2">
            <span className="text-4xl">{categoryIcons[location.category] || '📍'}</span>
            <div>
              <h2 className="text-xl font-bold">{location.name}</h2>
              <p className="text-xs text-muted-foreground">
                {location.distance?.toFixed(1)} miles away
              </p>
            </div>
          </div>
        </div>

        {/* Access badge */}
        {accessBadge && (
          <div className={`inline-block px-3 py-1 rounded-lg text-xs font-semibold ${accessBadge.color}`}>
            {accessBadge.label}
          </div>
        )}

        {/* Legality note */}
        {location.legalityNote && (
          <div className="p-3 rounded-lg border border-amber-200 bg-amber-50 flex gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800">{location.legalityNote}</p>
          </div>
        )}

        {/* Details */}
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Difficulty</span>
            <span className="font-medium capitalize">{location.difficulty}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Source</span>
            <span className="font-medium capitalize">{location.source}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Confidence</span>
            <span className="font-medium">{Math.round(location.confidence * 100)}%</span>
          </div>
        </div>

        {/* Expected finds */}
        {location.expectedFinds?.length > 0 && (
          <div className="space-y-1">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1">
              <Zap className="w-3 h-3" /> Expected Finds
            </h3>
            <div className="flex flex-wrap gap-1">
              {location.expectedFinds.map((find, idx) => (
                <span
                  key={idx}
                  className="px-2 py-1 rounded-full bg-secondary text-xs font-medium text-secondary-foreground"
                >
                  {find}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Notes */}
        {location.notes && (
          <div className="space-y-1">
            <h3 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground flex items-center gap-1">
              <Compass className="w-3 h-3" /> Notes
            </h3>
            <p className="text-sm text-muted-foreground">{location.notes}</p>
          </div>
        )}

        {/* Data source */}
        <div className="text-xs text-muted-foreground bg-secondary/20 p-2 rounded flex items-center gap-1">
          <Shield className="w-3 h-3" />
          Data verified {new Date(location.lastReported).toLocaleDateString()}
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-2 pt-2 pb-4">
          <button
            onClick={() => onOpenMaps(location.lat, location.lng, location.name)}
            className="py-2 rounded-lg border border-border bg-background hover:bg-secondary text-xs font-semibold transition-colors"
          >
            Open in Maps
          </button>
          <button
            onClick={() => onSaveOffline(location.id)}
            className="py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors"
          >
            Save Offline
          </button>
        </div>
      </div>
    </motion.div>
  );
}