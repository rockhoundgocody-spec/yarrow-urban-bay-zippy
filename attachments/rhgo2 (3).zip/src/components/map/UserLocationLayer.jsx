import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";

export default function UserLocationLayer({ position, accuracy }) {
  const map = useMap();
  const layerRef = useRef(null);

  useEffect(() => {
    if (!position) return;
    if (layerRef.current) layerRef.current.remove();

    const group = L.layerGroup().addTo(map);

    // Accuracy ring
    if (accuracy && accuracy < 50000) {
      L.circle(position, {
        radius: accuracy,
        color: "#3b82f6",
        fillColor: "#3b82f6",
        fillOpacity: 0.08,
        weight: 1,
        opacity: 0.4,
      }).addTo(group);
    }

    // User dot
    const userIcon = L.divIcon({
      html: `<div style="
        width:14px;height:14px;
        background:#3b82f6;
        border:3px solid #fff;
        border-radius:50%;
        box-shadow:0 0 0 3px rgba(59,130,246,0.4),0 2px 8px rgba(0,0,0,0.5);
      "></div>`,
      className: "",
      iconSize: [14, 14],
      iconAnchor: [7, 7],
    });
    L.marker(position, { icon: userIcon }).bindTooltip("You are here", { permanent: false }).addTo(group);

    layerRef.current = group;
    return () => group.remove();
  }, [map, position, accuracy]);

  return null;
}