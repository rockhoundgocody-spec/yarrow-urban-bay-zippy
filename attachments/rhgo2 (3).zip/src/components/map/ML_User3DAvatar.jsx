import { useEffect, useRef, useContext } from 'react';
import maplibregl from 'maplibre-gl';
import { MapLibreContext } from './MapLibreContext';

const AVATAR_HTML = `
<div style="position:relative;width:40px;height:60px;transform-style:preserve-3d;perspective:200px;">
  <!-- Shadow -->
  <div style="position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);width:28px;height:8px;background:rgba(0,0,0,0.35);border-radius:50%;filter:blur(3px);"></div>
  <!-- Body -->
  <div style="
    position:absolute;bottom:16px;left:50%;transform:translateX(-50%);
    width:18px;height:22px;
    background:linear-gradient(160deg,#3b82f6 0%,#1d4ed8 100%);
    border-radius:5px 5px 4px 4px;
    box-shadow:0 0 12px rgba(59,130,246,0.7),2px 2px 0 rgba(0,0,0,0.2);
  "></div>
  <!-- Head -->
  <div style="
    position:absolute;bottom:38px;left:50%;transform:translateX(-50%);
    width:16px;height:16px;
    background:linear-gradient(135deg,#fde68a 0%,#f59e0b 100%);
    border-radius:50%;
    box-shadow:0 0 14px rgba(59,130,246,0.9),0 0 4px rgba(0,0,0,0.3);
    border:2px solid rgba(255,255,255,0.4);
  "></div>
  <!-- Left arm -->
  <div style="position:absolute;bottom:24px;left:4px;width:6px;height:14px;background:#1d4ed8;border-radius:3px;transform:rotate(10deg);"></div>
  <!-- Right arm -->
  <div style="position:absolute;bottom:24px;right:4px;width:6px;height:14px;background:#1d4ed8;border-radius:3px;transform:rotate(-10deg);"></div>
  <!-- Left leg -->
  <div style="position:absolute;bottom:2px;left:10px;width:7px;height:14px;background:#1e3a8a;border-radius:3px;transform:rotate(5deg);"></div>
  <!-- Right leg -->
  <div style="position:absolute;bottom:2px;right:10px;width:7px;height:14px;background:#1e3a8a;border-radius:3px;transform:rotate(-5deg);"></div>
  <!-- Pulse ring -->
  <div style="
    position:absolute;bottom:-2px;left:50%;transform:translateX(-50%);
    width:36px;height:36px;
    border-radius:50%;
    border:2px solid rgba(59,130,246,0.6);
    animation:avatarPulse 1.8s ease-out infinite;
  "></div>
  <style>
    @keyframes avatarPulse {
      0%   { transform:translateX(-50%) scale(0.8); opacity:0.8; }
      100% { transform:translateX(-50%) scale(2.2); opacity:0; }
    }
  </style>
</div>
`;

export default function ML_User3DAvatar({ position }) {
  const map = useContext(MapLibreContext);
  const markerRef = useRef(null);

  useEffect(() => {
    if (!map || !position) return;

    const el = document.createElement('div');
    el.innerHTML = AVATAR_HTML;

    markerRef.current = new maplibregl.Marker({ element: el, anchor: 'bottom', offset: [0, 4] })
      .setLngLat([position[1], position[0]])
      .addTo(map);

    return () => {
      markerRef.current?.remove();
      markerRef.current = null;
    };
  }, [map, position]);

  // Update position if it changes
  useEffect(() => {
    if (markerRef.current && position) {
      markerRef.current.setLngLat([position[1], position[0]]);
    }
  }, [position]);

  return null;
}