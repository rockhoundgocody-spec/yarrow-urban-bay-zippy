import React from "react";
import { Shield, ShieldCheck, AlertTriangle, Lock, DollarSign, Users, CheckCircle2, HelpCircle } from "lucide-react";

const LAND_COLORS = {
  "BLM":        { bg: "bg-yellow-500/10", text: "text-yellow-400", border: "border-yellow-500/20" },
  "USFS":       { bg: "bg-green-500/10",  text: "text-green-400",  border: "border-green-500/20" },
  "NPS":        { bg: "bg-blue-500/10",   text: "text-blue-400",   border: "border-blue-500/20" },
  "FWS":        { bg: "bg-teal-500/10",   text: "text-teal-400",   border: "border-teal-500/20" },
  "State Park": { bg: "bg-purple-500/10", text: "text-purple-400", border: "border-purple-500/20" },
  "State Land": { bg: "bg-indigo-500/10", text: "text-indigo-400", border: "border-indigo-500/20" },
  "Private":    { bg: "bg-red-500/10",    text: "text-red-400",    border: "border-red-500/20" },
  "Tribal":     { bg: "bg-orange-500/10", text: "text-orange-400", border: "border-orange-500/20" },
  "Unknown":    { bg: "bg-white/5",       text: "text-white/40",   border: "border-white/10" },
};

function Chip({ icon: Icon, label, color }) {
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full border ${color.bg} ${color.text} ${color.border}`}>
      <Icon className="w-2.5 h-2.5" />
      {label}
    </span>
  );
}

export default function LocationRiskBadges({ location, compact = false }) {
  const {
    land_manager,
    permit_required,
    access_type,
    confidence_score,
    flagged,
    collection_limit,
    commercial_collecting_allowed,
    fee_required,
  } = location;

  const landColor = LAND_COLORS[land_manager] || LAND_COLORS["Unknown"];

  // Confidence color
  const confColor = confidence_score >= 70
    ? { bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20" }
    : confidence_score >= 40
    ? { bg: "bg-yellow-500/10", text: "text-yellow-400", border: "border-yellow-500/20" }
    : { bg: "bg-white/5", text: "text-white/40", border: "border-white/10" };

  return (
    <div className="flex flex-wrap gap-1 mt-1.5">
      {land_manager && land_manager !== "Unknown" && (
        <Chip icon={Shield} label={land_manager} color={landColor} />
      )}

      {permit_required ? (
        <Chip icon={Lock} label="Permit Required" color={{ bg: "bg-red-500/10", text: "text-red-400", border: "border-red-500/20" }} />
      ) : land_manager && land_manager !== "Unknown" ? (
        <Chip icon={ShieldCheck} label="No Permit" color={{ bg: "bg-emerald-500/10", text: "text-emerald-400", border: "border-emerald-500/20" }} />
      ) : null}

      {fee_required && (
        <Chip icon={DollarSign} label="Fee Area" color={{ bg: "bg-amber-500/10", text: "text-amber-400", border: "border-amber-500/20" }} />
      )}

      {commercial_collecting_allowed === false && land_manager && land_manager !== "Unknown" && !compact && (
        <Chip icon={Users} label="Personal Use Only" color={{ bg: "bg-white/5", text: "text-white/40", border: "border-white/10" }} />
      )}

      {flagged && (
        <Chip icon={AlertTriangle} label="Review Required" color={{ bg: "bg-orange-500/10", text: "text-orange-400", border: "border-orange-500/20" }} />
      )}

      {confidence_score > 0 && !compact && (
        <Chip icon={confidence_score >= 70 ? CheckCircle2 : HelpCircle} label={`${confidence_score}% Verified`} color={confColor} />
      )}
    </div>
  );
}