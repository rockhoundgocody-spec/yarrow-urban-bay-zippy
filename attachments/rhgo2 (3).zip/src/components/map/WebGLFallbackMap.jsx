import React, { useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import { MapLibreContext } from "./MapLibreContext";
import WebGLFallbackBanner from "./WebGLFallbackBanner";

const TILE_RASTER = {
  dark:      { url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",      sub: "abcd", attr: '&copy; OpenStreetMap, &copy; CARTO' },
  outdoor:   { url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",     sub: "abcd", attr: '&copy; OpenStreetMap, &copy; CARTO' },
  positron:  { url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",     sub: "abcd", attr: '&copy; OpenStreetMap, &copy; CARTO' },
  topo:      { url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", sub: "abcd", attr: '&copy; OpenStreetMap, &copy; CARTO' },
  voyager:   { url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", sub: "abcd", attr: '&copy; OpenStreetMap, &copy; CARTO' },
  satellite: { url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", sub: "", attr: 'Tiles &copy; Esri' },
};

const playerIcon = L.divIcon({
  className: "rh-fallback-player",
  html: '<div style="width:20px;height:20px;border-radius:50%;background:#5ae4b7;border:3px solid #fff;box-shadow:0 0 12px rgba(90,228,183,0.6);"></div>',
  iconSize: [20, 20],
  iconAnchor: [10, 10],
});

function MapEvents({ onMapReady, onBoundsChange, onMapClick }) {
  useMapEvents({
    moveend: (e) => {
      if (onBoundsChange) {
        const m = e.target;
        const b = m.getBounds();
        onBoundsChange({
          bounds: { north: b.getNorth(), south: b.getSouth(), east: b.getEast(), west: b.getWest() },
          center: [m.getCenter().lat, m.getCenter().lng],
          zoom: m.getZoom(),
        });
      }
    },
    click: (e) => {
      if (onMapClick) onMapClick({ lat: e.latlng.lat, lng: e.latlng.lng });
    },
  });
  useEffect(() => {
    if (onMapReady) onMapReady(null);
  }, [onMapReady]);
  return null;
}

/**
 * WebGLFallbackMap — drop-in Leaflet replacement for MapLibreMap.
 * Accepts the same props signature. MapLibreContext is set to null
 * so child layer components that check the context silently skip.
 */
export default function WebGLFallbackMap({
  center = [-98.5795, 39.8283], // [lng, lat] — same convention as MapLibreMap
  zoom = 15,
  tileStyleId = "dark",
  onMapReady,
  onBoundsChange,
  onMapClick,
  children,
  className = "",
  style = {},
}) {
  const tile = TILE_RASTER[tileStyleId] || TILE_RASTER.dark;
  // Convert [lng, lat] → [lat, lng] for Leaflet
  const leafletCenter = [center[1] ?? 39.8283, center[0] ?? -98.5795];

  return (
    <MapLibreContext.Provider value={null}>
      <div
        className={`rh-layer-map ${className}`}
        style={{
          width: "100%",
          height: "100%",
          position: "absolute",
          inset: 0,
          background: "#101e1e",
          borderRadius: 18,
          overflow: "hidden",
          ...style,
        }}
      >
        <WebGLFallbackBanner />
        <div style={{ position: "absolute", inset: 0, top: 32 }}>
          <MapContainer
            center={leafletCenter}
            zoom={zoom}
            style={{ width: "100%", height: "100%", background: "#101e1e" }}
            zoomControl={true}
            attributionControl={true}
          >
            <TileLayer url={tile.url} subdomains={tile.sub || "abc"} attribution={tile.attr} maxZoom={21} />
            <MapEvents onMapReady={onMapReady} onBoundsChange={onBoundsChange} onMapClick={onMapClick} />
            <PlayerLocationLeaflet />
          </MapContainer>
        </div>
        {children}
      </div>
    </MapLibreContext.Provider>
  );
}

/** Player location marker via Leaflet (mirrors MapLibreMap's geolocation logic). */
function PlayerLocationLeaflet() {
  const markerRef = useRef(null);
  const [pos, setPos] = React.useState(null);

  useEffect(() => {
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      (p) => setPos([p.coords.latitude, p.coords.longitude]),
      () => {},
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, []);

  if (!pos) return null;
  return <Marker ref={markerRef} position={pos} icon={playerIcon} />;
}