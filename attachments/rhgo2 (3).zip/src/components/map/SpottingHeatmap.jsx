/**
 * SpottingHeatmap — Trending hunting spots heatmap overlay.
 *
 * Queries the Spotting entity and renders a MapLibre heatmap showing
 * areas with the highest concentration of community-spotted specimens.
 * More recent spottings are weighted higher to surface *trending* spots.
 *
 * Features:
 *  - Time range filter (7d / 30d / all-time)
 *  - Intensity heatmap with color legend
 *  - Top trending spots panel (clustered by ~10km grid cell)
 *  - Click popup with specimen details
 */
import React, { useEffect, useRef, useState, useCallback, useMemo } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Flame, TrendingUp, Clock, Loader2, MapPin, Layers } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { escapeHtml } from "@/utils";

// ── Color palette: cool → hot gradient ──────────────────────────────────────
const HEAT_STOPS = [
  [0,    "rgba(0,80,120,0)"],
  [0.15, "rgba(0,120,180,0.25)"],
  [0.35, "rgba(0,214,143,0.45)"],
  [0.55, "rgba(245,182,66,0.65)"],
  [0.75, "rgba(255,120,40,0.82)"],
  [1.0,  "rgba(255,40,40,0.95)"],
];

const TIME_RANGES = [
  { id: "7d",  label: "7 Days",  days: 7 },
  { id: "30d", label: "30 Days", days: 30 },
  { id: "all", label: "All Time", days: 0 },
];

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Snap lat/lng to a ~10km grid cell key for clustering. */
function cellKey(lat, lng) {
  return `${lat.toFixed(1)},${lng.toFixed(1)}`;
}

/** Days since a given ISO date string. */
function daysSince(iso) {
  if (!iso) return 999;
  const diff = Date.now() - new Date(iso).getTime();
  return diff / 86400000;
}

/** Weight: more recent spottings score higher (exponential decay, 30-day half-life). */
function recencyWeight(createdDate) {
  const d = daysSince(createdDate);
  if (d > 365) return 0.1;
  return Math.max(0.15, Math.exp(-d / 30));
}

function buildGeoJSON(spottings) {
  const features = spottings
    .filter(s => s.gps_latitude && s.gps_longitude)
    .map(s => ({
      type: "Feature",
      geometry: { type: "Point", coordinates: [s.gps_longitude, s.gps_latitude] },
      properties: {
        weight: Math.min(recencyWeight(s.created_date), 1),
        name: s.specimen_name || "Unknown",
        location: s.location_name || "",
        user: s.user_display_name || "Anonymous",
        likes: s.likes_count || 0,
      },
    }));
  return { type: "FeatureCollection", features };
}

/** Aggregate spottings into grid cells and rank by score (recency-weighted count). */
function computeTopSpots(spottings) {
  const cells = new Map();
  for (const s of spottings) {
    if (!s.gps_latitude || !s.gps_longitude) continue;
    const key = cellKey(s.gps_latitude, s.gps_longitude);
    if (!cells.has(key)) {
      cells.set(key, {
        key,
        lat: s.gps_latitude,
        lng: s.gps_longitude,
        count: 0,
        score: 0,
        topSpecimen: s.specimen_name || "Unknown",
        specimens: new Set(),
      });
    }
    const cell = cells.get(key);
    cell.count++;
    cell.score += recencyWeight(s.created_date);
    cell.specimens.add(s.specimen_name || "Unknown");
    if (s.specimen_name) cell.topSpecimen = s.specimen_name;
  }
  return Array.from(cells.values())
    .map(c => ({ ...c, specimens: c.specimens.size }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);
}

// ── Component ────────────────────────────────────────────────────────────────
export default function SpottingHeatmap() {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const [timeRange, setTimeRange] = useState("30d");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [count, setCount] = useState(0);
  const [topSpots, setTopSpots] = useState([]);
  const [showTopSpots, setShowTopSpots] = useState(true);

  const rangeCfg = useMemo(() => TIME_RANGES.find(r => r.id === timeRange), [timeRange]);

  const loadData = useCallback(async (rangeId) => {
    if (!map.current) return;
    setLoading(true);
    setError(null);
    try {
      let spottings = await base44.entities.Spotting.list("-created_date", 500);

      // Filter by time range
      const cfg = TIME_RANGES.find(r => r.id === rangeId);
      if (cfg.days > 0) {
        const cutoff = Date.now() - cfg.days * 86400000;
        spottings = spottings.filter(s => {
          if (!s.created_date) return false;
          return new Date(s.created_date).getTime() >= cutoff;
        });
      }

      const geo = spottings.filter(s => s.gps_latitude && s.gps_longitude);
      setCount(geo.length);
      setTopSpots(computeTopSpots(geo));

      const geojson = buildGeoJSON(geo);

      // Update source
      if (map.current.getSource("spotting-heat")) {
        map.current.getSource("spotting-heat").setData(geojson);
      }

      // Re-render layers (remove + re-add to ensure fresh paint)
      ["spotting-heat-layer", "spotting-points"].forEach(id => {
        if (map.current.getLayer(id)) map.current.removeLayer(id);
      });

      if (geo.features.length === 0) return;

      map.current.addLayer({
        id: "spotting-heat-layer",
        type: "heatmap",
        source: "spotting-heat",
        maxzoom: 14,
        paint: {
          "heatmap-weight": ["interpolate", ["linear"], ["get", "weight"], 0, 0, 1, 1],
          "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 0, 1, 8, 3, 14, 5],
          "heatmap-color": ["interpolate", ["linear"], ["heatmap-density"], ...HEAT_STOPS.flat()],
          "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 0, 22, 8, 36, 14, 50],
          "heatmap-opacity": ["interpolate", ["linear"], ["zoom"], 7, 0.85, 14, 0.6],
        },
      }, "waterway-label");

      map.current.addLayer({
        id: "spotting-points",
        type: "circle",
        source: "spotting-heat",
        minzoom: 11,
        paint: {
          "circle-radius": 6,
          "circle-color": "rgba(245,182,66,0.85)",
          "circle-stroke-width": 1.5,
          "circle-stroke-color": "rgba(255,255,255,0.3)",
          "circle-opacity": 0.9,
        },
      });
    } catch (err) {
      setError("Failed to load spotting data.");
    } finally {
      setLoading(false);
    }
  }, []);

  // Init map
  useEffect(() => {
    if (!mapContainer.current) return;
    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: "https://tiles.openfreemap.org/styles/positron",
      center: [-98.5, 39.8],
      zoom: 4,
      attributionControl: false,
    });
    map.current.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");

    map.current.on("load", () => {
      // Add empty source first; the time-range effect will populate it
      map.current.addSource("spotting-heat", {
        type: "geojson",
        data: { type: "FeatureCollection", features: [] },
      });
    });

    // Popup on point click
    map.current.on("click", "spotting-points", (e) => {
      const props = e.features[0]?.properties;
      if (!props) return;
      new maplibregl.Popup({ closeButton: false, className: "geo-cell-tooltip" })
        .setLngLat(e.lngLat)
        .setHTML(`
          <div style="background:#0e141b;border:1px solid rgba(245,182,66,0.35);border-radius:10px;padding:10px 12px;min-width:150px">
            <div style="font-weight:700;color:#fff;font-size:13px">${escapeHtml(props.name)}</div>
            ${props.location ? `<div style="color:#7AE7FF;font-size:11px;margin-top:2px">${escapeHtml(props.location)}</div>` : ""}
            <div style="color:rgba(255,255,255,0.4);font-size:10px;margin-top:4px">by ${escapeHtml(props.user)} · ${props.likes} likes</div>
          </div>
        `)
        .addTo(map.current);
    });
    map.current.on("mouseenter", "spotting-points", () => { map.current.getCanvas().style.cursor = "pointer"; });
    map.current.on("mouseleave", "spotting-points", () => { map.current.getCanvas().style.cursor = ""; });

    return () => { map.current?.remove(); map.current = null; };
  }, []);

  // Reload when time range changes
  useEffect(() => {
    if (!map.current) return;
    if (map.current.loaded()) {
      loadData(timeRange);
    } else {
      map.current.once("load", () => loadData(timeRange));
    }
  }, [timeRange, loadData]);

  const flyToSpot = (spot) => {
    if (!map.current) return;
    map.current.flyTo({ center: [spot.lng, spot.lat], zoom: 12, duration: 800 });
  };

  return (
    <div className="absolute inset-0 flex flex-col">
      {/* ── Controls overlay ── */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2" style={{ maxWidth: 220 }}>

        {/* Title */}
        <div className="flex items-center gap-1.5 rounded-2xl px-3 py-2"
          style={{ background: "rgba(8,11,16,0.92)", border: "1px solid rgba(245,182,66,0.25)", backdropFilter: "blur(14px)" }}>
          <Flame style={{ width: 14, height: 14, color: "#F5B642" }} />
          <span className="text-xs font-bold text-white/70 uppercase tracking-wider">Trending Spots</span>
        </div>

        {/* Time range filter */}
        <div className="flex items-center gap-1 rounded-2xl p-1"
          style={{ background: "rgba(8,11,16,0.9)", border: "1px solid rgba(255,255,255,0.08)", backdropFilter: "blur(14px)" }}>
          {TIME_RANGES.map(({ id, label }) => (
            <button key={id} onClick={() => setTimeRange(id)}
              className="flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-semibold transition-all flex-1 justify-center"
              style={{
                background: timeRange === id ? "rgba(245,182,66,0.12)" : "transparent",
                border: timeRange === id ? "1px solid rgba(245,182,66,0.3)" : "1px solid transparent",
                color: timeRange === id ? "#F5B642" : "rgba(255,255,255,0.35)",
              }}>
              <Clock style={{ width: 11, height: 11 }} />
              {label}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="rounded-2xl px-3 py-2.5"
          style={{ background: "rgba(8,11,16,0.88)", border: "1px solid rgba(255,255,255,0.07)", backdropFilter: "blur(12px)" }}>
          <div className="flex items-center gap-1.5 mb-2">
            <Layers style={{ width: 11, height: 11, color: "#F5B642" }} />
            <span className="text-[10px] font-bold text-white/55 uppercase tracking-widest">Specimen Density</span>
          </div>
          <div className="h-2 rounded-full w-28" style={{
            background: "linear-gradient(90deg, rgba(0,120,180,0.3), rgba(0,214,143,0.5), rgba(245,182,66,0.7), rgba(255,40,40,0.9))"
          }} />
          <div className="flex justify-between mt-1">
            <span className="text-[9px] text-white/30">Low</span>
            <span className="text-[9px] text-white/30">Hot</span>
          </div>
          {count > 0 && (
            <div className="mt-2 text-[9px] text-white/25">{count} spottings plotted</div>
          )}
        </div>

        {/* Top trending spots panel */}
        {topSpots.length > 0 && (
          <div className="rounded-2xl overflow-hidden"
            style={{ background: "rgba(8,11,16,0.9)", border: "1px solid rgba(245,182,66,0.15)", backdropFilter: "blur(12px)" }}>
            <button onClick={() => setShowTopSpots(!showTopSpots)}
              className="w-full flex items-center gap-1.5 px-3 py-2"
              style={{ borderBottom: showTopSpots ? "1px solid rgba(255,255,255,0.06)" : "none" }}>
              <TrendingUp style={{ width: 12, height: 12, color: "#F5B642" }} />
              <span className="text-[10px] font-bold text-white/55 uppercase tracking-widest flex-1 text-left">Top Hotspots</span>
              <span className="text-[9px] text-white/30">{showTopSpots ? "▾" : "▸"}</span>
            </button>
            {showTopSpots && (
              <div className="max-h-[180px] overflow-y-auto">
                {topSpots.map((spot, i) => (
                  <button key={spot.key} onClick={() => flyToSpot(spot)}
                    className="w-full flex items-center gap-2 px-3 py-2 transition-colors hover:bg-white/5 text-left"
                    style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                    <span className="text-[10px] font-bold w-5 flex-shrink-0"
                      style={{ color: i === 0 ? "#F5B642" : i === 1 ? "#C7D0D9" : i === 2 ? "#CD7F32" : "rgba(255,255,255,0.3)" }}>
                      {i + 1}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-semibold text-white/80 truncate">{spot.topSpecimen}</div>
                      <div className="text-[9px] text-white/30">{spot.count} finds · {spot.specimens} minerals</div>
                    </div>
                    <MapPin style={{ width: 10, height: 10, color: "rgba(245,182,66,0.5)" }} className="flex-shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Loading overlay */}
      {loading && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3"
          style={{ background: "rgba(8,11,16,0.72)", backdropFilter: "blur(8px)" }}>
          <Loader2 style={{ width: 28, height: 28, color: "#F5B642" }} className="animate-spin" />
          <span className="text-sm text-white/50">Loading trending spots…</span>
        </div>
      )}

      {/* Empty state */}
      {!loading && count === 0 && !error && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3"
          style={{ background: "rgba(8,11,16,0.6)" }}>
          <Flame style={{ width: 36, height: 36, color: "rgba(245,182,66,0.3)" }} />
          <span className="text-sm text-white/40">No spottings in this time range</span>
          <span className="text-xs text-white/25">Try a wider time window</span>
        </div>
      )}

      {/* Error */}
      {error && !loading && (
        <div className="absolute bottom-16 left-3 right-3 z-10 rounded-xl p-3 text-center"
          style={{ background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.3)" }}>
          <p className="text-xs text-red-400">{error}</p>
        </div>
      )}

      {/* Map */}
      <div ref={mapContainer} className="absolute inset-0" />
    </div>
  );
}