/**
 * GeoSearchPanel
 * Slide-up filter panel for the geospatial search view.
 * Filters: radius, minerals, legality score range, bounding box (from map).
 */
import React, { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { SlidersHorizontal, X, Search, MapPin, Shield, Gem, Circle } from "lucide-react";

const COMMON_MINERALS = [
  "Quartz", "Agate", "Jasper", "Obsidian", "Pyrite", "Amethyst",
  "Turquoise", "Opal", "Garnet", "Tourmaline", "Fluorite", "Calcite",
  "Feldspar", "Mica", "Topaz", "Malachite", "Azurite", "Chalcedony",
];

const LEGALITY_TIERS = [
  { label: "Safe Public", value: "Safe Public", color: "#00D68F" },
  { label: "Likely Legal", value: "Likely Legal", color: "#7AE7FF" },
  { label: "Use Caution", value: "Use Caution", color: "#F5B642" },
  { label: "High Risk", value: "High Risk", color: "#ef4444" },
];

const RADIUS_OPTIONS = [5, 10, 25, 50, 100, 250];

export default function GeoSearchPanel({ filters, onChange, resultCount, loading }) {
  const [open, setOpen] = useState(false);
  const [mineralInput, setMineralInput] = useState("");

  const update = useCallback((patch) => onChange({ ...filters, ...patch }), [filters, onChange]);

  const toggleMineral = (m) => {
    const cur = filters.minerals || [];
    update({ minerals: cur.includes(m) ? cur.filter(x => x !== m) : [...cur, m] });
  };

  const toggleLegality = (v) => {
    const cur = filters.legalityTiers || [];
    update({ legalityTiers: cur.includes(v) ? cur.filter(x => x !== v) : [...cur, v] });
  };

  const addCustomMineral = () => {
    const val = mineralInput.trim();
    if (!val) return;
    const cur = filters.minerals || [];
    if (!cur.includes(val)) update({ minerals: [...cur, val] });
    setMineralInput("");
  };

  const activeCount = [
    (filters.minerals?.length > 0) ? 1 : 0,
    (filters.legalityTiers?.length > 0) ? 1 : 0,
    (filters.radius !== 50) ? 1 : 0,
    (filters.bbox) ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  return (
    <>
      {/* Trigger bar */}
      <div className="absolute top-2 left-2 right-2 z-20 flex items-center gap-2">
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 px-3 py-2.5 rounded-2xl flex-1 text-left transition-all"
          style={{ background: "rgba(10,15,20,0.92)", border: "1px solid rgba(0,214,143,0.25)", backdropFilter: "blur(12px)" }}
        >
          <Search className="w-4 h-4 shrink-0" style={{ color: "#00D68F" }} />
          <span className="text-sm font-semibold" style={{ color: activeCount > 0 ? "#00D68F" : "rgba(255,255,255,0.4)" }}>
            {activeCount > 0 ? `${activeCount} filter${activeCount !== 1 ? "s" : ""} active` : "Search & filter locations…"}
          </span>
          {loading && <div className="ml-auto w-3.5 h-3.5 border border-emerald-400/40 border-t-emerald-400 rounded-full animate-spin shrink-0" />}
        </button>

        {/* Results badge */}
        <div className="px-2.5 py-2.5 rounded-2xl shrink-0"
          style={{ background: "rgba(10,15,20,0.92)", border: "1px solid rgba(255,255,255,0.08)", backdropFilter: "blur(12px)" }}>
          <span className="text-xs font-black" style={{ color: "#7AE7FF" }}>{resultCount}</span>
          <span className="text-[9px] text-white/25 ml-1">sites</span>
        </div>
      </div>

      {/* Slide-up panel */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="absolute inset-0 z-30"
              style={{ background: "rgba(0,0,0,0.5)" }}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              className="absolute bottom-0 left-0 right-0 z-40 rounded-t-3xl overflow-hidden"
              style={{ background: "rgba(8,12,18,0.98)", border: "1px solid rgba(255,255,255,0.08)", maxHeight: "80%" }}
              initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 28, stiffness: 320 }}
            >
              <div className="overflow-y-auto" style={{ maxHeight: "80vh" }}>
                {/* Handle */}
                <div className="flex justify-center pt-3 pb-1">
                  <div className="w-10 h-1 rounded-full" style={{ background: "rgba(255,255,255,0.15)" }} />
                </div>

                {/* Header */}
                <div className="flex items-center justify-between px-5 pt-2 pb-4">
                  <div className="flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4" style={{ color: "#00D68F" }} />
                    <span className="text-base font-black text-white">Geo Search Filters</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {activeCount > 0 && (
                      <button onClick={() => { onChange({ radius: 50, minerals: [], legalityTiers: [], legalityMin: 0, bbox: null }); }}
                        className="text-[10px] font-bold px-2.5 py-1.5 rounded-xl"
                        style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444", border: "1px solid rgba(239,68,68,0.2)" }}>
                        Clear all
                      </button>
                    )}
                    <button onClick={() => setOpen(false)}
                      className="p-1.5 rounded-xl"
                      style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)" }} aria-label="Close">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="px-5 pb-8 space-y-6">

                  {/* Radius */}
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Circle className="w-3.5 h-3.5" style={{ color: "#7AE7FF" }} />
                      <span className="text-xs font-black uppercase tracking-widest text-white/40">Search Radius</span>
                      <span className="ml-auto text-sm font-black" style={{ color: "#7AE7FF" }}>{filters.radius} mi</span>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {RADIUS_OPTIONS.map(r => (
                        <button key={r} onClick={() => update({ radius: r })}
                          className="px-3 py-2 rounded-xl text-xs font-bold transition-all"
                          style={{
                            background: filters.radius === r ? "rgba(122,231,255,0.15)" : "rgba(255,255,255,0.04)",
                            border: `1px solid ${filters.radius === r ? "rgba(122,231,255,0.4)" : "rgba(255,255,255,0.08)"}`,
                            color: filters.radius === r ? "#7AE7FF" : "rgba(255,255,255,0.35)",
                          }}>
                          {r} mi
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Legality / Safety */}
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Shield className="w-3.5 h-3.5" style={{ color: "#00D68F" }} />
                      <span className="text-xs font-black uppercase tracking-widest text-white/40">Safety / Legal Tier</span>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {LEGALITY_TIERS.map(tier => {
                        const active = (filters.legalityTiers || []).includes(tier.value);
                        return (
                          <button key={tier.value} onClick={() => toggleLegality(tier.value)}
                            className="px-3 py-2 rounded-xl text-xs font-bold transition-all"
                            style={{
                              background: active ? `${tier.color}18` : "rgba(255,255,255,0.04)",
                              border: `1px solid ${active ? `${tier.color}50` : "rgba(255,255,255,0.08)"}`,
                              color: active ? tier.color : "rgba(255,255,255,0.35)",
                            }}>
                            {tier.label}
                          </button>
                        );
                      })}
                    </div>

                    {/* Minimum score slider */}
                    <div className="mt-3">
                      <div className="flex justify-between text-[10px] text-white/25 mb-1.5">
                        <span>Min legality score</span>
                        <span style={{ color: "#00D68F" }}>{filters.legalityMin ?? 0}+</span>
                      </div>
                      <input type="range" min={0} max={100} step={5}
                        value={filters.legalityMin ?? 0}
                        onChange={e => update({ legalityMin: Number(e.target.value) })}
                        className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                        style={{ accentColor: "#00D68F", background: `linear-gradient(to right, #00D68F ${filters.legalityMin ?? 0}%, rgba(255,255,255,0.08) ${filters.legalityMin ?? 0}%)` }}
                      />
                    </div>
                  </div>

                  {/* Minerals */}
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Gem className="w-3.5 h-3.5" style={{ color: "#8D7CFF" }} />
                      <span className="text-xs font-black uppercase tracking-widest text-white/40">Minerals Present</span>
                      {(filters.minerals?.length > 0) && (
                        <span className="ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full"
                          style={{ background: "rgba(141,124,255,0.15)", color: "#8D7CFF" }}>
                          {filters.minerals.length} selected
                        </span>
                      )}
                    </div>
                    <div className="flex gap-1.5 flex-wrap mb-3">
                      {COMMON_MINERALS.map(m => {
                        const active = (filters.minerals || []).includes(m);
                        return (
                          <button key={m} onClick={() => toggleMineral(m)}
                            className="px-2.5 py-1.5 rounded-xl text-[11px] font-semibold transition-all"
                            style={{
                              background: active ? "rgba(141,124,255,0.15)" : "rgba(255,255,255,0.04)",
                              border: `1px solid ${active ? "rgba(141,124,255,0.45)" : "rgba(255,255,255,0.08)"}`,
                              color: active ? "#8D7CFF" : "rgba(255,255,255,0.35)",
                            }}>
                            {m}
                          </button>
                        );
                      })}
                    </div>
                    {/* Custom mineral input */}
                    <div className="flex gap-2">
                      <input
                        value={mineralInput}
                        onChange={e => setMineralInput(e.target.value)}
                        onKeyDown={e => e.key === "Enter" && addCustomMineral()}
                        placeholder="Add custom mineral…"
                        className="flex-1 px-3 py-2 rounded-xl text-xs text-white placeholder-white/20 outline-none"
                        style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
                      />
                      <button onClick={addCustomMineral}
                        className="px-3 py-2 rounded-xl text-xs font-bold"
                        style={{ background: "rgba(141,124,255,0.15)", color: "#8D7CFF", border: "1px solid rgba(141,124,255,0.3)" }}>
                        Add
                      </button>
                    </div>
                  </div>

                  {/* Bounding box status */}
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-3.5 h-3.5" style={{ color: "#F5B642" }} />
                      <span className="text-xs font-black uppercase tracking-widest text-white/40">Map Bounding Box</span>
                    </div>
                    {filters.bbox ? (
                      <div className="flex items-center justify-between p-3 rounded-xl"
                        style={{ background: "rgba(245,182,66,0.08)", border: "1px solid rgba(245,182,66,0.25)" }}>
                        <div className="text-[10px] font-mono text-white/40 space-y-0.5">
                          <div>N {filters.bbox.north.toFixed(3)}° / S {filters.bbox.south.toFixed(3)}°</div>
                          <div>E {filters.bbox.east.toFixed(3)}° / W {filters.bbox.west.toFixed(3)}°</div>
                        </div>
                        <button onClick={() => update({ bbox: null })}
                          className="p-1.5 rounded-lg"
                          style={{ color: "#F5B642", background: "rgba(245,182,66,0.1)" }} aria-label="Close">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <p className="text-xs text-white/25">Pan and zoom the map — the current viewport is used as a bounding box filter automatically.</p>
                    )}
                  </div>

                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}