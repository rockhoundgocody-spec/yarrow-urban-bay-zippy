/**
 * PlayerLocationMarker — Pokemon-Go-style animated player position.
 * Drop-in replacement for the generic Leaflet user dot.
 * Renders into a MapLibre marker element.
 *
 * Export: createPlayerMarkerElement() → returns a DOM div ready for maplibregl.Marker
 * Also exports the React component for use in overlays.
 */
import React from "react";
import { motion } from "framer-motion";
import { fxFlags } from "@/theme/performance";

// React component (for portal/overlay usage)
export default function PlayerLocationMarker({ accuracy, heading }) {
  const fx = fxFlags();

  return (
    <div className="relative flex items-center justify-center" style={{ width: 52, height: 52 }}>
      {/* Accuracy ring */}
      {fx.heavyGlow && (
        <motion.div
          className="absolute rounded-full pointer-events-none"
          style={{
            width: 52, height: 52,
            background: "radial-gradient(circle, rgba(122,231,255,0.12), transparent 70%)",
          }}
          animate={{ scale: [1, 1.3, 1], opacity: [0.7, 0.3, 0.7] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      {/* Outer pulse ring */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{ width: 36, height: 36, border: "1.5px solid rgba(122,231,255,0.5)" }}
        animate={{ scale: [1, 1.6, 2.2], opacity: [0.6, 0.2, 0] }}
        transition={{ duration: 2.0, repeat: Infinity, ease: "easeOut" }}
      />

      {/* Heading indicator */}
      {heading != null && (
        <div
          className="absolute"
          style={{
            width: 52, height: 52,
            transform: `rotate(${heading}deg)`,
            transformOrigin: "center",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: 0, left: "50%",
              width: 8, height: 12,
              marginLeft: -4,
              background: "linear-gradient(180deg, rgba(122,231,255,0.8), transparent)",
              clipPath: "polygon(50% 0%, 0% 100%, 100% 100%)",
            }}
          />
        </div>
      )}

      {/* Core dot */}
      <div
        style={{
          width: 18, height: 18,
          borderRadius: "50%",
          background: "linear-gradient(135deg, #7AE7FF, #5BC0FF)",
          border: "2.5px solid rgba(255,255,255,0.9)",
          boxShadow: "0 0 0 3px rgba(122,231,255,0.35), 0 2px 12px rgba(0,0,0,0.6)",
          zIndex: 10,
        }}
      />
    </div>
  );
}

// DOM factory for maplibre marker injection
export function createPlayerMarkerElement() {
  const el = document.createElement("div");
  el.style.cssText = `
    position: relative;
    width: 52px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    pointer-events: none;
  `;

  // Pulse ring (CSS animation — zero JS cost)
  el.innerHTML = `
    <style>
      @keyframes rhPlayerPulse {
        0% { transform: scale(1); opacity: 0.6; }
        100% { transform: scale(2.4); opacity: 0; }
      }
      @keyframes rhPlayerGlow {
        0%, 100% { box-shadow: 0 0 0 3px rgba(122,231,255,0.4), 0 2px 12px rgba(0,0,0,0.6); }
        50% { box-shadow: 0 0 0 5px rgba(122,231,255,0.25), 0 0 18px rgba(122,231,255,0.35); }
      }
    </style>
    <div style="
      position: absolute;
      width: 36px; height: 36px;
      border-radius: 50%;
      border: 1.5px solid rgba(122,231,255,0.6);
      animation: rhPlayerPulse 2s ease-out infinite;
    "></div>
    <div style="
      width: 18px; height: 18px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7AE7FF, #5BC0FF);
      border: 2.5px solid rgba(255,255,255,0.9);
      animation: rhPlayerGlow 2.4s ease-in-out infinite;
      position: relative; z-index: 2;
    "></div>
  `;
  return el;
}