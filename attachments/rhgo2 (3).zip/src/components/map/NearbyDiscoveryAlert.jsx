/**
 * NearbyDiscoveryAlert — proximity notification banner.
 * Shows when user is near a saved location or high-value formation.
 */
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Bell, X, MapPin, Gem, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function NearbyDiscoveryAlert({ alerts = [] }) {
  const [dismissed, setDismissed] = useState([]);

  const visible = alerts.filter(a => !dismissed.includes(a.id));
  if (!visible.length) return null;

  const primary = visible[0];
  const dist = primary.distance;
  const distLabel = dist < 0.1 ? `${Math.round(dist * 1000)}m` : `${dist.toFixed(1)}km`;

  return (
    <motion.div
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, rgba(245,182,66,0.2), rgba(245,182,66,0.08))',
        border: '1px solid rgba(245,182,66,0.35)',
        boxShadow: '0 0 32px rgba(245,182,66,0.2), inset 0 1px 0 rgba(255,255,255,0.06)',
        backdropFilter: 'blur(20px)',
      }}
      initial={{ y: 24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      exit={{ y: 24, opacity: 0 }}
      transition={{ type: 'spring', damping: 22, stiffness: 260 }}
    >
      <div className="flex items-start gap-3 px-4 pt-4 pb-3">
        {/* Pulse icon */}
        <div className="relative flex-shrink-0">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(245,182,66,0.2)', border: '1px solid rgba(245,182,66,0.4)' }}
          >
            <Bell className="w-5 h-5" style={{ color: '#F5B642' }} />
          </div>
          <motion.div
            className="absolute inset-0 rounded-xl"
            style={{ border: '1px solid rgba(245,182,66,0.6)' }}
            animate={{ scale: [1, 1.4, 1], opacity: [0.6, 0, 0.6] }}
            transition={{ duration: 2.2, repeat: Infinity }}
          />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <p className="text-xs font-black uppercase tracking-wider" style={{ color: '#F5B642' }}>
                Nearby Discovery Site
              </p>
              <p className="text-sm font-semibold text-white mt-0.5 truncate">
                {primary.name || 'Geological Formation'}
              </p>
              <div className="flex items-center gap-3 mt-1.5">
                <span className="flex items-center gap-1 text-xs text-white/60">
                  <MapPin className="w-3 h-3" />
                  {distLabel} away
                </span>
                {primary.minerals_found?.length > 0 && (
                  <span className="flex items-center gap-1 text-xs text-white/60">
                    <Gem className="w-3 h-3" />
                    {primary.minerals_found.slice(0, 2).join(', ')}
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={() => setDismissed(d => [...d, primary.id])}
              className="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{ background: 'rgba(255,255,255,0.06)' }}
             aria-label="Close">
              <X className="w-3 h-3 text-white/40" />
            </button>
          </div>

          {/* Multiple alerts indicator */}
          {visible.length > 1 && (
            <div className="mt-2 flex items-center gap-1">
              {visible.slice(1).map((a) => (
                <span key={a.id} className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: 'rgba(245,182,66,0.12)', color: 'rgba(245,182,66,0.7)' }}>
                  +{(a.distance < 0.1 ? Math.round(a.distance * 1000) + 'm' : a.distance.toFixed(1) + 'km')} · {a.name || 'Site'}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Action row */}
      <Link to="/ExpeditionPlanner">
        <div
          className="flex items-center justify-between px-4 py-2.5 text-xs font-bold"
          style={{
            borderTop: '1px solid rgba(245,182,66,0.15)',
            color: 'rgba(245,182,66,0.8)',
          }}
        >
          View on Map
          <ChevronRight className="w-3.5 h-3.5" />
        </div>
      </Link>
    </motion.div>
  );
}