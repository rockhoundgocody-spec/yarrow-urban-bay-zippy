/**
 * ML_GeologicalLayers
 * MapLibre GIS overlay: real geological polygons (Macrostrat), fault lines (USGS),
 * rock type points (Macrostrat columns), and fossil density heatmap (PBDB).
 *
 * All data sourced from public-domain APIs — no API key required.
 */
import { useEffect, useRef, useCallback } from "react";
import {
  fetchRockUnits,
  fetchFaultLines,
  fetchFossilDensity,
  fetchRockTypePoints,
  geoAgeColor,
  LITH_COLORS,
} from "@/services/geologicalDataService";

const SOURCES = {
  rockUnits:   "gis-rock-units",
  faults:      "gis-faults",
  rockPoints:  "gis-rock-points",
  fossils:     "gis-fossils",
};
const LAYERS = {
  rockFill:    "gis-rock-fill",
  rockBorder:  "gis-rock-border",
  faultLines:  "gis-fault-lines",
  rockPoints:  "gis-rock-pts",
  fossilHeat:  "gis-fossil-heat",
  fossilPts:   "gis-fossil-pts",
};

function removeAll(map) {
  Object.values(LAYERS).forEach(id => { if (map.getLayer(id)) map.removeLayer(id); });
  Object.values(SOURCES).forEach(id => { if (map.getSource(id)) map.removeSource(id); });
}

function safeAdd(map, sourceId, sourceSpec) {
  if (!map.getSource(sourceId)) map.addSource(sourceId, sourceSpec);
}

function safeAddLayer(map, layerSpec) {
  if (!map.getLayer(layerSpec.id)) map.addLayer(layerSpec);
}

function setVis(map, layerId, visible) {
  if (map.getLayer(layerId)) map.setLayoutProperty(layerId, "visibility", visible ? "visible" : "none");
}

export default function ML_GeologicalLayers({
  mapInstance,
  mapBounds,
  visible = false,
  faultLinesVisible = false,
  rockTypesVisible = false,
  mineralsVisible = false,
  fossilsVisible = false,
}) {
  const loadedBoundsRef = useRef(null);
  const loadingRef = useRef(false);

  const buildLayers = useCallback(async (map, bounds) => {
    if (loadingRef.current) return;
    loadingRef.current = true;

    try {
      // Fetch all four data sources in parallel
      const [rockUnits, faults, fossilCells, rockPts] = await Promise.allSettled([
        fetchRockUnits(bounds),
        fetchFaultLines(bounds),
        fetchFossilDensity(bounds),
        fetchRockTypePoints(bounds),
      ]);

      if (!map || !map.getCanvas) { loadingRef.current = false; return; }

      // Tear down old layers first
      removeAll(map);

      // ── 1. Geologic rock unit polygons (Macrostrat) ──────────────────────
      const units = rockUnits.status === "fulfilled" ? rockUnits.value : [];
      if (units.length > 0) {
        // Inject age-derived fill colors into properties
        const enriched = units.map(f => ({
          ...f,
          properties: {
            ...f.properties,
            fill_color: f.properties.color && f.properties.color.startsWith("#")
              ? f.properties.color
              : geoAgeColor(f.properties.b_age || 0, f.properties.t_age || 0),
          }
        }));

        safeAdd(map, SOURCES.rockUnits, {
          type: "geojson",
          data: { type: "FeatureCollection", features: enriched }
        });

        safeAddLayer(map, {
          id: LAYERS.rockFill,
          type: "fill",
          source: SOURCES.rockUnits,
          layout: { visibility: rockTypesVisible ? "visible" : "none" },
          paint: {
            "fill-color": ["get", "fill_color"],
            "fill-opacity": 0.35,
          }
        });

        safeAddLayer(map, {
          id: LAYERS.rockBorder,
          type: "line",
          source: SOURCES.rockUnits,
          layout: { visibility: rockTypesVisible ? "visible" : "none" },
          paint: {
            "line-color": ["get", "fill_color"],
            "line-width": 1,
            "line-opacity": 0.6,
          }
        });

        // Popup on click
        map.on("click", LAYERS.rockFill, (e) => {
          const props = e.features?.[0]?.properties;
          if (!props) return;
          const el = document.createElement("div");
          const container = document.createElement("div");
          container.style.cssText = "background:#0e141b;border:1px solid rgba(255,255,255,0.12);border-radius:12px;padding:12px 14px;max-width:220px;font-family:sans-serif";

          const nameDiv = document.createElement("div");
          nameDiv.style.cssText = "font-size:13px;font-weight:700;color:#f3f7fa;margin-bottom:4px";
          nameDiv.textContent = props.name || "Rock Unit";
          container.appendChild(nameDiv);

          const lithDiv = document.createElement("div");
          lithDiv.style.cssText = "font-size:11px;color:rgba(255,255,255,0.5);margin-bottom:2px";
          lithDiv.textContent = props.lithology || "";
          container.appendChild(lithDiv);

          const ageDiv = document.createElement("div");
          ageDiv.style.cssText = "font-size:11px;color:#7AE7FF";
          ageDiv.textContent = (props.age || "") + (props.t_age ? ` · ${Math.round(props.t_age)}–${Math.round(props.b_age)} Ma` : "");
          container.appendChild(ageDiv);

          el.appendChild(container);
          el.style.cssText = "pointer-events:none";
          const Popup1 = window.maplibregl && window.maplibregl.Popup;
          if (Popup1) new Popup1({ closeButton: false, offset: 4 }).setDOMContent(el).setLngLat(e.lngLat).addTo(map);
        });
        map.on("mouseenter", LAYERS.rockFill, () => { map.getCanvas().style.cursor = "pointer"; });
        map.on("mouseleave", LAYERS.rockFill, () => { map.getCanvas().style.cursor = ""; });
      }

      // ── 2. Fault lines (USGS) ─────────────────────────────────────────────
      const faultFeatures = faults.status === "fulfilled" ? faults.value : [];
      safeAdd(map, SOURCES.faults, {
        type: "geojson",
        data: { type: "FeatureCollection", features: faultFeatures }
      });
      safeAddLayer(map, {
        id: LAYERS.faultLines,
        type: "line",
        source: SOURCES.faults,
        layout: { visibility: faultLinesVisible ? "visible" : "none", "line-join": "round", "line-cap": "round" },
        paint: {
          "line-color": "#ef4444",
          "line-width": 2,
          "line-opacity": 0.75,
          "line-dasharray": [5, 3],
        }
      });
      map.on("click", LAYERS.faultLines, (e) => {
        const props = e.features?.[0]?.properties;
        if (!props) return;
        const el = document.createElement("div");
        const container = document.createElement("div");
        container.style.cssText = "background:#0e141b;border:1px solid rgba(239,68,68,0.35);border-radius:12px;padding:10px 14px;max-width:200px;font-family:sans-serif";

        const nameDiv = document.createElement("div");
        nameDiv.style.cssText = "font-size:12px;font-weight:700;color:#fca5a5";
        nameDiv.textContent = props.name;
        container.appendChild(nameDiv);

        if (props.last_activity) {
          const actDiv = document.createElement("div");
          actDiv.style.cssText = "font-size:11px;color:rgba(255,255,255,0.4);margin-top:3px";
          actDiv.textContent = `Last: ${props.last_activity}`;
          container.appendChild(actDiv);
        }

        el.appendChild(container);
        const Popup2 = window.maplibregl && window.maplibregl.Popup;
        if (Popup2) new Popup2({ closeButton: false, offset: 4 }).setDOMContent(el).setLngLat(e.lngLat).addTo(map);
      });

      // ── 3. Rock type column points (Macrostrat) ───────────────────────────
      const rockPtFeatures = rockPts.status === "fulfilled" ? rockPts.value : [];
      const enrichedPts = rockPtFeatures.map(f => ({
        ...f,
        properties: { ...f.properties, pt_color: LITH_COLORS[f.properties.classification] || "#6b7280" }
      }));
      safeAdd(map, SOURCES.rockPoints, {
        type: "geojson",
        data: { type: "FeatureCollection", features: enrichedPts }
      });
      safeAddLayer(map, {
        id: LAYERS.rockPoints,
        type: "circle",
        source: SOURCES.rockPoints,
        layout: { visibility: rockTypesVisible ? "visible" : "none" },
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["zoom"], 5, 4, 10, 8],
          "circle-color": ["get", "pt_color"],
          "circle-opacity": 0.85,
          "circle-stroke-width": 1.5,
          "circle-stroke-color": "rgba(255,255,255,0.4)",
        }
      });
      map.on("click", LAYERS.rockPoints, (e) => {
        const p = e.features?.[0]?.properties;
        if (!p) return;
        const el = document.createElement("div");
        const container = document.createElement("div");
        container.style.cssText = "background:#0e141b;border:1px solid rgba(255,255,255,0.10);border-radius:12px;padding:10px 14px;max-width:200px;font-family:sans-serif";

        const nameDiv = document.createElement("div");
        nameDiv.style.cssText = "font-size:12px;font-weight:700;color:#f3f7fa";
        nameDiv.textContent = p.name || "Rock Column";
        container.appendChild(nameDiv);

        const lithDiv = document.createElement("div");
        lithDiv.style.cssText = "font-size:11px;color:rgba(255,255,255,0.5);margin-top:3px";
        lithDiv.textContent = (p.lith || "") + (p.age_label ? ` · ${p.age_label}` : "");
        container.appendChild(lithDiv);

        el.appendChild(container);
        const Popup3 = window.maplibregl && window.maplibregl.Popup;
        if (Popup3) new Popup3({ closeButton: false, offset: 4 }).setDOMContent(el).setLngLat(e.lngLat).addTo(map);
      });

      // ── 4. Fossil density (PBDB) — heat + dot layers ───────────────────────
      const fossilFeatures = fossilCells.status === "fulfilled" ? fossilCells.value : [];
      safeAdd(map, SOURCES.fossils, {
        type: "geojson",
        data: { type: "FeatureCollection", features: fossilFeatures }
      });
      safeAddLayer(map, {
        id: LAYERS.fossilHeat,
        type: "heatmap",
        source: SOURCES.fossils,
        layout: { visibility: fossilsVisible ? "visible" : "none" },
        paint: {
          "heatmap-weight": ["interpolate", ["linear"], ["get", "density"], 0, 0, 100, 1],
          "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 5, 0.8, 12, 2.5],
          "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 5, 20, 12, 50],
          "heatmap-opacity": ["interpolate", ["linear"], ["zoom"], 5, 0.7, 12, 0.5],
          "heatmap-color": [
            "interpolate", ["linear"], ["heatmap-density"],
            0,    "rgba(0,0,0,0)",
            0.1,  "#d4a843",
            0.35, "#e67e22",
            0.65, "#c0392b",
            1,    "#8e44ad",
          ],
        }
      });
      safeAddLayer(map, {
        id: LAYERS.fossilPts,
        type: "circle",
        source: SOURCES.fossils,
        minzoom: 8,
        layout: { visibility: fossilsVisible ? "visible" : "none" },
        paint: {
          "circle-radius": ["interpolate", ["linear"], ["get", "count"], 1, 5, 50, 14],
          "circle-color": "#d4a843",
          "circle-opacity": 0.7,
          "circle-stroke-width": 1.5,
          "circle-stroke-color": "rgba(255,255,255,0.5)",
        }
      });
      map.on("click", LAYERS.fossilPts, (e) => {
        const p = e.features?.[0]?.properties;
        if (!p) return;
        const el = document.createElement("div");
        const container = document.createElement("div");
        container.style.cssText = "background:#0e141b;border:1px solid rgba(212,168,67,0.4);border-radius:12px;padding:10px 14px;max-width:200px;font-family:sans-serif";

        const titleDiv = document.createElement("div");
        titleDiv.style.cssText = "font-size:12px;font-weight:700;color:#f5c842";
        titleDiv.textContent = "Fossil Occurrence Zone";
        container.appendChild(titleDiv);

        const statsDiv = document.createElement("div");
        statsDiv.style.cssText = "font-size:11px;color:rgba(255,255,255,0.6);margin-top:4px";
        statsDiv.textContent = `${p.count} occurrences · ${p.taxa} taxa`;
        container.appendChild(statsDiv);

        el.appendChild(container);
        const Popup4 = window.maplibregl && window.maplibregl.Popup;
        if (Popup4) new Popup4({ closeButton: false, offset: 4 }).setDOMContent(el).setLngLat(e.lngLat).addTo(map);
      });

      loadedBoundsRef.current = bounds;
    } catch (err) {
      console.warn("[ML_GeologicalLayers] load error:", err);
    } finally {
      loadingRef.current = false;
    }
  }, [faultLinesVisible, rockTypesVisible, fossilsVisible]);

  // Load on mount / bounds change when visible
  useEffect(() => {
    if (!mapInstance || !mapBounds || !visible) return;
    const boundsKey = [mapBounds.south, mapBounds.north, mapBounds.west, mapBounds.east].map(v => v.toFixed(2)).join(",");
    const prevKey = loadedBoundsRef.current
      ? [loadedBoundsRef.current.south, loadedBoundsRef.current.north, loadedBoundsRef.current.west, loadedBoundsRef.current.east].map(v => v.toFixed(2)).join(",")
      : null;
    if (boundsKey === prevKey) return; // same viewport
    buildLayers(mapInstance, mapBounds);
  }, [mapInstance, mapBounds, visible, buildLayers]);

  // Teardown when hidden
  useEffect(() => {
    if (!mapInstance || visible) return;
    removeAll(mapInstance);
    loadedBoundsRef.current = null;
  }, [mapInstance, visible]);

  // Sync individual sub-layer visibility without reloading data
  useEffect(() => {
    if (!mapInstance || !visible) return;
    setVis(mapInstance, LAYERS.rockFill,   rockTypesVisible);
    setVis(mapInstance, LAYERS.rockBorder, rockTypesVisible);
    setVis(mapInstance, LAYERS.rockPoints, rockTypesVisible);
    setVis(mapInstance, LAYERS.faultLines, faultLinesVisible);
    setVis(mapInstance, LAYERS.fossilHeat, fossilsVisible);
    setVis(mapInstance, LAYERS.fossilPts,  fossilsVisible);
  }, [mapInstance, visible, rockTypesVisible, faultLinesVisible, fossilsVisible, mineralsVisible]);

  return null;
}