import React, { useState, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import {
  X, Loader2, Zap, AlertTriangle, ChevronDown, ChevronUp,
  Layers, Mountain, Gem, Map, Lightbulb, RefreshCw, Target, Crown, FlaskConical
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

// ── Likelihood colors ──────────────────────────────────────────────────────────
const LIKELIHOOD_CONFIG = {
  high:   { color: "#10b981", bg: "rgba(16,185,129,0.12)",  label: "High",   bar: "bg-emerald-500" },
  medium: { color: "#f59e0b", bg: "rgba(245,158,11,0.12)",  label: "Medium", bar: "bg-amber-500"   },
  low:    { color: "#6b7280", bg: "rgba(107,114,128,0.12)", label: "Low",    bar: "bg-gray-400"    },
  trace:  { color: "#8b5cf6", bg: "rgba(139,92,246,0.12)",  label: "Trace",  bar: "bg-violet-400"  },
};

const POTENTIAL_CONFIG = {
  exceptional: { color: "#10b981", label: "Exceptional ✦" },
  high:        { color: "#34d399", label: "High"           },
  moderate:    { color: "#f59e0b", label: "Moderate"       },
  low:         { color: "#6b7280", label: "Low"            },
  poor:        { color: "#ef4444", label: "Poor"           },
};

const OCCURRENCE_LABELS = {
  primary:      "Primary",
  secondary:    "Secondary",
  placer:       "Placer",
  vein:         "Vein",
  disseminated: "Disseminated",
  contact_zone: "Contact Zone",
};

// ── Confidence bar ─────────────────────────────────────────────────────────────
function ConfidenceBar({ pct, color }) {
  return (
    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden mt-1">
      <div
        className="h-full rounded-full transition-all duration-700"
        style={{ width: `${pct}%`, background: color || "#f59e0b" }}
      />
    </div>
  );
}

// ── Collapsible section ────────────────────────────────────────────────────────
function Section({ icon: Icon, title, children, defaultOpen = false, accent = "#00f5ff" }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-xl overflow-hidden border border-white/8 mb-2">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between px-3.5 py-2.5 text-left"
        style={{ background: "rgba(255,255,255,0.04)" }}
      >
        <div className="flex items-center gap-2 text-[13px] font-semibold" style={{ color: accent }}>
          <Icon className="w-3.5 h-3.5 shrink-0" />
          {title}
        </div>
        {open
          ? <ChevronUp className="w-3.5 h-3.5 opacity-40" />
          : <ChevronDown className="w-3.5 h-3.5 opacity-40" />}
      </button>
      {open && <div className="px-3.5 pb-3 pt-1">{children}</div>}
    </div>
  );
}

// ── Host rock card ─────────────────────────────────────────────────────────────
function HostRockCard({ rock }) {
  const cfg = LIKELIHOOD_CONFIG[rock.likelihood] || LIKELIHOOD_CONFIG.low;
  return (
    <div
      className="rounded-lg p-2.5 mb-2 border"
      style={{ background: cfg.bg, borderColor: cfg.color + "30" }}
    >
      <div className="flex items-center justify-between mb-1">
        <span className="text-[12px] font-bold text-white">{rock.rock_type}</span>
        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ color: cfg.color, background: cfg.color + "22" }}>
          {cfg.label} · {rock.likelihood_pct}%
        </span>
      </div>
      <ConfidenceBar pct={rock.likelihood_pct} color={cfg.color} />
      {rock.formation_notes && (
        <p className="text-[11px] text-white/55 mt-1.5 leading-relaxed">{rock.formation_notes}</p>
      )}
      {rock.associated_minerals?.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-1.5">
          {rock.associated_minerals.map((m) => (
            <span key={m} className="text-[10px] px-1.5 py-0.5 rounded bg-white/8 text-white/70">{m}</span>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Mineral prediction card ────────────────────────────────────────────────────
function MineralCard({ mineral }) {
  return (
    <div className="rounded-lg p-2.5 mb-2 border border-amber-500/20 bg-amber-500/6">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className="text-[13px] font-bold text-amber-300">{mineral.mineral}</span>
            <span className="text-[10px] text-white/40 font-medium">{OCCURRENCE_LABELS[mineral.occurrence_type] || mineral.occurrence_type}</span>
          </div>
          <div className="text-[11px] text-white/50 mb-1">{mineral.host_rock}</div>
          <ConfidenceBar pct={mineral.confidence} color="#f59e0b" />
          <div className="text-[10px] text-amber-400/80 font-semibold mt-0.5">{mineral.confidence}% confidence</div>
        </div>
      </div>
      {mineral.collecting_tip && (
        <p className="text-[11px] text-white/55 mt-2 leading-relaxed border-t border-white/8 pt-1.5">
          💡 {mineral.collecting_tip}
        </p>
      )}
    </div>
  );
}

// ── Paywall gate (shows for free users) ────────────────────────────────────────
function GeologyPaywall({ onClose }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 text-center gap-5">
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center"
        style={{ background: "rgba(139,92,246,0.2)", border: "1px solid rgba(139,92,246,0.4)", boxShadow: "0 0 30px rgba(139,92,246,0.3)" }}
      >
        <FlaskConical className="w-8 h-8 text-violet-400" />
      </div>
      <div>
        <div className="text-[15px] font-bold text-white mb-1">Geology Insight</div>
        <div className="text-[12px] text-white/45 leading-relaxed max-w-[220px] mx-auto">
          AI-powered host rock analysis, mineral predictions, and USGS deposit data — requires a paid plan.
        </div>
      </div>
      <div className="w-full space-y-2">
        <Link
          to="/Pricing"
          onClick={onClose}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm text-white"
          style={{ background: "linear-gradient(135deg,#8b5cf6,#6d28d9)", boxShadow: "0 4px 20px rgba(139,92,246,0.4)" }}
        >
          <Crown className="w-4 h-4" /> Unlock with Crystal Pro
        </Link>
      </div>
      <div className="text-[11px] text-white/20">Included with Crystal Pro and Expedition Elite</div>
    </div>
  );
}

// ── Main panel ─────────────────────────────────────────────────────────────────
export default function GeologyInsightPanel({ mapBounds, mapCenter, nearbyLocations, onClose, user }) {
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [error, setError] = useState(null);

  // Gate: free users see the paywall
  const isFree = !user || !user.subscription_tier || user.subscription_tier === "free" ||
    (user.subscription_status !== "active" && user.subscription_status !== "past_due");

  const nearbyMinerals = React.useMemo(() => {
    const set = new Set();
    nearbyLocations?.forEach((l) => l.minerals_found?.forEach((m) => set.add(m)));
    return [...set];
  }, [nearbyLocations]);

  const runAnalysis = useCallback(async () => {
    if (!mapBounds || !mapCenter) return;
    setLoading(true);
    setError(null);
    setReport(null);
    try {
      const res = await base44.functions.invoke("geologyInsight", {
        bounds: mapBounds,
        center: mapCenter,
        nearby_minerals: nearbyMinerals,
      });
      if (res.data?.ok) {
        setReport(res.data.data);
      } else {
        setError(res.data?.error || "Analysis failed.");
      }
    } catch (e) {
      setError(e.message || "Network error.");
    } finally {
      setLoading(false);
    }
  }, [mapBounds, mapCenter, nearbyMinerals]);

  const potCfg = report ? (POTENTIAL_CONFIG[report.overall_potential] || POTENTIAL_CONFIG.moderate) : null;

  return (
    <div
      className="absolute top-0 right-0 z-30 h-full flex flex-col"
      style={{
        width: 340,
        background: "linear-gradient(180deg, rgba(6,6,18,0.98) 0%, rgba(10,4,28,0.98) 100%)",
        backdropFilter: "blur(24px)",
        borderLeft: "1px solid rgba(0,245,255,0.15)",
        boxShadow: "-8px 0 40px rgba(0,0,0,0.6), inset 1px 0 0 rgba(0,245,255,0.08)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-4 py-3 shrink-0 border-b"
        style={{ borderColor: "rgba(0,245,255,0.12)" }}
      >
        <div className="flex items-center gap-2">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
            style={{ background: "rgba(139,92,246,0.25)", border: "1px solid rgba(139,92,246,0.4)" }}
          >
            <Layers className="w-3.5 h-3.5 text-violet-400" />
          </div>
          <div>
            <div className="text-[13px] font-bold text-white">Geology Insight</div>
            <div className="text-[10px] text-white/40">AI · USGS · Topo Analysis</div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-white/40 hover:text-white hover:bg-white/8 transition-all"
         aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">

          {/* Paywall for free users */}
          {isFree && <GeologyPaywall onClose={onClose} />}

          {/* Paid content */}
          {!isFree && (
          <>

          {/* Area context pill */}
          {mapBounds && (
            <div
              className="rounded-xl px-3 py-2.5 text-[11px]"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <div className="flex items-center gap-1.5 text-white/60 mb-0.5">
                <Map className="w-3 h-3" />
                <span className="font-semibold">Analysis Area</span>
              </div>
              <div className="text-white/40">
                {mapCenter?.lat?.toFixed(3)}°N, {mapCenter?.lng?.toFixed(3)}°W
              </div>
              {nearbyMinerals.length > 0 && (
                <div className="mt-1.5 flex flex-wrap gap-1">
                  {nearbyMinerals.slice(0, 6).map((m) => (
                    <span key={m} className="text-[10px] px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400/80 border border-cyan-500/15">{m}</span>
                  ))}
                  {nearbyMinerals.length > 6 && (
                    <span className="text-[10px] text-white/30">+{nearbyMinerals.length - 6} more</span>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Analyze CTA */}
          {!report && !loading && (
            <button
              onClick={runAnalysis}
              disabled={!mapBounds}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-[13px] text-white transition-all disabled:opacity-40"
              style={{
                background: "linear-gradient(135deg, #7c3aed 0%, #4f46e5 100%)",
                boxShadow: "0 4px 24px rgba(124,58,237,0.35)",
              }}
            >
              <Zap className="w-4 h-4" />
              Analyze This Area
            </button>
          )}

          {/* Loading */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-10 gap-3">
              <div className="relative">
                <Loader2 className="w-8 h-8 text-violet-400 animate-spin" />
                <div
                  className="absolute inset-0 rounded-full animate-ping"
                  style={{ background: "rgba(139,92,246,0.2)", animationDuration: "1.5s" }}
                />
              </div>
              <div className="text-center">
                <div className="text-[12px] font-semibold text-white/80">Running geological analysis…</div>
                <div className="text-[11px] text-white/35 mt-0.5">Querying USGS, topo maps & deposit records</div>
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="rounded-xl px-3 py-3 bg-red-500/10 border border-red-500/25 text-red-300 text-[12px] flex gap-2 items-start">
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <div>
                <div className="font-semibold mb-0.5">Analysis failed</div>
                <div className="opacity-70">{error}</div>
                <button onClick={runAnalysis} className="mt-2 text-red-200 hover:text-white flex items-center gap-1 text-[11px]">
                  <RefreshCw className="w-3 h-3" /> Retry
                </button>
              </div>
            </div>
          )}

          {/* Report */}
          {report && (
            <>
              {/* Overall potential banner */}
              <div
                className="rounded-xl px-4 py-3 flex items-center justify-between"
                style={{ background: potCfg.color + "14", border: `1px solid ${potCfg.color}35` }}
              >
                <div>
                  <div className="text-[11px] text-white/45 font-semibold uppercase tracking-wider mb-0.5">Overall Gem Potential</div>
                  <div className="text-[18px] font-bold" style={{ color: potCfg.color }}>{potCfg.label}</div>
                  <div className="text-[11px] text-white/40 mt-0.5">{report.geologic_province}</div>
                </div>
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center shrink-0"
                  style={{ background: potCfg.color + "22", border: `1.5px solid ${potCfg.color}55` }}
                >
                  <Gem className="w-5 h-5" style={{ color: potCfg.color }} />
                </div>
              </div>

              {/* Summary */}
              <div
                className="rounded-xl px-3 py-2.5 text-[12px] leading-relaxed text-white/65"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                {report.region_summary}
              </div>

              {/* Host rocks */}
              {report.host_rocks?.length > 0 && (
                <Section icon={Mountain} title="Host Rock Likelihoods" defaultOpen={true} accent="#06b6d4">
                  {[...report.host_rocks]
                    .sort((a, b) => b.likelihood_pct - a.likelihood_pct)
                    .map((r, i) => <HostRockCard key={i} rock={r} />)}
                </Section>
              )}

              {/* Mineral predictions */}
              {report.mineral_predictions?.length > 0 && (
                <Section icon={Gem} title="Gem-Bearing Mineral Predictions" defaultOpen={true} accent="#f59e0b">
                  {[...report.mineral_predictions]
                    .sort((a, b) => b.confidence - a.confidence)
                    .map((m, i) => <MineralCard key={i} mineral={m} />)}
                </Section>
              )}

              {/* Soil analysis */}
              {report.soil_type && (
                <Section icon={Layers} title="Soil & Surface Analysis" accent="#a78bfa">
                  <div className="space-y-1.5 text-[12px]">
                    <div className="flex gap-2">
                      <span className="text-white/40 w-16 shrink-0">Primary</span>
                      <span className="text-white/75">{report.soil_type.primary}</span>
                    </div>
                    {report.soil_type.secondary && (
                      <div className="flex gap-2">
                        <span className="text-white/40 w-16 shrink-0">Secondary</span>
                        <span className="text-white/75">{report.soil_type.secondary}</span>
                      </div>
                    )}
                    {report.soil_type.collecting_notes && (
                      <div className="mt-2 p-2 rounded-lg bg-white/4 text-white/55 text-[11px] leading-relaxed">
                        {report.soil_type.collecting_notes}
                      </div>
                    )}
                  </div>
                </Section>
              )}

              {/* Topo analysis */}
              {report.topo_analysis && (
                <Section icon={Map} title="Topographic Analysis" accent="#34d399">
                  <div className="space-y-1.5 text-[12px]">
                    <div className="flex gap-2">
                      <span className="text-white/40 w-24 shrink-0">Terrain</span>
                      <span className="text-white/75">{report.topo_analysis.terrain_type}</span>
                    </div>
                    {report.topo_analysis.drainage_potential && (
                      <div className="flex gap-2">
                        <span className="text-white/40 w-24 shrink-0">Drainage</span>
                        <span className="text-white/75">{report.topo_analysis.drainage_potential}</span>
                      </div>
                    )}
                    {report.topo_analysis.best_terrain_features?.length > 0 && (
                      <div className="mt-2">
                        <div className="text-[10px] text-white/35 uppercase tracking-wider mb-1">Best Features to Target</div>
                        {report.topo_analysis.best_terrain_features.map((f, i) => (
                          <div key={i} className="flex items-start gap-1.5 text-white/60 text-[11px] mb-1">
                            <Target className="w-3 h-3 text-emerald-400 mt-0.5 shrink-0" />
                            {f}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </Section>
              )}

              {/* Nearby districts */}
              {report.nearby_districts?.length > 0 && (
                <Section icon={Map} title="Nearby Mining Districts" accent="#f97316">
                  {report.nearby_districts.map((d, i) => (
                    <div key={i} className="flex items-start justify-between gap-2 py-2 border-b border-white/6 last:border-0 text-[12px]">
                      <div className="flex-1 min-w-0">
                        <div className="text-white/80 font-semibold truncate">{d.name}</div>
                        <div className="text-white/35 text-[11px]">{d.status} · {d.distance_mi} mi</div>
                        {d.notable_minerals?.length > 0 && (
                          <div className="text-orange-300/70 text-[11px] mt-0.5 truncate">{d.notable_minerals.join(", ")}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </Section>
              )}

              {/* Field strategies */}
              {report.field_strategies?.length > 0 && (
                <Section icon={Lightbulb} title="Collecting Strategies" defaultOpen={true} accent="#fbbf24">
                  <div className="space-y-2">
                    {report.field_strategies.map((s, i) => (
                      <div key={i} className="flex items-start gap-2 text-[12px] text-white/65">
                        <div
                          className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold"
                          style={{ background: "rgba(251,191,36,0.2)", color: "#fbbf24" }}
                        >
                          {i + 1}
                        </div>
                        <span className="leading-relaxed">{s}</span>
                      </div>
                    ))}
                  </div>
                </Section>
              )}

              {/* Hazards */}
              {report.hazards?.length > 0 && (
                <Section icon={AlertTriangle} title="Field Hazards" accent="#ef4444">
                  <div className="space-y-1.5">
                    {report.hazards.map((h, i) => (
                      <div key={i} className="flex items-start gap-2 text-[12px] text-red-300/75">
                        <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0 text-red-400" />
                        {h}
                      </div>
                    ))}
                  </div>
                </Section>
              )}

              {/* Confidence note */}
              {report.confidence_note && (
                <div className="text-[11px] text-white/30 text-center leading-relaxed px-2 pb-1">
                  {report.confidence_note}
                </div>
              )}

              {/* Re-analyze */}
              <button
                onClick={runAnalysis}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-[12px] font-semibold text-white/60 hover:text-white border border-white/10 hover:border-white/20 transition-all"
                style={{ background: "rgba(255,255,255,0.04)" }}
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Re-analyze Area
              </button>
            </>
          )}
          </>
          )} {/* end paid content */}
        </div>
      </ScrollArea>
    </div>
  );
}