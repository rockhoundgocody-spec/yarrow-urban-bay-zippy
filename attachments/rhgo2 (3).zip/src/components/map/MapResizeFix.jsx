import { useEffect } from "react";
import { useMap } from "react-leaflet";

export default function MapResizeFix() {
  const map = useMap();

  useEffect(() => {
    const refresh = () => {
      setTimeout(() => {
        map.invalidateSize();
      }, 150);
    };

    refresh();
    window.addEventListener("resize", refresh);
    window.addEventListener("orientationchange", refresh);

    return () => {
      window.removeEventListener("resize", refresh);
      window.removeEventListener("orientationchange", refresh);
    };
  }, [map]);

  return null;
}