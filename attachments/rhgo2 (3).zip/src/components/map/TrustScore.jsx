import React, { useState } from "react";
import { Shield, ChevronDown, ChevronUp, CheckCircle, Clock, Users, Database } from "lucide-react";

/**
 * Calculates a 0–100 trust score for a rockhounding location.
 *
 * Breakdown (100 pts total):
 *  - Source Authority   30 pts  (confidence_score, land_status_verified, data_sources, ownership_source)
 *  - Coordinate Quality 20 pts  (decimal precision of lat/lng)
 *  - Recency            25 pts  (last_verified date)
 *  - Community          25 pts  (rating_count, rating_avg, review_status)
 */
export function calcTrustScore(loc) {
  let authority = 0;
  let precision = 0;
  let recency = 0;
  let community = 0;

  // ── Source Authority (30 pts) ──────────────────────────────
  if (loc.confidence_score != null) {
    authority += Math.round((loc.confidence_score / 100) * 15); // 0–15
  }
  if (loc.land_status_verified) authority += 8;
  if (Array.isArray(loc.data_sources)) authority += Math.min(loc.data_sources.length, 3) * 2; // 0–6
  if (loc.ownership_source) authority += 1;
  authority = Math.min(authority, 30);

  // ── Coordinate Precision (20 pts) ─────────────────────────
  const latDecimals = (String(loc.latitude || 0).split(".")[1] || "").length;
  const lngDecimals = (String(loc.longitude || 0).split(".")[1] || "").length;
  const avgDecimals = (latDecimals + lngDecimals) / 2;
  if (avgDecimals >= 5) precision = 20;
  else if (avgDecimals >= 4) precision = 16;
  else if (avgDecimals >= 3) precision = 11;
  else if (avgDecimals >= 2) precision = 6;
  else precision = 2;

  // ── Recency (25 pts) ──────────────────────────────────────
  if (loc.last_verified) {
    const daysSince = (Date.now() - new Date(loc.last_verified).getTime()) / (1000 * 60 * 60 * 24);
    if (daysSince < 30) recency = 25;
    else if (daysSince < 90) recency = 20;
    else if (daysSince < 180) recency = 15;
    else if (daysSince < 365) recency = 10;
    else recency = 5;
  }

  // ── Community Corroboration (25 pts) ──────────────────────
  const ratingCount = loc.rating_count || 0;
  community += Math.min(ratingCount, 10) * 1.5; // 0–15
  const avgRating = loc.rating_avg || 0;
  if (avgRating >= 4) community += 5;
  else if (avgRating >= 3) community += 2;
  if (loc.review_status === "approved") community += 5;
  community = Math.min(Math.round(community), 25);

  const total = Math.min(authority + precision + recency + community, 100);

  return {
    total,
    breakdown: {
      authority: { pts: authority, max: 30, label: "Source Authority" },
      precision: { pts: precision, max: 20, label: "Coordinate Quality" },
      recency:   { pts: recency,   max: 25, label: "Verification Recency" },
      community: { pts: community, max: 25, label: "Community Corroboration" },
    },
  };
}

function getTier(score) {
  if (score >= 80) return { label: "High Trust",  color: "#22c55e", bg: "#22c55e18", border: "#22c55e40" };
  if (score >= 60) return { label: "Verified",    color: "#3b82f6", bg: "#3b82f618", border: "#3b82f640" };
  if (score >= 40) return { label: "Moderate",    color: "#f59e0b", bg: "#f59e0b18", border: "#f59e0b40" };
  if (score >= 20) return { label: "Low",         color: "#f97316", bg: "#f9731618", border: "#f9731640" };
  return               { label: "Unverified",  color: "#ef4444", bg: "#ef444418", border: "#ef444440" };
}

const BREAKDOWN_ICONS = {
  authority: Database,
  precision: CheckCircle,
  recency:   Clock,
  community: Users,
};

/** Compact badge for LocationCard */
export function TrustBadge({ location, className = "" }) {
  const { total } = calcTrustScore(location);
  const tier = getTier(total);
  return (
    <div
      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${className}`}
      style={{ background: tier.bg, borderColor: tier.border, color: tier.color }}
      title={`Trust Score: ${total}/100`}
    >
      <Shield className="w-2.5 h-2.5" />
      {total}
      <span className="font-normal opacity-75">/ 100</span>
    </div>
  );
}

/** Full panel widget for LocationDetailsPanel */
export default function TrustScore({ location }) {
  const [expanded, setExpanded] = useState(false);
  const { total, breakdown } = calcTrustScore(location);
  const tier = getTier(total);

  return (
    <div
      className="rounded-xl border overflow-hidden"
      style={{ background: tier.bg, borderColor: tier.border }}
    >
      {/* Header row */}
      <button
        onClick={() => setExpanded(v => !v)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left"
      >
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: tier.color + "22" }}
        >
          <Shield className="w-4 h-4" style={{ color: tier.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">Trust Score</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full font-bold" style={{ background: tier.color + "25", color: tier.color }}>
              {tier.label}
            </span>
          </div>
          {/* Score bar */}
          <div className="mt-1.5 flex items-center gap-2">
            <div className="flex-1 h-1.5 bg-black/8 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${total}%`, background: tier.color }}
              />
            </div>
            <span className="text-sm font-black shrink-0" style={{ color: tier.color }}>{total}<span className="text-[10px] font-normal text-gray-400">/100</span></span>
          </div>
        </div>
        {expanded
          ? <ChevronUp className="w-4 h-4 text-gray-400 shrink-0" />
          : <ChevronDown className="w-4 h-4 text-gray-400 shrink-0" />}
      </button>

      {/* Breakdown */}
      {expanded && (
        <div className="px-4 pb-4 space-y-2.5 border-t" style={{ borderColor: tier.border + "80" }}>
          <p className="text-[10px] text-gray-400 pt-3 uppercase tracking-wider font-semibold">Score Breakdown</p>
          {Object.entries(breakdown).map(([key, { pts, max, label }]) => {
            const Icon = BREAKDOWN_ICONS[key];
            const pct = Math.round((pts / max) * 100);
            return (
              <div key={key}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5 text-[11px] text-gray-600 font-medium">
                    <Icon className="w-3 h-3 text-gray-400" />
                    {label}
                  </div>
                  <span className="text-[11px] font-bold text-gray-700">{pts}<span className="text-[10px] font-normal text-gray-400">/{max}</span></span>
                </div>
                <div className="h-1 bg-black/8 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full"
                    style={{ width: `${pct}%`, background: tier.color, opacity: 0.75 }}
                  />
                </div>
              </div>
            );
          })}
          <p className="text-[10px] text-gray-400 pt-1 leading-relaxed">
            Score is calculated from source authority, GPS precision, verification recency, and community reviews.
          </p>
        </div>
      )}
    </div>
  );
}