import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { motion } from "framer-motion";
import { Sparkles, MapPin, Gem, Loader2, ChevronRight, X, Star, Navigation } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const LEGALITY_COLORS = {
  "Safe Public": "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  "Likely Legal": "bg-blue-500/15 text-blue-400 border-blue-500/30",
  "Use Caution": "bg-amber-500/15 text-amber-400 border-amber-500/30",
  "High Risk": "bg-red-500/15 text-red-400 border-red-500/30",
};

export default function SuggestionPanel({ onSelectLocation, userLat, userLng }) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [meta, setMeta] = useState(null);
  const [error, setError] = useState(null);

  const fetchSuggestions = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await base44.functions.invoke("suggestLocations", {
        latitude: userLat || null,
        longitude: userLng || null,
        radius_miles: 150,
        limit: 8,
      });
      setSuggestions(result.data?.suggestions || []);
      setMeta({ level: result.data?.user_level, collected: result.data?.total_collected });
    } catch (e) {
      setError("Couldn't load suggestions");
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchSuggestions();
  }, [userLat, userLng]);

  if (!expanded) {
    return (
      <button onClick={() => setExpanded(true)}
        className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-all hover:scale-105 active:scale-95"
        style={{
          background: "linear-gradient(120deg, rgba(255,215,0,0.12), rgba(255,102,0,0.08))",
          border: "1px solid rgba(255,215,0,0.25)",
          color: "#ffd700",
          boxShadow: "0 0 12px rgba(255,215,0,0.1)",
        }}>
        <Sparkles className="w-4 h-4" />
        For You
        {suggestions.length > 0 && (
          <span className="w-5 h-5 rounded-full bg-amber-500/30 text-[10px] font-bold flex items-center justify-center">{suggestions.length}</span>
        )}
      </button>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      className="w-80 max-h-[70vh] rounded-2xl overflow-hidden"
      style={{
        background: "linear-gradient(135deg, rgba(10,10,21,0.95), rgba(26,10,46,0.95))",
        border: "1px solid rgba(255,215,0,0.2)",
        backdropFilter: "blur(20px)",
        boxShadow: "0 0 40px rgba(0,0,0,0.6), 0 0 20px rgba(255,215,0,0.05)",
      }}
    >
      {/* Header */}
      <div className="px-4 py-3 border-b border-white/5 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" /> Suggested for You
          </h3>
          {meta && (
            <p className="text-[10px] text-white/40 mt-0.5">
              Lv{meta.level} · {meta.collected} minerals collected
            </p>
          )}
        </div>
        <button onClick={() => setExpanded(false)} className="p-1 rounded-lg text-white/30 hover:text-white/60" aria-label="Toggle">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Content */}
      <div className="overflow-y-auto max-h-[55vh] p-3 space-y-2">
        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-5 h-5 text-amber-400 animate-spin" /></div>
        ) : error ? (
          <div className="text-center py-8 text-white/40 text-xs">{error}</div>
        ) : suggestions.length === 0 ? (
          <div className="text-center py-8">
            <Star className="w-8 h-8 text-white/10 mx-auto mb-2" />
            <p className="text-white/30 text-xs">No suggestions right now. Explore more!</p>
          </div>
        ) : (
          suggestions.map((s, i) => (
            <motion.button
              key={s.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              onClick={() => { onSelectLocation?.(s); setExpanded(false); }}
              className="w-full text-left rounded-xl p-3 transition-all hover:bg-white/5 active:scale-[0.98]"
              style={{ border: "1px solid rgba(255,255,255,0.05)" }}
            >
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <MapPin className="w-4 h-4 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="font-semibold text-white text-xs truncate">{s.name}</span>
                    {s.legality_status && (
                      <Badge className={`${LEGALITY_COLORS[s.legality_status] || ""} text-[8px] px-1 py-0`}>
                        {s.legality_status}
                      </Badge>
                    )}
                  </div>
                  <p className="text-[10px] text-white/40 mt-0.5 line-clamp-1">{s.reason}</p>
                  <div className="flex items-center gap-2 mt-1">
                    {s.missing_minerals?.length > 0 && (
                      <span className="text-[9px] text-amber-400 flex items-center gap-0.5">
                        <Gem className="w-2.5 h-2.5" /> {s.missing_minerals.length} new
                      </span>
                    )}
                    {s.distance_miles && (
                      <span className="text-[9px] text-white/30 flex items-center gap-0.5">
                        <Navigation className="w-2.5 h-2.5" /> {s.distance_miles}mi
                      </span>
                    )}
                    {s.state && <span className="text-[9px] text-white/25">{s.state}</span>}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-white/20 flex-shrink-0 mt-1" />
              </div>
            </motion.button>
          ))
        )}
      </div>
    </motion.div>
  );
}