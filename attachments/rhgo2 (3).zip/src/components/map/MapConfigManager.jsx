import React, { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Save } from "lucide-react";

export default function MapConfigManager({ open, onOpenChange, currentConfig, userEmail }) {
  const [formData, setFormData] = useState({
    config_name: "",
    description: "",
  });
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: (data) => base44.entities.SavedMapConfig.create({
      ...data,
      ...currentConfig,
      created_at: new Date().toISOString(),
      last_used: new Date().toISOString(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["saved-map-configs"] });
      setFormData({ config_name: "", description: "" });
      onOpenChange(false);
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.config_name.trim()) return;
    mutation.mutate(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#14141e] border-white/10 text-white">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Save className="w-4 h-4" /> Save Map Configuration
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label className="text-xs text-white/60">Configuration Name *</Label>
            <Input
              placeholder="e.g., Crystal Hunting Setup"
              value={formData.config_name}
              onChange={(e) => setFormData({ ...formData, config_name: e.target.value })}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1"
            />
          </div>

          <div>
            <Label className="text-xs text-white/60">Description</Label>
            <Textarea
              placeholder="Optional notes about this configuration..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              maxLength={200}
              className="bg-[#0a0a0f] border-white/10 text-white mt-1 h-16 text-sm"
            />
          </div>

          <div className="bg-white/5 border border-white/10 rounded-lg p-3 text-xs text-white/60">
            <p className="font-medium mb-2">This will save:</p>
            <ul className="space-y-1 ml-2">
              <li>✓ Layer visibility settings</li>
              <li>✓ Heatmap configuration</li>
              <li>✓ Active filters</li>
              <li>✓ Map center & zoom level</li>
            </ul>
          </div>

          <div className="flex gap-2 justify-end pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-white/10 text-white/60">
              Cancel
            </Button>
            <Button type="submit" disabled={mutation.isPending || !formData.config_name.trim()} className="bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500/30 border border-cyan-500/30">
              {mutation.isPending ? <Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> : null}
              Save Configuration
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}