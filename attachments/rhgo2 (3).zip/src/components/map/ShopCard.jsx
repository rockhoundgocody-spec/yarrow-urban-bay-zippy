import React from "react";
import { Badge } from "@/components/ui/badge";
import { Store, Sparkles, Globe } from "lucide-react";
import { cn } from "@/lib/utils";

const TIER_CONFIG = {
  Basic:    { color: "text-slate-400", bg: "bg-slate-500/10 border-slate-500/20" },
  Premium:  { color: "text-cyan-400", bg: "bg-cyan-500/10 border-cyan-500/20" },
  Featured: { color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
  Elite:    { color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
};

export default function ShopCard({ shop, compact = false }) {
  if (!shop.approved) return null;

  const tierCfg = TIER_CONFIG[shop.tier];
  const avgRating = shop.community_rating_count > 0 ? shop.community_rating.toFixed(1) : "New";

  return (
    <div className={cn(
      "rounded-xl border p-3 space-y-2",
      tierCfg.bg,
      compact ? "text-xs" : "text-sm"
    )}>
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-start gap-2 min-w-0">
          <Store className={cn("shrink-0", compact ? "w-3 h-3" : "w-4 h-4")} />
          <div className="min-w-0">
            <p className="font-semibold truncate">{shop.shop_name}</p>
            {!compact && shop.address && <p className="text-white/40 text-[10px]">{shop.address}</p>}
          </div>
        </div>
        <Badge className={cn(tierCfg.color, "shrink-0", "text-[9px]")}>
          {shop.tier}
        </Badge>
      </div>

      {!compact && (
        <>
          {shop.bio && <p className="text-white/50 line-clamp-2">{shop.bio}</p>}

          {shop.specialty_minerals?.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {shop.specialty_minerals.slice(0, 3).map((m) => (
                <Badge key={m} className="text-[9px] bg-purple-500/10 text-purple-400 border-purple-500/20">
                  {m}
                </Badge>
              ))}
              {shop.specialty_minerals.length > 3 && (
                <Badge className="text-[9px] bg-white/5 text-white/40">+{shop.specialty_minerals.length - 3}</Badge>
              )}
            </div>
          )}

          <div className="flex items-center gap-3 text-[10px] text-white/40">
            {shop.community_rating > 0 && (
              <span className="flex items-center gap-1">
                ⭐ {avgRating} ({shop.community_rating_count})
              </span>
            )}
            {shop.website && (
              <a href={shop.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 hover:text-white/60">
                <Globe className="w-3 h-3" /> Visit
              </a>
            )}
            {shop.xp_bonus_multiplier > 1 && (
              <span className="flex items-center gap-1 text-amber-400">
                <Sparkles className="w-3 h-3" /> {Math.round((shop.xp_bonus_multiplier - 1) * 100)}% XP Bonus
              </span>
            )}
          </div>
        </>
      )}
    </div>
  );
}