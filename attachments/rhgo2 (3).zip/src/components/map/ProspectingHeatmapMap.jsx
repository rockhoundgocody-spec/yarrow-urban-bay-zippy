/**
 * ProspectingHeatmapMap — Geospatial mineral density + rarity heatmap.
 * Uses MapLibre GL + heatmap layer over RockhoundingLocation + SpecimenEvent data.
 * Supports density mode and rarity emphasis mode.
 */
import React, { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { Layers, Zap, BarChart3, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { escapeHtml } from "@/utils";

/**
 * Weight per site, derived only from fields that exist on RockhoundingLocation.
 *  density → every site counts equally (true site density)
 *  rarity  → AI discovery_score when present, else mineral diversity
 */
function siteWeight(loc, mode) {
  if (mode !== "rarity") return 1;
  const diversity = Array.isArray(loc.minerals_found) ? loc.minerals_found.length : 0;
  const score = typeof loc.discovery_score === "number" ? loc.discovery_score / 20 : 0;
  return Math.min(Math.max(score, diversity * 0.6, 0.4), 5);
}

function buildGeoJSON(locations, mode) {
  const features = locations
    .filter(loc => loc.latitude && loc.longitude)
    .map(loc => ({
      type: "Feature",
      geometry: { type: "Point", coordinates: [loc.longitude, loc.latitude] },
      properties: {
        weight: siteWeight(loc, mode),
        name: loc.name || "Location",
        mineral: (loc.minerals_found || []).join(", ") || "Unknown",
        zone: loc.heat_zone || "unrated",
        score: Math.round(loc.discovery_score ?? 0),
        minerals: Array.isArray(loc.minerals_found) ? loc.minerals_found.length : 0,
      },
    }));

  return { type: "FeatureCollection", features };
}

const MODE_CONFIG = {
  density: {
    label: "Site Density",
    colors: [
      "rgba(0,214,143,0)", "rgba(0,214,143,0.3)", "rgba(122,231,255,0.55)",
      "rgba(141,124,255,0.75)", "rgba(245,182,66,0.9)", "rgba(248,113,113,1)"
    ],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
  },
  rarity: {
    label: "Mineral Potential",
    colors: [
      "rgba(0,0,0,0)", "rgba(141,124,255,0.25)", "rgba(141,124,255,0.5)",
      "rgba(245,182,66,0.7)", "rgba(248,113,113,0.85)", "rgba(255,215,0,1)"
    ],
    stops: [0, 0.2, 0.4, 0.6, 0.8, 1],
  },
};

export default function ProspectingHeatmapMap() {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const resizeObserver = useRef(null);
  const [mode, setMode] = useState("density");
  const [loading, setLoading] = useState(true);
  const [locationCount, setLocationCount] = useState(0);
  const [plottedCount, setPlottedCount] = useState(0);

  const loadAndRender = async (currentMode) => {
    setLoading(true);
    const locations = await base44.entities.RockhoundingLocation.list("-created_date", 500);
    setLocationCount(locations.length);
    const geojson = buildGeoJSON(locations, currentMode);
    setPlottedCount(geojson.features.length);
    const cfg = MODE_CONFIG[currentMode];

    if (!map.current) { setLoading(false); return; }

    // Update or add source
    if (map.current.getSource("heatmap-source")) {
      map.current.getSource("heatmap-source").setData(geojson);
    } else {
      map.current.addSource("heatmap-source", { type: "geojson", data: geojson });
    }

    // Remove old layers
    ["heatmap-layer", "circle-layer"].forEach(id => {
      if (map.current.getLayer(id)) map.current.removeLayer(id);
    });

    // Heatmap layer
    map.current.addLayer({
      id: "heatmap-layer",
      type: "heatmap",
      source: "heatmap-source",
      maxzoom: 14,
      paint: {
        "heatmap-weight": ["interpolate", ["linear"], ["get", "weight"], 0, 0, 5, 1],
        "heatmap-intensity": ["interpolate", ["linear"], ["zoom"], 0, 1, 9, 3],
        "heatmap-color": [
          "interpolate", ["linear"], ["heatmap-density"],
          ...cfg.stops.flatMap((stop, i) => [stop, cfg.colors[i]])
        ],
        "heatmap-radius": ["interpolate", ["linear"], ["zoom"], 0, 24, 9, 40],
        "heatmap-opacity": 0.82,
      },
    });

    // Circle layer at high zoom
    map.current.addLayer({
      id: "circle-layer",
      type: "circle",
      source: "heatmap-source",
      minzoom: 13,
      paint: {
        "circle-radius": 8,
        "circle-color": cfg.colors[4],
        "circle-stroke-width": 1.5,
        "circle-stroke-color": "rgba(255,255,255,0.3)",
        "circle-opacity": 0.85,
      },
    });

    setLoading(false);
  };

  useEffect(() => {
    if (!mapContainer.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: "https://tiles.openfreemap.org/styles/positron",
      center: [-105, 39],
      zoom: 4,
      attributionControl: false,
    });

    map.current.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");

    map.current.on("load", () => {
      map.current?.resize();
      loadAndRender("density");
    });

    // MapLibre sizes its canvas at init; the tab panel animates in after that,
    // so track container size and resize the map to match.
    const ro = new ResizeObserver(() => map.current?.resize());
    ro.observe(mapContainer.current);
    resizeObserver.current = ro;

    // Popup on circle click
    map.current.on("click", "circle-layer", (e) => {
      const props = e.features[0]?.properties;
      if (!props) return;
      new maplibregl.Popup({ closeButton: false, className: "geo-cell-tooltip" })
        .setLngLat(e.lngLat)
        .setHTML(`
          <div style="background:#0e141b;border:1px solid rgba(0,214,143,0.3);border-radius:10px;padding:10px 12px;min-width:160px">
            <div style="font-weight:700;color:#fff;font-size:13px">${escapeHtml(props.name)}</div>
            <div style="color:#00D68F;font-size:11px;margin-top:2px">${escapeHtml(props.mineral)}</div>
            <div style="color:rgba(255,255,255,0.4);font-size:10px;margin-top:4px">Zone: ${escapeHtml(props.zone)} · ${escapeHtml(props.minerals)} minerals</div>
          </div>
        `)
        .addTo(map.current);
    });

    map.current.on("mouseenter", "circle-layer", () => {
      map.current.getCanvas().style.cursor = "pointer";
    });
    map.current.on("mouseleave", "circle-layer", () => {
      map.current.getCanvas().style.cursor = "";
    });

    return () => {
      resizeObserver.current?.disconnect();
      resizeObserver.current = null;
      map.current?.remove();
      map.current = null;
    };
  }, []);

  // Re-render on mode change only (initial render is driven by the load handler)
  const firstRun = useRef(true);
  useEffect(() => {
    if (firstRun.current) { firstRun.current = false; return; }
    if (!map.current) return;
    if (map.current.loaded()) loadAndRender(mode);
    else map.current.once("load", () => loadAndRender(mode));
  }, [mode]);

  const cfg = MODE_CONFIG[mode];

  return (
    <div className="absolute inset-0 flex flex-col">
      {/* Controls */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
        <div className="flex items-center gap-1 rounded-2xl p-1"
          style={{ background: "rgba(8,11,16,0.9)", border: "1px solid rgba(255,255,255,0.08)", backdropFilter: "blur(12px)" }}>
          {Object.entries(MODE_CONFIG).map(([key, val]) => {
            const isActive = mode === key;
            const Icon = key === "density" ? BarChart3 : Zap;
            return (
              <button
                key={key}
                onClick={() => setMode(key)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all"
                style={{
                  background: isActive ? "rgba(0,214,143,0.15)" : "transparent",
                  border: isActive ? "1px solid rgba(0,214,143,0.35)" : "1px solid transparent",
                  color: isActive ? "#00D68F" : "rgba(255,255,255,0.35)",
                }}>
                <Icon style={{ width: 13, height: 13 }} />
                {key === "density" ? "Density" : "Potential"}
              </button>
            );
          })}
        </div>

        {/* Legend */}
        <div className="rounded-2xl px-3 py-2.5"
          style={{ background: "rgba(8,11,16,0.88)", border: "1px solid rgba(255,255,255,0.07)", backdropFilter: "blur(12px)" }}>
          <div className="flex items-center gap-1.5 mb-2">
            <Layers style={{ width: 11, height: 11, color: "#00D68F" }} />
            <span className="text-[10px] font-bold text-white/60 uppercase tracking-widest">{cfg.label}</span>
          </div>
          <div className="h-2 rounded-full w-28" style={{
            background: `linear-gradient(90deg, ${cfg.colors[1]}, ${cfg.colors[3]}, ${cfg.colors[5]})`
          }} />
          <div className="flex justify-between mt-1">
            <span className="text-[9px] text-white/30">Low</span>
            <span className="text-[9px] text-white/30">High</span>
          </div>
          {!loading && (
            <div className="text-[9px] mt-1.5 text-white/35">{plottedCount} sites plotted</div>
          )}
        </div>
      </div>

      {/* Empty state — no mappable sites */}
      {!loading && plottedCount === 0 && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 px-8 text-center">
          <Layers style={{ width: 26, height: 26, color: "rgba(255,255,255,0.15)" }} />
          <span className="text-sm text-white/45">No mapped sites yet</span>
          <span className="text-xs text-white/25">Sites with coordinates will appear on this heatmap.</span>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3"
          style={{ background: "rgba(8,11,16,0.75)", backdropFilter: "blur(8px)" }}>
          <Loader2 style={{ width: 28, height: 28, color: "#00D68F" }} className="animate-spin" />
          <span className="text-sm text-white/50">Loading {locationCount > 0 ? locationCount + " locations" : "heatmap"}…</span>
        </div>
      )}

      {/* Map — position/inset set inline: maplibre-gl.css forces
          `.maplibregl-map { position: relative }`, which beats the Tailwind
          `absolute` class and collapses the container to zero height. */}
      <div ref={mapContainer} style={{ position: "absolute", inset: 0 }} />
    </div>
  );
}