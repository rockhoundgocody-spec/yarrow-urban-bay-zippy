import React, { useState, useEffect } from "react";
import { Bell, Gem, MapPin, Sliders } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const STORAGE_KEY = "rh_proximity_config";

const DEFAULT_CONFIG = {
  enabled: true,
  radius_m: 500,
  notify_favorites_only: false,
  favorite_minerals: [],
  notify_types: ["all"], // "all" or array of site_types
};

export function loadProximityConfig() {
  try {
    return { ...DEFAULT_CONFIG, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") };
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveProximityConfig(config) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
}

const RADIUS_OPTIONS = [
  { label: "250 m", value: 250 },
  { label: "500 m", value: 500 },
  { label: "1 km", value: 1000 },
  { label: "2 km", value: 2000 },
  { label: "5 km", value: 5000 },
];

const SITE_TYPES = ["public_land", "mine", "quarry", "beach", "riverbed", "desert", "mountain", "roadcut", "fee_dig"];

const COMMON_MINERALS = ["Quartz", "Amethyst", "Pyrite", "Garnet", "Tourmaline", "Agate", "Jasper", "Gold", "Obsidian", "Calcite", "Fluorite", "Selenite"];

export default function ProximityAlertConfig({ open, onOpenChange, allMinerals = [] }) {
  const [config, setConfig] = useState(loadProximityConfig);
  const [mineralInput, setMineralInput] = useState("");

  useEffect(() => {
    if (open) setConfig(loadProximityConfig());
  }, [open]);

  const handleSave = () => {
    saveProximityConfig(config);
    onOpenChange(false);
    // Dispatch event so ProximityAlertBanner can re-read config
    window.dispatchEvent(new CustomEvent("proximityConfigUpdated", { detail: config }));
  };

  const toggleMineral = (m) => {
    setConfig(c => ({
      ...c,
      favorite_minerals: c.favorite_minerals.includes(m)
        ? c.favorite_minerals.filter(x => x !== m)
        : [...c.favorite_minerals, m]
    }));
  };

  const addCustomMineral = () => {
    const m = mineralInput.trim();
    if (!m || config.favorite_minerals.includes(m)) return;
    setConfig(c => ({ ...c, favorite_minerals: [...c.favorite_minerals, m] }));
    setMineralInput("");
  };

  const displayMinerals = [...new Set([...COMMON_MINERALS, ...(allMinerals || [])])].slice(0, 30);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#0e0e1a] border-white/10 text-white max-w-md max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-amber-400" /> Proximity Alert Settings
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          {/* Enable toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/8">
            <div>
              <p className="text-sm font-semibold text-white">Field Alerts</p>
              <p className="text-xs text-white/40">Get notified when approaching rockhounding sites</p>
            </div>
            <button
              onClick={() => setConfig(c => ({ ...c, enabled: !c.enabled }))}
              className={`w-12 h-6 rounded-full transition-all relative ${config.enabled ? "bg-amber-500" : "bg-white/10"}`}
             aria-label="Close">
              <div className={`w-5 h-5 rounded-full bg-white absolute top-0.5 transition-all ${config.enabled ? "left-6" : "left-0.5"}`} />
            </button>
          </div>

          {/* Radius */}
          <div>
            <label className="text-xs font-bold text-white/40 uppercase tracking-wider block mb-2">
              <Sliders className="w-3 h-3 inline mr-1" /> Alert Radius
            </label>
            <div className="flex flex-wrap gap-2">
              {RADIUS_OPTIONS.map(({ label, value }) => (
                <button
                  key={value}
                  onClick={() => setConfig(c => ({ ...c, radius_m: value }))}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    config.radius_m === value
                      ? "bg-amber-500/20 border-amber-500/40 text-amber-400"
                      : "bg-white/5 border-white/10 text-white/40 hover:border-white/20"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Mineral filter */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-white/40 uppercase tracking-wider">
                <Gem className="w-3 h-3 inline mr-1" /> Mineral Filter
              </label>
              <button
                onClick={() => setConfig(c => ({ ...c, notify_favorites_only: !c.notify_favorites_only }))}
                className={`text-[10px] px-2.5 py-1 rounded-full border transition-all ${
                  config.notify_favorites_only
                    ? "bg-purple-500/20 border-purple-500/40 text-purple-400"
                    : "bg-white/5 border-white/10 text-white/30"
                }`}
              >
                {config.notify_favorites_only ? "Favorites only" : "All minerals"}
              </button>
            </div>
            {config.notify_favorites_only && (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1.5">
                  {displayMinerals.map((m) => (
                    <button
                      key={m}
                      onClick={() => toggleMineral(m)}
                      className={`text-[10px] px-2 py-1 rounded-full border transition-all ${
                        config.favorite_minerals.includes(m)
                          ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                          : "bg-white/5 border-white/10 text-white/30 hover:border-white/25"
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
                <div className="flex gap-2">
                  <input
                    className="flex-1 px-3 py-1.5 text-xs rounded-lg bg-white/5 border border-white/10 text-white outline-none focus:border-amber-500/40 placeholder-white/20"
                    placeholder="Add custom mineral..."
                    value={mineralInput}
                    onChange={(e) => setMineralInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && addCustomMineral()}
                  />
                  <Button size="sm" onClick={addCustomMineral} className="bg-white/5 border border-white/10 text-white/50 text-xs">Add</Button>
                </div>
              </div>
            )}
          </div>

          {/* Site type filter */}
          <div>
            <label className="text-xs font-bold text-white/40 uppercase tracking-wider block mb-2">
              <MapPin className="w-3 h-3 inline mr-1" /> Location Types
            </label>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setConfig(c => ({ ...c, notify_types: ["all"] }))}
                className={`text-[10px] px-2.5 py-1 rounded-full border transition-all ${
                  config.notify_types[0] === "all"
                    ? "bg-cyan-500/20 border-cyan-500/40 text-cyan-400"
                    : "bg-white/5 border-white/10 text-white/30"
                }`}
              >
                All Types
              </button>
              {SITE_TYPES.map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setConfig(c => {
                      const cur = c.notify_types[0] === "all" ? [] : [...c.notify_types];
                      return { ...c, notify_types: cur.includes(t) ? cur.filter(x => x !== t) : [...cur, t] };
                    });
                  }}
                  className={`text-[10px] px-2.5 py-1 rounded-full border transition-all ${
                    config.notify_types[0] !== "all" && config.notify_types.includes(t)
                      ? "bg-cyan-500/20 border-cyan-500/40 text-cyan-400"
                      : "bg-white/5 border-white/10 text-white/30 hover:border-white/25"
                  }`}
                >
                  {t.replace("_", " ")}
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button variant="ghost" className="flex-1 text-white/40" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button className="flex-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-400" onClick={handleSave}>
              Save Settings
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}