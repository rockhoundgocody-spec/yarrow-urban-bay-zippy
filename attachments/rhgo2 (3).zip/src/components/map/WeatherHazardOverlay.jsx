/**
 * WeatherHazardOverlay — Real-time weather + safety hazard panel for Field Map.
 * Uses Open-Meteo (free, no key) for weather data and NWS API for US alerts.
 * Shows wind speed, precipitation, flash flood risk, and active safety alerts.
 */
import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  CloudRain, Wind, AlertTriangle, ShieldCheck, RefreshCw,
  Navigation, Thermometer, Droplets, Zap, CloudLightning, Eye
} from "lucide-react";
import { useUserLocation } from "@/hooks/useUserLocation";

const RISK_LEVELS = {
  extreme: { color: "#FF2244", label: "EXTREME", bg: "rgba(255,34,68,0.15)", border: "rgba(255,34,68,0.4)" },
  high:    { color: "#FF6633", label: "HIGH",    bg: "rgba(255,102,51,0.12)", border: "rgba(255,102,51,0.35)" },
  moderate:{ color: "#F5B642", label: "MODERATE",bg: "rgba(245,182,66,0.10)", border: "rgba(245,182,66,0.30)" },
  low:     { color: "#00D68F", label: "LOW",     bg: "rgba(0,214,143,0.08)",  border: "rgba(0,214,143,0.25)" },
  unknown: { color: "#94a3b8", label: "UNKNOWN", bg: "rgba(148,163,184,0.08)", border: "rgba(148,163,184,0.2)" },
};

function calcFloodRisk(precipMm, windKph) {
  if (precipMm > 25 || (precipMm > 15 && windKph > 40)) return "extreme";
  if (precipMm > 15 || (precipMm > 8 && windKph > 30)) return "high";
  if (precipMm > 5) return "moderate";
  if (precipMm > 0) return "low";
  return "low";
}

function RiskBadge({ level }) {
  const cfg = RISK_LEVELS[level] || RISK_LEVELS.unknown;
  return (
    <span className="text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-widest"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.color }}>
      {cfg.label}
    </span>
  );
}

function StatCard({ icon: Icon, label, value, unit, color = "#7AE7FF" }) {
  return (
    <div className="rounded-2xl p-3 flex flex-col gap-1"
      style={{ background: `${color}0A`, border: `1px solid ${color}20` }}>
      <div className="flex items-center gap-1.5">
        <Icon style={{ width: 13, height: 13, color }} />
        <span className="text-[9px] font-bold uppercase tracking-widest" style={{ color: `${color}80` }}>{label}</span>
      </div>
      <div className="flex items-end gap-1">
        <span className="text-xl font-black" style={{ color }}>{value ?? "—"}</span>
        {unit && <span className="text-[10px] mb-0.5" style={{ color: `${color}60` }}>{unit}</span>}
      </div>
    </div>
  );
}

function AlertCard({ alert }) {
  const severity = alert.properties?.severity?.toLowerCase() || "unknown";
  const level = severity === "extreme" ? "extreme" : severity === "severe" ? "high" : severity === "moderate" ? "moderate" : "low";
  const cfg = RISK_LEVELS[level];
  const event = alert.properties?.event || "Weather Alert";
  const headline = alert.properties?.headline || "";
  const desc = alert.properties?.description?.slice(0, 220) || "";

  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-4"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>
      <div className="flex items-start justify-between gap-2 mb-1.5">
        <div className="flex items-center gap-2">
          <AlertTriangle style={{ width: 14, height: 14, color: cfg.color, flexShrink: 0 }} />
          <span className="text-sm font-bold" style={{ color: cfg.color }}>{event}</span>
        </div>
        <RiskBadge level={level} />
      </div>
      {headline && <p className="text-xs text-white/60 leading-relaxed mb-1">{headline}</p>}
      {desc && <p className="text-[10px] text-white/35 leading-relaxed line-clamp-3">{desc}</p>}
    </motion.div>
  );
}

/**
 * Sub-components for WeatherHazardOverlay
 */

function WeatherHeader({ loading, coords, onRefresh }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center"
          style={{ background: "rgba(0,214,143,0.12)", border: "1px solid rgba(0,214,143,0.25)" }}>
          <CloudLightning style={{ width: 16, height: 16, color: "#00D68F" }} />
        </div>
        <div>
          <h2 className="text-base font-black text-white tracking-tight">Weather & Safety</h2>
          <p className="text-[10px] text-white/30">Real-time field hazard assessment</p>
        </div>
      </div>
      <button onClick={() => coords && onRefresh(coords.lat, coords.lng)}
        disabled={loading || !coords}
        className="w-8 h-8 flex items-center justify-center rounded-xl transition-all disabled:opacity-30"
        style={{ background: "rgba(0,214,143,0.1)", border: "1px solid rgba(0,214,143,0.2)" }} aria-label="Refresh">
        <RefreshCw style={{ width: 14, height: 14, color: "#00D68F" }}
          className={loading ? "animate-spin" : ""} />
      </button>
    </div>
  );
}

function LocationError({ geoError, requestLocation }) {
  if (!geoError) return null;
  return (
    <div className="rounded-2xl px-4 py-4 flex items-center justify-between"
      style={{ background: "rgba(245,182,66,0.07)", border: "1px solid rgba(245,182,66,0.22)" }}>
      <div className="flex items-center gap-2">
        <Navigation style={{ width: 14, height: 14, color: "#F5B642", flexShrink: 0 }} />
        <p className="text-xs text-white/55">{geoError}</p>
      </div>
      <button onClick={requestLocation}
        className="text-xs font-bold px-3 py-1.5 rounded-xl ml-3 shrink-0"
        style={{ background: "rgba(245,182,66,0.12)", color: "#F5B642" }}>
        Retry
      </button>
    </div>
  );
}

function LoadingSkeleton({ loading, weather }) {
  if (!loading || weather) return null;
  return (
    <div className="space-y-3">
      {[80, 100, 60].map((w, i) => (
        <div key={i} className="h-14 rounded-2xl animate-pulse" style={{ background: "rgba(255,255,255,0.04)", width: `${w}%` }} />
      ))}
    </div>
  );
}

function RiskBanner({ overallCfg, displayCoords, lastUpdated, overallRisk }) {
  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-4 flex items-center justify-between"
      style={{ background: overallCfg.bg, border: `1px solid ${overallCfg.border}` }}>
      <div className="flex items-center gap-3">
        <ShieldCheck style={{ width: 22, height: 22, color: overallCfg.color }} />
        <div>
          <p className="text-sm font-black" style={{ color: overallCfg.color }}>Field Risk: {overallCfg.label}</p>
          <p className="text-[10px] text-white/40">
            {displayCoords ? `${displayCoords.lat.toFixed(2)}°N, ${Math.abs(displayCoords.lng).toFixed(2)}°${displayCoords.lng < 0 ? "W" : "E"}` : "Your location"}
            {lastUpdated ? ` · Updated ${lastUpdated.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : ""}
          </p>
        </div>
      </div>
      <RiskBadge level={overallRisk} />
    </motion.div>
  );
}

function WeatherStatGrid({ tempC, windSpeed, dailyPrecip, humidityNow, visibilityNow, dailyMaxWind }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.06 }}
      className="grid grid-cols-2 gap-2">
      {tempC !== undefined && (
        <StatCard icon={Thermometer} label="Temperature" value={Math.round(tempC * 9/5 + 32)} unit="°F" color="#F5B642" />
      )}
      <StatCard icon={Wind} label="Wind Speed" value={Math.round(windSpeed)} unit="km/h" color="#7AE7FF" />
      <StatCard icon={Droplets} label="Precip Today" value={dailyPrecip.toFixed(1)} unit="mm" color="#60a5fa" />
      {humidityNow !== undefined && (
        <StatCard icon={CloudRain} label="Humidity" value={humidityNow} unit="%" color="#818cf8" />
      )}
      {visibilityNow !== undefined && (
        <StatCard icon={Eye} label="Visibility" value={(visibilityNow / 1000).toFixed(1)} unit="km" color="#94a3b8" />
      )}
      <StatCard icon={Zap} label="Max Wind" value={Math.round(dailyMaxWind)} unit="km/h" color="#f472b6" />
    </motion.div>
  );
}

function FloodRiskCard({ floodCfg, floodRisk, windSpeed, dailyMaxWind }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
      className="rounded-2xl p-4"
      style={{ background: floodCfg.bg, border: `1px solid ${floodCfg.border}` }}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <CloudRain style={{ width: 16, height: 16, color: floodCfg.color }} />
          <span className="text-sm font-bold" style={{ color: floodCfg.color }}>Flash Flood Risk</span>
        </div>
        <RiskBadge level={floodRisk} />
      </div>
      <p className="text-xs text-white/45 leading-relaxed">
        {floodRisk === "extreme" && "Dangerous flash flood potential. Do NOT enter canyons or dry washes. Evacuate low ground immediately."}
        {floodRisk === "high" && "Elevated flood risk for desert washes and canyon floors. Avoid low terrain and monitor water levels."}
        {floodRisk === "moderate" && "Moderate precipitation expected. Be cautious near dry washes, arroyos, and canyon bottoms."}
        {floodRisk === "low" && "Low current flood risk. Standard field precautions apply. Monitor skies for upstream storms."}
      </p>
      {(windSpeed > 40 || dailyMaxWind > 50) && (
        <p className="text-[10px] mt-2 font-semibold" style={{ color: "#F5B642" }}>
          ⚠ High wind advisory — loose specimens, equipment, and debris hazard.
        </p>
      )}
    </motion.div>
  );
}

function FieldSafetyTips({ windSpeed, dailyPrecip, tempC }) {
  return (
    <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.14 }}
      className="rounded-2xl px-4 py-3 space-y-2"
      style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <p className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-1">Field Safety Tips</p>
      {windSpeed > 35 && <p className="text-xs text-white/50">• Secure equipment — high winds may move tools and lightweight specimens.</p>}
      {dailyPrecip > 5 && <p className="text-xs text-white/50">• Wet rocks become slippery — wear boots with ankle support.</p>}
      {dailyPrecip === 0 && tempC > 35 && <p className="text-xs text-white/50">• Hot and dry — carry 3L+ water, seek shade during midday.</p>}
      {tempC < 5 && <p className="text-xs text-white/50">• Cold conditions — layer up and watch for icy surfaces on outcrops.</p>}
      <p className="text-xs text-white/35">• Always notify someone of your field location and expected return.</p>
      <p className="text-xs text-white/35">• Keep an eye on distant storms — lightning travels far ahead of rain.</p>
    </motion.div>
  );
}

function ActiveAlertsSection({ alerts }) {
  return (
    <>
      {alerts.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.18 }}
          className="space-y-2">
          <p className="text-[10px] font-bold uppercase tracking-widest text-white/30">
            Active Alerts ({alerts.length})
          </p>
          {alerts.slice(0, 5).map((a, i) => <AlertCard key={i} alert={a} />)}
        </motion.div>
      )}

      {alerts.length === 0 && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.18 }}
          className="rounded-2xl px-4 py-3 flex items-center gap-3"
          style={{ background: "rgba(0,214,143,0.06)", border: "1px solid rgba(0,214,143,0.2)" }}>
          <ShieldCheck style={{ width: 16, height: 16, color: "#00D68F" }} />
          <p className="text-xs text-white/50">No active NWS alerts for this location.</p>
        </motion.div>
      )}
    </>
  );
}

export default function WeatherHazardOverlay() {
  const { coords, displayCoords, loading: geoLoading, error: geoError, requestLocation } = useUserLocation();
  const [weather, setWeather] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchWeather = useCallback(async (lat, lng) => {
    setLoading(true);
    try {
      const [weatherRes, alertsRes] = await Promise.allSettled([
        fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}` +
          `&current_weather=true&hourly=precipitation,windspeed_10m,relativehumidity_2m,visibility` +
          `&daily=precipitation_sum,windspeed_10m_max,weathercode&timezone=auto&forecast_days=1`
        ).then(r => r.json()),
        fetch(`https://api.weather.gov/alerts/active?point=${lat.toFixed(4)},${lng.toFixed(4)}`)
          .then(r => r.json()).catch(() => ({ features: [] })),
      ]);

      if (weatherRes.status === "fulfilled") {
        setWeather(weatherRes.value);
        setLastUpdated(new Date());
      }
      if (alertsRes.status === "fulfilled") {
        setAlerts(alertsRes.value.features || []);
      }
    } catch (err) {
      console.error("Weather fetch failed:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch weather when GPS coords resolve
  useEffect(() => {
    if (coords) fetchWeather(coords.lat, coords.lng);
  }, [coords, fetchWeather]);

  const cw = weather?.current_weather;
  const hourlyIdx = 0; // current hour
  const humidityNow = weather?.hourly?.relativehumidity_2m?.[hourlyIdx];
  const visibilityNow = weather?.hourly?.visibility?.[hourlyIdx];
  const dailyPrecip = weather?.daily?.precipitation_sum?.[0] ?? 0;
  const dailyMaxWind = weather?.daily?.windspeed_10m_max?.[0] ?? 0;
  const windSpeed = cw?.windspeed ?? 0;
  const tempC = cw?.temperature;
  const floodRisk = calcFloodRisk(dailyPrecip, dailyMaxWind);
  const floodCfg = RISK_LEVELS[floodRisk];

  // Field-safe overall risk
  const overallRisk = alerts.some(a => ["Extreme", "Severe"].includes(a.properties?.severity))
    ? "extreme"
    : alerts.length > 0 ? "high"
    : floodRisk === "extreme" || (windSpeed > 50)
    ? "high"
    : floodRisk === "high" ? "moderate"
    : "low";
  const overallCfg = RISK_LEVELS[overallRisk];

  return (
    <div className="absolute inset-0 overflow-y-auto"
      style={{ background: "linear-gradient(160deg,#050A0F 0%,#060D10 100%)" }}>
      <div className="max-w-lg mx-auto px-4 pt-4 pb-8 space-y-4">
        <WeatherHeader loading={loading || geoLoading} coords={coords} onRefresh={fetchWeather} />
        <LocationError geoError={geoError} requestLocation={requestLocation} />
        <LoadingSkeleton loading={loading || geoLoading} weather={weather} />

        {weather && (
          <AnimatePresence>
            <RiskBanner overallCfg={overallCfg} displayCoords={displayCoords} lastUpdated={lastUpdated} overallRisk={overallRisk} />
            <WeatherStatGrid
              tempC={tempC}
              windSpeed={windSpeed}
              dailyPrecip={dailyPrecip}
              humidityNow={humidityNow}
              visibilityNow={visibilityNow}
              dailyMaxWind={dailyMaxWind}
            />
            <FloodRiskCard floodCfg={floodCfg} floodRisk={floodRisk} windSpeed={windSpeed} dailyMaxWind={dailyMaxWind} />
            <FieldSafetyTips windSpeed={windSpeed} dailyPrecip={dailyPrecip} tempC={tempC} />
            <ActiveAlertsSection alerts={alerts} />
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}