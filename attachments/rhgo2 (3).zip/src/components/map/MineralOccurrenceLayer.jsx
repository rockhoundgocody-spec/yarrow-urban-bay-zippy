import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { escapeHtml } from "@/utils";

const MINERAL_COLORS = {
  quartz: "#a855f7", amethyst: "#9333ea", pyrite: "#fbbf24",
  gold: "#f59e0b", obsidian: "#374151", tourmaline: "#06b6d4",
  garnet: "#dc2626", agate: "#f97316", jasper: "#ea580c",
};

function getMineralColor(mineral) {
  const key = mineral?.toLowerCase().trim();
  return MINERAL_COLORS[key] || "#6366f1";
}

/**
 * mode: "occurrences" (default) — show per-mineral dots
 *       "density"     — color-code cells by mineral count (high density = gold)
 *       "unexplored"  — dim collected locations, highlight uncollected (no LocationLog)
 */
const EMPTY_SET = new Set();

export default function MineralOccurrenceLayer({ locations, visible, mode = "occurrences", visitedLocationIds = EMPTY_SET }) {
  const map = useMap();

  const layerRef = useRef(null);

  useEffect(() => {
    if (!layerRef.current) layerRef.current = L.layerGroup().addTo(map);
    const group = layerRef.current;
    group.clearLayers();

    if (!visible || !locations?.length) return;

    if (mode === "density") {
      // Grid-based density: count minerals per 0.5° cell
      const cells = {};
      locations.forEach(loc => {
        if (!loc.latitude || !loc.longitude) return;
        const key = `${Math.floor(loc.latitude * 2) / 2},${Math.floor(loc.longitude * 2) / 2}`;
        cells[key] = (cells[key] || 0) + (loc.minerals_found?.length || 1);
      });
      const maxCount = Math.max(...Object.values(cells), 1);
      Object.entries(cells).forEach(([key, count]) => {
        const [lat, lng] = key.split(",").map(Number);
        const ratio = count / maxCount;
        const fillColor = ratio > 0.7 ? "#f5c842" : ratio > 0.4 ? "#7aff3c" : "#00ccff";
        L.rectangle([[lat, lng], [lat + 0.5, lng + 0.5]], {
          color: fillColor, fillColor, fillOpacity: 0.12 + ratio * 0.2, weight: 0.5, opacity: 0.4,
        }).bindTooltip(`${count} mineral types in cell`, { className: "geo-heatmap-tooltip", direction: "top" }).addTo(group);
      });
      return;
    }

    if (mode === "unexplored") {
      // Show uncollected (not in visitedLocationIds) as bright pins, collected as dim
      locations.forEach(loc => {
        if (!loc.latitude || !loc.longitude) return;
        const visited = visitedLocationIds.has(loc.id);
        L.circleMarker([loc.latitude, loc.longitude], {
          radius: visited ? 4 : 8,
          fillColor: visited ? "#6b7280" : "#00ff88",
          fillOpacity: visited ? 0.3 : 0.75,
          color: visited ? "#374151" : "#00cc6a",
          weight: visited ? 0.5 : 1.5,
        }).bindTooltip(`${visited ? "✓ Visited" : "🔍 Unexplored"}: ${escapeHtml(loc.name)}`, { className: "geo-heatmap-tooltip", direction: "top" }).addTo(group);
      });
      return;
    }

    // Default: per-mineral occurrence dots
    locations.forEach(loc => {
      const minerals = loc.minerals_found || [];
      if (!minerals.length || !loc.latitude || !loc.longitude) return;
      minerals.forEach((mineral, i) => {
        const offset = i * 0.0003;
        L.circleMarker([loc.latitude + offset, loc.longitude + offset], {
          radius: 6, fillColor: getMineralColor(mineral),
          fillOpacity: 0.7, color: "#fff", weight: 1,
        }).bindTooltip(`${escapeHtml(mineral)} — ${escapeHtml(loc.name || "Unknown")}`, { className: "geo-heatmap-tooltip", direction: "top" }).addTo(group);
      });
    });

    return () => group.clearLayers();
  }, [locations, visible, mode, visitedLocationIds, map]);

  useEffect(() => {
    return () => { if (layerRef.current) { layerRef.current.clearLayers(); map.removeLayer(layerRef.current); layerRef.current = null; } };
  }, []);

  return null;
}