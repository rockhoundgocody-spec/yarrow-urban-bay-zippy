import { useEffect } from "react";
import { useMap } from "react-leaflet";

/**
 * Topographic heatmap overlay using location density as a proxy.
 * Uses leaflet.heat to render a density heatmap of all locations.
 */
export default function TopoHeatmapLayer({ locations, visible }) {
  const map = useMap();

  useEffect(() => {
    if (!visible || !locations?.length) return;
    if (!window.L?.heatLayer) return; // leaflet.heat not loaded

    const points = locations
      .filter(l => l.latitude && l.longitude)
      .map(l => [l.latitude, l.longitude, 0.6]);

    const heat = window.L.heatLayer(points, {
      radius: 30,
      blur: 20,
      maxZoom: 14,
      gradient: {
        0.1: "#313695",
        0.3: "#4575b4",
        0.5: "#74add1",
        0.65: "#fee090",
        0.8: "#f46d43",
        1.0: "#a50026",
      },
    }).addTo(map);

    return () => heat.remove();
  }, [locations, visible, map]);

  return null;
}