/**
 * GISLayerPanel
 * Slide-in panel for toggling GIS overlay sub-layers with legend, data attribution,
 * and hunt-potential summary.
 */
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Layers, ChevronDown, ChevronUp, ExternalLink, AlertTriangle, Gem, Skull, Mountain, Zap } from "lucide-react";

const LAYERS = [
  {
    id: "rockTypesVisible",
    label: "Rock Formations",
    desc: "Geologic map polygons and column lithology (Macrostrat)",
    icon: Mountain,
    color: "#a78bfa",
    legend: [
      { color: "#FFF176", label: "Quaternary < 2.6 Ma" },
      { color: "#9ACD64", label: "Cretaceous 66–145 Ma" },
      { color: "#7ECBB0", label: "Jurassic 145–201 Ma" },
      { color: "#B2D9A5", label: "Triassic 201–252 Ma" },
      { color: "#E4A0A0", label: "Permian 252–299 Ma" },
      { color: "#a78bfa", label: "Precambrian > 541 Ma" },
    ],
    source: { label: "Macrostrat", url: "https://macrostrat.org" },
  },
  {
    id: "faultLinesVisible",
    label: "Fault Lines",
    desc: "USGS Quaternary Faults & Folds — active tectonic features",
    icon: Zap,
    color: "#ef4444",
    legend: [
      { color: "#ef4444", label: "Fault / fold trace (dashed)" },
    ],
    source: { label: "USGS Hazards", url: "https://earthquake.usgs.gov/hazards/qfaults/" },
    warning: "Fault zones can indicate unstable ground. Always research access before visiting.",
  },
  {
    id: "fossilsVisible",
    label: "Fossil Record Density",
    desc: "Paleobiology Database — fossil occurrence heatmap by location",
    icon: Skull,
    color: "#d4a843",
    legend: [
      { color: "#d4a843", label: "Low density" },
      { color: "#e67e22", label: "Moderate density" },
      { color: "#c0392b", label: "High density" },
      { color: "#8e44ad", label: "Very high density" },
    ],
    source: { label: "Paleobiology DB", url: "https://paleobiodb.org" },
  },
  {
    id: "mineralsVisible",
    label: "Mineral Potential",
    desc: "AI-composite layer: land type × rock age × community finds",
    icon: Gem,
    color: "#00D68F",
    legend: [
      { color: "#00D68F", label: "High potential zone" },
      { color: "#7AE7FF", label: "Moderate potential" },
      { color: "#334155", label: "Low / surveyed" },
    ],
    source: null,
  },
];

function LayerRow({ layer, enabled, onToggle }) {
  const [open, setOpen] = useState(false);
  const Icon = layer.icon;
  return (
    <div className="rounded-xl overflow-hidden"
      style={{ background: enabled ? `${layer.color}0D` : "rgba(255,255,255,0.03)", border: `1px solid ${enabled ? layer.color + "40" : "rgba(255,255,255,0.07)"}` }}>
      <div className="flex items-center gap-3 px-3 py-3">
        <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
          style={{ background: `${layer.color}20`, border: `1px solid ${layer.color}30` }}>
          <Icon className="w-4 h-4" style={{ color: layer.color }} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-white">{layer.label}</p>
          <p className="text-[10px] text-white/35 truncate">{layer.desc}</p>
        </div>
        <button
          onClick={onToggle}
          className="w-10 h-6 rounded-full relative transition-all shrink-0"
          style={{ background: enabled ? layer.color : "rgba(255,255,255,0.1)" }} aria-label="Toggle">
          <span className="absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all"
            style={{ left: enabled ? "calc(100% - 18px)" : "2px" }} />
        </button>
        <button onClick={() => setOpen(v => !v)} className="p-1 shrink-0 text-white/30 hover:text-white/60 transition-all">
          {open ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
            <div className="px-3 pt-3 pb-3 space-y-2.5">
              {/* Legend swatches */}
              <div className="space-y-1.5">
                {layer.legend.map((item, i) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="w-3 h-3 rounded-sm shrink-0" style={{ background: item.color }} />
                    <span className="text-[11px] text-white/50">{item.label}</span>
                  </div>
                ))}
              </div>
              {/* Warning */}
              {layer.warning && (
                <div className="flex items-start gap-2 px-2 py-2 rounded-lg"
                  style={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.2)" }}>
                  <AlertTriangle className="w-3 h-3 mt-0.5 shrink-0" style={{ color: "#fca5a5" }} />
                  <p className="text-[10px] leading-snug" style={{ color: "rgba(252,165,165,0.8)" }}>{layer.warning}</p>
                </div>
              )}
              {/* Source attribution */}
              {layer.source && (
                <a href={layer.source.url} target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[10px] font-semibold transition-all"
                  style={{ color: "rgba(122,231,255,0.6)" }}>
                  <ExternalLink className="w-3 h-3" /> Data: {layer.source.label}
                </a>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function GISLayerPanel({ open, onClose, states, onToggle }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 24 }}
          transition={{ duration: 0.2 }}
          className="absolute top-14 right-3 z-30 w-72 rounded-2xl shadow-2xl overflow-hidden"
          style={{ background: "rgba(8,11,18,0.97)", border: "1px solid rgba(255,255,255,0.09)", backdropFilter: "blur(20px)" }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4" style={{ color: "#00D68F" }} />
              <span className="text-sm font-bold text-white">GIS Overlays</span>
            </div>
            <button onClick={onClose} className="text-white/30 hover:text-white/70 text-xs font-semibold transition-all" aria-label="Close">✕</button>
          </div>

          <div className="p-3 space-y-2 max-h-[70vh] overflow-y-auto">
            {LAYERS.map(layer => (
              <LayerRow
                key={layer.id}
                layer={layer}
                enabled={!!states[layer.id]}
                onToggle={() => onToggle(layer.id)}
              />
            ))}

            {/* Data attribution footer */}
            <div className="pt-2 border-t" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
              <p className="text-[9px] text-white/20 leading-snug text-center">
                Geological data: Macrostrat · USGS · Paleobiology Database<br />
                All public-domain sources · No API key required
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}