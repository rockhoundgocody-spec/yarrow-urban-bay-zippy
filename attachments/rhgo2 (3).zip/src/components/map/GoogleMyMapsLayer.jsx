import React, { useState, useEffect, useMemo } from "react";
import { LayerGroup, CircleMarker, Popup, Tooltip } from "react-leaflet";
import { base44 } from "@/api/base44Client";

/**
 * GoogleMyMapsLayer — read-only KML overlay that renders ALL placemarks from
 * a Google My Maps source as small circle markers on the Leaflet map.
 *
 * This is separate from imported RockhoundingLocation entities: it shows the
 * full reference dataset for visual context, even locations not yet imported.
 *
 * Props:
 *   - url: Google My Maps URL (must contain mid= parameter)
 *   - visible: boolean toggle
 */
export default function GoogleMyMapsLayer({ url, visible = false }) {
  const [features, setFeatures] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!visible || !url) return;
    let cancelled = false;

    async function loadGeoJson() {
      setLoading(true);
      setError(null);
      try {
        const res = await base44.functions.invoke("getGoogleMyMapsGeoJson", { url });
        if (cancelled) return;
        if (res?.geoJson?.features) {
          setFeatures(res.geoJson.features);
        } else {
          setError(res?.error || "No features returned");
        }
      } catch (e) {
        if (!cancelled) setError(e.message || "Failed to load reference map");
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    loadGeoJson();
    return () => { cancelled = true; };
  }, [url, visible]);

  const markers = useMemo(
    () =>
      features.map((f, i) => {
        const [lon, lat] = f.geometry.coordinates;
        const { name, state, folder } = f.properties;
        return (
          <CircleMarker
            key={i}
            center={[lat, lon]}
            radius={4}
            pathOptions={{
              color: "#7AE7FF",
              fillColor: "#7AE7FF",
              fillOpacity: 0.35,
              weight: 1,
            }}
          >
            <Popup>
              <div className="text-xs max-w-48">
                <div className="font-bold text-slate-900 mb-1">{name}</div>
                {state && <div className="text-slate-600">{state}</div>}
                {folder && <div className="text-slate-400 mt-1 text-[10px]">{folder}</div>}
              </div>
            </Popup>
            <Tooltip direction="top" sticky>
              <span className="text-xs">{name}</span>
            </Tooltip>
          </CircleMarker>
        );
      }),
    [features]
  );

  if (!visible) return null;

  return (
    <>
      {loading && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full bg-slate-900/90 border border-cyan-400/30 text-cyan-300 text-xs font-medium shadow-lg">
          Loading reference map…
        </div>
      )}
      {error && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-3 py-1.5 rounded-full bg-red-900/90 border border-red-400/30 text-red-300 text-xs font-medium shadow-lg max-w-80 text-center">
          {error}
        </div>
      )}
      <LayerGroup>{markers}</LayerGroup>
    </>
  );
}