import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, SlidersHorizontal, Star } from "lucide-react";

const SITE_TYPE_OPTIONS = [
  { value: "public_land", label: "Public Land" },
  { value: "mine", label: "Mine" },
  { value: "quarry", label: "Quarry" },
  { value: "beach", label: "Beach" },
  { value: "riverbed", label: "Riverbed" },
  { value: "desert", label: "Desert" },
  { value: "mountain", label: "Mountain" },
  { value: "roadcut", label: "Roadcut" },
  { value: "fee_dig", label: "Fee Dig" },
  { value: "other", label: "Other" },
];

const DIFFICULTY_OPTIONS = [
  { value: "easy", label: "Easy" },
  { value: "moderate", label: "Moderate" },
  { value: "difficult", label: "Difficult" },
  { value: "expert", label: "Expert" },
];

const LAND_MANAGER_OPTIONS = [
  "BLM","USFS","NPS","FWS","State Park","State Land","Private","Tribal","Unknown"
];

const GEOLOGY_OPTIONS = [
  { value: "igneous", label: "Igneous" },
  { value: "sedimentary", label: "Sedimentary" },
  { value: "metamorphic", label: "Metamorphic" },
  { value: "volcanic", label: "Volcanic" },
  { value: "alluvial", label: "Alluvial" },
  { value: "karst", label: "Karst" },
];

function MultiToggle({ options, selected, onChange }) {
  const toggle = (v) => {
    if (selected.includes(v)) onChange(selected.filter(x => x !== v));
    else onChange([...selected, v]);
  };
  return (
    <div className="flex flex-wrap gap-1.5">
      {options.map(opt => {
        const v = typeof opt === "string" ? opt : opt.value;
        const label = typeof opt === "string" ? opt : opt.label;
        const active = selected.includes(v);
        return (
          <button
            key={v}
            onClick={() => toggle(v)}
            className={`px-2.5 py-1 rounded-full text-[11px] font-medium transition-all border ${
              active
                ? "bg-amber-100 text-amber-700 border-amber-300"
                : "bg-gray-50 text-gray-500 border-gray-200 hover:border-gray-300 hover:bg-gray-100"
            }`}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}

export default function FilterPanel({ filters, onChange, allMinerals }) {
  const [open, setOpen] = useState(false);
  const [mineralSearch, setMineralSearch] = useState("");
  const [activeSection, setActiveSection] = useState("basic"); // "basic" | "geology" | "minerals"

  const filteredMinerals = allMinerals.filter(m =>
    m.toLowerCase().includes(mineralSearch.toLowerCase())
  ).slice(0, 30);

  const activeCount = [
    filters.site_types.length,
    filters.difficulties.length,
    filters.minerals.length,
    filters.land_managers.length,
    (filters.geology_types || []).length,
    filters.min_rating > 1 ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  const clearAll = () => onChange({ site_types: [], difficulties: [], minerals: [], land_managers: [], geology_types: [], min_rating: 1 });

  return (
    <>
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          onClick={() => setOpen(!open)}
          className={`text-xs h-8 gap-1.5 border font-semibold ${
            activeCount > 0
              ? "bg-amber-100 text-amber-700 border-amber-300 hover:bg-amber-200"
              : "bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200"
          }`}
          variant="ghost"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          Filters
          {activeCount > 0 && (
            <span className="bg-amber-500 text-black text-[10px] rounded-full w-4 h-4 flex items-center justify-center font-bold">
              {activeCount}
            </span>
          )}
        </Button>

        {/* Active filter chips */}
        {filters.min_rating > 1 && (
          <Badge
            className="text-[10px] bg-amber-100 text-amber-700 border-amber-200 cursor-pointer gap-1 font-medium"
            onClick={() => onChange({ ...filters, min_rating: 1 })}
          >
            {filters.min_rating}+ ★ <X className="w-2.5 h-2.5" />
          </Badge>
        )}
        {filters.site_types.slice(0, 2).map(s => (
          <Badge
            key={s}
            className="text-[10px] bg-gray-100 text-gray-600 border-gray-200 cursor-pointer gap-1 hidden sm:flex font-medium"
            onClick={() => onChange({ ...filters, site_types: filters.site_types.filter(x => x !== s) })}
          >
            {s} <X className="w-2.5 h-2.5" />
          </Badge>
        ))}
        {activeCount > 0 && (
          <button onClick={clearAll} className="text-[10px] text-gray-400 hover:text-gray-600 transition-colors font-medium">
            Clear all
          </button>
        )}
      </div>

      {open && (
        <div className="absolute top-full left-0 right-0 z-30 bg-white border border-gray-200 rounded-xl shadow-2xl shadow-black/15 mt-1 max-h-[75vh] overflow-hidden flex flex-col" style={{minWidth: 320}}>
          <div className="flex items-center justify-between px-4 pt-4 pb-2 shrink-0">
            <h3 className="text-sm font-bold text-gray-800">Filter Locations</h3>
            <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-600 transition-colors" aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Section tabs */}
          <div className="flex border-b border-gray-100 shrink-0 px-2">
            {[["basic","Basic"],["geology","Geology"],["minerals","Minerals"]].map(([key,label]) => (
              <button
                key={key}
                onClick={() => setActiveSection(key)}
                className={`px-3 py-2 text-[11px] font-semibold transition-colors border-b-2 -mb-px ${
                  activeSection === key ? "border-amber-500 text-amber-600" : "border-transparent text-gray-400 hover:text-gray-600"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="overflow-y-auto flex-1 p-4 space-y-4">
            {activeSection === "basic" && (
              <>
                {/* Min Rating */}
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Min Rating</label>
                  <div className="flex gap-1">
                    {[1,2,3,4,5].map(r => (
                      <button key={r} onClick={() => onChange({ ...filters, min_rating: filters.min_rating === r ? 1 : r })} className="p-0.5" aria-label="Rate">
                        <Star className={`w-5 h-5 transition-colors ${r <= filters.min_rating ? "fill-amber-400 text-amber-400" : "text-gray-200"}`} />
                      </button>
                    ))}
                    {filters.min_rating > 1 && <span className="text-[11px] text-gray-400 self-center ml-1">{filters.min_rating}+ stars</span>}
                  </div>
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Site Type</label>
                  <MultiToggle options={SITE_TYPE_OPTIONS} selected={filters.site_types} onChange={v => onChange({ ...filters, site_types: v })} />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Difficulty</label>
                  <MultiToggle options={DIFFICULTY_OPTIONS} selected={filters.difficulties} onChange={v => onChange({ ...filters, difficulties: v })} />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Land Manager</label>
                  <MultiToggle options={LAND_MANAGER_OPTIONS} selected={filters.land_managers} onChange={v => onChange({ ...filters, land_managers: v })} />
                </div>
              </>
            )}

            {activeSection === "geology" && (
              <div>
                <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Geological Features</label>
                <p className="text-[10px] text-gray-400 mb-3 leading-relaxed">Filter locations by the underlying geological formation type.</p>
                <MultiToggle options={GEOLOGY_OPTIONS} selected={filters.geology_types || []} onChange={v => onChange({ ...filters, geology_types: v })} />
              </div>
            )}

            {activeSection === "minerals" && (
              <div>
                <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-2">Specimen Types Found</label>
                <input
                  type="text"
                  placeholder="Search minerals..."
                  value={mineralSearch}
                  onChange={e => setMineralSearch(e.target.value)}
                  className="w-full mb-2 px-3 py-2 rounded-lg bg-gray-50 border border-gray-200 text-gray-800 text-xs placeholder:text-gray-400 outline-none focus:border-amber-400 transition-colors"
                />
                <MultiToggle
                  options={filteredMinerals.map(m => ({ value: m, label: m }))}
                  selected={filters.minerals}
                  onChange={v => onChange({ ...filters, minerals: v })}
                />
                {filteredMinerals.length === 0 && (
                  <p className="text-[11px] text-gray-400 text-center py-4">No minerals match your search</p>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-between px-4 py-3 border-t border-gray-100 shrink-0">
            <button onClick={clearAll} className="text-xs text-gray-400 hover:text-gray-600 transition-colors font-medium">Clear all</button>
            <Button size="sm" onClick={() => setOpen(false)} className="bg-amber-500 hover:bg-amber-600 text-white border-0 text-xs h-7 shadow-sm">
              Done
            </Button>
          </div>
        </div>
      )}
    </>
  );
}