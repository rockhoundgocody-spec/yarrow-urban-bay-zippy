/**
 * GeoSearchMap
 * Interactive map view with geospatial location search.
 * Filters: radius from center, minerals present, legality tier/score, viewport bbox.
 * Uses react-leaflet. All filtering is client-side after a single bulk fetch.
 */
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, useMapEvents, useMap } from "react-leaflet";
import { base44 } from "@/api/base44Client";
import GeoSearchPanel from "./GeoSearchPanel";
import { Shield, Gem, Navigation } from "lucide-react";

const DEFAULT_FILTERS = {
  radius: 50,        // miles
  minerals: [],
  legalityTiers: [],
  legalityMin: 0,
  bbox: null,        // { north, south, east, west }
};

const LEGALITY_COLOR = {
  "Safe Public":  "#00D68F",
  "Likely Legal": "#7AE7FF",
  "Use Caution":  "#F5B642",
  "High Risk":    "#ef4444",
  "unknown":      "#6E7681",
};

function toRad(deg) { return deg * Math.PI / 180; }
function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
const KM_PER_MILE = 1.60934;

// Syncs bbox from map viewport into filters
function BboxWatcher({ onBboxChange }) {
  const map = useMapEvents({
    moveend: () => onBboxChange(map.getBounds()),
    zoomend: () => onBboxChange(map.getBounds()),
  });
  return null;
}

// Moves map center when user requests GPS-centering
function MapCenterController({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom(), { animate: true });
  }, [center, map]);
  return null;
}

export default function GeoSearchMap() {
  const [allLocations, setAllLocations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [mapCenter, setMapCenter] = useState([39.5, -98.35]); // US center default
  const [userPos, setUserPos] = useState(null);
  const [flyTo, setFlyTo] = useState(null);

  // Load all locations once
  useEffect(() => {
    setLoading(true);
    base44.entities.RockhoundingLocation.list("-rating_avg", 3000)
      .then(data => { setAllLocations(data || []); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  // GPS centering
  const centerOnUser = useCallback(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(pos => {
      const c = [pos.coords.latitude, pos.coords.longitude];
      setUserPos(c);
      setFlyTo(c);
    }, null, { enableHighAccuracy: true, timeout: 8000 });
  }, []);

  const handleBboxChange = useCallback((bounds) => {
    setFilters(f => ({
      ...f,
      bbox: {
        north: bounds.getNorth(),
        south: bounds.getSouth(),
        east:  bounds.getEast(),
        west:  bounds.getWest(),
      }
    }));
  }, []);

  // Pre-calculate lowercased strings for filter matching to prevent O(N*M) allocations
  const optimizedLocations = useMemo(() => {
    return allLocations.map(loc => {
      const found = loc.minerals_found || [];
      const predicted = loc.predicted_minerals || [];
      return {
        ...loc,
        _mineralsLower: [...found, ...predicted].join("|").toLowerCase(),
      };
    });
  }, [allLocations]);

  // Filtering
  const filteredLocations = useMemo(() => {
    const radiusKm = filters.radius * KM_PER_MILE;
    const center = userPos || mapCenter;

    // Hoist lowercase conversion outside the loop to prevent O(N*M) allocations
    const filterMineralsLower = filters.minerals.map(m => m.toLowerCase());

    return optimizedLocations.filter(loc => {
      if (!loc.latitude || !loc.longitude) return false;

      // Radius filter (only when user pos known)
      if (userPos) {
        const dist = haversineKm(center[0], center[1], loc.latitude, loc.longitude);
        if (dist > radiusKm) return false;
      }

      // Bbox filter
      if (filters.bbox) {
        const { north, south, east, west } = filters.bbox;
        if (loc.latitude > north || loc.latitude < south || loc.longitude > east || loc.longitude < west) return false;
      }

      // Legality tier filter
      if (filters.legalityTiers.length > 0) {
        if (!filters.legalityTiers.includes(loc.legality_status)) return false;
      }

      // Legality score minimum
      if (filters.legalityMin > 0) {
        const score = Number(loc.legality_score ?? 0);
        if (score < filters.legalityMin) return false;
      }

      // Minerals filter — location must have ALL selected minerals
      if (filterMineralsLower.length > 0) {
        // Use pre-calculated lowercase strings and short-circuit evaluation
        const hasAll = filterMineralsLower.every(searchMin => {
          return loc._mineralsLower.includes(searchMin);
        });
        if (!hasAll) return false;
      }

      return true;
    });
  }, [optimizedLocations, filters, userPos, mapCenter]);

  return (
    <div className="absolute inset-0" style={{ zIndex: 0 }}>
      <MapContainer
        center={mapCenter}
        zoom={5}
        style={{ width: "100%", height: "100%" }}
        zoomControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='© <a href="https://carto.com/">CARTO</a>'
          maxZoom={18}
        />

        <BboxWatcher onBboxChange={handleBboxChange} />
        {flyTo && <MapCenterController center={flyTo} />}

        {filteredLocations.map(loc => {
          const color = LEGALITY_COLOR[loc.legality_status] || LEGALITY_COLOR.unknown;
          const score = loc.legality_score != null ? Math.round(loc.legality_score) : null;
          const topMinerals = (loc.minerals_found || loc.predicted_minerals || []).slice(0, 3);
          return (
            <CircleMarker
              key={loc.id}
              center={[loc.latitude, loc.longitude]}
              radius={7}
              pathOptions={{
                color,
                fillColor: color,
                fillOpacity: 0.75,
                weight: 1.5,
                opacity: 0.9,
              }}
            >
              <Popup>
                <div style={{ minWidth: 180, fontFamily: "inherit" }}>
                  <div className="font-black text-sm text-gray-900 mb-1">{loc.name}</div>
                  {loc.state && <div className="text-xs text-gray-500 mb-2">{loc.state}{loc.county ? `, ${loc.county}` : ""}</div>}
                  {score != null && (
                    <div className="flex items-center gap-1 mb-1.5">
                      <Shield style={{ width: 12, height: 12, color }} />
                      <span className="text-xs font-semibold" style={{ color }}>{loc.legality_status || "Unknown"}</span>
                      <span className="text-xs text-gray-400 ml-1">({score}/100)</span>
                    </div>
                  )}
                  {topMinerals.length > 0 && (
                    <div className="flex items-start gap-1">
                      <Gem style={{ width: 12, height: 12, color: "#8D7CFF", marginTop: 2, flexShrink: 0 }} />
                      <span className="text-xs text-gray-600">{topMinerals.join(", ")}</span>
                    </div>
                  )}
                  {loc.access_type && (
                    <div className="mt-1.5 text-[10px] text-gray-400">{loc.access_type}</div>
                  )}
                </div>
              </Popup>
            </CircleMarker>
          );
        })}

        {/* User position marker */}
        {userPos && (
          <CircleMarker center={userPos} radius={10}
            pathOptions={{ color: "#7AE7FF", fillColor: "#7AE7FF", fillOpacity: 0.9, weight: 2 }}>
            <Popup><div className="text-sm font-bold text-blue-700">Your Location</div></Popup>
          </CircleMarker>
        )}
      </MapContainer>

      {/* Filter panel overlay */}
      <GeoSearchPanel
        filters={filters}
        onChange={setFilters}
        resultCount={filteredLocations.length}
        loading={loading}
      />

      {/* GPS button */}
      <button
        onClick={centerOnUser}
        className="absolute bottom-4 right-4 z-20 w-12 h-12 rounded-2xl flex items-center justify-center transition-all active:scale-95"
        style={{ background: "rgba(10,15,20,0.92)", border: "1px solid rgba(122,231,255,0.3)", backdropFilter: "blur(12px)" }}
       aria-label="Navigate" title="Navigate">
        <Navigation className="w-5 h-5" style={{ color: "#7AE7FF" }} />
      </button>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 z-20 rounded-2xl p-3 space-y-1.5"
        style={{ background: "rgba(10,15,20,0.92)", border: "1px solid rgba(255,255,255,0.07)", backdropFilter: "blur(12px)" }}>
        {Object.entries(LEGALITY_COLOR).filter(([k]) => k !== "unknown").map(([label, color]) => (
          <div key={label} className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: color }} />
            <span className="text-[10px] font-medium" style={{ color: "rgba(255,255,255,0.45)" }}>{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}