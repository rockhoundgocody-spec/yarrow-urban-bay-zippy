import { useEffect } from 'react';
import { useMapLibre } from './MapLibreContext';

const SOURCE = 'predictive-zones';

function probColor(score) {
  if (score >= 80) return '#00ff88';
  if (score >= 65) return '#7aff3c';
  if (score >= 50) return '#f5c842';
  if (score >= 35) return '#ff9640';
  return '#ff4d4d';
}

export default function ML_PredictiveLayer({ zones = [], visible, onZoneClick }) {
  const map = useMapLibre();

  useEffect(() => {
    if (!map) return;

    const removeLayers = () => {
      ['predictive-outer', 'predictive-fill', 'predictive-stroke'].forEach(id => {
        try { if (map.getLayer(id)) map.removeLayer(id); } catch (_) {}
      });
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };

    const addLayers = () => {
      if (!visible || zones.length === 0) { removeLayers(); return; }

      const geojson = {
        type: 'FeatureCollection',
        features: zones.filter(z => z.lat && z.lng).map(z => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [z.lng, z.lat] },
          properties: {
            probability: z.probability ?? 50,
            color: probColor(z.probability ?? 50),
            radius_m: (z.radius_km ?? 2) * 1000,
            name: z.name ?? 'Zone',
          }
        }))
      };

      if (map.getSource(SOURCE)) { map.getSource(SOURCE).setData(geojson); return; }

      map.addSource(SOURCE, { type: 'geojson', data: geojson });

      // Outer glow ring
      map.addLayer({ id: 'predictive-outer', type: 'circle', source: SOURCE, paint: {
        'circle-color': ['get', 'color'], 'circle-opacity': 0.07,
        'circle-radius': ['interpolate', ['linear'], ['zoom'], 5, 20, 12, 60],
        'circle-blur': 0.8,
      }});

      // Main fill
      map.addLayer({ id: 'predictive-fill', type: 'circle', source: SOURCE, paint: {
        'circle-color': ['get', 'color'], 'circle-opacity': 0.18,
        'circle-radius': ['interpolate', ['linear'], ['zoom'], 5, 14, 12, 45],
        'circle-stroke-width': 1.5, 'circle-stroke-color': ['get', 'color'], 'circle-stroke-opacity': 0.85,
      }});

      if (onZoneClick) {
        map.on('click', 'predictive-fill', e => {
          const z = zones.find(z => z.name === e.features[0]?.properties?.name);
          if (z) onZoneClick(z);
        });
        map.on('mouseenter', 'predictive-fill', () => { map.getCanvas().style.cursor = 'pointer'; });
        map.on('mouseleave', 'predictive-fill', () => { map.getCanvas().style.cursor = ''; });
      }
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, zones, visible, onZoneClick]);

  return null;
}