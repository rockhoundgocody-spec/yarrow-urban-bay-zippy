import { WMSTileLayer } from "react-leaflet";

/**
 * USGS National Geologic Map Database WMS layer.
 * Rendered only when show_geology_layer is true.
 */
export default function GeologyLayer({ visible }) {
  if (!visible) return null;

  return (
    <WMSTileLayer
      url="https://mrdata.usgs.gov/services/gscworld"
      layers="US_Geology"
      format="image/png"
      transparent={true}
      opacity={0.45}
      attribution='<a href="https://mrdata.usgs.gov/">USGS</a> Geology'
      version="1.3.0"
    />
  );
}