/**
 * AccessBadge — Shows access status on map markers and site cards
 * public | permit_required | private_unknown | fee_area
 */
import React from 'react';
import { Shield, AlertCircle, Lock, DollarSign } from 'lucide-react';

export default function AccessBadge({ status = 'public', size = 'sm' }) {
  const configs = {
    public: {
      label: 'Public Access',
      icon: Shield,
      color: '#00D68F',
      bgColor: 'rgba(0,214,143,0.15)'
    },
    permit_required: {
      label: 'Permit Required',
      icon: AlertCircle,
      color: '#F5B642',
      bgColor: 'rgba(245,182,66,0.15)'
    },
    private_unknown: {
      label: 'Access Unverified',
      icon: Lock,
      color: '#FF6B6B',
      bgColor: 'rgba(255,107,107,0.15)'
    },
    fee_area: {
      label: 'Fee Required',
      icon: DollarSign,
      color: '#7AE7FF',
      bgColor: 'rgba(122,231,255,0.15)'
    }
  };

  const config = configs[status] || configs.public;
  const Icon = config.icon;
  const sizeClass = size === 'sm' ? 'text-[10px]' : 'text-xs';

  return (
    <div
      className={`inline-flex items-center gap-1.5 px-2 py-1 rounded-lg font-bold ${sizeClass}`}
      style={{ background: config.bgColor, color: config.color }}>
      <Icon className="w-3 h-3" />
      {config.label}
    </div>
  );
}