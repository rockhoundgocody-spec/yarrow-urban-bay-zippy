import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X, Route, Plus, Trash2, Save, MapPin, ChevronUp, ChevronDown, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function RouteBuilder({ locations, onClose, onFlyTo, currentUser }) {
  const [routeName, setRouteName] = useState("");
  const [waypoints, setWaypoints] = useState([]); // array of location ids
  const [searchQ, setSearchQ] = useState("");
  const [activeTab, setActiveTab] = useState("build"); // "build" | "saved"
  const queryClient = useQueryClient();

  const { data: savedRoutes = [] } = useQuery({
    queryKey: ["saved-routes", currentUser?.email],
    enabled: !!currentUser?.email,
    queryFn: () => base44.entities.SavedMapConfig.filter({ created_by: currentUser.email }, "-created_date"),
  });

  const saveMutation = useMutation({
    mutationFn: (data) => base44.entities.SavedMapConfig.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["saved-routes"] });
      setRouteName("");
      setWaypoints([]);
      setActiveTab("saved");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.SavedMapConfig.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["saved-routes"] }),
  });

  const addedIds = useMemo(() => new Set(waypoints), [waypoints]);

  // ⚡ Bolt: Pre-process and cache lowercase values for locations
  // This runs only when `locations` reference changes, avoiding repetitive operations on every keystroke
  const preprocessedLocations = useMemo(() => {
    return locations.map(l => ({
      item: l,
      _lowerName: l.name?.toLowerCase() || "",
      _lowerState: l.state?.toLowerCase() || "",
      _lowerMinerals: l.minerals_found?.map(m => m.toLowerCase()) || []
    }));
  }, [locations]);

  // ⚡ Bolt: Hoisted lowercase conversion and memoized filter to prevent O(N*M) allocations
  const suggestions = useMemo(() => {
    if (!searchQ) {
      return locations.filter(l => !addedIds.has(l.id)).slice(0, 8);
    }
    const query = searchQ.toLowerCase();
    return preprocessedLocations
      .filter(l => !addedIds.has(l.item.id) && (
        l._lowerName.includes(query) ||
        l._lowerState.includes(query) ||
        l._lowerMinerals.some(m => m.includes(query))
      ))
      .map(l => l.item)
      .slice(0, 8);
  }, [preprocessedLocations, locations, addedIds, searchQ]);

  // ⚡ Bolt: Memoize location lookup to prevent O(N * selected) search on every render
  const waypointLocations = useMemo(() =>
    waypoints.map(id => locations.find(l => l.id === id)).filter(Boolean),
  [waypoints, locations]);

  const moveUp = (idx) => {
    if (idx === 0) return;
    const next = [...waypoints];
    [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
    setWaypoints(next);
  };

  const moveDown = (idx) => {
    if (idx === waypoints.length - 1) return;
    const next = [...waypoints];
    [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
    setWaypoints(next);
  };

  const totalMiles = waypointLocations.reduce((acc, loc, i) => {
    if (i === 0) return 0;
    const prev = waypointLocations[i - 1];
    const R = 3958.8;
    const dLat = ((loc.latitude - prev.latitude) * Math.PI) / 180;
    const dLng = ((loc.longitude - prev.longitude) * Math.PI) / 180;
    const a = Math.sin(dLat / 2) ** 2 + Math.cos((prev.latitude * Math.PI) / 180) * Math.cos((loc.latitude * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
    return acc + R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }, 0);

  const handleSave = () => {
    if (!routeName.trim() || waypoints.length < 2) return;
    saveMutation.mutate({
      config_name: routeName.trim(),
      description: `Expedition route: ${waypointLocations.map(l => l.name).join(" → ")}`,
      filters: { route_waypoints: waypoints, route_waypoint_names: waypointLocations.map(l => l.name) },
      map_layers: {},
    });
  };

  const routeConfigs = savedRoutes.filter(r => r.filters?.route_waypoints?.length > 0);

  return (
    <div className="absolute bottom-24 right-3 z-30 w-80 bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col max-h-[70vh] overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white shrink-0">
        <div className="flex items-center gap-2">
          <Route className="w-4 h-4" />
          <span className="text-sm font-bold">Expedition Routes</span>
        </div>
        <button
          aria-label="Close route builder"
          title="Close route builder"
          onClick={onClose}
          className="text-white/70 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-100 shrink-0">
        {["build", "saved"].map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-2 text-xs font-semibold capitalize transition-colors ${
              activeTab === tab ? "text-emerald-600 border-b-2 border-emerald-500 bg-emerald-50/50" : "text-gray-400 hover:text-gray-600"
            }`}
          >
            {tab === "build" ? "Build Route" : `Saved (${routeConfigs.length})`}
          </button>
        ))}
      </div>

      <ScrollArea className="flex-1">
        {activeTab === "build" ? (
          <div className="p-4 space-y-4">
            {/* Route name */}
            <Input
              placeholder="Route name..."
              value={routeName}
              onChange={e => setRouteName(e.target.value)}
              className="text-sm border-gray-200 focus:border-emerald-400"
            />

            {/* Waypoints list */}
            {waypointLocations.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">
                  Route · {waypointLocations.length} stops · ~{Math.round(totalMiles)} mi straight-line
                </p>
                {waypointLocations.map((loc, idx) => (
                  <div
                    key={loc.id}
                    className="flex items-center gap-2 bg-gray-50 rounded-xl px-3 py-2 border border-gray-100 group"
                  >
                    <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                      {idx + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-700 truncate">{loc.name}</p>
                      <p className="text-[10px] text-gray-400 truncate">{loc.state}</p>
                    </div>
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        aria-label="Fly to location"
                        onClick={() => onFlyTo?.([loc.latitude, loc.longitude])}
                        className="p-1 text-gray-400 hover:text-emerald-600 transition-colors"
                        title="Fly to"
                      >
                        <Navigation className="w-3 h-3" />
                      </button>
                      <button
                        aria-label="Move waypoint up"
                        title="Move waypoint up"
                        onClick={() => moveUp(idx)}
                        disabled={idx === 0}
                        className="p-1 text-gray-300 hover:text-gray-600 disabled:opacity-20 transition-colors"
                      >
                        <ChevronUp className="w-3 h-3" />
                      </button>
                      <button
                        aria-label="Move waypoint down"
                        title="Move waypoint down"
                        onClick={() => moveDown(idx)}
                        disabled={idx === waypointLocations.length - 1}
                        className="p-1 text-gray-300 hover:text-gray-600 disabled:opacity-20 transition-colors"
                      >
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      <button
                        aria-label="Remove waypoint"
                        title="Remove waypoint"
                        onClick={() => setWaypoints(waypoints.filter(id => id !== loc.id))}
                        className="p-1 text-gray-300 hover:text-red-500 transition-colors"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Location search to add */}
            <div>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider mb-2">Add Stops</p>
              <input
                type="text"
                placeholder="Search locations..."
                value={searchQ}
                onChange={e => setSearchQ(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-gray-50 border border-gray-200 text-xs text-gray-800 placeholder:text-gray-400 outline-none focus:border-emerald-400 transition-colors mb-2"
              />
              <div className="space-y-1">
                {suggestions.map(loc => (
                  <button
                    key={loc.id}
                    onClick={() => setWaypoints([...waypoints, loc.id])}
                    className="w-full flex items-center gap-2 text-left px-3 py-2 rounded-lg hover:bg-emerald-50 border border-transparent hover:border-emerald-100 transition-all group"
                  >
                    <MapPin className="w-3.5 h-3.5 text-gray-300 group-hover:text-emerald-500 transition-colors shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-gray-700 truncate">{loc.name}</p>
                      <p className="text-[10px] text-gray-400">{loc.state} · {loc.minerals_found?.slice(0, 2).join(", ")}</p>
                    </div>
                    <Plus className="w-3 h-3 text-gray-300 group-hover:text-emerald-500 transition-colors shrink-0" />
                  </button>
                ))}
                {suggestions.length === 0 && searchQ && (
                  <p className="text-[11px] text-gray-400 text-center py-2">No matches found</p>
                )}
              </div>
            </div>

            {/* Save button */}
            {currentUser && (
              <Button
                onClick={handleSave}
                disabled={waypoints.length < 2 || !routeName.trim() || saveMutation.isPending}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-white border-0 text-xs h-9 gap-2"
              >
                <Save className="w-3.5 h-3.5" />
                Save Route ({waypoints.length} stops)
              </Button>
            )}
            {!currentUser && (
              <p className="text-[11px] text-gray-400 text-center">Sign in to save routes</p>
            )}
          </div>
        ) : (
          <div className="p-4 space-y-3">
            {routeConfigs.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Route className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <p className="text-sm">No saved routes yet</p>
                <button onClick={() => setActiveTab("build")} className="mt-2 text-xs text-emerald-600 hover:underline">Build your first route →</button>
              </div>
            ) : (
              routeConfigs.map(route => {
                const names = route.filters?.route_waypoint_names || [];
                const ids = route.filters?.route_waypoints || [];
                return (
                  <div key={route.id} className="bg-gray-50 rounded-xl border border-gray-100 p-3">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-semibold text-gray-800">{route.config_name}</p>
                      <button
                        aria-label="Delete saved route"
                        title="Delete saved route"
                        onClick={() => deleteMutation.mutate(route.id)}
                        className="text-gray-300 hover:text-red-400 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <p className="text-[10px] text-gray-400 mb-2">{ids.length} stops</p>
                    <div className="flex flex-wrap gap-1">
                      {names.slice(0, 4).map((n, i) => (
                        <span key={i} className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-full px-2 py-0.5">{n}</span>
                      ))}
                      {names.length > 4 && <span className="text-[10px] text-gray-400">+{names.length - 4} more</span>}
                    </div>
                    <button
                      onClick={() => {
                        setWaypoints(ids);
                        setRouteName(route.config_name);
                        setActiveTab("build");
                      }}
                      className="mt-2 text-[11px] text-emerald-600 hover:underline"
                    >
                      Load & edit →
                    </button>
                  </div>
                );
              })
            )}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}