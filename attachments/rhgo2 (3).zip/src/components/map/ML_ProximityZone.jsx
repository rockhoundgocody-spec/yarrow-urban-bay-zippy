import { useEffect } from 'react';
import { useMapLibre } from './MapLibreContext';

const EARTH_R = 3958.8;
const NEAR_MI = 3.0;
const ENTER_MI = 1.0;

function haversine(lat1, lon1, lat2, lon2) {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
  return EARTH_R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function isHighPotential(loc) {
  const score =
    (loc.mineral_prediction_confidence || 0) * 0.4 +
    ((loc.rating_avg || 0) / 5) * 100 * 0.3 +
    (loc.legality_status === 'Safe Public' ? 100 : loc.legality_status === 'Likely Legal' ? 70 : 30) * 0.3;
  return score >= 45;
}

const SOURCE = 'proximity-zones';

export default function ML_ProximityZone({ userPos, locations }) {
  const map = useMapLibre();

  useEffect(() => {
    if (!map || !userPos || !locations?.length) return;

    const nearby = locations.filter(isHighPotential).filter(loc => {
      if (!loc.latitude || !loc.longitude) return false;
      return haversine(userPos[0], userPos[1], loc.latitude, loc.longitude) <= NEAR_MI;
    });

    const features = nearby.map(loc => {
      const dist = haversine(userPos[0], userPos[1], loc.latitude, loc.longitude);
      const entering = dist <= ENTER_MI;
      return {
        type: 'Feature',
        geometry: { type: 'Point', coordinates: [loc.longitude, loc.latitude] },
        properties: {
          color: entering ? '#f59e0b' : '#6366f1',
          radius_m: entering ? 800 : 2400,
          name: loc.name,
        }
      };
    });

    const geojson = { type: 'FeatureCollection', features };

    const addLayers = () => {
      if (map.getSource(SOURCE)) {
        map.getSource(SOURCE).setData(geojson);
        return;
      }
      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({
        id: 'proximity-fill',
        type: 'circle',
        source: SOURCE,
        paint: {
          'circle-color': ['get', 'color'],
          'circle-opacity': 0.12,
          'circle-radius': ['get', 'radius_m'],
          'circle-stroke-width': 1.5,
          'circle-stroke-color': ['get', 'color'],
          'circle-stroke-opacity': 0.4,
          'circle-radius-transition': { duration: 300 },
        }
      });
    };

    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      try { if (map.getLayer('proximity-fill')) map.removeLayer('proximity-fill'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };
  }, [map, userPos, locations]);

  return null;
}