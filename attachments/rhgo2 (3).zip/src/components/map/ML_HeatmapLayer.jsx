import { useEffect, useMemo } from 'react';
import { useMapLibre } from './MapLibreContext';

const SOURCE = 'geo-heatmap';

const MGR_COLORS = {
  BLM: '#f59e0b', USFS: '#22c55e', 'State Land': '#38bdf8',
  'State Park': '#a78bfa', FWS: '#06b6d4', NPS: '#818cf8',
  Tribal: '#fb923c', Private: '#f87171', Unknown: '#6b7280',
};

function scoreColor(score) {
  const stops = [
    [0, [67, 56, 202]], [20, [37, 99, 235]], [40, [6, 182, 212]],
    [58, [16, 185, 129]], [74, [245, 158, 11]], [88, [239, 68, 68]], [100, [220, 38, 127]],
  ];
  let lo = stops[0], hi = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (score >= stops[i][0] && score <= stops[i + 1][0]) { lo = stops[i]; hi = stops[i + 1]; break; }
  }
  const t = lo[0] === hi[0] ? 0 : (score - lo[0]) / (hi[0] - lo[0]);
  const r = Math.round(lo[1][0] + (hi[1][0] - lo[1][0]) * t);
  const g = Math.round(lo[1][1] + (hi[1][1] - lo[1][1]) * t);
  const b = Math.round(lo[1][2] + (hi[1][2] - lo[1][2]) * t);
  return `rgba(${r},${g},${b},1)`;
}

export default function ML_HeatmapLayer({ cells, gridDeg, visible, mineralFilter, landFilter }) {
  const map = useMapLibre();

  // ⚡ Bolt: Pre-calculate lowercase search strings to prevent O(N*M) allocations during frequent filtering.
  // Using a wrapper object preserves original references and avoids excessive cloning overhead.
  const optimizedCells = useMemo(() => {
    return (cells || []).map(cell => ({
      item: cell,
      searchStr: (cell.top_minerals || []).join('|').toLowerCase()
    }));
  }, [cells]);

  const filtered = useMemo(() => {
    const minLower = mineralFilter ? mineralFilter.toLowerCase() : '';
    return optimizedCells.filter(({ item, searchStr }) => {
      if (landFilter && landFilter !== 'all') {
        if (landFilter === 'public_only') {
          if (!['BLM', 'USFS', 'State Land', 'State Park'].includes(item.dominant_manager)) return false;
        } else if (item.dominant_manager !== landFilter) return false;
      }
      if (minLower && !searchStr.includes(minLower)) return false;
      return true;
    }).map(({ item }) => item);
  }, [optimizedCells, landFilter, mineralFilter]);

  useEffect(() => {
    if (!map) return;

    const addLayers = () => {
      const geojson = {
        type: 'FeatureCollection',
        features: filtered.map(cell => ({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [cell.lng, cell.lat] },
          properties: {
            score: cell.score,
            color: scoreColor(cell.score),
            size: (gridDeg || 0.5) * 40000,
          }
        }))
      };

      if (map.getSource(SOURCE)) {
        map.getSource(SOURCE).setData(geojson);
        return;
      }

      if (!visible || filtered.length === 0) return;

      map.addSource(SOURCE, { type: 'geojson', data: geojson });
      map.addLayer({
        id: 'geo-heatmap-fill',
        type: 'circle',
        source: SOURCE,
        paint: {
          'circle-color': ['get', 'color'],
          'circle-radius': ['interpolate', ['linear'], ['zoom'], 4, 8, 10, 30],
          'circle-opacity': 0.35,
          'circle-blur': 0.6,
          'circle-stroke-color': ['get', 'color'],
          'circle-stroke-width': 0.5,
          'circle-stroke-opacity': 0.5,
        }
      });
    };

    const removeLayers = () => {
      try { if (map.getLayer('geo-heatmap-fill')) map.removeLayer('geo-heatmap-fill'); } catch (_) {}
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
    };

    if (!visible) { if (map.isStyleLoaded()) removeLayers(); return; }
    if (filtered.length === 0) return;

    if (map.isStyleLoaded()) addLayers(); else map.once('load', addLayers);
    map.on('style.load', addLayers);

    return () => {
      map.off('style.load', addLayers);
      if (map.isStyleLoaded()) removeLayers();
    };
  }, [map, filtered, visible, gridDeg]);

  return null;
}