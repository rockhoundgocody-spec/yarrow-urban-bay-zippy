import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CheckCircle2, AlertTriangle, ThumbsUp, Plus, Loader2, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

const EVENT_CONFIG = {
  access_confirmed:       { label: "Access Confirmed",        color: "text-green-400 bg-green-400/10 border-green-400/20", icon: CheckCircle2 },
  access_denied:          { label: "Access Denied",           color: "text-red-400 bg-red-400/10 border-red-400/20",       icon: AlertTriangle },
  permit_confirmed:       { label: "Permit Confirmed",        color: "text-blue-400 bg-blue-400/10 border-blue-400/20",    icon: ShieldCheck },
  boundary_corrected:     { label: "Boundary Corrected",      color: "text-amber-400 bg-amber-400/10 border-amber-400/20", icon: AlertTriangle },
  hazard_reported:        { label: "Hazard Reported",         color: "text-orange-400 bg-orange-400/10 border-orange-400/20", icon: AlertTriangle },
  found_here:             { label: "Found Here",              color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",    icon: CheckCircle2 },
  closed_seasonal:        { label: "Seasonally Closed",       color: "text-red-400 bg-red-400/10 border-red-400/20",       icon: AlertTriangle },
  reopened:               { label: "Reopened",                color: "text-green-400 bg-green-400/10 border-green-400/20", icon: CheckCircle2 },
  land_manager_corrected: { label: "Land Manager Corrected",  color: "text-purple-400 bg-purple-400/10 border-purple-400/20", icon: ShieldCheck },
};

export default function LocalityLedger({ location }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ event_type: "access_confirmed", notes: "", visit_date: "", field_value: "" });
  const queryClient = useQueryClient();

  const { data: events = [], isLoading } = useQuery({
    queryKey: ["verifications", location.id],
    queryFn: () => base44.entities.VerificationEvent.filter({ location_id: location.id }, "-created_date", 20),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.VerificationEvent.create({ ...data, location_id: location.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["verifications", location.id] });
      setShowForm(false);
      setForm({ event_type: "access_confirmed", notes: "", visit_date: "", field_value: "" });
    },
  });

  const confirmMutation = useMutation({
    mutationFn: (event) => base44.entities.VerificationEvent.update(event.id, {
      confirmed_by_count: (event.confirmed_by_count || 0) + 1
    }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["verifications", location.id] }),
  });

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-semibold text-white/60">Locality Ledger</p>
        <Button
          size="sm"
          onClick={() => setShowForm(true)}
          className="h-6 px-2 text-[10px] bg-white/5 hover:bg-white/10 text-white/50 border border-white/10"
        >
          <Plus className="w-3 h-3 mr-1" /> Report
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-3"><Loader2 className="w-4 h-4 animate-spin text-white/30" /></div>
      ) : events.length === 0 ? (
        <p className="text-[10px] text-white/30 italic text-center py-2">No verifications yet. Be the first to confirm access!</p>
      ) : (
        <div className="space-y-1.5">
          {events.map((ev) => {
            const cfg = EVENT_CONFIG[ev.event_type] || EVENT_CONFIG.access_confirmed;
            const Icon = cfg.icon;
            return (
              <div key={ev.id} className="flex items-start gap-2 p-2 rounded-lg bg-white/[0.02] border border-white/5">
                <Icon className={cn("w-3 h-3 mt-0.5 shrink-0", cfg.color.split(" ")[0])} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <Badge className={cn("text-[9px] px-1.5 py-0 border", cfg.color)}>{cfg.label}</Badge>
                    {ev.visit_date && <span className="text-[9px] text-white/30">{ev.visit_date}</span>}
                  </div>
                  {ev.notes && <p className="text-[10px] text-white/50 mt-0.5 line-clamp-2">{ev.notes}</p>}
                </div>
                <button
                  onClick={() => confirmMutation.mutate(ev)}
                  className="flex items-center gap-0.5 text-[9px] text-white/30 hover:text-green-400 transition shrink-0"
                  title="Confirm this report"
                >
                  <ThumbsUp className="w-3 h-3" />
                  {ev.confirmed_by_count > 0 && <span>{ev.confirmed_by_count}</span>}
                </button>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Submit Verification</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-white/50 block mb-1">Event Type</label>
              <Select value={form.event_type} onValueChange={(v) => setForm({ ...form, event_type: v })}>
                <SelectTrigger className="bg-white/5 border-white/10 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(EVENT_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Visit Date</label>
              <Input type="date" value={form.visit_date} onChange={(e) => setForm({ ...form, visit_date: e.target.value })}
                className="bg-white/5 border-white/10 text-sm" />
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Notes</label>
              <Textarea
                placeholder="What did you observe? Gate open? New sign? Permit required now?"
                value={form.notes}
                onChange={(e) => setForm({ ...form, notes: e.target.value })}
                className="bg-white/5 border-white/10 text-sm" rows={3}
              />
            </div>
            <Button
              onClick={() => createMutation.mutate(form)}
              disabled={!form.event_type || createMutation.isPending}
              className="w-full bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/20"
            >
              {createMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : null}
              Submit Verification
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}