import React from "react";
import { Badge } from "@/components/ui/badge";
import { Shield, AlertTriangle, Lock, DollarSign, Car, CheckCircle, HelpCircle } from "lucide-react";

const landManagerColors = {
  BLM: "bg-yellow-500/15 text-yellow-400 border-yellow-500/25",
  USFS: "bg-green-500/15 text-green-400 border-green-500/25",
  NPS: "bg-blue-500/15 text-blue-400 border-blue-500/25",
  FWS: "bg-teal-500/15 text-teal-400 border-teal-500/25",
  "State Park": "bg-purple-500/15 text-purple-400 border-purple-500/25",
  "State Land": "bg-indigo-500/15 text-indigo-400 border-indigo-500/25",
  Private: "bg-red-500/15 text-red-400 border-red-500/25",
  Tribal: "bg-orange-500/15 text-orange-400 border-orange-500/25",
  Unknown: "bg-white/5 text-white/40 border-white/10",
};

const accessColors = {
  "Free Public": "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  "Fee Area": "bg-yellow-500/15 text-yellow-400 border-yellow-500/25",
  "Permit Required": "bg-orange-500/15 text-orange-400 border-orange-500/25",
  "Private Permission": "bg-red-500/15 text-red-400 border-red-500/25",
  Closed: "bg-red-700/20 text-red-400 border-red-600/30",
};

function ConfidenceMeter({ score }) {
  if (score == null) return null;
  const color = score >= 70 ? "bg-emerald-500" : score >= 40 ? "bg-yellow-500" : "bg-red-500";
  const label = score >= 70 ? "High Confidence" : score >= 40 ? "Moderate" : "Low Confidence";
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${score}%` }} />
      </div>
      <span className="text-[10px] text-white/40 whitespace-nowrap">{label} ({score})</span>
    </div>
  );
}

export default function RiskBadges({ location, className = "" }) {
  const hasRisk = location.permit_required || location.fee_required ||
    location.land_manager === "Private" || location.access_type === "Closed" ||
    location.admin_flags?.length > 0;

  return (
    <div className={`space-y-2 ${className}`}>
      {/* Land manager + access type */}
      <div className="flex flex-wrap gap-1.5">
        {location.land_manager && (
          <Badge className={`text-[10px] ${landManagerColors[location.land_manager] || landManagerColors.Unknown}`}>
            <Shield className="w-2.5 h-2.5 mr-1" />
            {location.land_manager}
          </Badge>
        )}
        {location.access_type && (
          <Badge className={`text-[10px] ${accessColors[location.access_type] || "bg-white/5 text-white/40"}`}>
            {location.access_type}
          </Badge>
        )}
        {location.vehicle_requirement && location.vehicle_requirement !== "2WD" && (
          <Badge className="text-[10px] bg-orange-500/10 text-orange-400 border-orange-500/20">
            <Car className="w-2.5 h-2.5 mr-1" /> {location.vehicle_requirement}
          </Badge>
        )}
      </div>

      {/* Permit / Fee / Commercial */}
      <div className="flex flex-wrap gap-1.5">
        {location.permit_required && (
          <Badge className="text-[10px] bg-orange-500/15 text-orange-300 border-orange-500/25">
            <Lock className="w-2.5 h-2.5 mr-1" />
            Permit: {location.permit_type || "Required"}
          </Badge>
        )}
        {location.fee_required && (
          <Badge className="text-[10px] bg-yellow-500/15 text-yellow-300 border-yellow-500/25">
            <DollarSign className="w-2.5 h-2.5 mr-1" />
            Fee{location.fee_amount ? `: ${location.fee_amount}` : ""}
          </Badge>
        )}
        {location.collection_limit && (
          <Badge className="text-[10px] bg-cyan-500/10 text-cyan-400 border-cyan-500/20">
            Limit: {location.collection_limit}
          </Badge>
        )}
        {location.commercial_collecting_allowed === false && (
          <Badge className="text-[10px] bg-red-500/10 text-red-400 border-red-500/20">
            No Commercial
          </Badge>
        )}
      </div>

      {/* Admin flags */}
      {location.admin_flags?.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {location.admin_flags.map((flag) => (
            <Badge key={flag} className="text-[10px] bg-red-500/15 text-red-300 border-red-500/25">
              <AlertTriangle className="w-2.5 h-2.5 mr-1" /> {flag}
            </Badge>
          ))}
        </div>
      )}

      {/* Confidence meter */}
      {location.confidence_score != null && (
        <ConfidenceMeter score={location.confidence_score} />
      )}

      {/* Verification status */}
      {location.land_status_verified != null && (
        <div className="flex items-center gap-1.5 text-[10px]">
          {location.land_status_verified ? (
            <CheckCircle className="w-3 h-3 text-emerald-400" />
          ) : (
            <HelpCircle className="w-3 h-3 text-white/30" />
          )}
          <span className={location.land_status_verified ? "text-emerald-400" : "text-white/30"}>
            {location.land_status_verified ? "Ownership Verified" : "Ownership Unverified"}
          </span>
          {location.last_verified && (
            <span className="text-white/20">· {new Date(location.last_verified).toLocaleDateString()}</span>
          )}
        </div>
      )}
    </div>
  );
}