import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Loader2, Brain, ChevronDown, ChevronUp } from "lucide-react";

export default function MineralPrediction({ location }) {
  const [loading, setLoading] = useState(false);
  const [showReasoning, setShowReasoning] = useState(false);
  const [localResult, setLocalResult] = useState(null);

  const predicted = localResult?.predicted_minerals || location.predicted_minerals || [];
  const confidence = localResult?.confidence ?? location.mineral_prediction_confidence ?? null;
  const reasoning = localResult?.reasoning || location.mineral_prediction_reasoning || "";

  const handlePredict = async () => {
    setLoading(true);
    const res = await base44.functions.invoke("predictMinerals", { location_id: location.id });
    setLocalResult(res.data);
    setLoading(false);
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Brain className="w-3.5 h-3.5 text-purple-400" />
          <span className="text-xs font-semibold text-white/60">AI Mineral Prediction</span>
          {confidence != null && (
            <span className="text-[10px] text-purple-400/70 font-medium">{Math.round(confidence)}% confidence</span>
          )}
        </div>
        <Button
          size="sm"
          onClick={handlePredict}
          disabled={loading}
          className="h-6 px-2 text-[10px] bg-purple-500/10 text-purple-300 border border-purple-500/20 hover:bg-purple-500/20"
        >
          {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          {predicted.length > 0 ? "Re-predict" : "Predict"}
        </Button>
      </div>

      {predicted.length > 0 ? (
        <div className="space-y-1.5">
          <div className="flex flex-wrap gap-1">
            {predicted.map(m => (
              <Badge key={m} className="text-[10px] bg-purple-500/10 text-purple-300 border-purple-500/20">
                {m}
              </Badge>
            ))}
          </div>
          {reasoning && (
            <div>
              <button
                onClick={() => setShowReasoning(!showReasoning)}
                className="flex items-center gap-1 text-[10px] text-white/30 hover:text-white/50 transition-colors"
              >
                {showReasoning ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                {showReasoning ? "Hide" : "Show"} reasoning
              </button>
              {showReasoning && (
                <p className="text-[11px] text-white/40 mt-1 leading-relaxed italic border-l border-purple-500/20 pl-2">
                  {reasoning}
                </p>
              )}
            </div>
          )}
        </div>
      ) : !loading ? (
        <p className="text-[11px] text-white/25">Click Predict to use AI to suggest likely minerals based on geology and location.</p>
      ) : null}
    </div>
  );
}