/**
 * ExploreIntelligenceHud
 * Overlay HUD: layer toggle + legality badge + tap snapshot inline.
 * Sits inside the map container, pointer-events passthrough on wrapper.
 */
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import ExploreLayerToggle from "./ExploreLayerToggle";
import { riskLevelToLabel } from "../../lib/useExploreSnapshot";

const RISK_PALETTE = {
  blocked: { bg: "rgba(255,107,122,0.12)", border: "rgba(255,107,122,0.35)", color: "#ff6b7a" },
  high:    { bg: "rgba(244,200,106,0.12)", border: "rgba(244,200,106,0.32)", color: "#f4c86a" },
  med:     { bg: "rgba(244,200,106,0.10)", border: "rgba(244,200,106,0.26)", color: "#f4c86a" },
  low:     { bg: "rgba(78,226,154,0.10)",  border: "rgba(78,226,154,0.28)",  color: "#4ee29a" },
};

function RiskBadge({ level }) {
  const p = RISK_PALETTE[level] || RISK_PALETTE.high;
  return (
    <span
      className="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-black tracking-wider"
      style={{ background: p.bg, border: `1px solid ${p.border}`, color: p.color }}
    >
      {riskLevelToLabel(level)}
    </span>
  );
}

function MineralChip({ label, score }) {
  return (
    <span
      className="inline-flex items-center px-2 py-1 rounded-full text-[10px] font-bold"
      style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}
    >
      {label} <span className="ml-1 text-white/30">{Math.round(score * 100)}%</span>
    </span>
  );
}

export default function ExploreIntelligenceHud({ layer, onChangeLayer, snapshot, loading }) {
  return (
    <div
      className="absolute top-0 left-0 right-0 z-30 pointer-events-none"
      style={{ padding: "12px 12px 0" }}
    >
      {/* Glass panel */}
      <div
        className="pointer-events-auto rounded-2xl p-3 space-y-3"
        style={{
          background: "rgba(8,8,20,0.88)",
          border: "1px solid rgba(255,255,255,0.08)",
          backdropFilter: "blur(20px)",
          boxShadow: "0 4px 24px rgba(0,0,0,0.6)",
        }}
      >
        {/* Row 1: layer toggle + status */}
        <div className="flex items-center justify-between gap-3">
          <ExploreLayerToggle active={layer} onChange={onChangeLayer} />
          <span className="text-[9px] font-black tracking-widest shrink-0"
            style={{ color: loading ? "#7AE7FF" : snapshot ? "#4ee29a" : "rgba(255,255,255,0.25)" }}>
            {loading ? "RESOLVING…" : snapshot ? "SNAPSHOT ACTIVE" : "TAP MAP"}
          </span>
        </div>

        {/* Row 2: snapshot content */}
        <AnimatePresence mode="wait">
          {snapshot && !loading && (
            <motion.div
              key={snapshot.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.18 }}
              className="space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-black text-white leading-tight truncate">{snapshot.parcelLabel}</p>
                  <p className="text-[10px] font-semibold mt-0.5"
                    style={{ color: "rgba(255,255,255,0.35)" }}>
                    {snapshot.ownerType} · Trust {snapshot.trustLevel.toUpperCase()} · {Math.round(snapshot.confidence * 100)}%
                  </p>
                </div>
                <RiskBadge level={snapshot.riskLevel} />
              </div>

              <p className="text-[11px] leading-relaxed" style={{ color: "rgba(255,255,255,0.45)" }}>
                {snapshot.legalityMessage}
              </p>

              {snapshot.predictedMinerals?.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {snapshot.predictedMinerals.map(m => <MineralChip key={m.label} label={m.label} score={m.score} />)}
                </div>
              )}
            </motion.div>
          )}

          {!snapshot && !loading && (
            <motion.p
              key="hint"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-[10px] font-semibold"
              style={{ color: "rgba(255,255,255,0.2)" }}
            >
              Tap the map to resolve parcel access, trust level, and mineral prediction.
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}