import L from "leaflet";

// SVG icon templates for geological site types
const MINERAL_ICONS = {
  crystal: (color, glow) => `
    <svg width="32" height="38" viewBox="0 0 32 38" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <filter id="glow-c">
          <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
          <feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
      <!-- Pin stem -->
      <path d="M16 34 L10 18 L16 4 L22 18 Z" fill="${color}" opacity="0.9" filter="url(#glow-c)"/>
      <!-- Crystal facets -->
      <polygon points="16,2 8,14 16,20 24,14" fill="${color}" filter="url(#glow-c)"/>
      <polygon points="16,2 24,14 16,20" fill="white" opacity="0.25"/>
      <polygon points="16,2 8,14 16,20" fill="black" opacity="0.1"/>
      <!-- Sparkle -->
      <circle cx="16" cy="11" r="2" fill="white" opacity="0.7"/>
      <!-- Drop shadow tip -->
      <ellipse cx="16" cy="36" rx="4" ry="1.5" fill="black" opacity="0.2"/>
    </svg>`,

  geode: (color, glow) => `
    <svg width="32" height="38" viewBox="0 0 32 38" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="geo-grad" cx="40%" cy="35%">
          <stop offset="0%" stop-color="white" stop-opacity="0.4"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="1"/>
        </radialGradient>
      </defs>
      <!-- Pin drop -->
      <path d="M16 36 C16 36 6 24 6 16 C6 10.5 10.5 6 16 6 C21.5 6 26 10.5 26 16 C26 24 16 36 16 36Z" fill="url(#geo-grad)"/>
      <!-- Outer ring -->
      <circle cx="16" cy="15" r="8" fill="none" stroke="white" stroke-width="1.5" opacity="0.5"/>
      <!-- Inner crystal pattern -->
      <circle cx="16" cy="15" r="4.5" fill="${color}" opacity="0.7"/>
      <circle cx="16" cy="15" r="2.5" fill="white" opacity="0.4"/>
      <!-- Shine -->
      <circle cx="13" cy="12" r="1.5" fill="white" opacity="0.6"/>
      <ellipse cx="16" cy="37" rx="4" ry="1.5" fill="black" opacity="0.2"/>
    </svg>`,

  mine: (color, glow) => `
    <svg width="34" height="40" viewBox="0 0 34 40" xmlns="http://www.w3.org/2000/svg">
      <!-- Pin body -->
      <path d="M17 38 C17 38 5 26 5 17 C5 10.4 10.4 5 17 5 C23.6 5 29 10.4 29 17 C29 26 17 38 17 38Z" fill="${color}"/>
      <path d="M17 38 C17 38 5 26 5 17 C5 10.4 10.4 5 17 5 C23.6 5 29 10.4 29 17 C29 26 17 38 17 38Z" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="1.5"/>
      <!-- Mine entrance arch -->
      <path d="M10 22 L10 16 Q17 10 24 16 L24 22 Z" fill="rgba(0,0,0,0.5)"/>
      <!-- Crossed pickaxes -->
      <g transform="translate(17,17)" fill="white" opacity="0.9">
        <rect x="-6" y="-1" width="12" height="2" rx="1" transform="rotate(45)"/>
        <rect x="-6" y="-1" width="12" height="2" rx="1" transform="rotate(-45)"/>
        <circle cx="0" cy="0" r="1.5"/>
      </g>
      <ellipse cx="17" cy="39.5" rx="5" ry="1.5" fill="black" opacity="0.2"/>
    </svg>`,

  mystery: (color, glow) => `
    <svg width="32" height="38" viewBox="0 0 32 38" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="myst-grad" cx="50%" cy="30%">
          <stop offset="0%" stop-color="#ff00ff" stop-opacity="0.7"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="1"/>
        </radialGradient>
        <filter id="myst-glow">
          <feGaussianBlur stdDeviation="3" result="blur"/>
          <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
        </filter>
      </defs>
      <!-- Pulsing star pin -->
      <path d="M16 36 C16 36 6 24 6 16 C6 10.5 10.5 6 16 6 C21.5 6 26 10.5 26 16 C26 24 16 36 16 36Z" fill="url(#myst-grad)" filter="url(#myst-glow)"/>
      <!-- Question / relic symbol -->
      <text x="16" y="21" text-anchor="middle" font-size="13" font-weight="bold" fill="white" opacity="0.95">?</text>
      <!-- Sparkles -->
      <circle cx="22" cy="9" r="1.5" fill="#ff00ff" opacity="0.8"/>
      <circle cx="10" cy="11" r="1" fill="#00f5ff" opacity="0.8"/>
      <circle cx="24" cy="20" r="1" fill="white" opacity="0.6"/>
      <ellipse cx="16" cy="37" rx="4" ry="1.5" fill="black" opacity="0.2"/>
    </svg>`,

  fossil: (color, glow) => `
    <svg width="32" height="38" viewBox="0 0 32 38" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 36 C16 36 5 25 5 16.5 C5 10.6 10 6 16 6 C22 6 27 10.6 27 16.5 C27 25 16 36 16 36Z" fill="${color}"/>
      <path d="M16 36 C16 36 5 25 5 16.5 C5 10.6 10 6 16 6 C22 6 27 10.6 27 16.5 C27 25 16 36 16 36Z" fill="none" stroke="rgba(255,255,255,0.3)" stroke-width="1.2"/>
      <!-- Spiral shell -->
      <path d="M16 14 C16 14 14 15 14 17 C14 19 15.5 20 17 19 C18.5 18 18.5 15 16 14" fill="none" stroke="white" stroke-width="1.5" opacity="0.8"/>
      <circle cx="16" cy="17" r="1.5" fill="white" opacity="0.6"/>
      <ellipse cx="16" cy="37" rx="4" ry="1.5" fill="black" opacity="0.2"/>
    </svg>`,

  default: (color) => `
    <svg width="28" height="34" viewBox="0 0 28 34" xmlns="http://www.w3.org/2000/svg">
      <path d="M14 32 C14 32 4 22 4 14 C4 8.5 8.5 4 14 4 C19.5 4 24 8.5 24 14 C24 22 14 32 14 32Z" fill="${color}"/>
      <circle cx="14" cy="13" r="5" fill="white" opacity="0.3"/>
      <circle cx="12" cy="11" r="2" fill="white" opacity="0.5"/>
      <ellipse cx="14" cy="33" rx="4" ry="1.2" fill="black" opacity="0.2"/>
    </svg>`,
};

// Map legality/type to icon style
function getIconType(loc) {
  const minerals = (loc.minerals_found || []).join(" ").toLowerCase();
  const name = (loc.name || "").toLowerCase();

  if (minerals.includes("fossil") || name.includes("fossil")) return "fossil";
  if (minerals.includes("crystal") || minerals.includes("quartz") || minerals.includes("amethyst") || minerals.includes("tourmaline")) return "crystal";
  if (minerals.includes("geode") || minerals.includes("agate") || minerals.includes("jasper") || minerals.includes("chalcedony")) return "geode";
  if (loc.site_type === "mine" || loc.site_type === "quarry" || name.includes("mine") || name.includes("quarry")) return "mine";
  if (loc.legality_status === "High Risk" || !loc.minerals_found?.length) return "mystery";
  return "geode"; // Default geological pin
}

function getLegalityColor(loc, isSelected) {
  if (isSelected) return { fill: "#a855f7", glow: "#a855f7" };
  switch (loc.legality_status) {
    case "Safe Public":   return { fill: "#10b981", glow: "#10b981" };
    case "Likely Legal":  return { fill: "#3b82f6", glow: "#3b82f6" };
    case "Use Caution":   return { fill: "#f59e0b", glow: "#f59e0b" };
    case "High Risk":     return { fill: "#ef4444", glow: "#ef4444" };
    default:              return { fill: "#6366f1", glow: "#6366f1" };
  }
}

export function createGeoLocationIcon(loc, isSelected = false) {
  const iconType = getIconType(loc);
  const { fill, glow } = getLegalityColor(loc, isSelected);
  const svgFn = MINERAL_ICONS[iconType] || MINERAL_ICONS.default;
  const svg = svgFn(fill, glow);

  const size = isSelected ? [38, 44] : [32, 38];
  const anchor = [size[0] / 2, size[1]];

  return L.divIcon({
    html: `<div style="filter: drop-shadow(0 4px 8px ${fill}80); transition: transform 0.15s; ${isSelected ? 'transform: scale(1.25)' : ''}">${svg}</div>`,
    className: "",
    iconSize: size,
    iconAnchor: anchor,
    tooltipAnchor: [0, -size[1] + 8],
  });
}

export function createGeoClusterIcon(count) {
  const size = count < 10 ? 38 : count < 100 ? 46 : 54;
  return L.divIcon({
    html: `
      <div style="
        width:${size}px;height:${size}px;
        background: radial-gradient(circle at 35% 35%, rgba(0,245,255,0.9), rgba(139,0,255,0.85));
        border: 2.5px solid rgba(255,255,255,0.6);
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-weight: 800; font-size: ${count < 100 ? 13 : 10}px;
        box-shadow: 0 0 16px rgba(0,245,255,0.5), 0 3px 14px rgba(0,0,0,0.35);
        letter-spacing: -0.3px;
        position: relative;
      ">
        ${count}
        <div style="position:absolute;inset:-4px;border-radius:50%;border:2px solid rgba(0,245,255,0.3);animation: none;"></div>
      </div>`,
    className: "",
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
  });
}