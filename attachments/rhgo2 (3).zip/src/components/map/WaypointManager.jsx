import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { X, MapPin, Trash2, Plus, Check, WifiOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { enqueueOperation } from "@/components/offline/SyncEngine";

const WAYPOINT_COLORS = [
  "#a855f7", "#00f5ff", "#f59e0b", "#10b981", "#ef4444", "#3b82f6", "#f97316",
];

export default function WaypointManager({ pendingLatLng, onClose, onSaved }) {
  const [waypoints, setWaypoints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: "", notes: "", color: WAYPOINT_COLORS[0] });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadWaypoints();
  }, []);

  // Auto-open form when a pending lat/lng is provided from map click
  useEffect(() => {
    if (pendingLatLng) {
      setShowForm(true);
      setForm(f => ({ ...f, name: "", notes: "" }));
    }
  }, [pendingLatLng]);

  async function loadWaypoints() {
    setLoading(true);
    const wpts = await base44.entities.SavedMapConfig.list("-created_date", 100);
    setWaypoints(wpts);
    setLoading(false);
  }

  async function handleSave() {
    if (!form.name.trim()) return;
    setSaving(true);

    const waypointData = {
      name: form.name.trim(),
      notes: form.notes || undefined,
      color: form.color,
      center_lat: pendingLatLng?.lat,
      center_lng: pendingLatLng?.lng,
      zoom_level: 10,
      config_type: "waypoint",
    };

    if (navigator.onLine) {
      await base44.entities.SavedMapConfig.create(waypointData);
    } else {
      // Queue for sync when connectivity returns
      await enqueueOperation("SavedMapConfig", "create", waypointData);
      // Optimistically add to local list
      setWaypoints(prev => [
        { ...waypointData, id: `offline_${Date.now()}`, _offline: true },
        ...prev,
      ]);
    }

    setSaving(false);
    setShowForm(false);
    setForm({ name: "", notes: "", color: WAYPOINT_COLORS[0] });
    if (navigator.onLine) await loadWaypoints();
    onSaved?.();
  }

  async function handleDelete(id) {
    await base44.entities.SavedMapConfig.delete(id);
    await loadWaypoints();
    onSaved?.();
  }

  return (
    <div className="p-4 space-y-4 h-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-white/90 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-purple-400" /> Waypoints
        </h3>
        <button onClick={onClose} aria-label="Close waypoint manager" title="Close" className="text-white/30 hover:text-white/60 transition-all">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Add form */}
      {showForm ? (
        <div className="space-y-3 p-3 rounded-xl bg-white/[0.03] border border-white/8">
          <p className="text-xs text-white/40">
            {pendingLatLng
              ? `📍 ${pendingLatLng.lat.toFixed(5)}, ${pendingLatLng.lng.toFixed(5)}`
              : "New waypoint"}
          </p>
          <Input
            placeholder="Waypoint name *"
            value={form.name}
            onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
            className="bg-white/5 border-white/10 text-white text-sm"
          />
          <Textarea
            placeholder="Notes (optional)"
            value={form.notes}
            onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            className="bg-white/5 border-white/10 text-white text-sm resize-none h-16"
          />
          <div className="flex gap-1.5">
            {WAYPOINT_COLORS.map(c => (
              <button key={c} onClick={() => setForm(f => ({ ...f, color: c }))}
                aria-label={`Select color ${c}`}
                title={`Select color ${c}`}
                className="w-6 h-6 rounded-full flex items-center justify-center transition-transform hover:scale-110"
                style={{ background: c, outline: form.color === c ? `2px solid white` : "none", outlineOffset: 2 }}>
                {form.color === c && <Check className="w-3 h-3 text-white" />}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowForm(false)}
              className="flex-1 border-white/10 text-white/50 text-xs">Cancel</Button>
            <Button size="sm" onClick={handleSave} disabled={saving || !form.name.trim()}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white text-xs">
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        </div>
      ) : (
        <button onClick={() => setShowForm(true)}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-medium text-purple-400 border border-purple-500/30 hover:bg-purple-500/10 transition-all">
          <Plus className="w-3.5 h-3.5" /> Add Waypoint
        </button>
      )}

      {/* List */}
      <div className="space-y-2">
        {loading ? (
          <p className="text-xs text-white/30 text-center py-4">Loading...</p>
        ) : waypoints.length === 0 ? (
          <p className="text-xs text-white/25 text-center py-6">
            No waypoints yet.<br />Tap the map or click Add Waypoint.
          </p>
        ) : (
          waypoints.map(wp => (
            <div key={wp.id} className={`flex items-start gap-2.5 p-2.5 rounded-xl border ${wp._offline ? "bg-amber-500/5 border-amber-500/20" : "bg-white/[0.03] border-white/6"}`}>
              <div className="w-3.5 h-3.5 rounded-full shrink-0 mt-0.5" style={{ background: wp.color || "#a855f7" }} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="text-sm font-medium text-white/85 truncate">{wp.name}</p>
                  {wp._offline && (
                    <span className="flex items-center gap-0.5 text-[9px] text-amber-400 shrink-0">
                      <WifiOff className="w-2.5 h-2.5" /> queued
                    </span>
                  )}
                </div>
                {wp.center_lat && (
                  <p className="text-[10px] text-white/35 mt-0.5">
                    {wp.center_lat?.toFixed(4)}, {wp.center_lng?.toFixed(4)}
                  </p>
                )}
                {wp.notes && <p className="text-xs text-white/45 mt-0.5 leading-snug">{wp.notes}</p>}
              </div>
              <button onClick={() => handleDelete(wp.id)}
                aria-label="Delete waypoint"
                title="Delete waypoint"
                className="text-white/20 hover:text-red-400 transition-all p-1">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}