import React, { useState, useEffect, useCallback } from "react";
import { fetchCurrentWeather } from "@/services/weather/weatherService";
import { Loader2, CloudRain, Sun, Cloud, Wind, Thermometer, AlertTriangle, ShieldCheck, X, CloudSnow, Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const WX_ICONS = {
  Clear: Sun,
  Clouds: Cloud,
  Rain: CloudRain,
  Drizzle: CloudRain,
  Snow: CloudSnow,
  Thunderstorm: Zap,
  default: Cloud,
};

function getSafetyAlerts(weather, location) {
  const alerts = [];
  if (!weather) return alerts;

  const temp = weather.main?.temp;
  const windSpeed = weather.wind?.speed; // mph
  const condition = weather.weather?.[0]?.main;
  const visibility = weather.visibility; // meters
  const visibilityMiles = visibility != null ? (visibility / 1609.34).toFixed(1) : null;

  if (condition === "Thunderstorm") alerts.push({ level: "danger", msg: "⛈️ Thunderstorm active — avoid open ridges and exposed areas." });
  if (condition === "Snow") alerts.push({ level: "warning", msg: "❄️ Snow conditions — rocky surfaces may be icy and slippery." });
  if (condition === "Rain" || condition === "Drizzle") alerts.push({ level: "warning", msg: "🌧️ Wet conditions — watch for slippery rocks and flash flood risk." });
  if (windSpeed > 25) alerts.push({ level: "warning", msg: `💨 High winds (${Math.round(windSpeed)} mph) — secure loose equipment.` });
  if (temp !== undefined && temp < 32) alerts.push({ level: "warning", msg: `🥶 Freezing temps (${Math.round(temp)}°F) — hypothermia risk, dress in layers.` });
  if (temp !== undefined && temp > 100) alerts.push({ level: "danger", msg: `🔥 Extreme heat (${Math.round(temp)}°F) — carry extra water, limit exertion.` });
  if (visibilityMiles !== undefined && visibilityMiles !== null && parseFloat(visibilityMiles) < 1) alerts.push({ level: "warning", msg: `🌫️ Low visibility (${visibilityMiles} mi) — stay on marked trails.` });

  if (location?.difficulty === "expert" || location?.difficulty === "difficult") {
    alerts.push({ level: "info", msg: "🧗 Difficult terrain — helmets and proper footwear recommended." });
  }
  if (location?.hazards?.length > 0) {
    alerts.push({ level: "info", msg: `⚠️ Site hazards: ${location.hazards.slice(0, 3).join(", ")}.` });
  }

  return alerts;
}

export default function WeatherSafetyPanel({ location, onClose }) {
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [useCelsius, setUseCelsius] = useState(false);
  const [useMetric, setUseMetric] = useState(false);

  const fmtTemp = (f) => {
    if (f == null) return "—";
    return useCelsius ? `${Math.round((f - 32) * 5 / 9)}°C` : `${Math.round(f)}°F`;
  };
  const fmtWind = (mph) => {
    if (mph == null) return "—";
    return useMetric ? `${Math.round(mph * 1.609)} km/h` : `${Math.round(mph)} mph`;
  };

  const loadWeather = useCallback(async () => {
    if (!location?.latitude || !location?.longitude) return;
    setLoading(true);
    setError(null);
    setWeather(null);

    try {
      const data = await fetchCurrentWeather(location.latitude, location.longitude);
      setWeather(data);
      setLoading(false);
    } catch (err) {
      setError("Could not load weather data. Check your connection and try again.");
      setLoading(false);
    }
  }, [location?.latitude, location?.longitude]);

  useEffect(() => {
    loadWeather();
  }, [loadWeather]);

  const alerts = getSafetyAlerts(weather, location);
  const condition = weather?.weather?.[0]?.main || "default";
  const WxIcon = WX_ICONS[condition] || WX_ICONS.default;

  const safeCount = alerts.filter(a => a.level === "info").length;
  const warnCount = alerts.filter(a => a.level === "warning").length;
  const dangerCount = alerts.filter(a => a.level === "danger").length;

  return (
    <div className="absolute top-16 right-3 z-30 w-72 bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white">
        <div>
          <p className="text-xs font-bold uppercase tracking-wider opacity-80">Weather & Safety</p>
          <p className="text-sm font-semibold truncate max-w-[180px]">{location?.name}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setUseCelsius(v => !v)}
            className="text-[10px] font-bold px-2 py-0.5 rounded-full transition-all"
            style={{ background: "rgba(255,255,255,0.2)", color: "white" }}
          >
            {useCelsius ? "°C" : "°F"}
          </button>
          <button
            onClick={() => setUseMetric(v => !v)}
            className="text-[10px] font-bold px-2 py-0.5 rounded-full transition-all"
            style={{ background: "rgba(255,255,255,0.2)", color: "white" }}
          >
            {useMetric ? "km" : "mi"}
          </button>
          <button onClick={onClose} className="text-white/70 hover:text-white transition-colors" aria-label="Close">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {loading ? (
          <div className="flex items-center justify-center py-6 gap-2 text-gray-400">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Fetching weather...</span>
          </div>
        ) : error ? (
          <p className="text-sm text-red-400 text-center py-4">{error}</p>
        ) : weather ? (
          <>
            {/* Current conditions */}
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-sky-50 border border-sky-100 flex items-center justify-center">
                <WxIcon className="w-7 h-7 text-sky-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-800">{fmtTemp(weather.main?.temp)}</p>
                <p className="text-xs text-gray-500 capitalize">{weather.weather?.[0]?.description || condition}</p>
                {weather.main?.feels_like && (
                  <p className="text-[11px] text-gray-400">Feels like {fmtTemp(weather.main.feels_like)}</p>
                )}
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-gray-50 rounded-xl p-2 border border-gray-100">
                <Wind className="w-3.5 h-3.5 text-gray-400 mx-auto mb-0.5" />
                <p className="text-xs font-bold text-gray-700">{fmtWind(weather.wind?.speed)}</p>
                <p className="text-[10px] text-gray-400">Wind</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-2 border border-gray-100">
                <CloudRain className="w-3.5 h-3.5 text-gray-400 mx-auto mb-0.5" />
                <p className="text-xs font-bold text-gray-700">{weather.main?.humidity ? `${weather.main.humidity}%` : "—"}</p>
                <p className="text-[10px] text-gray-400">Humidity</p>
              </div>
              <div className="bg-gray-50 rounded-xl p-2 border border-gray-100">
                <Thermometer className="w-3.5 h-3.5 text-gray-400 mx-auto mb-0.5" />
                <p className="text-xs font-bold text-gray-700">{weather.visibility ? `${(weather.visibility / 1000).toFixed(1)}km` : "—"}</p>
                <p className="text-[10px] text-gray-400">Visibility</p>
              </div>
            </div>
          </>
        ) : null}

        {/* Safety Alerts */}
        <div>
          <div className="flex items-center gap-2 mb-2">
            {dangerCount > 0
              ? <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
              : warnCount > 0
              ? <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
              : <ShieldCheck className="w-3.5 h-3.5 text-green-500" />
            }
            <span className="text-[11px] font-bold uppercase tracking-wider text-gray-500">Safety Alerts</span>
            {dangerCount > 0 && <Badge className="text-[9px] bg-red-100 text-red-700 border-red-200">{dangerCount} danger</Badge>}
            {warnCount > 0 && <Badge className="text-[9px] bg-amber-100 text-amber-700 border-amber-200">{warnCount} warning</Badge>}
          </div>

          {alerts.length === 0 ? (
            <div className="flex items-center gap-2 text-green-600 text-xs bg-green-50 rounded-xl p-3 border border-green-100">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              Conditions look good — safe to explore!
            </div>
          ) : (
            <div className="space-y-1.5">
              {alerts.map((a, i) => (
                <div
                  key={i}
                  className={`text-[11px] rounded-xl p-2.5 border leading-relaxed ${
                    a.level === "danger"
                      ? "bg-red-50 border-red-100 text-red-700"
                      : a.level === "warning"
                      ? "bg-amber-50 border-amber-100 text-amber-700"
                      : "bg-blue-50 border-blue-100 text-blue-700"
                  }`}
                >
                  {a.msg}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}