import React from "react";
import WebGLFallbackBanner from "./WebGLFallbackBanner";

/**
 * MapErrorBoundary — lightweight class-based error boundary for map failures.
 *
 * Catches errors that occur AFTER the WebGL probe passed (e.g. context lost
 * mid-session, style load failure, GPU driver crash). Renders a Leaflet
 * fallback + amber banner instead of crashing the page's ErrorBoundary.
 *
 * Usage:
 *   <MapErrorBoundary fallback={<WebGLFallbackMap {...props} />}>
 *     <MapLibreMap {...props} />
 *   </MapErrorBoundary>
 */
export default class MapErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("[MapErrorBoundary] Map render error caught:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // If a custom fallback is provided, use it; otherwise render a minimal
      // dark container with the amber banner so the page never shows a blank
      // or crashed state.
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div
          className="relative overflow-hidden"
          style={{
            height: this.props.height || "100%",
            borderRadius: 18,
            border: "1px solid rgba(90,228,183,0.20)",
            background: "#101e1e",
          }}
        >
          <WebGLFallbackBanner message="Map failed to load — showing standard view" />
          <div
            className="flex items-center justify-center"
            style={{ position: "absolute", inset: 0, top: 32, color: "rgba(90,228,183,0.4)", fontSize: 13 }}
          >
            Map unavailable on this device
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}