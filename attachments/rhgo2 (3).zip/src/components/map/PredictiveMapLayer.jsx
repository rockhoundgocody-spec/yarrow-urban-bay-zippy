import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const OPPORTUNITY_ICONS = {
  quartz_zone: '💎',
  gravel_bar: '🪨',
  glacial_erratic: '🧊',
  fluorite_district: '✨',
  shop_fallback: '🏪',
  museum_nearby: '🏛️',
  public_access_zone: '🟢',
};

const OPPORTUNITY_LABELS = {
  quartz_zone: 'Quartz Zone',
  gravel_bar: 'Gravel Bar',
  glacial_erratic: 'Glacial Erratic',
  fluorite_district: 'Fluorite District',
  shop_fallback: 'Rock Shop',
  museum_nearby: 'Museum',
  public_access_zone: 'Public Access',
};

export default function PredictiveMapLayer({ userLocation }) {
  const [opportunities, setOpportunities] = useState([]);
  const [toggles, setToggles] = useState({
    mineral_probability: true,
    geology_overlay: true,
    public_access: false,
    land_restrictions: true,
    hazards: true,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadPredictions = async () => {
      try {
        const res = await base44.functions.invoke('generateMapPredictions', {
          latitude: userLocation?.lat || 0,
          longitude: userLocation?.lng || 0,
        });
        setOpportunities(res.data?.predictions || []);
      } catch (err) {
        console.error('Prediction loading failed:', err);
      } finally {
        setLoading(false);
      }
    };

    loadPredictions();
  }, [userLocation]);

  const handleToggle = (key) => {
    setToggles({ ...toggles, [key]: !toggles[key] });
  };

  const filteredOpportunities = opportunities.filter((opp) => {
    if (toggles.public_access && opp.access_status !== 'public') return false;
    return true;
  });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-2xl p-6 space-y-4"
      style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
      <div className="flex items-center gap-2">
        <Zap className="w-4 h-4" style={{ color: '#F5B642' }} />
        <h3 className="text-sm font-bold" style={{ color: '#F5B642' }}>Predictive Opportunities</h3>
      </div>

      <p className="text-xs text-white/40">Confidence-based mineral zones, geology layers, and access info.</p>

      {/* Toggles */}
      <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/10">
        {Object.entries(toggles).map(([key, enabled]) => (
          <button
            key={key}
            onClick={() => handleToggle(key)}
            className="text-left px-3 py-2 rounded-lg text-xs font-medium transition-all"
            style={{
              background: enabled ? 'rgba(122,231,255,0.15)' : 'rgba(255,255,255,0.03)',
              border: enabled ? '1px solid rgba(122,231,255,0.3)' : '1px solid rgba(255,255,255,0.06)',
              color: enabled ? '#7AE7FF' : 'rgba(255,255,255,0.4)',
            }}>
            {key.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Opportunities */}
      {!loading && filteredOpportunities.length > 0 && (
        <div className="space-y-2 pt-3 border-t border-white/10">
          {filteredOpportunities.map((opp, i) => (
            <OpportunityCard key={i} opportunity={opp} />
          ))}
        </div>
      )}

      {!loading && filteredOpportunities.length === 0 && (
        <p className="text-xs text-white/30 italic">No opportunities match your filters.</p>
      )}

      <p className="text-[9px] text-white/30 border-t border-white/10 pt-3">
        ⚠️ Predictions use published data. Always verify access, get permission, and follow local laws.
      </p>
    </motion.div>
  );
}

function OpportunityCard({ opportunity }) {
  const confidenceColor =
    opportunity.confidence >= 80 ? '#00D68F' :
    opportunity.confidence >= 60 ? '#7AE7FF' : '#F5B642';

  const accessIcon = {
    public: '🟢',
    permit_required: '🟡',
    private_unknown: '🔴',
    fee_area: '💵',
  }[opportunity.access_status];

  return (
    <div className="rounded-lg p-3" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-start gap-2">
          <span className="text-lg">{OPPORTUNITY_ICONS[opportunity.opportunity_type]}</span>
          <div>
            <p className="text-xs font-bold text-white">{OPPORTUNITY_LABELS[opportunity.opportunity_type]}</p>
            <p className="text-[9px] text-white/50 mt-0.5">{opportunity.mineral_type}</p>
          </div>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded" style={{ background: confidenceColor + '20', color: confidenceColor }}>
            {opportunity.confidence}%
          </span>
          <span className="text-lg">{accessIcon}</span>
        </div>
      </div>

      <p className="text-[9px] text-white/50 leading-tight mb-2">{opportunity.description}</p>

      {opportunity.safety_warnings && opportunity.safety_warnings.length > 0 && (
        <div className="flex gap-1 flex-wrap">
          {opportunity.safety_warnings.map((warning, i) => (
            <span key={i} className="text-[8px] px-1.5 py-0.5 rounded" style={{ background: 'rgba(255,107,157,0.2)', color: '#FF6B9D' }}>
              {warning}
            </span>
          ))}
        </div>
      )}

      <p className="text-[8px] text-white/30 mt-2">📊 Source: {opportunity.source}</p>
    </div>
  );
}