import React, { useEffect, useRef, useState, useCallback } from "react";
import { X, MapPin, Navigation2, ChevronDown, ChevronUp, Loader2, Plus, CheckCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ParticleCanvas, { useParticleEmitter } from "../gamification/ParticleCanvas";

// ── Haversine distance (meters) ───────────────────────────────────────────────
function distanceMeter(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── Bearing from user to target (degrees, 0=North) ────────────────────────────
function bearing(lat1, lng1, lat2, lng2) {
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const y = Math.sin(dLng) * Math.cos(lat2 * Math.PI / 180);
  const x = Math.cos(lat1 * Math.PI / 180) * Math.sin(lat2 * Math.PI / 180) -
    Math.sin(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.cos(dLng);
  return ((Math.atan2(y, x) * 180 / Math.PI) + 360) % 360;
}

// ── Format distance for display ───────────────────────────────────────────────
function fmtDist(m) {
  return m < 1000 ? `${Math.round(m)}m` : `${(m / 1609.34).toFixed(1)}mi`;
}

// ── Pin type config ────────────────────────────────────────────────────────────
const PIN_STYLES = {
  deposit: { color: "#f59e0b", bg: "rgba(245,158,11,0.18)", icon: "💎", label: "Mineral Deposit" },
  vein:    { color: "#06b6d4", bg: "rgba(6,182,212,0.18)",  icon: "⛏",  label: "Vein Direction" },
  crumb:   { color: "#a78bfa", bg: "rgba(167,139,250,0.18)", icon: "🏴", label: "Community Breadcrumb" },
  mycrumb: { color: "#34d399", bg: "rgba(52,211,153,0.18)", icon: "📍", label: "Your Breadcrumb" },
};

// ── AR Pin overlay element ─────────────────────────────────────────────────────
function ARPin({ pin, screenX, screenY, distance, opacity, selected, onClick }) {
  const style = PIN_STYLES[pin.type] || PIN_STYLES.deposit;
  const size = Math.max(36, Math.min(60, 70 - distance / 80));

  return (
    <button
      onClick={onClick}
      aria-label={`${style.label}: ${pin.name}, ${fmtDist(distance)} away`}
      style={{
        position: "absolute",
        left: screenX,
        top: screenY,
        transform: "translate(-50%, -100%)",
        opacity,
        transition: "opacity 0.3s, transform 0.2s",
        zIndex: selected ? 50 : 30,
      }}
      className="flex flex-col items-center gap-0.5 group"
    >
      {/* Info bubble */}
      <div
        style={{
          background: selected ? style.color : style.bg,
          border: `1.5px solid ${style.color}`,
          backdropFilter: "blur(8px)",
          color: selected ? "#fff" : style.color,
          maxWidth: 160,
          minWidth: 80,
        }}
        className="px-2.5 py-1.5 rounded-xl text-[11px] font-semibold shadow-lg text-center leading-tight"
      >
        <div className="truncate">{pin.name}</div>
        {pin.minerals?.length > 0 && (
          <div className="text-[10px] font-normal opacity-80 truncate">{pin.minerals.slice(0, 2).join(", ")}</div>
        )}
        {pin.vein_direction && (
          <div className="text-[10px] font-normal opacity-80">↗ {pin.vein_direction}° · {pin.vein_depth || "?"} depth</div>
        )}
        <div className="text-[10px] font-normal opacity-70 mt-0.5">{fmtDist(distance)}</div>
      </div>
      {/* Stem + dot */}
      <div style={{ width: 2, height: 16, background: style.color, opacity: 0.7 }} />
      <div
        style={{
          width: size * 0.38,
          height: size * 0.38,
          background: style.color,
          border: "2px solid rgba(255,255,255,0.5)",
          borderRadius: "50%",
          boxShadow: `0 0 14px ${style.color}88`,
        }}
      >
        <span className="flex items-center justify-center w-full h-full text-[10px]">{style.icon}</span>
      </div>
    </button>
  );
}

// ── Vein direction indicator ───────────────────────────────────────────────────
function VeinDirectionArrow({ pin, screenX, screenY, opacity }) {
  if (!pin.vein_direction) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: screenX,
        top: screenY + 8,
        transform: "translate(-50%, 0)",
        opacity: opacity * 0.7,
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          width: 2,
          height: 40,
          background: `linear-gradient(to bottom, #06b6d4, transparent)`,
          transform: `rotate(${pin.vein_direction}deg)`,
          transformOrigin: "top center",
          boxShadow: "0 0 8px #06b6d488",
        }}
      />
    </div>
  );
}

// ── Compass strip (top) ────────────────────────────────────────────────────────
function CompassStrip({ heading }) {
  const ticks = [];
  for (let i = -60; i <= 60; i += 10) {
    const deg = ((heading + i) % 360 + 360) % 360;
    const cardinals = { 0: "N", 45: "NE", 90: "E", 135: "SE", 180: "S", 225: "SW", 270: "W", 315: "NW" };
    ticks.push({ i, deg, label: cardinals[deg] });
  }
  return (
    <div className="absolute top-14 left-0 right-0 z-40 flex justify-center pointer-events-none">
      <div
        style={{ background: "rgba(0,0,0,0.45)", backdropFilter: "blur(6px)" }}
        className="relative flex items-end gap-0 px-6 py-1 rounded-full overflow-hidden select-none"
      >
        {ticks.map(({ i, deg, label }) => (
          <div key={i} className="flex flex-col items-center" style={{ width: 22 }}>
            <span
              style={{
                color: label ? "#f59e0b" : "rgba(255,255,255,0.4)",
                fontSize: label ? 10 : 8,
                fontWeight: label ? 700 : 400,
              }}
            >
              {label || "|"}
            </span>
          </div>
        ))}
        {/* Center marker */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-full bg-amber-400 opacity-80" />
      </div>
    </div>
  );
}

// ── Geological vein canvas overlay ────────────────────────────────────────────
function VeinCanvas({ visiblePins, dims }) {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = dims.w;
    canvas.height = dims.h;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, dims.w, dims.h);

    visiblePins.forEach(pin => {
      if (pin.type !== "vein" || !pin.vein_direction) return;
      const { x, y, opacity } = pin.proj;
      const rad = (pin.vein_direction - 90) * Math.PI / 180;
      const len = Math.min(dims.h * 0.35, 160);

      ctx.save();
      ctx.globalAlpha = opacity * 0.7;
      const grad = ctx.createLinearGradient(
        x - Math.cos(rad) * len, y - Math.sin(rad) * len,
        x + Math.cos(rad) * len, y + Math.sin(rad) * len
      );
      grad.addColorStop(0, "transparent");
      grad.addColorStop(0.5, "#06b6d4");
      grad.addColorStop(1, "transparent");
      ctx.strokeStyle = grad;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = "#06b6d4";
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(x - Math.cos(rad) * len, y - Math.sin(rad) * len);
      ctx.lineTo(x + Math.cos(rad) * len, y + Math.sin(rad) * len);
      ctx.stroke();
      ctx.restore();
    });
  }, [visiblePins, dims]);

  return (
    <canvas
      ref={canvasRef}
      style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 20, width: dims.w, height: dims.h }}
    />
  );
}

// ── Main AR Overlay component ──────────────────────────────────────────────────
export default function AROverlay({ locations = [], fieldPins = [], userPos, onClose }) {
  const videoRef = useRef(null);
  const [heading, setHeading] = useState(0);
  const [pitch, setPitch] = useState(0);   // device tilt (beta)
  const [ready, setCameraReady] = useState(false);
  const [error, setError] = useState("");
  const [selectedPin, setSelectedPin] = useState(null);
  const [showList, setShowList] = useState(false);
  const [dims, setDims] = useState({ w: window.innerWidth, h: window.innerHeight });
  const [logging, setLogging] = useState(false);
  const [loggedPin, setLoggedPin] = useState(null);
  const streamRef = useRef(null);
  const orientRef = useRef({ alpha: 0, beta: 0 });
  const { canvasRef: particleCanvasRef, emit } = useParticleEmitter();

  // Log a field find for the selected pin, award XP via particle burst
  const handleLogFind = useCallback(async () => {
    if (!selectedPin || logging) return;
    setLogging(true);
    const note = {
      specimen_name: selectedPin.minerals?.[0] || "Unknown",
      location_name: selectedPin.name,
      description: `AR field log at ${selectedPin.name}`,
      gps_latitude: selectedPin.lat,
      gps_longitude: selectedPin.lng,
      user_display_name: "AR Log",
    };
    await base44.entities.Spotting.create(note);
    emit("burst", { x: dims.w / 2, y: dims.h / 2, color: "#00D68F" });
    setTimeout(() => emit("xp", { x: dims.w / 2, y: dims.h * 0.35 }), 200);
    setLoggedPin(selectedPin);
    setSelectedPin(null);
    setLogging(false);
    setTimeout(() => setLoggedPin(null), 3000);
  }, [selectedPin, logging, emit, dims]);

  // Camera & orientation setup
  useEffect(() => {
    let stream;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          streamRef.current = stream;
          setCameraReady(true);
        }
      } catch (e) {
        setError("Camera permission denied. Please allow camera access to use AR mode.");
      }
    })();

    // Device orientation — prefer AbsoluteOrientation for true compass heading
    const handleOrient = (e) => {
      orientRef.current = { alpha: e.alpha || 0, beta: e.beta || 0 };
      setHeading((e.alpha || 0));
      setPitch((e.beta || 0));
    };

    if (window.DeviceOrientationEvent) {
      // iOS 13+ requires permission
      if (typeof DeviceOrientationEvent.requestPermission === "function") {
        DeviceOrientationEvent.requestPermission()
          .then(() => window.addEventListener("deviceorientation", handleOrient))
          .catch(() => {});
      } else {
        window.addEventListener("deviceorientation", handleOrient);
      }
    }

    const handleResize = () => setDims({ w: window.innerWidth, h: window.innerHeight });
    window.addEventListener("resize", handleResize);

    return () => {
      if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
      window.removeEventListener("deviceorientation", handleOrient);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Build AR pins from locations + field pins
  const arPins = React.useMemo(() => {
    if (!userPos) return [];
    const pins = [];

    // Mineral deposit locations (within 10 miles)
    locations.forEach((loc) => {
      if (!loc.latitude || !loc.longitude) return;
      const dist = distanceMeter(userPos[0], userPos[1], loc.latitude, loc.longitude);
      if (dist > 16093) return; // 10 miles
      pins.push({
        id: `loc-${loc.id}`,
        type: "deposit",
        name: loc.name,
        lat: loc.latitude,
        lng: loc.longitude,
        minerals: loc.minerals_found || [],
        vein_direction: loc.vein_direction || null,
        vein_depth: loc.vein_depth || null,
        dist,
      });
    });

    // Community + personal breadcrumbs from field pins
    fieldPins.forEach((pin) => {
      if (!pin.lat || !pin.lng) return;
      const dist = distanceMeter(userPos[0], userPos[1], pin.lat, pin.lng);
      if (dist > 5000) return; // 5km
      pins.push({
        id: `pin-${pin.id}`,
        type: pin.isOwn !== false ? "mycrumb" : "crumb",
        name: pin.title || "Breadcrumb",
        lat: pin.lat,
        lng: pin.lng,
        minerals: [],
        notes: pin.notes,
        dist,
      });
    });

    // Sort by distance
    return pins.sort((a, b) => a.dist - b.dist);
  }, [locations, fieldPins, userPos]);

  // Project a lat/lng to screen XY based on heading
  const project = useCallback((lat, lng) => {
    if (!userPos) return null;
    const bear = bearing(userPos[0], userPos[1], lat, lng);
    const dist = distanceMeter(userPos[0], userPos[1], lat, lng);

    // Angular difference between camera heading and target bearing
    let angleDiff = bear - heading;
    if (angleDiff > 180) angleDiff -= 360;
    if (angleDiff < -180) angleDiff += 360;

    // Field of view (horizontal ~60°, vertical ~45°)
    const hFov = 60;
    if (Math.abs(angleDiff) > hFov / 2 + 10) return null; // out of view

    const screenX = dims.w / 2 + (angleDiff / (hFov / 2)) * (dims.w / 2);

    // Vertical: farther objects appear higher, tilt compensates
    const pitchOffset = (pitch - 60) * 2; // 60° = horizon
    const distFactor = Math.max(0.1, 1 - dist / 16093);
    const screenY = dims.h * 0.5 - distFactor * dims.h * 0.25 + pitchOffset;

    // Opacity fades with distance
    const opacity = Math.max(0.25, Math.min(1, 1 - dist / 14000));

    return { x: screenX, y: screenY, opacity };
  }, [userPos, heading, pitch, dims]);

  const visiblePins = React.useMemo(() => {
    // ⚡ Bolt: Single-pass loop to avoid allocating temporary wrapper objects for pins that are out of view.
    // This reduces garbage collection overhead in this high-frequency AR render loop.
    const visible = [];
    for (let i = 0; i < arPins.length; i++) {
      const pin = arPins[i];
      const proj = project(pin.lat, pin.lng);
      if (proj !== null) {
        visible.push({ ...pin, proj });
      }
    }
    return visible;
  }, [arPins, project]);

  return (
    <div className="fixed inset-0 z-[9999] bg-black overflow-hidden">
      {/* Camera feed */}
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        style={{ width: "100%", height: "100%", objectFit: "cover", position: "absolute", inset: 0 }}
      />

      {/* Dark vignette edges */}
      <div
        style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.5) 100%)",
        }}
      />

      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/80">
          <div className="text-white text-center px-8">
            <div className="text-4xl mb-4">📷</div>
            <p className="text-sm opacity-70">{error}</p>
            <button onClick={onClose} className="mt-6 px-6 py-2 bg-amber-500 text-white rounded-full text-sm font-semibold">Close</button>
          </div>
        </div>
      )}

      {!ready && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/70">
          <Loader2 className="w-8 h-8 text-amber-400 animate-spin" />
        </div>
      )}

      {/* Compass */}
      <CompassStrip heading={heading} />

      {/* Close */}
      <button
        aria-label="Close AR Overlay"
        title="Close AR Overlay"
        onClick={onClose}
        className="absolute top-4 right-4 z-50 w-10 h-10 rounded-full bg-black/50 backdrop-blur-sm text-white flex items-center justify-center border border-white/20"
      >
        <X className="w-5 h-5" />
      </button>

      {/* AR mode label */}
      <div className="absolute top-4 left-4 z-50 px-3 py-1 rounded-full bg-amber-500/80 text-white text-xs font-bold tracking-wide backdrop-blur-sm">
        AR MODE
      </div>

      {/* No location warning */}
      {!userPos && ready && (
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 z-40 px-4 py-3 rounded-xl bg-black/60 border border-amber-500/40 text-amber-300 text-xs text-center max-w-[200px] backdrop-blur-sm">
          <Navigation2 className="w-4 h-4 mx-auto mb-1" />
          Enable location on the map first to see AR pins
        </div>
      )}

      {/* Particle canvas */}
      <ParticleCanvas canvasRef={particleCanvasRef} style={{ zIndex: 60 }} />

      {/* Geological vein canvas */}
      <VeinCanvas visiblePins={visiblePins} dims={dims} />

      {/* Log success toast */}
      {loggedPin && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-semibold text-emerald-300"
          style={{ background: "rgba(0,214,143,0.15)", border: "1px solid rgba(0,214,143,0.4)", backdropFilter: "blur(10px)" }}>
          <CheckCircle className="w-4 h-4" />
          Logged: {loggedPin.name}
        </div>
      )}

      {/* AR Pins */}
      {visiblePins.map((pin) => (
        <React.Fragment key={pin.id}>
          <ARPin
            pin={pin}
            screenX={pin.proj.x}
            screenY={pin.proj.y}
            distance={pin.dist}
            opacity={pin.proj.opacity}
            selected={selectedPin?.id === pin.id}
            onClick={() => setSelectedPin(selectedPin?.id === pin.id ? null : pin)}
          />
          {pin.type === "vein" && (
            <VeinDirectionArrow pin={pin} screenX={pin.proj.x} screenY={pin.proj.y} opacity={pin.proj.opacity} />
          )}
        </React.Fragment>
      ))}

      {/* Selected pin detail card */}
      {selectedPin && (
        <div
          className="absolute bottom-28 left-4 right-4 z-50 rounded-2xl p-4 border text-white"
          style={{ background: "rgba(10,10,20,0.85)", backdropFilter: "blur(12px)", borderColor: PIN_STYLES[selectedPin.type]?.color + "55" }}
        >
          <div className="flex items-start justify-between gap-2 mb-2">
            <div>
              <div className="font-bold text-sm">{selectedPin.name}</div>
              <div className="text-[11px] opacity-60 mt-0.5">{PIN_STYLES[selectedPin.type]?.label} · {fmtDist(selectedPin.dist)}</div>
            </div>
            <button
              aria-label="Close details"
              title="Close details"
              onClick={() => setSelectedPin(null)}
              className="text-white/40 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          {selectedPin.minerals?.length > 0 && (
            <div className="flex flex-wrap gap-1 mb-2">
              {selectedPin.minerals.map((m) => (
                <span key={m} className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">{m}</span>
              ))}
            </div>
          )}
          {selectedPin.vein_direction && (
            <div className="text-[11px] text-cyan-300">⛏ Vein: {selectedPin.vein_direction}° azimuth{selectedPin.vein_depth ? ` · ${selectedPin.vein_depth} depth` : ""}</div>
          )}
          {selectedPin.notes && (
            <div className="text-[11px] opacity-60 mt-1">📝 {selectedPin.notes}</div>
          )}
          <button
            onClick={handleLogFind}
            disabled={logging}
            className="mt-3 w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-bold transition-all"
            style={{ background: "rgba(0,214,143,0.18)", border: "1px solid rgba(0,214,143,0.4)", color: "#34d399" }}
          >
            {logging ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
            {logging ? "Logging…" : "Log Find Here"}
          </button>
        </div>
      )}

      {/* Bottom: pin count + toggle list */}
      <div className="absolute bottom-6 left-4 right-4 z-50">
        <button
          onClick={() => setShowList((v) => !v)}
          aria-expanded={showList}
          aria-label={showList ? "Hide nearby pins list" : "Show nearby pins list"}
          className="w-full flex items-center justify-between px-4 py-3 rounded-2xl border border-white/15 text-white text-sm font-semibold"
          style={{ background: "rgba(0,0,0,0.6)", backdropFilter: "blur(10px)" }}
        >
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>{visiblePins.length} pins in view</span>
            <span className="text-white/40 font-normal">· {arPins.length} nearby</span>
          </div>
          {showList ? <ChevronDown className="w-4 h-4 opacity-50" /> : <ChevronUp className="w-4 h-4 opacity-50" />}
        </button>

        {showList && (
          <div
            className="mt-2 rounded-2xl border border-white/10 overflow-hidden"
            style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(12px)", maxHeight: 200, overflowY: "auto" }}
          >
            {arPins.slice(0, 12).map((pin) => {
              const style = PIN_STYLES[pin.type] || PIN_STYLES.deposit;
              return (
                <button
                  key={pin.id}
                  onClick={() => { setSelectedPin(pin); setShowList(false); }}
                  aria-label={`Select ${style.label}: ${pin.name}, ${fmtDist(pin.dist)} away`}
                  className="w-full flex items-center gap-3 px-4 py-2.5 hover:bg-white/5 transition-colors text-left border-b border-white/5 last:border-0"
                >
                  <span className="text-base" aria-hidden="true">{style.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-semibold text-white truncate">{pin.name}</div>
                    {pin.minerals?.length > 0 && <div className="text-[10px] opacity-50 truncate">{pin.minerals.slice(0, 3).join(", ")}</div>}
                  </div>
                  <span className="text-[10px] opacity-50 shrink-0">{fmtDist(pin.dist)}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}