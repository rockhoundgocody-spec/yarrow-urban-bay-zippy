import { useEffect, useState } from "react";
import { useMap, useMapEvents, Polygon } from "react-leaflet";
import L from "leaflet";

// Draws a polygon by clicking points on the map. 
// onComplete(latLngs) called when user closes polygon (3+ points).
export default function PolygonDrawer({ active, onComplete, onCancel }) {
  const [points, setPoints] = useState([]);
  const map = useMap();

  useEffect(() => {
    if (!active) { setPoints([]); return; }
    map.getContainer().style.cursor = "crosshair";
    return () => { map.getContainer().style.cursor = ""; };
  }, [active, map]);

  useMapEvents({
    click(e) {
      if (!active) return;
      setPoints(prev => [...prev, [e.latlng.lat, e.latlng.lng]]);
    },
    dblclick(e) {
      if (!active || points.length < 3) return;
      e.originalEvent.preventDefault();
      onComplete(points);
      setPoints([]);
    },
  });

  if (!active || points.length === 0) return null;

  return (
    <>
      {/* Draw lines between points */}
      {points.length >= 2 && (
        <Polygon
          positions={points}
          pathOptions={{ color: "#f59e0b", weight: 2, dashArray: "6,4", fillColor: "#f59e0b", fillOpacity: 0.12 }}
        />
      )}
      {/* Dot markers */}
      {points.map((p, i) => {
        const icon = L.divIcon({
          className: "",
          html: `<div style="width:10px;height:10px;border-radius:50%;background:#f59e0b;border:2px solid white;box-shadow:0 1px 4px rgba(0,0,0,0.4)"></div>`,
          iconAnchor: [5, 5],
        });
        return null; // Leaflet divIcon via JS only, skip for simplicity
      })}
    </>
  );
}

// Renders a completed filter polygon
export function FilterPolygon({ positions, onClear }) {
  if (!positions || positions.length < 3) return null;
  return (
    <Polygon
      positions={positions}
      pathOptions={{ color: "#f59e0b", weight: 2.5, fillColor: "#f59e0b", fillOpacity: 0.1 }}
      eventHandlers={{ dblclick: onClear }}
    />
  );
}

// Point-in-polygon check (ray casting)
export function pointInPolygon(lat, lng, polygon) {
  let inside = false;
  const n = polygon.length;
  for (let i = 0, j = n - 1; i < n; j = i++) {
    const [yi, xi] = polygon[i];
    const [yj, xj] = polygon[j];
    if ((yi > lat) !== (yj > lat) && lng < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}