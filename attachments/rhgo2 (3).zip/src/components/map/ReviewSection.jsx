import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star, Loader2, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";

function StarRating({ value, onChange, size = "w-5 h-5" }) {
  const [hover, setHover] = useState(0);
  return (
    <div className="flex gap-0.5">
      {[1,2,3,4,5].map(r => (
        <button
          key={r}
          type="button"
          onClick={() => onChange(r)}
          onMouseEnter={() => setHover(r)}
          onMouseLeave={() => setHover(0)}
          className="p-0.5"
        >
          <Star className={cn(size, "transition-colors", (hover || value) >= r ? "fill-amber-400 text-amber-400" : "text-white/20")} />
        </button>
      ))}
    </div>
  );
}

export default function ReviewSection({ location, user }) {
  const queryClient = useQueryClient();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [commentErr, setCommentErr] = useState("");

  const { data: reviews = [], isLoading } = useQuery({
    queryKey: ["reviews-v2", location.id],
    queryFn: () => base44.entities.Review.filter({ location_id: location.id }, "-created_date", 50),
  });

  const userReview = user ? reviews.find(r => r.created_by === user.email) : null;

  const submitMutation = useMutation({
    mutationFn: () => base44.functions.invoke("submitReview", {
      location_id: location.id,
      rating,
      comment: comment.trim(),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reviews-v2", location.id] });
      queryClient.invalidateQueries({ queryKey: ["locations"] });
    },
  });

  const handleSubmit = () => {
    if (comment.length > 1000) { setCommentErr("Max 1000 characters"); return; }
    setCommentErr("");
    submitMutation.mutate();
  };

  // Pre-fill if editing existing
  React.useEffect(() => {
    if (userReview) {
      setRating(userReview.rating);
      setComment(userReview.comment || "");
    }
  }, [userReview?.id]);

  const avgRating = reviews.length > 0
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : null;

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="flex items-center gap-3">
        <p className="text-xs font-semibold text-white/60">Reviews</p>
        {avgRating && (
          <div className="flex items-center gap-1.5">
            <div className="flex gap-0.5">
              {[1,2,3,4,5].map(i => (
                <Star key={i} className={cn("w-3 h-3", i <= Math.round(avgRating) ? "fill-amber-400 text-amber-400" : "text-white/20")} />
              ))}
            </div>
            <span className="text-xs text-amber-400 font-semibold">{avgRating}</span>
            <span className="text-[10px] text-white/30">({reviews.length})</span>
          </div>
        )}
      </div>

      {/* Submit / Edit Form */}
      {!user ? (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-white/[0.03] border border-white/5 text-xs text-white/40">
          <LogIn className="w-3.5 h-3.5" /> Sign in to leave a review
        </div>
      ) : (
        <div className="space-y-2 bg-white/[0.03] rounded-xl p-3 border border-white/5">
          <p className="text-[11px] text-white/50">{userReview ? "Update your review" : "Leave a review"}</p>
          <StarRating value={rating} onChange={setRating} />
          <Textarea
            value={comment}
            onChange={e => { setComment(e.target.value); setCommentErr(""); }}
            placeholder="Share your experience... (optional)"
            className="bg-white/5 border-white/10 text-white text-xs resize-none"
            rows={2}
            maxLength={1000}
          />
          {commentErr && <p className="text-red-400 text-[10px]">{commentErr}</p>}
          <div className="flex items-center justify-between">
            <span className={`text-[10px] ${comment.length > 900 ? "text-orange-400" : "text-white/20"}`}>{comment.length}/1000</span>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={submitMutation.isPending}
              className="h-7 text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 hover:bg-amber-500/30"
            >
              {submitMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-1" /> : null}
              {userReview ? "Update" : "Post"}
            </Button>
          </div>
        </div>
      )}

      {/* Review list */}
      {isLoading ? (
        <div className="flex justify-center py-3"><Loader2 className="w-4 h-4 text-amber-400 animate-spin" /></div>
      ) : reviews.length > 0 ? (
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {reviews.map(r => (
            <div key={r.id} className="p-2.5 rounded-lg bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between mb-1">
                <div className="flex gap-0.5">
                  {[1,2,3,4,5].map(i => (
                    <Star key={i} className={cn("w-2.5 h-2.5", i <= r.rating ? "fill-amber-400 text-amber-400" : "text-white/20")} />
                  ))}
                </div>
                <span className="text-[10px] text-white/30">{r.created_by?.split("@")[0]}</span>
              </div>
              {r.comment && <p className="text-[11px] text-white/50 leading-relaxed">{r.comment}</p>}
            </div>
          ))}
        </div>
      ) : (
        <p className="text-[11px] text-white/30 text-center py-2">No reviews yet. Be the first!</p>
      )}
    </div>
  );
}