import { useState } from "react";
import { Marker, Popup, useMapEvents } from "react-leaflet";
import { canShowExactLocation, fuzzyCoords } from "@/lib/accessControl";
import L from "leaflet";
import { ThumbsUp, MapPin, Calendar, User } from "lucide-react";

// Rarity → color mapping
const RARITY_COLOR = {
  common:     "#6B7280",
  uncommon:   "#00D68F",
  rare:       "#7AE7FF",
  "very rare": "#D4AF37",
};

const RARITY_LABEL = {
  common: "⚪ Common", uncommon: "🟢 Uncommon", rare: "🔵 Rare", "very rare": "🟡 Very Rare",
};

function makeIcon(rarity) {
  const color = RARITY_COLOR[rarity] || "#7AE7FF";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="30" height="36" viewBox="0 0 30 36">
    <filter id="glow"><feGaussianBlur stdDeviation="1.5" result="coloredBlur"/><feMerge><feMergeNode in="coloredBlur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <path d="M15 0C6.716 0 0 6.716 0 15c0 10.5 15 21 15 21S30 25.5 30 15C30 6.716 23.284 0 15 0z" fill="${color}" opacity="0.9" filter="url(#glow)"/>
    <circle cx="15" cy="15" r="7" fill="rgba(255,255,255,0.25)"/>
    <circle cx="15" cy="15" r="4" fill="white" opacity="0.9"/>
  </svg>`;
  return L.divIcon({
    html: svg,
    iconSize: [30, 36],
    iconAnchor: [15, 36],
    popupAnchor: [0, -38],
    className: "",
  });
}

// Tap handler — places pin on map click for new find
function TapToPlace({ onPlace }) {
  useMapEvents({
    click(e) { onPlace({ lat: e.latlng.lat, lng: e.latlng.lng }); },
  });
  return null;
}

export default function VerifiedFindsLayer({ finds, pinMode, onPlace, onHelpful, currentUserEmail }) {
  const [selectedId, setSelectedId] = useState(null);

  return (
    <>
      {pinMode && <TapToPlace onPlace={onPlace} />}
      {finds.map((find) => {
        const showExact = canShowExactLocation(currentUserEmail, find);
        const coords = showExact
          ? { lat: find.latitude, lng: find.longitude }
          : fuzzyCoords(find.latitude, find.longitude);
        if (coords.lat == null) return null;
        return (
          <Marker
            key={find.id}
            position={[coords.lat, coords.lng]}
          icon={makeIcon(find.rarity)}
        >
          <Popup
            closeButton={false}
            className="verified-find-popup"
          >
            <div style={{
              background: "linear-gradient(145deg, rgba(8,10,20,0.98) 0%, rgba(12,16,28,0.97) 100%)",
              border: "1px solid rgba(122,231,255,0.20)",
              borderRadius: 16, padding: 14, minWidth: 220, maxWidth: 260,
              boxShadow: "0 8px 32px rgba(0,0,0,0.7)",
              color: "#fff", fontFamily: "inherit",
            }}>
              {/* Photo */}
              {find.photo_url && (
                <img src={find.photo_url} alt={find.mineral_name} style={{ width: "100%", height: 100, objectFit: "cover", borderRadius: 10, marginBottom: 10 }} />
              )}

              {/* Mineral + rarity */}
              <div className="flex items-start justify-between gap-2 mb-1">
                <span style={{ fontWeight: 800, fontSize: 15, color: "#fff", fontFamily: "'Sora', sans-serif" }}>{find.mineral_name}</span>
                <span style={{
                  fontSize: 9, fontWeight: 700, padding: "2px 7px", borderRadius: 20, letterSpacing: "0.08em", whiteSpace: "nowrap",
                  background: `${RARITY_COLOR[find.rarity]}22`, border: `1px solid ${RARITY_COLOR[find.rarity]}55`, color: RARITY_COLOR[find.rarity],
                }}>
                  {find.rarity?.toUpperCase()}
                </span>
              </div>

              {/* Location */}
              {find.locality_name && (
                <div className="flex items-center gap-1 mb-1">
                  <MapPin style={{ width: 11, height: 11, color: "rgba(122,231,255,0.6)", flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: "rgba(255,255,255,0.45)" }}>{find.locality_name}</span>
                </div>
              )}

              {/* Date + Finder */}
              <div className="flex items-center gap-3 mb-2">
                {find.visit_date && (
                  <div className="flex items-center gap-1">
                    <Calendar style={{ width: 10, height: 10, color: "rgba(255,255,255,0.3)" }} />
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>{find.visit_date}</span>
                  </div>
                )}
                {find.finder_display_name && (
                  <div className="flex items-center gap-1">
                    <User style={{ width: 10, height: 10, color: "rgba(255,255,255,0.3)" }} />
                    <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)" }}>{find.finder_display_name}</span>
                  </div>
                )}
              </div>

              {/* Description */}
              {find.description && (
                <p style={{ fontSize: 12, color: "rgba(255,255,255,0.55)", marginBottom: 10, lineHeight: 1.5 }}>
                  {find.description.slice(0, 120)}{find.description.length > 120 ? "…" : ""}
                </p>
              )}

              {/* Helpful */}
              <button
                onClick={() => onHelpful(find.id, find.helpful_count)}
                style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "6px 12px", borderRadius: 20,
                  background: "rgba(0,214,143,0.08)", border: "1px solid rgba(0,214,143,0.25)",
                  color: "#00D68F", fontSize: 12, cursor: "pointer", fontWeight: 600,
                }}
              >
                <ThumbsUp style={{ width: 12, height: 12 }} />
                Helpful · {find.helpful_count || 0}
              </button>
            </div>
          </Popup>
        </Marker>
        );
      })}
    </>
  );
}