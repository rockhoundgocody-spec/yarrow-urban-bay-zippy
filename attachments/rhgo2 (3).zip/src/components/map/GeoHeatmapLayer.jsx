import React, { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { escapeHtml } from "@/utils";
// Hex grid math — axial coordinates, flat-top orientation
// Inline subset of lib/hexGrid.js to avoid ESM issues inside L.Layer class
const HEX_ANGLES = [0, 60, 120, 180, 240, 300].map(d => d * Math.PI / 180);

// ── Smooth 6-stop probability palette (deep-space → ember) ───────────────────
function scoreToRGBA(score, alpha = 1) {
  // 0-100 → interpolate through: indigo → cobalt → teal → lime → amber → crimson
  const stops = [
    [0,   [67,  56, 202]],   // indigo-700
    [20,  [37, 99,  235]],   // blue-600
    [40,  [6,  182, 212]],   // cyan-500
    [58,  [16, 185, 129]],   // emerald-500
    [74,  [245,158,  11]],   // amber-500
    [88,  [239, 68,  68]],   // red-500
    [100, [220, 38, 127]],   // pink-600
  ];

  let lo = stops[0], hi = stops[stops.length - 1];
  for (let i = 0; i < stops.length - 1; i++) {
    if (score >= stops[i][0] && score <= stops[i + 1][0]) {
      lo = stops[i]; hi = stops[i + 1]; break;
    }
  }
  const t = lo[0] === hi[0] ? 0 : (score - lo[0]) / (hi[0] - lo[0]);
  const r = Math.round(lo[1][0] + (hi[1][0] - lo[1][0]) * t);
  const g = Math.round(lo[1][1] + (hi[1][1] - lo[1][1]) * t);
  const b = Math.round(lo[1][2] + (hi[1][2] - lo[1][2]) * t);
  return { r, g, b, css: `rgba(${r},${g},${b},${alpha})` };
}

// Land manager palette — vivid but not garish
const MGR_HEX = {
  BLM:           "#f59e0b",
  USFS:          "#22c55e",
  "State Land":  "#38bdf8",
  "State Park":  "#a78bfa",
  FWS:           "#06b6d4",
  NPS:           "#818cf8",
  Tribal:        "#fb923c",
  Private:       "#f87171",
  Unknown:       "#6b7280",
};

const MGR_LABEL = {
  BLM: "BLM", USFS: "Forest Svc", "State Land": "State Land",
  "State Park": "State Park", FWS: "Wildlife Refuge", NPS: "Natl Park",
  Tribal: "Tribal", Private: "Private", Unknown: "Unknown",
};

// Pre-built tooltip HTML cache
const tooltipCache = new Map();

function buildTooltip(cell) {
  if (tooltipCache.has(cell.key)) return tooltipCache.get(cell.key);

  const { r, g, b } = scoreToRGBA(cell.score);
  const scoreColor = `rgb(${r},${g},${b})`;
  const mgr = cell.dominant_manager || "Unknown";
  const mgrColor = MGR_HEX[mgr] || "#6b7280";
  const mgrLabel = MGR_LABEL[mgr] || mgr;
  const minerals = (cell.top_minerals || []).slice(0, 5);
  const pubPct = cell.public_fraction != null ? cell.public_fraction : "—";

  const tierBadge = cell.tier === "high"
    ? `<span style="background:rgba(239,68,68,0.18);color:#fca5a5;border:1px solid rgba(239,68,68,0.35)">● HIGH</span>`
    : cell.tier === "medium"
    ? `<span style="background:rgba(245,158,11,0.18);color:#fcd34d;border:1px solid rgba(245,158,11,0.35)">◈ MED</span>`
    : `<span style="background:rgba(99,102,241,0.18);color:#a5b4fc;border:1px solid rgba(99,102,241,0.35)">○ LOW</span>`;

  const lidarBadge = cell.lidar_score >= 1.3
    ? `<span style="background:rgba(0,245,255,0.12);color:#67e8f9;border:1px solid rgba(0,245,255,0.25)">▲ HIGH RELIEF</span>`
    : cell.lidar_score >= 1.1
    ? `<span style="background:rgba(34,197,94,0.12);color:#86efac;border:1px solid rgba(34,197,94,0.25)">◈ MOD RELIEF</span>`
    : "";

  const geoBadge = cell.geo_bonus >= 14
    ? `<span style="background:rgba(245,158,11,0.12);color:#fcd34d;border:1px solid rgba(245,158,11,0.25)">★ GEO BELT</span>`
    : "";

  const mineralRows = minerals.length
    ? minerals.map(m => `<span style="background:rgba(255,255,255,0.06);color:#d4d4d8;border:1px solid rgba(255,255,255,0.1);padding:1px 6px;border-radius:4px;font-size:9px">${escapeHtml(m)}</span>`).join("")
    : "";

  const html = `
    <div style="font-family:'Inter',system-ui;width:210px;background:linear-gradient(145deg,rgba(10,9,28,0.97),rgba(18,8,40,0.97));border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:12px;box-shadow:0 8px 32px rgba(0,0,0,0.6),0 0 0 1px rgba(255,255,255,0.04)">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div style="font-weight:700;font-size:20px;color:${scoreColor};letter-spacing:-0.03em;line-height:1">${cell.score}<span style="font-size:11px;color:rgba(255,255,255,0.3);font-weight:400">/100</span></div>
        <div style="display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end">
          <span style="font-size:8px;font-weight:700;letter-spacing:0.08em;padding:2px 6px;border-radius:20px">${tierBadge.replace(/<\/?span[^>]*>/g,'')}</span>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <div style="width:8px;height:8px;border-radius:50%;background:${mgrColor};box-shadow:0 0 6px ${mgrColor};flex-shrink:0"></div>
        <span style="font-size:11px;font-weight:600;color:${mgrColor}">${escapeHtml(mgrLabel)}</span>
        <span style="font-size:10px;color:rgba(255,255,255,0.25);margin-left:auto">${escapeHtml(pubPct)}% public</span>
      </div>
      <div style="font-size:10px;color:rgba(255,255,255,0.35);margin-bottom:8px">
        ${cell.sample_count} site${cell.sample_count !== 1 ? "s" : ""} · ${escapeHtml(cell.dominant_access || "Open")}
      </div>
      ${lidarBadge || geoBadge ? `
      <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px">
        ${lidarBadge ? `<span style="font-size:8px;font-weight:700;letter-spacing:0.06em;padding:2px 6px;border-radius:20px">${lidarBadge.replace(/<\/?span[^>]*>/g,'')}</span>` : ""}
        ${geoBadge ? `<span style="font-size:8px;font-weight:700;letter-spacing:0.06em;padding:2px 6px;border-radius:20px">${geoBadge.replace(/<\/?span[^>]*>/g,'')}</span>` : ""}
      </div>` : ""}
      ${mineralRows ? `<div style="display:flex;flex-wrap:wrap;gap:3px;border-top:1px solid rgba(255,255,255,0.06);padding-top:8px">${mineralRows}</div>` : ""}
    </div>`;

  tooltipCache.set(cell.key, html);
  return html;
}

// ── Canvas-based heatmap renderer — far faster than SVG rectangles ────────────
class CanvasHeatLayer extends L.Layer {
  constructor(cells, gridDeg, options = {}) {
    super();
    this._cells = cells;
    this._gridDeg = gridDeg;
    this._options = options;
    this._canvas = null;
    this._frame = null;
  }

  onAdd(map) {
    this._map = map;
    this._canvas = L.DomUtil.create("canvas", "geo-heatmap-canvas");
    Object.assign(this._canvas.style, {
      position: "absolute", top: 0, left: 0,
      pointerEvents: "none", zIndex: 200, opacity: 0,
      transition: "opacity 0.4s ease",
    });
    map.getPane("overlayPane").appendChild(this._canvas);
    map.on("viewreset moveend zoomend resize", this._redraw, this);
    this._redraw();
    requestAnimationFrame(() => { this._canvas.style.opacity = 1; });
  }

  onRemove(map) {
    if (this._canvas) {
      this._canvas.style.opacity = 0;
      setTimeout(() => this._canvas?.remove(), 400);
    }
    map.off("viewreset moveend zoomend resize", this._redraw, this);
  }

  updateCells(cells) {
    this._cells = cells;
    tooltipCache.clear();
    this._redraw();
  }

  _redraw() {
    if (!this._map || !this._canvas) return;
    if (this._frame) cancelAnimationFrame(this._frame);
    this._frame = requestAnimationFrame(() => this._paint());
  }

  _paint() {
    if (!this._map || !this._canvas) return;
    const map = this._map;
    const size = map.getSize();
    const canvas = this._canvas;
    canvas.width = size.x;
    canvas.height = size.y;

    // Reposition canvas to map pane origin
    const topLeft = map.containerPointToLayerPoint([0, 0]);
    L.DomUtil.setPosition(canvas, topLeft);

    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, size.x, size.y);

    // Hex circumradius in degrees (flat-top: circumradius = gridDeg * 0.577)
    const hexR = (this._gridDeg / 2) * 1.155;
    const cells = this._cells;

    for (let i = 0; i < cells.length; i++) {
      const cell = cells[i];

      // Compute 6 hex corner points in pixel space (flat-top orientation)
      const corners = HEX_ANGLES.map(angle => {
        const cLat = cell.lat + hexR * Math.sin(angle);
        const cLng = cell.lng + hexR * Math.cos(angle);
        return map.latLngToContainerPoint([cLat, cLng]);
      });

      // Bounding box for size check
      const xs = corners.map(c => c.x), ys = corners.map(c => c.y);
      const w = Math.max(...xs) - Math.min(...xs);
      const h = Math.max(...ys) - Math.min(...ys);
      if (w < 2 || h < 2) continue;

      const cx = (Math.min(...xs) + Math.max(...xs)) / 2;
      const cy = (Math.min(...ys) + Math.max(...ys)) / 2;

      const { r, g, b } = scoreToRGBA(cell.score);
      const fillAlpha = 0.12 + (cell.score / 100) * 0.52;
      const strokeAlpha = 0.15 + (cell.score / 100) * 0.55;

      // Radial gradient fill
      const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(w, h) * 0.6);
      grad.addColorStop(0, `rgba(${r},${g},${b},${fillAlpha})`);
      grad.addColorStop(1, `rgba(${r},${g},${b},${fillAlpha * 0.3})`);

      // Draw hex polygon path
      ctx.beginPath();
      ctx.moveTo(corners[0].x, corners[0].y);
      for (let j = 1; j < 6; j++) ctx.lineTo(corners[j].x, corners[j].y);
      ctx.closePath();

      ctx.fillStyle = grad;
      ctx.fill();

      ctx.strokeStyle = `rgba(${r},${g},${b},${strokeAlpha})`;
      ctx.lineWidth = cell.tier === "high" ? 1.5 : 0.75;
      ctx.stroke();

      // Land-manager accent dot (top-right corner vertex)
      const mgrColor = MGR_HEX[cell.dominant_manager] || "#6b7280";
      const dotR = cell.tier === "high" ? 4 : 3;
      ctx.fillStyle = mgrColor;
      ctx.globalAlpha = 0.9;
      ctx.beginPath();
      ctx.arc(corners[1].x, corners[1].y, dotR, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;

      // Score label for high-tier cells if large enough
      if (cell.tier === "high" && w > 48) {
        ctx.font = `bold ${Math.min(11, w / 5)}px 'Inter',system-ui`;
        ctx.fillStyle = `rgba(${r},${g},${b},0.9)`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(cell.score, cx, cy);
      }
    }
  }
}

// ── Invisible hit-test layer for tooltips (uses L.Rectangle, not canvas) ──────
export default function GeoHeatmapLayer({ cells, gridDeg, visible, mineralFilter, landFilter }) {
  const map = useMap();
  const canvasLayerRef = useRef(null);
  const tooltipLayerRef = useRef(null);

  // Filter cells once
  const filteredCells = React.useMemo(() => {
    if (!cells) return [];
    return cells.filter(cell => {
      if (landFilter && landFilter !== "all") {
        if (landFilter === "public_only") {
          if (!["BLM","USFS","State Land","State Park"].includes(cell.dominant_manager)) return false;
        } else if (cell.dominant_manager !== landFilter) return false;
      }
      if (mineralFilter && !cell.top_minerals?.some(m =>
        m.toLowerCase().includes(mineralFilter.toLowerCase())
      )) return false;
      return true;
    });
  }, [cells, landFilter, mineralFilter]);

  // Canvas layer (visual)
  useEffect(() => {
    if (canvasLayerRef.current) {
      map.removeLayer(canvasLayerRef.current);
      canvasLayerRef.current = null;
    }
    if (!visible || filteredCells.length === 0) return;

    const layer = new CanvasHeatLayer(filteredCells, gridDeg || 0.25);
    layer.addTo(map);
    canvasLayerRef.current = layer;

    return () => {
      if (canvasLayerRef.current) map.removeLayer(canvasLayerRef.current);
    };
  }, [filteredCells, visible, gridDeg, map]);

  // Tooltip interaction layer (transparent rectangles on top)
  useEffect(() => {
    if (tooltipLayerRef.current) {
      map.removeLayer(tooltipLayerRef.current);
      tooltipLayerRef.current = null;
    }
    if (!visible || filteredCells.length === 0) return;

    const group = L.layerGroup();
    const half = (gridDeg || 0.25) / 2;

    // Only add tooltip rects for high/medium tier (performance)
    for (const cell of filteredCells) {
      if (cell.tier === "low" && filteredCells.length > 80) continue;
      const bounds = [[cell.lat - half, cell.lng - half],[cell.lat + half, cell.lng + half]];
      const rect = L.rectangle(bounds, {
        opacity: 0, fillOpacity: 0,
        interactive: true,
        bubblingMouseEvents: false,
      });
      rect.bindTooltip(buildTooltip(cell), {
        className: "geo-cell-tooltip",
        sticky: true,
        offset: [12, 0],
        direction: "right",
      });
      group.addLayer(rect);
    }

    group.addTo(map);
    tooltipLayerRef.current = group;

    return () => {
      if (tooltipLayerRef.current) map.removeLayer(tooltipLayerRef.current);
    };
  }, [filteredCells, visible, gridDeg, map]);

  return (
    <style>{`
      .geo-cell-tooltip .leaflet-tooltip {
        background: transparent !important;
        border: none !important;
        box-shadow: none !important;
        padding: 0 !important;
      }
      .geo-cell-tooltip .leaflet-tooltip::before { display: none !important; }
    `}</style>
  );
}