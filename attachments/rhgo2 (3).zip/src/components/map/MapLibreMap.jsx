import React, { useEffect, useRef, useState, useCallback } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { MapLibreContext } from './MapLibreContext';
import { createPlayerMarkerElement } from './PlayerLocationMarker';
import { useWebGLSupport } from '@/hooks/useWebGLSupport';
import WebGLFallbackMap from './WebGLFallbackMap';
import MapErrorBoundary from './MapErrorBoundary';

const TILE_STYLES = {
  dark: 'https://basemaps.cartocdn.com/gl/dark-matter-nolabels-gl-style/style.json',
  satellite: {
    version: 8,
    sources: {
      esri_satellite: {
        type: 'raster',
        tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
        tileSize: 256,
        maxzoom: 19,
        attribution: 'Tiles © Esri'
      }
    },
    layers: [{ id: 'esri-satellite', type: 'raster', source: 'esri_satellite' }]
  },
  topo: 'https://basemaps.cartocdn.com/gl/voyager-nolabels-gl-style/style.json',
  outdoor: 'https://basemaps.cartocdn.com/gl/positron-nolabels-gl-style/style.json',
};

export default function MapLibreMap(props) {
  const webglStatus = useWebGLSupport();
  if (webglStatus === 'unsupported') {
    return (
      <MapErrorBoundary>
        <WebGLFallbackMap {...props} />
      </MapErrorBoundary>
    );
  }
  return <MapLibreMapInner {...props} />;
}

function MapLibreMapInner({
  center = [-98.5795, 39.8283], // [lng, lat]
  zoom = 15,
  tileStyleId = 'satellite',
  onMapReady,
  onBoundsChange,
  onMapClick,
  children,
  className = '',
  style = {},
}) {
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const [map, setMap] = useState(null);
  const boundsTimerRef = useRef(null);

  const emitBounds = useCallback((m) => {
    if (!onBoundsChange) return;
    clearTimeout(boundsTimerRef.current);
    boundsTimerRef.current = setTimeout(() => {
      const b = m.getBounds();
      onBoundsChange({
        bounds: { north: b.getNorth(), south: b.getSouth(), east: b.getEast(), west: b.getWest() },
        center: [m.getCenter().lat, m.getCenter().lng],
        zoom: m.getZoom(),
      });
    }, 600);
  }, [onBoundsChange]);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const styleUrl = TILE_STYLES[tileStyleId] || TILE_STYLES.dark;
    const m = new maplibregl.Map({
      container: containerRef.current,
      style: styleUrl,
      center,
      zoom,
      maxZoom: 21,
      antialias: true,
      fadeDuration: 150,
    });

    mapRef.current = m;

    m.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right');
    m.addControl(new maplibregl.ScaleControl({ unit: 'imperial' }), 'bottom-left');

    // Player location marker (game-style, persistent)
    let playerMarker = null;
    let watchId = null;

    m.on('load', () => {
      setMap(m);
      window._maplibreMap = m;
      if (onMapReady) onMapReady(m);
      emitBounds(m);

      if (navigator.geolocation) {
        // Initial fly-in
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            m.flyTo({
              center: [pos.coords.longitude, pos.coords.latitude],
              zoom: 18,
              duration: 1400,
              essential: true,
            });
            // Place game-style player marker
            const el = createPlayerMarkerElement();
            playerMarker = new maplibregl.Marker({ element: el, anchor: 'center' })
              .setLngLat([pos.coords.longitude, pos.coords.latitude])
              .addTo(m);
          },
          () => {}
        );
        // Live position tracking
        watchId = navigator.geolocation.watchPosition(
          (pos) => {
            if (playerMarker) {
              playerMarker.setLngLat([pos.coords.longitude, pos.coords.latitude]);
            }
          },
          () => {},
          { enableHighAccuracy: true, maximumAge: 3000, timeout: 10000 }
        );
      }
    });

    m.on('moveend', () => emitBounds(m));

    m.on('click', (e) => {
      if (onMapClick) onMapClick({ lat: e.lngLat.lat, lng: e.lngLat.lng });
    });

    return () => {
      clearTimeout(boundsTimerRef.current);
      if (watchId != null) navigator.geolocation.clearWatch(watchId);
      if (playerMarker) playerMarker.remove();
      if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }
      window._maplibreMap = null;
    };
  }, []);  

  return (
    <MapErrorBoundary
      fallback={
        <WebGLFallbackMap
          center={center}
          zoom={zoom}
          tileStyleId={tileStyleId}
          onMapReady={onMapReady}
          onBoundsChange={onBoundsChange}
          onMapClick={onMapClick}
          children={children}
          className={className}
          style={style}
        />
      }
    >
      <MapLibreContext.Provider value={map}>
        <div
          ref={containerRef}
          className={`rh-layer-map ${className}`}
          style={{ width: '100%', height: '100%', position: 'absolute', inset: 0, ...style }}
        />
        {map && children}
      </MapLibreContext.Provider>
    </MapErrorBoundary>
  );
}

export { TILE_STYLES };