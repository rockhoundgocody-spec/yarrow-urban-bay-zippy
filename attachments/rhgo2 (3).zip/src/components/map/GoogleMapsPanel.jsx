import React, { useState, useEffect, useRef, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { X, Map, Loader2, Search, Gem } from "lucide-react";

const TILE_STYLES = [
  { id: "light",     label: "Light",     url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",                                                        preview: "#e8e0d5" },
  { id: "dark",      label: "Dark",      url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",                                                         preview: "#1a1a2e" },
  { id: "satellite", label: "Satellite", url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",                         preview: "#2d4a1e" },
  { id: "terrain",   label: "Terrain",   url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",                                                                      preview: "#c8d8a8" },
  { id: "voyager",   label: "Voyager",   url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",                                              preview: "#f0ebe3" },
  { id: "toner",     label: "B&W",       url: "https://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}.png",                                                       preview: "#ffffff" },
];

// ── Marker color by legality ─────────────────────────────────────────────────
const LEGALITY_COLORS = {
  "Safe Public":   "#22c55e",
  "Likely Legal":  "#f59e0b",
  "Use Caution":   "#f97316",
  "High Risk":     "#ef4444",
};
function markerColor(loc) {
  return LEGALITY_COLORS[loc.legality_status] || "#6b7280";
}

// Custom pin SVG icon
function pinSvg(color, active = false) {
  const size  = active ? 36 : 28;
  const scale = active ? 1.3 : 1;
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${Math.round(size * 1.3)}" viewBox="0 0 28 36">
      <path d="M14 0C6.3 0 0 6.3 0 14c0 10.5 14 22 14 22S28 24.5 28 14C28 6.3 21.7 0 14 0z"
            fill="${color}" stroke="white" stroke-width="2"/>
      <circle cx="14" cy="13" r="5" fill="white" opacity="0.85"/>
    </svg>`
  )}`;
}

const MAX_MARKERS = 250;

export default function GoogleMapsPanel({
  location, onClose, onTileStyleChange, currentTileStyle,
  filteredLocations = [], mineralFilter, onLocationSelect,
}) {
  const [apiKey,           setApiKey]           = useState(null);
  const [tab,              setTab]              = useState("streetview");
  const [svLoading,        setSvLoading]        = useState(false);
  const [svAvailable,      setSvAvailable]      = useState(null);
  const [placeQuery,       setPlaceQuery]       = useState("");
  const [placeSuggestions, setPlaceSuggestions] = useState([]);
  const [placeLoading,     setPlaceLoading]     = useState(false);
  const [mapReady,         setMapReady]         = useState(false);

  const svContainerRef    = useRef(null);
  const svPanoRef         = useRef(null);
  const initDoneRef       = useRef(false);
  const gmapContainerRef  = useRef(null);
  const gmapInstanceRef   = useRef(null);
  const markersRef        = useRef([]);
  const infoWindowRef     = useRef(null);

  // Fetch API key once
  useEffect(() => {
    base44.functions.invoke("getGoogleMapsKey")
      .then(res => setApiKey(res.data?.apiKey || null))
      .catch(() => setApiKey(null));
  }, []);

  // Load Google Maps JS SDK once (shared across tabs)
  useEffect(() => {
    if (!apiKey) return;
    if (window.google?.maps) { setMapReady(true); return; }
    if (document.querySelector("script[data-gmaps]")) {
      const check = setInterval(() => { if (window.google?.maps) { clearInterval(check); setMapReady(true); } }, 150);
      return () => clearInterval(check);
    }
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    script.async = true;
    script.defer = true;
    script.setAttribute("data-gmaps", "1");
    script.onload = () => setMapReady(true);
    document.head.appendChild(script);
  }, [apiKey]);

  // ── Street View ─────────────────────────────────────────────────────────────
  useEffect(() => {
    if (tab !== "streetview" || !location || !mapReady) return;
    initDoneRef.current = false;
    setSvAvailable(null);

    const init = () => {
      if (!svContainerRef.current || initDoneRef.current) return;
      initDoneRef.current = true;
      setSvLoading(true);
      const svc = new window.google.maps.StreetViewService();
      svc.getPanorama({ location: new window.google.maps.LatLng(location.latitude, location.longitude), radius: 500 }, (data, status) => {
        setSvLoading(false);
        if (status === "OK") {
          setSvAvailable(true);
          svPanoRef.current = new window.google.maps.StreetViewPanorama(svContainerRef.current, {
            position: new window.google.maps.LatLng(location.latitude, location.longitude),
            pov: { heading: 165, pitch: 0 }, zoom: 1,
            addressControl: false, fullscreenControl: false, motionTracking: false,
          });
        } else { setSvAvailable(false); }
      });
    };
    if (window.google?.maps) init();
  }, [tab, location, mapReady]);

  // ── Google Map (Locations tab) — initialize once ─────────────────────────────
  useEffect(() => {
    if (tab !== "map" || !mapReady || !gmapContainerRef.current) return;
    if (gmapInstanceRef.current) return; // already initialized

    gmapInstanceRef.current = new window.google.maps.Map(gmapContainerRef.current, {
      center: { lat: 39.8283, lng: -98.5795 },
      zoom: 4,
      mapTypeId: "roadmap",
      disableDefaultUI: false,
      zoomControl: true,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
      styles: [
        { featureType: "poi", stylers: [{ visibility: "off" }] },
        { elementType: "labels.icon", stylers: [{ visibility: "off" }] },
      ],
    });

    infoWindowRef.current = new window.google.maps.InfoWindow();
  }, [tab, mapReady]);

  // ── Google Map — sync markers when filteredLocations / mineralFilter changes ──
  useEffect(() => {
    if (!gmapInstanceRef.current || !mapReady) return;

    // Clear old markers
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = [];

    const locs = filteredLocations.slice(0, MAX_MARKERS);
    if (!locs.length) return;

    const bounds = new window.google.maps.LatLngBounds();

    locs.forEach(loc => {
      if (!loc.latitude || !loc.longitude) return;
      const pos = { lat: loc.latitude, lng: loc.longitude };
      const color = markerColor(loc);
      const isActive = location?.id === loc.id;

      const marker = new window.google.maps.Marker({
        position: pos,
        map: gmapInstanceRef.current,
        title: loc.name,
        icon: {
          url:    pinSvg(color, isActive),
          anchor: new window.google.maps.Point(14, 36),
        },
        zIndex: isActive ? 999 : 1,
      });

      marker.addListener("click", () => {
        const minerals = (loc.minerals_found || []).slice(0, 4).join(", ") || "Not listed";
        infoWindowRef.current.setContent(`
          <div style="font-family:sans-serif;max-width:200px;padding:4px">
            <div style="font-weight:700;font-size:13px;margin-bottom:4px">${loc.name}</div>
            <div style="color:#555;font-size:11px;margin-bottom:2px">${loc.state || ""} · ${loc.site_type || ""}</div>
            <div style="color:#555;font-size:11px;margin-bottom:6px">💎 ${minerals}</div>
            ${loc.legality_status ? `<div style="display:inline-block;padding:2px 8px;border-radius:99px;font-size:10px;font-weight:600;background:${color}22;color:${color};border:1px solid ${color}66">${loc.legality_status}</div>` : ""}
          </div>
        `);
        infoWindowRef.current.open(gmapInstanceRef.current, marker);
        onLocationSelect?.(loc);
      });

      markersRef.current.push(marker);
      bounds.extend(pos);
    });

    // Fit map to markers (but don't over-zoom on single marker)
    if (markersRef.current.length === 1) {
      gmapInstanceRef.current.setCenter(bounds.getCenter());
      gmapInstanceRef.current.setZoom(10);
    } else if (markersRef.current.length > 1) {
      gmapInstanceRef.current.fitBounds(bounds, 40);
    }
  }, [filteredLocations, mineralFilter, mapReady, location]);

  // ── Places search ───────────────────────────────────────────────────────────
  const handlePlacesSearch = useCallback((q) => {
    if (!q.trim() || !window.google?.maps?.places) { setPlaceSuggestions([]); return; }
    setPlaceLoading(true);
    new window.google.maps.places.AutocompleteService().getPlacePredictions({ input: q }, (preds, status) => {
      setPlaceLoading(false);
      setPlaceSuggestions(status === "OK" && preds ? preds : []);
    });
  }, []);

  const handlePlaceSelect = (pred) => {
    if (!window.google?.maps) return;
    new window.google.maps.Geocoder().geocode({ placeId: pred.place_id }, (results, status) => {
      if (status === "OK" && results[0]) {
        const loc = results[0].geometry.location;
        window.dispatchEvent(new CustomEvent("googlePlaceSelected", { detail: { lat: loc.lat(), lng: loc.lng(), name: pred.description } }));
        setPlaceSuggestions([]);
        setPlaceQuery(pred.description);
      }
    });
  };

  // ── Legend for the Locations tab ─────────────────────────────────────────────
  const Legend = () => (
    <div className="flex flex-wrap gap-2 px-3 py-2 border-b border-white/10 shrink-0 bg-black/20">
      {Object.entries(LEGALITY_COLORS).map(([label, color]) => (
        <div key={label} className="flex items-center gap-1">
          <span style={{ background: color }} className="w-2.5 h-2.5 rounded-full inline-block" />
          <span className="text-white/50 text-[10px]">{label}</span>
        </div>
      ))}
      <div className="flex items-center gap-1">
        <span style={{ background: "#6b7280" }} className="w-2.5 h-2.5 rounded-full inline-block" />
        <span className="text-white/50 text-[10px]">Unknown</span>
      </div>
    </div>
  );

  const TABS = [
    { id: "streetview", label: "Street View" },
    { id: "map",        label: `Locations${filteredLocations.length ? ` (${Math.min(filteredLocations.length, MAX_MARKERS)})` : ""}` },
    { id: "places",     label: "Places" },
    { id: "style",      label: "Style" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header tabs */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 shrink-0 overflow-x-auto">
        <div className="flex gap-1 shrink-0">
          {TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold transition-all whitespace-nowrap ${
                tab === t.id ? "bg-amber-500 text-white" : "text-white/50 hover:text-white hover:bg-white/5"
              }`}>
              {t.label}
            </button>
          ))}
        </div>
        <button onClick={onClose} className="p-1 ml-2 rounded-lg hover:bg-white/10 text-white/50 hover:text-white shrink-0" aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* ── Street View Tab ── */}
      {tab === "streetview" && (
        <div className="flex-1 relative overflow-hidden">
          {!location ? (
            <div className="flex flex-col items-center justify-center h-full p-6 text-center">
              <Map className="w-8 h-8 text-white/20 mb-3" />
              <p className="text-white/40 text-sm">Select a location on the map to open Street View</p>
            </div>
          ) : !apiKey ? (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
            </div>
          ) : (
            <>
              {svLoading && (
                <div className="absolute inset-0 flex items-center justify-center bg-[#14141e] z-10">
                  <Loader2 className="w-6 h-6 text-amber-400 animate-spin mx-auto" />
                </div>
              )}
              {svAvailable === false && (
                <div className="flex flex-col items-center justify-center h-full p-6 text-center">
                  <Map className="w-10 h-10 text-white/20 mb-3" />
                  <p className="text-white/50 text-sm font-semibold">{location.name}</p>
                  <p className="text-white/30 text-xs mt-1">No Street View imagery here</p>
                </div>
              )}
              <div ref={svContainerRef} className="w-full h-full" style={{ display: svAvailable === false ? "none" : "block" }} />
            </>
          )}
        </div>
      )}

      {/* ── Locations Map Tab ── */}
      {tab === "map" && (
        <div className="flex flex-col flex-1 overflow-hidden">
          <Legend />
          {mineralFilter && (
            <div className="px-3 py-1.5 text-[11px] text-amber-300 border-b border-white/10 shrink-0 flex items-center gap-1.5">
              <Gem className="w-3 h-3" />
              Filtered: <strong>{mineralFilter}</strong>
            </div>
          )}
          {!apiKey ? (
            <div className="flex-1 flex items-center justify-center">
              <Loader2 className="w-6 h-6 text-amber-400 animate-spin" />
            </div>
          ) : (
            <div ref={gmapContainerRef} className="flex-1 w-full" style={{ minHeight: 0 }} />
          )}
          {filteredLocations.length === 0 && apiKey && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <p className="text-white/40 text-sm">No locations match current filters</p>
            </div>
          )}
        </div>
      )}

      {/* ── Places Search Tab ── */}
      {tab === "places" && (
        <div className="flex flex-col p-4 gap-3 overflow-y-auto">
          <p className="text-white/40 text-xs">Search for a place to fly the map there</p>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              value={placeQuery}
              onChange={(e) => { setPlaceQuery(e.target.value); handlePlacesSearch(e.target.value); }}
              placeholder="Cities, landmarks, addresses..."
              className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-white text-sm placeholder:text-white/30 focus:outline-none focus:border-amber-500/50"
            />
          </div>
          {placeLoading && <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />}
          <div className="space-y-1">
            {placeSuggestions.map(p => (
              <button key={p.place_id} onClick={() => handlePlaceSelect(p)}
                className="w-full text-left px-3 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors border border-white/5">
                <p className="text-white/80 text-sm font-medium">{p.structured_formatting?.main_text}</p>
                <p className="text-white/30 text-xs">{p.structured_formatting?.secondary_text}</p>
              </button>
            ))}
          </div>
          {!apiKey && <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 text-amber-400 animate-spin" /></div>}
        </div>
      )}

      {/* ── Map Style Tab ── */}
      {tab === "style" && (
        <div className="p-4 overflow-y-auto">
          <p className="text-white/40 text-xs mb-3">Choose the Leaflet tile style</p>
          <div className="grid grid-cols-2 gap-2">
            {TILE_STYLES.map(style => (
              <button key={style.id} onClick={() => onTileStyleChange(style)}
                className={`relative flex flex-col items-center gap-2 p-3 rounded-xl border transition-all ${
                  currentTileStyle?.id === style.id
                    ? "border-amber-400 bg-amber-500/10"
                    : "border-white/10 bg-white/5 hover:border-white/20"
                }`}>
                <div className="w-full h-10 rounded-lg border border-white/10" style={{ backgroundColor: style.preview }} />
                <span className="text-xs font-medium text-white/70">{style.label}</span>
                {currentTileStyle?.id === style.id && (
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-amber-400" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}