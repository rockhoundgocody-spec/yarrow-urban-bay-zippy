import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Sparkles, Loader2, ChevronDown, ChevronUp, AlertCircle } from "lucide-react";

function probColor(score) {
  if (score >= 80) return "#00ff88";
  if (score >= 65) return "#7aff3c";
  if (score >= 50) return "#f5c842";
  if (score >= 35) return "#ff9640";
  return "#ff4d4d";
}

export default function PredictiveProspectingPanel({
  visible, onToggle, mapBounds, locations = [],
  zones, onZonesLoaded, onZoneClick, loading, setLoading,
}) {
  const [expanded, setExpanded] = useState(false);
  const [error, setError] = useState(null);
  const [summary, setSummary] = useState(null);

  const handleRun = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke("predictiveProspecting", {
        bounds: mapBounds,
        locations: locations.slice(0, 80),
      });
      onZonesLoaded(res.data?.zones || [], res.data?.summary || "");
      setSummary(res.data?.summary || null);
    } catch (e) {
      setError("AI model failed. Try again.");
    }
    setLoading(false);
  };

  return (
    <div className="absolute bottom-24 right-3 z-20 w-64 md:w-72" style={{ maxHeight: "70vh" }}>
      {/* Toggle chip */}
      <div className="flex justify-end mb-1.5">
        <button
          onClick={onToggle}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-lg"
          style={{
            background: visible ? "rgba(0,255,136,0.18)" : "rgba(8,7,22,0.88)",
            border: `1px solid ${visible ? "rgba(0,255,136,0.45)" : "rgba(255,255,255,0.1)"}`,
            color: visible ? "#00ff88" : "rgba(255,255,255,0.5)",
            backdropFilter: "blur(16px)",
            boxShadow: visible ? "0 0 16px rgba(0,255,136,0.25)" : "0 4px 20px rgba(0,0,0,0.5)",
          }}
        >
          <Sparkles className="w-3 h-3" />
          AI Prospecting
          {zones.length > 0 && <span className="ml-1 opacity-70">({zones.length})</span>}
        </button>
      </div>

      {/* Panel */}
      {visible && (
        <div className="rounded-2xl overflow-hidden shadow-2xl"
          style={{
            background: "linear-gradient(180deg, rgba(8,7,22,0.97) 0%, rgba(10,8,26,0.97) 100%)",
            border: "1px solid rgba(0,255,136,0.18)",
            backdropFilter: "blur(20px)",
            boxShadow: "0 8px 40px rgba(0,0,0,0.6), 0 0 0 1px rgba(0,255,136,0.05)",
          }}>

          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span className="text-sm font-bold text-white">Predictive Zones</span>
            </div>
            <button onClick={() => setExpanded(v => !v)} className="text-white/30 hover:text-white/60">
              {expanded ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
            </button>
          </div>

          <div className="px-4 py-3 space-y-3">
            {/* Run button */}
            <button
              onClick={handleRun}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-bold transition-all"
              style={{
                background: loading ? "rgba(0,255,136,0.05)" : "linear-gradient(135deg, rgba(0,255,136,0.2), rgba(122,231,255,0.15))",
                border: "1px solid rgba(0,255,136,0.3)",
                color: loading ? "rgba(0,255,136,0.4)" : "#00ff88",
              }}
            >
              {loading
                ? <><Loader2 className="w-3.5 h-3.5 animate-spin" />Analyzing {locations.length} sites...</>
                : <><Sparkles className="w-3.5 h-3.5" />Run AI Analysis ({locations.length} sites)</>}
            </button>

            {error && (
              <div className="flex items-center gap-2 text-red-400 text-xs bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />{error}
              </div>
            )}

            {summary && (
              <p className="text-[11px] text-white/40 leading-relaxed border-t border-white/5 pt-2">{summary}</p>
            )}

            {/* Zone legend */}
            {zones.length > 0 && (
              <div className="border-t border-white/5 pt-2 space-y-1">
                <p className="text-[10px] font-bold text-white/30 uppercase tracking-wider mb-2">
                  {zones.length} zones detected
                </p>
                {(expanded ? zones : zones.slice(0, 4)).map((z, i) => (
                  <button
                    key={i}
                    onClick={() => onZoneClick(z)}
                    className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg hover:bg-white/5 transition-colors text-left"
                  >
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ background: probColor(z.probability), boxShadow: `0 0 6px ${probColor(z.probability)}80` }} />
                    <span className="flex-1 text-xs text-white/70 truncate">{z.name}</span>
                    <span className="text-[10px] font-bold shrink-0" style={{ color: probColor(z.probability) }}>
                      {z.probability}%
                    </span>
                  </button>
                ))}
                {zones.length > 4 && !expanded && (
                  <button onClick={() => setExpanded(true)} className="w-full text-center text-[10px] text-white/25 hover:text-white/50 pt-1">
                    +{zones.length - 4} more zones
                  </button>
                )}
              </div>
            )}

            {/* Probability legend */}
            <div className="border-t border-white/5 pt-2">
              <div className="flex items-center gap-1.5 mb-1">
                <div className="flex-1 h-2 rounded-full" style={{ background: "linear-gradient(90deg, #ff4d4d 0%, #f5c842 40%, #7aff3c 70%, #00ff88 100%)" }} />
              </div>
              <div className="flex justify-between text-[9px] text-white/25">
                <span>Low</span><span>Medium</span><span>High</span><span>Prime</span>
              </div>
            </div>

            <p className="text-[9px] text-white/20 text-center">
              Based on geological patterns & historical site data. Not surveyed ground.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}