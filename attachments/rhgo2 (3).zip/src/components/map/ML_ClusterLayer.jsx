import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { useMapLibre } from './MapLibreContext';


const SOURCE = 'locations-source';

const LEGALITY_COLORS = {
  'Safe Public': '#22c55e',
  'Likely Legal': '#eab308',
  'Use Caution': '#f97316',
  'High Risk': '#ef4444',
};

export default function ML_ClusterLayer({ locations, onSelect, selectedId }) {
  const map = useMapLibre();
  const popupRef = useRef(null);

  useEffect(() => {
    if (!map) return;

    const geojson = {
      type: 'FeatureCollection',
      features: locations
        .filter(l => l.latitude && l.longitude)
        .map(l => ({
          type: 'Feature',
          id: l.id,
          geometry: { type: 'Point', coordinates: [l.longitude, l.latitude] },
          properties: {
            id: l.id,
            name: l.name,
            site_type: l.site_type || 'other',
            legality_status: l.legality_status || '',
            minerals: (l.minerals_found || []).slice(0, 3).join(', '),
            rating: l.rating_avg || 0,
            color: LEGALITY_COLORS[l.legality_status] || '#6366f1',
          }
        }))
    };

    const addAll = () => {
      if (map.getSource(SOURCE)) {
        map.getSource(SOURCE).setData(geojson);
        return;
      }

      map.addSource(SOURCE, {
        type: 'geojson',
        data: geojson,
        cluster: true,
        clusterMaxZoom: 14,
        clusterRadius: 50,
      });

      map.addLayer({
        id: 'clusters',
        type: 'circle',
        source: SOURCE,
        filter: ['has', 'point_count'],
        paint: {
          'circle-color': ['step', ['get', 'point_count'], '#6366f1', 10, '#8b5cf6', 50, '#a855f7'],
          'circle-radius': ['step', ['get', 'point_count'], 20, 10, 28, 50, 36],
          'circle-stroke-width': 2,
          'circle-stroke-color': 'rgba(255,255,255,0.3)',
          'circle-opacity': 0.85,
        }
      });

      map.addLayer({
        id: 'cluster-count',
        type: 'symbol',
        source: SOURCE,
        filter: ['has', 'point_count'],
        layout: {
          'text-field': '{point_count_abbreviated}',
          'text-size': 13,
        },
        paint: { 'text-color': '#fff' }
      });

      map.addLayer({
        id: 'unclustered-point',
        type: 'circle',
        source: SOURCE,
        filter: ['!', ['has', 'point_count']],
        paint: {
          'circle-color': ['get', 'color'],
          'circle-radius': 8,
          'circle-stroke-width': 2,
          'circle-stroke-color': '#ffffff',
          'circle-opacity': 0.9,
        }
      });

      map.addLayer({
        id: 'selected-point',
        type: 'circle',
        source: SOURCE,
        filter: ['==', ['get', 'id'], selectedId || ''],
        paint: {
          'circle-color': '#f59e0b',
          'circle-radius': 12,
          'circle-stroke-width': 3,
          'circle-stroke-color': '#fff',
          'circle-opacity': 1,
        }
      });
    };

    if (map.isStyleLoaded()) addAll(); else map.once('load', addAll);
    map.on('style.load', addAll);

    const onClusterClick = (e) => {
      const features = map.queryRenderedFeatures(e.point, { layers: ['clusters'] });
      if (!features.length) return;
      const clusterId = features[0].properties.cluster_id;
      map.getSource(SOURCE).getClusterExpansionZoom(clusterId, (err, zoom) => {
        if (err) return;
        map.flyTo({ center: features[0].geometry.coordinates, zoom });
      });
    };

    const onPointClick = (e) => {
      const features = map.queryRenderedFeatures(e.point, { layers: ['unclustered-point'] });
      if (!features.length) return;
      const props = features[0].properties;
      const loc = locations.find(l => l.id === props.id);
      if (loc) onSelect(loc);

      if (popupRef.current) popupRef.current.remove();
      popupRef.current = new maplibregl.Popup({ offset: 12, closeButton: false })
        .setLngLat(features[0].geometry.coordinates)
        .setDOMContent((() => {
            const container = document.createElement('div');
            const nameEl = document.createElement('div');
            nameEl.style.cssText = 'font-weight:700;font-size:12px';
            nameEl.textContent = props.name;
            const mineralsEl = document.createElement('div');
            mineralsEl.style.cssText = 'font-size:10px;color:#888;margin-top:2px';
            mineralsEl.textContent = props.minerals || '—';
            container.appendChild(nameEl);
            container.appendChild(mineralsEl);
            return container;
          })())
        .addTo(map);
    };

    map.on('click', 'clusters', onClusterClick);
    map.on('click', 'unclustered-point', onPointClick);
    map.on('mouseenter', 'clusters', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'clusters', () => { map.getCanvas().style.cursor = ''; });
    map.on('mouseenter', 'unclustered-point', () => { map.getCanvas().style.cursor = 'pointer'; });
    map.on('mouseleave', 'unclustered-point', () => { map.getCanvas().style.cursor = ''; });

    return () => {
      map.off('style.load', addAll);
      map.off('click', 'clusters', onClusterClick);
      map.off('click', 'unclustered-point', onPointClick);
      ['clusters', 'cluster-count', 'unclustered-point', 'selected-point'].forEach(id => {
        try { if (map.getLayer(id)) map.removeLayer(id); } catch (_) {}
      });
      try { if (map.getSource(SOURCE)) map.removeSource(SOURCE); } catch (_) {}
      if (popupRef.current) popupRef.current.remove();
    };
  }, [map, locations, onSelect]);

  useEffect(() => {
    if (!map || !map.getLayer('selected-point')) return;
    map.setFilter('selected-point', ['==', ['get', 'id'], selectedId || '']);
  }, [map, selectedId]);

  return null;
}