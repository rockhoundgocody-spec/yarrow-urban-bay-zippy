/**
 * CrystalMapPin — Premium map marker components for Explore / Field Map.
 * Variants:
 *   default  — purple crystal (standard site)
 *   nearby   — cyan pulse ring (close proximity)
 *   verified — gold frame (expert-verified)
 *   private  — amber warning (private land)
 *   permit   — orange (permit required)
 *   user     — green dot (user location)
 *
 * Returns an L.divIcon-compatible HTML string OR a React SVG element.
 */
import React from "react";
import { motion } from "framer-motion";

export const PIN_PRESETS = {
  default:  { fill: "#8D7CFF", stroke: "rgba(141,124,255,0.60)", glow: "rgba(141,124,255,0.55)", label: "Site" },
  nearby:   { fill: "#7AE7FF", stroke: "rgba(122,231,255,0.70)", glow: "rgba(122,231,255,0.60)", label: "Nearby" },
  verified: { fill: "#D4AF37", stroke: "rgba(212,175,55,0.75)",  glow: "rgba(212,175,55,0.60)",  label: "Verified" },
  private:  { fill: "#F59E0B", stroke: "rgba(245,158,11,0.65)",  glow: "rgba(245,158,11,0.50)",  label: "Private" },
  permit:   { fill: "#F97316", stroke: "rgba(249,115,22,0.65)",  glow: "rgba(249,115,22,0.50)",  label: "Permit" },
  user:     { fill: "#00D68F", stroke: "rgba(0,214,143,0.80)",   glow: "rgba(0,214,143,0.65)",   label: "You" },
};

/** React component for overlay use */
export function CrystalPin({ variant = "default", size = 28, pulse = false, label }) {
  const p = PIN_PRESETS[variant] || PIN_PRESETS.default;
  return (
    <div className="relative flex flex-col items-center" style={{ width: size, pointerEvents: "none" }}>
      {/* Pulse ring for nearby */}
      {pulse && (
        <motion.div
          className="absolute rounded-full"
          style={{
            width: size * 2.2, height: size * 2.2,
            top: -(size * 0.6), left: -(size * 0.6),
            border: `1.5px solid ${p.stroke}`,
          }}
          animate={{ scale: [1, 1.8], opacity: [0.7, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: "easeOut" }}
        />
      )}
      {/* Pin SVG */}
      <svg width={size} height={size * 1.35} viewBox="0 0 28 38" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id={`pg-${variant}`} cx="40%" cy="35%" r="65%">
            <stop offset="0%" stopColor="rgba(255,255,255,0.20)" />
            <stop offset="100%" stopColor="rgba(0,0,0,0)" />
          </radialGradient>
        </defs>
        {/* Drop shadow */}
        <ellipse cx="14" cy="37" rx="5" ry="1.5" fill="rgba(0,0,0,0.30)" />
        {/* Pin body */}
        <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 24 14 24S28 23.33 28 14C28 6.27 21.73 0 14 0z"
          fill={p.fill} />
        {/* Crystal sheen */}
        <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 24 14 24S28 23.33 28 14C28 6.27 21.73 0 14 0z"
          fill={`url(#pg-${variant})`} />
        {/* Stroke border */}
        <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 24 14 24S28 23.33 28 14C28 6.27 21.73 0 14 0z"
          fill="none" stroke={p.stroke} strokeWidth="1.5" />
        {/* Inner dot */}
        <circle cx="14" cy="13" r="5" fill="rgba(255,255,255,0.90)" />
        <circle cx="14" cy="13" r="3" fill={p.fill} />
      </svg>
      {/* Optional label */}
      {label && (
        <span style={{
          fontSize: 9, fontWeight: 800, color: p.fill,
          textShadow: `0 0 6px ${p.glow}`,
          letterSpacing: "0.06em", marginTop: 2,
          background: "rgba(5,7,10,0.80)",
          padding: "1px 5px", borderRadius: 4,
          border: `1px solid ${p.stroke}`,
          whiteSpace: "nowrap",
        }}>
          {label}
        </span>
      )}
    </div>
  );
}

/** HTML string for Leaflet divIcon */
export function crystalPinHTML(variant = "default", sizeNum = 28) {
  const p = PIN_PRESETS[variant] || PIN_PRESETS.default;
  const h = Math.round(sizeNum * 1.35);
  return `
    <div style="position:relative;width:${sizeNum}px;pointer-events:none;">
      <svg width="${sizeNum}" height="${h}" viewBox="0 0 28 38" fill="none" xmlns="http://www.w3.org/2000/svg">
        <ellipse cx="14" cy="37" rx="5" ry="1.5" fill="rgba(0,0,0,0.30)"/>
        <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 24 14 24S28 23.33 28 14C28 6.27 21.73 0 14 0z" fill="${p.fill}"/>
        <path d="M14 0C6.27 0 0 6.27 0 14c0 9.33 14 24 14 24S28 23.33 28 14C28 6.27 21.73 0 14 0z" fill="none" stroke="${p.stroke}" stroke-width="1.5"/>
        <circle cx="14" cy="13" r="5" fill="rgba(255,255,255,0.90)"/>
        <circle cx="14" cy="13" r="3" fill="${p.fill}"/>
      </svg>
    </div>`;
}

export default CrystalPin;