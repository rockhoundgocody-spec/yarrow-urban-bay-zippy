import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation, Mountain, Pickaxe, Star } from "lucide-react";
import LocationRiskBadges from "./LocationRiskBadges";
import HeatZoneBadge from "./HeatZoneBadge";
import { TrustBadge } from "./TrustScore";

const typeIcons = {
  public_land: Mountain,
  mine: Pickaxe,
  quarry: Pickaxe,
  beach: MapPin,
  riverbed: MapPin,
  desert: MapPin,
  mountain: Mountain,
  roadcut: MapPin,
  fee_dig: Pickaxe,
  other: MapPin,
};

const difficultyColors = {
  easy: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  moderate: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
  difficult: "bg-orange-500/10 text-orange-400 border-orange-500/20",
  expert: "bg-red-500/10 text-red-400 border-red-500/20",
};

export default function LocationCard({ location, compact }) {
  const Icon = typeIcons[location.site_type] || MapPin;
  const mapsUrl = `https://www.google.com/maps?q=${location.latitude},${location.longitude}`;

  return (
    <Card className={`bg-white border border-gray-100 hover:border-amber-200 hover:shadow-md transition-all ${compact ? "p-3" : "p-5"}`}>
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-amber-50 border border-amber-100 flex items-center justify-center shrink-0">
          <Icon className="w-4 h-4 text-amber-600" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className={`font-bold text-gray-800 truncate ${compact ? "text-sm" : "text-base"}`}>
            {location.name}
          </h3>
          {location.state && (
            <p className="text-xs text-gray-400 mt-0.5">{location.state}{location.country !== "USA" ? `, ${location.country}` : ""}</p>
          )}
          {location.minerals_found?.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {location.minerals_found.slice(0, compact ? 3 : 6).map((m, i) => (
                <Badge key={i} className="text-[10px] bg-blue-50 text-blue-600 border-blue-100 font-medium">
                  {m}
                </Badge>
              ))}
              {location.minerals_found.length > (compact ? 3 : 6) && (
                <Badge className="text-[10px] bg-gray-100 text-gray-500 border-gray-200">
                  +{location.minerals_found.length - (compact ? 3 : 6)}
                </Badge>
              )}
            </div>
          )}
          <LocationRiskBadges location={location} compact={compact} />
          <div className="flex items-center gap-2 mt-2 flex-wrap">
            <TrustBadge location={location} />
            <HeatZoneBadge location={location} compact={compact} />
            {location.difficulty && (
              <Badge className={`text-[10px] ${difficultyColors[location.difficulty]}`}>
                {location.difficulty}
              </Badge>
            )}
            {location.rating_count > 0 && (
              <div className="flex items-center gap-0.5">
                <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400" />
                <span className="text-[10px] text-amber-600 font-semibold">{Number(location.rating_avg).toFixed(1)}</span>
                <span className="text-[10px] text-gray-400">({location.rating_count})</span>
              </div>
            )}
            <a
              href={mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-[10px] text-blue-500 hover:text-blue-700 font-medium transition"
            >
              <Navigation className="w-3 h-3" /> Navigate
            </a>
          </div>
        </div>
      </div>
    </Card>
  );
}