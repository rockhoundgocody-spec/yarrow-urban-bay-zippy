/**
 * GameMapMarker — Pokemon-Go-style animated map marker for MapLibre.
 * Injects into a maplibregl.Marker's DOM element.
 * Standalone React component rendered via createRoot into a portal element.
 *
 * Usage (in map layer components):
 *   const el = document.createElement("div");
 *   createRoot(el).render(<GameMapMarker rarity="rare" />);
 *   new maplibregl.Marker({ element: el }).setLngLat([lng, lat]).addTo(map);
 */
import React from "react";
import { motion } from "framer-motion";
import { getRarityCfg } from "@/theme/crystalSystem";
import { fxFlags } from "@/theme/performance";

export default function GameMapMarker({
  rarity = "common",
  collected = false,
  active = false,
  type = "specimen", // "specimen"|"trail"|"hotspot"|"waypoint"
}) {
  const cfg   = getRarityCfg(rarity);
  const fx    = fxFlags();
  const color = collected ? "rgba(255,255,255,0.28)" : cfg.color;
  const size  = active ? 44 : 36;

  // Type-specific inner icon color
  const typeAccent = {
    specimen: color,
    trail:    "#88FF99",
    hotspot:  "#F5B642",
    waypoint: "#7AE7FF",
  }[type] || color;

  return (
    <div style={{ width: size + 16, height: size + 16, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
      {/* Pulse rings */}
      {!collected && fx.heavyGlow && (
        <>
          {[0, 1].map(i => (
            <motion.div
              key={i}
              style={{
                position: "absolute",
                width: size, height: size,
                borderRadius: "50%",
                border: `1.5px solid ${color}`,
                opacity: 0,
                pointerEvents: "none",
              }}
              animate={{ scale: [1, 1.8, 2.4], opacity: [0.55, 0.2, 0] }}
              transition={{ duration: 2.2, repeat: Infinity, delay: i * 1.1, ease: "easeOut" }}
            />
          ))}
        </>
      )}

      {/* Pin body */}
      <motion.div
        style={{
          width: size, height: size,
          borderRadius: "50%",
          background: collected
            ? "rgba(255,255,255,0.06)"
            : `radial-gradient(circle at 35% 32%, ${color}50, ${color}1A)`,
          border: `1.5px solid ${color}${collected ? "40" : "AA"}`,
          boxShadow: (!collected && fx.heavyGlow)
            ? `0 0 14px ${cfg.glow}, 0 4px 16px rgba(0,0,0,0.6)`
            : "0 2px 8px rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
        }}
        whileHover={{ scale: 1.12 }}
        whileTap={{ scale: 0.92 }}
        animate={active ? { scale: [1, 1.06, 1] } : {}}
        transition={active ? { duration: 1.6, repeat: Infinity, ease: "easeInOut" } : {}}
      >
        {/* Inner crystal facet */}
        <svg width={size * 0.46} height={size * 0.46} viewBox="0 0 24 24" fill="none">
          {type === "trail" ? (
            <path d="M3 17L8 9L13 14L17 8L21 17" stroke={typeAccent} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          ) : type === "hotspot" ? (
            <polygon points="12,2 15.5,8.5 22,9.5 17,14.5 18.5,21 12,17.5 5.5,21 7,14.5 2,9.5 8.5,8.5" stroke={typeAccent} strokeWidth="1.5" fill={`${typeAccent}22`} />
          ) : (
            <path d="M6 3L18 3L21 12L12 21L3 12L6 3Z" stroke={typeAccent} strokeWidth="1.5" strokeLinejoin="round" fill={`${typeAccent}18`} />
          )}
        </svg>
      </motion.div>

      {/* Collected indicator */}
      {collected && (
        <div style={{
          position: "absolute", top: 2, right: 2,
          width: 14, height: 14, borderRadius: "50%",
          background: "#00D68F", border: "1.5px solid rgba(0,0,0,0.5)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
            <path d="M1.5 4L3.2 5.7L6.5 2.5" stroke="white" strokeWidth="1.5" strokeLinecap="round" />
          </svg>
        </div>
      )}
    </div>
  );
}