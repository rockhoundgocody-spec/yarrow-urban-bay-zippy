import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { CloudRain, Snowflake, Waves, Truck, Sun, Flame, Plus, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { format, isWithinInterval, parseISO } from "date-fns";

const ALERT_CONFIG = {
  after_rain:         { label: "After Rain",         icon: CloudRain,  color: "text-blue-400 bg-blue-400/10 border-blue-400/20",   tip: "Rain washes away loose material, exposing fresh rock faces and creek beds." },
  after_freeze_thaw:  { label: "Freeze-Thaw Cycle",  icon: Snowflake,  color: "text-cyan-400 bg-cyan-400/10 border-cyan-400/20",   tip: "Freeze-thaw fractures rock, breaking crystals free from host matrix." },
  low_water:          { label: "Low Water",           icon: Waves,      color: "text-amber-400 bg-amber-400/10 border-amber-400/20", tip: "Low water reveals gravel bars and riverbed material normally submerged." },
  road_graded:        { label: "Road Graded",         icon: Truck,      color: "text-orange-400 bg-orange-400/10 border-orange-400/20",tip: "Fresh grading exposes subsurface material." },
  seasonal_open:      { label: "Now Open",            icon: Sun,        color: "text-green-400 bg-green-400/10 border-green-400/20",  tip: "Site has reopened after seasonal closure." },
  seasonal_close:     { label: "Closing Soon",        icon: Sun,        color: "text-red-400 bg-red-400/10 border-red-400/20",       tip: "Site is approaching seasonal closure." },
  storm_cleared:      { label: "Storm Cleared",       icon: CloudRain,  color: "text-purple-400 bg-purple-400/10 border-purple-400/20",tip: "Storm damage cleared — access restored." },
  wildfire_regrowth:  { label: "Post-Fire Window",    icon: Flame,      color: "text-red-400 bg-red-400/10 border-red-400/20",       tip: "Regrowth exposes mineralized zones. Exercise caution." },
};

const OUTCOME_CONFIG = {
  great_finds: { label: "Great Finds!", color: "text-green-400" },
  normal:      { label: "Normal",       color: "text-white/40" },
  poor:        { label: "Poor",         color: "text-red-400" },
  not_visited: { label: "Not visited",  color: "text-white/20" },
};

export default function TimingAlerts({ location }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ alert_type: "after_rain", title: "", message: "", window_start: "", window_end: "" });
  const queryClient = useQueryClient();
  const today = new Date();

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["timing", location.id],
    queryFn: () => base44.entities.TimingAlert.filter({ location_id: location.id }, "-created_date", 10),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.TimingAlert.create({
      ...data, location_id: location.id, user_reported: true
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["timing", location.id] });
      setShowForm(false);
      setForm({ alert_type: "after_rain", title: "", message: "", window_start: "", window_end: "" });
    },
  });

  const reportOutcomeMutation = useMutation({
    mutationFn: ({ id, outcome }) => base44.entities.TimingAlert.update(id, { outcome_reported: outcome }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["timing", location.id] }),
  });

  const activeAlerts = alerts.filter(a => {
    if (!a.window_end) return true;
    try { return parseISO(a.window_end) >= today; } catch { return true; }
  });

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-1">
        <p className="text-xs font-semibold text-white/60">Timing Windows</p>
        <Button
          size="sm"
          onClick={() => setShowForm(true)}
          className="h-6 px-2 text-[10px] bg-white/5 hover:bg-white/10 text-white/50 border border-white/10"
        >
          <Plus className="w-3 h-3 mr-1" /> Report
        </Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-3"><Loader2 className="w-4 h-4 animate-spin text-white/30" /></div>
      ) : activeAlerts.length === 0 ? (
        <p className="text-[10px] text-white/30 italic text-center py-2">No active timing windows. Report one after a rain or freeze-thaw!</p>
      ) : (
        <div className="space-y-1.5">
          {activeAlerts.map((alert) => {
            const cfg = ALERT_CONFIG[alert.alert_type] || ALERT_CONFIG.after_rain;
            const Icon = cfg.icon;
            const outcome = OUTCOME_CONFIG[alert.outcome_reported] || OUTCOME_CONFIG.not_visited;
            const isActive = alert.window_start && alert.window_end
              ? isWithinInterval(today, { start: parseISO(alert.window_start), end: parseISO(alert.window_end) })
              : true;

            return (
              <div key={alert.id} className={cn("p-2 rounded-lg border", cfg.color.split(" ").slice(1).join(" "), isActive && "ring-1 ring-inset ring-white/5")}>
                <div className="flex items-start gap-2">
                  <Icon className={cn("w-3 h-3 mt-0.5 shrink-0", cfg.color.split(" ")[0])} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <Badge className={cn("text-[9px] px-1.5 py-0 border", cfg.color)}>{cfg.label}</Badge>
                      {alert.window_start && (
                        <span className="text-[9px] text-white/30">
                          {format(parseISO(alert.window_start), "MMM d")}
                          {alert.window_end ? ` – ${format(parseISO(alert.window_end), "MMM d")}` : "+"}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] text-white/70 mt-0.5 font-medium">{alert.title}</p>
                    <p className="text-[9px] text-white/40 italic">{cfg.tip}</p>
                    {alert.message && <p className="text-[10px] text-white/50 mt-1">{alert.message}</p>}

                    {/* Outcome reporting */}
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className={cn("text-[9px]", outcome.color)}>{outcome.label}</span>
                      {alert.outcome_reported === "not_visited" && (
                        <div className="flex gap-1">
                          <button onClick={() => reportOutcomeMutation.mutate({ id: alert.id, outcome: "great_finds" })}
                            className="text-[9px] text-green-400/50 hover:text-green-400 transition">✓ Great finds</button>
                          <span className="text-white/20">·</span>
                          <button onClick={() => reportOutcomeMutation.mutate({ id: alert.id, outcome: "poor" })}
                            className="text-[9px] text-red-400/50 hover:text-red-400 transition">✗ Poor</button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="bg-[#14141e] border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-sm">Report Timing Window</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-white/50 block mb-1">Trigger</label>
              <Select value={form.alert_type} onValueChange={(v) => setForm({ ...form, alert_type: v })}>
                <SelectTrigger className="bg-white/5 border-white/10 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(ALERT_CONFIG).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Title</label>
              <Input placeholder="Heavy rain last night, creek running clear" value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="bg-white/5 border-white/10 text-sm" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-white/50 block mb-1">Window Start</label>
                <Input type="date" value={form.window_start} onChange={(e) => setForm({ ...form, window_start: e.target.value })}
                  className="bg-white/5 border-white/10 text-sm" />
              </div>
              <div>
                <label className="text-xs text-white/50 block mb-1">Window End</label>
                <Input type="date" value={form.window_end} onChange={(e) => setForm({ ...form, window_end: e.target.value })}
                  className="bg-white/5 border-white/10 text-sm" />
              </div>
            </div>
            <div>
              <label className="text-xs text-white/50 block mb-1">Notes (optional)</label>
              <Textarea placeholder="Additional context..." value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="bg-white/5 border-white/10 text-sm" rows={2} />
            </div>
            <Button
              onClick={() => createMutation.mutate(form)}
              disabled={!form.alert_type || !form.title || createMutation.isPending}
              className="w-full bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/20"
            >
              {createMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : null}
              Submit Window
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}