import { useEffect } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { escapeHtml } from "@/utils";

/**
 * Renders public land boundary outlines from location data.
 * Groups locations by land_manager and draws convex hull polygons.
 */
const MANAGER_COLORS = {
  "BLM": "#22c55e",
  "USFS": "#16a34a",
  "NPS": "#eab308",
  "FWS": "#3b82f6",
  "State Park": "#f59e0b",
  "State Land": "#84cc16",
};

export default function PublicLandLayer({ locations, visible }) {
  const map = useMap();

  useEffect(() => {
    if (!visible || !locations?.length) return;

    const layers = [];

    // Group locations by land_manager and draw approximate boundary circles
    const byManager = {};
    locations.forEach(loc => {
      const manager = loc.land_manager;
      if (!manager || manager === "Private" || manager === "Unknown" || manager === "Tribal") return;
      if (!loc.latitude || !loc.longitude) return;
      if (!byManager[manager]) byManager[manager] = [];
      byManager[manager].push([loc.latitude, loc.longitude]);
    });

    Object.entries(byManager).forEach(([manager, coords]) => {
      if (coords.length < 1) return;
      const color = MANAGER_COLORS[manager] || "#6b7280";

      coords.forEach(([lat, lng]) => {
        // Draw a circle around each public land location (approximate boundary)
        const circle = L.circle([lat, lng], {
          radius: 800, // ~0.5 mile
          color,
          weight: 1.5,
          fillColor: color,
          fillOpacity: 0.08,
          dashArray: "5, 5",
        }).addTo(map);
        circle.bindTooltip(`${escapeHtml(manager)} Land`, {
          className: "geo-heatmap-tooltip",
          direction: "top",
        });
        layers.push(circle);
      });
    });

    return () => layers.forEach(l => l.remove());
  }, [locations, visible, map]);

  return null;
}