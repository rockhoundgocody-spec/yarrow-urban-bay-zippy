import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import { escapeHtml } from "@/utils";

// Threshold distances in miles
const ENTER_RADIUS_MI = 1.0;
const NEAR_RADIUS_MI = 3.0;
const EARTH_R = 3958.8;

function haversineMi(lat1, lon1, lat2, lon2) {
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return EARTH_R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function isHighPotential(loc) {
  const score =
    (loc.mineral_prediction_confidence || 0) * 0.4 +
    ((loc.rating_avg || 0) / 5) * 100 * 0.3 +
    (loc.legality_status === "Safe Public" ? 100 : loc.legality_status === "Likely Legal" ? 70 : 30) * 0.3;
  return score >= 45;
}

export default function ProximityZonePulse({ userPos, locations }) {
  const map = useMap();
  const layerRef = useRef(null);

  useEffect(() => {
    if (!userPos || !locations?.length) return;

    if (layerRef.current) {
      layerRef.current.remove();
      layerRef.current = null;
    }

    const group = L.layerGroup().addTo(map);

    const highPotential = locations.filter(isHighPotential);

    highPotential.forEach((loc) => {
      if (!loc.latitude || !loc.longitude) return;
      const dist = haversineMi(userPos[0], userPos[1], loc.latitude, loc.longitude);

      if (dist > NEAR_RADIUS_MI) return;

      const isEntering = dist <= ENTER_RADIUS_MI;
      const color = isEntering ? "#f59e0b" : "#6366f1";
      const pulseColor = isEntering ? "rgba(245,158,11,0.35)" : "rgba(99,102,241,0.25)";
      const ringColor = isEntering ? "rgba(245,158,11,0.15)" : "rgba(99,102,241,0.1)";
      const label = isEntering ? "⚡ High-Potential Zone" : "◎ Promising Area Nearby";

      // Outer soft ring
      L.circle([loc.latitude, loc.longitude], {
        radius: isEntering ? 800 : 2400,
        color: color,
        fillColor: color,
        fillOpacity: 0.06,
        weight: 1.5,
        opacity: 0.35,
        dashArray: "6 4",
      }).addTo(group);

      // Animated pulse dot via divIcon
      const pulseIcon = L.divIcon({
        html: `
          <div style="position:relative;width:28px;height:28px;">
            <div style="
              position:absolute;inset:0;border-radius:50%;
              background:${pulseColor};
              animation:proximityPulse 2s ease-out infinite;
            "></div>
            <div style="
              position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
              width:12px;height:12px;border-radius:50%;
              background:${color};
              border:2px solid #fff;
              box-shadow:0 0 8px ${pulseColor};
            "></div>
          </div>
          <style>
            @keyframes proximityPulse {
              0% { transform: scale(0.8); opacity: 0.8; }
              70% { transform: scale(2.2); opacity: 0; }
              100% { transform: scale(0.8); opacity: 0; }
            }
          </style>
        `,
        className: "",
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      L.marker([loc.latitude, loc.longitude], { icon: pulseIcon, zIndexOffset: 200 })
        .bindTooltip(
          `<div style="font-size:11px;font-weight:600;color:#111">${escapeHtml(label)}</div>
           <div style="font-size:10px;color:#555;margin-top:2px">${escapeHtml(loc.name)}</div>
           <div style="font-size:10px;color:#888;margin-top:1px">${escapeHtml((loc.minerals_found || []).slice(0, 3).join(", "))}</div>`,
          {
            permanent: false,
            direction: "top",
            offset: [0, -16],
            className: "geo-heatmap-tooltip",
          }
        )
        .addTo(group);
    });

    layerRef.current = group;
    return () => {
      if (layerRef.current) {
        layerRef.current.remove();
        layerRef.current = null;
      }
    };
  }, [map, userPos, locations]);

  return null;
}