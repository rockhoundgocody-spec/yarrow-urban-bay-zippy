import { useState, useRef } from "react";
import { X, Trash2, Camera, Save } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { updatePin, deletePin } from "./FieldPinStorage";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const TYPE_OPTIONS = [
  { value: "find",      label: "💎 Interesting Find" },
  { value: "hazard",    label: "⚠️ Hazard" },
  { value: "base_camp", label: "⛺ Base Camp" },
  { value: "note",      label: "📝 Note" },
];

export default function FieldPinPanel({ pin, onClose, onUpdate, onDelete }) {
  const [type, setType]     = useState(pin.type || "note");
  const [title, setTitle]   = useState(pin.title || "");
  const [notes, setNotes]   = useState(pin.notes || "");
  const [photo, setPhoto]   = useState(pin.photo_url || null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();
  const isNew = !pin.title && !pin.notes;

  async function handlePhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPhoto(file_url);
    setUploading(false);
  }

  function save() {
    const updated = { ...pin, type, title, notes, photo_url: photo };
    const pins = updatePin(pin.id, { type, title, notes, photo_url: photo });
    onUpdate(updated, pins);
    onClose();
  }

  function remove() {
    const pins = deletePin(pin.id);
    onDelete(pins);
    onClose();
  }

  return (
    <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-30 w-80 bg-background rounded-2xl shadow-2xl border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-bold text-foreground text-sm">
          {isNew ? "New Field Pin" : "Edit Field Pin"}
        </h3>
        <button onClick={onClose} className="text-muted-foreground hover:text-foreground" aria-label="Close">
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-3">
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-full text-sm bg-background border-input text-foreground">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {TYPE_OPTIONS.map(o => (
              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <input
          value={title}
          onChange={e => setTitle(e.target.value)}
          placeholder="Title (e.g. Quartz vein spotted)"
          className="w-full text-sm border border-input rounded-lg px-3 py-2 text-foreground placeholder:text-muted-foreground bg-background"
        />

        <textarea
          value={notes}
          onChange={e => setNotes(e.target.value)}
          placeholder="Notes, observations..."
          rows={3}
          className="w-full text-sm border border-input rounded-lg px-3 py-2 text-foreground placeholder:text-muted-foreground bg-background resize-none"
        />

        {/* Photo */}
        {photo ? (
          <div className="relative">
            <img src={photo} alt="pin" className="w-full h-32 object-cover rounded-lg" />
            <button
              onClick={() => setPhoto(null)}
              className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1"
             aria-label="Close">
              <X className="w-3 h-3" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground border border-dashed border-input rounded-lg py-2 hover:border-amber-400 hover:text-amber-600 transition-all"
          >
            <Camera className="w-4 h-4" />
            {uploading ? "Uploading..." : "Add Photo"}
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />

        <div className="flex gap-2 pt-1">
          <button
            onClick={save}
            className="flex-1 flex items-center justify-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium rounded-lg py-2 transition-all"
          >
            <Save className="w-3.5 h-3.5" /> Save Pin
          </button>
          <button
            onClick={remove}
            className="px-3 py-2 rounded-lg border border-red-500/30 text-red-500 hover:bg-red-500/10 text-sm transition-all"
           aria-label="Delete">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <p className="text-[10px] text-muted-foreground text-center">
          📍 {pin.lat.toFixed(5)}, {pin.lng.toFixed(5)} · Saved offline
        </p>
      </div>
    </div>
  );
}