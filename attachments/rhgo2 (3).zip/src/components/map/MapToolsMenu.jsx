import React, { useState } from "react";
import {
  Menu, X, MessageCircle, CloudSun, Route, Globe,
  MapPin, PenLine, Share2, RefreshCw
} from "lucide-react";

const TOOL_GROUPS = [
  {
    label: "AI & Insights",
    items: [
      { key: "assistant", icon: MessageCircle, label: "AI Assistant", color: "bg-amber-500" },
      { key: "weather", icon: CloudSun, label: "Weather & Safety", color: "bg-sky-500" },
    ],
  },
  {
    label: "Map Tools",
    items: [
      { key: "routes", icon: Route, label: "Route Builder", color: "bg-emerald-500" },
      { key: "google", icon: Globe, label: "Google Maps", color: "bg-blue-600" },
      { key: "pin", icon: MapPin, label: "Drop Pin", color: "bg-amber-500" },
      { key: "polygon", icon: PenLine, label: "Draw Area Filter", color: "bg-violet-500" },
    ],
  },
  {
    label: "Actions",
    items: [
      { key: "share", icon: Share2, label: "Share View", color: "bg-teal-500" },
      { key: "refresh", icon: RefreshCw, label: "Refresh Data", color: "bg-gray-500" },
    ],
  },
];

export default function MapToolsMenu({ activeStates, onAction }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((p) => !p)}
        className={`w-9 h-9 rounded-full flex items-center justify-center shadow-lg border transition-all ${
          open
            ? "bg-gray-800 border-gray-700 text-white"
            : "bg-white border-gray-200 text-gray-600 hover:bg-gray-50"
        }`}
        style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.15)" }}
        aria-label="Map tools"
      >
        {open ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
      </button>

      {open && (
        <div
          className="absolute top-full mt-2 right-0 z-50 bg-white border border-gray-200 rounded-2xl p-2 min-w-56 shadow-2xl shadow-black/15"
          style={{ boxShadow: "0 8px 40px rgba(0,0,0,0.2)" }}
        >
          {TOOL_GROUPS.map((group, gi) => (
            <div key={group.label}>
              {gi > 0 && <div className="h-px bg-gray-100 my-1.5" />}
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest px-3 py-1.5">
                {group.label}
              </p>
              {group.items.map(({ key, icon: Icon, label, color }) => {
                const active = activeStates?.[key];
                return (
                  <button
                    key={key}
                    onClick={() => {
                      onAction(key);
                      // Keep menu open for toggles, close for one-shots
                      if (key === "share" || key === "refresh") setOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      active
                        ? "bg-gray-100 text-gray-900"
                        : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        active ? `${color} text-white` : "bg-gray-100 text-gray-500"
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span>{label}</span>
                    {active && (
                      <span className="ml-auto w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}