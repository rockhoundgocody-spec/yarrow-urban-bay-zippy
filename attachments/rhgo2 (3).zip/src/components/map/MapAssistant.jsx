import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Send, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import CloverCole3D from "../clover/CloverCole3D";
import { speak } from "../clover/voice";

const MAP_MENTOR_PROMPT = `You are Clover Cole, the in-app map wingwoman for RockHound GO.
Sound smooth, warm, field-smart, and a little playful, never robotic.
Reply in 2-3 short sentences by default.
Explain what the filters are doing, mention one to three promising leads from the provided locations, and include one access or safety caution when relevant.
End with a clear next tap or next filter change.`;

const MAP_STARTERS = [
  "Show me safer public quartz.",
  "What's the fun long-shot here?",
  "Tune this map for an easy weekend hunt.",
];

export default function MapAssistant({
  open,
  onClose,
  locations,
  filters,
  onFiltersChange,
  onLocationSelect,
  allMinerals
}) {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const parseFilterIntent = (query) => {
    const newFilters = { ...filters };
    const lowerQuery = query.toLowerCase();

    const foundMinerals = allMinerals.filter((mineral) =>
      lowerQuery.includes(mineral.toLowerCase())
    );
    if (foundMinerals.length > 0) {
      newFilters.minerals = foundMinerals;
    }

    if (lowerQuery.includes("easy")) newFilters.difficulties = ["easy"];
    if (lowerQuery.includes("hard") || lowerQuery.includes("difficult")) {
      newFilters.difficulties = ["difficult", "expert"];
    }

    if (lowerQuery.includes("public")) newFilters.site_types = ["public_land"];
    if (lowerQuery.includes("pay") || lowerQuery.includes("fee")) {
      newFilters.site_types = ["fee_dig"];
    }

    if (lowerQuery.includes("blm")) newFilters.land_managers = ["BLM"];
    if (lowerQuery.includes("forest") || lowerQuery.includes("usfs")) {
      newFilters.land_managers = ["USFS"];
    }

    if (lowerQuery.includes("rated") || lowerQuery.includes("popular")) {
      newFilters.min_rating = 4;
    }

    return newFilters;
  };

  async function send(queryOverride) {
    const userQuery = (queryOverride || input).trim();
    if (!userQuery || loading) return;

    setInput("");
    setMessages((prev) => [...prev, { user: userQuery, ai: null }]);
    setLoading(true);

    try {
      const updatedFilters = parseFilterIntent(userQuery);
      onFiltersChange(updatedFilters);

      const matchedLocations = locations.slice(0, 3);
      const res = await base44.functions.invoke("aiGateway", {
        prompt: `${MAP_MENTOR_PROMPT}

User asked: "${userQuery}"
Applied filters: ${JSON.stringify(updatedFilters, null, 2)}
Top matching locations: ${JSON.stringify(matchedLocations.map((location) => ({ name: location.name, state: location.state, minerals: location.minerals_found })), null, 2)}
Explain the best next move on the map without overpromising land access or finds.
Make the answer feel like a seamless part of the app, not a separate chatbot.`,
        task: "map_assistant"
      });

      const reply = res.data?.reply || "I tightened the map to your strongest leads. Open a pin, verify access, and compare the mineral list before you commit to the drive.";
      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1].ai = reply;
        return updated;
      });
      speak(reply);
    } catch (err) {
      console.error("Map assistant error:", err);
      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1].ai = "I narrowed the map to the best current leads I can infer. Open a pin and confirm access notes before you head out.";
        return updated;
      });
    } finally {
      setLoading(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed bottom-20 right-4 z-40 flex h-[520px] w-96 max-w-[calc(100vw-2rem)] flex-col rounded-2xl border border-white/10 bg-[#0a0a0f] shadow-2xl">
      <div className="flex shrink-0 items-center justify-between border-b border-white/5 p-4">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-[#5cff88] to-[#2d8a4a]">
            <span className="text-sm">🌿</span>
          </div>
          <div>
            <h3 className="font-semibold text-white">Clover Map Guide</h3>
            <p className="text-[10px] uppercase tracking-[0.18em] text-white/30">Map wingwoman</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="rounded-lg p-1 transition-colors hover:bg-white/5"
          aria-label="Close Assistant"
        >
          <X className="h-4 w-4 text-white/40" />
        </button>
      </div>

      <div
        ref={scrollRef}
        className="flex-1 space-y-3 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-white/10"
      >
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3">
            <CloverCole3D height={190} />
            <p className="text-center text-sm text-white/40">
              Ask for a mineral, travel style, or access filter and I'll narrow the map to the smartest next leads
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {MAP_STARTERS.map((starter) => (
                <button
                  key={starter}
                  onClick={() => send(starter)}
                  disabled={loading}
                  className="rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[11px] text-white/72 transition-all hover:border-emerald-300/30 hover:bg-emerald-300/8 hover:text-white disabled:opacity-50"
                >
                  {starter}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((message, index) => (
            <div key={index} className="space-y-2">
              <div className="flex justify-end">
                <div className="max-w-[80%] rounded-lg bg-amber-500/20 px-3 py-2 text-sm text-amber-300">
                  {message.user}
                </div>
              </div>
              {message.ai && (
                <div className="flex justify-start">
                  <div className="max-w-[80%] rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white/80">
                    {message.ai}
                  </div>
                </div>
              )}
              {!message.ai && (
                <div className="flex justify-start">
                  <Loader2 className="h-4 w-4 animate-spin text-white/40" />
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <div className="flex shrink-0 gap-2 border-t border-white/5 p-3">
        <input
          value={input}
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => event.key === "Enter" && send()}
          placeholder="Ask Clover to tune the map..."
          className="flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder:text-white/30 focus:outline-none focus:ring-1 focus:ring-amber-500/50"
          disabled={loading}
        />
        <Button
          onClick={() => send()}
          disabled={loading || !input.trim()}
          size="icon"
          aria-label="Send message"
          title="Send message"
          className="h-9 w-9 shrink-0 border border-amber-500/30 bg-amber-500/20 text-amber-400 hover:bg-amber-500/30"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </div>
    </div>
  );
}
