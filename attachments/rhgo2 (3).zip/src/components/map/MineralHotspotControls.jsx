import React, { useMemo } from "react";
import { Flame } from "lucide-react";
import { MINERAL_CATEGORIES } from "./MineralHotspotLayer";
import { cn } from "@/lib/utils";

export default function MineralHotspotControls({
  visible,
  onToggle,
  activeCategoryId,
  onCategoryChange,
  locations = [],
}) {
  // Count matching locations per category for badge numbers
  const counts = useMemo(() => {
    // ⚡ Bolt: Replace multiple O(N) filters and O(C*N*M) inline string allocations
    // with a single pass that pre-calculates the search string.
    const result = {};
    MINERAL_CATEGORIES.forEach(c => result[c.id] = 0);

    for (const loc of locations) {
      const foundLen = loc.minerals_found?.length || 0;
      const predLen = loc.predicted_minerals?.length || 0;
      if (foundLen === 0 && predLen === 0) continue;

      result.all += 1;

      const searchStr = [
        ...(loc.minerals_found || []),
        ...(loc.predicted_minerals || [])
      ].join("|").toLowerCase();

      for (let i = 1; i < MINERAL_CATEGORIES.length; i++) {
        const cat = MINERAL_CATEGORIES[i];
        if (cat.keywords.some(kw => searchStr.includes(kw))) {
          result[cat.id] += 1;
        }
      }
    }
    return result;
  }, [locations]);

  return (
    <div className="absolute bottom-4 right-4 z-[1000] flex flex-col items-end gap-2 pointer-events-none">
      {/* Toggle button */}
      <button
        onClick={onToggle}
        className={cn(
          "pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold shadow-lg border transition-all",
          visible
            ? "bg-orange-500 text-white border-orange-400"
            : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
        )}
        style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.15)" }}
      >
        <Flame className="w-3.5 h-3.5" />
        Mineral Hotspots
        {visible && (
          <span className="ml-1 bg-white/20 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">
            {counts[activeCategoryId] ?? 0}
          </span>
        )}
      </button>

      {/* Category pills — only when visible */}
      {visible && (
        <div
          className="pointer-events-auto bg-white rounded-2xl shadow-xl border border-gray-100 p-3 w-60"
          style={{ boxShadow: "0 4px 24px rgba(0,0,0,0.18)" }}
        >
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Filter by mineral type</p>
          <div className="flex flex-wrap gap-1.5">
            {MINERAL_CATEGORIES.map(cat => {
              const active = activeCategoryId === cat.id;
              const count = counts[cat.id] ?? 0;
              return (
                <button
                  key={cat.id}
                  onClick={() => onCategoryChange(cat.id)}
                  className={cn(
                    "flex items-center gap-1 px-2 py-1 rounded-full text-[10px] font-semibold border transition-all",
                    active
                      ? "text-white border-transparent shadow-sm"
                      : "bg-gray-50 text-gray-500 border-gray-200 hover:border-gray-300"
                  )}
                  style={active ? { background: cat.color, borderColor: cat.color } : {}}
                >
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ background: cat.color, opacity: active ? 1 : 0.6 }}
                  />
                  {cat.label}
                  {count > 0 && (
                    <span className={cn("ml-0.5", active ? "text-white/80" : "text-gray-400")}>
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Color legend strip */}
          <div className="mt-3 pt-2.5 border-t border-gray-100">
            <p className="text-[9px] text-gray-400 mb-1.5">Intensity legend</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-2 rounded-full" style={{ background: "linear-gradient(90deg, #0033aa55, #ffeb3b, #ffffff)" }} />
              <div className="flex justify-between w-full text-[9px] text-gray-400 absolute left-0 px-3 pt-1" style={{ position: "relative" }}>
                <span>Few</span>
                <span>Many</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}