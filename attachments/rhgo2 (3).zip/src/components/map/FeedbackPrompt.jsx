import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageSquarePlus, X, Star, Send, CheckCircle2, ChevronRight } from "lucide-react";

const PROMPTS = [
  { id: "map_accuracy", label: "Is the map data accurate?", type: "rating", icon: "🗺️" },
  { id: "missing_location", label: "Know a missing location?", type: "text", placeholder: "Describe the location...", icon: "📍" },
  { id: "feature_request", label: "What feature would help most?", type: "choice", choices: ["Better search", "Offline maps", "More minerals data", "Trip planning", "Community chat"], icon: "✨" },
  { id: "app_rating", label: "How's your experience so far?", type: "rating", icon: "⭐" },
  { id: "report_issue", label: "Spot a bug or data error?", type: "text", placeholder: "Describe the issue...", icon: "🐛" },
];

export default function FeedbackPrompt() {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState(0); // which prompt
  const [rating, setRating] = useState(0);
  const [text, setText] = useState("");
  const [choice, setChoice] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [dismissed, setDismissed] = useState(() => {
    try { return JSON.parse(localStorage.getItem("feedback_dismissed") || "false"); } catch { return false; }
  });
  const [nudgeVisible, setNudgeVisible] = useState(false);

  // Show nudge after 30s on map page
  useEffect(() => {
    if (dismissed) return;
    const t = setTimeout(() => setNudgeVisible(true), 30000);
    return () => clearTimeout(t);
  }, [dismissed]);

  const prompt = PROMPTS[step];

  const handleSubmit = () => {
    // Store feedback locally (could be sent to an entity/function in a real app)
    const feedback = {
      prompt_id: prompt.id,
      value: prompt.type === "rating" ? rating : prompt.type === "text" ? text : choice,
      timestamp: new Date().toISOString(),
    };
    let existing = [];
    try { existing = JSON.parse(localStorage.getItem("user_feedback") || "[]"); } catch { existing = []; }
    localStorage.setItem("user_feedback", JSON.stringify([...existing, feedback]));
    setSubmitted(true);
    setTimeout(() => {
      if (step < PROMPTS.length - 1) {
        setStep(s => s + 1);
        setRating(0); setText(""); setChoice(null); setSubmitted(false);
      } else {
        setOpen(false);
        setDismissed(true);
        localStorage.setItem("feedback_dismissed", "true");
      }
    }, 1200);
  };

  const canSubmit = prompt?.type === "rating" ? rating > 0
    : prompt?.type === "text" ? text.trim().length > 2
    : choice !== null;

  const dismiss = () => {
    setNudgeVisible(false);
    setOpen(false);
    setDismissed(true);
    localStorage.setItem("feedback_dismissed", "true");
  };

  return (
    <>
      {/* Nudge bubble */}
      <AnimatePresence>
        {nudgeVisible && !open && !dismissed && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute bottom-28 right-3 z-30 flex items-end gap-2"
          >
            <div className="rounded-2xl px-3.5 py-2.5 text-xs font-medium text-white max-w-[160px] leading-snug cursor-pointer"
              style={{ background: "linear-gradient(135deg,#6366f1,#8b5cf6)", boxShadow: "0 4px 20px rgba(99,102,241,0.45)" }}
              onClick={() => { setNudgeVisible(false); setOpen(true); }}>
              💬 Quick question for you!
              <ChevronRight className="inline w-3 h-3 ml-0.5" />
            </div>
            <button onClick={() => setNudgeVisible(false)} className="mb-0.5 text-white/60 hover:text-white/90 transition-all" aria-label="Dismiss" title="Dismiss">
              <span className="sr-only">Dismiss</span>
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating feedback button */}
      {!nudgeVisible && !dismissed && (
        <button
          onClick={() => setOpen(true)}
          title="Give feedback"
          className="absolute bottom-28 right-3 z-30 w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 active:scale-95"
          style={{ background: "linear-gradient(135deg,#6366f1,#8b5cf6)", boxShadow: "0 4px 20px rgba(99,102,241,0.4)" }}
        >
          <MessageSquarePlus className="w-4 h-4 text-white" />
        </button>
      )}

      {/* Feedback modal */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 z-40 bg-black/30 backdrop-blur-sm" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.95 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute bottom-28 right-3 left-3 z-50 max-w-sm mx-auto rounded-2xl p-5"
              style={{ background: "linear-gradient(135deg,#1a1a2e,#16213e)", border: "1px solid rgba(99,102,241,0.4)", boxShadow: "0 20px 60px rgba(0,0,0,0.5), 0 0 30px rgba(99,102,241,0.2)" }}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{prompt.icon}</span>
                  <div>
                    <p className="text-[10px] text-indigo-400/70 font-bold uppercase tracking-widest">Feedback {step + 1}/{PROMPTS.length}</p>
                    <h3 className="text-sm font-bold text-white leading-tight">{prompt.label}</h3>
                  </div>
                </div>
                <button onClick={() => setOpen(false)} className="text-white/30 hover:text-white/60 transition-all p-1" aria-label="Close feedback modal" title="Close feedback modal">
                  <span className="sr-only">Close feedback modal</span>
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Progress dots */}
              <div className="flex gap-1.5 mb-4">
                {PROMPTS.map((_, i) => (
                  <div key={i} className="h-1 rounded-full flex-1 transition-all"
                    style={{ background: i <= step ? "#6366f1" : "rgba(255,255,255,0.1)" }} />
                ))}
              </div>

              <AnimatePresence mode="wait">
                {submitted ? (
                  <motion.div key="done" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center gap-2 py-4">
                    <CheckCircle2 className="w-8 h-8 text-green-400" />
                    <p className="text-white/70 text-sm font-medium">Thanks for the feedback!</p>
                  </motion.div>
                ) : (
                  <motion.div key={prompt.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
                    {/* Rating input */}
                    {prompt.type === "rating" && (
                      <div className="flex gap-2 justify-center mb-4">
                        {[1, 2, 3, 4, 5].map(n => (
                          <button key={n} onClick={() => setRating(n)}
                            className="w-10 h-10 rounded-full text-xl transition-all hover:scale-110 active:scale-95"
                            style={{ background: n <= rating ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.05)", border: `1px solid ${n <= rating ? "rgba(99,102,241,0.6)" : "rgba(255,255,255,0.1)"}` }} aria-label="Rate">
                            <Star className="w-5 h-5 mx-auto" fill={n <= rating ? "#fbbf24" : "none"} stroke={n <= rating ? "#fbbf24" : "rgba(255,255,255,0.3)"} />
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Text input */}
                    {prompt.type === "text" && (
                      <textarea
                        value={text}
                        onChange={e => setText(e.target.value)}
                        placeholder={prompt.placeholder}
                        rows={3}
                        className="w-full rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-white/25 focus:outline-none resize-none mb-3"
                        style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(99,102,241,0.3)" }}
                        autoFocus
                      />
                    )}

                    {/* Choice input */}
                    {prompt.type === "choice" && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {prompt.choices.map(c => (
                          <button key={c} onClick={() => setChoice(c)}
                            className="px-3 py-1.5 rounded-full text-xs font-medium transition-all"
                            style={{
                              background: choice === c ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.05)",
                              border: `1px solid ${choice === c ? "rgba(99,102,241,0.6)" : "rgba(255,255,255,0.1)"}`,
                              color: choice === c ? "#a5b4fc" : "rgba(255,255,255,0.5)",
                            }}>
                            {c}
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Submit / Skip row */}
                    <div className="flex gap-2">
                      <button onClick={dismiss} className="flex-1 py-2 rounded-xl text-xs font-medium text-white/30 hover:text-white/50 transition-all"
                        style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                        Skip all
                      </button>
                      <button onClick={handleSubmit} disabled={!canSubmit}
                        className="flex-[2] py-2 rounded-xl text-sm font-bold text-white flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40"
                        style={{ background: "linear-gradient(135deg,#6366f1,#8b5cf6)", boxShadow: canSubmit ? "0 0 16px rgba(99,102,241,0.4)" : "none" }}>
                        <Send className="w-3.5 h-3.5" />
                        {step < PROMPTS.length - 1 ? "Submit & Next" : "Submit"}
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}