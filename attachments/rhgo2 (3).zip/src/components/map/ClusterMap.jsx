import { useEffect, useRef, useCallback, useMemo } from "react";
import { useMap } from "react-leaflet";
import L from "leaflet";
import Supercluster from "supercluster";
import { createGeoLocationIcon, createGeoClusterIcon } from "./GeoMarkerIcons";
import { escapeHtml } from "@/utils";

const CLUSTER_RADIUS = 60;
const CLUSTER_MAX_ZOOM = 14;

export default function ClusterMap({ locations, onSelect, selectedId }) {
  const map = useMap();
  const layerRef = useRef(null);
  const indexRef = useRef(null);

  const points = useMemo(() => locations.map((loc) => ({
    type: "Feature",
    properties: { id: loc.id, location: loc },
    geometry: { type: "Point", coordinates: [loc.longitude, loc.latitude] },
  })), [locations]);

  const renderClusters = useCallback(() => {
    if (!indexRef.current) return;
    if (layerRef.current) {
      layerRef.current.clearLayers();
    } else {
      layerRef.current = L.layerGroup().addTo(map);
    }

    const bounds = map.getBounds();
    const zoom = map.getZoom();
    const bbox = [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()];
    const clusters = indexRef.current.getClusters(bbox, zoom);

    clusters.forEach((feature) => {
      const [lng, lat] = feature.geometry.coordinates;
      const { cluster, point_count, cluster_id } = feature.properties;

      if (cluster) {
        const marker = L.marker([lat, lng], { icon: createGeoClusterIcon(point_count) });
        marker.on("click", () => {
          const expansionZoom = Math.min(
            indexRef.current.getClusterExpansionZoom(cluster_id),
            CLUSTER_MAX_ZOOM
          );
          map.flyTo([lat, lng], expansionZoom, { duration: 0.8 });
        });
        layerRef.current.addLayer(marker);
      } else {
        const loc = feature.properties.location;
        const isSelected = loc.id === selectedId;
        const marker = L.marker([lat, lng], { icon: createGeoLocationIcon(loc, isSelected) });
        marker.on("click", () => onSelect(loc));
        marker.bindTooltip(escapeHtml(loc.name), { direction: "top", offset: [0, -10], className: "leaflet-tooltip-light" });
        layerRef.current.addLayer(marker);
      }
    });
  }, [map, onSelect, selectedId]);

  // Build supercluster index when points change
  useEffect(() => {
    const sc = new Supercluster({ radius: CLUSTER_RADIUS, maxZoom: CLUSTER_MAX_ZOOM, minPoints: 3 });
    sc.load(points);
    indexRef.current = sc;
    renderClusters();
  }, [points, renderClusters]);

  // Re-render only after pan/zoom ends (eliminates lag)
  useEffect(() => {
    const handler = () => renderClusters();
    map.on("moveend zoomend", handler);
    return () => {
      map.off("moveend zoomend", handler);
      if (layerRef.current) layerRef.current.clearLayers();
    };
  }, [map, renderClusters]);

  return null;
}