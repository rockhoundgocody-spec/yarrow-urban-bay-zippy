/**
 * GPSFallback — high-contrast fallback UI for all GPS failure states.
 * States: denied | pending | unavailable | timeout | offline
 * Field-use optimized: large text, clear action, no blank screens.
 */
import React from "react";
import { motion } from "framer-motion";
import { Navigation, WifiOff, Clock, MapPinOff, ShieldAlert, RefreshCw } from "lucide-react";

const STATE_CONFIG = {
  denied: {
    icon: ShieldAlert,
    color: "#FF6B6B",
    title: "GPS Access Denied",
    body: "RockHound-GO needs location access to show field intelligence. Enable it in your browser or device settings.",
    action: "Open Settings",
    actionFn: () => {
      // On mobile browsers, just prompt again — iOS/Android handles the dialog
      if (navigator.permissions?.query) {
        navigator.permissions.query({ name: "geolocation" }).catch(() => {});
      }
      window.open("app-settings:", "_blank");
    },
  },
  pending: {
    icon: Navigation,
    color: "#F5B642",
    title: "Waiting for GPS…",
    body: "Acquiring your location. This may take a few seconds on first use.",
    action: null,
  },
  unavailable: {
    icon: MapPinOff,
    color: "#F5B642",
    title: "Location Unavailable",
    body: "Your device location is unavailable. Field intelligence will use the Illinois region fallback.",
    action: "Use Region Data",
  },
  timeout: {
    icon: Clock,
    color: "#F5B642",
    title: "GPS Timed Out",
    body: "Couldn't get a precise fix. Using region-based field data instead.",
    action: "Retry",
  },
  offline: {
    icon: WifiOff,
    color: "#7AE7FF",
    title: "No Signal",
    body: "You're offline. Cached field data and your offline map are still available.",
    action: "View Offline Map",
    actionPath: "/OfflineMap",
  },
};

export default function GPSFallback({
  state = "pending",   // denied | pending | unavailable | timeout | offline
  onRetry,
  onDismiss,
  compact = false,
  variant = "dark",    // dark | ledger
}) {
  const cfg = STATE_CONFIG[state] || STATE_CONFIG.pending;
  const Icon = cfg.icon;

  const handleAction = () => {
    if (cfg.actionPath) {
      window.location.href = cfg.actionPath;
    } else if (cfg.actionFn) {
      cfg.actionFn();
    } else {
      onRetry?.();
    }
  };

  if (compact && variant === "ledger") {
    return (
      <motion.div
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="px-4 py-3"
        style={{
          background: "#E9DFC6",
          border: "1.5px solid #3B342A",
          borderRadius: 6,
          boxShadow: "2px 2px 0 rgba(59,52,42,0.35)",
          fontFamily: "Georgia, 'Times New Roman', serif",
        }}
      >
        <div className="flex items-center gap-2 mb-1">
          <Icon className="w-4 h-4 flex-shrink-0" style={{ color: "#2A241B" }} />
          <h3 className="text-sm font-black" style={{ color: "#2A241B" }}>GPS Status</h3>
        </div>
        <p className="text-[13px] leading-relaxed" style={{ color: "#4A4335" }}>
          {cfg.title} — {cfg.body}
        </p>
        {cfg.action && (
          <button
            onClick={handleAction}
            className="mt-2 text-xs font-bold px-3 py-1.5"
            style={{ background: "#F5F0E3", border: "1.5px solid #3B342A", borderRadius: 6, color: "#2A241B" }}
          >
            {cfg.action}
          </button>
        )}
      </motion.div>
    );
  }

  if (compact) {
    return (
      <motion.div
        initial={{ opacity: 0, y: -4 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3 rounded-2xl px-4 py-3"
        style={{
          background: `${cfg.color}08`,
          border: `1px solid ${cfg.color}25`,
        }}
      >
        <Icon className="w-4 h-4 flex-shrink-0" style={{ color: cfg.color }} />
        <p className="text-xs flex-1" style={{ color: "rgba(255,255,255,0.55)" }}>
          {cfg.title} — {cfg.body}
        </p>
        {cfg.action && (
          <button
            onClick={handleAction}
            className="text-xs font-bold px-3 py-1.5 rounded-xl flex-shrink-0"
            style={{ background: `${cfg.color}18`, color: cfg.color }}
          >
            {cfg.action}
          </button>
        )}
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center gap-5 rounded-2xl px-6 py-10 text-center"
      style={{
        background: `linear-gradient(145deg, rgba(10,15,20,0.9), rgba(6,10,14,0.95))`,
        border: `1px solid ${cfg.color}20`,
        minHeight: 220,
      }}
    >
      {/* Animated icon */}
      <motion.div
        className="w-14 h-14 rounded-2xl flex items-center justify-center"
        style={{ background: `${cfg.color}12`, border: `1px solid ${cfg.color}30` }}
        animate={state === "pending" ? { opacity: [0.6, 1, 0.6] } : {}}
        transition={{ duration: 1.8, repeat: Infinity }}
      >
        <Icon className="w-7 h-7" style={{ color: cfg.color }} />
      </motion.div>

      <div className="space-y-1.5 max-w-xs">
        <h3 className="text-base font-black text-white">{cfg.title}</h3>
        <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.42)" }}>
          {cfg.body}
        </p>
      </div>

      <div className="flex flex-col gap-2 w-full max-w-xs">
        {cfg.action && (
          <button
            onClick={handleAction}
            className="w-full py-3 rounded-2xl font-bold text-sm"
            style={{ background: `${cfg.color}18`, border: `1px solid ${cfg.color}35`, color: cfg.color }}
          >
            {cfg.action}
          </button>
        )}
        {onRetry && state !== "pending" && (
          <button
            onClick={onRetry}
            className="w-full py-3 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)" }}
          >
            <RefreshCw className="w-4 h-4" /> Retry GPS
          </button>
        )}
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="text-xs py-2"
            style={{ color: "rgba(255,255,255,0.2)" }}
          >
            Continue without GPS
          </button>
        )}
      </div>
    </motion.div>
  );
}