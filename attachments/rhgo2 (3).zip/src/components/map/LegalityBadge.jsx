/**
 * LegalityBadge
 * Risk-level color-coded badge for parcel access state.
 */
import React from "react";

const RISK_PALETTE = {
  blocked: { bg: "rgba(255,107,122,0.12)", border: "rgba(255,107,122,0.35)", color: "#ff6b7a" },
  high:    { bg: "rgba(244,200,106,0.12)", border: "rgba(244,200,106,0.32)", color: "#f4c86a" },
  med:     { bg: "rgba(244,200,106,0.10)", border: "rgba(244,200,106,0.26)", color: "#f4c86a" },
  low:     { bg: "rgba(78,226,154,0.10)",  border: "rgba(78,226,154,0.28)",  color: "#4ee29a" },
};

export function LegalityBadge({ level, label }) {
  const p = RISK_PALETTE[level] || RISK_PALETTE.high;
  return (
    <span
      className="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-black tracking-wider"
      style={{ background: p.bg, border: `1px solid ${p.border}`, color: p.color }}
    >
      {label}
    </span>
  );
}

export function riskLevelToLabel(level) {
  if (level === "blocked") return "COLLECTING BLOCKED";
  if (level === "high")    return "ACCESS UNVERIFIED";
  if (level === "med")     return "PERMIT / RULE CHECK";
  return "LOW RESTRICTION SIGNAL";
}