import { useEffect, useRef } from "react";
import { useMap } from "react-leaflet";

export default function MapEventHandler({ onBoundsChange, onMapClick, onMapReady }) {
  const map = useMap();
  const timerRef = useRef(null);

  useEffect(() => {
    if (onMapReady) onMapReady(map);
    // Force Leaflet to recalculate container size (critical on mobile)
    map.invalidateSize();
    const t = setTimeout(() => map.invalidateSize(), 300);
    return () => clearTimeout(t);
  }, [map, onMapReady]);

  useEffect(() => {
    const handleMoveEnd = () => {
      clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => {
        const bounds = map.getBounds();
        const center = map.getCenter();
        onBoundsChange({
          bounds: {
            north: bounds.getNorth(),
            south: bounds.getSouth(),
            east: bounds.getEast(),
            west: bounds.getWest(),
          },
          center: [center.lat, center.lng],
          zoom: map.getZoom(),
        });
      }, 600);
    };

    map.on("moveend", handleMoveEnd);
    return () => {
      map.off("moveend", handleMoveEnd);
      clearTimeout(timerRef.current);
    };
  }, [map, onBoundsChange]);

  // Handle pin-drop clicks
  useEffect(() => {
    if (!onMapClick) return;
    const handler = (e) => onMapClick(e.latlng);
    map.on("click", handler);
    return () => map.off("click", handler);
  }, [map, onMapClick]);

  return null;
}