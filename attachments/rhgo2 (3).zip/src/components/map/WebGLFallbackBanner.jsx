import React, { useState, useEffect } from "react";
import { X } from "lucide-react";

/**
 * WebGLFallbackBanner — non-intrusive amber degradation banner.
 * Fixed to the top of the map container (not the page).
 * Auto-dismisses after 6 seconds. No modal, no blocking overlay.
 */
export default function WebGLFallbackBanner({ message = "3D map unavailable on this device — showing standard view" }) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 6000);
    return () => clearTimeout(timer);
  }, []);

  if (!visible) return null;

  return (
    <div
      className="absolute top-0 left-0 right-0 z-[1000] flex items-center justify-between px-3"
      style={{
        height: 32,
        background: "rgba(245,182,66,0.12)",
        borderBottom: "1px solid rgba(245,182,66,0.25)",
        backdropFilter: "blur(8px)",
      }}
    >
      <span
        style={{
          fontSize: 11,
          color: "#F5B642",
          fontWeight: 600,
          letterSpacing: "0.02em",
          lineHeight: 1,
        }}
      >
        {message}
      </span>
      <button
        onClick={() => setVisible(false)}
        className="tap-compact flex items-center justify-center"
        style={{ width: 24, height: 24, borderRadius: 6, color: "rgba(245,182,66,0.7)" }}
        aria-label="Dismiss"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}