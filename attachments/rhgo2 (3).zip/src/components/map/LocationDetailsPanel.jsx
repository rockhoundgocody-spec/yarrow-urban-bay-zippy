import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Star, Camera, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import SaveSiteButton from "./SaveSiteButton";
import RiskBadges from "./RiskBadges";
import LocalityLedger from "./LocalityLedger";
import TimingAlerts from "./TimingAlerts";
import ReviewSection from "./ReviewSection";
import MineralPrediction from "./MineralPrediction";
import TrustScore from "./TrustScore";

export default function LocationDetailsPanel({ location, onClose, user }) {
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [showPhotoForm, setShowPhotoForm] = useState(false);
  const [review, setReview] = useState({ rating: 5, title: "", text: "" });
  const [photoFile, setPhotoFile] = useState(null);
  const [photoPreview, setPhotoPreview] = useState("");
  const [photo, setPhoto] = useState({ specimen_name: "", description: "" });
  const queryClient = useQueryClient();

  const { data: reviews = [] } = useQuery({
    queryKey: ["reviews", location.id],
    queryFn: () => base44.entities.LocationReview.filter({ location_id: location.id }, "-created_date", 50),
    enabled: false, // legacy — ReviewSection handles new reviews
  });

  const { data: photos = [] } = useQuery({
    queryKey: ["photos", location.id],
    queryFn: () => base44.entities.LocationPhoto.filter({ location_id: location.id }, "-created_date", 20),
  });

  const { data: nearbyLocations = [] } = useQuery({
    queryKey: ["nearby", location.id],
    queryFn: async () => {
      const all = await base44.entities.RockhoundingLocation.list("-created_date", 100);
      return all.filter(
        (l) =>
          l.id !== location.id &&
          (l.site_type === location.site_type ||
            l.minerals_found?.some((m) => location.minerals_found?.includes(m)))
      ).slice(0, 5);
    },
  });

  const createReviewMutation = useMutation({
    mutationFn: (data) =>
      base44.entities.LocationReview.create({ ...data, location_id: location.id }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["reviews", location.id] });
      setShowReviewForm(false);
      setReview({ rating: 5, title: "", text: "" });
    },
  });

  const createPhotoMutation = useMutation({
    mutationFn: async (data) => {
      const uploadRes = await base44.integrations.Core.UploadFile({ file: photoFile });
      return base44.entities.LocationPhoto.create({
        ...data,
        location_id: location.id,
        photo_url: uploadRes.file_url,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["photos", location.id] });
      setShowPhotoForm(false);
      setPhotoFile(null);
      setPhotoPreview("");
      setPhoto({ specimen_name: "", description: "" });
    },
  });

  const handlePhotoSelect = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      setPhotoFile(file);
      const reader = new FileReader();
      reader.onload = (evt) => setPhotoPreview(evt.target?.result);
      reader.readAsDataURL(file);
    }
  };

  const avgRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : 0;

  return (
    <div className="absolute bottom-0 left-0 right-0 md:bottom-0 md:left-0 md:top-auto md:right-auto md:w-96 md:h-full bg-white z-30 flex flex-col shadow-2xl" style={{ borderRadius: "20px 20px 0 0", maxHeight: "75vh" }}>
      {/* Drag handle (mobile) */}
      <div className="flex justify-center pt-2.5 pb-0 shrink-0 md:hidden">
        <div className="w-10 h-1 rounded-full bg-gray-300" />
      </div>
      {/* Header */}
      <div className="p-5 border-b border-gray-100 bg-white md:rounded-none" style={{ borderRadius: "20px 20px 0 0" }}>
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1 pr-2">
            <h2 className="text-base font-bold text-gray-900 leading-tight">{location.name}</h2>
            <p className="text-xs text-gray-400 mt-0.5">{[location.county, location.state, location.country].filter(Boolean).join(", ")}</p>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            <SaveSiteButton location={location} user={user} size="sm" />
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600 transition-colors" aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Rating */}
        {reviews.length > 0 && (
          <div className="flex items-center gap-2 text-xs">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={cn("w-3.5 h-3.5", i < Math.round(avgRating) ? "fill-amber-400 text-amber-400" : "text-gray-200")}
                />
              ))}
            </div>
            <span className="font-semibold text-gray-700">{avgRating}</span>
            <span className="text-gray-400">({reviews.length} reviews)</span>
          </div>
        )}
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 bg-white">
        <div className="p-4 space-y-4">
          {/* Site type badge */}
          {location.site_type && (
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-indigo-50 text-indigo-600 text-xs font-semibold border border-indigo-100">
                📍 {location.site_type.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
              </span>
            </div>
          )}

          {/* ── Rocks You Might Find (hero section) ── */}
          <div>
            <p className="text-base font-bold text-gray-900 mb-0.5">Rocks You Might Find</p>
            <p className="text-xs text-gray-400 mb-3">
              {(location.minerals_found?.length || 0) + (location.predicted_minerals?.length || 0)} matches found
            </p>
            {location.minerals_found?.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-3">
                {location.minerals_found.map((m) => (
                  <Badge key={m} className="text-xs bg-gray-100 text-gray-700 border-gray-200 font-medium px-2.5 py-1">
                    {m}
                  </Badge>
                ))}
              </div>
            )}
            <div className="rounded-xl border border-gray-100 overflow-hidden shadow-sm">
              <MineralPrediction location={location} />
            </div>
          </div>

          {/* Trust Score */}
          <TrustScore location={location} />

          {/* Risk / Legal */}
          {(location.land_manager || location.access_type || location.permit_required) && (
            <div className="bg-gray-50 rounded-xl p-4 border border-gray-100 space-y-2">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Ownership & Legal</p>
              <RiskBadges location={location} />
              {location.collection_limit && (
                <p className="text-[10px] text-gray-400">Collection limit: <span className="font-semibold text-gray-600">{location.collection_limit}</span></p>
              )}
              {location.best_season && (
                <p className="text-[10px] text-gray-400">Best season: <span className="font-semibold text-gray-600">{location.best_season}</span></p>
              )}
            </div>
          )}

          {/* Photos */}
          {photos.length > 0 && (
            <div>
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Specimen Photos ({photos.length})</p>
              <div className="grid grid-cols-2 gap-2">
                {photos.map((p) => (
                  <div key={p.id} className="rounded-xl overflow-hidden border border-gray-100 shadow-sm">
                    <img src={p.photo_url} alt={p.specimen_name} className="w-full h-28 object-cover" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Nearby Locations */}
          {nearbyLocations.length > 0 && (
            <div>
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Nearby Locations</p>
              <div className="space-y-1.5">
                {nearbyLocations.map((l) => (
                  <div key={l.id} className="p-3 rounded-xl bg-white border border-gray-100 shadow-sm">
                    <p className="text-xs font-semibold text-gray-700">{l.name}</p>
                    <p className="text-[10px] text-gray-400">{l.state}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Locality Ledger */}
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <LocalityLedger location={location} />
          </div>

          {/* Timing Windows */}
          <div className="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
            <TimingAlerts location={location} />
          </div>

          {/* Reviews */}
          <ReviewSection location={location} user={user} />
        </div>
      </ScrollArea>

      {/* Action Buttons */}
      <div className="p-4 border-t border-gray-100 bg-white flex gap-2">
        <Button
          size="sm"
          onClick={() => setShowPhotoForm(true)}
          className="w-full bg-amber-500 hover:bg-amber-600 text-white border-0 shadow-sm"
        >
          <Camera className="w-3 h-3 mr-1.5" /> Add Photo
        </Button>
      </div>

      {/* Photo Form Dialog */}
      <Dialog open={showPhotoForm} onOpenChange={setShowPhotoForm}>
        <DialogContent className="bg-white border-gray-200 text-gray-900">
          <DialogHeader>
            <DialogTitle>Upload Specimen Photo</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-gray-500 font-medium block mb-2">Select Photo</label>
              <input
                type="file"
                accept="image/*"
                onChange={handlePhotoSelect}
                className="w-full text-xs text-gray-500 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:bg-amber-50 file:text-amber-600 file:border file:border-amber-200 file:cursor-pointer file:text-xs file:font-medium"
              />
              {photoPreview && <img src={photoPreview} alt="preview" className="mt-2 w-full max-h-40 object-contain rounded-xl border border-gray-100" />}
            </div>
            <div>
              <label className="text-xs text-gray-500 font-medium block mb-1">Specimen Name</label>
              <Input
                placeholder="e.g., Clear Quartz Crystal"
                value={photo.specimen_name}
                onChange={(e) => setPhoto({ ...photo, specimen_name: e.target.value })}
                className="bg-gray-50 border-gray-200 text-gray-900 text-sm"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500 font-medium block mb-1">Description (optional)</label>
              <Textarea
                placeholder="Details about the find..."
                value={photo.description}
                onChange={(e) => setPhoto({ ...photo, description: e.target.value })}
                className="bg-gray-50 border-gray-200 text-gray-900 text-sm"
                rows={2}
              />
            </div>
            <Button
              onClick={() => createPhotoMutation.mutate(photo)}
              disabled={!photoFile || !photo.specimen_name || createPhotoMutation.isPending}
              className="w-full bg-amber-500 hover:bg-amber-600 text-white border-0"
            >
              {createPhotoMutation.isPending ? <Loader2 className="w-3 h-3 animate-spin mr-2" /> : null}
              Upload Photo
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}