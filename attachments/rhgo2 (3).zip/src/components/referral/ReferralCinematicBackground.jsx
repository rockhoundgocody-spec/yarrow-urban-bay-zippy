import React, { useMemo } from "react";
import { motion } from "framer-motion";

/**
 * ReferralCinematicBackground
 * Hollywood-grade atmospheric backdrop for the Referral hub.
 * Layered aurora gradients, drifting crystal embers, slow light sweep, vignette.
 * Pointer-events:none, pure CSS + framer-motion, deterministic particles.
 */
export default function ReferralCinematicBackground() {
  // Deterministic ember field — no runtime randomness for stable paint
  const embers = useMemo(
    () =>
      Array.from({ length: 22 }, (_, i) => {
        const seed = (i * 9301 + 49297) % 233280;
        const r = seed / 233280;
        const r2 = ((i * 4523 + 7891) % 233280) / 233280;
        return {
          id: i,
          left: 4 + r * 92,
          top: 8 + r2 * 88,
          size: 2 + r * 4,
          delay: r * 6,
          duration: 7 + r2 * 8,
          hue: i % 3 === 0 ? "#8D7CFF" : i % 3 === 1 ? "#7AE7FF" : "#D4AF37",
          drift: 18 + r * 34,
        };
      }),
    []
  );

  return (
    <div
      aria-hidden
      className="absolute inset-0 overflow-hidden pointer-events-none"
      style={{ zIndex: 0 }}
    >
      {/* ── Base cinematic color grade ── */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse 80% 60% at 50% 0%, rgba(141,124,255,0.20) 0%, transparent 60%)," +
            "radial-gradient(ellipse 70% 50% at 20% 100%, rgba(122,231,255,0.14) 0%, transparent 55%)," +
            "radial-gradient(ellipse 60% 50% at 85% 70%, rgba(212,175,55,0.10) 0%, transparent 55%)," +
            "linear-gradient(160deg, #04020E 0%, #08061A 55%, #05030F 100%)",
        }}
      />

      {/* ── Slow aurora ribbon (conic, rotating) ── */}
      <motion.div
        className="absolute"
        style={{
          top: "-30%", left: "-40%", width: "180%", height: "160%",
          background:
            "conic-gradient(from 0deg at 50% 50%, transparent 0deg, rgba(141,124,255,0.10) 50deg, transparent 120deg, rgba(122,231,255,0.08) 180deg, transparent 240deg, rgba(212,175,55,0.06) 300deg, transparent 360deg)",
          filter: "blur(48px)",
        }}
        animate={{ rotate: 360 }}
        transition={{ duration: 90, ease: "linear", repeat: Infinity }}
      />

      {/* ── Liquid metal drift band ── */}
      <motion.div
        className="absolute inset-x-0"
        style={{
          top: "30%", height: "40%",
          background:
            "linear-gradient(110deg, transparent 0%, rgba(141,124,255,0.08) 30%, rgba(122,231,255,0.10) 50%, rgba(141,124,255,0.08) 70%, transparent 100%)",
          backgroundSize: "200% 100%",
          filter: "blur(24px)",
        }}
        animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
        transition={{ duration: 18, ease: "easeInOut", repeat: Infinity }}
      />

      {/* ── Cinematic light sweep ── */}
      <motion.div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(102deg, transparent 38%, rgba(199,208,217,0.045) 47%, rgba(122,231,255,0.06) 50%, rgba(199,208,217,0.045) 53%, transparent 62%)",
          backgroundSize: "300% 100%",
        }}
        animate={{ backgroundPosition: ["-60% 0%", "160% 0%"] }}
        transition={{ duration: 12, ease: "easeInOut", repeat: Infinity, repeatDelay: 6 }}
      />

      {/* ── Crystal embers ── */}
      {embers.map((e) => (
        <motion.span
          key={e.id}
          className="absolute rounded-full"
          style={{
            left: `${e.left}%`, top: `${e.top}%`,
            width: e.size, height: e.size,
            background: e.hue,
            boxShadow: `0 0 ${e.size * 3}px ${e.hue}, 0 0 ${e.size * 6}px ${e.hue}55`,
          }}
          animate={{
            y: [0, -e.drift, 0],
            x: [0, e.drift * 0.3, 0],
            opacity: [0, 0.9, 0],
            scale: [0.4, 1, 0.4],
          }}
          transition={{
            duration: e.duration, delay: e.delay,
            ease: "easeInOut", repeat: Infinity,
          }}
        />
      ))}

      {/* ── Top specular beam ── */}
      <div
        className="absolute inset-x-0 top-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, rgba(141,124,255,0.55), rgba(122,231,255,0.35), transparent)",
        }}
      />

      {/* ── Vignette ── */}
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(ellipse at 50% 45%, transparent 55%, rgba(0,0,0,0.55) 100%)",
        }}
      />
    </div>
  );
}