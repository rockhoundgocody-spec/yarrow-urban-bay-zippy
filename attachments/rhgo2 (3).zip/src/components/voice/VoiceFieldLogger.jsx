/**
 * VoiceFieldLogger
 * Hands-free voice interface for field logging.
 * Primary: Groq Whisper-large-v3 (insanely-fast-whisper quality via REST)
 * Fallback: Web Speech API (offline / no-upload mode)
 */
import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Mic, MicOff, X, Loader2, CheckCircle, AlertTriangle, Zap, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

// Parse voice command intent from transcript
function parseIntent(text) {
  const t = text.toLowerCase();
  if (/(identify|scan|what is|analyze|look at this)/.test(t)) return "identify";
  if (/(log|found|spotted|collected|saw|picked up)/.test(t)) return "log";
  if (/(note|remember|memo|location note)/.test(t)) return "note";
  return "log";
}

// Convert Blob to base64
async function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Use Groq Whisper-large-v3 for transcription
async function transcribeWithWhisper(audioBlob) {
  const audio_base64 = await blobToBase64(audioBlob);
  const resp = await base44.functions.invoke('whisperTranscribe', {
    audio_base64,
    mime_type: audioBlob.type || 'audio/webm',
    language: 'en',
    task: 'transcribe',
  });
  return resp.data?.text || '';
}

function StatusDot({ active }) {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className={`${active ? "animate-ping" : ""} absolute inline-flex h-full w-full rounded-full opacity-75`}
        style={{ background: active ? "#ef4444" : "#4b5563" }} />
      <span className="relative inline-flex rounded-full h-2.5 w-2.5"
        style={{ background: active ? "#ef4444" : "#374151" }} />
    </span>
  );
}

export default function VoiceFieldLogger({ onLog, onIdentifyRequest }) {
  const [open, setOpen] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interim, setInterim] = useState("");
  const [status, setStatus] = useState("idle"); // idle | listening | processing | transcribing | done | error
  const [lastAction, setLastAction] = useState(null);
  const [mode, setMode] = useState('whisper'); // 'whisper' | 'web_speech'
  const [supported] = useState(true); // Whisper works in all browsers via MediaRecorder
  const recRef = useRef(null);
  const mediaRecRef = useRef(null);
  const chunksRef = useRef([]);

  const stopListening = useCallback(() => {
    if (mediaRecRef.current?.state === 'recording') mediaRecRef.current.stop();
    recRef.current?.stop();
    setListening(false);
    setInterim('');
  }, []);

  const processTranscript = useCallback(async (text) => {
    if (!text.trim()) return;
    setStatus("processing");
    const intent = parseIntent(text);

    if (intent === "identify" && onIdentifyRequest) {
      setLastAction({ type: "identify", text: "Triggered AI identification" });
      onIdentifyRequest(text);
    } else {
      // Log a field note / specimen spotting
      const mineralsInText = text.match(/\b([A-Z][a-z]+(?:ite|ine|stone|tz|ite)?)\b/g) || [];
      const note = {
        specimen_name: mineralsInText[0] || "Unknown",
        description: text,
        user_display_name: "Voice Log",
      };
      await base44.entities.Spotting.create(note);
      setLastAction({ type: "log", text: `Logged: "${text.slice(0, 60)}${text.length > 60 ? "…" : ""}"` });
      onLog?.(note);
    }
    setStatus("done");
    setTimeout(() => setStatus("idle"), 3000);
  }, [onLog, onIdentifyRequest]);

  // Whisper mode: record via MediaRecorder → send to Groq
  const startWhisperRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const mr = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : 'audio/mp4' });
      mediaRecRef.current = mr;
      mr.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      mr.onstart = () => { setListening(true); setStatus('listening'); setTranscript(''); setInterim(''); };
      mr.onstop = async () => {
        setListening(false);
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunksRef.current, { type: mr.mimeType });
        setStatus('transcribing');
        const text = await transcribeWithWhisper(blob);
        setTranscript(text);
        if (text) processTranscript(text);
        else { setStatus('error'); setTimeout(() => setStatus('idle'), 2500); }
      };
      mr.onerror = () => { setListening(false); setStatus('error'); setTimeout(() => setStatus('idle'), 2500); };
      mr.start();
    } catch {
      // Fallback to Web Speech API
      setMode('web_speech');
      startWebSpeech();
    }
  }, []);

  // Web Speech fallback (offline)
  const startWebSpeech = useCallback(() => {
    if (!SpeechRecognition) { setStatus('error'); return; }
    const rec = new SpeechRecognition();
    rec.continuous = false;
    rec.interimResults = true;
    rec.lang = 'en-US';
    recRef.current = rec;
    rec.onstart = () => { setListening(true); setStatus('listening'); setTranscript(''); setInterim(''); };
    rec.onresult = (e) => {
      let fin = '', intr = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (e.results[i].isFinal) fin += e.results[i][0].transcript;
        else intr += e.results[i][0].transcript;
      }
      if (fin) setTranscript(t => t + fin);
      setInterim(intr);
    };
    rec.onend = () => { setListening(false); setInterim(''); };
    rec.onerror = () => { setListening(false); setStatus('error'); setTimeout(() => setStatus('idle'), 2500); };
    rec.start();
  }, []);

  const startListening = useCallback(() => {
    if (mode === 'whisper') startWhisperRecording();
    else startWebSpeech();
  }, [mode, startWhisperRecording, startWebSpeech]);

  // Auto-process when rec ends and we have transcript
  useEffect(() => {
    if (!listening && transcript && status === "listening") {
      processTranscript(transcript);
    }
  }, [listening, transcript]);

  if (!supported) return null;

  return (
    <>
      {/* FAB trigger */}
      <button
        onClick={() => setOpen(true)}
        className="fixed bottom-24 right-5 z-50 w-14 h-14 rounded-full flex items-center justify-center shadow-2xl"
        style={{
          background: listening ? "rgba(239,68,68,0.9)" : "rgba(0,214,143,0.9)",
          boxShadow: listening ? "0 0 24px rgba(239,68,68,0.5)" : "0 0 20px rgba(0,214,143,0.4)",
        }}
        aria-label="Voice field logger"
      >
        {listening ? <MicOff className="w-6 h-6 text-white" /> : <Mic className="w-6 h-6 text-white" />}
      </button>

      {/* Panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 60 }}
            className="fixed inset-x-0 bottom-0 z-50 rounded-t-3xl px-5 pt-5"
            style={{
              background: "linear-gradient(180deg, #0E141B 0%, #05070A 100%)",
              border: "1px solid rgba(255,255,255,0.08)",
              boxShadow: "0 -8px 40px rgba(0,0,0,0.6)",
            }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <StatusDot active={listening} />
                <span className="font-bold text-white">
                  {listening ? "Listening…" : status === "processing" ? "Processing…" : status === "done" ? "Logged ✓" : "Voice Field Logger"}
                </span>
              </div>
              <button onClick={() => { stopListening(); setOpen(false); }}
                className="p-2 rounded-xl text-white/30 hover:text-white/70 transition-colors" aria-label="Close">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mode toggle */}
            <div className="flex items-center gap-2 mb-4">
              <button onClick={() => setMode('whisper')}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${mode === 'whisper' ? 'text-emerald-400' : 'text-white/25'}`}
                style={{ background: mode === 'whisper' ? 'rgba(0,214,143,0.12)' : 'rgba(255,255,255,0.04)', border: `1px solid ${mode === 'whisper' ? 'rgba(0,214,143,0.3)' : 'rgba(255,255,255,0.07)'}` }}>
                <Sparkles className="w-3 h-3 inline mr-1" />Whisper AI
              </button>
              <button onClick={() => setMode('web_speech')}
                className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-all ${mode === 'web_speech' ? 'text-cyan-400' : 'text-white/25'}`}
                style={{ background: mode === 'web_speech' ? 'rgba(122,231,255,0.12)' : 'rgba(255,255,255,0.04)', border: `1px solid ${mode === 'web_speech' ? 'rgba(122,231,255,0.3)' : 'rgba(255,255,255,0.07)'}` }}>
                <Mic className="w-3 h-3 inline mr-1" />On-Device
              </button>
            </div>

            {/* Transcript display */}
            <div className="min-h-[80px] rounded-2xl p-4 mb-6"
              style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              {status === 'transcribing' ? (
                <div className="flex items-center gap-2 text-emerald-400 text-sm">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Whisper AI transcribing…
                </div>
              ) : transcript || interim ? (
                <p className="text-white/80 text-sm leading-relaxed">
                  {transcript}<span className="text-white/30">{interim}</span>
                </p>
              ) : (
                <p className="text-white/20 text-sm">
                  {listening ? 'Speak now — "Found a quartz crystal near the dry creek…"' : mode === 'whisper' ? 'Whisper AI — tap mic, speak, stop. High accuracy.' : 'On-device — real-time, no upload.'}
                </p>
              )}
            </div>

            {/* Status message */}
            {lastAction && status === "done" && (
              <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-xl"
                style={{ background: "rgba(0,214,143,0.1)", border: "1px solid rgba(0,214,143,0.2)" }}>
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-sm text-emerald-400">{lastAction.text}</span>
              </div>
            )}
            {status === "error" && (
              <div className="flex items-center gap-2 mb-4 px-3 py-2 rounded-xl"
                style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)" }}>
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span className="text-sm text-red-400">Mic error — check permissions</span>
              </div>
            )}

            {/* Command examples */}
            <div className="grid grid-cols-1 gap-2 mb-6">
              {[
                { cmd: '"Found a rose quartz near the creek"', intent: "log" },
                { cmd: '"Identify this mineral"', intent: "identify" },
                { cmd: '"Note: heavy clay overburden at site 3"', intent: "note" },
              ].map(({ cmd, intent }, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-white/25">
                  <Zap className="w-3 h-3 text-white/15 shrink-0" />
                  <span className="italic">{cmd}</span>
                  <span className="ml-auto text-[10px] px-1.5 rounded"
                    style={{ background: "rgba(255,255,255,0.05)" }}>
                    → {intent}
                  </span>
                </div>
              ))}
            </div>

            {/* Big mic button */}
            <motion.button
              onTap={() => listening ? stopListening() : startListening()}
              onClick={() => listening ? stopListening() : startListening()}
              whileTap={{ scale: 0.93 }}
              disabled={status === "processing"}
              className="w-full py-5 rounded-2xl font-black text-lg tracking-wide flex items-center justify-center gap-3"
              style={{
                background: listening
                  ? "linear-gradient(135deg, rgba(239,68,68,0.8), rgba(239,68,68,0.5))"
                  : "linear-gradient(135deg, rgba(0,214,143,0.7), rgba(0,214,143,0.4))",
                boxShadow: listening ? "0 0 30px rgba(239,68,68,0.3)" : "0 0 24px rgba(0,214,143,0.25)",
                color: "white",
                border: "none",
              }}
            >
              {status === "processing" ? (
                <><Loader2 className="w-6 h-6 animate-spin" /> Processing</>
              ) : listening ? (
                <><MicOff className="w-6 h-6" /> Stop Recording</>
              ) : (
                <><Mic className="w-6 h-6" /> Start Recording</>
              )}
            </motion.button>

            <p className="text-center text-[11px] text-white/15 mt-3 pb-safe">
              {mode === 'whisper' ? 'Audio sent to Groq Whisper — not stored after transcription.' : 'On-device only — no audio upload.'}
            </p>
            {/* Footer spacer */}
            <div style={{ height: 'calc(env(safe-area-inset-bottom, 0px) + 5rem)' }} />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}