/**
 * RatingRow — star rating display row with optional count label.
 *
 * Props:
 *  rating   number  — 0–5
 *  count    number  — review count
 *  size     "sm" | "md"
 */

import React from "react";
import { Star } from "lucide-react";

export default function RatingRow({ rating = 0, count, size = "md" }) {
  const starSize = size === "sm" ? "h-3 w-3" : "h-4 w-4";
  const textSize = size === "sm" ? "text-[10px]" : "text-xs";
  const filled = Math.round(rating);

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex gap-0.5">
        {Array.from({ length: 5 }, (_, i) => (
          <Star
            key={i}
            className={starSize}
            style={{ color: i < filled ? "#FFC857" : "rgba(255,255,255,0.15)", fill: i < filled ? "#FFC857" : "none" }}
          />
        ))}
      </div>
      <span className={`${textSize} font-bold text-white/60`}>{rating.toFixed(1)}</span>
      {count != null && (
        <span className={`${textSize} text-white/30`}>({count})</span>
      )}
    </div>
  );
}