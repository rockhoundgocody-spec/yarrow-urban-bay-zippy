/**
 * TrustBadges — seller/listing trust signal row.
 * Used on listing cards, seller profiles, and checkout.
 *
 * Props:
 *  verified     boolean
 *  salesCount   number
 *  rating       number  — 0-5
 *  escrow       boolean — escrow-protected
 *  responsive   boolean — collapses to icons on mobile
 */

import React from "react";
import { ShieldCheck, Package, Star, Lock } from "lucide-react";

function Badge({ icon: Icon, label, color, bg, border }) {
  return (
    <div
      className="flex items-center gap-1 rounded-full px-2 py-1"
      style={{ background: bg, border: `1px solid ${border}` }}
    >
      <Icon className="h-3 w-3 shrink-0" style={{ color }} />
      <span className="text-[10px] font-bold" style={{ color }}>{label}</span>
    </div>
  );
}

export default function TrustBadges({ verified, salesCount = 0, rating, escrow, responsive = true }) {
  return (
    <div className={`flex flex-wrap gap-1.5 ${responsive ? "overflow-x-auto scrollbar-none" : ""}`}>
      {verified && (
        <Badge icon={ShieldCheck} label="Verified" color="#00FFC6" bg="rgba(0,255,198,0.08)" border="rgba(0,255,198,0.22)" />
      )}
      {escrow && (
        <Badge icon={Lock} label="Escrow" color="#7DF9FF" bg="rgba(125,249,255,0.08)" border="rgba(125,249,255,0.20)" />
      )}
      {salesCount > 0 && (
        <Badge icon={Package} label={`${salesCount} sales`} color="rgba(255,255,255,0.5)" bg="rgba(255,255,255,0.04)" border="rgba(255,255,255,0.10)" />
      )}
      {rating != null && (
        <Badge icon={Star} label={rating.toFixed(1)} color="#FFC857" bg="rgba(255,200,87,0.08)" border="rgba(255,200,87,0.20)" />
      )}
    </div>
  );
}