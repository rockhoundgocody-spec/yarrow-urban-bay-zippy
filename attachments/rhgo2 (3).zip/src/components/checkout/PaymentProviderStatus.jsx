/**
 * PaymentProviderStatus — shown when Stripe keys are not configured
 * Provides safe placeholder and disabled checkout state
 */
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldAlert, Lock } from 'lucide-react';

export default function PaymentProviderStatus({ provider = 'stripe', configured = false }) {
  if (configured) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-4 space-y-3"
      style={{ background: 'rgba(245,182,66,0.06)', border: '1px solid rgba(245,182,66,0.2)' }}
    >
      <div className="flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" style={{ color: '#F5B642' }} />
        <div>
          <p className="text-sm font-bold" style={{ color: '#F5B642' }}>Payment Provider Not Configured</p>
          <p className="text-xs text-white/50 mt-1 leading-relaxed">
            {provider === 'stripe'
              ? 'Stripe keys are not connected. Live checkout is disabled. To enable payments, add your STRIPE_SECRET_KEY and STRIPE_WEBHOOK_SECRET in app settings.'
              : 'Payment provider not connected. Configure your provider to enable checkout.'}
          </p>
        </div>
      </div>

      <div className="rounded-xl p-3 flex items-center gap-3"
        style={{ background: 'rgba(0,0,0,0.3)', border: '1px solid rgba(255,255,255,0.06)' }}>
        <Lock className="w-4 h-4 shrink-0" style={{ color: 'rgba(255,255,255,0.3)' }} />
        <div className="flex-1">
          <p className="text-xs font-semibold text-white/50">Checkout Disabled</p>
          <p className="text-[10px] text-white/25 mt-0.5">Connect Stripe to enable live purchases, subscriptions, and marketplace payments.</p>
        </div>
      </div>

      <p className="text-[10px] text-white/25">
        Card details are never stored. All payments are processed by Stripe PCI-DSS infrastructure.
      </p>
    </motion.div>
  );
}