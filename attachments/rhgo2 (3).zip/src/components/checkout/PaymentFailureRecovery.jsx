/**
 * PaymentFailureRecovery — shown on failed or cancelled checkout
 * Provides retry, contact support, and order history links
 */
import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle, RefreshCw, MessageSquare, Receipt } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PaymentFailureRecovery({ reason, onRetry, orderId }) {
  const navigate = useNavigate();

  const failureReasons = {
    card_declined: { title: 'Card Declined', message: 'Your card was declined. Try a different card or contact your bank.' },
    insufficient_funds: { title: 'Insufficient Funds', message: 'Your card has insufficient funds for this transaction.' },
    expired_card: { title: 'Card Expired', message: 'Your card has expired. Please update your payment method.' },
    cancelled: { title: 'Payment Cancelled', message: 'You cancelled this payment. Your cart is still saved.' },
    provider_error: { title: 'Provider Error', message: 'A payment processing error occurred. Please try again shortly.' },
    default: { title: 'Payment Failed', message: 'Something went wrong with your payment. No charge was made.' },
  };

  const info = failureReasons[reason] || failureReasons.default;

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="min-h-[60vh] flex flex-col items-center justify-center px-6 py-12 text-center gap-6"
      style={{ background: 'linear-gradient(160deg,#050A0F 0%,#080E18 60%,#05070A 100%)' }}
    >
      <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
        style={{ background: 'rgba(255,107,107,0.1)', border: '1px solid rgba(255,107,107,0.3)' }}>
        <AlertCircle className="w-8 h-8" style={{ color: '#FF6B6B' }} />
      </div>

      <div>
        <h2 className="text-xl font-bold text-white mb-2">{info.title}</h2>
        <p className="text-sm text-white/50 max-w-sm leading-relaxed">{info.message}</p>
        {orderId && (
          <p className="text-[11px] text-white/25 mt-2 font-mono">Ref: {orderId}</p>
        )}
      </div>

      <div className="flex flex-col gap-3 w-full max-w-xs">
        {onRetry && (
          <button
            onClick={onRetry}
            className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 text-sm"
            style={{ background: 'rgba(0,214,143,0.15)', border: '1px solid rgba(0,214,143,0.35)', color: '#00D68F' }}>
            <RefreshCw className="w-4 h-4" /> Try Again
          </button>
        )}
        <button
          onClick={() => navigate('/Orders')}
          className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 text-sm"
          style={{ background: 'rgba(122,231,255,0.08)', border: '1px solid rgba(122,231,255,0.2)', color: '#7AE7FF' }}>
          <Receipt className="w-4 h-4" /> View Order History
        </button>
        <button
          onClick={() => navigate('/HelpSupport')}
          className="w-full py-3 rounded-xl font-bold flex items-center justify-center gap-2 text-sm"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.5)' }}>
          <MessageSquare className="w-4 h-4" /> Contact Support
        </button>
      </div>

      <p className="text-[10px] text-white/20 max-w-xs">
        No charges have been made to your account. If you believe this is an error, contact support with your reference number.
      </p>
    </motion.div>
  );
}