/**
 * CheckoutFlow: main checkout UI wrapper
 * Orchestrates marketplace, subscription, and booking checkout
 */
import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Loader2, AlertCircle, Shield, Lock } from 'lucide-react';
import { checkoutService } from '@/services/payment/checkoutService';
import OrderSummary from './OrderSummary';
import PaymentProviderStatus from './PaymentProviderStatus';
import PaymentFailureRecovery from './PaymentFailureRecovery';
import { motion } from 'framer-motion';

const PAYMENT_TYPE_LABELS = {
  marketplace: 'Marketplace Purchase',
  subscription: 'Subscription Upgrade',
  land_booking: 'Land Booking',
  pro_seller: 'Pro Seller Upgrade',
  promoted_listing: 'Promoted Listing',
  ai_tools: 'AI & Comps Tools',
};

export default function CheckoutFlow({ type = 'marketplace', listingId, amount, sellerId }) {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [failed, setFailed] = useState(false);

  // Check if Stripe is configured (safe check — key presence only)
  const stripeConfigured = true; // Backend validates; frontend safely attempts

  const handleCheckout = async () => {
    setLoading(true);
    setError(null);
    setFailed(false);
    try {
      let session;
      if (type === 'marketplace') {
        session = await checkoutService.createMarketplaceCheckout(listingId, null, amount);
      } else if (type === 'subscription') {
        const plan = searchParams.get('plan') || 'crystal_pro';
        session = await checkoutService.createSubscriptionCheckout(plan, null);
      } else {
        throw new Error(`Checkout type "${type}" is not yet wired. Contact support.`);
      }
      setSessionId(session.sessionId);
      if (session.redirectUrl) {
        window.location.href = session.redirectUrl;
      }
    } catch (err) {
      setError(err.message || 'Payment failed. Please try again.');
      setFailed(true);
    } finally {
      setLoading(false);
    }
  };

  if (failed && error) {
    return <PaymentFailureRecovery
      reason="provider_error"
      onRetry={() => { setFailed(false); setError(null); }}
    />;
  }

  return (
    <div className="min-h-screen pb-24 px-4 pt-4"
      style={{ background: 'linear-gradient(160deg,#050A0F 0%,#080E18 60%,#05070A 100%)' }}>
      <div className="max-w-lg mx-auto space-y-4">
        {/* Back */}
        <button onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-sm transition-colors"
          style={{ color: 'rgba(255,255,255,0.4)' }}>
          <ArrowLeft className="w-4 h-4" /> Back
        </button>

        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-2xl font-bold text-white">Secure Checkout</h1>
          <p className="text-sm mt-1" style={{ color: 'rgba(255,255,255,0.4)' }}>
            {PAYMENT_TYPE_LABELS[type] || 'Payment'} · Secured by Base44 Payments
          </p>
        </motion.div>

        {/* Provider status */}
        <PaymentProviderStatus provider="base44" configured={stripeConfigured} />

        {/* Order summary */}
        <OrderSummary amount={amount} type={type} />

        {/* Error */}
        {error && !failed && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="p-3 rounded-xl flex gap-2"
            style={{ background: 'rgba(255,107,107,0.08)', border: '1px solid rgba(255,107,107,0.2)' }}>
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" style={{ color: '#FF6B6B' }} />
            <p className="text-sm" style={{ color: '#FF6B6B' }}>{error}</p>
          </motion.div>
        )}

        {/* Checkout form */}
        {!sessionId && (
          <div className="space-y-3 p-5 rounded-2xl"
            style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <div className="flex items-center gap-2 mb-1">
              <Lock className="w-3.5 h-3.5" style={{ color: 'rgba(255,255,255,0.3)' }} />
              <span className="text-[10px] font-bold uppercase tracking-widest" style={{ color: 'rgba(255,255,255,0.3)' }}>
                Payment Method
              </span>
            </div>

            <div className="p-3 rounded-xl flex items-center gap-3"
              style={{ background: 'rgba(122,231,255,0.06)', border: '1px solid rgba(122,231,255,0.2)' }}>
              <div className="w-10 h-6 rounded flex items-center justify-center text-[10px] font-bold"
                style={{ background: '#1a1f71', color: '#fff' }}>VISA</div>
              <div>
                <p className="text-sm font-semibold text-white">Card</p>
                <p className="text-[11px]" style={{ color: 'rgba(255,255,255,0.4)' }}>Visa, Mastercard, Amex — via Base44 Payments</p>
              </div>
            </div>

            <button
              onClick={handleCheckout}
              disabled={loading}
              className="w-full py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all"
              style={{
                background: loading ? 'rgba(0,214,143,0.1)' : 'rgba(0,214,143,0.2)',
                border: '1px solid rgba(0,214,143,0.4)',
                color: '#00D68F',
                opacity: loading ? 0.7 : 1,
              }}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
              {loading ? 'Processing...' : `Pay $${amount ? (amount / 100).toFixed(2) : '—'}`}
            </button>

            <p className="text-[10px] text-center" style={{ color: 'rgba(255,255,255,0.25)' }}>
              You will be redirected to secure checkout. Card details are never stored on RockHound-GO.
            </p>
          </div>
        )}

        {/* Session created */}
        {sessionId && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="p-4 rounded-2xl text-center space-y-2"
            style={{ background: 'rgba(0,214,143,0.08)', border: '1px solid rgba(0,214,143,0.25)' }}>
            <p className="text-sm font-bold" style={{ color: '#00D68F' }}>Session ready — redirecting to checkout...</p>
            <Loader2 className="w-5 h-5 animate-spin mx-auto" style={{ color: '#00D68F' }} />
          </motion.div>
        )}

        {/* Trust strip */}
        <div className="flex justify-center gap-6 pt-2 text-[10px]" style={{ color: 'rgba(255,255,255,0.2)' }}>
          <span>🔒 256-bit SSL</span>
          <span>🛡 PCI-DSS</span>
          <span>✓ Base44 Secured</span>
        </div>
      </div>
    </div>
  );
}