/**
 * OrderSummary: displays order details before checkout
 */
import React from 'react';
import { ShoppingBag, Zap, Home } from 'lucide-react';

export default function OrderSummary({ amount, type, listing, details = {} }) {
  const formatPrice = (cents) => `$${(cents / 100).toFixed(2)}`;

  const typeLabels = {
    marketplace: { label: 'Item Purchase', icon: ShoppingBag },
    subscription: { label: 'Subscription', icon: Zap },
    booking: { label: 'Land Booking', icon: Home },
  };

  const { label, icon: Icon } = typeLabels[type] || typeLabels.marketplace;

  return (
    <div className="rounded-lg border border-border bg-card p-4 space-y-3">
      {/* Type header */}
      <div className="flex items-center gap-2 pb-3 border-b border-border">
        <Icon className="w-5 h-5 text-primary" />
        <h2 className="font-semibold">{label}</h2>
      </div>

      {/* Item details */}
      {listing && (
        <div className="space-y-1">
          <p className="text-sm font-medium">{listing.title}</p>
          <p className="text-xs text-muted-foreground">{listing.description}</p>
        </div>
      )}

      {/* Booking details */}
      {type === 'booking' && details.checkInDate && (
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-in:</span>
            <span className="font-medium">{details.checkInDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Check-out:</span>
            <span className="font-medium">{details.checkOutDate}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Nights:</span>
            <span className="font-medium">{details.nights}</span>
          </div>
        </div>
      )}

      {/* Price breakdown */}
      <div className="space-y-2 pt-3 border-t border-border">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Subtotal</span>
          <span className="font-medium">{formatPrice(amount)}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Taxes & Fees</span>
          <span className="font-medium">Calculated at checkout</span>
        </div>
        <div className="flex justify-between font-bold text-lg pt-2">
          <span>Total</span>
          <span className="text-primary">{formatPrice(amount)}</span>
        </div>
      </div>

      {/* Info */}
      <div className="text-xs text-muted-foreground bg-secondary/20 p-2 rounded">
        <p>
          {type === 'marketplace' && 'Your order will be held in secure escrow until confirmed delivered.'}
          {type === 'booking' && 'Payment is held until check-in, then released to host after completion.'}
          {type === 'subscription' && 'Your subscription renews automatically. Cancel anytime.'}
        </p>
      </div>
    </div>
  );
}