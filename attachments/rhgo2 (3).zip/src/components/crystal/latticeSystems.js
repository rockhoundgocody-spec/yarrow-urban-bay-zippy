/**
 * Unit-cell parameters for the seven crystal systems, with a representative
 * mineral for each. Axes are in ångströms, angles in degrees — real published
 * cell constants, not decorative values.
 */
export const CRYSTAL_SYSTEMS = {
  triclinic:    { label: 'Triclinic',    mineral: 'Albite',    a: 8.14, b: 12.79, c: 7.16, alpha: 94.3, beta: 116.6, gamma: 87.7 },
  monoclinic:   { label: 'Monoclinic',   mineral: 'Gypsum',    a: 5.68, b: 15.18, c: 6.29, alpha: 90,   beta: 118.4, gamma: 90 },
  orthorhombic: { label: 'Orthorhombic', mineral: 'Aragonite', a: 4.96, b: 7.97,  c: 5.74, alpha: 90,   beta: 90,    gamma: 90 },
  tetragonal:   { label: 'Tetragonal',   mineral: 'Zircon',    a: 6.61, b: 6.61,  c: 5.98, alpha: 90,   beta: 90,    gamma: 90 },
  trigonal:     { label: 'Trigonal',     mineral: 'Quartz',    a: 4.91, b: 4.91,  c: 5.41, alpha: 90,   beta: 90,    gamma: 120 },
  hexagonal:    { label: 'Hexagonal',    mineral: 'Beryl',     a: 9.21, b: 9.21,  c: 9.19, alpha: 90,   beta: 90,    gamma: 120 },
  isometric:    { label: 'Isometric',    mineral: 'Pyrite',    a: 5.42, b: 5.42,  c: 5.42, alpha: 90,   beta: 90,    gamma: 90 },
};

const rad = (d) => (d * Math.PI) / 180;

/**
 * Convert cell constants to Cartesian lattice vectors using the standard
 * crystallographic convention (a along x, b in the xy-plane).
 */
export function latticeVectors({ a, b, c, alpha, beta, gamma }) {
  const al = rad(alpha), be = rad(beta), ga = rad(gamma);
  const va = [a, 0, 0];
  const vb = [b * Math.cos(ga), b * Math.sin(ga), 0];
  const cx = c * Math.cos(be);
  const cy = (c * (Math.cos(al) - Math.cos(be) * Math.cos(ga))) / Math.sin(ga);
  const cz = Math.sqrt(Math.max(c * c - cx * cx - cy * cy, 0));
  return [va, vb, [cx, cy, cz]];
}

/** The eight corners of the unit cell, centred on the origin. */
export function cellCorners(params) {
  const [va, vb, vc] = latticeVectors(params);
  const pts = [];
  for (const i of [0, 1]) for (const j of [0, 1]) for (const k of [0, 1]) {
    pts.push([
      i * va[0] + j * vb[0] + k * vc[0],
      i * va[1] + j * vb[1] + k * vc[1],
      i * va[2] + j * vb[2] + k * vc[2],
    ]);
  }
  const cx = pts.reduce((s, p) => s + p[0], 0) / 8;
  const cy = pts.reduce((s, p) => s + p[1], 0) / 8;
  const cz = pts.reduce((s, p) => s + p[2], 0) / 8;
  return pts.map((p) => [p[0] - cx, p[1] - cy, p[2] - cz]);
}

/** Corner index pairs forming the twelve cell edges. */
export const CELL_EDGES = [
  [0, 1], [0, 2], [0, 4], [1, 3], [1, 5], [2, 3],
  [2, 6], [3, 7], [4, 5], [4, 6], [5, 7], [6, 7],
];