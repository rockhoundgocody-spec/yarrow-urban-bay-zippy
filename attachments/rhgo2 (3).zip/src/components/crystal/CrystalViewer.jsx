import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { CRYSTAL_SYSTEMS, cellCorners, CELL_EDGES, latticeVectors } from "./latticeSystems";

const AXIS_COLORS = [0xf5b642, 0x00d68f, 0xff6b9d];

/**
 * Unit-cell viewer built directly on three.js — no react-three-fiber, so it is
 * unaffected by renderer/version drift elsewhere in the app. Drag to rotate.
 */
function buildLattice(params, showAxes) {
  const group = new THREE.Group();
  const corners = cellCorners(params);
  const scale = 1.6 / Math.max(params.a, params.b, params.c);
  group.scale.setScalar(scale);

  const edgeVerts = [];
  for (const [i, j] of CELL_EDGES) edgeVerts.push(...corners[i], ...corners[j]);
  const edgeGeom = new THREE.BufferGeometry();
  edgeGeom.setAttribute("position", new THREE.Float32BufferAttribute(edgeVerts, 3));
  group.add(new THREE.LineSegments(edgeGeom, new THREE.LineBasicMaterial({ color: 0x8d7cff })));

  const r = Math.max(params.a, params.c) * 0.05;
  const sphereGeom = new THREE.SphereGeometry(r, 20, 20);
  const sphereMat = new THREE.MeshStandardMaterial({ color: 0x7ae7ff, emissive: 0x3b82f6, emissiveIntensity: 0.35 });
  for (const p of corners) {
    const m = new THREE.Mesh(sphereGeom, sphereMat);
    m.position.set(p[0], p[1], p[2]);
    group.add(m);
  }

  if (showAxes) {
    latticeVectors(params).forEach((v, n) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute([0, 0, 0, ...v], 3));
      group.add(new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: AXIS_COLORS[n] })));
    });
  }
  return group;
}

function LatticeCanvas({ params, showAxes }) {
  const mountRef = useRef(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const width = mount.clientWidth || 320;
    const height = mount.clientHeight || 300;

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch {
      return; // no WebGL — the static caption below still describes the cell
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(2.6, 2.0, 2.6);
    camera.lookAt(0, 0, 0);

    scene.add(new THREE.AmbientLight(0xffffff, 0.6));
    const point = new THREE.PointLight(0xffffff, 1.1);
    point.position.set(4, 5, 4);
    scene.add(point);

    const lattice = buildLattice(params, showAxes);
    scene.add(lattice);

    // Drag to rotate, otherwise slow auto-spin.
    let dragging = false;
    let lastX = 0;
    let lastY = 0;
    let autoSpin = true;
    const onDown = (e) => { dragging = true; autoSpin = false; lastX = e.clientX; lastY = e.clientY; };
    const onMove = (e) => {
      if (!dragging) return;
      lattice.rotation.y += (e.clientX - lastX) * 0.008;
      lattice.rotation.x += (e.clientY - lastY) * 0.008;
      lastX = e.clientX; lastY = e.clientY;
    };
    const onUp = () => { dragging = false; };
    renderer.domElement.addEventListener("pointerdown", onDown);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);

    let frame;
    const tick = () => {
      if (autoSpin) lattice.rotation.y += 0.004;
      renderer.render(scene, camera);
      frame = requestAnimationFrame(tick);
    };
    tick();

    const onResize = () => {
      const w = mount.clientWidth || width;
      const h = mount.clientHeight || height;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      renderer.domElement.removeEventListener("pointerdown", onDown);
      renderer.dispose();
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement);
    };
  }, [params, showAxes]);

  return <div ref={mountRef} style={{ width: "100%", height: "100%", cursor: "grab" }} />;
}

export default function CrystalViewer() {
  const [system, setSystem] = useState("trigonal");
  const [showAxes, setShowAxes] = useState(true);
  const params = CRYSTAL_SYSTEMS[system];

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap gap-1.5">
        {Object.entries(CRYSTAL_SYSTEMS).map(([key, s]) => (
          <button
            key={key}
            onClick={() => setSystem(key)}
            className="px-3 py-2 rounded-xl text-xs font-bold tap-compact"
            style={{
              minHeight: 36,
              background: system === key ? "rgba(141,124,255,0.22)" : "rgba(255,255,255,0.04)",
              border: `1px solid ${system === key ? "rgba(141,124,255,0.55)" : "rgba(255,255,255,0.08)"}`,
              color: system === key ? "#C4B5FD" : "rgba(255,255,255,0.5)",
            }}
          >
            {s.label}
          </button>
        ))}
      </div>

      <div
        className="rounded-2xl overflow-hidden"
        style={{
          height: 300,
          background: "radial-gradient(ellipse at 50% 40%, rgba(141,124,255,0.10) 0%, #04020E 70%)",
          border: "1px solid rgba(141,124,255,0.20)",
        }}
      >
        <LatticeCanvas params={params} showAxes={showAxes} />
      </div>

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="text-xs" style={{ color: "rgba(255,255,255,0.55)" }}>
          <span className="font-bold" style={{ color: "#C4B5FD" }}>{params.mineral}</span>
          {" — "}a {params.a} Å · b {params.b} Å · c {params.c} Å · α {params.alpha}° β {params.beta}° γ {params.gamma}°
        </div>
        <button
          onClick={() => setShowAxes((v) => !v)}
          className="px-3 py-2 rounded-xl text-xs font-semibold tap-compact"
          style={{ minHeight: 36, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.10)", color: "rgba(255,255,255,0.65)" }}
        >
          {showAxes ? "Hide axes" : "Show axes"}
        </button>
      </div>
    </div>
  );
}