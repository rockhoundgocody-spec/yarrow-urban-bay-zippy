/**
 * SoundHapticSettings — user control panel for sound + haptics preferences.
 * Embed in Profile/Settings page or as a sheet.
 */
import React, { useState } from "react";
import { Volume2, VolumeX, Smartphone } from "lucide-react";
import {
  isSoundEnabled, isHapticEnabled,
  setSoundEnabled, setHapticEnabled,
  triggerHapticSound,
} from "@/lib/useHapticSound";

export default function SoundHapticSettings() {
  const [sound, setSound]   = useState(isSoundEnabled());
  const [haptic, setHaptic] = useState(isHapticEnabled());

  const toggleSound = () => {
    const next = !sound;
    setSound(next);
    setSoundEnabled(next);
    if (next) triggerHapticSound("hub_tap");
  };

  const toggleHaptic = () => {
    const next = !haptic;
    setHaptic(next);
    setHapticEnabled(next);
    if (next) triggerHapticSound("hub_tap");
  };

  const Row = ({ icon: Icon, label, sub, checked, onToggle, color }) => (
    <div className="flex items-center gap-3 py-3"
      style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
      <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${color}12`, border: `1px solid ${color}22` }}>
        <Icon style={{ color, width: 16, height: 16 }} />
      </div>
      <div className="flex-1 min-w-0">
        <p style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.80)" }}>{label}</p>
        <p style={{ fontSize: 10, color: "rgba(255,255,255,0.35)" }}>{sub}</p>
      </div>
      <button
        onClick={onToggle}
        className="rounded-full transition-all"
        style={{
          width: 44, height: 26, padding: "3px",
          background: checked ? `${color}30` : "rgba(255,255,255,0.07)",
          border: `1px solid ${checked ? color + "50" : "rgba(255,255,255,0.12)"}`,
          display: "flex", alignItems: "center",
          justifyContent: checked ? "flex-end" : "flex-start",
        }}
        aria-pressed={checked}
       aria-label="Toggle">
        <div className="w-5 h-5 rounded-full"
          style={{ background: checked ? color : "rgba(255,255,255,0.25)", transition: "all 0.2s" }} />
      </button>
    </div>
  );

  return (
    <div className="rounded-2xl px-4 pt-1 pb-2"
      style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
      <p style={{ fontSize: 9, fontWeight: 800, color: "rgba(255,255,255,0.25)", letterSpacing: "0.2em", textTransform: "uppercase", paddingTop: 12, paddingBottom: 8 }}>
        Sound &amp; Haptics
      </p>
      <Row
        icon={sound ? Volume2 : VolumeX}
        label="Interaction Sounds"
        sub="Subtle tones on scan, identify, and reward moments"
        checked={sound}
        onToggle={toggleSound}
        color="#00D68F"
      />
      <Row
        icon={Smartphone}
        label="Haptic Feedback"
        sub="Tactile response on key actions (device permitting)"
        checked={haptic}
        onToggle={toggleHaptic}
        color="#7AE7FF"
      />
    </div>
  );
}