/**
 * ClearCacheButton — wipes service-worker caches, unregisters SWs,
 * clears session storage, then hard-reloads the app.
 * Preserves localStorage (login/session + user prefs stay intact).
 */
import React, { useState } from "react";
import { Trash2, Loader2 } from "lucide-react";

export default function ClearCacheButton() {
  const [clearing, setClearing] = useState(false);

  const clearCache = async () => {
    if (clearing) return;
    setClearing(true);
    try {
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map(k => caches.delete(k)));
      }
      if ("serviceWorker" in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map(r => r.unregister()));
      }
      sessionStorage.clear();
    } catch (_) {}
    window.location.reload();
  };

  return (
    <button
      onClick={clearCache}
      disabled={clearing}
      className="w-full flex items-center gap-3 px-4 py-4 rounded-2xl text-left"
      style={{
        background: "rgba(255,107,107,0.05)",
        border: "1px solid rgba(255,107,107,0.18)",
      }}
    >
      {clearing
        ? <Loader2 className="w-4 h-4 shrink-0 animate-spin" style={{ color: "#FF6B6B" }} />
        : <Trash2 className="w-4 h-4 shrink-0" style={{ color: "#FF6B6B" }} />}
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold" style={{ color: "#FF8A8A" }}>
          {clearing ? "Clearing cache…" : "Clear cache & reload"}
        </p>
        <p className="text-[11px]" style={{ color: "rgba(255,255,255,0.35)" }}>
          Wipes cached app files and reloads. You stay signed in.
        </p>
      </div>
    </button>
  );
}