/**
 * OrderStatus: displays order payment and fulfillment status
 */
import React, { useMemo, useState } from 'react';
import { CheckCircle2, Clock, AlertCircle, TrendingUp, Lock, Loader2, Truck } from 'lucide-react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';

const STATUS_CONFIG = {
  pending: { icon: Clock, color: 'text-amber-600', label: 'Pending', bg: 'bg-amber-50 border-amber-200' },
  paid: { icon: CheckCircle2, color: 'text-green-600', label: 'Paid', bg: 'bg-green-50 border-green-200' },
  failed: { icon: AlertCircle, color: 'text-red-600', label: 'Failed', bg: 'bg-red-50 border-red-200' },
  refunded: { icon: TrendingUp, color: 'text-blue-600', label: 'Refunded', bg: 'bg-blue-50 border-blue-200' },
  partially_refunded: { icon: TrendingUp, color: 'text-blue-600', label: 'Partially Refunded', bg: 'bg-blue-50 border-blue-200' },
};

const ESCROW_CONFIG = {
  none: { label: 'No escrow', icon: null },
  held: { label: 'Payment held in escrow', icon: Lock },
  released: { label: 'Escrow released', icon: CheckCircle2 },
  disputed: { label: 'Dispute in progress', icon: AlertCircle },
  refunded: { label: 'Escrow refunded', icon: TrendingUp },
};

export default function OrderStatus({ order, daysUntilRelease, onChanged }) {
  const { user } = useAuth();
  const [working, setWorking] = useState(false);
  const [error, setError] = useState('');
  const [showDispute, setShowDispute] = useState(false);
  const [disputeReason, setDisputeReason] = useState('item_not_received');
  const [disputeDetails, setDisputeDetails] = useState('');
  const [trackingCarrier, setTrackingCarrier] = useState('');
  const [trackingNumber, setTrackingNumber] = useState('');

  const paymentConfig = STATUS_CONFIG[order.paymentStatus] || STATUS_CONFIG.pending;
  const escrowConfig = ESCROW_CONFIG[order.escrowStatus] || ESCROW_CONFIG.none;
  const isBuyer = user?.email && order.buyerId === user.email;
  const isSeller = user?.email && order.sellerId === user.email;

  const PaymentIcon = paymentConfig.icon;
  const EscrowIcon = escrowConfig.icon;

  const runAction = async (payload) => {
    setWorking(true);
    setError('');
    try {
      await base44.functions.invoke('orderLifecycle', { order_id: order.id, ...payload });
      onChanged?.();
    } catch (e) {
      setError(e?.response?.data?.error || e.message || 'Order action failed');
    } finally {
      setWorking(false);
    }
  };

  const openDispute = async () => {
    if (!disputeDetails.trim()) {
      setError('Add a short description of the issue.');
      return;
    }
    setWorking(true);
    setError('');
    try {
      await base44.functions.invoke('disputeResolution', {
        action: 'open_dispute',
        order_id: order.id,
        reason: disputeReason,
        reason_details: disputeDetails.trim(),
      });
      setShowDispute(false);
      setDisputeDetails('');
      onChanged?.();
    } catch (e) {
      setError(e?.response?.data?.error || e.message || 'Could not open dispute');
    } finally {
      setWorking(false);
    }
  };

  const timeline = useMemo(() => {
    return [
      { status: 'order_created', label: 'Order Created', completed: true },
      { status: 'escrow_held', label: 'Payment Held', completed: order.escrowStatus !== 'none' },
      { status: 'shipped', label: 'Shipped', completed: ['shipped', 'delivered', 'completed'].includes(order.fulfillmentStatus) },
      { status: 'delivered', label: 'Delivered', completed: ['delivered', 'completed'].includes(order.fulfillmentStatus) },
      { status: 'escrow_released', label: 'Escrow Released', completed: order.escrowStatus === 'released' },
    ];
  }, [order]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {/* Payment Status */}
      <div className={`rounded-lg border p-4 ${paymentConfig.bg}`}>
        <div className="flex items-start gap-3">
          <PaymentIcon className={`w-5 h-5 ${paymentConfig.color} flex-shrink-0 mt-0.5`} />
          <div>
            <h3 className="font-semibold text-sm">{paymentConfig.label}</h3>
            <p className="text-xs text-muted-foreground mt-1">
              {order.paymentStatus === 'paid' && `Paid on ${new Date(order.created_date).toLocaleDateString()}`}
              {order.paymentStatus === 'pending' && 'Awaiting payment confirmation'}
              {order.paymentStatus === 'failed' && 'Payment processing failed. Please retry.'}
              {order.paymentStatus === 'refunded' && 'Full refund processed'}
              {order.paymentStatus === 'partially_refunded' && `Partial refund processed${order.refundedAmount ? ` · $${(order.refundedAmount / 100).toFixed(2)} refunded` : ''}`}
            </p>
          </div>
        </div>
      </div>

      {/* Escrow Status */}
      {EscrowIcon && (
        <div className="rounded-lg border border-border bg-card p-4">
          <div className="flex items-start gap-3">
            <EscrowIcon className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-sm">{escrowConfig.label}</h3>
              {order.escrowStatus === 'held' && daysUntilRelease && (
                <p className="text-xs text-muted-foreground mt-1">
                  Funds will be released in {daysUntilRelease} days after delivery confirmation.
                </p>
              )}
              {order.escrowStatus === 'released' && (
                <p className="text-xs text-muted-foreground mt-1">
                  Seller payout is being processed.
                </p>
              )}
              {order.escrowStatus === 'disputed' && (
                <p className="text-xs text-muted-foreground mt-1">
                  A dispute has been opened. Support team will review within 24 hours.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Timeline */}
      <div className="space-y-2">
        <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">Order Timeline</h4>
        <div className="space-y-2">
          {timeline.map((step, idx) => (
            <div key={idx} className="flex gap-3">
              <div className="flex flex-col items-center">
                <div
                  className={`w-4 h-4 rounded-full border-2 ${
                    step.completed ? 'bg-primary border-primary' : 'border-muted-foreground'
                  }`}
                />
                {idx < timeline.length - 1 && (
                  <div className={`w-0.5 h-6 ${step.completed ? 'bg-primary' : 'bg-muted-foreground/30'}`} />
                )}
              </div>
              <div className="py-1">
                <p className={`text-xs font-medium ${step.completed ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {step.label}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fulfillment actions */}
      {isSeller && order.paymentStatus === 'paid' && order.fulfillmentStatus === 'pending' && (
        <div className="rounded-lg border border-border bg-card p-3 space-y-2">
          <div className="flex items-center gap-2 text-xs font-semibold"><Truck className="w-4 h-4" /> Mark shipment</div>
          <div className="grid grid-cols-2 gap-2">
            <input value={trackingCarrier} onChange={(e) => setTrackingCarrier(e.target.value)} placeholder="Carrier (optional)" className="rounded-md border border-border bg-background px-2 py-2 text-xs" />
            <input value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} placeholder="Tracking # (optional)" className="rounded-md border border-border bg-background px-2 py-2 text-xs" />
          </div>
          <button disabled={working} onClick={() => runAction({ action: 'seller_mark_shipped', tracking_carrier: trackingCarrier, tracking_number: trackingNumber })}
            className="w-full py-2 rounded-lg border border-border text-xs font-semibold hover:bg-background transition-colors disabled:opacity-50">
            {working ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Mark as Shipped'}
          </button>
        </div>
      )}

      {isBuyer && order.paymentStatus === 'paid' && order.fulfillmentStatus === 'shipped' && order.disputeStatus === 'none' && (
        <button disabled={working} onClick={() => runAction({ action: 'buyer_confirm_delivery' })}
          className="w-full py-2.5 rounded-lg border border-green-500/30 text-xs font-semibold text-green-700 bg-green-50 hover:bg-green-100 transition-colors disabled:opacity-50">
          {working ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Confirm Delivery & Release Escrow'}
        </button>
      )}

      {/* Order ID and Actions */}
      <div className="rounded-lg border border-border bg-secondary/20 p-3 space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-muted-foreground">Order ID</span>
          <code className="font-mono bg-background px-2 py-1 rounded">{order.id}</code>
        </div>
        {order.trackingNumber && (
          <div className="flex justify-between items-center text-xs">
            <span className="text-muted-foreground">Tracking</span>
            <span className="font-mono">{order.trackingCarrier ? `${order.trackingCarrier} · ` : ''}{order.trackingNumber}</span>
          </div>
        )}
        <div className="flex gap-2">
          <button onClick={() => window.print()} className="flex-1 py-2 rounded-lg border border-border text-xs font-semibold hover:bg-background transition-colors">
            Print Receipt
          </button>
          {order.disputeStatus === 'none' && (isBuyer || isSeller) && (
            <button onClick={() => setShowDispute((v) => !v)} className="flex-1 py-2 rounded-lg border border-border text-xs font-semibold hover:bg-background transition-colors">
              Open Dispute
            </button>
          )}
        </div>
        {showDispute && (
          <div className="space-y-2 pt-2 border-t border-border">
            <select value={disputeReason} onChange={(e) => setDisputeReason(e.target.value)} className="w-full rounded-md border border-border bg-background px-2 py-2 text-xs">
              <option value="item_not_received">Item not received</option>
              <option value="item_not_as_described">Item not as described</option>
              <option value="wrong_item">Wrong item</option>
              <option value="damaged">Damaged</option>
              <option value="fraud">Fraud concern</option>
              <option value="other">Other</option>
            </select>
            <textarea value={disputeDetails} onChange={(e) => setDisputeDetails(e.target.value)} rows={3} placeholder="Describe the issue" className="w-full rounded-md border border-border bg-background px-2 py-2 text-xs" />
            <button disabled={working || !disputeDetails.trim()} onClick={openDispute}
              className="w-full py-2 rounded-lg border border-red-500/30 text-xs font-semibold text-red-700 bg-red-50 hover:bg-red-100 disabled:opacity-50">
              {working ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : 'Submit Dispute'}
            </button>
          </div>
        )}
        {error && <p className="text-xs text-red-600">{error}</p>}
      </div>
    </motion.div>
  );
}