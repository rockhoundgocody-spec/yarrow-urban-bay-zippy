import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Gem, ArrowRight, Sparkles } from "lucide-react";

// Agate variety highlights for the landing section
const HIGHLIGHTS = [
  { name: "Lake Superior", hue: "Brick-red fortification bands", color: "#C0504D" },
  { name: "Fairburn", hue: "Holly-leaf crimson & salmon", color: "#E07050" },
  { name: "Ellensburg Blue", hue: "Sky-blue Rayleigh scattering", color: "#5B9BD5" },
  { name: "Coyamito", hue: "Magenta pseudomorphs", color: "#B048A0" },
  { name: "Fire Agate", hue: "Iridescent Schiller effects", color: "#F5B642" },
  { name: "Iris Agate", hue: "Rainbow diffraction spectrum", color: "#7AE7FF" },
];

export default function AgateTreatiseSection() {
  return (
    <section className="relative py-20 px-4 overflow-hidden"
      style={{ background: "linear-gradient(180deg, #04020E 0%, #0a0820 50%, #04020E 100%)" }}>
      {/* Ambient crystal glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-[55%] h-[45%] -top-[8%] left-[5%] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(141,124,255,0.08) 0%, transparent 70%)", filter: "blur(90px)" }} />
        <div className="absolute w-[45%] h-[40%] bottom-[5%] right-[5%] rounded-full"
          style={{ background: "radial-gradient(circle, rgba(212,175,55,0.06) 0%, transparent 70%)", filter: "blur(90px)" }} />
      </div>

      <div className="relative max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          transition={{ duration: 0.5 }} className="text-center mb-10">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider"
            style={{ background: "rgba(141,124,255,0.12)", color: "#C4B5FD", border: "1px solid rgba(141,124,255,0.3)" }}>
            <Sparkles className="w-3 h-3" /> Field Guide · Advanced Mineralogy
          </span>
          <h2 className="mt-4 text-3xl sm:text-4xl font-black text-white tracking-tight"
            style={{ fontFamily: "'Sora', sans-serif" }}>
            The Complete Agate Treatise
          </h2>
          <p className="mt-3 text-sm sm:text-base text-white/55 leading-relaxed max-w-2xl mx-auto">
            Explore the geochemical genesis, crystallography, optical physics, and global taxonomy of the most chemically intricate
            expression of cryptocrystalline quartz — from Liesegang banding to thin-film iridescence.
          </p>
        </motion.div>

        {/* Variety highlight grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-10">
          {HIGHLIGHTS.map((h, i) => (
            <motion.div key={h.name}
              initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="p-4 rounded-2xl border border-white/8 bg-white/[0.02] hover:border-white/15 transition-all">
              <div className="w-8 h-8 rounded-lg mb-2.5 flex items-center justify-center"
                style={{ background: `${h.color}22`, border: `1px solid ${h.color}55` }}>
                <Gem className="w-4 h-4" style={{ color: h.color }} />
              </div>
              <p className="text-sm font-bold text-white">{h.name}</p>
              <p className="text-xs text-white/40 mt-0.5">{h.hue}</p>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }} className="text-center">
          <Link to="/agates"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl text-sm font-bold transition-all hover:scale-[1.02]"
            style={{ background: "linear-gradient(120deg, #8D7CFF, #7AE7FF)", color: "#04020E", boxShadow: "0 0 24px rgba(141,124,255,0.3)" }}>
            Read the Full Treatise <ArrowRight className="w-4 h-4" />
          </Link>
          <p className="mt-3 text-xs text-white/35">
            Covers genesis, optical mechanisms (Iris, Fire, Shadow), inclusion morphology, and global localities.
          </p>
        </motion.div>
      </div>
    </section>
  );
}