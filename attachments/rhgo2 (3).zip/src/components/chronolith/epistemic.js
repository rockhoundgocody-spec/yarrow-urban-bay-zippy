// Shared epistemic status → color/label mapping for CHRONOLITH UI
export const EPISTEMIC_META = {
  observed:          { label: "Observed",          color: "#00D68F" },
  strongly_inferred: { label: "Strongly inferred", color: "#7AE7FF" },
  plausible:         { label: "Plausible",         color: "#8D7CFF" },
  speculative:       { label: "Speculative",       color: "#F5B642" },
  unknown:           { label: "Unknown",           color: "#9ca3af" },
};

export const epistemicMeta = (key) => EPISTEMIC_META[key] || EPISTEMIC_META.unknown;