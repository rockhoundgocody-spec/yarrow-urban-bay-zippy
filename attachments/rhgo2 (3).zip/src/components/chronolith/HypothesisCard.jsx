import React, { useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, ChevronUp, XCircle } from "lucide-react";

const Metric = ({ label, value, color }) => (
  <div className="text-center">
    <div className="text-sm font-black" style={{ color }}>{Math.round(value ?? 0)}%</div>
    <div className="text-[9px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</div>
  </div>
);

const List = ({ title, items, color }) => !items?.length ? null : (
  <div className="mt-3">
    <p className="text-[10px] font-black uppercase tracking-widest mb-1.5" style={{ color }}>{title}</p>
    <ul className="space-y-1">
      {items.map((it, i) => (
        <li key={i} className="text-xs leading-5 pl-3 relative" style={{ color: "rgba(255,255,255,0.6)" }}>
          <span className="absolute left-0" style={{ color }}>·</span>{it}
        </li>
      ))}
    </ul>
  </div>
);

export default function HypothesisCard({ hypothesis: h, rank }) {
  const [open, setOpen] = useState(rank === 0);
  const leading = rank === 0 && !h.eliminated;
  const accent = h.eliminated ? "#6b7280" : leading ? "#8D7CFF" : "#7AE7FF";

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: rank * 0.06 }}
      className="rounded-2xl overflow-hidden"
      style={{
        background: h.eliminated ? "rgba(255,255,255,0.015)" : "linear-gradient(160deg, rgba(12,8,28,0.94), rgba(8,12,22,0.92))",
        border: `1px solid ${leading ? "rgba(141,124,255,0.35)" : h.eliminated ? "rgba(255,255,255,0.05)" : "rgba(255,255,255,0.08)"}`,
        boxShadow: leading ? "0 0 24px rgba(141,124,255,0.12)" : "none",
        opacity: h.eliminated ? 0.55 : 1,
      }}
    >
      <button onClick={() => setOpen(o => !o)} className="w-full text-left px-4 py-3.5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              {h.eliminated && <XCircle className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "#ff3366" }} />}
              <span className="text-sm font-bold" style={{ color: h.eliminated ? "rgba(255,255,255,0.4)" : "#fff", textDecoration: h.eliminated ? "line-through" : "none" }}>
                {h.label}
              </span>
              {leading && (
                <span className="text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(141,124,255,0.15)", border: "1px solid rgba(141,124,255,0.35)", color: "#C4B5FD" }}>
                  Leading
                </span>
              )}
            </div>
            {/* Probability bar */}
            <div className="mt-2.5 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.05)" }}>
              <motion.div initial={{ width: 0 }} animate={{ width: `${Math.min(100, h.probability ?? 0)}%` }}
                transition={{ duration: 0.8, ease: [0.23, 1, 0.32, 1] }}
                className="h-full rounded-full" style={{ background: `linear-gradient(90deg, ${accent}, ${accent}88)` }} />
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 flex-shrink-0">
            <span className="text-xl font-black" style={{ color: accent }}>{Math.round(h.probability ?? 0)}%</span>
            {open ? <ChevronUp className="w-3.5 h-3.5 text-white/25" /> : <ChevronDown className="w-3.5 h-3.5 text-white/25" />}
          </div>
        </div>
      </button>

      {open && (
        <div className="px-4 pb-4">
          <p className="text-xs leading-5 mb-3" style={{ color: "rgba(255,255,255,0.5)" }}>{h.summary}</p>
          <div className="grid grid-cols-3 gap-2 rounded-xl py-2.5"
            style={{ background: "rgba(255,255,255,0.025)", border: "1px solid rgba(255,255,255,0.05)" }}>
            <Metric label="Evidence" value={h.evidence_quality} color="#00D68F" />
            <Metric label="Contradiction" value={h.contradiction_load} color="#ff3366" />
            <Metric label="Verification" value={h.verification_depth} color="#7AE7FF" />
          </div>
          <List title="Supporting evidence" items={h.supporting_evidence} color="#00D68F" />
          <List title="Contradictions" items={h.contradictions} color="#ff3366" />
          <List title="Missing evidence" items={h.missing_evidence} color="#F5B642" />
          <List title="Predicts" items={h.predicts} color="#7AE7FF" />
        </div>
      )}
    </motion.div>
  );
}