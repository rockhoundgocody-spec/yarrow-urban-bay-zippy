import React, { useState } from "react";
import { motion } from "framer-motion";
import { FlaskConical, Zap, Loader2 } from "lucide-react";

const Stat = ({ label, value }) => (
  <div className="rounded-xl px-3 py-2" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
    <div className="text-[9px] uppercase tracking-widest" style={{ color: "rgba(255,255,255,0.3)" }}>{label}</div>
    <div className="text-xs font-bold text-white/80 mt-0.5">{value || "—"}</div>
  </div>
);

export default function NextTestPanel({ nextTest, onSubmitResult, submitting }) {
  const [result, setResult] = useState("");

  if (!nextTest?.name) {
    return (
      <div className="rounded-2xl p-6 text-center" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
        <p className="text-sm text-white/40">No test recommendation yet — run the investigation first.</p>
      </div>
    );
  }

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl overflow-hidden"
      style={{ background: "linear-gradient(160deg, rgba(12,8,28,0.94), rgba(8,12,22,0.92))", border: "1px solid rgba(0,214,143,0.22)" }}>
      <div className="px-4 py-3.5 flex items-center gap-3" style={{ borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: "rgba(0,214,143,0.10)" }}>
          <FlaskConical className="w-4 h-4" style={{ color: "#00D68F" }} />
        </div>
        <div>
          <p className="text-[9px] font-black uppercase tracking-widest" style={{ color: "rgba(0,214,143,0.6)" }}>Best next action</p>
          <p className="text-sm font-bold text-white">{nextTest.name}</p>
        </div>
        <div className="ml-auto text-right">
          <div className="flex items-center gap-1 justify-end">
            <Zap className="w-3 h-3" style={{ color: "#F5B642" }} />
            <span className="text-lg font-black" style={{ color: "#F5B642" }}>−{Math.round(nextTest.expected_uncertainty_reduction ?? 0)}%</span>
          </div>
          <p className="text-[9px] uppercase tracking-wider" style={{ color: "rgba(255,255,255,0.3)" }}>uncertainty</p>
        </div>
      </div>

      <div className="p-4 space-y-3">
        <p className="text-xs leading-5" style={{ color: "rgba(255,255,255,0.55)" }}>{nextTest.rationale}</p>
        <div className="grid grid-cols-2 gap-2">
          <Stat label="Cost" value={nextTest.cost} />
          <Stat label="Time" value={nextTest.time_estimate} />
          <Stat label="Specimen risk" value={nextTest.specimen_risk} />
          <Stat label="Mode" value={nextTest.mode} />
        </div>
        {nextTest.instructions && (
          <div className="rounded-xl p-3" style={{ background: "rgba(122,231,255,0.04)", border: "1px solid rgba(122,231,255,0.12)" }}>
            <p className="text-[10px] font-black uppercase tracking-widest mb-1" style={{ color: "#7AE7FF" }}>How to perform it</p>
            <p className="text-xs leading-5 whitespace-pre-line" style={{ color: "rgba(255,255,255,0.6)" }}>{nextTest.instructions}</p>
          </div>
        )}

        {/* Result entry */}
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest mb-1.5" style={{ color: "rgba(255,255,255,0.35)" }}>Enter your result</p>
          <textarea
            value={result}
            onChange={(e) => setResult(e.target.value)}
            rows={2}
            placeholder="e.g. Density measured at 7.4 g/cm³ via water displacement"
            className="w-full rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none resize-none"
            style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
          />
          <button
            onClick={() => { if (result.trim()) { onSubmitResult(nextTest.name, result.trim()); setResult(""); } }}
            disabled={submitting || !result.trim()}
            className="mt-2 w-full flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-black uppercase tracking-wide transition-all disabled:opacity-40"
            style={{ background: "linear-gradient(135deg, rgba(0,214,143,0.18), rgba(122,231,255,0.10))", border: "1px solid rgba(0,214,143,0.35)", color: "#00D68F" }}>
            {submitting ? <><Loader2 className="w-4 h-4 animate-spin" /> Re-adjudicating…</> : "Submit result — update all hypotheses"}
          </button>
        </div>
      </div>
    </motion.div>
  );
}