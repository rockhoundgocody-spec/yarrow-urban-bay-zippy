import React from "react";
import { FileSearch, FlaskConical, ShieldAlert } from "lucide-react";
import { epistemicMeta } from "./epistemic";

const Section = ({ icon: Icon, title, color, children }) => (
  <div className="rounded-2xl p-4" style={{ background: "linear-gradient(160deg, rgba(12,8,28,0.92), rgba(8,12,22,0.9))", border: "1px solid rgba(255,255,255,0.07)" }}>
    <div className="flex items-center gap-2 mb-3">
      <Icon className="w-4 h-4" style={{ color }} />
      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color }}>{title}</p>
    </div>
    {children}
  </div>
);

export default function EvidenceLedger({ observations = [], testResults = [], falsificationConditions = [] }) {
  return (
    <div className="space-y-3">
      <Section icon={FileSearch} title="Evidence ledger" color="#7AE7FF">
        {observations.length === 0 && <p className="text-xs text-white/30">No observations recorded yet.</p>}
        <div className="space-y-2">
          {observations.map((o, i) => {
            const meta = epistemicMeta(o.epistemic);
            return (
              <div key={i} className="rounded-xl p-2.5" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)" }}>
                <p className="text-xs leading-5" style={{ color: "rgba(255,255,255,0.65)" }}>{o.text}</p>
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: `${meta.color}12`, color: meta.color }}>{meta.label}</span>
                  {o.source && <span className="text-[9px] text-white/25 uppercase tracking-wider">src: {o.source}</span>}
                  {o.reliability != null && <span className="text-[9px] text-white/25">reliability {(o.reliability * 100).toFixed(0)}%</span>}
                </div>
              </div>
            );
          })}
        </div>
      </Section>

      <Section icon={FlaskConical} title="Tests performed" color="#00D68F">
        {testResults.length === 0 && <p className="text-xs text-white/30">No physical tests entered yet.</p>}
        <div className="space-y-2">
          {testResults.map((t, i) => (
            <div key={i} className="rounded-xl p-2.5" style={{ background: "rgba(0,214,143,0.03)", border: "1px solid rgba(0,214,143,0.10)" }}>
              <p className="text-xs font-bold" style={{ color: "#00D68F" }}>{t.test_name}</p>
              <p className="text-xs leading-5 mt-0.5" style={{ color: "rgba(255,255,255,0.55)" }}>{t.result}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section icon={ShieldAlert} title="What would prove this wrong" color="#F5B642">
        {falsificationConditions.length === 0 && <p className="text-xs text-white/30">Falsification conditions appear after adjudication.</p>}
        <ul className="space-y-1.5">
          {falsificationConditions.map((f, i) => (
            <li key={i} className="text-xs leading-5 pl-3 relative" style={{ color: "rgba(255,255,255,0.55)" }}>
              <span className="absolute left-0" style={{ color: "#F5B642" }}>·</span>{f}
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}