import React from "react";
import { motion } from "framer-motion";
import { epistemicMeta, EPISTEMIC_META } from "./epistemic";

export default function CaseTimeline({ timeline = [] }) {
  if (!timeline.length) {
    return (
      <div className="rounded-2xl p-6 text-center" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.06)" }}>
        <p className="text-sm text-white/40">The deep-time reconstruction appears once the investigation completes.</p>
      </div>
    );
  }

  return (
    <div>
      {/* Epistemic legend */}
      <div className="flex flex-wrap gap-2 mb-4">
        {Object.values(EPISTEMIC_META).map(({ label, color }) => (
          <span key={label} className="flex items-center gap-1.5 text-[10px] font-semibold px-2 py-1 rounded-full"
            style={{ background: `${color}10`, border: `1px solid ${color}30`, color }}>
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: color }} />{label}
          </span>
        ))}
      </div>

      <div className="relative pl-6">
        {/* Spine */}
        <div className="absolute left-[7px] top-2 bottom-2 w-px"
          style={{ background: "linear-gradient(180deg, rgba(141,124,255,0.5), rgba(122,231,255,0.3), rgba(0,214,143,0.4))" }} />
        <div className="space-y-4">
          {timeline.map((ev, i) => {
            const meta = epistemicMeta(ev.epistemic_status);
            return (
              <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}
                className="relative">
                <div className="absolute -left-6 top-1.5 w-[15px] h-[15px] rounded-full flex items-center justify-center"
                  style={{ background: "#05070A", border: `2px solid ${meta.color}`, boxShadow: `0 0 10px ${meta.color}50` }} />
                <div className="rounded-2xl p-3.5"
                  style={{ background: "linear-gradient(160deg, rgba(12,8,28,0.9), rgba(8,12,22,0.88))", border: `1px solid ${meta.color}22` }}>
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <span className="text-[10px] font-black uppercase tracking-widest" style={{ color: meta.color }}>{ev.time_label}</span>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={{ background: `${meta.color}12`, color: meta.color }}>
                      {meta.label}
                    </span>
                  </div>
                  <p className="text-sm font-bold text-white mt-1">{ev.title}</p>
                  <p className="text-xs leading-5 mt-1" style={{ color: "rgba(255,255,255,0.5)" }}>{ev.description}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}