import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Camera, MapPin, Loader2, X } from "lucide-react";

export default function NewCaseForm({ onCreate, creating }) {
  const [photos, setPhotos] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [notes, setNotes] = useState("");
  const [gps, setGps] = useState(null);
  const [gpsBusy, setGpsBusy] = useState(false);

  const handleFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    const urls = [];
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      urls.push(file_url);
    }
    setPhotos((p) => [...p, ...urls]);
    setUploading(false);
  };

  const attachGPS = () => {
    setGpsBusy(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }); setGpsBusy(false); },
      () => setGpsBusy(false),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const canSubmit = (photos.length > 0 || notes.trim().length > 10) && !uploading && !creating;

  return (
    <div className="rounded-2xl p-4 space-y-3"
      style={{ background: "linear-gradient(160deg, rgba(12,8,28,0.94), rgba(8,12,22,0.92))", border: "1px solid rgba(141,124,255,0.22)" }}>
      <p className="text-[10px] font-black uppercase tracking-widest" style={{ color: "#C4B5FD" }}>Open a new case</p>

      {/* Photos */}
      <label className="flex items-center justify-center gap-2 rounded-xl py-4 cursor-pointer transition-all focus-within:ring-2 focus-within:ring-[#7AE7FF]/50 focus-within:outline-none"
        style={{ background: "rgba(122,231,255,0.04)", border: "1px dashed rgba(122,231,255,0.25)", color: "#7AE7FF" }}>
        {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Camera className="w-4 h-4" />}
        <span className="text-xs font-bold">{uploading ? "Uploading…" : "Add specimen photos"}</span>
        <input type="file" accept="image/*" multiple className="sr-only" onChange={handleFiles} disabled={uploading} />
      </label>
      {photos.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          {photos.map((url, i) => (
            <div key={i} className="relative">
              <img src={url} alt={`Specimen ${i + 1}`} className="w-16 h-16 rounded-xl object-cover" style={{ border: "1px solid rgba(255,255,255,0.1)" }} />
              <button onClick={() => setPhotos((p) => p.filter((_, j) => j !== i))} aria-label="Remove photo"
                className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full flex items-center justify-center tap-compact"
                style={{ background: "#05070A", border: "1px solid rgba(255,255,255,0.2)", minWidth: 20, minHeight: 20 }}>
                <X className="w-3 h-3 text-white/60" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Notes */}
      <textarea
        value={notes} onChange={(e) => setNotes(e.target.value)} rows={3}
        placeholder="Field notes: weight, magnetism, where it was recovered, provenance claims, attached material…"
        className="w-full rounded-xl px-3 py-2.5 text-sm text-white placeholder:text-white/20 outline-none resize-none"
        style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}
      />

      {/* GPS */}
      <button onClick={attachGPS} disabled={gpsBusy}
        className="flex items-center gap-2 rounded-xl px-3 py-2.5 text-xs font-bold transition-all"
        style={{
          background: gps ? "rgba(0,214,143,0.08)" : "rgba(255,255,255,0.03)",
          border: `1px solid ${gps ? "rgba(0,214,143,0.3)" : "rgba(255,255,255,0.08)"}`,
          color: gps ? "#00D68F" : "rgba(255,255,255,0.45)",
        }}>
        {gpsBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <MapPin className="w-3.5 h-3.5" />}
        {gps ? `Recovery location attached (${gps.latitude.toFixed(4)}, ${gps.longitude.toFixed(4)})` : "Attach recovery GPS (optional)"}
      </button>

      <button
        onClick={() => onCreate({ photo_urls: photos, specimen_notes: notes.trim(), ...(gps || {}) })}
        disabled={!canSubmit}
        className="w-full flex items-center justify-center gap-2 rounded-xl py-3.5 text-sm font-black uppercase tracking-wide transition-all disabled:opacity-40"
        style={{ background: "linear-gradient(135deg, rgba(141,124,255,0.22), rgba(80,40,180,0.15))", border: "1px solid rgba(141,124,255,0.45)", color: "#C4B5FD", boxShadow: "0 0 20px rgba(141,124,255,0.15)" }}>
        {creating ? <><Loader2 className="w-4 h-4 animate-spin" /> Opening case…</> : "Begin reconstruction"}
      </button>
    </div>
  );
}