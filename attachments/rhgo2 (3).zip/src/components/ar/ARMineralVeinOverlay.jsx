/**
 * ARMineralVeinOverlay
 * Canvas-based AR overlay for the camera module.
 * Renders simulated mineral-rich vein highlights and real-time AI identification
 * labels on the live camera viewport as the user pans a rockhounding site.
 *
 * Architecture:
 * - SVG/Canvas layer sits absolutely over the video element
 * - Vein candidates are computed from a lightweight edge/contrast heuristic on
 *   downsampled video frames (no heavy ML; uses ImageData analysis)
 * - When Clover/AI has identified a specimen, labels are pinned to their region
 * - Pulses on high-confidence zones to draw attention
 */
import React, { useRef, useEffect, useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, Eye } from "lucide-react";

// ── Lightweight frame analyser ──────────────────────────────────────────────
// Runs on a 160×90 downsampled canvas; detects high-contrast edge regions
// that correlate with potential mineral boundaries / veins.
function analyseFrame(videoEl, helperCanvas) {
  if (!videoEl || !helperCanvas) return [];
  const W = 160, H = 90;
  helperCanvas.width = W;
  helperCanvas.height = H;
  const ctx = helperCanvas.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(videoEl, 0, 0, W, H);
  const { data } = ctx.getImageData(0, 0, W, H);

  // Grid of 4×4 sampling cells — score each by brightness variance
  const COLS = 8, ROWS = 5;
  const cellW = W / COLS, cellH = H / ROWS;
  const candidates = [];

  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const cx = Math.round(col * cellW + cellW / 2);
      const cy = Math.round(row * cellH + cellH / 2);
      const idx = (cy * W + cx) * 4;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2];
      const brightness = (r + g + b) / 3;
      const saturation = Math.max(r, g, b) - Math.min(r, g, b);
      const score = saturation * 0.6 + Math.abs(brightness - 128) * 0.4;

      if (score > 45) {
        candidates.push({
          id: `${row}_${col}`,
          // Normalised 0-1 viewport coords
          nx: cx / W,
          ny: cy / H,
          score: Math.min(score / 120, 1),
          r, g, b,
        });
      }
    }
  }

  // Return top 4 candidates
  return candidates.sort((a, b) => b.score - a.score).slice(0, 4);
}

function mineralColor(r, g, b) {
  // Heuristic: map dominant channel to mineral family colour
  if (r > g && r > b) return { color: "#F97316", label: "Iron Oxide / Hematite" };
  if (g > r && g > b) return { color: "#22c55e", label: "Malachite / Serpentine" };
  if (b > r && b > g) return { color: "#60a5fa", label: "Azurite / Lazurite" };
  if (r > 200 && g > 200 && b > 200) return { color: "#e2e8f0", label: "Quartz / Feldspar" };
  return { color: "#a78bfa", label: "Unknown Mineral Zone" };
}

// ── Vein candidate component ────────────────────────────────────────────────
function VeinMarker({ candidate, vpW, vpH }) {
  const x = candidate.nx * vpW;
  const y = candidate.ny * vpH;
  const { color, label } = mineralColor(candidate.r, candidate.g, candidate.b);
  const opacity = 0.45 + candidate.score * 0.45;

  return (
    <g>
      {/* Pulse ring */}
      <circle cx={x} cy={y} r={18} fill="none" stroke={color} strokeWidth={1.5} opacity={opacity * 0.6}>
        <animate attributeName="r" values="14;26;14" dur="2.4s" repeatCount="indefinite" />
        <animate attributeName="opacity" values={`${opacity};0;${opacity}`} dur="2.4s" repeatCount="indefinite" />
      </circle>
      {/* Core dot */}
      <circle cx={x} cy={y} r={5} fill={color} opacity={opacity} />
      {/* Label */}
      <rect x={x + 10} y={y - 14} width={140} height={22} rx={6} fill="rgba(0,0,0,0.72)" />
      <text x={x + 18} y={y + 2} fontSize={10} fontWeight="600" fill={color} fontFamily="sans-serif">
        {label}
      </text>
      <text x={x + 18} y={y + 14} fontSize={9} fill="rgba(255,255,255,0.5)" fontFamily="sans-serif">
        {Math.round(candidate.score * 100)}% signal
      </text>
    </g>
  );
}

// ── AI label overlay ─────────────────────────────────────────────────────────
function AILabel({ label, confidence, x, y }) {
  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{ left: x, top: y, transform: "translate(-50%, -100%)" }}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
    >
      <div
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold"
        style={{
          background: "rgba(0,0,0,0.78)",
          border: "1px solid rgba(0,214,143,0.5)",
          color: "#00D68F",
          backdropFilter: "blur(8px)",
          boxShadow: "0 0 16px rgba(0,214,143,0.3)",
        }}
      >
        <Sparkles style={{ width: 11, height: 11 }} />
        {label}
        <span style={{ color: "rgba(255,255,255,0.45)", fontWeight: 400 }}>
          {Math.round(confidence * 100)}%
        </span>
      </div>
      {/* Pointer */}
      <div
        className="mx-auto"
        style={{
          width: 0, height: 0,
          borderLeft: "5px solid transparent",
          borderRight: "5px solid transparent",
          borderTop: "6px solid rgba(0,214,143,0.5)",
        }}
      />
    </motion.div>
  );
}

// ── Main component ────────────────────────────────────────────────────────────
export default function ARMineralVeinOverlay({
  videoRef,
  isActive = false,
  aiLabels = [], // [{ label, confidence, nx, ny }] — passed in from parent identify flow
}) {
  const helperCanvasRef = useRef(null);
  const svgRef = useRef(null);
  const [candidates, setCandidates] = useState([]);
  const [vpSize, setVpSize] = useState({ w: 1, h: 1 });
  const frameRef = useRef(null);
  const lastAnalysis = useRef(0);

  // Track viewport size
  useEffect(() => {
    const measure = () => {
      if (svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        setVpSize({ w: rect.width, h: rect.height });
      }
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const tick = useCallback(() => {
    if (!isActive) return;
    const now = Date.now();
    // Analyse at ~3fps to keep CPU low
    if (now - lastAnalysis.current > 333) {
      lastAnalysis.current = now;
      const video = videoRef?.current;
      if (video && video.readyState >= 2) {
        const found = analyseFrame(video, helperCanvasRef.current);
        setCandidates(found);
      }
    }
    frameRef.current = requestAnimationFrame(tick);
  }, [isActive, videoRef]);

  useEffect(() => {
    if (isActive) {
      frameRef.current = requestAnimationFrame(tick);
    }
    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [isActive, tick]);

  if (!isActive) return null;

  return (
    <>
      {/* Hidden helper canvas for pixel analysis */}
      <canvas ref={helperCanvasRef} style={{ display: "none" }} />

      {/* SVG vein overlay */}
      <svg
        ref={svgRef}
        className="absolute inset-0 pointer-events-none"
        style={{ width: "100%", height: "100%", zIndex: 15 }}
        viewBox={`0 0 ${vpSize.w} ${vpSize.h}`}
      >
        {candidates.map((c) => (
          <VeinMarker
            key={c.id}
            candidate={c}
            vpW={vpSize.w}
            vpH={vpSize.h}
          />
        ))}
      </svg>

      {/* AI identification labels */}
      <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 16 }}>
        <AnimatePresence>
          {aiLabels.map((lbl, idx) => (
            <AILabel
              key={`${lbl.label}_${idx}`}
              label={lbl.label}
              confidence={lbl.confidence}
              x={lbl.nx * vpSize.w}
              y={lbl.ny * vpSize.h}
            />
          ))}
        </AnimatePresence>
      </div>

      {/* AR mode indicator */}
      <motion.div
        className="absolute top-4 right-4 pointer-events-none"
        style={{ zIndex: 20 }}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-bold"
          style={{
            background: "rgba(0,0,0,0.65)",
            border: "1px solid rgba(122,231,255,0.35)",
            color: "#7AE7FF",
            backdropFilter: "blur(8px)",
          }}
        >
          <Eye style={{ width: 11, height: 11 }} />
          AR VEIN MODE
          <motion.div
            style={{ width: 6, height: 6, borderRadius: "50%", background: "#00D68F" }}
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 1.2, repeat: Infinity }}
          />
        </div>
      </motion.div>
    </>
  );
}