import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ThumbsUp, Reply } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { formatDistanceToNow } from "date-fns";

export default function ForumPostItem({ post, user, onReply }) {
  const isOwnPost = user?.email === post.created_by;

  return (
    <Card className="bg-[#14141e] border-white/5 p-4 mb-3">
      <div className="flex items-start gap-3 mb-3">
        <div className="flex-1">
          <p className="text-xs text-white/40">
            <span className="text-white/60 font-medium">{post.created_by?.split("@")[0]}</span>
            {" "}posted {formatDistanceToNow(new Date(post.created_date), { addSuffix: true })}
          </p>
        </div>
        {isOwnPost && <span className="text-[10px] px-2 py-1 rounded bg-amber-500/10 text-amber-400">Author</span>}
      </div>
      <div className="prose prose-sm prose-invert max-w-none mb-3 prose-p:text-white/70 prose-strong:text-white prose-a:text-cyan-400">
        <ReactMarkdown>{post.content}</ReactMarkdown>
      </div>
      <div className="flex items-center gap-2">
        <Button size="sm" variant="ghost" className="text-white/40 hover:text-white/60 text-xs h-7">
          <ThumbsUp className="w-3 h-3 mr-1" /> {post.helpful_count || 0}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => onReply(post.id)}
          className="text-white/40 hover:text-white/60 text-xs h-7"
        >
          <Reply className="w-3 h-3 mr-1" /> Reply
        </Button>
      </div>
    </Card>
  );
}