import React from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Eye, Pin } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const categoryColors = {
  locations: "bg-cyan-500/10 text-cyan-400",
  finds: "bg-emerald-500/10 text-emerald-400",
  techniques: "bg-purple-500/10 text-purple-400",
  equipment: "bg-orange-500/10 text-orange-400",
  general: "bg-slate-500/10 text-slate-400",
};

export default function ForumTopicCard({ topic, onClick }) {
  return (
    <Card
      onClick={onClick}
      className="bg-[#14141e] border-white/5 hover:border-white/10 transition-all cursor-pointer p-4 group"
    >
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {topic.pinned && <Pin className="w-3 h-3 text-amber-400" />}
            <h3 className="font-semibold text-white/90 group-hover:text-amber-400 transition-colors line-clamp-2">
              {topic.title}
            </h3>
          </div>
          <p className="text-xs text-white/40 line-clamp-1">{topic.description}</p>
        </div>
        <Badge className={`text-[10px] shrink-0 ${categoryColors[topic.category]}`}>
          {topic.category}
        </Badge>
      </div>
      <div className="flex items-center gap-4 text-xs text-white/40">
        <span className="text-white/60">Posted {formatDistanceToNow(new Date(topic.created_date), { addSuffix: true })}</span>
        <div className="flex items-center gap-1">
          <MessageCircle className="w-3 h-3" />
          <span>{topic.reply_count || 0}</span>
        </div>
        <div className="flex items-center gap-1">
          <Eye className="w-3 h-3" />
          <span>{topic.view_count || 0}</span>
        </div>
      </div>
    </Card>
  );
}