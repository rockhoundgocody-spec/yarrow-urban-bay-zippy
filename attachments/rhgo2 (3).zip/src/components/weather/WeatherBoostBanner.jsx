import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CloudRain, Sun, Cloud, Wind, Snowflake, Eye, Zap, ChevronDown, ChevronUp, Gem, Moon } from 'lucide-react';
import { getConditionLabel } from '@/services/weatherBoostService';

const ICON_MAP = { CloudRain, Sun, Cloud, Wind, Snowflake, Eye, Zap, Moon };
const COLOR_MAP = {
  rain: { bg: 'rgba(37,99,235,0.15)', border: 'rgba(96,165,250,0.4)', text: '#93c5fd', accent: '#60a5fa' },
  sunny: { bg: 'rgba(180,83,9,0.12)', border: 'rgba(251,191,36,0.4)', text: '#fde68a', accent: '#fbbf24' },
  cloudy: { bg: 'rgba(75,85,99,0.15)', border: 'rgba(156,163,175,0.3)', text: '#d1d5db', accent: '#9ca3af' },
  windy: { bg: 'rgba(5,150,105,0.12)', border: 'rgba(52,211,153,0.3)', text: '#6ee7b7', accent: '#34d399' },
  snow: { bg: 'rgba(186,230,253,0.1)', border: 'rgba(125,211,252,0.4)', text: '#e0f2fe', accent: '#7dd3fc' },
  fog: { bg: 'rgba(107,114,128,0.12)', border: 'rgba(156,163,175,0.25)', text: '#d1d5db', accent: '#9ca3af' },
  storm: { bg: 'rgba(109,40,217,0.15)', border: 'rgba(167,139,250,0.5)', text: '#ddd6fe', accent: '#a78bfa' },
  'clear-night': { bg: 'rgba(76,50,120,0.18)', border: 'rgba(167,139,250,0.4)', text: '#e9d5ff', accent: '#c4b5fd' },
};

export default function WeatherBoostBanner({ boostData, loading }) {
  const [expanded, setExpanded] = useState(false);

  if (loading) {
    return (
      <div className="rounded-xl px-3 py-2.5 animate-pulse" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="h-4 w-48 rounded" style={{ background: 'rgba(255,255,255,0.08)' }} />
      </div>
    );
  }

  if (!boostData?.condition) return null;

  const { condition, boost, temperature_c, wind_speed_kmh, moon_phase_emoji, moon_phase_label, is_full_moon, is_night } = boostData;
  const colors = COLOR_MAP[condition] || COLOR_MAP.cloudy;
  const iconKey = { rain: 'CloudRain', sunny: 'Sun', cloudy: 'Cloud', windy: 'Wind', snow: 'Snowflake', fog: 'Eye', storm: 'Zap', 'clear-night': 'Moon' }[condition] || 'Cloud';
  const Icon = ICON_MAP[iconKey];

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-xl overflow-hidden"
      style={{ background: colors.bg, border: `1px solid ${colors.border}` }}
    >
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-2.5 px-3 py-2.5"
        style={{ minHeight: 44 }}
      >
        <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ background: `${colors.accent}22` }}>
          <Icon className="w-4 h-4" style={{ color: colors.accent }} />
        </div>
        <div className="flex-1 text-left">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider" style={{ color: colors.accent }}>
              {boost?.is_storm_event ? '⚡ Storm Boost Active' : is_full_moon ? '🌕 Full Moon Boost' : 'Weather Boost'}
            </span>
            <span className="text-xs font-semibold" style={{ color: colors.text }}>
              {getConditionLabel(condition)}
            </span>
          </div>
          <div className="text-xs mt-0.5 flex items-center gap-1.5" style={{ color: `${colors.text}99` }}>
            {is_night && moon_phase_emoji && (
              <span className="text-sm leading-none" title={moon_phase_label}>{moon_phase_emoji}</span>
            )}
            <span>
              {boost?.xp_multiplier && boost.xp_multiplier > 1
                ? `+${Math.round((boost.xp_multiplier - 1) * 100)}% XP • ${boost.minerals?.slice(0,2).join(', ')}${boost.minerals?.length > 2 ? ' +more' : ''}`
                : 'No active boost'}
            </span>
          </div>
        </div>
        {temperature_c !== undefined && (
          <span className="text-xs font-semibold tabular-nums" style={{ color: `${colors.text}80` }}>
            {Math.round(temperature_c * 9/5 + 32)}°F
          </span>
        )}
        {expanded ? <ChevronUp className="w-3.5 h-3.5 flex-shrink-0" style={{ color: colors.text }} />
          : <ChevronDown className="w-3.5 h-3.5 flex-shrink-0" style={{ color: colors.text }} />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="px-3 pb-3 space-y-2.5" style={{ borderTop: `1px solid ${colors.border}40` }}>
              {/* Moon phase — night sight hunting */}
              {is_night && moon_phase_label && (
                <div className="pt-2.5 flex items-center gap-2">
                  <span className="text-lg leading-none">{moon_phase_emoji}</span>
                  <div className="flex-1">
                    <div className="text-xs font-bold" style={{ color: colors.accent }}>
                      {moon_phase_label}{is_full_moon ? ' — Night Hunt Active' : ''}
                    </div>
                    <div className="text-xs" style={{ color: `${colors.text}80` }}>
                      {is_full_moon
                        ? 'Full moon provides natural light for night field hunting.'
                        : 'Limited moonlight — bring a headlamp for night hunting.'}
                    </div>
                  </div>
                </div>
              )}

              {/* Boosted minerals */}
              {boost?.minerals?.length > 0 && (
                <div className="pt-2.5">
                  <div className="text-xs font-semibold mb-1.5 flex items-center gap-1" style={{ color: colors.accent }}>
                    <Gem className="w-3 h-3" /> Boosted Minerals
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {boost.minerals.map(m => (
                      <span key={m} className="text-xs px-2 py-0.5 rounded-full font-medium"
                        style={{ background: `${colors.accent}18`, color: colors.text, border: `1px solid ${colors.border}` }}>
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Multipliers */}
              <div className="flex gap-2">
                {boost?.xp_multiplier > 1 && (
                  <div className="flex-1 rounded-lg px-2.5 py-2 text-center"
                    style={{ background: `${colors.accent}12`, border: `1px solid ${colors.border}` }}>
                    <div className="text-sm font-black" style={{ color: colors.accent }}>{boost.xp_multiplier}×</div>
                    <div className="text-xs" style={{ color: `${colors.text}80` }}>XP Boost</div>
                  </div>
                )}
                {boost?.spawn_multiplier > 1 && (
                  <div className="flex-1 rounded-lg px-2.5 py-2 text-center"
                    style={{ background: `${colors.accent}12`, border: `1px solid ${colors.border}` }}>
                    <div className="text-sm font-black" style={{ color: colors.accent }}>{boost.spawn_multiplier}×</div>
                    <div className="text-xs" style={{ color: `${colors.text}80` }}>Find Rate</div>
                  </div>
                )}
              </div>

              {/* Educational note */}
              {boost?.educational_note && (
                <p className="text-xs leading-relaxed" style={{ color: `${colors.text}90` }}>
                  🔬 {boost.educational_note}
                </p>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}