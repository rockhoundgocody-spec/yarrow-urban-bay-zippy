import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { AlertTriangle, CloudSun, ArrowRight } from "lucide-react";
import { fetchWeatherBoost } from "@/services/weatherBoostService";
import { createPageUrl } from "@/utils";

// Only renders when there's an active weather emergency (storm/thunderstorm).
// Silently does nothing otherwise — no API cost, no UI clutter.
export default function WeatherEmergencyAlert() {
  const [emergency, setEmergency] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const cacheKey = "rh_emergency_weather";
    const TTL = 10 * 60 * 1000; // 10 min

    try {
      const cached = JSON.parse(localStorage.getItem(cacheKey) || "null");
      if (cached && Date.now() - cached.ts < TTL) {
        if (cached.emergency) setEmergency(cached.emergency);
        return;
      }
    } catch {}

    if (!navigator.geolocation) return;

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (cancelled) return;
        // Use coarsened coords for weather fetch — weather doesn't need precise GPS
        const lat = parseFloat(pos.coords.latitude.toFixed(2));
        const lon = parseFloat(pos.coords.longitude.toFixed(2));
        try {
          const data = await fetchWeatherBoost(lat, lon);
          if (cancelled) return;
          const isStorm = data.condition === "storm" || data.boost?.is_storm_event;
          const extremeWind = data.wind_speed_kmh > 60;
          if (isStorm || extremeWind) {
            const alert = {
              condition: data.condition,
              temp_c: data.temperature_c,
              wind_kmh: data.wind_speed_kmh,
              type: isStorm ? "storm" : "wind",
              label: isStorm ? "Severe Thunderstorm" : "Extreme Wind Warning",
              message: isStorm
                ? "Storm conditions active in your area. Avoid exposed ridges and dry washes."
                : "Wind speeds reaching " + Math.round(data.wind_speed_kmh) + " km/h. Secure loose gear.",
            };
            setEmergency(alert);
            localStorage.setItem(cacheKey, JSON.stringify({ ts: Date.now(), emergency: alert }));
          } else {
            localStorage.setItem(cacheKey, JSON.stringify({ ts: Date.now(), emergency: null }));
          }
        } catch {
          // Weather fetch failed — silently skip
        }
      },
      () => {},
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 5 * 60 * 1000 }
    );

    return () => { cancelled = true; };
  }, []);

  return (
    <AnimatePresence>
      {emergency && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
          className="overflow-hidden"
        >
          <Link
            to={createPageUrl("WeatherSafety")}
            className="block rounded-2xl p-3.5 relative overflow-hidden group"
            style={{
              background: "linear-gradient(135deg, rgba(239,68,68,0.18) 0%, rgba(245,158,11,0.12) 100%)",
              border: "1px solid rgba(239,68,68,0.45)",
              boxShadow: "0 0 20px rgba(239,68,68,0.25), inset 0 1px 0 rgba(255,255,255,0.08)",
            }}
          >
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: "radial-gradient(ellipse at 20% 50%, rgba(239,68,68,0.12) 0%, transparent 70%)",
                animation: "rhCrystalEdge 2s ease-in-out infinite",
              }}
            />
            <div className="relative flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: "rgba(239,68,68,0.22)" }}
              >
                <AlertTriangle className="w-5 h-5" style={{ color: "#ef4444" }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <span
                    className="text-[10px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded"
                    style={{ background: "rgba(239,68,68,0.3)", color: "#fca5a5" }}
                  >
                    Emergency
                  </span>
                  <span className="text-sm font-bold" style={{ color: "#fef2f2" }}>
                    {emergency.label}
                  </span>
                </div>
                <p className="text-xs leading-snug" style={{ color: "rgba(254,242,242,0.75)" }}>
                  {emergency.message}
                </p>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <CloudSun className="w-4 h-4" style={{ color: "rgba(254,242,242,0.4)" }} />
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" style={{ color: "#fca5a5" }} />
              </div>
            </div>
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
}