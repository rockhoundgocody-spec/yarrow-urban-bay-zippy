import React, { useState, useEffect } from 'react';
import { fetchWeatherBoost } from '@/services/weatherBoostService';
import WeatherBoostBanner from './WeatherBoostBanner';

export default function WeatherBoostWidget() {
  const [boostData, setBoostData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!navigator.geolocation) { setLoading(false); return; }

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const data = await fetchWeatherBoost(pos.coords.latitude, pos.coords.longitude);
          setBoostData(data);
        } catch {}
        setLoading(false);
      },
      () => setLoading(false),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 2 * 60 * 1000 }
    );
  }, []);

  if (!loading && !boostData) return null;

  return <WeatherBoostBanner boostData={boostData} loading={loading} />;
}