import React from 'react';
import { Link } from 'react-router-dom';
import { Compass, MapPin } from 'lucide-react';

/** Empty + error states for the public specimen feed. */
export default function PublicFeedEmptyState({ radiusActive, error, onReset }) {
  if (error) {
    return (
      <div className="text-center py-14 px-6">
        <Compass className="w-10 h-10 mx-auto mb-3" style={{ color: 'rgba(255,255,255,0.12)' }} />
        <p className="text-sm font-semibold text-white">Couldn't load the feed</p>
        <p className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.35)' }}>
          Check your connection and try again.
        </p>
        <button
          onClick={onReset}
          className="mt-4 px-4 py-2 rounded-xl text-xs font-bold"
          style={{ background: 'rgba(122,231,255,0.10)', border: '1px solid rgba(122,231,255,0.30)', color: '#7AE7FF' }}
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="text-center py-14 px-6">
      <MapPin className="w-10 h-10 mx-auto mb-3" style={{ color: 'rgba(255,255,255,0.12)' }} />
      <p className="text-sm font-semibold text-white">
        {radiusActive ? 'No finds shared in this area yet' : 'No community finds yet'}
      </p>
      <p className="text-xs mt-1 max-w-xs mx-auto leading-relaxed" style={{ color: 'rgba(255,255,255,0.35)' }}>
        {radiusActive
          ? 'Try widening the search area — or be the first to share a find here.'
          : 'Share one of your finds to kick off the community feed.'}
      </p>
      <Link
        to="/VerifiedFindsMap"
        className="inline-block mt-4 px-4 py-2 rounded-xl text-xs font-bold"
        style={{ background: 'rgba(0,214,143,0.10)', border: '1px solid rgba(0,214,143,0.30)', color: '#00D68F' }}
      >
        Share a Find
      </Link>
    </div>
  );
}