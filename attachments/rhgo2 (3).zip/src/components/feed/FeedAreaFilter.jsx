import React from 'react';
import { Navigation, AlertCircle } from 'lucide-react';
import { RADIUS_OPTIONS, RARITY_OPTIONS, RARITY_COLOR } from '@/services/feed/publicFeedService';

function Chip({ active, color, children, onClick, label }) {
  return (
    <button
      onClick={onClick}
      aria-label={label}
      aria-pressed={active}
      className="tap-compact flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-bold capitalize transition-all"
      style={{
        background: active ? `${color}22` : 'rgba(255,255,255,0.04)',
        border: `1px solid ${active ? color : 'rgba(255,255,255,0.10)'}`,
        color: active ? color : 'rgba(255,255,255,0.45)',
        minHeight: 32,
      }}
    >
      {children}
    </button>
  );
}

/** Area + rarity filters for the public feed. */
export default function FeedAreaFilter({
  radius, onRadiusChange, rarity, onRarityChange, locationAvailable,
}) {
  return (
    <div className="space-y-2">
      {/* Area / radius */}
      <div className="flex gap-2 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
        {RADIUS_OPTIONS.map((opt) => {
          const disabled = opt.miles !== null && !locationAvailable;
          return (
            <Chip
              key={opt.id}
              active={radius === opt.id}
              color="#7AE7FF"
              label={opt.label}
              onClick={() => !disabled && onRadiusChange(opt.id)}
            >
              <span style={{ opacity: disabled ? 0.4 : 1 }} className="flex items-center gap-1">
                {opt.miles !== null && <Navigation className="w-3 h-3" />}
                {opt.label}
              </span>
            </Chip>
          );
        })}
      </div>

      {/* Rarity */}
      <div className="flex gap-2 overflow-x-auto pb-0.5" style={{ scrollbarWidth: 'none' }}>
        {RARITY_OPTIONS.map((r) => (
          <Chip
            key={r}
            active={rarity === r}
            color={RARITY_COLOR[r] || '#8D7CFF'}
            label={r === 'all' ? 'All rarities' : r}
            onClick={() => onRarityChange(r)}
          >
            {r === 'all' ? 'All Rarities' : r}
          </Chip>
        ))}
      </div>

      {!locationAvailable && (
        <div
          className="flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{ background: 'rgba(245,182,66,0.07)', border: '1px solid rgba(245,182,66,0.20)' }}
        >
          <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#F5B642' }} />
          <span className="text-xs" style={{ color: 'rgba(245,182,66,0.85)' }}>
            Enable location to filter finds near you.
          </span>
        </div>
      )}
    </div>
  );
}