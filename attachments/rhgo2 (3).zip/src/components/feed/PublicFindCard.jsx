import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, ThumbsUp, Gem, BadgeCheck } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { RARITY_COLOR, formatDistance } from '@/services/feed/publicFeedService';

/** A single community find in the public feed. Presentational only. */
export default function PublicFindCard({ find, delay = 0, onHelpful }) {
  const rarityColor = RARITY_COLOR[find.rarity] || RARITY_COLOR.common;
  const distance = formatDistance(find.distance_miles);
  const when = find.created_date
    ? formatDistanceToNow(new Date(find.created_date), { addSuffix: true })
    : null;

  return (
    <motion.article
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.25 }}
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.025)',
        border: '1px solid rgba(255,255,255,0.07)',
      }}
    >
      {find.photo_url && (
        <img
          src={find.photo_url}
          alt={find.mineral_name}
          loading="lazy"
          className="w-full object-cover"
          style={{ height: 190 }}
        />
      )}

      <div className="p-3.5">
        {/* Title + rarity */}
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Gem className="w-4 h-4 flex-shrink-0" style={{ color: rarityColor }} />
            <h3 className="text-base font-bold text-white truncate">{find.mineral_name}</h3>
          </div>
          <span
            className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full flex-shrink-0"
            style={{ background: `${rarityColor}1F`, color: rarityColor, border: `1px solid ${rarityColor}55` }}
          >
            {find.rarity || 'common'}
          </span>
        </div>

        {/* Area context */}
        <div className="flex flex-wrap items-center gap-x-2 gap-y-1 mt-1.5">
          {find.locality_name && (
            <span className="flex items-center gap-1 text-xs" style={{ color: 'rgba(255,255,255,0.5)' }}>
              <MapPin className="w-3 h-3" style={{ color: '#7AE7FF' }} />
              {find.locality_name}
            </span>
          )}
          {distance && (
            <span
              className="text-[10px] font-bold px-1.5 py-0.5 rounded"
              style={{ background: 'rgba(122,231,255,0.10)', color: '#7AE7FF' }}
            >
              {distance}
            </span>
          )}
        </div>

        {find.description && (
          <p className="text-xs mt-2 leading-relaxed" style={{ color: 'rgba(255,255,255,0.45)' }}>
            {find.description}
          </p>
        )}

        {/* Footer: finder, time, helpful */}
        <div className="flex items-center justify-between gap-2 mt-3 pt-2.5" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <div className="flex items-center gap-1.5 min-w-0">
            {find.verified_by_user && (
              <BadgeCheck className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#00D68F' }} />
            )}
            <span className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.4)' }}>
              {find.finder_display_name || 'A rockhound'}
            </span>
            {when && (
              <span className="text-[10px] flex-shrink-0" style={{ color: 'rgba(255,255,255,0.22)' }}>
                · {when}
              </span>
            )}
          </div>

          <button
            onClick={() => onHelpful?.(find)}
            className="tap-compact flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg"
            style={{
              background: 'rgba(0,214,143,0.08)',
              border: '1px solid rgba(0,214,143,0.22)',
              color: '#00D68F',
              fontSize: 11,
              fontWeight: 700,
              minHeight: 32,
            }}
            aria-label={`Mark ${find.mineral_name} as helpful`}
          >
            <ThumbsUp className="w-3 h-3" />
            {find.helpful_count || 0}
          </button>
        </div>
      </div>
    </motion.article>
  );
}