/**
 * AchievementUnlock — Full-screen celebration when badge is unlocked.
 * Plays confetti, animates badge reveal, shows XP gain.
 */
import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { getBadgeById } from '@/services/rewards/badgeDefinitions';

export default function AchievementUnlock({ badgeId, xpAwarded, isVisible, onClose }) {
  const badge = getBadgeById(badgeId);

  useEffect(() => {
    if (isVisible) {
      // Trigger confetti
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });

      // Auto-close after 4 seconds
      const timer = setTimeout(onClose, 4000);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onClose]);

  if (!badge) return null;

  const tierColors = {
    bronze: '#CD7F32',
    silver: '#C0C0C0',
    gold: '#FFD700',
    platinum: '#E5E4E2',
    legendary: '#FF6B9D',
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          key="unlock-overlay"
          className="fixed inset-0 z-50 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)' }}
        >
          <motion.div
            className="flex flex-col items-center"
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 20 }}
            transition={{ type: 'spring', stiffness: 100, damping: 15 }}
          >
            {/* Badge icon — large */}
            <motion.div
              className="text-9xl mb-6"
              animate={{ y: [0, -20, 0] }}
              transition={{ duration: 0.6, repeat: Infinity, repeatDelay: 1 }}
            >
              {badge.icon}
            </motion.div>

            {/* Badge name */}
            <h2 className="text-4xl font-black text-white mb-2 text-center">{badge.name}</h2>

            {/* Description */}
            <p className="text-sm text-white/60 text-center max-w-sm mb-6">{badge.description}</p>

            {/* Tier badge */}
            <div
              className="px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider mb-6"
              style={{
                background: tierColors[badge.tier],
                color: badge.tier === 'gold' || badge.tier === 'legendary' ? '#000' : '#fff',
              }}
            >
              {badge.tier}
            </div>

            {/* XP awarded */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="text-2xl font-black text-white flex items-center gap-2"
            >
              <span style={{ color: '#F5B642' }}>+{xpAwarded || badge.xp_reward}</span>
              <span style={{ color: '#F5B642' }}>XP</span>
            </motion.div>

            {/* Click to close hint */}
            <motion.p
              className="text-xs text-white/40 mt-8"
              animate={{ opacity: [0.4, 0.8, 0.4] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              Tap to continue
            </motion.p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}