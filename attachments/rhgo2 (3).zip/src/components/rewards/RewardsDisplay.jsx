/**
 * RewardsDisplay — Shows user's XP level, badges, and progress.
 * Embedded in profile or gamification hub.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Trophy } from 'lucide-react';
import { getUserLevel, getCategoryStats, getAllBadgesSorted } from '@/services/rewards/rewardsService';

export default function RewardsDisplay() {
  const [totalXP, setTotalXP] = useState(0);
  const [unlockedBadges, setUnlockedBadges] = useState([]);

  // Fetch user's total XP
  const { data: xpData } = useQuery({
    queryKey: ['userXP'],
    queryFn: async () => {
      const results = await base44.entities.UserXP.list();
      return results.reduce((sum, xp) => sum + (xp.amount || 0), 0);
    },
  });

  // Fetch user's unlocked badges
  const { data: badgeData } = useQuery({
    queryKey: ['userBadges'],
    queryFn: async () => {
      const results = await base44.entities.UserBadge.list();
      return results.map((b) => b.badge_id);
    },
  });

  useEffect(() => {
    if (xpData !== undefined) setTotalXP(xpData);
    if (badgeData) setUnlockedBadges(badgeData);
  }, [xpData, badgeData]);

  const levelInfo = getUserLevel(totalXP);
  const categoryStats = getCategoryStats(unlockedBadges);
  const allBadges = getAllBadgesSorted();

  return (
    <div className="space-y-6">
      {/* Level & XP Bar */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl p-6"
        style={{
          background: 'linear-gradient(135deg, rgba(122,231,255,0.1) 0%, rgba(0,214,143,0.05) 100%)',
          border: '1px solid rgba(122,231,255,0.2)',
        }}
      >
        {/* Level display */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className="w-16 h-16 rounded-full flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #7AE7FF 0%, #00D68F 100%)',
                boxShadow: '0 0 24px rgba(122,231,255,0.4)',
              }}
            >
              <span className="font-black text-2xl text-slate-900">{levelInfo.level}</span>
            </div>
            <div>
              <p className="text-sm font-bold text-white">Level {levelInfo.level}</p>
              <p className="text-xs text-white/50">{totalXP.toLocaleString()} total XP</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-black" style={{ color: '#7AE7FF' }}>
              {unlockedBadges.length}
            </p>
            <p className="text-xs text-white/50">Badges Earned</p>
          </div>
        </div>

        {/* XP Progress bar */}
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-xs font-bold text-white">{levelInfo.currentXP.toLocaleString()}</span>
            <span className="text-xs text-white/40">{levelInfo.nextLevelXP.toLocaleString()}</span>
          </div>
          <div
            className="h-2 rounded-full overflow-hidden"
            style={{ background: 'rgba(122,231,255,0.15)' }}
          >
            <motion.div
              className="h-full"
              style={{
                background: 'linear-gradient(90deg, #7AE7FF, #00D68F)',
              }}
              initial={{ width: 0 }}
              animate={{ width: `${(levelInfo.currentXP / levelInfo.nextLevelXP) * 100}%` }}
              transition={{ duration: 0.6 }}
            />
          </div>
        </div>
      </motion.div>

      {/* Category breakdown */}
      <div className="grid grid-cols-3 gap-3">
        {Object.entries(categoryStats).map(([category, count]) => (
          <motion.div
            key={category}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="p-3 rounded-xl text-center"
            style={{
              background: 'rgba(122,231,255,0.08)',
              border: '1px solid rgba(122,231,255,0.15)',
            }}
          >
            <p className="text-sm font-bold text-white capitalize">{category}</p>
            <p className="text-lg font-black" style={{ color: '#7AE7FF' }}>
              {count}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Badge grid */}
      <div>
        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
          <Trophy className="w-5 h-5" style={{ color: '#F5B642' }} />
          Achievements
        </h3>
        <div className="grid grid-cols-4 gap-3">
          {allBadges.map((badge) => {
            const unlocked = unlockedBadges.includes(badge.id);
            return (
              <motion.div
                key={badge.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                whileHover={{ scale: unlocked ? 1.05 : 1 }}
                className="relative rounded-xl p-2 flex flex-col items-center justify-center aspect-square cursor-pointer"
                style={{
                  background: unlocked
                    ? 'linear-gradient(135deg, rgba(245,182,66,0.15) 0%, rgba(122,231,255,0.1) 100%)'
                    : 'rgba(122,231,255,0.05)',
                  border: unlocked
                    ? '1px solid rgba(245,182,66,0.3)'
                    : '1px solid rgba(122,231,255,0.1)',
                  opacity: unlocked ? 1 : 0.5,
                }}
                title={badge.name}
              >
                <span className="text-2xl">{badge.icon}</span>
                <span className="text-[10px] text-white text-center mt-1 leading-tight font-bold">
                  {badge.name}
                </span>
                {unlocked && (
                  <div
                    className="absolute top-1 right-1 w-3 h-3 rounded-full"
                    style={{ background: '#00D68F', boxShadow: '0 0 6px #00D68F' }}
                  />
                )}
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}