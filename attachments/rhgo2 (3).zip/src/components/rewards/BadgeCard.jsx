import React from "react";
import { motion } from "framer-motion";
import {
  Gem,
  Package,
  Zap,
  Crown,
  Map,
  Compass,
  Star,
  Sparkles,
  Share2,
  Award,
  Beaker,
  Layers,
  Flame,
} from "lucide-react";
import { BADGE_RARITY_COLORS, getBadgeById } from "@/services/rewards/badgeDefinitions";

const ICON_MAP = {
  Gem,
  Package,
  Zap,
  Crown,
  Map,
  Compass,
  Star,
  Sparkles,
  Share2,
  Award,
  Beaker,
  Layers,
  Flame,
};

export default function BadgeCard({
  badgeId,
  earned = false,
  showDescription = true,
  size = "md",
  animated = true,
}) {
  const badge = getBadgeById(badgeId);
  if (!badge) return null;

  const colors = BADGE_RARITY_COLORS[badge.rarity] || BADGE_RARITY_COLORS.common;
  const Icon = ICON_MAP[badge.icon] || Gem;

  const sizeClass =
    size === "sm"
      ? "h-12 w-12"
      : size === "lg"
        ? "h-20 w-20"
        : "h-16 w-16";

  const inner = (
    <div className="flex flex-col items-center gap-2">
      <motion.div
        className={`flex items-center justify-center rounded-full border-2 ${sizeClass} ${colors.bg} ${colors.border} ${colors.text}`}
        animate={
          animated && earned
            ? {
                scale: [0.95, 1.05, 1],
                boxShadow: [
                  "0 0 0 0 rgba(139, 92, 246, 0)",
                  "0 0 16px 8px rgba(139, 92, 246, 0.2)",
                  "0 0 0 0 rgba(139, 92, 246, 0)",
                ],
              }
            : { scale: earned ? 1 : 0.8, opacity: earned ? 1 : 0.4 }
        }
        transition={{ duration: 0.6 }}
      >
        <Icon className={`${size === "sm" ? "h-5 w-5" : size === "lg" ? "h-10 w-10" : "h-7 w-7"}`} />
      </motion.div>

      {showDescription && size !== "sm" && (
        <div className="text-center">
          <div className={`text-sm font-bold ${colors.text}`}>{badge.name}</div>
          <div className="text-xs text-white/40">{badge.description}</div>
        </div>
      )}
    </div>
  );

  if (!showDescription || size === "sm") return inner;

  return (
    <motion.div
      className={`rounded-xl border-2 ${colors.bg} ${colors.border} p-4 text-center`}
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      {inner}
      {badge.xp_reward && (
        <div className="mt-2 text-xs font-semibold text-amber-300">
          +{badge.xp_reward} XP
        </div>
      )}
    </motion.div>
  );
}