/**
 * ProgressTracker — Shows user progress toward unlocking upcoming badges.
 * Displays conditions for next achievable badges.
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getAllBadgesSorted } from '@/services/rewards/badgeDefinitions';
import { checkBadgeQualification } from '@/services/rewards/rewardsService';
import { Zap } from 'lucide-react';

export default function ProgressTracker({ userProgress, unlockedBadges = [] }) {
  const [nextBadges, setNextBadges] = useState([]);

  useEffect(() => {
    // Find 3 closest achievable badges
    const unlockedSet = new Set(unlockedBadges);
    const upcoming = getAllBadgesSorted()
      .filter((b) => !unlockedSet.has(b.id))
      .slice(0, 3);

    setNextBadges(upcoming);
  }, [unlockedBadges, userProgress]);

  const getProgressPercent = (badge, userProgress) => {
    const { condition_type, condition_value } = badge;
    let current = 0;

    switch (condition_type) {
      case 'count':
        current = userProgress.total_finds || 0;
        break;
      case 'rarity_threshold':
        current = userProgress.max_rarity_found || 0;
        break;
      case 'location_count':
        current = userProgress.unique_locations || 0;
        break;
      case 'lesson_completion':
        current = userProgress.lessons_completed || 0;
        break;
      case 'streak':
        current = userProgress.current_streak || 0;
        break;
      case 'milestone':
        current = userProgress.collection_size || 0;
        break;
      default:
        return 0;
    }

    return Math.min((current / condition_value) * 100, 100);
  };

  return (
    <div className="space-y-4">
      <h3 className="font-bold text-white text-sm flex items-center gap-2">
        <Zap className="w-4 h-4" style={{ color: '#F5B642' }} />
        Next Achievements
      </h3>

      {nextBadges.length === 0 ? (
        <p className="text-xs text-white/40">All achievements unlocked!</p>
      ) : (
        nextBadges.map((badge) => {
          const progress = getProgressPercent(badge, userProgress);
          const isQualified = checkBadgeQualification(badge.id, userProgress);

          return (
            <motion.div
              key={badge.id}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="rounded-lg p-3"
              style={{
                background: isQualified
                  ? 'linear-gradient(135deg, rgba(245,182,66,0.15) 0%, rgba(122,231,255,0.1) 100%)'
                  : 'rgba(122,231,255,0.06)',
                border: isQualified
                  ? '1px solid rgba(245,182,66,0.3)'
                  : '1px solid rgba(122,231,255,0.1)',
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">{badge.icon}</span>
                  <div>
                    <p className="text-xs font-bold text-white">{badge.name}</p>
                    <p className="text-[10px] text-white/40 capitalize">{badge.category}</p>
                  </div>
                </div>
                <span
                  className="text-xs font-bold"
                  style={{ color: isQualified ? '#00D68F' : '#7AE7FF' }}
                >
                  {isQualified ? '✓ Ready!' : `${Math.round(progress)}%`}
                </span>
              </div>

              {/* Progress bar */}
              {!isQualified && (
                <div
                  className="h-1.5 rounded-full overflow-hidden"
                  style={{ background: 'rgba(122,231,255,0.1)' }}
                >
                  <motion.div
                    className="h-full"
                    style={{
                      background: 'linear-gradient(90deg, #7AE7FF, #00D68F)',
                    }}
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              )}
            </motion.div>
          );
        })
      )}
    </div>
  );
}