import React, { useState } from "react";
import { getAllBadges } from "@/services/rewards/badgeDefinitions";
import BadgeCard from "./BadgeCard";
import { motion } from "framer-motion";

export default function BadgeShowcase({ userBadges = [], isLoading = false, compact = false }) {
  const [allBadges] = useState(() => getAllBadges());
  const earnedIds = new Set(userBadges.map((b) => (typeof b === "string" ? b : b.badge_id)));

  const displayBadges = compact ? allBadges.slice(0, 6) : allBadges;
  const earnedCount = userBadges.length;
  const totalCount = allBadges.length;

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="h-5 w-32 animate-pulse rounded bg-white/10" />
        <div className="grid gap-3 grid-cols-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-xl bg-white/5" />
          ))}
        </div>
      </div>
    );
  }

  if (allBadges.length === 0) {
    return (
      <div className="text-center py-8 text-white/40 text-sm">
        No badges earned yet. Start your rockhounding journey!
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold uppercase tracking-wider text-white">Achievements</h3>
          <span className="text-xs text-white/50">
            {earnedCount} / {totalCount}
          </span>
        </div>
        <div className="mt-2 h-1.5 rounded-full bg-white/10 overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-cyan-400 to-violet-400"
            initial={{ width: 0 }}
            animate={{ width: `${(earnedCount / totalCount) * 100}%` }}
            transition={{ duration: 0.6 }}
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 md:grid-cols-4 lg:grid-cols-6">
        {displayBadges.map((badge) => (
          <BadgeCard
            key={badge.id}
            badgeId={badge.id}
            earned={earnedIds.has(badge.id)}
            showDescription={false}
            size="sm"
            animated
          />
        ))}
      </div>

      {compact && allBadges.length > 6 && (
        <div className="text-center pt-2">
          <span className="text-xs text-white/40">
            +{allBadges.length - 6} more badges to earn
          </span>
        </div>
      )}
    </div>
  );
}