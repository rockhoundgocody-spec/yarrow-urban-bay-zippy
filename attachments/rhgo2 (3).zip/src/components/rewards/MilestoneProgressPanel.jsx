import React from "react";
import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";
import { getNextMilestone } from "@/services/rewards/badgeProgressionService";

export default function MilestoneProgressPanel({
  metricType = "specimen_count",
  currentValue = 0,
  label = "Specimens Found",
}) {
  const milestone = getNextMilestone(metricType, currentValue);

  if (!milestone) {
    return (
      <div className="rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-4 text-center">
        <div className="text-xs uppercase tracking-wider text-emerald-300 font-semibold">
          🎉 Milestone Complete
        </div>
        <div className="mt-2 text-sm text-white/80">{label}</div>
        <div className="text-lg font-bold text-emerald-300">{currentValue}</div>
      </div>
    );
  }

  const percentProgress = Math.min(milestone.progress, 100);

  return (
    <motion.div
      className="rounded-xl border border-violet-300/20 bg-violet-500/8 p-4"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-violet-300" />
            <span className="text-xs uppercase tracking-wider text-violet-300 font-semibold">
              {label}
            </span>
          </div>

          <div className="mt-3 space-y-2">
            <div className="flex justify-between">
              <span className="text-sm font-semibold text-white">{currentValue}</span>
              <span className="text-sm text-white/50">{milestone.target}</span>
            </div>

            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-violet-400 to-cyan-400"
                initial={{ width: 0 }}
                animate={{ width: `${percentProgress}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>

            <div className="text-xs text-white/50">
              {milestone.target - currentValue} more to go
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}