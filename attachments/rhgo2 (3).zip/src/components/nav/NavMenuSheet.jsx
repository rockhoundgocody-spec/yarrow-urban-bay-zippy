/**
 * NavMenuSheet — grouped, searchable navigation for the dropdown menu (home mode).
 * Quick actions on top, color-coded sections below, instant search to jump anywhere.
 */
import React, { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, X } from "lucide-react";
import { createPageUrl } from "@/utils";
import { QUICK_ACTIONS, NAV_SECTIONS, ALL_NAV_ITEMS } from "./navRegistry";

function NavTile({ item, color, active, onNavigate, index }) {
  const Icon = item.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.025, 0.3), duration: 0.2 }}
    >
      <Link
        to={createPageUrl(item.page)}
        onClick={onNavigate}
        className="flex flex-col items-center gap-2 px-1.5 py-3.5 rounded-2xl transition-all duration-200 active:scale-95"
        style={{
          background: active ? `${color}14` : "rgba(255,255,255,0.04)",
          border: `1px solid ${active ? `${color}40` : "rgba(255,255,255,0.07)"}`,
        }}
      >
        <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${color}12` }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </div>
        <span className="text-[11px] text-center leading-tight font-medium"
          style={{ color: active ? color : "rgba(255,255,255,0.60)" }}>
          {item.name}
        </span>
      </Link>
    </motion.div>
  );
}

export default function NavMenuSheet({ currentPageName, onNavigate }) {
  const [query, setQuery] = useState("");
  const q = query.trim().toLowerCase();

  const results = useMemo(() => {
    if (!q) return null;
    return ALL_NAV_ITEMS.filter(
      (i) => i.name.toLowerCase().includes(q) || (i.keywords || "").includes(q) || i.section.toLowerCase().includes(q)
    );
  }, [q]);

  return (
    <div className="space-y-5">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30 pointer-events-none" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Jump to anything…"
          aria-label="Search navigation"
          className="w-full pl-10 pr-10 py-3 rounded-2xl bg-white/5 border border-white/10 text-white text-sm placeholder:text-white/25 focus:outline-none focus:border-[#8D7CFF]/40"
        />
        {query && (
          <button onClick={() => setQuery("")} aria-label="Clear search"
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-white/40 tap-compact">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Search results */}
      {results ? (
        results.length > 0 ? (
          <nav className="grid grid-cols-3 gap-2">
            {results.map((item, i) => (
              <NavTile key={item.page + item.name} item={item} color={item.color}
                active={currentPageName === item.page} onNavigate={onNavigate} index={i} />
            ))}
          </nav>
        ) : (
          <p className="text-center text-white/30 text-sm py-6">Nothing matches "{query}"</p>
        )
      ) : (
        <>
          {/* Quick actions */}
          <div className="grid grid-cols-4 gap-2">
            {QUICK_ACTIONS.map((qa, i) => {
              const Icon = qa.icon;
              return (
                <motion.div key={qa.page} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.04, type: "spring", stiffness: 400, damping: 24 }}>
                  <Link to={createPageUrl(qa.page)} onClick={onNavigate}
                    className="flex flex-col items-center gap-1.5 py-3 rounded-2xl transition-all active:scale-95"
                    style={{
                      background: `linear-gradient(160deg, ${qa.color}1E, ${qa.color}08)`,
                      border: `1px solid ${qa.color}35`,
                      boxShadow: `0 0 16px ${qa.color}12`,
                    }}>
                    <Icon className="w-5 h-5" style={{ color: qa.color }} />
                    <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: qa.color }}>{qa.name}</span>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          {/* Grouped sections */}
          {NAV_SECTIONS.map((section) => (
            <div key={section.label}>
              <div className="flex items-center gap-2 mb-2 px-1">
                <span className="w-1.5 h-1.5 rounded-full" style={{ background: section.color, boxShadow: `0 0 8px ${section.color}` }} />
                <span className="text-[10px] font-bold uppercase tracking-[0.14em]" style={{ color: `${section.color}CC` }}>
                  {section.label}
                </span>
                <div className="flex-1 h-px" style={{ background: `linear-gradient(90deg, ${section.color}22, transparent)` }} />
              </div>
              <nav className="grid grid-cols-3 gap-2">
                {section.items.map((item, i) => (
                  <NavTile key={item.page + item.name} item={item} color={section.color}
                    active={currentPageName === item.page} onNavigate={onNavigate} index={i} />
                ))}
              </nav>
            </div>
          ))}
        </>
      )}
    </div>
  );
}