/**
 * FooterNav — RockHound-GO crystalline control rail.
 * 5-tab: Explore | Collection | [Scan orb] | Community | Market
 * Premium dark glass surface. Scan orb is the dominant CTA.
 */
import React, { memo, useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Map, Gem, Users, ShoppingBag, Camera, Loader2, AlertCircle } from "lucide-react";
import { createPageUrl } from "@/utils";
import { useTabHistory } from "./TabHistoryContext";
import { useModeStore } from "@/lib/modeStore.jsx";
import { feedback } from "@/lib/feedbackSystem";
import { SCAN_STATE, getScanState, triggerCapture } from "@/pages/SpecimenIdentifier";

const TABS = [
  { icon: Map,    label: "Map",        page: "Explore",            color: "#00D68F", fieldColor: "#4AA354" },
  { icon: Gem,    label: "Vault",      page: "Collection",         color: "#7AE7FF", fieldColor: "#88FF99" },
  { icon: null,   label: "Scan",       page: "SpecimenIdentifier", color: "#F5B642", fieldColor: "#FFCC44", isCenter: true },
  { icon: Users,  label: "Community", page: "Community",          color: "#8D7CFF", fieldColor: "#7AE7FF" },
  { icon: ShoppingBag, label: "Market", page: "Marketplace",       color: "#F5B642", fieldColor: "#FFCC44" },
];

const PAGE_TO_TAB = {
  Home: "Home", Explore: "Explore", RockhoundingMap: "Explore", FieldMap: "Explore",
  OfflineMap: "Explore", TripPlanner: "Explore", ItineraryPlanner: "Explore",
  WeatherSafety: "Explore", LegalityIntelligence: "Explore", FieldTripManager: "Explore",
  RockhoundingAssistant: "Explore", TrailsRoutes: "Explore",
  Collection: "Collection", Mineralpedia: "Collection", GeoDex: "Collection",
  SpecimenViewer: "Collection", SpecimenDetail: "Collection",
  Community: "Community", SocialFeed: "Community", Discoveries: "Community",
  Profile: "Community", Guilds: "Community", Events: "Community",
  Challenges: "Community", FieldMissions: "Community", GamificationHub: "Community",
  Marketplace: "Marketplace", Market: "Marketplace", Store: "Marketplace",
  ShopProfile: "Marketplace", MarketIntelligence: "Marketplace",
  MarketSell: "Marketplace", QuickSell: "Marketplace", SellerCommandCenter: "Marketplace",
  TradeBoard: "Marketplace", CommerceEngine: "Marketplace", MarketAnalytics: "Marketplace",
  Orders: "Marketplace", OrderConfirmation: "Marketplace", Checkout: "Marketplace",
  SubscriptionManagement: "Marketplace", BillingAccount: "Marketplace", StorageSubscription: "Marketplace",
  DisputeDashboard: "Marketplace", SquareDashboard: "Marketplace",
  FieldTools: "Explore", FieldAlerts: "Explore",
  OfflineFieldMode: "Explore", FieldVoiceLogger: "Explore",
  AdminDashboard: "Home",
};

// ── Regular tab ───────────────────────────────────────────────────────────────
function NavTab({ tab, active, isField, onClick }) {
  const Icon = tab.icon;
  const color = isField ? tab.fieldColor : tab.color;

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={tab.label}
      aria-current={active ? "page" : undefined}
      className="relative flex flex-col items-center justify-center flex-1 transition-all"
      style={{ minHeight: 52, paddingTop: 8, paddingBottom: 6, gap: 3 }}
    >
      {/* Active indicator — luminous line */}
      <AnimatePresence>
        {active && (
          <motion.div
            className="absolute top-0 left-1/2 -translate-x-1/2"
            initial={{ scaleX: 0, opacity: 0 }}
            animate={{ scaleX: 1, opacity: 1 }}
            exit={{ scaleX: 0, opacity: 0 }}
            transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
            style={{
              width: 24,
              height: 2,
              background: `linear-gradient(90deg, transparent, ${color}, transparent)`,
              borderRadius: 2,
              boxShadow: `0 0 8px ${color}80`,
            }}
          />
        )}
      </AnimatePresence>

      {/* Icon container */}
      <motion.div
        animate={{ scale: active ? 1.08 : 1 }}
        transition={{ duration: 0.2 }}
        className="relative flex items-center justify-center"
        style={{ width: 28, height: 28 }}
      >
        {active && (
          <motion.div
            className="absolute inset-0 rounded-lg"
            style={{ background: `${color}12`, border: `1px solid ${color}20` }}
            layoutId={`tab-bg-${tab.page}`}
          />
        )}
        <Icon
          style={{
            width: 18,
            height: 18,
            color: active ? color : "rgba(255,255,255,0.45)",
            transition: "color 0.15s ease",
            filter: active ? `drop-shadow(0 0 6px ${color}60)` : 'none',
            position: 'relative',
            zIndex: 1,
          }}
        />
      </motion.div>

      {/* Label */}
      <span style={{
        fontSize: 9,
        fontWeight: active ? 700 : 500,
        letterSpacing: "0.10em",
        textTransform: "uppercase",
        color: active ? color : "rgba(255,255,255,0.40)",
        transition: "color 0.15s ease",
        textShadow: active ? `0 0 10px ${color}60` : 'none',
      }}>
        {tab.label}
      </span>
    </button>
  );
}

// ── Scan state → orb config ────────────────────────────────────────────────────
function getOrbConfig(scanState, isField) {
  const gold = isField ? "#FFCC44" : "#F5B642";
  switch (scanState) {
    case SCAN_STATE.READY:      return { color: gold,      label: "Capture",   icon: "camera", pulse: true };
    case SCAN_STATE.CAPTURING:  return { color: gold,      label: "Capturing", icon: "camera", locked: true };
    case SCAN_STATE.REQUESTING: return { color: "#7AE7FF", label: "Starting…", icon: "loader", locked: true };
    case SCAN_STATE.ANALYZING:  return { color: "#00D68F", label: "Analysing", icon: "loader", locked: true };
    case SCAN_STATE.RESULT:     return { color: "#00D68F", label: "Done",      icon: "camera" };
    case SCAN_STATE.ERROR:      return { color: "#F5B642", label: "Retry",     icon: "camera" };
    default:                    return { color: gold,      label: "Scan",      icon: "camera", pulse: true };
  }
}

// ── Center Scan Orb — crystalline gem button ──────────────────────────────────
function ScanOrb({ isOnScanRoute, isField, onClick }) {
  const [pressed, setPressed] = useState(false);
  const [scanState, setScanState] = useState(() => getScanState());

  useEffect(() => {
    const handler = (e) => setScanState(e.detail);
    window.addEventListener("scan:statechange", handler);
    return () => window.removeEventListener("scan:statechange", handler);
  }, []);

  const cfg = isOnScanRoute ? getOrbConfig(scanState, isField) : getOrbConfig(SCAN_STATE.IDLE, isField);

  return (
    <div className="flex flex-col items-center justify-center flex-shrink-0" style={{ width: 72, marginTop: -22 }}>
      <motion.button
        type="button"
        onClick={cfg.locked ? undefined : onClick}
        onPointerDown={() => !cfg.locked && setPressed(true)}
        onPointerUp={() => setPressed(false)}
        onPointerLeave={() => setPressed(false)}
        aria-label={isOnScanRoute ? "Capture specimen photo" : "Open Specimen Scanner"}
        className="relative flex items-center justify-center"
        style={{ width: 60, height: 60, borderRadius: 20, cursor: cfg.locked ? "default" : "pointer" }}
        animate={{ scale: pressed ? 0.90 : 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 26 }}
      >
        {/* Outer pulse ring — CSS-driven, no JS animation loop */}
        {cfg.pulse && (
          <div
            className="absolute pointer-events-none"
            style={{
              inset: -4,
              borderRadius: 24,
              border: `1.5px solid ${cfg.color}40`,
              animation: "rhRingPulse 2.6s ease-out infinite",
            }}
          />
        )}

        {/* Beveled gem surface */}
        <div
          className="absolute inset-0"
          style={{
            borderRadius: 20,
            background: `radial-gradient(circle at 35% 30%, ${cfg.color}50 0%, ${cfg.color}20 40%, ${cfg.color}08 100%)`,
            border: `1.5px solid ${cfg.color}80`,
            boxShadow: [
              `0 0 0 1px ${cfg.color}20`,
              `0 0 24px ${cfg.color}50`,
              `0 4px 20px rgba(0,0,0,0.6)`,
              `inset 0 1px 0 rgba(255,255,255,0.18)`,
              `inset 0 -1px 0 rgba(0,0,0,0.3)`,
            ].join(', '),
            transition: "all 0.25s",
          }}
        />

        {/* Crystal facet shimmer */}
        <div
          className="absolute pointer-events-none"
          style={{
            inset: 2,
            borderRadius: 18,
            background: 'linear-gradient(135deg, rgba(255,255,255,0.12) 0%, transparent 50%)',
          }}
        />

        {/* Icon */}
        <div style={{ position: "relative", zIndex: 1 }}>
          {cfg.icon === "loader" && (
            <Loader2 style={{ width: 26, height: 26, color: cfg.color }} className="animate-spin" />
          )}
          {cfg.icon === "error" && (
            <AlertCircle style={{ width: 26, height: 26, color: cfg.color }} />
          )}
          {cfg.icon === "camera" && (
            <Camera style={{
              width: 26,
              height: 26,
              color: "#fff",
              filter: `drop-shadow(0 0 8px ${cfg.color}90)`,
              transition: "color 0.12s",
            }} />
          )}
        </div>
      </motion.button>

      <span
        className="mt-1.5 uppercase font-bold"
        style={{
          fontSize: 8,
          color: cfg.color,
          letterSpacing: "0.18em",
          transition: "color 0.25s",
          textShadow: `0 0 8px ${cfg.color}60`,
        }}
      >
        {cfg.label}
      </span>
    </div>
  );
}

// ── Main FooterNav ─────────────────────────────────────────────────────────────
function FooterNav({ currentPageName }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { setTabLastUrl, getTabLastUrl, saveScroll, getSavedScroll } = useTabHistory();
  const { isField } = useModeStore();
  const scrollRestored = useRef(false);
  const hasEnteredRef = useRef(false);

  const isIdentifyRoute =
    location.pathname === "/SpecimenIdentifier" ||
    location.pathname === "/Identify" ||
    location.pathname === "/Scan";

  useEffect(() => {
    const tab = PAGE_TO_TAB[currentPageName] || currentPageName;
    setTabLastUrl(tab, location.pathname + location.search);
    scrollRestored.current = false;
  }, [location.pathname, location.search, currentPageName, setTabLastUrl]);

  useEffect(() => {
    const key = location.pathname + location.search;
    const onScroll = () => saveScroll(key, window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [location.pathname, location.search, saveScroll]);

  useEffect(() => {
    if (scrollRestored.current) return;
    scrollRestored.current = true;
    const key = location.pathname + location.search;
    const saved = getSavedScroll(key);
    if (saved > 0) requestAnimationFrame(() => requestAnimationFrame(() => window.scrollTo(0, saved)));
  }, [location.pathname, location.search, getSavedScroll]);

  const handleNavClick = (e, page) => {
    e.preventDefault();
    const currentTab = PAGE_TO_TAB[currentPageName] || currentPageName;
    if (currentTab === page) {
      navigate(createPageUrl(page), { replace: true });
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      const lastUrl = getTabLastUrl(page);
      navigate(lastUrl && lastUrl !== createPageUrl(page) ? lastUrl : createPageUrl(page));
    }
  };

  const handleOrbClick = (e) => {
    feedback.scan(e?.nativeEvent || e);
    if (!isIdentifyRoute) {
      navigate(createPageUrl("SpecimenIdentifier"));
      return;
    }
    triggerCapture();
  };

  const currentTab = PAGE_TO_TAB[currentPageName] || currentPageName;

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-50 px-3"
      style={{ paddingBottom: "max(env(safe-area-inset-bottom, 0px), 12px)" }}
    >
      <style>{`
@keyframes rhCrystalSweepX {
  0%   { transform: translateX(-130%) skewX(-18deg); opacity: 0; }
  8%   { opacity: 0.7; }
  92%  { opacity: 0.7; }
  100% { transform: translateX(230%) skewX(-18deg); opacity: 0; }
}
@keyframes rhCrystalConic {
  0%   { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
@keyframes rhCrystalEdgePulse {
  0%, 100% { opacity: 0.35; }
  50%      { opacity: 0.7; }
}
`}</style>
      <motion.div
        className="pointer-events-auto relative mx-auto overflow-visible"
        style={{ maxWidth: 430, borderRadius: 26 }}
        initial={hasEnteredRef.current ? false : { y: 64, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        onAnimationComplete={() => { hasEnteredRef.current = true; }}
        transition={{ type: "spring", stiffness: 340, damping: 32, delay: 0.05 }}
      >
        {/* Glass surface — crystalline control rail (overflow visible so the scan orb isn't clipped) */}
        <div
          className="relative"
          style={{
            background: isField
              ? "linear-gradient(180deg, rgba(4,12,6,0.92) 0%, rgba(2,8,4,0.97) 100%)"
              : "linear-gradient(180deg, rgba(10,9,24,0.88) 0%, rgba(5,5,16,0.95) 100%)",
            backdropFilter: "blur(12px)",
            WebkitBackdropFilter: "blur(12px)",
            border: isField
              ? "1px solid rgba(74,163,84,0.26)"
              : "1px solid rgba(141,124,255,0.18)",
            borderRadius: 26,
            boxShadow: isField
              ? "0 -4px 32px rgba(0,0,0,0.75), 0 0 44px rgba(74,163,84,0.08), inset 0 1px 0 rgba(255,255,255,0.06), inset 0 -1px 0 rgba(0,0,0,0.3)"
              : "0 -4px 32px rgba(0,0,0,0.75), 0 0 44px rgba(141,124,255,0.06), inset 0 1px 0 rgba(255,255,255,0.06), inset 0 -1px 0 rgba(0,0,0,0.3)",
            paddingLeft: 4,
            paddingRight: 4,
            paddingTop: 4,
            paddingBottom: 4,
          }}
        >
          {/* Decorative layers — clipped to the rail so the raised orb stays visible */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none" style={{ borderRadius: 26 }}>
          {/* Top edge highlight — pulsing crystal refraction */}
          <div
            className="absolute inset-x-0 top-0 h-px pointer-events-none"
            style={{
              borderRadius: '26px 26px 0 0',
              background: isField
                ? "linear-gradient(90deg, transparent, rgba(74,163,84,0.35) 30%, rgba(136,255,153,0.25) 50%, rgba(74,163,84,0.35) 70%, transparent)"
                : "linear-gradient(90deg, transparent, rgba(141,124,255,0.30) 30%, rgba(122,231,255,0.25) 50%, rgba(141,124,255,0.30) 70%, transparent)",
            }}
          />
          </div>

          {/* Tab row */}
          <div className="flex items-end relative z-10">
            {TABS.map((tab) => {
              if (tab.isCenter) {
                return (
                  <ScanOrb
                    key="scan"
                    isOnScanRoute={isIdentifyRoute}
                    isField={isField}
                    onClick={handleOrbClick}
                  />
                );
              }
              const active = currentTab === tab.page;
              return (
                <NavTab
                  key={tab.page}
                  tab={tab}
                  active={active}
                  isField={isField}
                  onClick={(e) => handleNavClick(e, tab.page)}
                />
              );
            })}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default memo(FooterNav);