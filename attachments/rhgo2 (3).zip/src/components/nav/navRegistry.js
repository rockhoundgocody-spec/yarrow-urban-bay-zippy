/**
 * navRegistry — single source of truth for the in-app navigation menu.
 * Every page here maps to a real route in App.jsx / pages.config.
 */
import {
  Map, Footprints, Compass, CloudSun, ShieldCheck, Heart,
  Gem, History, BookOpen, Sparkles, Newspaper, Hourglass,
  Users, ShoppingBag, TrendingUp, Star, UserPlus, Target,
  UserCircle, Bell, Settings, LifeBuoy, Camera, Trophy, Repeat, GraduationCap,
} from "lucide-react";

export const QUICK_ACTIONS = [
  { name: "Scan",   icon: Camera, page: "SpecimenIdentifier", color: "#F5B642" },
  { name: "Map",    icon: Map,    page: "Explore",            color: "#00D68F" },
  { name: "Vault",  icon: Gem,    page: "Collection",         color: "#7AE7FF" },
  { name: "Quests", icon: Target, page: "DailyQuestHub",      color: "#8D7CFF" },
];

export const NAV_SECTIONS = [
  {
    label: "Explore & Field",
    color: "#00D68F",
    items: [
      { name: "Live Map",       icon: Map,         page: "Explore",              keywords: "explore sites hotspots" },
      { name: "Trails & Routes",icon: Footprints,  page: "TrailsRoutes",         keywords: "hiking paths" },
      { name: "Trip Planner",   icon: Compass,     page: "TripPlanner",          keywords: "expedition itinerary" },
      { name: "Field Safety",   icon: CloudSun,    page: "WeatherSafety",        keywords: "weather hazards" },
      { name: "Legal Access",   icon: ShieldCheck, page: "LegalityIntelligence", keywords: "land permits blm" },
      { name: "Saved Sites",    icon: Heart,       page: "SavedSites",           keywords: "favorites bookmarks" },
    ],
  },
  {
    label: "Your Collection",
    color: "#7AE7FF",
    items: [
      { name: "My Vault",     icon: Gem,        page: "Collection",      keywords: "specimens rocks minerals" },
      { name: "Scan History", icon: History,    page: "ScanHistory",     keywords: "past identifications" },
      { name: "Geo-Dex",      icon: Sparkles,   page: "GeoDex",          keywords: "catalog dex species" },
      { name: "Valuation",    icon: TrendingUp, page: "MarketAnalytics", keywords: "worth value price" },
    ],
  },
  {
    label: "Play & Progress",
    color: "#F5B642",
    items: [
      { name: "Daily Quests",  icon: Target,   page: "DailyQuestHub",     keywords: "missions tasks" },
      { name: "Challenges",    icon: Trophy,   page: "Challenges",        keywords: "compete goals" },
      { name: "My Progress",   icon: TrendingUp, page: "ProgressDashboard", keywords: "xp level stats streak" },
      { name: "Badges",        icon: Star,     page: "BadgeShowcase",     keywords: "achievements awards" },
      { name: "Invite & Earn", icon: UserPlus, page: "ReferralHub",       keywords: "referral friends rewards" },
    ],
  },
  {
    label: "Community & Market",
    color: "#8D7CFF",
    items: [
      { name: "Community",   icon: Users,       page: "Community",           keywords: "feed posts social" },
      { name: "Discoveries", icon: Compass,     page: "SocialDiscoveryFeed", keywords: "finds shared" },
      { name: "Expeditions", icon: Footprints,  page: "FieldExpeditionHub",  keywords: "group trips" },
      { name: "Marketplace", icon: ShoppingBag, page: "Marketplace",         keywords: "buy sell shop" },
      { name: "Trade Board", icon: Repeat,      page: "TradeBoard",          keywords: "swap trading" },
    ],
  },
  {
    label: "Learn",
    color: "#D4AF37",
    items: [
      { name: "Learn Hub",      icon: GraduationCap, page: "EducationHub",   keywords: "lessons education courses" },
      { name: "Mineralpedia",   icon: BookOpen,      page: "Mineralpedia",   keywords: "encyclopedia database reference" },
      { name: "Science News",   icon: Newspaper,     page: "MineralNewsFeed",keywords: "articles geology news" },
      { name: "Geo Tutor",      icon: Sparkles,      page: "GeoTutorChat",   keywords: "ai chat questions tutor" },
      { name: "Chronolith Lab", icon: Hourglass,     page: "Chronolith",     keywords: "deep time forensics cases" },
    ],
  },
  {
    label: "Account",
    color: "#93A2BC",
    items: [
      { name: "Profile",       icon: UserCircle, page: "Profile",       keywords: "me account settings" },
      { name: "Notifications", icon: Bell,       page: "Notifications", keywords: "alerts inbox" },
      { name: "Pricing",       icon: Star,       page: "Pricing",       keywords: "premium upgrade plans subscribe" },
      { name: "Settings",      icon: Settings,   page: "AppSettings",   keywords: "preferences options" },
      { name: "Help",          icon: LifeBuoy,   page: "HelpSupport",   keywords: "faq support contact" },
    ],
  },
];

// Flat list for search
export const ALL_NAV_ITEMS = NAV_SECTIONS.flatMap((s) =>
  s.items.map((i) => ({ ...i, color: s.color, section: s.label }))
);