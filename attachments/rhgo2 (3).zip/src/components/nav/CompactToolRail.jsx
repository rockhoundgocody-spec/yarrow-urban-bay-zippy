/**
 * CompactToolRail — slim, auto-hiding sticky tool bar.
 * Sits just below the app header. Icon-only (no labels) to minimize footprint.
 * Hides on scroll-down, reveals on scroll-up so it never wastes screen space.
 * Mode-aware (home = amethyst, field = green).
 */
import React, { memo, useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Camera, Map, Gem, Target, CloudSun, Compass } from "lucide-react";
import { createPageUrl } from "@/utils";
import { useModeStore } from "@/lib/modeStore.jsx";
import { feedback } from "@/lib/feedbackSystem";
import { SCAN_STATE, getScanState, triggerCapture } from "@/pages/SpecimenIdentifier";

const TOOLS = [
  { id: "scan",    icon: Camera,   page: "SpecimenIdentifier", color: "#F5B642", fieldColor: "#FFCC44", label: "Scan" },
  { id: "map",     icon: Map,      page: "Explore",            color: "#00D68F", fieldColor: "#4AA354", label: "Map" },
  { id: "vault",   icon: Gem,      page: "Collection",         color: "#7AE7FF", fieldColor: "#88FF99", label: "Vault" },
  { id: "quests",  icon: Target,   page: "DailyQuestHub",      color: "#8D7CFF", fieldColor: "#7AE7FF", label: "Quests" },
  { id: "weather", icon: CloudSun, page: "WeatherSafety",      color: "#7AE7FF", fieldColor: "#88FF99", label: "Weather" },
  { id: "trip",    icon: Compass,  page: "TripPlanner",        color: "#D4AF37", fieldColor: "#FFCC44", label: "Trip" },
];

// Pages where the rail shouldn't render (full-bleed camera / map / immersive)
const HIDDEN_ROUTES = new Set([
  "/SpecimenIdentifier", "/Identify", "/Scan",
  "/Explore", "/FieldMap", "/RockhoundingMap",
]);

function CompactToolRail() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isField } = useModeStore();
  const [visible, setVisible] = useState(true);
  const [scanState, setScanState] = useState(() => getScanState());
  const lastScroll = useRef(0);
  const hiding = useRef(false);

  // Track scan state so the scan icon reflects live capture status
  useEffect(() => {
    const handler = (e) => setScanState(e.detail);
    window.addEventListener("scan:statechange", handler);
    return () => window.removeEventListener("scan:statechange", handler);
  }, []);

  // Auto-hide on scroll down, reveal on scroll up (within the main scroll container)
  useEffect(() => {
    const main = document.querySelector("main");
    if (!main) return;
    const onScroll = () => {
      const y = main.scrollTop;
      const delta = y - lastScroll.current;
      lastScroll.current = y;
      if (y < 8) { setVisible(true); return; }
      if (delta > 6 && !hiding.current) { hiding.current = true; setVisible(false); }
      else if (delta < -6 && hiding.current) { hiding.current = false; setVisible(true); }
    };
    main.addEventListener("scroll", onScroll, { passive: true });
    return () => main.removeEventListener("scroll", onScroll);
  }, []);

  // Always show on route change
  useEffect(() => {
    setVisible(true);
    hiding.current = false;
    lastScroll.current = 0;
  }, [location.pathname]);

  if (HIDDEN_ROUTES.has(location.pathname)) return null;

  const isIdentifyRoute = location.pathname === "/SpecimenIdentifier";
  const accent = isField ? "#4AA354" : "#8D7CFF";

  const handleClick = (tool, e) => {
    e.preventDefault();
    if (tool.id === "scan") {
      feedback.scan(e?.nativeEvent || e);
      if (!isIdentifyRoute) {
        navigate(createPageUrl(tool.page));
        return;
      }
      triggerCapture();
      return;
    }
    navigate(createPageUrl(tool.page));
  };

  const scanBusy = isIdentifyRoute && (scanState === SCAN_STATE.CAPTURING || scanState === SCAN_STATE.REQUESTING || scanState === SCAN_STATE.ANALYZING);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="compact-rail"
          initial={{ y: -56, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -56, opacity: 0 }}
          transition={{ type: "spring", stiffness: 420, damping: 34 }}
          className="pointer-events-none absolute inset-x-0 z-40 px-3"
          style={{ top: "calc(4rem + env(safe-area-inset-top, 0px) + 6px)" }}
        >
          <div
            className="pointer-events-auto mx-auto flex items-center justify-between gap-1"
            style={{
              maxWidth: 430,
              height: 44,
              padding: "0 6px",
              borderRadius: 16,
              background: isField
                ? "linear-gradient(180deg, rgba(4,12,6,0.92) 0%, rgba(2,8,4,0.96) 100%)"
                : "linear-gradient(180deg, rgba(10,9,24,0.90) 0%, rgba(5,5,16,0.95) 100%)",
              backdropFilter: "blur(10px)",
              WebkitBackdropFilter: "blur(10px)",
              border: `1px solid ${isField ? "rgba(74,163,84,0.24)" : "rgba(141,124,255,0.20)"}`,
              boxShadow: isField
                ? "0 4px 18px rgba(0,0,0,0.6), 0 0 18px rgba(74,163,84,0.06), inset 0 1px 0 rgba(255,255,255,0.05)"
                : "0 4px 18px rgba(0,0,0,0.6), 0 0 18px rgba(141,124,255,0.06), inset 0 1px 0 rgba(255,255,255,0.05)",
            }}
          >
            {/* Brand tick */}
            <div className="flex items-center gap-1.5 pl-1 pr-1.5 mr-0.5" style={{ borderRight: `1px solid ${isField ? "rgba(74,163,84,0.18)" : "rgba(141,124,255,0.16)"}` }}>
              <div style={{ width: 6, height: 6, borderRadius: 2, background: accent, boxShadow: `0 0 8px ${accent}` }} />
            </div>

            {TOOLS.map((tool) => {
              const Icon = tool.icon;
              const color = isField ? tool.fieldColor : tool.color;
              const active = location.pathname === `/${tool.page}`;
              const busy = tool.id === "scan" && scanBusy;
              return (
                <button
                  key={tool.id}
                  type="button"
                  onClick={(e) => handleClick(tool, e)}
                  aria-label={tool.label}
                  aria-current={active ? "page" : undefined}
                  className="relative flex items-center justify-center transition-all tap-compact"
                  style={{ width: 38, height: 38, borderRadius: 12, flexShrink: 0 }}
                >
                  {active && (
                    <motion.div
                      layoutId="compact-rail-active"
                      className="absolute inset-0"
                      style={{ borderRadius: 12, background: `${color}14`, border: `1px solid ${color}30` }}
                      transition={{ type: "spring", stiffness: 500, damping: 38 }}
                    />
                  )}
                  <Icon
                    style={{
                      width: 18,
                      height: 18,
                      color: active ? color : "rgba(255,255,255,0.52)",
                      filter: active ? `drop-shadow(0 0 5px ${color}70)` : "none",
                      transition: "color 0.15s ease, filter 0.15s ease",
                      position: "relative",
                      zIndex: 1,
                      animation: busy ? "spin 0.8s linear infinite" : undefined,
                    }}
                  />
                </button>
              );
            })}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default memo(CompactToolRail);