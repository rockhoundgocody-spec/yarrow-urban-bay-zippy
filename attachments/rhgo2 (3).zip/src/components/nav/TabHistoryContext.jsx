import React, { createContext, useContext, useRef, useCallback } from "react";

// Per-tab last URL stack + in-memory back-stack
const TabHistoryContext = createContext({
  setTabLastUrl: () => {},
  getTabLastUrl: () => null,
  saveScroll: () => {},
  getSavedScroll: () => 0,
  pushHistory: () => {},
  popHistory: () => null,
  canGoBack: () => false,
  TAB_PAGES: [],
});

const TAB_PAGES = ["Home", "RockhoundingMap", "Identify", "Collection", "Profile"];

function getInitialTabUrls() {
  try {
    return JSON.parse(sessionStorage.getItem("rh_tab_urls") || "{}");
  } catch {
    return {};
  }
}

export function TabHistoryProvider({ children }) {
  const tabLastUrl = useRef(null);
  if (tabLastUrl.current === null) {
    tabLastUrl.current = getInitialTabUrls();
  }

  const navStack = useRef([]);
  const scrollCache = useRef({});

  const setTabLastUrl = useCallback((tab, url) => {
    tabLastUrl.current[tab] = url;
    try { sessionStorage.setItem("rh_tab_urls", JSON.stringify(tabLastUrl.current)); } catch {}
  }, []);

  const getTabLastUrl = useCallback((tab) => {
    return tabLastUrl.current[tab] || null;
  }, []);

  const saveScroll = useCallback((url, y) => {
    scrollCache.current[url] = y;
  }, []);

  const getSavedScroll = useCallback((url) => {
    return scrollCache.current[url] ?? 0;
  }, []);

  const pushHistory = useCallback((url) => {
    navStack.current.push(url);
    if (navStack.current.length > 50) navStack.current.shift();
  }, []);

  const popHistory = useCallback(() => {
    return navStack.current.pop() ?? null;
  }, []);

  const canGoBack = useCallback(() => navStack.current.length > 0, []);

  return (
    <TabHistoryContext.Provider value={{
      setTabLastUrl, getTabLastUrl,
      saveScroll, getSavedScroll,
      pushHistory, popHistory, canGoBack,
      TAB_PAGES,
    }}>
      {children}
    </TabHistoryContext.Provider>
  );
}

export function useTabHistory() {
  return useContext(TabHistoryContext);
}