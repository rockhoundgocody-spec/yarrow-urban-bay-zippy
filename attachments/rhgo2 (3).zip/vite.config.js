import base44 from "@base44/vite-plugin"
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  logLevel: 'error', // Suppress warnings, only show errors
  plugins: [
    base44({
      // Support for legacy code that imports the base44 SDK with @/integrations, @/entities, etc.
      // can be removed if the code has been updated to use the new SDK imports from @base44/sdk
      legacySDKImports: process.env.BASE44_LEGACY_SDK_IMPORTS === 'true',
      hmrNotifier: true,
      navigationNotifier: true,
      visualEditAgent: true
    }),
    react(),
  ],
  // Pre-bundle core deps up front. After the dependency upgrade, progressive
  // dep discovery was re-optimizing mid-load and aborting dynamic imports
  // ("Failed to fetch dynamically imported module: src/App.jsx").
  optimizeDeps: {
    include: [
      'react', 'react-dom', 'react-router-dom', 'framer-motion',
      '@tanstack/react-query', 'lucide-react', 'date-fns', 'lodash',
      'zustand', 'clsx', 'tailwind-merge', 'class-variance-authority',
      'react-hook-form', 'recharts', 'moment', 'zod', 'axios', 'sonner',
      'vaul',
      '@radix-ui/react-dialog', '@radix-ui/react-toast', '@radix-ui/react-select',
      '@radix-ui/react-popover', '@radix-ui/react-tooltip',
      '@radix-ui/react-scroll-area', '@radix-ui/react-tabs',
      '@radix-ui/react-slot', '@radix-ui/react-label',
      '@radix-ui/react-checkbox', '@radix-ui/react-switch',
      '@radix-ui/react-progress', '@radix-ui/react-accordion',
      '@radix-ui/react-avatar', '@radix-ui/react-separator',
      '@radix-ui/react-slider', '@radix-ui/react-alert-dialog',
      '@radix-ui/react-hover-card', '@radix-ui/react-radio-group',
      '@radix-ui/react-dropdown-menu',
      'next-themes', 'react-hot-toast', 'react-markdown',
      'canvas-confetti', 'cmdk',
    ],
  },
  // ── Code-splitting / "compress + defrag" ────────────────────────────────
  // Isolate heavy vendor libs into cacheable chunks so they don't bloat the
  // main entry and can be cached independently across deploys.
  build: {
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules')) {
            if (id.includes('/three/')) return 'vendor-three';
            if (id.includes('maplibre-gl') || id.includes('/leaflet/') || id.includes('react-leaflet') || id.includes('leaflet.heat') || id.includes('supercluster')) return 'vendor-map';
            if (id.includes('/recharts/') || id.includes('/d3-')) return 'vendor-charts';
            if (id.includes('/framer-motion/')) return 'vendor-motion';
            if (id.includes('/html2canvas/') || id.includes('/jspdf/')) return 'vendor-pdf';
            if (id.includes('react-quill')) return 'vendor-editor';
            if (id.includes('@hello-pangea')) return 'vendor-dnd';
            if (id.includes('@tanstack')) return 'vendor-query';
            if (id.includes('/react/') || id.includes('/react-dom/') || id.includes('/react-router') || id.includes('/scheduler/')) return 'vendor-react';
            return 'vendor-misc';
          }
        }
      }
    }
  }
});